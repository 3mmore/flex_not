# FLEXORA Gym OS

Multi-tenant gym management SaaS — NestJS API + Next.js web app + Flutter member/staff apps.

## v3.5.0 — Live-verified bug-fix round (2026-08-18)

Every item below was reproduced live against a running stack (API + web + Postgres + Redis),
fixed at its root cause, and re-verified live. Evidence for each is in the commit/PR notes.

### A. Member edit 400 validation errors — FIXED
- **Root cause:** the members page edit payload always included `invitationSlots` (not a field
  of `UpdateMemberDto`) and sent the list's *derived* lowercase status (`active`/`expired`),
  which is not the stored `MemberStatus` enum. The 3-part-name rule also blocked editing
  members with 2-part names.
- **Fix:** `apps/web/src/app/members/page.tsx` now builds a strict whitelist of
  `UpdateMemberDto` fields (no `invitationSlots`, no `status` — membership state is driven by
  plan/expiry/frozen), and `apps/api/src/modules/members/dto.ts` relaxed the name rule to
  `@MinLength(2)` on update. Verified: PATCH returns 200 and persists.

### B. Lead creation 400 validation errors — FIXED
- **Root cause:** the CRM page (`/crm`) sent a free-text `source` (defaulting to `''`) and
  offered status options (`FOLLOW_UP`, `TRIAL`) that are not `LeadStatus` enum values.
- **Fix:** `apps/web/src/app/crm/page.tsx` uses enum-only selects, defaults to
  `WALK_IN`/`NEW`, strips empty fields, and validates before sending. Verified: POST 201.

### C. Staff/employee creation — FIXED
1. **False success toast:** the toast now fires only after a 2xx response, and the list is
   reloaded (`await load()`) so the new row appears without a page reload.
2. **Branch column always "الكل":** `UsersService.list` never selected the `branch`
   relation; the UI's `u.branch?.name` fallback showed "All" for everyone. Fixed by joining
   `branch: { select: { id, name } }`. Verified: created a COACH on "Maadi" → list shows Maadi.
3. **Form redesign:** labeled fields, one block per employee, and a short explanation under
   every field (name/email/password/role/branch).

### D. Subscription plans — FIXED
1. Delete/deactivate already worked via the API; the UI delete flow (incl. member
   reassignment) was verified live. Plan creation from the UI also 400'd (`property active
   should not exist`) — `CreatePlanDto` now accepts `active`.
2. Every plan table cell now carries an inline unit label (days, EGP, invitations, freezes).
3. **Demo plans leaking into new gyms:** the onboarding wizard pre-filled step 3 with 5
   template plans and saved them on completion. Step 3 now starts empty (zero plans) and is
   skippable; templates are opt-in. Verified: brand-new gym that skips step 3 completes with
   **0 plans**.

### E. Member renewal — FIXED (real root cause this time)
- **Root cause:** `POST /payments/manual` already creates a `Receipt` row, and
  `Receipt.paymentId` is `@unique` — so `createMembershipFinancials` (shared by member create
  AND renew) failed with P2002 → 409 `unique_constraint_violation`. The UI's renew flow
  therefore always died at the final step. Member creation was broken the same way.
- **Fix:** `members.service.ts` reuses the payment's existing receipt (re-pointing it at the
  membership invoice) instead of creating a second one. Verified end-to-end: manual payment →
  renew → member returns `status: ACTIVE`, `sessionsLeft: 15`, new `startDate`; member create
  likewise returns 201.

### F. Onboarding logo & theme — FIXED
1. Logo upload now has a preview with **Remove** and **Choose a different image** (client-side
   size/type validation, stored as data-URL in step 1 data).
2. **Logo never appeared:** `BrandProvider` never read the gym's persisted branding.
   It now fetches `/api/gyms/me` once per session and feeds `logoUrl`/`accentColor` into the
   brand context; `Logo` renders the uploaded image instead of the default mark.
3. **Theme color had no effect:** the chosen `accentColor` (persisted as `gym.accentColor`)
   now drives the `--cyan` CSS variable family (buttons, focus rings, active nav, badges,
   borders) through `BrandContext`.

### G. Classes: edits/bookings claimed success but didn't show — FIXED
- **Root cause:** `listSessions` cached results in Redis for 5 minutes and **no mutation
  invalidated the cache** — creates/edits/deletes/bookings were invisible (even after full
  reloads) until the TTL expired, and stale sessions reappeared after deletion.
- **Fix:** every mutating classes endpoint (create/update/cancel/delete session, book,
  cancel-booking, complete) now clears the gym's `classes:sessions:*` cache. Verified live:
  create → list shows it instantly; coach edit → shows instantly; book → `booked: 1` instantly;
  force-delete → gone instantly.

### H. Purchase order / inventory reorder — FIXED
- Empty supplier default produced a bare "Invalid supplier" (surfaced as "ذكاء المخزون غير
  متاح"). The API now returns an actionable message ("Supplier is required…"), the form
  validates before sending, auto-selects the first supplier, and links to "add supplier" when
  none exist. Verified: create supplier → create PO → send PO all succeed.

### I. POS pricing clarity — FIXED
- Each cart line now shows **unit price × qty = line total**, the discount row shows the
  applied amount with a minus sign, and totals keep explicit subtotal/discount/tax/due labels.

### J. Accounting page — REDESIGNED for non-accountants
- New plain-language layout: Money in / Money out / Net profit (month + today) cards, a
  prominent **Daily cash check** (expected POS cash today vs cash counted, with plain-language
  over/short guidance), a recent money-movements list (newest first), and the accountant tools
  (chart of accounts / journals) tucked under a labelled "Advanced" section.

### K. Backup download — FIXED
- **Root cause:** `getLatestBackup` picked the newest `Backup` row regardless of
  `location`; S3-flagged rows have no local file, so `res.download()` hit ENOENT → 500
  `server_error`. `list` also mixed in non-downloadable S3 rows.
- **Fix:** both now filter `location: 'local'`; missing files/backups return a clean 404
  instead of 500. The page downloads through the authenticated API client with real error
  surfacing. Verified: generate → download/latest returns 200 with a valid `.xlsx` (PK magic
  bytes); a gym with no backups gets 404, not 500.

### L. Check-in page raw i18n keys — FIXED
- Added real AR/EN translations for `device_token_title`, `device_token_desc`,
  `generate_device_token`, `device_token_once`, `copy` (+ `copied`, `device_token_hidden`,
  `no_checkins_yet`, `checkins_will_appear`) and rebuilt the `/checkin` page around a working
  device-token section (generate → copy → store-once warning). `scripts/check-i18n.sh`
  passes with 0 mismatches, and the rendered page shows Arabic, not raw keys.

### M. Digital contracts purpose — FIXED
- The contracts page now explains what a contract record represents (gym↔member signed
  agreement), walks through the 3-step workflow (create → send/sign via WhatsApp → keep as
  proof) with a concrete example, and lists contracts with member names (API now includes the
  member relation).

### Verification stack used
- Postgres 18 (embedded), Redis 7.2, `npx prisma migrate deploy` (45 migrations),
  `prisma/seed.ts` demo gym, API on :4000, Next.js dev on :3000.
- Full `npm run build` (i18n parity + API build + web build) passes; API jest specs pass.

### Demo credentials (seeded demo gym `slug: demo`)
| Email | Role | Password |
|---|---|---|
| `owner@demo.flexora.app` | OWNER | *the value of `SUPER_ADMIN_PASSWORD`* |
| `reception@demo.flexora.app` | RECEPTION | *the value of `SUPER_ADMIN_PASSWORD`* |
| `manager@demo.flexora.app` | MANAGER | *the value of `SUPER_ADMIN_PASSWORD`* |
| `coach@demo.flexora.app` | COACH | *the value of `SUPER_ADMIN_PASSWORD`* |

**There is no default password.** `apps/api/prisma/seed.ts` reads
`SUPER_ADMIN_PASSWORD` and refuses to run if it is unset or shorter than 12
characters — it will not invent one, because a shipped default is a credential
that lives in every clone and every scanner's dictionary. Set it before seeding:

```bash
cd apps/api
cp .env.example .env
echo "SUPER_ADMIN_PASSWORD=$(openssl rand -base64 24 | tr '+/' '-_')" >> .env
npm run seed
```

Every demo user above is created with that one value, so `SUPER_ADMIN_PASSWORD`
is the password you log in with. See `docs/SECRET_ROTATION.md` for how to rotate
it (and every other secret) later.

---

## Phase 4–6 verification notes (this round)

All items below were verified by driving the real running app (Puppeteer + direct DB reads),
not by reading code.

### Phase 4 — staff management
- Add-staff form is discrete labeled fields: `الاسم الكامل *`, `البريد الإلكتروني *`,
  `رقم الهاتف`, `كلمة المرور *`, `الدور *`, `الفرع`.
- `/users` has an `إضافة موظف` button.
- Branch design chosen: **branches are collected in onboarding; staff are assigned to a
  branch in the dashboard**, both at creation and via an inline per-row branch dropdown.
- Live: created `Mohamed Adel Farouk` → DB `COACH / Zagazig Branch`; inline reassign →
  `Main Branch`.
- The non-persisting onboarding add-staff step was removed.

### Phase 5 — plans
- Fresh customer signup seeds **zero** plans (onboarding plans step shows 0 prefilled rows).
- Owner-built plan verified: `باقة الحديد الشهرية / 777.00`.
- Plan dropdowns are fully localized — no raw `Month` / `Months` / `Sessions` leaking into
  Arabic: `شهر — 499 ج.م`, `15 حصة — 600 ج.م`, `3 أشهر — 1,100 ج.م`, `12 شهر — 3,200 ج.م`.
- Seeded demo plans remain only for the internal demo gym.

### Phase 6
1. **Classes** — coach assignment is an inline `<select>` in the session row (no popup).
   Live: `NULL → Sara Salah → Omar Khaled` persisted to `ClassSession.coachId`.
2. **POS price** — root cause: the API returned raw columns (`sellingPrice`, `costPrice`,
   `lowStockThreshold`) while POS/inventory read `price`, `cost`, `lowAlert`, so every card
   read `undefined → 0`. Fixed with a `toDto()` mapper in `products.service.ts` applied to
   list/create/update/stats. Live: cart row `Protein Bar P6 | 85 ج.م × 1 = 85 ج.م`.
3. **AI assistant key** — onboarding step 6 and Settings both take the gym's own API key.
   Keys are stored **AES-256-GCM encrypted** in `GymSettings` (`ai.apiKey`) and never
   returned; the API exposes only `hasOwnKey` + `keyHint` (`••••9911`).
   Free tier: Gemini still requires a key, but a free one from Google AI Studio — the UI
   says so explicitly, and the step is skippable.
   `GET/POST /api/ai/config` live in a dedicated `AiConfigController` that is deliberately
   **not** behind `@RequiresFeature('ai')`, otherwise BASIC-tier gyms 403'd and the
   onboarding key silently failed to save.
4. **Settings** — real `الخطط` (full plan CRUD) and `إعداد المساعد الذكي` sections.
   Live: editing a plan price in Settings persisted `Plan.price 450 → 499`.
5. **Translations** — 46 literal/machine-translated Arabic strings rewritten into natural
   phrasing; `scripts/check-i18n.sh` passes with full ar/en key parity.

### Build status
- `apps/api`: `tsc -p tsconfig.build.json` — zero errors.
- `apps/web`: `npm run build` — **zero errors**, 68 routes generated.

### Local bring-up
```bash
npm install
# Postgres + Redis running; then:
cd apps/api && npx prisma migrate deploy && npx prisma db seed
cd ../.. && npm run dev
```

### Round-2 code review fixes

1. **Tenant isolation on staff creation** — `UsersService.create()` validates that
   `branchId` belongs to the caller's gym (`branch.findFirst({ id, gymId })`), matching
   `update()` and `assignBranch()`. Verified live against a second real tenant: posting
   another gym's branch id returns `400 Invalid branch`, no user row is written, and the
   DB holds zero cross-tenant staff/branch pairs. Same-gym assignment still works.
2. **Shared Egyptian phone rule** — the `EG_PHONE` regex now lives in one place,
   `src/common/validators/phone.ts`, and is used by staff (`users/dto.ts`), members,
   invitations and leads. Staff phones previously used a loose
   `/^[0-9+\-\s()]{7,20}$/` that accepted `+1 (555) 123-4567`; such values are now
   rejected with the same message as the rest of the system.
3. **Packaging** — `apps/web/tsconfig.tsbuildinfo` no longer ships. Use
   `bash scripts/package-release.sh` to build the delivery zip; it excludes build
   artifacts and **fails the build** if any leak into the archive.

Regression tests: `apps/api/src/modules/users/users.tenant-isolation.spec.ts` (11 tests)
covers both the tenant check and the phone rule.
