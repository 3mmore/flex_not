#!/usr/bin/env bash
#
# FLEXORA Gym OS — Item 2: provision the dedicated `flexora_app` Postgres role
# and rotate its password to a fresh, strong, generated value.
#
# This is idempotent: safe to run multiple times. It does NOT create the
# role's tables/schema (that's what `prisma migrate deploy` does, as the
# owner/superuser role) — it only ensures the role exists with the correct
# least-privilege attributes and sets a brand-new random password.
#
# Usage:
#   DATABASE_URL="postgresql://postgres:<owner-password>@host:5432/flexora" \
#     ./scripts/setup-db-role.sh
#
# Prints the generated password to stdout ONCE. Store it in your secrets
# manager immediately; it is not saved anywhere by this script.

set -euo pipefail

if [ -z "${DATABASE_URL:-}" ]; then
  echo "ERROR: set DATABASE_URL to an owner/superuser connection string first." >&2
  # PHASE L1: never print a realistic-looking DSN — a placeholder cannot be
  # copy-pasted into production by accident.
  echo "Example: DATABASE_URL='postgresql://<user>:<password>@<host>:5432/<db>?schema=public' $0" >&2
  exit 1
fi

NEW_PASSWORD="$(openssl rand -hex 24)"

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'flexora_app') THEN
    CREATE ROLE flexora_app
      WITH LOGIN
      NOSUPERUSER
      NOCREATEDB
      NOCREATEROLE
      NOREPLICATION
      NOBYPASSRLS
      CONNECTION LIMIT -1
      PASSWORD '${NEW_PASSWORD}';
  ELSE
    ALTER ROLE flexora_app
      NOSUPERUSER
      NOCREATEDB
      NOCREATEROLE
      NOREPLICATION
      NOBYPASSRLS
      PASSWORD '${NEW_PASSWORD}';
  END IF;
END \$\$;

GRANT USAGE ON SCHEMA public TO flexora_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO flexora_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO flexora_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO flexora_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO flexora_app;
SQL

echo ""
echo "flexora_app role is ready. New password (store this now, it will not be shown again):"
echo "  ${NEW_PASSWORD}"
echo ""
echo "Update DATABASE_URL for the running API to:"
echo "  postgresql://flexora_app:${NEW_PASSWORD}@<host>:5432/<db>?schema=public"
