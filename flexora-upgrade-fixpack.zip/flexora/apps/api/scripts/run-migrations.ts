/**
 * FLEXORA Gym OS — standalone Prisma migration runner
 * © 2024 Ammar Allam. All rights reserved.
 */
import { spawn } from 'child_process';

const child = spawn(process.platform === 'win32' ? 'npx.cmd' : 'npx', ['prisma', 'migrate', 'deploy'], {
  cwd: process.cwd(),
  env: process.env,
  stdio: 'inherit',
});

child.on('exit', (code) => process.exit(code ?? 1));
child.on('error', (error) => {
  console.error(`Migration runner failed: ${error.message}`);
  process.exit(1);
});
