# FLEXORA API Reference

Base URL: `http://localhost:4000/api`  ·  Interactive docs: `GET /docs` (Swagger)
Auth: `Authorization: Bearer <accessToken>` on all routes except those marked **public**.
Tenant scope: derived from JWT `gymId`. `SUPER_ADMIN` may pass `X-Gym-Id` header where applicable.

## Auth
| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | `/auth/register` | public | Create gym + owner + default plans/license/subscription. Returns tokens. |
| POST | `/auth/login` | public | Body `{ email, password, gymSlug? }`. Returns `{ accessToken, refreshToken, user }`. |
| POST | `/auth/refresh` | public | Rotating refresh tokens (argon2-hashed, stored). |
| POST | `/auth/logout` | public | Revokes refresh token. |
| POST | `/auth/change-password` | any | Revokes all refresh tokens. |

## Members
| Method | Path | Roles |
|---|---|---|
| GET | `/members?page&limit&q&status` | all |
| GET | `/members/:id` | all |
| GET | `/members/code/:code` | all |
| POST | `/members` | OWNER, MANAGER, RECEPTION |
| PATCH | `/members/:id` | OWNER, MANAGER, RECEPTION |
| POST | `/members/:id/renew` | OWNER, MANAGER, RECEPTION |
| POST | `/members/:id/freeze` | OWNER, MANAGER |
| DELETE | `/members/:id` | OWNER, MANAGER |

Egyptian mobile validation enforced server-side: `^(010|011|012|015)\d{8}$`.

## Plans / Branches / Users
- `GET/POST/PATCH/DELETE /plans` (OWNER, MANAGER)
- `GET/POST/PATCH/DELETE /branches` (OWNER, MANAGER) — enforces license `branchesAllowed`
- `GET /users`, `POST /users`, `PATCH /users/:id`, `PATCH /users/:id/toggle` (OWNER) — enforces license `seats`

## Attendance (real QR)
| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/attendance?page&limit&q&branchId` | all |
| POST | `/attendance/checkin` | all staff | Body `{ memberCode, method?, branchId? }`. Atomic session deduction + visit increment; blocks expired/frozen. |
| POST | `/attendance/manual` | OWNER, MANAGER, RECEPTION | Body `{ memberId, branchId? }`. |

## Products / POS / Expenses
- `GET /products?q&category`, `GET /products/stats`, `POST/PATCH/DELETE /products`
- `POST /sales` — atomic: validates stock, decrements, writes sale+items+income transaction
- `GET /sales?page&limit`
- `GET /expenses?page&limit&branchId&category&from&to` — paginated + filterable (OWNER/MANAGER)
- `POST /expenses` — writes expense + EXPENSE ledger transaction atomically
- `DELETE /expenses/:id` — removes expense + its linked ledger transaction atomically

## Reports
- `GET /reports/dashboard` — revenue today/month, net profit, active/expiring members, check-ins
- `GET /reports/ledger` — append-only transaction ledger
- `GET /reports/revenue-by-month`
- `GET /reports/membership-analytics`
- `GET /reports/peak-hours`

## Notifications
- `GET /notifications`
- `POST /notifications/send` — `{ channel: email|whatsapp|inapp, to, body, subject? }`
- Automated reminder cron (9AM daily): D-7 / D-3 / D-1 / D-0 WhatsApp renewal reminders.

## Billing (Stripe)
- `GET /billing/subscription`
- `POST /billing/checkout` — `{ tier }` → Stripe Checkout URL (dev fallback applies tier locally)
- `POST /billing/webhook` — **public**, Stripe signature-verified

## Backups
- `GET /backups` (OWNER)
- `GET /backups/export` (OWNER) — logical per-tenant JSON snapshot
- `POST /backups/run` (SUPER_ADMIN) — physical `pg_dump` (also nightly cron, 14-day rotation)

## Super Admin (platform) — REMOVED IN PHASE R1 §5.0

The three endpoints this section used to list no longer exist, and neither does the module that
served them (`apps/api/src/modules/admin/`, deleted with the owner's approval in PHASE R1 §5.0).
All three answer **404**. That was first measured in PHASE R2 (`GET /api/admin/stats` returned
404 on both an admin host and a public host, while `GET /api/platform/overview` returned 401
without a session — the platform route exists and the admin route does not), and re-measured in
PHASE R4 on the running api and through the nginx edge on a public host. The R4 measurement,
including the exact commands, is in `work/r4-evidence/01-dead-admin-endpoints.log`.

They were replaced by the owner console's platform routes, which are host-gated, session-based
and audited — see `docs/ADMIN_CONSOLE.md`:

```
GET   /api/platform/overview                        gym and revenue aggregates
GET   /api/platform/gyms                            list with search, filters, sort, paging
PATCH /api/platform/gyms/:id/plan                   change a gym's plan
POST  /api/platform/gyms/:id/suspend                suspend  (step-up + reason + audit row)
POST  /api/platform/gyms/:id/reactivate             reactivate (step-up + reason + audit row)
```

The last web page that called `/admin/stats` (`apps/web/src/app/admin/page.tsx`, and the
`/admin` entry in the tenant `Shell.tsx` nav) was deleted in PHASE R4 on the owner's decision 1.

## Health
- `GET /health` — **public**; checks Postgres + Redis.

## Audit
- `GET /audit?page&limit` (OWNER) — append-only audit log; auto-written via `@Audit()` on all mutations.


## AI Intelligence (Claude `claude-sonnet-4-6`)
All `/ai/*` routes require **OWNER or MANAGER** (no COACH/RECEPTION). When
`AI_ENABLED=false` or `ANTHROPIC_API_KEY` is unset, every endpoint degrades
gracefully (`aiEnabled:false` + local heuristic data) and never throws.

| Method | Path | Notes |
|---|---|---|
| GET | `/ai/churn-risk` | Local HIGH/MEDIUM/LOW risk scoring per member + AI re-engagement messages (Arabic) for top-10 high-risk |
| GET | `/ai/revenue-forecast` | 6-month history, MoM growth, statistical baseline + Claude forecast range/driver/action |
| GET | `/ai/product-insights` | Margin/velocity/days-of-stock + AI promote/discontinue picks |
| GET | `/ai/daily-briefing` | KPIs + delta vs yesterday + alerts + Arabic morning briefing paragraph |
| POST | `/ai/ask` | `{ question, context?: members\|revenue\|products\|attendance }` → grounded answer |

Env: `ANTHROPIC_API_KEY`, `AI_ENABLED`. WhatsApp templates: `WA_TEMPLATE_RENEWAL`, `WA_TEMPLATE_SESSION`.

## Notifications (updated)
- `POST /notifications/send` — `{ channel: email|whatsapp|inapp, to, body, subject? }`
- WhatsApp: `whatsapp()` = reactive free-text (inside 24h window); `whatsappTemplate()` = proactive template messages (used by the reminder cron).
- Reminder cron (daily 09:00): time-plan expiries D-7/D-3/D-1/D-0 **and** session-plan members with `sessionsLeft IN (3,1)`, deduplicated per run.


## Paymob (Egyptian payments)
| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | `/paymob/checkout` | OWNER | `{ tier: BASIC|PRO|ELITE }` -> `{ iframeUrl }` (EGP 299/599/999). Dev fallback applies tier locally. |
| POST | `/paymob/webhook` | public | HMAC-SHA512 verified; activates subscription on `success`. |

## Member Self-Service Portal (separate MEMBER JWT)
| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/portal/request-otp` | public | `{ mobile, gymSlug? }` -> 6-digit OTP via WhatsApp (10-min expiry, 3/hr Redis rate-limit) |
| POST | `/portal/verify-otp` | public | `{ mobile, code, gymSlug? }` -> `{ token }` (24h MEMBER JWT, `JWT_MEMBER_SECRET`) |
| GET | `/portal/me` | MemberGuard | member profile, plan, expiry/sessions, last 10 visits |
| POST | `/portal/renew` | MemberGuard | `{ tier }` -> Paymob checkout |

MEMBER tokens are validated by `MemberAuthGuard` and are isolated from staff JWTs
(different secret + role check); they can ONLY reach `/portal/*`.


## Classes & Booking
| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/classes/templates` | staff | list active templates |
| POST | `/classes/templates` | OWNER, MANAGER | create template (name, capacity, color, coach) |
| DELETE | `/classes/templates/:id` | OWNER, MANAGER | soft-delete (active=false) |
| GET | `/classes/sessions?from&to&branchId` | staff | sessions in range + booked/full counts |
| POST | `/classes/sessions` | OWNER, MANAGER | create session from template |
| POST | `/classes/sessions/:id/cancel` | OWNER, MANAGER | cancel session + its bookings |
| POST | `/classes/sessions/:id/book` | staff | `{ memberId }` — atomic, capacity-enforced |
| POST | `/classes/sessions/:id/cancel-booking` | staff | `{ memberId }` |
| POST | `/classes/sessions/:id/complete` | OWNER, MANAGER, COACH | mark done, bookings -> ATTENDED |
| GET | `/classes/sessions/:id/roster` | staff | confirmed/attended members |

Member portal: `GET /portal/classes`, `POST /portal/classes/:id/book`, `POST /portal/classes/:id/cancel`.


## Coach Management & Personal Training
| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/pt/coaches` | staff | coaches + profiles |
| POST | `/pt/coaches/profile` | OWNER, MANAGER | upsert specialties/bio/pricePerHour |
| GET | `/pt/coaches/:id/schedule?from&to` | staff | COACH may only view own schedule |
| POST | `/pt/sessions` | OWNER, MANAGER, RECEPTION | book PT session |
| PATCH | `/pt/sessions/:id` | staff | COACH may only update own (status/notes/paid) |
| GET | `/pt/sessions?coachId&memberId&status` | staff | paginated |
| GET | `/pt/coach-stats` | OWNER, MANAGER | sessions/month + revenue per coach |

Coach portal page `/coach`: own schedule (today + week), mark COMPLETED/NO_SHOW,
add notes. Cannot see other coaches' schedules or financials.
Daily briefing now includes `ptSessionsToday`, `classBookingsToday`, `coachUtilization`.


## SMS (Vonage)
- `POST /notifications/send` now accepts `channel: "sms"` — `{ channel:"sms", to, body }`.
- Egyptian numbers auto-normalized `01xxxxxxxxx` -> `+201xxxxxxxxx`; Unicode (Arabic) supported.
- Reminder cron sends **both WhatsApp and SMS** when SMS is configured (additive, never either/or).
- Env: `VONAGE_API_KEY`, `VONAGE_API_SECRET`, `SMS_FROM`. Degrades gracefully (logs + records as SMS) when unset.
- `NotifyChannel` enum gains `SMS`.


## Body Measurements
| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/measurements/:memberId` | OWNER, MANAGER, COACH | full history; COACH limited to members they train (via PT sessions) |
| POST | `/measurements/:memberId` | OWNER, MANAGER, COACH | weight/bodyFat/muscleMass/chest/waist/hips/arms/notes; `recordedBy` stamped |
| DELETE | `/measurements/:id` | OWNER, MANAGER | delete entry |

Member profile (`/members`) gains a 📏 Measurements modal with a weight + body-fat
SVG chart and add form. AI `ask` context=`members` now includes each member's
latest measurement (enables "who isn't losing weight?" style questions).


## Realtime (WebSocket — socket.io)
Gateway at the API origin. Client emits `join` with the staff access token; the
gateway verifies the JWT and joins room `gym:{gymId}`. Events are tenant-scoped
(never cross gyms) and emitted by services after writes:
- `checkin`    -> `{ memberName, branchName, at }` (AttendanceService)
- `low_stock`  -> `{ productName, qty }` (ProductsService.update + SalesService.checkout)
- `new_member` -> `{ memberName, plan }` (MembersService.create)

Web: `lib/socket.ts` singleton (auto-reconnect, auto-join); Shell shows a 🔔 bell
with unread badge and top-end toast cards.


## Advanced AI (Egyptian-market)
All under `/ai` (OWNER/MANAGER), Claude-backed with local fallback when `AI_ENABLED=false`.
| Method | Path | Notes |
|---|---|---|
| GET | `/ai/upsell-targets` | active 60d+ monthly members, freq>0.5/day; AI Arabic upgrade pitch + Send WhatsApp |
| GET | `/ai/smart-pricing` | active count, revenue, plan distribution, season -> recommendation + urgency + reasoning |
| GET | `/ai/retention-score` | 0-100 score per member (freq/recency/tenure/VIP); distribution + bottom 20 + action plan |

`POST /ai/ask` context now also accepts `measurements`, `classes`, `pt`.
Daily briefing additionally returns `topUpsell`.

## Invitation System (free guest visits & AI follow-up)
Members receive a configurable number of free-visit "slots". Reception registers
a guest against an inviting member; the slot counter is decremented atomically.
Two hours after a visit, an hourly cron sends a personalised (Claude-generated,
local fallback) WhatsApp **and** SMS follow-up containing a public feedback link.
Visitors can later be converted to paying members. All staff endpoints are
tenant-scoped by `gymId`.

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/invitations/stats` | OWNER, MANAGER | totals, conversion rate, pending feedback, top inviters |
| GET | `/invitations` | OWNER, MANAGER, RECEPTION | paginated visits; filter `status`, `memberId`, `from`, `to` |
| GET | `/invitations/slots` | all staff | every member with allocated/used/remaining slots |
| POST | `/invitations/slots/:memberId` | OWNER, MANAGER | set `totalSlots` (0–20) |
| GET | `/invitations/slots/:memberId` | all staff | a member's slot allocation |
| POST | `/invitations/register` | OWNER, MANAGER, RECEPTION | register a visit (atomic slot decrement; soft warning on repeat phone) |
| POST | `/invitations/:id/convert` | OWNER, MANAGER | mark visitor CONVERTED + link new member |
| GET | `/invitations/:id/feedback-form` | **public** | mobile-first HTML 5-star feedback page |
| POST | `/invitations/:id/feedback` | **public** | save `{ score 1–5, text }`; AI summarises feedback |

Member create/renew accept optional `invitationSlots` (0–20) to set the allowance
at signup. `POST /ai/ask` context now also accepts `invitations`.
Cron: `@Cron(EVERY_HOUR)` `InvitationsCron.sendVisitorFollowUps()` — skips NO_SHOW
and already-followed-up visits; AI follow-up degrades gracefully without a key.
