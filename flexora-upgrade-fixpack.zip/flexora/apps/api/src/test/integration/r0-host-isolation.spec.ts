/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - host isolation against the REAL application graph.
 *
 * The unit suite (common/guards/admin-host.guard.spec.ts) proves the guard's logic
 * with fixture controllers. This suite proves it where it actually matters: the real
 * AppModule, the real controllers, the real global prefix, the real middleware chain
 * and the real exception filter - so a wiring mistake (the guard registered too late,
 * a console controller that forgot its marker, a route added next month) fails here.
 *
 * ROUTES ARE ENUMERATED FROM METADATA, NEVER FROM A URL LIST (owner rule, PHASE Q).
 * The console routes below are discovered by walking the two platform controllers'
 * handler metadata (PATH_METADATA / METHOD_METADATA / IS_PLATFORM_ROUTE_KEY), so the
 * matrix cannot go stale: a new console route is picked up automatically, and test 6
 * fails if one is added WITHOUT the marker that puts it behind the gate.
 *
 * Every assertion is an attack attempt: a real HTTP request with a hostile Host
 * header, answered by a running Nest application.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { PATH_METADATA, METHOD_METADATA } from '@nestjs/common/constants';
import { RequestMethod } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { IS_PLATFORM_ROUTE_KEY } from '../../common/decorators/platform-route.decorator';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR, NGINX_GATE_HOSTNAME } from '../../config/admin-hosts';
import { PlatformController } from '../../modules/platform/platform.controller';
import { PlatformAuthController } from '../../modules/platform-auth/platform-auth.controller';

const ADMIN_HOST = 'localhost';
const PUBLIC_HOST = 'r0-public.example';
const SPOOF_HOST = 'r0-spoof.example';
const UUID = '00000000-0000-4000-8000-000000000000';
const LOGIN_ROUTE = `/${API_GLOBAL_PREFIX}/platform/auth/login`;

interface RouteRef {
  method: string;
  path: string;
  controller: string;
  handler: string;
  marked: boolean;
}

/** Join a controller path and a handler path the way Nest's router does. */
function joinPath(base: string, handlerPath: string): string {
  const normalise = (segment: string) => String(segment ?? '').replace(/^\/+|\/+$/g, '');
  const parts = [API_GLOBAL_PREFIX, normalise(base), normalise(handlerPath)].filter(Boolean);
  return `/${parts.join('/')}`;
}

/** Replace `:param` segments with a syntactically valid value so routing matches. */
function concretePath(path: string): string {
  return path
    .split('/')
    .map((segment) =>
      segment.startsWith(':') ? (/id/i.test(segment) ? UUID : 'r0-value') : segment,
    )
    .join('/');
}

/** Discover the console routes from metadata alone. */
function platformRoutesFromMetadata(): RouteRef[] {
  const routes: RouteRef[] = [];
  for (const controller of [PlatformController, PlatformAuthController]) {
    const base = (Reflect.getMetadata(PATH_METADATA, controller) as string | undefined) ?? '';
    const markedOnClass = Reflect.getMetadata(IS_PLATFORM_ROUTE_KEY, controller) === true;
    for (const name of Object.getOwnPropertyNames(controller.prototype)) {
      if (name === 'constructor') continue;
      const descriptor = Object.getOwnPropertyDescriptor(controller.prototype, name);
      const handler = descriptor?.value;
      if (typeof handler !== 'function') continue;
      const methodMeta = Reflect.getMetadata(METHOD_METADATA, handler) as number | undefined;
      if (methodMeta === undefined) continue; // not a route handler
      const handlerPath = (Reflect.getMetadata(PATH_METADATA, handler) as string | undefined) ?? '';
      const markedOnMethod = Reflect.getMetadata(IS_PLATFORM_ROUTE_KEY, handler) === true;
      routes.push({
        method: RequestMethod[methodMeta],
        path: concretePath(joinPath(base, handlerPath)),
        controller: controller.name,
        handler: name,
        marked: markedOnClass || markedOnMethod,
      });
    }
  }
  return routes;
}

let app: INestApplication;
let savedAdminHosts: string | undefined;
let savedNodeEnv: string | undefined;
let savedHops: string | undefined;
let routes: RouteRef[] = [];

/** Strip the two fields that legitimately differ between any two 404 bodies. */
function normalise(text: string, path: string): string {
  return text
    .replace(/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?Z/g, '<TS>')
    .split(path)
    .join('<PATH>');
}

function headerNames(res: { headers: Record<string, unknown> }): string[] {
  return Object.keys(res.headers).map((h) => h.toLowerCase()).sort();
}

/** supertest verb call without fighting its index signature. */
function send(server: unknown, method: string, path: string): request.Test {
  const agent = request(server) as unknown as Record<string, (p: string) => request.Test>;
  return agent[method.toLowerCase()](path);
}

beforeAll(async () => {
  savedAdminHosts = process.env[ADMIN_HOSTS_VAR];
  savedNodeEnv = process.env.NODE_ENV;
  savedHops = process.env.TRUST_PROXY_HOPS;
  // An explicit allow-list, so nothing here can pass because of the development
  // fallback. NODE_ENV is left as jest set it: booting the real graph in production
  // mode would change unrelated behaviour (CORS, cookies) and prove nothing about
  // this gate. Test 9 flips NODE_ENV for the fail-closed assertions only, which is
  // valid because the configuration is read at call time, never at module scope.
  process.env[ADMIN_HOSTS_VAR] = ADMIN_HOST;
  delete process.env.TRUST_PROXY_HOPS;
  process.env.IMPORT_UPLOAD_DIR = '/tmp/flexora/imports';
  process.env.BACKUP_DIR = '/tmp/flexora/backups';
  process.env.CONTRACT_PDF_DIR = '/tmp/flexora/contracts';

  const moduleFixture: TestingModule = await Test.createTestingModule({ imports: [AppModule] }).compile();
  app = moduleFixture.createNestApplication();
  // Mirror main.ts: the global prefix, cookie parsing, the validation pipe and the
  // global exception filter are what give a 404 its production body shape. Without
  // the filter this suite would compare against Nest's default 404 instead.
  app.setGlobalPrefix(API_GLOBAL_PREFIX);
  app.use(cookieParser());
  app.useGlobalFilters(new HttpExceptionFilter());
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: false,
      validationError: { target: false, value: false },
    }),
  );
  await app.init();
  routes = platformRoutesFromMetadata();
}, 240_000);

afterAll(async () => {
  await app?.close();
  if (savedAdminHosts === undefined) delete process.env[ADMIN_HOSTS_VAR];
  else process.env[ADMIN_HOSTS_VAR] = savedAdminHosts;
  if (savedNodeEnv === undefined) delete process.env.NODE_ENV;
  else process.env.NODE_ENV = savedNodeEnv;
  if (savedHops === undefined) delete process.env.TRUST_PROXY_HOPS;
  else process.env.TRUST_PROXY_HOPS = savedHops;
});

describe('PHASE R0 - host isolation on the real application', () => {
  it('1. the console route matrix was discovered from metadata and is not empty', () => {
    expect(routes.length).toBeGreaterThanOrEqual(25);
    const methods = new Set(routes.map((r) => r.method));
    expect(methods.has('GET')).toBe(true);
    expect(methods.has('POST')).toBe(true);
    expect(methods.has('DELETE')).toBe(true);
    // the two auth routes are part of the console and must be in the matrix
    expect(routes.some((r) => r.path === LOGIN_ROUTE)).toBe(true);
    expect(routes.some((r) => r.path.endsWith('/platform/auth/change-password'))).toBe(true);
  });

  it('2. ATTACK: every console route on a public hostname answers a 404 indistinguishable from an unknown route', async () => {
    const server = app.getHttpServer();
    const unknownPath = `/${API_GLOBAL_PREFIX}/r0-route-that-does-not-exist`;

    // The reference is per METHOD, because Nest's 404 echoes the verb: a real
    // unknown POST says "Cannot POST ...". Comparing a refused POST against a GET
    // reference would report a difference that any unknown route would also have.
    const references = new Map<string, { status: number; ctype: string; headers: string; body: string }>();
    for (const method of Array.from(new Set(routes.map((r) => r.method)))) {
      const res = await send(server, method, unknownPath).set('Host', PUBLIC_HOST).set('content-type', 'application/json').send({});
      expect(res.status).toBe(404);
      references.set(method, {
        status: res.status,
        ctype: res.headers['content-type'],
        headers: JSON.stringify(headerNames(res)),
        body: normalise(JSON.stringify(res.body), unknownPath),
      });
    }

    const failures: string[] = [];
    for (const route of routes) {
      const ref = references.get(route.method) as { status: number; ctype: string; headers: string; body: string };
      const res = await send(server, route.method, route.path)
        .set('Host', PUBLIC_HOST)
        .set('content-type', 'application/json')
        .send({});
      const sameBody = normalise(JSON.stringify(res.body), route.path) === ref.body;
      const sameHeaders = JSON.stringify(headerNames(res)) === ref.headers;
      if (res.status !== ref.status || res.headers['content-type'] !== ref.ctype || !sameHeaders || !sameBody) {
        failures.push(
          `${route.method} ${route.path} status=${res.status}/${ref.status} ` +
            `type=${res.headers['content-type'] === ref.ctype ? 'same' : `DIFFERENT ${res.headers['content-type']}`} ` +
            `headers=${sameHeaders ? 'same' : 'DIFFERENT'} ` +
            `body=${sameBody ? 'same' : `DIFFERENT ${JSON.stringify(res.body).slice(0, 200)}`}`,
        );
      }
    }
    expect(failures).toEqual([]);
  }, 240_000);

  it('3. the refusal never explains itself once the echoed path is normalised away', async () => {
    const server = app.getHttpServer();
    for (const route of routes.slice(0, 8)) {
      const res = await send(server, route.method, route.path).set('Host', PUBLIC_HOST).send({});
      // The body echoes the requested path, exactly as an unknown route does, so the
      // path itself is normalised away before looking for an explanation. What must
      // not appear is any wording that says "this exists but you may not have it".
      const text = normalise(JSON.stringify(res.body), route.path).toLowerCase();
      expect(text).not.toMatch(/admin|console|platform|forbidden|unauthor|licence|license|host/);
      for (const name of headerNames(res)) expect(name).not.toMatch(/admin|console|platform/);
    }
  }, 180_000);

  it('4. on an admin hostname every console route still behaves exactly as before (never a gated 404)', async () => {
    const server = app.getHttpServer();
    const failures: string[] = [];
    for (const route of routes) {
      const res = await send(server, route.method, route.path)
        .set('Host', ADMIN_HOST)
        .set('content-type', 'application/json')
        .send({});
      // No platform session is presented, so the answer is 401 - except for the two
      // routes PHASE R1 marked @Public(): the login route, which validates its body
      // (400) and is rate limited (429) and brute-force guarded, and the CSP report
      // sink, which a browser posts without credentials and which answers 204 with no
      // body. Both are still behind the R0 host gate, which test 3 above proves by
      // requiring a path-faithful 404 for them on a public hostname.
      if (route.path === LOGIN_ROUTE) {
        if (![400, 401, 429].includes(res.status)) failures.push(`${route.method} ${route.path} -> ${res.status}`);
      } else if (route.path.endsWith('/platform/auth/csp-report')) {
        if (![204, 400, 429].includes(res.status)) failures.push(`${route.method} ${route.path} -> ${res.status}`);
      } else if (res.status !== 401) {
        failures.push(`${route.method} ${route.path} -> ${res.status}`);
      }
    }
    expect(failures).toEqual([]);
  }, 240_000);

  it('5. NEGATIVE CONTROL: tenant routes and health probes are untouched on a public hostname', async () => {
    const server = app.getHttpServer();
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/health/live`).set('Host', PUBLIC_HOST)).status).toBe(200);
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/health/ready`).set('Host', PUBLIC_HOST)).status).toBe(200);
    // unauthenticated tenant routes answer 401 exactly as they did before PHASE R0
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/plans`).set('Host', PUBLIC_HOST)).status).toBe(401);
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/members`).set('Host', PUBLIC_HOST)).status).toBe(401);
    const login = await request(server)
      .post(`/${API_GLOBAL_PREFIX}/auth/login`)
      .set('Host', PUBLIC_HOST)
      .set('content-type', 'application/json')
      .send({ email: 'r0-nobody@example.com', password: 'not-a-real-password' });
    expect([400, 401, 429]).toContain(login.status);
  }, 180_000);

  it('6. every route under the platform controllers carries the marker that puts it behind the gate', () => {
    const unmarked = routes.filter((r) => !r.marked);
    // This is the test that fails when somebody adds a console route next month and
    // forgets @PlatformRoute(): the gate is metadata-driven, so an unmarked console
    // route would be served on the public hostname.
    expect(unmarked.map((r) => `${r.method} ${r.path}`)).toEqual([]);
    expect(routes.every((r) => r.path.startsWith(`/${API_GLOBAL_PREFIX}/platform`))).toBe(true);
  });

  it('7. ATTACK: X-Forwarded-Host cannot open the console from a public hostname', async () => {
    const server = app.getHttpServer();
    const res = await request(server)
      .get(`/${API_GLOBAL_PREFIX}/platform/overview`)
      .set('Host', PUBLIC_HOST)
      .set('X-Forwarded-Host', ADMIN_HOST);
    expect(res.status).toBe(404);
  });

  it('8. ATTACK: a forwarded host that contradicts the Host header is refused in both directions', async () => {
    const server = app.getHttpServer();
    const a = await request(server)
      .get(`/${API_GLOBAL_PREFIX}/platform/overview`)
      .set('Host', ADMIN_HOST)
      .set('X-Forwarded-Host', PUBLIC_HOST);
    expect(a.status).toBe(404);
    const b = await request(server)
      .get(`/${API_GLOBAL_PREFIX}/platform/overview`)
      .set('Host', PUBLIC_HOST)
      .set('X-Forwarded-Host', `${SPOOF_HOST}, ${ADMIN_HOST}`);
    expect(b.status).toBe(404);
  });

  it('9. a wildcard ADMIN_HOSTS never opens the console, and production without the variable refuses everything', async () => {
    const server = app.getHttpServer();
    process.env[ADMIN_HOSTS_VAR] = '*';
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/platform/overview`).set('Host', PUBLIC_HOST)).status).toBe(404);
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/platform/overview`).set('Host', ADMIN_HOST)).status).toBe(404);

    // fail closed in production with no value at all
    process.env.NODE_ENV = 'production';
    delete process.env[ADMIN_HOSTS_VAR];
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/platform/overview`).set('Host', ADMIN_HOST)).status).toBe(404);
    // ... while the tenant app keeps serving: the gate closes the console, not the product
    expect((await request(server).get(`/${API_GLOBAL_PREFIX}/health/live`).set('Host', PUBLIC_HOST)).status).toBe(200);

    process.env.NODE_ENV = savedNodeEnv;
    process.env[ADMIN_HOSTS_VAR] = ADMIN_HOST;
  }, 180_000);

  it('10. WIRING: AdminHostGuard is a global guard and runs before the licence, throttler and auth guards', () => {
    const providers = (Reflect.getMetadata('providers', AppModule) as Array<Record<string, unknown>>) ?? [];
    const guards = providers
      .map((p, index) => ({ p, index }))
      .filter(({ p }) => p && p.provide === 'APP_GUARD')
      .map(({ p, index }) => ({ name: (p.useClass as { name?: string })?.name ?? String(p.useValue), index }));
    const names = guards.map((g) => g.name);
    expect(names).toContain('AdminHostGuard');
    const hostGate = guards.find((g) => g.name === 'AdminHostGuard')?.index ?? Number.MAX_SAFE_INTEGER;
    for (const other of ['LicenceAvailabilityGuard', 'ThrottlerGuard', 'JwtAuthGuard', 'TenantGuard', 'RolesGuard']) {
      const idx = guards.find((g) => g.name === other)?.index;
      if (idx !== undefined) expect(hostGate).toBeLessThan(idx);
    }
  });

  it('11. ATTACK: direct access to Nest with the Host nginx substitutes on a public hostname is refused on every console route, and that Host can never be allow-listed', async () => {
    // nginx hands the api `Host: host-gate.denied.invalid` for a console request
    // that arrived on a public hostname, and preserves the original URI and method
    // so that the refusal below is the api's own path-faithful 404. Listing the
    // reserved name in ADMIN_HOSTS must not rescue it: the parser drops reserved
    // `.invalid` entries, so only `localhost` remains usable here.
    const server = app.getHttpServer();
    process.env[ADMIN_HOSTS_VAR] = `${NGINX_GATE_HOSTNAME},${ADMIN_HOST}`;
    try {
      for (const route of routes) {
        const res = await send(server, route.method, route.path)
          .set('Host', NGINX_GATE_HOSTNAME)
          .set('content-type', 'application/json')
          .send({});
        expect(`${route.method} ${route.path} -> ${res.status}`).toBe(`${route.method} ${route.path} -> 404`);
        expect(res.body.path).toBe(route.path);
      }
      // the same configuration still serves the console on a real admin hostname
      const allowed = await send(server, 'GET', `/${API_GLOBAL_PREFIX}/platform/overview`).set('Host', ADMIN_HOST);
      expect(allowed.status).not.toBe(404);
    } finally {
      process.env[ADMIN_HOSTS_VAR] = ADMIN_HOST;
    }
  });

  it('12. the refusal preserves the original URI and method: no sentinel path is ever echoed back to the client', async () => {
    // Requirement from the owner when the sentinel rewrite was removed: what Nest
    // echoes must be the path and verb the attacker actually sent, so that a
    // refused console route and a route that never existed are the same answer.
    const server = app.getHttpServer();
    for (const route of routes) {
      const res = await send(server, route.method, route.path)
        .set('Host', PUBLIC_HOST)
        .set('content-type', 'application/json')
        .send({});
      const raw = JSON.stringify(res.body);
      expect(`${route.method} ${route.path} -> ${res.status}`).toBe(`${route.method} ${route.path} -> 404`);
      expect(res.body.path).toBe(route.path);
      expect(res.body.message).toBe(`Cannot ${route.method} ${route.path}`);
      // Nothing but the request's own coordinates: no sentinel, no gate vocabulary,
      // no explanation. (A blanket "must not contain admin" would be wrong - the
      // route /api/platform/admins legitimately echoes it, exactly as an unknown
      // route echoes its own name.)
      const shape = raw.split(route.path).join('<PATH>').replace(/"timestamp":"[^"]*"/, '"timestamp":"<TS>"');
      expect(shape).toBe(
        `{"statusCode":404,"path":"<PATH>","timestamp":"<TS>","message":"Cannot ${route.method} <PATH>"}`,
      );
      expect(raw.toLowerCase()).not.toContain('host-gate');
      expect(raw.toLowerCase()).not.toContain('.invalid');
      expect(Object.keys(res.body).sort()).toEqual(['message', 'path', 'statusCode', 'timestamp']);
    }
  });
});
