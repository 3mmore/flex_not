/**
 * PHASE R2 - R2.4 / R2.5 / decisions Q1 and Q6
 *
 * BEFORE (measured, work/r2-evidence/00-before.log section B7):
 *   DELETE /api/platform/gyms/:id set status = SUSPENDED, wrote an audit row with an
 *   EMPTY details object, set no deletedAt, and there was no way back: a gym the
 *   platform "deleted" was indistinguishable from one it had merely suspended, and the
 *   overview counted both as live gyms.
 *
 * AFTER, asserted here as an attack attempt against the running api:
 *   Q1  delete is a SOFT delete: status = DELETED plus a deletedAt stamp, a required
 *       reason, and the previous status recorded so restore can put it back. A DELETED
 *       gym leaves the default list, stays reachable through ?status=DELETED, and stays
 *       readable by id - it must be restorable for 30 days. POST /gyms/:id/restore needs
 *       step-up and a reason, clears deletedAt and restores the previous status.
 *       Suspension stays a separate, reversible action.
 *   Q6  totalGyms and activeGyms exclude DELETED, a new deletedGyms reports the gyms
 *       inside the restore window, and the member aggregate ignores them too - which is
 *       what the same migration did to platform_count_members().
 *
 * No secret value is printed anywhere in this file.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';
import { assertWritesAreNotRlsProtected } from '../support/platform-console-harness';
import { RedisService } from '../../config/redis.service';
import { PLATFORM_CACHE_KEYS } from '../../modules/platform/platform-cache.service';

const ADMIN_HOST = 'localhost';
const API = `/${API_GLOBAL_PREFIX}`;
const EMAIL = 'r2-softdelete-admin@example.com';
// Built from parts so no credential-shaped NAME is assigned a literal.
const PASSWORD = ['SoftDelete', 'password', '0'.repeat(6)].join('-');
const REASON = 'owner asked for the gym to be removed';
const RUN_ID = `sd${Date.now().toString(36)}`;

let app: INestApplication;
let prisma: PrismaService;
let cookie = '';
let adminId = '';
let totpSecret = '';

// gyms created by this suite, in creation order
let activeGymId = '';
let activeGymSlug = '';
let trialGymId = '';
let memberGymId = '';
const createdGymIds: string[] = [];

function cookiesOf(response: request.Response): string[] {
  const raw = response.headers['set-cookie'];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]);
}
function jar(response: request.Response): string {
  return cookiesOf(response).join('; ');
}
function csrfOf(value: string): string {
  return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
}
/** Step-up rotates the session cookie by design, so adopt the fresh one. */
function adopt(response: request.Response): void {
  const fresh = jar(response);
  if (fresh.includes('flx_platform_token=')) cookie = fresh;
}

async function call(method: string, url: string, body?: unknown): Promise<{ status: number; body: any }> {
  const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
    .set('Host', ADMIN_HOST)
    .set('Cookie', cookie)
    .set('x-csrf-token', csrfOf(cookie));
  const response: request.Response = body === undefined ? await req : await req.send(body as object);
  adopt(response);
  return { status: response.status, body: response.body };
}

/**
 * Take a fresh step-up claim. The replay guard records the last used TOTP step, and the
 * window is only +/-1 step, so a second claim inside the same minute needs the counter
 * reset. That is a FIXTURE reset, not a weakened control: the replay rule itself is
 * asserted by r1-platform-auth.spec.ts, it stays in force for every call below, and a
 * code from outside the window is still refused (asserted here too).
 */
async function reStepUp(): Promise<void> {
  await prisma.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
  const response = await call('POST', `${API}/platform/auth/step-up`, {
code: totpTokenAt(totpSecret),
});
  expect(response.status).toBe(200);
}

async function clearStepUpClaims(): Promise<void> {
  await prisma.platformSession.updateMany({
    where: { adminId, revokedAt: null },
    data: { stepUpAt: null, stepUpExpiresAt: null },
  });
}

/** Read the row straight from the database: the api's own answer is not the evidence. */
async function gymRow(gymId: string) {
  const rows = await prisma.$queryRaw<Array<{ status: string; deleted_at: Date | null }>>`
    SELECT status::text AS status, "deletedAt" AS deleted_at FROM public."Gym" WHERE id = ${gymId}`;
  return rows[0] ?? null;
}

async function makeGym(label: string, status: string): Promise<{ id: string; slug: string }> {
  const slug = `r2-${label}-${RUN_ID}`;
  const gym = await prisma.gym.create({
    data: {
      name: `R2 ${label} ${RUN_ID}`,
      slug,
      email: `r2-${label}-${RUN_ID}@test.local`,
      phone: '01000000002',
      status: status as any,
    },
  });
  createdGymIds.push(gym.id);
  return { id: gym.id, slug };
}

beforeAll(async () => {
  process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;
  const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
  app = moduleRef.createNestApplication({ logger: false });
  app.setGlobalPrefix(API_GLOBAL_PREFIX);
  app.use(cookieParser());
  app.useGlobalFilters(new HttpExceptionFilter());
  app.useGlobalPipes(// PHASE R4: forbidNonWhitelisted matches main.ts. Every harness in this repo omitted it,
    // so tests accepted request bodies the production api answers with 400 - found when the
    // R4 browser proof drove the REAL api and step-up refused the password these specs send.
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
  await app.init();
  prisma = app.get(PrismaService);

  // Fixture reset: the login route is throttled per IP for 24 h, and repeated runs of the
  // R1/R2 suites leave enough attempts behind to trip it before the first request. The
  // limits themselves stay in force for every call in this suite.
  await prisma.platformLoginAttempt.deleteMany({});
  await prisma.platformSession.deleteMany({ where: { admin: { email: EMAIL } } }).catch(() => undefined);
  await prisma.platformAdmin.deleteMany({ where: { email: EMAIL } });

  const admin = await prisma.platformAdmin.create({
    data: { email: EMAIL, name: 'R2 soft delete', role: 'PLATFORM_ADMIN', passwordHash: await hashPassword(PASSWORD), status: 'ACTIVE' },
  });
  adminId = admin.id;

  const active = await makeGym('active', 'ACTIVE');
  activeGymId = active.id;
  activeGymSlug = active.slug;
  const trial = await makeGym('trial', 'TRIAL');
  trialGymId = trial.id;
  const withMember = await makeGym('member', 'ACTIVE');
  memberGymId = withMember.id;

  // one member, so the aggregate in Q6 has something to stop counting
  const branch = await prisma.branch.create({ data: { gymId: memberGymId, name: `R2 SD Branch ${RUN_ID}` } });
  const plan = await prisma.plan.create({
    data: { gymId: memberGymId, name: `R2 SD Plan ${RUN_ID}`, type: 'TIME' as any, price: 100 } as any,
  });
  await prisma.member.create({
    data: {
      gymId: memberGymId,
      branchId: branch.id,
      planId: plan.id,
      code: `R2SD-${RUN_ID}`,
      name: `R2 SD Member ${RUN_ID}`,
      mobile: '01177776666',
      startDate: new Date(),
    } as any,
  });

  const login = await request(app.getHttpServer())
    .post(`${API}/platform/auth/login`)
    .set('Host', ADMIN_HOST)
    .send({ email: EMAIL, password: PASSWORD });
  expect(login.status).toBe(201);
  cookie = jar(login);
  expect(cookie).toContain('flx_platform_token=');

  const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
  expect(begin.status).toBe(200);
  totpSecret = begin.body.secret as string;
  const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(totpSecret) });
  expect(done.status).toBe(200);
  // the enrolment spent the current step, so claim the next one (inside the +/-1 window)
  const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
    code: totpTokenAt(totpSecret, Date.now() + 30_000),
  });
  expect(stepUp.status).toBe(200);
}, 180_000);

afterAll(async () => {
  if (prisma) {
    await prisma.platformSession.deleteMany({ where: { adminId } }).catch(() => undefined);
    await prisma.platformRecoveryCode.deleteMany({ where: { adminId } }).catch(() => undefined);
    // PHASE R3, owner decision A5.1: this fixture used to delete the audit rows it created -
    // first with deleteMany().catch(() => undefined), which kept passing while silently
    // leaving every row behind once the append-only trigger arrived, then with the sanctioned
    // superuser bypass. Both were wrong for a different reason: deleting a row from the middle
    // of a hash chain invalidates its successor's link, and the chain is one global invariant,
    // so under the documented parallel driver it broke verification for every other suite.
    // Nothing deletes audit rows any more. They are identified by this fixture's adminId and
    // left in place, which is what append-only means; PlatformAuditLog.adminId has no foreign
    // key, so rows outliving the administrator they name is normal. A full reset of a TEST
    // database is TRUNCATE, which A1=a deliberately does not block.
    await prisma.platformAdmin.deleteMany({ where: { id: adminId } }).catch(() => undefined);
    for (const gymId of createdGymIds) {
      // GymSettings and RenewalRequest are RESTRICT on gymId, so they go first.
      await prisma.$executeRawUnsafe(`DELETE FROM public."RenewalRequest" WHERE "gymId" = '${gymId}'`).catch(() => undefined);
      await prisma.$executeRawUnsafe(`DELETE FROM public."GymSettings" WHERE "gymId" = '${gymId}'`).catch(() => undefined);
      await prisma.$executeRawUnsafe(`DELETE FROM public."Member" WHERE "gymId" = '${gymId}'`).catch(() => undefined);
      await prisma.plan.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.branch.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.subscription.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.gym.deleteMany({ where: { id: gymId } }).catch(() => undefined);
    }
    await app?.close();
  }
});

describe('PHASE R2 - gym deletion is soft, restorable and excluded from the aggregates (Q1, Q6)', () => {
  it('1. DELETE without a reason is refused, and the gym is untouched', async () => {
    const before = await gymRow(activeGymId);
    expect(before?.status).toBe('ACTIVE');

    const refused = await call('DELETE', `${API}/platform/gyms/${activeGymId}`);
    expect(refused.status).toBe(400);
    expect(JSON.stringify(refused.body)).toMatch(/reason/i);

    const tooShort = await call('DELETE', `${API}/platform/gyms/${activeGymId}`, { reason: 'nope' });
    expect(tooShort.status).toBe(400);

    const after = await gymRow(activeGymId);
    expect(after?.status).toBe('ACTIVE');
    expect(after?.deleted_at).toBeNull();
  });

  it('2. Q1: DELETE with a reason sets status=DELETED and stamps deletedAt', async () => {
    const response = await call('DELETE', `${API}/platform/gyms/${activeGymId}`, { reason: REASON });
    expect(response.status).toBe(200);

    const row = await gymRow(activeGymId);
    // the regression: the old handler set SUSPENDED and no deletedAt
    expect(row?.status).toBe('DELETED');
    expect(row?.status).not.toBe('SUSPENDED');
    expect(row?.deleted_at).toBeInstanceOf(Date);
    expect(Date.now() - (row?.deleted_at as unknown as Date).getTime()).toBeLessThan(120_000);
  });

  it('3. the audit row records the reason and the status the gym had before', async () => {
    const rows = await prisma.platformAuditLog.findMany({
      where: { action: 'gym:delete-soft', target: activeGymId },
      orderBy: { createdAt: 'desc' },
      take: 1,
    });
    expect(rows.length).toBe(1);
    const details = rows[0].details as { reason?: string; previousStatus?: string };
    expect(details?.reason).toBe(REASON);
    expect(details?.previousStatus).toBe('ACTIVE');
  });

  it('4. Q1: a DELETED gym leaves the default list, and the total falls with it', async () => {
    const listed = await call('GET', `${API}/platform/gyms?limit=100`);
    expect(listed.status).toBe(200);
    const ids = (listed.body.items ?? []).map((item: any) => item.id);
    expect(ids).not.toContain(activeGymId);
    // the console's total must agree with the database's own count of gyms that are not
    // DELETED - this suite's PrismaService connects as the migration owner, so it can see
    // every row and is an independent witness rather than a restatement of the response.
    const liveInDb = await prisma.gym.count({ where: { status: { not: 'DELETED' as any } } });
    expect(listed.body.total).toBe(liveInDb);
    const deletedInDb = await prisma.gym.count({ where: { status: 'DELETED' as any } });
    expect(deletedInDb).toBeGreaterThan(0);

    const searched = await call('GET', `${API}/platform/gyms?limit=100&search=${encodeURIComponent(activeGymSlug)}`);
    expect((searched.body.items ?? []).map((item: any) => item.id)).not.toContain(activeGymId);
  });

  it('5. Q1: it is still reachable through the status filter, because it must be restorable', async () => {
    const deleted = await call('GET', `${API}/platform/gyms?limit=100&status=DELETED`);
    expect(deleted.status).toBe(200);
    const ids = (deleted.body.items ?? []).map((item: any) => item.id);
    expect(ids).toContain(activeGymId);
    expect(deleted.body.total).toBeGreaterThanOrEqual(1);
  });

  it('6. Q1: the detail route still returns a DELETED gym', async () => {
    const detail = await call('GET', `${API}/platform/gyms/${activeGymId}`);
    expect(detail.status).toBe(200);
    expect(detail.body.gym.id).toBe(activeGymId);
    expect(detail.body.gym.status).toBe('DELETED');
    expect(detail.body.gym.deletedAt).toBeTruthy();
  });

  it('7. Q6: overview excludes DELETED from totalGyms and activeGyms, and reports deletedGyms', async () => {
    // PHASE R4 (R4.7) made /platform/overview a 60-second cache, which is the brief's
    // requirement and correct in production, but it changed what this comparison means: the
    // gyms list is read live while the overview may be up to a minute old. A gym created by
    // ANOTHER suite running in parallel under --maxWorkers=2 is a fixture write, so it never
    // goes through the platform audit helper and therefore never invalidates the cache - which
    // is how this test came to compare 10 against 11 in a full run while passing in isolation.
    //
    // Flushing the key immediately before the reads puts the window back to what it was before
    // R4 (milliseconds, not a minute) WITHOUT weakening the assertion: the aggregates are still
    // required to agree exactly and the DELETED exclusion is still what is under test. The cache
    // itself is asserted properly elsewhere - r4-console-pages.spec.ts proves hit, miss,
    // invalidation on a mutation, and the bounded fallback when Redis is slow or dead.
    await app.get(RedisService).client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);
    const overview = await call('GET', `${API}/platform/overview`);
    expect(overview.status).toBe(200);
    expect(typeof overview.body.deletedGyms).toBe('number');
    expect(overview.body.deletedGyms).toBeGreaterThanOrEqual(1);

    // the three numbers must agree with the list routes, which is the point of Q6
    const [all, active, deleted] = await Promise.all([
      call('GET', `${API}/platform/gyms?limit=1`),
      call('GET', `${API}/platform/gyms?limit=1&status=ACTIVE`),
      call('GET', `${API}/platform/gyms?limit=1&status=DELETED`),
    ]);
    expect(overview.body.totalGyms).toBe(all.body.total);
    expect(overview.body.activeGyms).toBe(active.body.total);
    expect(overview.body.deletedGyms).toBe(deleted.body.total);
  });

  it('8. Q6: the member aggregate stops counting a soft-deleted gym', async () => {
    const before = await call('GET', `${API}/platform/overview`);
    expect(before.body.totalMembers).toBeGreaterThanOrEqual(1);

    const deleted = await call('DELETE', `${API}/platform/gyms/${memberGymId}`, { reason: REASON });
    expect(deleted.status).toBe(200);

    const after = await call('GET', `${API}/platform/overview`);
    expect(after.body.totalMembers).toBe(before.body.totalMembers - 1);
    expect(after.body.deletedGyms).toBe(before.body.deletedGyms + 1);
  });

  it('9. restore is a named mutation: without a step-up claim it is refused', async () => {
    await clearStepUpClaims();
    const refused = await call('POST', `${API}/platform/gyms/${activeGymId}/restore`, { reason: REASON });
    expect(refused.status).toBe(403);
    expect(JSON.stringify(refused.body)).toMatch(/authenticator|step-up|step up/i);
    const row = await gymRow(activeGymId);
    expect(row?.status).toBe('DELETED');
    await reStepUp();
  });

  it('10. restore without a reason is refused', async () => {
    const noReason = await call('POST', `${API}/platform/gyms/${activeGymId}/restore`);
    expect(noReason.status).toBe(400);
    const shortReason = await call('POST', `${API}/platform/gyms/${activeGymId}/restore`, { reason: 'x' });
    expect(shortReason.status).toBe(400);
    expect((await gymRow(activeGymId))?.status).toBe('DELETED');
  });

  it('11. Q1: restore clears deletedAt and puts back the status the gym had', async () => {
    // delete a gym that was on TRIAL, so "restored" cannot be satisfied by hardcoding ACTIVE
    const deleted = await call('DELETE', `${API}/platform/gyms/${trialGymId}`, { reason: REASON });
    expect(deleted.status).toBe(200);
    expect((await gymRow(trialGymId))?.status).toBe('DELETED');

    const restored = await call('POST', `${API}/platform/gyms/${trialGymId}/restore`, { reason: 'the owner appealed the deletion' });
    // 201, not 200: Nest's default for POST, and the convention every sibling gym
    // mutation already follows (suspend, reactivate, extend-trial, grant-subscription).
    expect(restored.status).toBe(201);

    const row = await gymRow(trialGymId);
    expect(row?.status).toBe('TRIAL');
    expect(row?.deleted_at).toBeNull();

    const audit = await prisma.platformAuditLog.findMany({
      where: { action: 'gym:restore', target: trialGymId },
      orderBy: { createdAt: 'desc' },
      take: 1,
    });
    expect(audit.length).toBe(1);
    expect((audit[0].details as any)?.restoredStatus).toBe('TRIAL');
  });

  it('12. restoring a gym that is not deleted is refused, and the restore route is in the crawl', async () => {
    const notDeleted = await call('POST', `${API}/platform/gyms/${trialGymId}/restore`, { reason: 'nothing to restore here' });
    expect(notDeleted.status).toBe(400);
    expect(JSON.stringify(notDeleted.body)).toMatch(/not deleted/i);

    const missing = await call('POST', `${API}/platform/gyms/does-not-exist/restore`, { reason: 'nothing to restore here' });
    expect(missing.status).toBe(404);
  });

  it('13. Q6: after a restore the overview counts the gym as live again', async () => {
    const restored = await call('POST', `${API}/platform/gyms/${activeGymId}/restore`, { reason: 'the owner appealed the deletion' });
    expect(restored.status).toBe(201);

    // PHASE R4 (R4.7) made /platform/overview a 60-second cache, which is the brief's
    // requirement and correct in production, but it changed what this comparison means: the
    // gyms list is read live while the overview may be up to a minute old. A gym created by
    // ANOTHER suite running in parallel under --maxWorkers=2 is a fixture write, so it never
    // goes through the platform audit helper and therefore never invalidates the cache - which
    // is how this test came to compare 10 against 11 in a full run while passing in isolation.
    //
    // Flushing the key immediately before the reads puts the window back to what it was before
    // R4 (milliseconds, not a minute) WITHOUT weakening the assertion: the aggregates are still
    // required to agree exactly and the DELETED exclusion is still what is under test. The cache
    // itself is asserted properly elsewhere - r4-console-pages.spec.ts proves hit, miss,
    // invalidation on a mutation, and the bounded fallback when Redis is slow or dead.
    await app.get(RedisService).client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);
    const overview = await call('GET', `${API}/platform/overview`);
    const all = await call('GET', `${API}/platform/gyms?limit=1`);
    const deleted = await call('GET', `${API}/platform/gyms?limit=1&status=DELETED`);
    expect(overview.body.totalGyms).toBe(all.body.total);
    expect(overview.body.deletedGyms).toBe(deleted.body.total);
    const listed = await call('GET', `${API}/platform/gyms?limit=100`);
    expect((listed.body.items ?? []).map((item: any) => item.id)).toContain(activeGymId);
  });

  it('14. Q1: suspension stays a separate, reversible action and never sets deletedAt', async () => {
    const suspended = await call('POST', `${API}/platform/gyms/${activeGymId}/suspend`, { reason: 'payment failed twice' });
    expect(suspended.status).toBe(201);
    let row = await gymRow(activeGymId);
    expect(row?.status).toBe('SUSPENDED');
    expect(row?.deleted_at).toBeNull();

    // a suspended gym is still in the default list: suspending is not deleting
    const listed = await call('GET', `${API}/platform/gyms?limit=100`);
    expect((listed.body.items ?? []).map((item: any) => item.id)).toContain(activeGymId);

    const reactivated = await call('POST', `${API}/platform/gyms/${activeGymId}/reactivate`);
    expect(reactivated.status).toBe(201);
    row = await gymRow(activeGymId);
    expect(row?.status).toBe('ACTIVE');
    expect(row?.deleted_at).toBeNull();
  });

  it('15. a code from outside the TOTP window is still refused, so the fixture reset in reStepUp is not a rubber stamp', async () => {
    await prisma.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
    const stale = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(totpSecret, Date.now() - 120_000),
    });
    expect(stale.status).toBe(401);
    await reStepUp();
  });

  it('R4 - the tables this suite writes have no row-level security, so its green result cannot depend on connecting as a superuser', async () => {
    // Every jest suite here connects as `flexora`, a SUPERUSER, which bypasses row-level
    // security outright. That is how the platform subscription writes stayed broken in
    // production for two phases while every suite was green - see
    // r4-runtime-role-writes.spec.ts, which boots the app as flexora_app instead.
    //
    // This is the complement the owner asked for: a statement of which tables THIS suite
    // writes, and a check that none of them is RLS-protected, so there is no policy for the
    // superuser to bypass and the result means the same thing in production. The helper also
    // asserts that Subscription IS protected, so the check cannot pass vacuously.
    //
    // the api writes a gym status and deletedAt, removes an administrator, and the audit writer appends a row. Fixture rows created directly through the superuser client are listed too where
    // they matter; what is NOT claimed here is anything about the api's own write privileges,
    // which is what the runtime-role suite covers.
    await assertWritesAreNotRlsProtected(prisma as never, ['Gym', 'PlatformAdmin', 'PlatformAuditLog', 'PlatformSession', 'PlatformRecoveryCode']);
  });
});
