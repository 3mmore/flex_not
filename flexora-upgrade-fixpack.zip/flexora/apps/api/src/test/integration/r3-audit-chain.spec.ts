/** @jest-environment node */
/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — R3.1, R3.2, R3.3, R3.5 and owner decisions A1/A2, proven by attack.
 *
 * The standing rule is that a security claim is proved by an ATTEMPT in a test, never by
 * reading code. So this file tries to forge the platform audit log and asserts that each
 * attempt fails, and that the chain verifier reports the exact row when something is
 * changed out of band.
 *
 * BEFORE (work/r3-evidence/00-before.log, section B3, measured live and rolled back):
 *     as the migration owner:  UPDATE 1 / DELETE 1  - both SUCCEEDED
 *     as flexora_app:          UPDATE 1 / DELETE 1  - both SUCCEEDED
 * An administrator who could reach either role, or anyone who obtained the database
 * credential, could rewrite or erase the record of their own actions. That is what R3.1
 * closes, and tests 1 and 2 below are the AFTER for those two exact attacks.
 *
 * Every tampering test here runs inside a transaction that is ROLLED BACK, and each one
 * asserts afterwards that the chain head digest is unchanged, so the rollback is proven
 * rather than assumed. The literal reading of A2.5 - tamper on a COPY of the database and
 * drop the copy - is work/r3-tamper-on-copy.sh, which never lets a superuser write to the
 * live log even transiently. Both exist on purpose.
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import { PrismaClient } from '@prisma/client';
import {
  CHAIN_LOCK_SQL,
  deleteAuditRowsInTransaction,
  tamperAndVerify,
  trimChainFromFirstGap,
} from '../support/audit-bypass';

jest.setTimeout(240_000);

const RUNTIME_ROLE = 'flexora_app';
const MARKER = 'r3-chain-spec';
/**
 * Base 36, and per-run. Because decision A5 means nothing ever deletes an audit row, every run
 * of this suite leaves its rows behind, so any assertion that counts "the rows this test made"
 * must be scoped to this run or it counts the previous run's survivors too. That is not a
 * workaround - it is the direct consequence of an append-only log, and it is why A5.1 says
 * tests identify their own rows rather than cleaning up.
 */
const RUN_ID = Date.now().toString(36);
/** The migration whose backfill must use the same hash function as the runtime trigger. */
const CHAIN_MIGRATION_FILE = path.resolve(
  __dirname,
  '../../../prisma/migrations/20261107120000_platform_audit_chain_r3/migration.sql',
);

/** Refusal message written by the append-only trigger. */
const APPEND_ONLY_MESSAGE = /append-only/i;

function buildRuntimeRoleUrl(): string {
  const ownerUrl = process.env.DATABASE_URL;
  const password = process.env.FLEXORA_APP_TEST_PASSWORD;
  if (!ownerUrl) throw new Error('DATABASE_URL is not set; run this through work/r2-one-spec.sh');
  if (!password) throw new Error('FLEXORA_APP_TEST_PASSWORD is not set; run this through work/r2-one-spec.sh');
  const url = new URL(ownerUrl);
  url.username = RUNTIME_ROLE;
  url.password = password;
  return url.toString();
}

/**
 * Run a statement that is expected to be refused and return the SQLSTATE the server gave,
 * captured inside the same transaction by a PL/pgSQL exception handler.
 *
 * Asserting on a caught JavaScript error message would prove only that SOMETHING failed.
 * This proves the failure was SQLSTATE 42501 (insufficient_privilege), which is the class
 * the api maps to a 403 and the class the trigger is documented to raise. 'none' means the
 * statement was allowed, and the caller asserts that never happens.
 */
async function probeRefusal(client: PrismaClient, statement: string): Promise<{ sqlstate: string; message: string }> {
  return client.$transaction(async (tx) => {
    await tx.$executeRaw`CREATE TEMP TABLE r3_probe (sqlstate text, message text) ON COMMIT DROP`;
    await tx.$executeRawUnsafe(`
      DO $probe$
      BEGIN
        ${statement}
        INSERT INTO r3_probe VALUES ('none', 'statement was allowed');
      EXCEPTION WHEN OTHERS THEN
        INSERT INTO r3_probe VALUES (SQLSTATE, left(SQLERRM, 160));
      END
      $probe$;`);
    const rows = await tx.$queryRaw<Array<{ sqlstate: string; message: string }>>`SELECT * FROM r3_probe`;
    return rows[0] ?? { sqlstate: 'no-row', message: 'the probe recorded nothing' };
  });
}

describe('R3.1/R3.2/R3.5 — the platform audit log is append-only and hash-chained', () => {
  let owner: PrismaClient;
  let runtime: PrismaClient;
  const createdIds: string[] = [];
  /** Rows this suite created for itself, so it never depends on pre-existing history. */
  const seededSeqs: number[] = [];
  const SEED_ROWS = 10;

  beforeAll(async () => {
    owner = new PrismaClient();
    runtime = new PrismaClient({ datasources: { db: { url: buildRuntimeRoleUrl() } } });
    // A5.1: tests identify their own rows rather than cleaning up, which also means they
    // must CREATE their own rows. This suite used to read whatever history the workspace
    // happened to have, and a sandbox wipe rebuilds the database empty - six tests then failed on
    // `findFirst(... skip: 4)` returning null. Seeding a known population makes the suite
    // self-sufficient and its assertions deterministic.
    const seeded = await owner.platformAuditLog.count({ where: { adminId: MARKER } });
    if (seeded < SEED_ROWS) {
      for (let index = 0; index < SEED_ROWS - seeded; index += 1) {
        const created = await owner.platformAuditLog.create({
          data: {
            adminId: MARKER,
            adminName: 'R3 chain spec',
            action: `${MARKER}:seed-${seeded + index}`,
            target: `target-${index}`,
            details: { seeded: true, index } as object,
            reason: 'seed row so the suite does not depend on pre-existing history',
          },
          select: { seq: true },
        });
        seededSeqs.push(Number(created.seq));
      }
    } else {
      const existing = await owner.platformAuditLog.findMany({
        where: { adminId: MARKER },
        orderBy: { seq: 'asc' },
        take: SEED_ROWS,
        select: { seq: true },
      });
      seededSeqs.push(...existing.map((row) => Number(row.seq)));
    }
    expect(seededSeqs.length).toBeGreaterThanOrEqual(SEED_ROWS);

    const [identity] = await runtime.$queryRaw<Array<{ current_user: string }>>`SELECT current_user`;
    // If this is not the runtime role, every "refused for the runtime role" assertion below
    // would be meaningless, so fail the suite instead of quietly testing the wrong thing.
    expect(identity.current_user).toBe(RUNTIME_ROLE);
  });

  afterAll(async () => {
    // PHASE R3, owner decision A5.1: NOTHING here deletes audit rows. This suite used to
    // remove the rows it created through the sanctioned bypass, and that is precisely what
    // broke the chain for every other suite running in parallel - deleting a row from the
    // middle invalidates its successor's link, and the chain is one global invariant.
    //
    // Rows are identified by their marker instead of being cleaned up, and they are left in
    // place, which is what an append-only log means. PlatformAuditLog.adminId has no foreign
    // key (measured), so rows outliving the administrator they name is normal, not untidy.
    // A full reset of a TEST database is TRUNCATE, which A1=a deliberately does not block;
    // that never applies to a real deployment.
    void createdIds;
    await runtime.$disconnect();
    await owner.$disconnect();
  });

  it('0. A6 - the chain has no gap left behind by an earlier deletion, and repairs one through the sanctioned helper if it finds it', async () => {
    // WHY THIS TEST EXISTS. Test fixtures used to delete the audit rows they created through
    // the documented superuser bypass. Deleting a row from the MIDDLE of a hash chain
    // invalidates its successor's link, and because the chain is one global invariant, that
    // broke verification for every other suite reading it at the same moment - which is how
    // this suite came to see valid=false before it had done anything, under the documented
    // parallel driver (maxWorkers=2), while passing 16/16 in isolation.
    //
    // Owner decision A5 removed audit-row deletion from every fixture. Decision A6 is the
    // one-off repair of the database where it had already happened: remove every row at or
    // above the first gap, leaving a valid shorter chain, and never rewrite a stored hash -
    // rewriting history is the thing the chain exists to prevent.
    //
    // It stays in the suite as a guard. On a healthy database trimChainFromFirstGap removes
    // nothing and reports repaired=false, so this is a no-op assertion that the chain is
    // intact. If a gap ever reappears, this repairs it and prints exactly which seqs went.
    const report = await trimChainFromFirstGap(owner);
    // Printed, not swallowed: A6.1 and A6.6 require the removed seqs and the reason to be
    // recorded. No secret value appears in this report.
    // eslint-disable-next-line no-console
    console.log(
      [
        'R3_CHAIN_REPAIR_REPORT',
        `  repaired=${report.repaired}`,
        `  reason=${report.reason}`,
        `  firstMissingSeq=${report.firstMissingSeq ?? '-'}`,
        `  rowsBefore=${report.rowsBefore} rowsAfter=${report.rowsAfter}`,
        `  lastValidSeq=${report.lastValidSeq ?? '-'} lastValidHash=${
          report.lastValidHash ? report.lastValidHash.slice(0, 16) + '...' : '-'
        }`,
        `  removedSeqs(${report.removedSeqs.length})=${report.removedSeqs.join(',') || '(none)'}`,
        `  belowGapCount=${report.belowGapCountBefore}->${report.belowGapCountAfter}`,
        `  belowGapChecksum=${report.belowGapChecksumBefore}->${report.belowGapChecksumAfter}`,
        `  belowGapUnchanged=${report.belowGapUnchanged}`,
        `  verifyAfter=${JSON.stringify(report.verifyAfter)}`,
        `  probeSeq=${report.probeSeq ?? '-'}`,
      ].join('\n'),
    );

    expect(report.belowGapUnchanged).toBe(true);
    expect(report.verifyAfter.valid).toBe(true);
    expect(report.verifyAfter.broken_rows).toBe(0);
    expect(Number(report.verifyAfter.rows_checked)).toBe(report.rowsAfter);
    if (report.repaired) {
      // A6.4 - the numbering must continue gaplessly, which the probe row proves: it was the
      // last insert, so its seq is exactly the row count. The probe is LEFT IN PLACE, because
      // A5 means nothing deletes audit rows.
      expect(report.probeSeq).toBe(report.rowsAfter + 1);
      expect(report.firstMissingSeq).not.toBeNull();
      expect(report.removedSeqs.every((seq) => seq >= (report.firstMissingSeq as number))).toBe(true);
    }
  });

  it('0b. A6 ROUND TRIP - a gap made by a sanctioned deletion is repaired, and everything below it is byte-identical', async () => {
    // The database whose chain the fixtures had actually broken was destroyed by a sandbox
    // wipe before the repair could run, so the repair is proved here instead: make a real gap
    // on purpose, then repair it, and assert every property A6 asks for.
    //
    // All of it happens inside ONE transaction holding the chain advisory lock, so the broken
    // state is never committed and no suite running in parallel can observe it - which is the
    // interference that decision A5 exists to remove. If any step throws, everything rolls
    // back and the database is left exactly as it was.
    const outcome = await owner.$transaction(async (tx) => {
      await tx.$executeRawUnsafe(CHAIN_LOCK_SQL);
      const adminId = `${MARKER}-a6-${RUN_ID}`;
      createdIds.push(adminId);

      const created: Array<{ seq: number | null }> = [];
      for (let index = 0; index < 3; index += 1) {
        created.push(
          await tx.platformAuditLog.create({
            data: {
              adminId,
              adminName: MARKER,
              action: `${MARKER}:a6-roundtrip-${index}`,
              target: null,
            },
            select: { seq: true },
          }),
        );
      }

      // Take out the MIDDLE row. That is exactly what a fixture cleanup used to do, and it is
      // the case a hash chain detects at the successor rather than at the victim.
      const middle = Number(created[1].seq);
      const removed = await deleteAuditRowsInTransaction(tx, { seq: middle });
      expect(removed).toBe(1);

      const broken = await tx.$queryRaw<
        Array<{ valid: boolean; first_broken_seq: number | null; first_broken_reason: string | null }>
      >`SELECT valid, first_broken_seq::integer, first_broken_reason FROM public.platform_audit_verify()`;

      // Repair it through the sanctioned helper, inside the same transaction.
      const report = await trimChainFromFirstGap(tx);
      return { created, middle, broken: broken[0], report };
    });

    // A6.1 and A6.6: record what the repair did. Printed rather than swallowed, because the
    // owner asked for the removed seqs and the reason to be in the evidence, and no secret
    // value appears in any of these fields.
    // eslint-disable-next-line no-console
    console.log(
      [
        'R3_A6_ROUND_TRIP',
        `  gapCreatedAtSeq=${outcome.middle}`,
        `  diagnosedValid=${outcome.broken.valid} firstBrokenSeq=${outcome.broken.first_broken_seq} reason=${outcome.broken.first_broken_reason}`,
        `  repaired=${outcome.report.repaired}`,
        `  firstMissingSeq=${outcome.report.firstMissingSeq}`,
        `  removedSeqs(${outcome.report.removedSeqs.length})=${outcome.report.removedSeqs.join(',') || '(none)'}`,
        `  rowsBefore=${outcome.report.rowsBefore} rowsAfter=${outcome.report.rowsAfter}`,
        `  lastValidSeq=${outcome.report.lastValidSeq} lastValidHash=${outcome.report.lastValidHash?.slice(0, 16)}...`,
        `  belowGapCount=${outcome.report.belowGapCountBefore}->${outcome.report.belowGapCountAfter}`,
        `  belowGapChecksum=${outcome.report.belowGapChecksumBefore}->${outcome.report.belowGapChecksumAfter}`,
        `  belowGapUnchanged=${outcome.report.belowGapUnchanged}`,
        `  verifyAfter=${JSON.stringify(outcome.report.verifyAfter)}`,
        `  probeSeq=${outcome.report.probeSeq}`,
      ].join('\n'),
    );

    // the gap was real and was diagnosed
    expect(outcome.broken.valid).toBe(false);
    expect(outcome.broken.first_broken_reason).toBeTruthy();

    // A6.2 - only rows at or above the first gap were removed, and the first gap is the row
    // that was taken out, so what goes is the single row that survived above it.
    expect(outcome.report.repaired).toBe(true);
    expect(outcome.report.firstMissingSeq).toBe(outcome.middle);
    expect(outcome.report.removedSeqs).toEqual([Number(outcome.created[2].seq)]);
    expect(outcome.report.removedSeqs.every((seq) => seq >= outcome.middle)).toBe(true);

    // A6.1/A6.3 - everything below the gap is byte-identical, by count AND by checksum.
    expect(outcome.report.belowGapUnchanged).toBe(true);
    expect(outcome.report.belowGapCountBefore).toBe(outcome.report.belowGapCountAfter);
    expect(outcome.report.belowGapChecksumBefore).toBe(outcome.report.belowGapChecksumAfter);
    expect(outcome.report.belowGapChecksumBefore).toMatch(/^[0-9a-f]{32}$/);

    // A6.4 - valid afterwards, the count agrees, and the numbering continues gaplessly: the
    // probe row was the last insert, so its seq is exactly the row count.
    expect(outcome.report.verifyAfter.valid).toBe(true);
    expect(outcome.report.verifyAfter.broken_rows).toBe(0);
    expect(Number(outcome.report.verifyAfter.rows_checked)).toBe(outcome.report.rowsAfter);
    // The probe is inserted AFTER rowsAfter is counted, so gapless means rowsAfter + 1: the
    // trimmed chain is 1..rowsAfter with no holes, and the next insert takes the next number.
    expect(outcome.report.probeSeq).toBe(outcome.report.rowsAfter + 1);

    // and in committed state the chain holds, with the rows A5 says are never deleted
    const [chain] = await owner.$queryRaw<Array<{ valid: boolean; broken_rows: number }>>`
      SELECT valid, broken_rows::integer FROM public.platform_audit_verify()`;
    expect(chain.valid).toBe(true);
    expect(chain.broken_rows).toBe(0);
    const survivors = await owner.platformAuditLog.count({
      where: { adminId: `${MARKER}-a6-${RUN_ID}` },
    });
    // Scoped to THIS run, exactly one row survives under its administrator id: row 1 was the
    // deliberate gap and row 2 sat above the gap, so the trim took it too. The probe row is
    // written by the helper under its OWN administrator id ('chain-repair-probe'), which is
    // counted separately - the first version of this assertion assumed otherwise and was
    // wrong, which is worth recording because it is the kind of thing that looks like a
    // product defect and is not.
    expect(survivors).toBe(1);
    const probes = await owner.platformAuditLog.count({ where: { adminId: 'chain-repair-probe' } });
    expect(probes).toBeGreaterThanOrEqual(1);
  });

  it('0c. A5.3 GUARD - nothing outside the sanctioned module and this file deletes audit rows', () => {
    // A guard, not a comment. If a future fixture reaches for deleteMany on the audit log, or
    // imports the bypass helper, this fails and says which file did it. Without it, decision
    // A5 would be a convention that only code review enforces.
    const apiRoot = path.resolve(__dirname, '../../..');
    const roots = [path.resolve(apiRoot, 'src'), path.resolve(apiRoot, 'prisma')];

    const files: string[] = [];
    const walk = (directory: string): void => {
      for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        const full = path.join(directory, entry.name);
        if (entry.isDirectory()) {
          if (entry.name === 'node_modules' || entry.name === 'dist') continue;
          walk(full);
        } else if (entry.name.endsWith('.ts')) {
          files.push(full);
        }
      }
    };
    for (const root of roots) walk(root);
    expect(files.length).toBeGreaterThan(50);

    // The only two files allowed to mention a deletion path at all: the sanctioned module
    // itself, and this suite's single negative control.
    const sanctioned = ['test/support/audit-bypass.ts', 'test/integration/r3-audit-chain.spec.ts'];
    const forbidden = [
      { name: 'platformAuditLog.deleteMany', re: /platformAuditLog\s*\.\s*deleteMany/ },
      { name: 'platformAuditLog.delete(', re: /platformAuditLog\s*\.\s*delete\s*\(/ },
      { name: 'DELETE FROM "PlatformAuditLog"', re: /DELETE\s+FROM\s+(public\.)?"PlatformAuditLog"/i },
      { name: 'deleteAuditRowsBypass', re: /deleteAuditRowsBypass/ },
      { name: 'deleteAuditRowsInTransaction', re: /deleteAuditRowsInTransaction/ },
      { name: 'trimChainFromFirstGap', re: /trimChainFromFirstGap/ },
    ];

    const violations: string[] = [];
    for (const file of files) {
      const relative = path.relative(apiRoot, file).split(path.sep).join('/');
      if (sanctioned.some((allowed) => relative.endsWith(allowed))) continue;
      const text = fs.readFileSync(file, 'utf8');
      for (const rule of forbidden) {
        if (rule.re.test(text)) violations.push(`${relative} -> ${rule.name}`);
      }
    }
    expect(violations).toEqual([]);

    // Product source must not import a fixture module at all, in either direction.
    const productFiles = files.filter((file) => {
      const relative = path.relative(apiRoot, file).split(path.sep).join('/');
      return relative.startsWith('src/modules/') || relative.startsWith('src/config/') || relative.startsWith('prisma/');
    });
    const badImports = productFiles.filter((file) =>
      /from\s+'[^']*test\/support\/audit-bypass'/.test(fs.readFileSync(file, 'utf8')),
    );
    expect(badImports).toEqual([]);

    // And inside the sanctioned suite the deletion path appears only where A5.2 allows: the
    // negative control (2c), the A6 round trip (0b) and the A6 guard (0). Counting the call
    // sites means adding a fourth one is a visible, deliberate act.
    const own = fs.readFileSync(__filename, 'utf8');
    const callSites = (own.match(/deleteAuditRowsInTransaction\(tx,/g) ?? []).length;
    expect(callSites).toBe(2);
    expect((own.match(/trimChainFromFirstGap\(/g) ?? []).length).toBe(2);
    expect(own).not.toMatch(/deleteAuditRowsBypass\(/);
  });

  // ── 1 and 2: the two BEFORE attacks, now refused ────────────────────────────
  it('1. ATTACK as the runtime role: UPDATE and DELETE on an audit row are both refused with 42501', async () => {
    const before = await owner.platformAuditLog.count();

    const victim = seededSeqs[0];
    const update = await probeRefusal(
      runtime,
      `UPDATE public."PlatformAuditLog" SET action = '${MARKER}-forged' WHERE seq = ${victim};`,
    );
    const remove = await probeRefusal(
      runtime,
      `DELETE FROM public."PlatformAuditLog" WHERE seq = ${victim};`,
    );

    expect(update.sqlstate).toBe('42501');
    expect(update.message).toMatch(APPEND_ONLY_MESSAGE);
    expect(remove.sqlstate).toBe('42501');
    expect(remove.message).toMatch(APPEND_ONLY_MESSAGE);

    // The refusal must not have cost a row, and no forged action may have landed.
    expect(await owner.platformAuditLog.count()).toBe(before);
    // The FORGED action specifically, not the marker: this suite now seeds its own rows and
    // every one of them carries the marker in its action, so counting the marker would count
    // the fixture's own legitimate rows.
    expect(
      await owner.platformAuditLog.count({ where: { action: { contains: `${MARKER}-forged` } } }),
    ).toBe(0);
    expect(
      await owner.platformAuditLog.count({ where: { adminName: { contains: `${MARKER}-owner` } } }),
    ).toBe(0);
  });

  it('2. ATTACK as the migration owner (a SUPERUSER): UPDATE and DELETE are refused too — A1 option a', async () => {
    const [role] = await owner.$queryRaw<Array<{ rolsuper: boolean; current_user: string }>>`
      SELECT r.rolsuper, current_user FROM pg_roles r WHERE r.rolname = current_user`;
    // The claim is about a superuser being refused. If the owner credential ever stops
    // being a superuser this test would pass for the wrong reason.
    expect(role.rolsuper).toBe(true);

    const before = await owner.platformAuditLog.count();
    const victim = seededSeqs[0];
    const update = await probeRefusal(
      owner,
      `UPDATE public."PlatformAuditLog" SET "adminName" = '${MARKER}-owner' WHERE seq = ${victim};`,
    );
    const remove = await probeRefusal(owner, `DELETE FROM public."PlatformAuditLog" WHERE seq = ${victim};`);

    expect(update.sqlstate).toBe('42501');
    expect(remove.sqlstate).toBe('42501');
    expect(await owner.platformAuditLog.count()).toBe(before);
  });

  it('2b. NEGATIVE CONTROL: the same runtime connection can still write to a non-audit platform table', async () => {
    // Without this, tests 1 and 2 would also pass if the runtime role simply had no write
    // access anywhere, or if the probe helper swallowed every error. PlatformAlert has no
    // RLS and is granted to the runtime role, so one insert proves the connection writes.
    const id = `${MARKER}-control-${Date.now()}`;
    await runtime.$executeRaw`
      INSERT INTO public."PlatformAlert"
        ("id","type","severity","targetKind","channel","status","attempts","maxAttempts","dedupeKey","createdAt","updatedAt")
      VALUES (${id}::text,'GYM_DELETED'::text,'info'::text,'platform'::text,'WHATSAPP_OWNER'::text,
              'PENDING'::text,0::integer,5::integer,${id}::text,now(),now())`;
    const written = await owner.platformAlert.count({ where: { id } });
    expect(written).toBe(1);
    await owner.platformAlert.deleteMany({ where: { id } });
  });

  it('2c. NEGATIVE CONTROL: the documented superuser bypass DOES work, so the refusal is the trigger and not a missing grant', async () => {
    // A1=a names session_replication_role=replica as the sanctioned bypass. Proving it works
    // is what separates "the trigger refuses this" from "nobody could ever write here".
    //
    // A5.2: this is the ONLY deletion of an audit row anywhere in the test tree, and it holds
    // the chain advisory lock - the same lock the insert trigger takes - across the whole of
    // create-and-delete. That is what makes the removed row provably the tail: no writer can
    // append in between and turn a tail-trim into a mid-chain deletion. The chain is asserted
    // valid afterwards, so if that ordering were ever broken this test would fail.
    const adminId = `${MARKER}-bypass`;
    createdIds.push(adminId);

    const outcome = await owner.$transaction(async (tx) => {
      await tx.$executeRawUnsafe(CHAIN_LOCK_SQL);
      const headBefore = await tx.$queryRaw<Array<{ head_seq: number | null }>>`
        SELECT head_seq::integer FROM public.platform_audit_verify()`;
      const created = await tx.platformAuditLog.create({
        data: { adminId, adminName: MARKER, action: `${MARKER}:bypass-probe`, target: null },
        select: { id: true, seq: true },
      });
      const deleted = await deleteAuditRowsInTransaction(tx, { id: created.id });
      return { headBefore: headBefore[0].head_seq, created, deleted };
    });

    expect(outcome.deleted).toBe(1);
    expect(outcome.created.seq).not.toBeNull();
    expect(await owner.platformAuditLog.count({ where: { id: outcome.created.id } })).toBe(0);
    // The row it took was the tail, so the head is back where it started and the chain holds.
    const [chain] = await owner.$queryRaw<Array<{ valid: boolean; head_seq: number; broken_rows: number }>>`
      SELECT valid, head_seq::integer, broken_rows::integer FROM public.platform_audit_verify()`;
    expect(chain.valid).toBe(true);
    expect(chain.broken_rows).toBe(0);
    expect(chain.head_seq).toBe(outcome.headBefore);
  });

  it('2d. TRUNCATE is deliberately NOT blocked (A1 option a, not c), inside a rolled-back transaction', async () => {
    // The harness reset and any future retention job truncate this table. Blocking TRUNCATE
    // was option c and the owner chose a. Proved in a transaction that is rolled back, so
    // the live log is never actually emptied.
    const outcome = await owner
      .$transaction(async (tx) => {
        await tx.$executeRaw`TRUNCATE public."PlatformAuditLog"`;
        const rows = await tx.$queryRaw<Array<{ n: number }>>`SELECT count(*)::integer AS n FROM public."PlatformAuditLog"`;
        throw new Rollback(rows[0].n);
      })
      .catch((error: unknown) => (error instanceof Rollback ? error.payload : Promise.reject(error)));
    expect(outcome).toBe(0);
    // ...and the real table is untouched.
    expect(await owner.platformAuditLog.count()).toBeGreaterThan(0);
  });

  // ── 3: the chain is assigned by the database, never by the caller ───────────
  it('3. a caller who supplies seq, hash and prevHash has all three overwritten by the trigger', async () => {
    const head = await owner.$queryRaw<Array<{ head_seq: number | null; head_hash: string | null }>>`
      SELECT head_seq::integer, head_hash FROM public.platform_audit_verify()`;
    const expectedSeq = (head[0].head_seq ?? 0) + 1;

    const row = await owner.$queryRaw<
      Array<{ id: string; seq: number; hash: string; prevHash: string | null }>
    >`
      INSERT INTO public."PlatformAuditLog"
        -- There is deliberately no "updatedAt" column on an append-only table, so a raw
        -- insert must not name one.
        ("id","adminId","adminName","action","target","details","ip","createdAt",
         "seq","hash","prevHash","stepUpUsed")
      VALUES (gen_random_uuid()::text, ${`${MARKER}-forge`}::text, ${MARKER}::text,
              ${`${MARKER}:forged-chain`}::text, NULL, '{}'::jsonb, NULL, now(),
              999999::integer, ${'forged'.repeat(16)}::text, ${'forgedprev'.repeat(10)}::text,
              false)
      RETURNING "id", seq::integer, hash, "prevHash"`;

    createdIds.push(`${MARKER}-forge`);
    expect(row).toHaveLength(1);
    // The forged chain position and both forged digests were all discarded.
    expect(row[0].seq).toBe(expectedSeq);
    expect(row[0].hash).not.toMatch(/forged/);
    expect(row[0].hash).toHaveLength(64);
    expect(row[0].prevHash).toBe(head[0].head_hash);
    // And the chain is still intact with the new row on the end of it.
    const after = await owner.$queryRaw<Array<{ valid: boolean; head_seq: number }>>`
      SELECT valid, head_seq::integer FROM public.platform_audit_verify()`;
    expect(after[0].valid).toBe(true);
    expect(after[0].head_seq).toBe(expectedSeq);
  });

  // ── 4: verification over real, backfilled history ──────────────────────────
  it('4. the chain verifies over every row including the ones the migration backfilled', async () => {
    const [chain] = await owner.$queryRaw<
      Array<{ rows_checked: number; valid: boolean; broken_rows: number; head_seq: number; genesis_hash: string }>
    >`SELECT rows_checked::integer, valid, broken_rows::integer, head_seq::integer, genesis_hash
         FROM public.platform_audit_verify()`;
    const count = await owner.platformAuditLog.count();

    expect(chain.valid).toBe(true);
    expect(chain.broken_rows).toBe(0);
    expect(chain.rows_checked).toBe(count);
    expect(chain.head_seq).toBe(count);

    // The first row links to the documented genesis digest, not to an arbitrary value: a
    // chain whose root is chosen by whoever writes row 1 can be re-rooted silently.
    const [first] = await owner.$queryRaw<Array<{ prev_hash: string; seq: number }>>`
      SELECT "prevHash" AS prev_hash, seq::integer FROM public."PlatformAuditLog" ORDER BY seq LIMIT 1`;
    expect(first.seq).toBe(1);
    expect(first.prev_hash).toBe(chain.genesis_hash);

    // seq is contiguous from 1, which is what makes head_seq a meaningful anchor.
    const gaps = await owner.$queryRaw<Array<{ missing: number }>>`
      SELECT count(*)::integer AS missing
        FROM generate_series(1, (SELECT max(seq) FROM public."PlatformAuditLog")) g
       WHERE NOT EXISTS (SELECT 1 FROM public."PlatformAuditLog" a WHERE a.seq = g)`;
    expect(gaps[0].missing).toBe(0);
  });

  it('4b. A2.3 - the backfill and the runtime writer agree, because both use the one SQL hash function', async () => {
    // (i) EVERY stored row, whatever its origin, matches a recomputation through
    //     platform_audit_hash over its own stored columns. This is the agreement that
    //     matters, and it is origin-independent.
    const mismatches = await owner.$queryRaw<Array<{ seq: number }>>`
      SELECT a.seq::integer FROM public."PlatformAuditLog" a
       WHERE a.hash IS DISTINCT FROM public.platform_audit_hash(
               a.seq::integer, a."adminId", a."adminName", a.action, a.target, a.details,
               a."beforeState", a."afterState", a.reason, a.ip, a."userAgent",
               a."stepUpUsed", a."createdAt", a."prevHash")`;
    expect(mismatches).toEqual([]);
    expect(await owner.platformAuditLog.count()).toBeGreaterThan(0);

    // (ii) Both writers really do call that one function. The trigger is checked in the
    //      catalog. The backfill is checked in the migration FILE, because once it has run
    //      there is no catalog object left to inspect - and because a freshly rebuilt
    //      database has no backfilled rows at all, so a test that sampled "one backfilled row
    //      and one runtime row" would pass while testing nothing. That is exactly what
    //      happened here: the sandbox was wiped, the database came back empty, and the old
    //      version of this test had nothing to compare.
    const triggerDef = await owner.$queryRaw<Array<{ def: string }>>`
      SELECT pg_get_functiondef(p.oid) AS def
        FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
       WHERE n.nspname = 'public' AND p.proname = 'platform_audit_chain_assign'`;
    expect(triggerDef).toHaveLength(1);
    expect(triggerDef[0].def).toContain('platform_audit_hash');

    const migration = fs.readFileSync(CHAIN_MIGRATION_FILE, 'utf8');
    const backfillStart = migration.indexOf('_r3_audit_pre');
    const backfillEnd = migration.indexOf('SET NOT NULL');
    expect(backfillStart).toBeGreaterThan(0);
    expect(backfillEnd).toBeGreaterThan(backfillStart);
    const backfill = migration.slice(backfillStart, backfillEnd);
    expect(backfill).toContain('platform_audit_hash');
    // ONE definition, so there is no second scheme for the two writers to disagree with.
    expect((migration.match(/CREATE (?:OR REPLACE )?FUNCTION public\.platform_audit_hash/g) ?? [])).toHaveLength(1);
    // And no TypeScript hash implementation exists to drift from the SQL one.
    const modulesDir = path.resolve(__dirname, '../../modules');
    const offenders: string[] = [];
    const walk = (directory: string): void => {
      for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
        const full = path.join(directory, entry.name);
        if (entry.isDirectory()) walk(full);
        else if (entry.name.endsWith('.ts') && /platform[-_]audit/i.test(entry.name)) {
          const text = fs.readFileSync(full, 'utf8');
          if (/createHash\(\s*['"]sha256['"]\s*\)/.test(text)) offenders.push(entry.name);
        }
      }
    };
    walk(modulesDir);
    expect(offenders).toEqual([]);
  });

  // ── 5: tamper detection, each rolled back ─────────────────────────────────
  it('5a. TAMPER: editing one old row makes verification name its exact seq', async () => {
    const seq = seededSeqs[2];
    expect(seq).toBeGreaterThan(0);

    const result = await tamperAndVerify(
      owner,
      `UPDATE public."PlatformAuditLog" SET action = action || '${MARKER}' WHERE seq = ${seq};`,
    );

    expect(result.verify.valid).toBe(false);
    expect(result.verify.brokenRows).toBe(1);
    expect(result.verify.firstBrokenSeq).toBe(seq);
    expect(result.verify.firstBrokenReason).toBe('hash-mismatch');
    expect(result.rolledBack).toBe(true);
    expect(result.headHashAfter).toBe(result.headHashBefore);
  });

  it('5b. TAMPER: forging a row\'s prevHash is reported as a broken LINK, not as a content change', async () => {
    const seq = seededSeqs[4];
    expect(seq).toBeGreaterThan(0);

    const result = await tamperAndVerify(
      owner,
      `UPDATE public."PlatformAuditLog" SET "prevHash" = repeat('0', 64) WHERE seq = ${seq};`,
    );

    expect(result.verify.valid).toBe(false);
    expect(result.verify.firstBrokenSeq).toBe(seq);
    // The verifier tests the link BEFORE the row's own digest on purpose: prevHash is itself
    // one of the hashed fields, so a content-first order would report this as hash-mismatch
    // and the operator would lose the more specific diagnosis. Measured, then fixed.
    expect(result.verify.firstBrokenReason).toBe('link-mismatch');
    expect(result.rolledBack).toBe(true);
  });

  it('5c. TAMPER: deleting a middle row is reported at its SUCCESSOR, with one fewer row checked', async () => {
    const total = await owner.platformAuditLog.count();
    const seq = seededSeqs[3];
    expect(seq).toBeGreaterThan(0);

    const result = await tamperAndVerify(owner, `DELETE FROM public."PlatformAuditLog" WHERE seq = ${seq};`);

    expect(result.verify.valid).toBe(false);
    expect(result.verify.rowsChecked).toBe(total - 1);
    expect(result.verify.firstBrokenSeq).toBe(seq + 1);
    expect(result.verify.firstBrokenReason).toBe('link-mismatch');
    expect(result.rolledBack).toBe(true);
  });

  it('5d. KNOWN LIMIT: deleting the LAST row leaves a valid shorter chain, and the alert anchor is what exposes it', async () => {
    // Stated rather than hidden. A hash chain cannot see the removal of its own tail: what
    // remains is still a perfectly valid, shorter chain. Only a superuser who has bypassed
    // the trigger can do it. The mitigation is an externally recorded head - which is why
    // platform_audit_verify returns head_seq/head_hash, why the console displays them, why
    // the CSV export carries seq, and why the api's verify route compares head_seq with the
    // highest auditSeq any PlatformAlert references.
    const total = await owner.platformAuditLog.count();
    const result = await tamperAndVerify(owner, `DELETE FROM public."PlatformAuditLog" WHERE seq = ${total};`);

    expect(result.verify.valid).toBe(true);
    expect(result.verify.brokenRows).toBe(0);
    expect(result.verify.headSeq).toBe(total - 1);
    expect(result.rolledBack).toBe(true);

    // The cross-check the api performs, expressed directly: an alert that cites a chain
    // position above the head proves rows are missing.
    const anchorSeq = total;
    const headAfterTailLoss = total - 1;
    expect(headAfterTailLoss < anchorSeq).toBe(true);
  });

  // ── 6: concurrency ────────────────────────────────────────────────────────
  it('6. A2.4 — 12 concurrent inserts get contiguous, duplicate-free chain positions', async () => {
    const adminId = `${MARKER}-parallel`;
    createdIds.push(adminId);
    const headBefore = await owner.$queryRaw<Array<{ head_seq: number | null }>>`
      SELECT head_seq::integer FROM public.platform_audit_verify()`;
    const start = headBefore[0].head_seq ?? 0;

    const inserts = Array.from({ length: 12 }, (_, index) =>
      owner.platformAuditLog.create({
        data: {
          adminId,
          adminName: MARKER,
          action: `${MARKER}:parallel-${index}`,
          target: null,
          details: { index } as object,
        },
        select: { seq: true },
      }),
    );
    const rows = await Promise.all(inserts);

    const seqs = rows.map((row) => row.seq).sort((a, b) => Number(a) - Number(b));
    // FOR UPDATE alone would fork the chain here: a concurrent inserter holds the lock on
    // the row that was head when its statement began, and the waiter proceeds with that
    // stale head. The transaction-scoped advisory lock taken first is what prevents it.
    expect(new Set(seqs).size).toBe(12);
    expect(seqs[0]).toBe(start + 1);
    expect(seqs[11]).toBe(start + 12);
    for (let i = 1; i < seqs.length; i += 1) expect(Number(seqs[i]) - Number(seqs[i - 1])).toBe(1);

    const [chain] = await owner.$queryRaw<Array<{ valid: boolean; broken_rows: number; head_seq: number }>>`
      SELECT valid, broken_rows::integer, head_seq::integer FROM public.platform_audit_verify()`;
    expect(chain.valid).toBe(true);
    expect(chain.broken_rows).toBe(0);
    expect(chain.head_seq).toBe(start + 12);
  });

  // ── 7: the shape A3.1 and A4.2 require of the two new tables ──────────────
  it('7. PlatformAlert and PlatformAdminDevice are platform tables: no gymId, no RLS, no message body', async () => {
    const gymColumns = await owner.$queryRaw<Array<{ table_name: string }>>`
      SELECT table_name FROM information_schema.columns
       WHERE table_schema = 'public'
         AND table_name IN ('PlatformAlert','PlatformAdminDevice')
         AND column_name = 'gymId'`;
    expect(gymColumns).toHaveLength(0);

    const rls = await owner.$queryRaw<Array<{ relname: string; relrowsecurity: boolean; relforcerowsecurity: boolean }>>`
      SELECT c.relname, c.relrowsecurity, c.relforcerowsecurity
        FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = 'public' AND c.relname IN ('PlatformAlert','PlatformAdminDevice')`;
    expect(rls).toHaveLength(2);
    for (const row of rls) {
      expect(row.relrowsecurity).toBe(false);
      expect(row.relforcerowsecurity).toBe(false);
    }

    // A3.1: no phone number, token, message body or raw provider error may be stored.
    const forbidden = await owner.$queryRaw<Array<{ column_name: string }>>`
      SELECT column_name FROM information_schema.columns
       WHERE table_schema = 'public'
         AND table_name IN ('PlatformAlert','PlatformAdminDevice')
         AND (column_name ~* 'phone|token|body|message|secret|password|errorText')`;
    expect(forbidden).toHaveLength(0);

    // A4.2: the device table stores a digest and normalised UA parts, never raw values.
    const deviceColumns = await owner.$queryRaw<Array<{ column_name: string }>>`
      SELECT column_name FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = 'PlatformAdminDevice'
       ORDER BY column_name`;
    const names = deviceColumns.map((row) => row.column_name);
    expect(names).toContain('deviceHash');
    expect(names).not.toContain('ip');
    expect(names).not.toContain('userAgent');
    // ipOnly is a boolean marker for "seeded from an attempt with no user agent", not an
    // address. Asserting its type is what keeps that true.
    const ipOnly = await owner.$queryRaw<Array<{ data_type: string }>>`
      SELECT data_type FROM information_schema.columns
       WHERE table_schema='public' AND table_name='PlatformAdminDevice' AND column_name='ipOnly'`;
    expect(ipOnly[0].data_type).toBe('boolean');
  });

  it('7b. every R3 function is SECURITY INVOKER, on purpose, and pins search_path', async () => {
    // The mirror image of the R2 contract, and the reason r1-platform-auth.spec.ts had to
    // narrow its sweep. A SECURITY DEFINER function runs with its OWNER's privileges, so a
    // definer owned by the migration owner would let any role that can execute it read the
    // audit log and compute chain digests regardless of its own grants. These ten are
    // invoker-privileged: what you can call them on is exactly what you could already read.
    const rows = await owner.$queryRaw<
      Array<{ fn: string; secdef: boolean; config: string | null }>
    >`
      SELECT p.proname AS fn, p.prosecdef AS secdef, array_to_string(p.proconfig, ' ') AS config
        FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
       WHERE n.nspname = 'public'
         AND (p.proname LIKE 'platform\\_audit\\_%' OR p.proname LIKE 'platform\\_device\\_%'
              OR p.proname IN ('platform_normalize_ua','platform_seed_admin_devices',
                               'platform_claim_alerts_for_retry'))
       ORDER BY 1`;
    expect(rows.length).toBe(10);
    for (const row of rows) {
      expect({ fn: row.fn, securityDefiner: row.secdef }).toEqual({ fn: row.fn, securityDefiner: false });
      expect(row.config ?? '').toContain('search_path');
    }
  });

  it('8. the runtime role can read both new tables and still sees zero Member rows', async () => {
    // Least privilege is unchanged by R3: the new platform tables are readable by the
    // runtime role, and that grant did not widen anything tenant-scoped.
    const alerts = await runtime.platformAlert.count();
    const devices = await runtime.platformAdminDevice.count();
    expect(typeof alerts).toBe('number');
    expect(typeof devices).toBe('number');

    const members = await runtime.member.count();
    expect(members).toBe(0);
  });
});

class Rollback extends Error {
  constructor(readonly payload: number) {
    super('rollback');
  }
}
