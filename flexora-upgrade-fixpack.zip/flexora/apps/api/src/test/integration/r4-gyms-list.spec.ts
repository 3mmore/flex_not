/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - R4.9, the gyms list: search, filters, sort and SERVER-side pagination at 25.
 *
 * BEFORE (measured): GET /platform/gyms took page, limit, search, plan and status - and no sort
 * at all. platform_list_gyms ended in a hard-coded `ORDER BY g."createdAt" DESC`, and the default
 * limit was 20, not the 25 the scope statement asks for.
 *
 * WHY SORTING HAD TO BE A MIGRATION. The list is served by a SECURITY DEFINER aggregate function
 * (PHASE R2 decision Q2), not by a Prisma findMany, so sorting in TypeScript would sort ONE PAGE
 * of 25 - page 2 would still hold rows that belong on page 1. The ORDER BY moved into the
 * function, as a CASE ladder rather than string concatenation, because p_sort arrives from a query
 * string and this function can see every tenant's rows: it is the worst possible place to build
 * SQL out of caller input. Test 5 attacks it directly.
 *
 * The tiebreaker (`g.id`) is not decoration either, and test 6 is the reason it is here: ordering
 * by a non-unique column leaves the order of ties to the planner, and with LIMIT/OFFSET a row can
 * then appear on two pages or on neither.
 */
import { Prisma } from '@prisma/client';
import {
  GYM_LIST_PAGE_SIZE,
  GYM_SORT_COLUMNS,
  GYM_SORT_DIRECTIONS,
} from '../../modules/platform/platform.controller';
import { makeGym, startConsoleHarness, API, type ConsoleHarness } from '../support/platform-console-harness';
import { assertWritesAreNotRlsProtected } from '../support/platform-console-harness';

jest.setTimeout(240_000);

const LABEL = 'gyms-list';

describe('R4.9 - the gyms list: search, filters, sort, server-side pagination at 25', () => {
  let h: ConsoleHarness;
  const gymIds: string[] = [];
  /** Names chosen so an alphabetical order is unambiguous and differs from creation order. */
  const names = ['Zeta Fitness', 'Alpha Gym', 'Middle Studio', 'Beta Athletics', 'Omega Club'];

  beforeAll(async () => {
    h = await startConsoleHarness(LABEL);
    // Created in an order that is NOT alphabetical, so sorting by name is observable.
    for (const name of names) {
      const gym = await makeGym(h.prisma, LABEL, { name });
      gymIds.push(gym.id);
    }
    // One suspended and one soft-deleted, so the status filter and the DELETED exclusion have
    // something to act on.
    const suspended = await makeGym(h.prisma, LABEL, { name: 'Suspended Place', status: 'SUSPENDED' });
    gymIds.push(suspended.id);
    const deleted = await makeGym(h.prisma, LABEL, { name: 'Deleted Place', status: 'DELETED' });
    gymIds.push(deleted.id);
  });

  afterAll(async () => {
    if (h) {
      for (const gymId of gymIds) {
        await h.prisma.subscription.deleteMany({ where: { gymId } }).catch(() => undefined);
        await h.prisma.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
        await h.prisma.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      }
      await h.prisma.gym.deleteMany({ where: { id: { in: gymIds } } }).catch(() => undefined);
      await h.close();
    }
  });

  /** Every gym this suite made that the list should currently show. */
  function ownedRows(body: { items: Array<{ id: string; name?: string }> }) {
    return (body.items ?? []).filter((item) => gymIds.includes(item.id));
  }

  it('1. the default page size is the 25 the scope statement asks for, and the response says what it did', async () => {
    const response = await h.get(`${API}/platform/gyms`);
    expect(response.status).toBe(200);
    expect(response.body.limit).toBe(GYM_LIST_PAGE_SIZE);
    expect(GYM_LIST_PAGE_SIZE).toBe(25);
    expect(response.body.page).toBe(1);
    expect(typeof response.body.total).toBe('number');
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeLessThanOrEqual(25);
    // Echoed so the console renders the active sort without keeping its own copy of the
    // whitelist, and so the defaults are visible rather than implied.
    expect(response.body.sort).toBe('createdAt');
    expect(response.body.dir).toBe('desc');
    expect(response.body.sortColumns).toEqual([...GYM_SORT_COLUMNS]);
  });

  it('2. sorting by name really re-orders the rows, in both directions', async () => {
    const asc = await h.get(`${API}/platform/gyms?sort=name&dir=asc&limit=100`);
    const desc = await h.get(`${API}/platform/gyms?sort=name&dir=desc&limit=100`);
    expect(asc.status).toBe(200);
    expect(desc.status).toBe(200);
    expect(asc.body.sort).toBe('name');
    expect(asc.body.dir).toBe('asc');

    const ascNames = ownedRows(asc.body).map((row) => String((row as { name?: string }).name ?? ''));
    const descNames = ownedRows(desc.body).map((row) => String((row as { name?: string }).name ?? ''));
    expect(ascNames.length).toBeGreaterThanOrEqual(5);
    // Sorted, and not merely "a different order": compare against a JS sort of the same values.
    expect(ascNames).toEqual([...ascNames].sort((a, b) => a.localeCompare(b)));
    expect(descNames).toEqual([...ascNames].reverse());
    // and the two directions are genuinely opposite, which is what would break if the CASE
    // ladder had a copy-paste error in one branch
    expect(ascNames[0]).not.toBe(descNames[0]);
  });

  it('3. every whitelisted sort column is accepted, and each direction of it', async () => {
    for (const sort of GYM_SORT_COLUMNS) {
      for (const dir of GYM_SORT_DIRECTIONS) {
        const response = await h.get(`${API}/platform/gyms?sort=${sort}&dir=${dir}&limit=5`);
        expect({ sort, dir, status: response.status }).toEqual({ sort, dir, status: 200 });
        expect(response.body.sort).toBe(sort);
        expect(response.body.dir).toBe(dir);
      }
    }
  });

  it('4. an unknown sort column or direction is a 400, not a silent fallback', async () => {
    // A silent fallback would let the console believe it is showing one order while the server
    // returns another. Refusing is the honest answer.
    for (const query of ['sort=taxId', 'sort=password', 'sort=ownerPhone', 'dir=sideways', 'dir=ASC;DROP']) {
      const response = await h.get(`${API}/platform/gyms?${query}`);
      expect({ query, status: response.status }).toEqual({ query, status: 400 });
    }
  });

  it('5. ATTACK: SQL injected through the sort parameter is refused, and the table survives', async () => {
    // The controller whitelist stops these with a 400. The database-side CASE ladder is the
    // second guarantee, and it is the one that holds if a future caller forgets the first - so
    // the attack is attempted through both layers, and the table is checked afterwards rather
    // than assumed to be fine.
    const attacks = [
      "name; DROP TABLE public.\"Gym\"; --",
      "name) DESC; DELETE FROM public.\"Gym\"; --",
      "(SELECT password FROM public.\"PlatformAdmin\" LIMIT 1)",
      "1; SELECT pg_sleep(5)",
    ];
    for (const sort of attacks) {
      const response = await h.get(`${API}/platform/gyms?sort=${encodeURIComponent(sort)}`);
      expect({ sort: sort.slice(0, 24), status: response.status }).toEqual({ sort: sort.slice(0, 24), status: 400 });
    }

    // And the same strings handed straight to the function, bypassing the controller entirely:
    // this is the database-side guarantee on its own. It must not error, must not sort by
    // anything, and must not touch the table.
    const direct = await h.prisma.$queryRaw<Array<{ n: number }>>(
      Prisma.sql`SELECT count(*)::integer AS n FROM public.platform_list_gyms(
        NULL::text, NULL::text, NULL::text, 5::integer, 0::integer,
        ${'name; DROP TABLE public."Gym"; --'}::text, 'asc'::text)`,
    );
    expect(direct[0].n).toBeGreaterThan(0);
    const stillThere = await h.prisma.gym.count({ where: { id: { in: gymIds } } });
    expect(stillThere).toBe(gymIds.length);
    // No administrator credential left through the injected expression either.
    const admins = await h.prisma.platformAdmin.count();
    expect(admins).toBeGreaterThan(0);
  });

  it('6. pagination is deterministic: pages do not overlap and nothing is skipped', async () => {
    // This is what the g.id tiebreaker buys. With a small page size and a sort column that ties
    // (every gym here has the same status), a planner is free to order ties differently between
    // two executions, and OFFSET pagination then repeats or drops rows. Asking for the same page
    // twice and for consecutive pages is how that shows up.
    const size = 2;
    const readPage = async (page: number) => {
      const response = await h.get(`${API}/platform/gyms?sort=status&dir=asc&page=${page}&limit=${size}`);
      expect(response.status).toBe(200);
      return (response.body.items ?? []).map((item: { id: string }) => item.id);
    };

    const pageOneA = await readPage(1);
    const pageOneB = await readPage(1);
    const pageTwo = await readPage(2);
    const pageThree = await readPage(3);

    expect(pageOneA).toHaveLength(size);
    // The same page asked for twice is the same rows in the same order.
    expect(pageOneB).toEqual(pageOneA);
    // Consecutive pages share nothing.
    expect(pageOneA.filter((id: string) => pageTwo.includes(id))).toEqual([]);
    expect(pageTwo.filter((id: string) => pageThree.includes(id))).toEqual([]);

    // And walking every page collects each of this suite's gyms exactly once, which is the
    // property an administrator scrolling the console actually depends on.
    const seen: string[] = [];
    for (let page = 1; page <= 40; page += 1) {
      const ids = await readPage(page);
      if (!ids.length) break;
      seen.push(...ids);
    }
    const mine = seen.filter((id) => gymIds.includes(id));
    // DELETED gyms are excluded from the default list (R2 decision Q1), so expect all but that one.
    expect(mine.length).toBe(gymIds.length - 1);
    expect(new Set(mine).size).toBe(mine.length);
  });

  it('7. search and the status/plan filters still work, and DELETED stays out of the default list', async () => {
    const byName = await h.get(`${API}/platform/gyms?search=Zeta&limit=100`);
    expect(byName.status).toBe(200);
    expect(ownedRows(byName.body).map((row) => (row as { name?: string }).name)).toContain('Zeta Fitness');

    const bySlug = await h.get(`${API}/platform/gyms?search=r4-${LABEL}&limit=100`);
    expect(bySlug.status).toBe(200);
    expect(ownedRows(bySlug.body).length).toBeGreaterThanOrEqual(6);

    const suspended = await h.get(`${API}/platform/gyms?status=SUSPENDED&limit=100`);
    expect(suspended.status).toBe(200);
    const suspendedNames = ownedRows(suspended.body).map((row) => (row as { name?: string }).name);
    expect(suspendedNames).toContain('Suspended Place');
    expect(suspendedNames).not.toContain('Zeta Fitness');

    // R2 decision Q1, re-asserted because R4 touched this function: a soft-deleted gym leaves
    // the default list but is still reachable by an explicit filter, so it can be restored.
    const defaultList = await h.get(`${API}/platform/gyms?limit=100`);
    expect(ownedRows(defaultList.body).map((row) => (row as { name?: string }).name)).not.toContain('Deleted Place');
    const explicit = await h.get(`${API}/platform/gyms?status=DELETED&limit=100`);
    expect(ownedRows(explicit.body).map((row) => (row as { name?: string }).name)).toContain('Deleted Place');
  });

  it('8. R2 regression: the list still carries no credential column and no member PII', async () => {
    // R4 changed this function's signature and its ORDER BY. The allowlist it returns is the
    // R2 decision Q2 contract, and a migration is exactly the kind of change that can widen it
    // by accident - so it is re-asserted here rather than left to the crawl alone.
    const response = await h.get(`${API}/platform/gyms?limit=100`);
    const row = ownedRows(response.body)[0] as Record<string, unknown> | undefined;
    expect(row).toBeTruthy();
    const keys = Object.keys(row as Record<string, unknown>);
    for (const forbidden of ['taxId', 'password', 'passwordHash', 'whatsappBotToken', 'theme', 'members']) {
      expect({ forbidden, present: keys.includes(forbidden) }).toEqual({ forbidden, present: false });
    }
    // Scoped to THIS suite's gyms, and the reason is a measured mistake: the first version
    // scanned every row in the response, which includes gyms other fixtures created, and a
    // fourteen-digit run in one of those failed an assertion about MY rows. The calibrated
    // whole-response scan is the PII crawl's job - it uses member-scoped patterns precisely
    // because blanket ones false-positive on approved columns - and it covers this route.
    const mine = ownedRows(response.body);
    expect(mine.length).toBeGreaterThan(0);

    // the gym's own business contact is ALLOWED (R2 decision Q2), and asserting only absences
    // would let a future change strip it silently - so assert the allowance first, explicitly
    expect(mine[0]).toHaveProperty('phone');
    expect(mine[0]).toHaveProperty('email');

    // THEN scan for person-shaped data with the approved contact columns removed. This is the
    // calibration the PII crawl uses and the reason it does not false-positive: an Egyptian
    // mobile pattern matches the gym's own business phone (measured - the fixture phone
    // 01000000006 matches /01[0125]\d{8}/ exactly), so a blanket scan of an ALLOWED response
    // fails on data that is supposed to be there. What must never appear is member data, and
    // that is what is left to look for once the allowlist is taken out.
    const APPROVED_CONTACT = ['phone', 'email', 'ownerName', 'ownerPhone', 'address', 'logo', 'accentColor'];
    const withoutApproved = mine.map((row) => {
      const copy: Record<string, unknown> = { ...(row as Record<string, unknown>) };
      for (const key of APPROVED_CONTACT) delete copy[key];
      return copy;
    });
    const serialised = JSON.stringify(withoutApproved);
    expect(serialised).not.toMatch(/\+?01[0125]\d{8}/);
    expect(serialised).not.toMatch(/\b\d{14}\b/);
    // and no member-shaped object rode along inside the row
    expect(serialised).not.toMatch(/"members?"\s*:/i);
    expect(serialised).not.toMatch(/\b(mobile|nationalId|birthDate)\b/i);
  });

  it('9. R4.22 - the list is refused without a console session', async () => {
    const anonymous = await h.anonymous('GET', `${API}/platform/gyms`);
    expect([401, 403, 404]).toContain(anonymous.status);
    expect(anonymous.status).not.toBe(200);
  });

  it('10. the function R4 replaced keeps the R2 contract: definer, STABLE, pinned search_path, no PUBLIC grant', async () => {
    // Changing a SECURITY DEFINER function is how a privilege posture quietly changes, so the
    // catalog is re-read after the migration rather than trusted.
    const rows = await h.prisma.$queryRaw<
      Array<{ ident: string; secdef: boolean; vol: string; config: string | null; has_public: number; has_app: number }>
    >`
      SELECT pg_get_function_identity_arguments(p.oid) AS ident,
             p.prosecdef AS secdef,
             p.provolatile::text AS vol,
             array_to_string(p.proconfig, ' ') AS config,
             (SELECT count(*) FROM aclexplode(coalesce(p.proacl, acldefault('f', p.proowner))) a WHERE a.grantee = 0)::integer AS has_public,
             (SELECT count(*) FROM aclexplode(coalesce(p.proacl, acldefault('f', p.proowner))) a
               WHERE a.grantee = (SELECT oid FROM pg_roles WHERE rolname = 'flexora_app'))::integer AS has_app
        FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
       WHERE n.nspname = 'public' AND p.proname = 'platform_list_gyms'`;

    // exactly one overload: the five-argument form was dropped, because leaving it would make a
    // five-argument call ambiguous now that the new parameters have defaults
    expect(rows).toHaveLength(1);
    // pg_get_function_identity_arguments returns NAMED arguments, so this is the seven
    // parameters of the R4 signature and not the five of the R2 one. The first version of this
    // assertion expected bare types and was simply wrong about the catalog function.
    expect(rows[0].ident).toBe(
      'p_status text, p_search text, p_tier text, p_limit integer, p_offset integer, p_sort text, p_dir text',
    );
    expect(rows[0].secdef).toBe(true);
    expect(rows[0].vol).toBe('s');
    expect(rows[0].config).toContain('search_path=pg_catalog, public');
    expect(rows[0].has_public).toBe(0);
    expect(rows[0].has_app).toBe(1);
  });

  it('R4 - the tables this suite writes have no row-level security, so its green result cannot depend on connecting as a superuser', async () => {
    // Every jest suite here connects as `flexora`, a SUPERUSER, which bypasses row-level
    // security outright. That is how the platform subscription writes stayed broken in
    // production for two phases while every suite was green - see
    // r4-runtime-role-writes.spec.ts, which boots the app as flexora_app instead.
    //
    // This is the complement the owner asked for: a statement of which tables THIS suite
    // writes, and a check that none of them is RLS-protected, so there is no policy for the
    // superuser to bypass and the result means the same thing in production. The helper also
    // asserts that Subscription IS protected, so the check cannot pass vacuously.
    //
    // this suite only READS through the api; the one table it creates fixtures in is Gym. Fixture rows created directly through the superuser client are listed too where
    // they matter; what is NOT claimed here is anything about the api's own write privileges,
    // which is what the runtime-role suite covers.
    await assertWritesAreNotRlsProtected(h.prisma as never, ['Gym']);
  });
});
