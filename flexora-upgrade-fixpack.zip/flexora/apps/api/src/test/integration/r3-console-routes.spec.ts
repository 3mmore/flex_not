/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 - R3.7, R3.8, R3.10, R3.11 proved against the running api.
 *
 * BEFORE (work/r3-evidence/00-before.log):
 *   B5  GET /platform/audit-log accepted page, limit, adminId and action, and nothing else.
 *   B6  exactly one file in the whole api emitted text/csv (payroll), and there were zero
 *       audit export routes and zero references to a hash chain in product source.
 *   B7  the console's audit page was 24 lines with no filter, search, csv, verify, download
 *       or date control - grep returned 0 for all six.
 *   B8  zero owner-channel calls in any of the three files that implement the five alert
 *       events, so none of them could alert.
 *
 * Everything below is asserted by making the request and, where the claim is about what was
 * RECORDED, by reading the row back out of the database rather than trusting the response.
 * No secret value is printed anywhere in this file.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';
import { AUDIT_CSV_COLUMNS, AUDIT_EXPORT_MAX_ROWS } from '../../modules/platform/platform.controller';
import { assertWritesAreNotRlsProtected } from '../support/platform-console-harness';

const ADMIN_HOST = 'localhost';
const API = `/${API_GLOBAL_PREFIX}`;
const EMAIL = 'r3-routes-admin@example.com';
const VICTIM_EMAIL = 'r3-routes-victim@example.com';
// Built from parts so no credential-shaped NAME is assigned a literal.
const PASSWORD = ['R3Routes', 'password', '0'.repeat(6)].join('-');
const REASON = 'R3 route spec needs a reason of at least eight characters';
const RUN_ID = `r3${Date.now().toString(36)}`;
/** A recognisable agent string, so the recorded value can be asserted on exactly. */
const SPEC_USER_AGENT =
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 R3RouteSpec/1.0';

let app: INestApplication;
let prisma: PrismaService;
let cookie = '';
let adminId = '';
let totpSecret = '';
const createdGymIds: string[] = [];
const createdAdminIds: string[] = [];
const createdAlertIds: string[] = [];

function cookiesOf(response: request.Response): string[] {
  const raw = response.headers['set-cookie'];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]);
}
function jar(response: request.Response): string {
  return cookiesOf(response).join('; ');
}
function csrfOf(value: string): string {
  return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
}
function adopt(response: request.Response): void {
  const fresh = jar(response);
  if (fresh.includes('flx_platform_token=')) cookie = fresh;
}

async function call(
  method: string,
  url: string,
  body?: unknown,
  options: { anonymous?: boolean } = {},
): Promise<{ status: number; body: any; headers: any; text: string }> {
  const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
    .set('Host', ADMIN_HOST)
    // supertest sends no User-Agent unless one is set, and a missing header is honestly
    // stored as NULL. Setting a real one is what makes "the row records the user agent"
    // a meaningful assertion rather than a tautology about a fixture that sent nothing.
    .set('User-Agent', SPEC_USER_AGENT);
  if (!options.anonymous) {
    req.set('Cookie', cookie).set('x-csrf-token', csrfOf(cookie));
  }
  const response: request.Response = body === undefined ? await req : await req.send(body as object);
  adopt(response);
  return { status: response.status, body: response.body, headers: response.headers, text: response.text };
}

async function reStepUp(): Promise<void> {
  // FIXTURE reset of the replay counter, not a weakened control: the replay rule stays in
  // force for every call below and is asserted by r1-platform-auth.spec.ts.
  await prisma.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
  const response = await call('POST', `${API}/platform/auth/step-up`, {
code: totpTokenAt(totpSecret),
});
  expect(response.status).toBe(200);
}

async function makeGym(label: string): Promise<string> {
  const gym = await prisma.gym.create({
    data: {
      name: `R3 ${label} ${RUN_ID}`,
      slug: `r3-${label}-${RUN_ID}`,
      email: `r3-${label}-${RUN_ID}@test.local`,
      phone: '01000000003',
      status: 'ACTIVE' as any,
    },
  });
  createdGymIds.push(gym.id);
  return gym.id;
}

/** Delivery is fire-and-forget by design (A3.3), so give it a moment before reading. */
const settle = (ms = 400) => new Promise((resolve) => setTimeout(resolve, ms));

describe('R3.7/R3.8/R3.10/R3.11 - the console audit, verify, export and alert routes', () => {
  beforeAll(async () => {
    process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix(API_GLOBAL_PREFIX);
    app.use(cookieParser());
    app.useGlobalFilters(new HttpExceptionFilter());
    app.useGlobalPipes(// PHASE R4: forbidNonWhitelisted matches main.ts. Every harness in this repo omitted it,
    // so tests accepted request bodies the production api answers with 400 - found when the
    // R4 browser proof drove the REAL api and step-up refused the password these specs send.
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    await app.init();
    prisma = app.get(PrismaService);

    // Deterministic starting state for the verify route. An alert may cite a chain position
    // that no longer exists only if audit rows were removed - which in this workspace happens
    // when a fixture cleanup uses the documented superuser bypass. Leaving one behind makes
    // the tail-truncation anchor fire before the test has done anything, so the sweep that
    // a future retention job would own is done here explicitly, and the test then proves the
    // anchor works by creating an anchor of its own.
    await prisma.$executeRaw`
      WITH head AS (SELECT head_seq FROM public.platform_audit_verify())
      DELETE FROM public."PlatformAlert" a
       USING head
       WHERE a."auditSeq" IS NOT NULL AND a."auditSeq" > head.head_seq`;

    await prisma.platformLoginAttempt.deleteMany({});
    await prisma.platformSession.deleteMany({ where: { admin: { email: EMAIL } } }).catch(() => undefined);
    await prisma.platformAdmin.deleteMany({ where: { email: { in: [EMAIL, VICTIM_EMAIL] } } });

    const admin = await prisma.platformAdmin.create({
      data: {
        email: EMAIL,
        name: 'R3 routes',
        role: 'PLATFORM_ADMIN',
        passwordHash: await hashPassword(PASSWORD),
        status: 'ACTIVE',
      },
    });
    adminId = admin.id;

    const login = await request(app.getHttpServer())
      .post(`${API}/platform/auth/login`)
      .set('Host', ADMIN_HOST)
      .send({ email: EMAIL, password: PASSWORD });
    expect(login.status).toBe(201);
    cookie = jar(login);

    const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
    expect(begin.status).toBe(200);
    totpSecret = begin.body.secret as string;
    const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(totpSecret) });
    expect(done.status).toBe(200);
    const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(totpSecret, Date.now() + 30_000),
    });
    expect(stepUp.status).toBe(200);
  }, 240_000);

  afterAll(async () => {
    if (prisma) {
      // Alerts FIRST, then the audit rows they cite. Order matters and this was measured:
      // an earlier version of this cleanup deleted the audit rows (through the documented
      // superuser bypass) and left three GYM_DELETED alerts citing seq 32 and 34 behind, so
      // the next run's verify route reported tailTruncated against a head of 26. That is the
      // anchor working exactly as designed - the fixture was the thing out of step with it.
      // The run raises alerts for gyms deleted by tests that are not the alert test, so the
      // sweep is by target as well as by id and by dedupe key.
      await prisma.platformAlert
        .deleteMany({
          where: {
            OR: [
              ...(createdAlertIds.length ? [{ id: { in: createdAlertIds } }] : []),
              { dedupeKey: { contains: RUN_ID } },
              ...(createdGymIds.length ? [{ targetId: { in: createdGymIds } }] : []),
              ...(createdAdminIds.length ? [{ targetId: { in: createdAdminIds } }] : []),
              { type: 'GYM_DELETED', targetKind: 'audit' },
            ],
          },
        })
        .catch(() => undefined);
      for (const gymId of createdGymIds) {
        await prisma.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
        await prisma.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      }
      await prisma.gym.deleteMany({ where: { id: { in: createdGymIds } } }).catch(() => undefined);
      const auditAdmins = [adminId, ...createdAdminIds];
      await prisma.platformSession.deleteMany({ where: { adminId: { in: auditAdmins } } }).catch(() => undefined);
      await prisma.platformRecoveryCode.deleteMany({ where: { adminId: { in: auditAdmins } } }).catch(() => undefined);
      // PHASE R3 / A1=a - the audit log is append-only for every role, so fixture cleanup
      // uses the one documented superuser bypass instead of a swallowed deleteMany.
      // A5.1 - audit rows are left in place. See the note in r3-audit-chain.spec.ts.
      await prisma.platformAdmin.deleteMany({ where: { id: { in: auditAdmins } } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('R3.7 - the audit list now filters by action, target, search and date range, and paginates with a total', async () => {
    const all = await call('GET', `${API}/platform/audit-log?limit=5`);
    expect(all.status).toBe(200);
    expect(Array.isArray(all.body.rows)).toBe(true);
    expect(typeof all.body.total).toBe('number');
    expect(all.body.rows.length).toBeLessThanOrEqual(5);
    expect(all.body.chainHead).not.toBeNull();

    const byAction = await call('GET', `${API}/platform/audit-log?action=admin:login&limit=100`);
    expect(byAction.status).toBe(200);
    expect(byAction.body.rows.length).toBeGreaterThan(0);
    for (const row of byAction.body.rows) expect(row.action).toBe('admin:login');

    const bySearch = await call('GET', `${API}/platform/audit-log?search=gym:&limit=100`);
    expect(bySearch.status).toBe(200);
    for (const row of bySearch.body.rows) {
      // Exactly the columns buildAuditWhere searches - action, target, adminName, reason - and
      // deliberately not details. Adding details was tried and reverted: the server cannot
      // match on it, so accepting it here would let a wrong result through.
      const haystack = `${row.action} ${row.target ?? ''} ${row.adminName} ${row.reason ?? ''}`;
      expect(haystack.toLowerCase()).toContain('gym:');
    }

    // A date range that excludes everything returns an empty page, not an error and not
    // the whole log: silently widening a range an operator narrowed would export more
    // history than they asked for.
    const future = new Date(Date.now() + 86_400_000).toISOString();
    const none = await call('GET', `${API}/platform/audit-log?from=${encodeURIComponent(future)}`);
    expect(none.status).toBe(200);
    expect(none.body.rows).toHaveLength(0);
    expect(none.body.total).toBe(0);

    const badDate = await call('GET', `${API}/platform/audit-log?from=not-a-date`);
    expect(badDate.status).toBe(400);
  });

  it('R3.8 - the verify route reports the chain, and cross-checks the head against the highest alerted seq', async () => {
    const verify = await call('GET', `${API}/platform/audit-log/verify`);
    expect(verify.status).toBe(200);
    expect(verify.body.chainValid).toBe(true);
    expect(verify.body.valid).toBe(true);
    expect(verify.body.brokenRows).toBe(0);
    expect(verify.body.rowsChecked).toBeGreaterThan(0);
    expect(verify.body.headSeq).toBe(verify.body.rowsChecked);
    expect(verify.body.headHash).toMatch(/^[0-9a-f]{64}$/);
    expect(verify.body.genesisHash).toMatch(/^[0-9a-f]{64}$/);
    // Asserted as a CHANGE, not as a global absolute. Whether some other suite happens to
    // have an alert citing a seq above the head is not this test's business, and asserting
    // false made the test fail under parallel load for a reason that was not a defect. What
    // is under test is that creating an anchor above the head flips the verdict.
    const tailBefore = verify.body.tailTruncated;
    expect(typeof tailBefore).toBe('boolean');

    // The documented limit of a hash chain is that losing the TAIL still verifies. The
    // anchor is an alert that cites a chain position above the head. Create one and the
    // route must stop claiming the log is intact.
    const anchorSeq = verify.body.headSeq + 50;
    const anchor = await prisma.platformAlert.create({
      data: {
        type: 'GYM_DELETED',
        severity: 'warning',
        targetKind: 'audit',
        auditSeq: anchorSeq,
        status: 'SENT',
        dedupeKey: `${RUN_ID}-anchor`,
      },
    });
    createdAlertIds.push(anchor.id);

    const after = await call('GET', `${API}/platform/audit-log/verify`);
    expect(after.status).toBe(200);
    expect(after.body.tailTruncated).toBe(true);
    expect(tailBefore).toBe(false);
    // The chain itself is still consistent - what changed is that rows are missing from the
    // end. Two different failures, reported as two different fields.
    expect(after.body.chainValid).toBe(true);
    expect(after.body.valid).toBe(false);
    expect(after.body.maxAlertedSeq).toBe(anchorSeq);
  });

  it('R3.7 - the CSV export writes exactly the allowlisted columns, quotes per RFC 4180 and neutralises formulas', async () => {
    // A reason beginning with '=' is the injection case: a spreadsheet would evaluate it.
    const gymId = await makeGym('csv');
    await reStepUp();
    const deleted = await call('DELETE', `${API}/platform/gyms/${gymId}`, { reason: '=SUM(A1:A9) leaked' });
    expect([200, 201]).toContain(deleted.status);

    const exportResponse = await call('GET', `${API}/platform/audit-log/export?action=gym:delete-soft`);
    expect(exportResponse.status).toBe(200);
    expect(String(exportResponse.headers['content-type'])).toContain('text/csv');
    expect(String(exportResponse.headers['content-disposition'])).toMatch(/attachment; filename="flexora-platform-audit-\d{8}\.csv"/);
    expect(exportResponse.headers['x-flexora-audit-truncated']).toBe('false');

    const text: string = exportResponse.text;
    const lines = text.split('\r\n').filter((line) => line.length > 0);
    // Hard-coded on purpose. The first version of this assertion compared the header against
    // AUDIT_CSV_COLUMNS itself, which is tautological: the mutation cycle proved it by adding a
    // column to the constant and watching this test still pass. The allowlist is only a control
    // if the expectation lives somewhere the product cannot change by accident, so it lives
    // here - and the cross-check below means widening the export is a deliberate, visible act
    // that requires editing this spec too.
    const EXPECTED_HEADER = [
      'seq', 'createdAt', 'adminId', 'adminName', 'action', 'target', 'reason', 'ip',
      'userAgent', 'stepUpUsed', 'details', 'beforeState', 'afterState', 'hash', 'prevHash',
    ];
    expect(lines[0].split(',')).toEqual(EXPECTED_HEADER);
    expect(lines[0]).toBe(EXPECTED_HEADER.join(','));
    expect([...AUDIT_CSV_COLUMNS]).toEqual(EXPECTED_HEADER);

    const injected = lines.find((line) => line.includes('SUM(A1:A9)'));
    expect(injected).toBeTruthy();
    // The cell no longer begins with '=', which is what stops Excel and LibreOffice from
    // evaluating it. It contains no comma and no quote, so RFC 4180 does not require it to
    // be wrapped - asserting quotes here would be asserting something the RFC does not say.
    expect(injected).toMatch(/,'=SUM\(A1:A9\) leaked,/);
    expect(injected).not.toMatch(/,=SUM/);

    // A value that DOES need quoting: a leading formula character and an embedded comma.
    const commaGym = await makeGym('csv-comma');
    await reStepUp();
    const commaDelete = await call('DELETE', `${API}/platform/gyms/${commaGym}`, {
      reason: '=1+1, injected',
    });
    expect([200, 201]).toContain(commaDelete.status);
    const commaExport = await call('GET', `${API}/platform/audit-log/export?target=${commaGym}`);
    expect(commaExport.status).toBe(200);
    const commaLine = commaExport.text.split('\r\n').find((line: string) => line.includes('1+1'));
    expect(commaLine).toBeTruthy();
    expect(commaLine).toContain(`"'=1+1, injected"`);

    expect(Number(exportResponse.headers['x-flexora-audit-rows'])).toBe(lines.length - 1);
    expect(Number(exportResponse.headers['x-flexora-audit-rows'])).toBeLessThanOrEqual(AUDIT_EXPORT_MAX_ROWS);
  });

  it('R3.6 - a mutation records beforeState/afterState, a first-class reason, ip, user agent and step-up', async () => {
    const gymId = await makeGym('suspend');
    await reStepUp();
    const suspended = await call('POST', `${API}/platform/gyms/${gymId}/suspend`, { reason: REASON });
    expect([200, 201]).toContain(suspended.status);

    // Read the row from the database: the api's own answer is not the evidence.
    const row = await prisma.platformAuditLog.findFirst({
      where: { action: 'gym:suspend', target: gymId },
      orderBy: { seq: 'desc' },
    });
    expect(row).not.toBeNull();
    expect(row!.reason).toBe(REASON);
    expect(row!.ip).toBeTruthy();
    expect(row!.userAgent).toBe(SPEC_USER_AGENT);
    expect(row!.stepUpUsed).toBe(true);
    expect(row!.seq).not.toBeNull();
    expect(row!.hash).toMatch(/^[0-9a-f]{64}$/);
    expect(row!.beforeState).toEqual({ status: 'ACTIVE' });
    expect(row!.afterState).toEqual({ status: 'SUSPENDED' });
    // R3.6: state transitions carry no personal data at all.
    const stateText = JSON.stringify({ ...row!.beforeState, ...row!.afterState });
    expect(stateText).not.toMatch(/@|\+?\d{7,}/);
  });

  it('R3.11 - deleting a gym raises GYM_DELETED, referencing the audit row by chain position', async () => {
    const gymId = await makeGym('alert-delete');
    await reStepUp();
    const deleted = await call('DELETE', `${API}/platform/gyms/${gymId}`, { reason: REASON });
    expect([200, 201]).toContain(deleted.status);
    const auditSeq = deleted.body?.seq ?? null;

    await settle();
    const alerts = await prisma.platformAlert.findMany({
      where: { type: 'GYM_DELETED', targetId: gymId },
      orderBy: { createdAt: 'desc' },
    });
    expect(alerts.length).toBeGreaterThan(0);
    createdAlertIds.push(...alerts.map((row) => row.id));
    // A3.7 - the alert points at the row that recorded the deletion.
    expect(alerts[0].auditSeq).toBe(auditSeq);
    expect(['PENDING', 'SENT', 'FAILED', 'NO_CHANNEL']).toContain(alerts[0].status);
    // A3.1 - nothing about the gym or the owner is copied into the alert row.
    const serialised = JSON.stringify(alerts[0]);
    expect(serialised).not.toContain(REASON);
    expect(serialised).not.toMatch(/@test\.local/);
  });

  it('R3.11 - granting a subscription raises SUBSCRIPTION_GRANTED', async () => {
    const gymId = await makeGym('alert-grant');
    await prisma.subscription.create({
      data: { gymId, tier: 'BASIC' as any, status: 'ACTIVE' as any, currentPeriodEnd: new Date() } as any,
    }).catch(() => undefined);
    await reStepUp();
    // PHASE R4 (R4.11) changed this contract: the reason was already required in spirit but is
    // now enforced, and the route additionally requires an idempotency key and the end date the
    // administrator was quoted - which is what lets the modal show the date the server will
    // actually write. The date is taken from the quote route, so this is a faithful client
    // rather than a second implementation of the formula.
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=3`);
    expect(quote.status).toBe(200);
    const granted = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PRO',
      months: 3,
      reason: REASON,
      idempotencyKey: `r3-routes-grant-${RUN_ID}`,
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    });
    expect([200, 201]).toContain(granted.status);

    await settle();
    const alerts = await prisma.platformAlert.findMany({
      where: { type: 'SUBSCRIPTION_GRANTED', targetId: gymId },
    });
    expect(alerts.length).toBeGreaterThan(0);
    createdAlertIds.push(...alerts.map((row) => row.id));
    expect(alerts[0].auditSeq).toBe(granted.body?.seq ?? null);

    const row = await prisma.platformAuditLog.findFirst({
      where: { action: 'gym:grant-subscription', target: gymId },
      orderBy: { seq: 'desc' },
    });
    expect(row!.afterState).toMatchObject({ tier: 'PRO', status: 'ACTIVE', months: 3 });
    expect(row!.beforeState).toBeTruthy();
  });

  it('R3.11 - removing an administrator raises ADMIN_REMOVED', async () => {
    const victim = await prisma.platformAdmin.create({
      data: {
        email: VICTIM_EMAIL,
        name: 'R3 victim',
        role: 'PLATFORM_ADMIN',
        passwordHash: await hashPassword(PASSWORD),
        status: 'ACTIVE',
      },
    });
    createdAdminIds.push(victim.id);
    await reStepUp();

    const removed = await call('DELETE', `${API}/platform/admins/${victim.id}`);
    expect([200, 201]).toContain(removed.status);

    await settle();
    const alerts = await prisma.platformAlert.findMany({
      where: { type: 'ADMIN_REMOVED', targetId: victim.id },
    });
    expect(alerts.length).toBeGreaterThan(0);
    createdAlertIds.push(...alerts.map((row) => row.id));
    expect(alerts[0].auditSeq).toBe(removed.body?.seq ?? null);
    expect(alerts[0].severity).toBe('warning');
  });

  it('R3.10 - the alert list is paginated and reports the channel state so a missing channel is visible', async () => {
    const list = await call('GET', `${API}/platform/alerts?limit=5`);
    expect(list.status).toBe(200);
    expect(Array.isArray(list.body.rows)).toBe(true);
    expect(list.body.rows.length).toBeLessThanOrEqual(5);
    expect(typeof list.body.total).toBe('number');
    expect(list.body.channel).toBeDefined();
    expect(typeof list.body.channel.configured).toBe('boolean');
    expect(Array.isArray(list.body.channel.missing)).toBe(true);
    // A3.4 - variable NAMES only, never a value.
    for (const name of list.body.channel.missing) expect(name).toMatch(/^[A-Z0-9_]+$/);

    // The whole first page is scanned, not a subset. Scoping this to "our" alerts was tried
    // and reverted: listForConsole deliberately does not return dedupeKey, so filtering on it
    // would have produced an empty set and a vacuous assertion. The root cause of the parallel
    // failure was another suite writing a 13-digit decimal Date.now() into a targetId, which
    // looks exactly like an Egyptian mobile; that fixture is base 36 now, so scanning
    // everything is both stronger and safe.
    // UUID-shaped values are removed before scanning, and this was measured rather than assumed:
    // the assertion flaked about one run in three, and querying the table showed ZERO rows with a
    // ten-digit run in targetId, dedupeKey or errorCode. The offender was the alert's own `id` -
    // a random UUID, in which a run of ten consecutive decimal digits occurs roughly once in a
    // thousand. A UUID is not a phone number, and the PII crawl scopes its person-data patterns to
    // member data for exactly this reason. Stripping the identifier shape keeps the check honest
    // about what it is looking for instead of failing on randomness.
    const withoutUuids = JSON.stringify(list.body.rows).replace(
      /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi,
      '<uuid>',
    );
    expect(withoutUuids).not.toMatch(/\+?\d{10,}/);
    for (const row of list.body.rows) {
      expect(row).not.toHaveProperty('body');
      expect(row).not.toHaveProperty('message');
      expect(row).not.toHaveProperty('phone');
    }
  });

  it('R3.10 - re-queueing needs step-up, refuses a SENT alert, and is itself audited', async () => {
    const alert = await prisma.platformAlert.create({
      data: {
        type: 'GYM_DELETED',
        severity: 'info',
        targetKind: 'platform',
        status: 'NO_CHANNEL',
        errorCode: 'channel_not_configured',
        dedupeKey: `${RUN_ID}-requeue`,
      },
    });
    createdAlertIds.push(alert.id);

    // Without a fresh step-up the route must refuse. The exact status is whatever the
    // step-up guard returns, and the point is that it is NOT 200 and the row did not change.
    await prisma.platformSession.updateMany({
      where: { adminId, revokedAt: null },
      data: { stepUpAt: null, stepUpExpiresAt: null },
    });
    const refused = await call('POST', `${API}/platform/alerts/${alert.id}/requeue`);
    expect(refused.status).not.toBe(200);
    expect(refused.status).toBeGreaterThanOrEqual(400);
    const unchanged = await prisma.platformAlert.findUniqueOrThrow({ where: { id: alert.id } });
    expect(unchanged.status).toBe('NO_CHANNEL');

    await reStepUp();
    const requeued = await call('POST', `${API}/platform/alerts/${alert.id}/requeue`);
    expect(requeued.status).toBe(200);
    expect(requeued.body.status).toBe('PENDING');

    const row = await prisma.platformAuditLog.findFirst({
      where: { action: 'alert:requeue', target: alert.id },
      orderBy: { seq: 'desc' },
    });
    expect(row).not.toBeNull();
    expect(row!.details).toMatchObject({ previousStatus: 'NO_CHANNEL' });

    // A SENT alert is never re-queued: that is how an alert would be delivered twice.
    const sent = await prisma.platformAlert.create({
      data: {
        type: 'ADMIN_CREATED',
        targetKind: 'platform',
        status: 'SENT',
        sentAt: new Date(),
        dedupeKey: `${RUN_ID}-sent`,
      },
    });
    createdAlertIds.push(sent.id);
    const refusedSent = await call('POST', `${API}/platform/alerts/${sent.id}/requeue`);
    expect(refusedSent.status).toBe(400);
  });

  it('R5 - the new routes are refused without a console session', async () => {
    for (const path of [
      `${API}/platform/audit-log`,
      `${API}/platform/audit-log/verify`,
      `${API}/platform/audit-log/export`,
      `${API}/platform/alerts`,
    ]) {
      const anonymous = await call('GET', path, undefined, { anonymous: true });
      // A rejected platform request is a plain 401/404 and reveals nothing about the route.
      expect([401, 403, 404]).toContain(anonymous.status);
      expect(anonymous.status).not.toBe(200);
    }
  });

  it('R4 - the tables this suite writes have no row-level security, so its green result cannot depend on connecting as a superuser', async () => {
    // Every jest suite here connects as `flexora`, a SUPERUSER, which bypasses row-level
    // security outright. That is how the platform subscription writes stayed broken in
    // production for two phases while every suite was green - see
    // r4-runtime-role-writes.spec.ts, which boots the app as flexora_app instead.
    //
    // This is the complement the owner asked for: a statement of which tables THIS suite
    // writes, and a check that none of them is RLS-protected, so there is no policy for the
    // superuser to bypass and the result means the same thing in production. The helper also
    // asserts that Subscription IS protected, so the check cannot pass vacuously.
    //
    // the api suspends and soft-deletes gyms, removes an administrator, re-queues an alert and appends audit rows. Fixture rows created directly through the superuser client are listed too where
    // they matter; what is NOT claimed here is anything about the api's own write privileges,
    // which is what the runtime-role suite covers.
    await assertWritesAreNotRlsProtected(prisma as never, ['Gym', 'PlatformAdmin', 'PlatformAlert', 'PlatformAuditLog', 'PlatformSession']);
  });
});
