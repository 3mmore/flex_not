/**
 * FLEXORA Gym OS — Item 3 regression test: refresh token / cookie expiry
 * consistency.
 *
 * Proves two things with a REAL running Nest app (supertest) hitting the
 * real `/auth/refresh` endpoint against a real Postgres test DB:
 *
 *   1. The `flx_refresh` cookie's `Set-Cookie` `Max-Age` now exactly matches
 *      refreshTokenCookieMaxAgeMs() (7 days by default) — not the old,
 *      inconsistent 30-day value.
 *   2. An 8-day-old refresh token (i.e. one issued outside the 7-day
 *      window) is rejected with 401 by POST /auth/refresh.
 */
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import request from 'supertest';
import cookieParser from 'cookie-parser';
import * as jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'crypto';
import { hashPassword } from '../../config/password-hash';
import { AuthModule } from '../../modules/auth/auth.module';
import { PermissionsModule } from '../../modules/permissions/permissions.module';
import { PrismaModule } from '../../prisma/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { SecurityModule } from '../../common/security/security.module';
import { PrismaService } from '../../config/prisma.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { BruteForceService } from '../../common/security/brute-force.service';
import {
    refreshTokenCookieMaxAgeMs,
    refreshTokenTtlDays,
  } from '../../modules/auth/auth-token.config';


/**
 * This spec deliberately boots only the modules Item 3 actually touches
 * (AuthModule + its @Global() dependencies: PrismaModule, RedisModule,
 * SecurityModule) rather than the full AppModule. Booting the full
 * AppModule currently fails for an unrelated, pre-existing reason (documented
 * in flexora_evidence/00-BASELINE-NOTES.md): WaBotModule does not import
 * AiModule, so Nest cannot resolve AiBrainService when every module is
 * wired up at once. That bug predates all 13 items in this ticket and is
 * out of scope for Item 3 — per the rules, we do not fix unrelated bugs
 * while working a different item. Building a minimal, real (not mocked)
 * Nest application from just the modules under test avoids that unrelated
 * failure while still exercising the genuine HTTP layer, real Postgres,
 * real cookie-parser, and the real AuthService/AuthController code paths.
 */
describe('Item 3 — refresh token / cookie expiry consistency', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let bruteForce: BruteForceService;
  let gymId: string;
  let userId: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      // PHASE N2 — `PermissionsModule` MUST be in this list. AuthService takes
      // PermissionsService as its 7th constructor parameter (it fills in the
      // `effectivePermissions` on the login/refresh response), and that service
      // is provided by a `@Global()` module which `AuthModule` itself does not
      // import — the real AppModule does. A minimal TestingModule therefore has
      // to import it explicitly, or compile() fails with
      // "Nest can't resolve dependencies of the AuthService (..., ?)". This was
      // invisible in isolation before because the suite never got past the
      // worker-killing teardown crash; the real module is imported here, nothing
      // is mocked.
      imports: [ConfigModule.forRoot({ isGlobal: true }), PrismaModule, RedisModule, SecurityModule, PermissionsModule, AuthModule],
    })
      // AuthController's `@UseGuards(JwtAuthGuard)` decorations (class
      // reference form, e.g. on /auth/me and /auth/change-password) make
      // Nest's DI container try to instantiate JwtAuthGuard itself.
      // JwtAuthGuard's constructor intentionally accepts either a Reflector
      // or a `{ verifyAsync }`-shaped object as its first parameter (a
      // pre-existing, unrelated design choice in this codebase, not part of
      // Item 3's scope); TypeScript's emitted `design:paramtypes` metadata
      // cannot disambiguate that union for automatic constructor injection.
      // `overrideGuard` supplies the exact same construction main.ts uses
      // for its *global* guard instance (`new JwtAuthGuard(reflector)`), so
      // the real JwtAuthGuard.canActivate logic still runs, unmodified, for
      // every request in this test.
      .overrideGuard(JwtAuthGuard)
      .useValue(new JwtAuthGuard(new Reflector()))
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(cookieParser());
    app.useGlobalGuards(new JwtAuthGuard(app.get(Reflector)));
    // PHASE R4: forbidNonWhitelisted matches main.ts, so a body the production api would
    // reject with 400 cannot pass here.
    app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }));
    prisma = app.get(PrismaService);
    bruteForce = app.get(BruteForceService);
    // This test hits the real, rate-limited /auth/login and /auth/refresh
    // endpoints repeatedly (including a deliberately-rejected 8-day-old
    // token). Reset any IP-based brute-force lockout state left over from a
    // previous run in this same sandbox/CI container so the suite is not
    // flaky when run back-to-back — this does not touch the actual
    // brute-force *logic* under test elsewhere (see item 13's rate-limit
    // tests), it only clears state specific to this spec's own IP.
    await bruteForce.reset('ip:::ffff:127.0.0.1');
    await bruteForce.reset('ip:127.0.0.1');
    await app.init();

    const slug = `refresh-ttl-${randomBytes(4).toString('hex')}`;
    const gym = await prisma.gym.create({
      data: { name: 'Refresh TTL Test Gym', slug, email: `${slug}@test.com`, phone: '0100000000', status: 'ACTIVE' },
    });
    gymId = gym.id;
    const user = await prisma.user.create({
      data: {
        gymId: gym.id,
        name: 'Refresh TTL Owner',
        email: `${slug}-owner@test.com`,
        passwordHash: '$argon2id$v=19$m=65536,t=3,p=1$c2FsdHNhbHQ$ZmFrZWhhc2hmb3J0ZXN0aW5nb25seQ', // unused, we craft tokens directly
        role: 'OWNER',
      },
    });
    userId = user.id;
  }, 30000);


  afterAll(async () => {
    await prisma.refreshToken.deleteMany({ where: { userId } });
    await prisma.user.deleteMany({ where: { id: userId } });
    await prisma.gym.deleteMany({ where: { id: gymId } });
    await app.close();
  }, 30000);

  function hashToken(token: string) {
    return createHash('sha256').update(token).digest('hex');
  }

  it(`refreshTokenTtlDays() defaults to 7 (single source of truth used by both JWT and cookie)`, () => {
    expect(refreshTokenTtlDays()).toBe(7);
    expect(refreshTokenCookieMaxAgeMs()).toBe(7 * 24 * 60 * 60 * 1000);
  });

  it('sets the flx_refresh cookie with Max-Age exactly equal to refreshTokenCookieMaxAgeMs() on login', async () => {
    // Create a real user with a known password via the register/login flow
    // would require full DTO validation; instead we directly hit /auth/login
    // by creating a user with a real argon2 hash matching a known password.
    const password = 'Str0ngPassw0rd!23';
    const hash = await hashPassword(password);
    await prisma.user.update({ where: { id: userId }, data: { passwordHash: hash } });

    const res = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: (await prisma.user.findUnique({ where: { id: userId } }))!.email, password })
      .expect(201);

    const setCookieHeader = res.headers['set-cookie'];
    expect(setCookieHeader).toBeDefined();
    const cookies: string[] = Array.isArray(setCookieHeader) ? setCookieHeader : [setCookieHeader as unknown as string];
    const refreshCookie = cookies.find((c) => c.startsWith('flx_refresh='));
    expect(refreshCookie).toBeDefined();

    const maxAgeMatch = refreshCookie!.match(/Max-Age=(\d+)/i);
    expect(maxAgeMatch).not.toBeNull();
    const maxAgeSeconds = Number(maxAgeMatch![1]);
    const expectedSeconds = refreshTokenCookieMaxAgeMs() / 1000;
    expect(maxAgeSeconds).toBe(expectedSeconds);
    // Explicitly assert it is NOT the old, inconsistent 30-day value.
    expect(maxAgeSeconds).not.toBe(30 * 24 * 3600);
  });

  it('rejects an 8-day-old refresh token with 401 on POST /auth/refresh', async () => {
    const familyId = randomBytes(16).toString('hex');

    // Craft a refresh JWT whose `iat` is 8 days in the past and whose
    // `expiresIn` is the real 7d value used by the service — so its `exp`
    // claim has already elapsed, exactly simulating "a refresh token that is
    // 8 days old" being presented to the API today.
    const eightDaysAgoSeconds = Math.floor(Date.now() / 1000) - 8 * 24 * 60 * 60;
    const staleRefreshToken = jwt.sign(
      { sub: userId, familyId, iat: eightDaysAgoSeconds },
      process.env.JWT_REFRESH_SECRET as string,
      { expiresIn: `${refreshTokenTtlDays()}d`, algorithm: 'HS256', noTimestamp: true } as jwt.SignOptions,
    );

    // Also insert a matching (non-expired-in-DB, to isolate that we are
    // testing the JWT's own exp claim rather than the DB row's expiresAt)
    // RefreshToken row, so a failure here can only be explained by JWT
    // expiry verification, not by the DB lookup.
    await prisma.refreshToken.create({
      data: {
        userId,
        tokenHash: hashToken(staleRefreshToken),
        familyId,
        expiresAt: new Date(Date.now() + 60_000), // DB row itself NOT expired
      },
    });

    const res = await request(app.getHttpServer())
      .post('/auth/refresh')
      .set('Cookie', [`flx_refresh=${staleRefreshToken}`])
      .expect(401);

    expect(res.body.message).toMatch(/invalid refresh token/i);
  });

  it('sanity check: a freshly issued (non-expired) refresh token IS accepted by POST /auth/refresh', async () => {
    const familyId = randomBytes(16).toString('hex');
    const freshRefreshToken = jwt.sign(
      { sub: userId, familyId },
      process.env.JWT_REFRESH_SECRET as string,
      { expiresIn: `${refreshTokenTtlDays()}d`, algorithm: 'HS256' } as jwt.SignOptions,
    );
    await prisma.refreshToken.create({
      data: {
        userId,
        tokenHash: hashToken(freshRefreshToken),
        familyId,
        expiresAt: new Date(Date.now() + refreshTokenCookieMaxAgeMs()),
      },
    });

    await request(app.getHttpServer())
      .post('/auth/refresh')
      .set('Cookie', [`flx_refresh=${freshRefreshToken}`])
      .expect(201);
  });
});
