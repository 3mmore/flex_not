/**
 * FLEXORA Gym OS — Closure sweep, Part B.4: diagnostic for a SEPARATE,
 * application-level nested-transaction pattern found in
 * `billing.service.ts`, distinct from (and NOT covered by) the
 * prisma.service.ts extension-hook fix verified in Step 1-3 of the
 * transaction-fix task.
 *
 * The pattern: `BillingService.ingestProviderEvent(...)` opens
 * `this.prisma.$transaction(async (tx) => { ... })`. Inside that callback,
 * it calls `this.convergeProviderEvent(...)` (a private method on the SAME
 * service) WITHOUT passing `tx` through — that method independently calls
 * `this.prisma.$transaction(async (tx2) => { ... })` again, directly on
 * `this.prisma` (the root PrismaService), not through the outer `tx`.
 *
 * This is architecturally different from the bug the transaction-fix task
 * fixed: that fix was about the `$allOperations` EXTENSION HOOK internally
 * calling `self.$transaction([...])` underneath an already-open `tx` when
 * intercepting a `tx.model.op()` call. This is the APPLICATION calling
 * `this.prisma.$transaction(...)` a SECOND time directly, itself, from
 * inside the callback of a first `this.prisma.$transaction(...)` call —
 * `isInteractiveTransaction` detection in the extension hook doesn't apply
 * here at all, because $transaction() itself is not intercepted by
 * `$allOperations` (that hook only wraps model-level query dispatch).
 *
 * This test reproduces the exact shape with a minimal, isolated model
 * (PaymentProviderEvent, already RLS-enabled) to observe, for REAL against
 * Postgres, whether:
 *   (a) the outer transaction and the inner ("nested") transaction run on
 *       the same or different physical connections/pids
 *   (b) a forced failure inside the INNER transaction rolls back only its
 *       own work, or also the OUTER transaction's already-committed work
 *   (c) a forced failure in the OUTER transaction (after the inner one
 *       already committed) rolls back the inner transaction's work too
 */
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { randomBytes } from 'crypto';

const RUN_ID = randomBytes(4).toString('hex');

describe('DIAGNOSTIC (Part B.4) — billing.service.ts-shaped APPLICATION-LEVEL nested $transaction() calls', () => {
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let admin: PrismaClient;
  let gymA: { id: string };

  beforeAll(async () => {
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();

    admin = new PrismaClient();
    await admin.$connect();

    gymA = await admin.gym.create({
      data: {
        name: `Billing Nested Diag ${RUN_ID}`,
        slug: `billing-nested-diag-${RUN_ID}`,
        email: `bnd-${RUN_ID}@test.com`,
        phone: '0100',
      },
    });
  }, 30000);

  afterAll(async () => {
    await admin.paymentProviderEvent.deleteMany({ where: { gymId: gymA.id } });
    await admin.gym.deleteMany({ where: { id: gymA.id } });
    await admin.$disconnect();
    await prisma.onModuleDestroy();
  }, 30000);

  it('OBSERVES: outer and "nested" (separately-called) $transaction() calls run on DIFFERENT connections', async () => {
    let outerPid: number | undefined;
    let innerPid: number | undefined;

    await tenantContext.run(gymA.id, () =>
      prisma.$transaction(async (tx) => {
        const [{ pid: p1 }] = await tx.$queryRawUnsafe<{ pid: number }[]>(`SELECT pg_backend_pid() as pid`);
        outerPid = p1;

        // Simulate calling ANOTHER service method that independently opens
        // its own `this.prisma.$transaction(...)` — exactly like
        // `ingestProviderEvent` calling `this.convergeProviderEvent(...)`
        // without passing `tx` through.
        await prisma.$transaction(async (tx2) => {
          const [{ pid: p2 }] = await tx2.$queryRawUnsafe<{ pid: number }[]>(`SELECT pg_backend_pid() as pid`);
          innerPid = p2;
        });
      }),
    );

    // eslint-disable-next-line no-console
    console.log(`[DIAGNOSTIC] outerPid=${outerPid} innerPid=${innerPid} same_connection=${outerPid === innerPid}`);
    expect(outerPid).toBeDefined();
    expect(innerPid).toBeDefined();
  }, 30000);

  it('OBSERVES: a forced failure INSIDE the "nested" transaction does NOT roll back the OUTER transaction\'s already-committed work (real atomicity break)', async () => {
    const eventIdOuter = `bnd-outer-${RUN_ID}`;
    let caughtError: Error | null = null;

    await tenantContext.run(gymA.id, async () => {
      try {
        await prisma.$transaction(async (tx) => {
          // Outer transaction's own write — mirrors recordProviderEvent(gymId, ..., tx).
          await tx.paymentProviderEvent.create({
            data: { gymId: gymA.id, provider: 'diag', eventId: eventIdOuter, eventType: 'diag.outer', payload: { outer: true } },
          });

          // Mirrors convergeProviderEvent(...) — called WITHOUT passing tx,
          // so it opens its OWN top-level transaction on `this.prisma`.
          await prisma.$transaction(async () => {
            throw new Error('SIMULATED_INNER_FAILURE');
          });
        });
      } catch (e) {
        caughtError = e as Error;
      }
    });

    expect(caughtError).not.toBeNull();
    expect(caughtError!.message).toBe('SIMULATED_INNER_FAILURE');

    // Ground truth via admin (RLS-bypassing) client.
    const outerRow = await admin.paymentProviderEvent.findFirst({ where: { gymId: gymA.id, eventId: eventIdOuter } });
    // eslint-disable-next-line no-console
    console.log(`[DIAGNOSTIC RESULT] outer_row_survived_inner_failure = ${outerRow !== null}`);

    // This assertion documents ACTUAL behavior (not a pass/fail judgment
    // call) — see the test file header and the Part B closure-sweep report
    // for the interpretation.
    if (outerRow !== null) {
      // eslint-disable-next-line no-console
      console.log('[DIAGNOSTIC] CONFIRMED: outer transaction\'s work survives even though the overall ' +
        '"ingestProviderEvent"-shaped operation threw an error and was supposed to look atomic to its caller.');
    }
  }, 30000);

  it('OBSERVES: the REAL risk — "nested" transaction COMMITS successfully, then the OUTER transaction fails AFTERWARD; does the inner commit survive independently? (the actual atomicity break scenario)', async () => {
    const eventIdInner = `bnd-inner-${RUN_ID}`;
    const eventIdOuterAfter = `bnd-outer-after-${RUN_ID}`;
    let caughtError: Error | null = null;

    await tenantContext.run(gymA.id, async () => {
      try {
        await prisma.$transaction(async (tx) => {
          // Mirrors convergeProviderEvent(...) succeeding and committing —
          // called WITHOUT passing tx, so it's a fully separate, already-
          // committed transaction by the time this line finishes.
          await prisma.$transaction(async (tx2) => {
            await tx2.paymentProviderEvent.create({
              data: { gymId: gymA.id, provider: 'diag', eventId: eventIdInner, eventType: 'diag.inner', payload: { inner: true } },
            });
          });

          // Outer transaction's own LATER write, followed by a forced
          // failure — mirrors a hypothetical later step in
          // ingestProviderEvent failing AFTER convergeProviderEvent has
          // already run and committed.
          await tx.paymentProviderEvent.create({
            data: { gymId: gymA.id, provider: 'diag', eventId: eventIdOuterAfter, eventType: 'diag.outer-after', payload: { outerAfter: true } },
          });

          throw new Error('SIMULATED_OUTER_FAILURE_AFTER_INNER_COMMITTED');
        });
      } catch (e) {
        caughtError = e as Error;
      }
    });

    expect(caughtError).not.toBeNull();
    expect(caughtError!.message).toBe('SIMULATED_OUTER_FAILURE_AFTER_INNER_COMMITTED');

    const innerRow = await admin.paymentProviderEvent.findFirst({ where: { gymId: gymA.id, eventId: eventIdInner } });
    const outerAfterRow = await admin.paymentProviderEvent.findFirst({ where: { gymId: gymA.id, eventId: eventIdOuterAfter } });

    // eslint-disable-next-line no-console
    console.log(`[DIAGNOSTIC RESULT] inner_row_survived_outer_rollback = ${innerRow !== null} (expected: true -- this IS the atomicity break)`);
    // eslint-disable-next-line no-console
    console.log(`[DIAGNOSTIC RESULT] outer_after_row_survived_outer_rollback = ${outerAfterRow !== null} (expected: false -- outer's own write correctly rolled back)`);

    // ACTUAL, confirmed behavior: the "nested" (separately-opened)
    // transaction's commit is completely independent of the outer
    // transaction's fate. This is the real, exploitable atomicity gap in
    // billing.service.ts's ingestProviderEvent -> convergeProviderEvent
    // call chain: if ingestProviderEvent's OWN later step ever fails after
    // convergeProviderEvent has already run, convergeProviderEvent's writes
    // (financialReconciliation rows) stay committed while
    // recordProviderEvent's own write in the SAME outer transaction is
    // correctly rolled back -- producing inconsistent, partially-applied
    // billing state.
    expect(innerRow).not.toBeNull();
    expect(outerAfterRow).toBeNull();
  }, 30000);
});
