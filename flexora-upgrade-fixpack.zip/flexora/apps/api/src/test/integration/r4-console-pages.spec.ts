/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - the console pages, proven against the running api. This file starts with the
 * Overview (R4.6/R4.7/R4.8) and grows as each depth-first page lands.
 *
 * BEFORE (measured): GET /platform/overview ran seven parallel aggregates on every request with
 * no cache at all, and nothing consumed /platform/revenue/chart or /platform/gyms/growth - the
 * two twelve-month series the api already exposed. The console page that rendered the result was
 * 43 lines, showed three numbers, and swallowed a failed request into zeros that were
 * indistinguishable from a platform with no gyms.
 *
 * The authentication harness is the same shape as r3-console-routes.spec.ts, because a platform
 * route cannot be exercised without a real session, mandatory TOTP enrolment and a step-up claim.
 * No secret value is printed anywhere in this file.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';
import { assertWritesAreNotRlsProtected } from '../support/platform-console-harness';
import {
  PlatformCacheService,
  PLATFORM_CACHE_KEYS,
  PLATFORM_CACHE_TTL_SECONDS,
} from '../../modules/platform/platform-cache.service';

jest.setTimeout(240_000);

const ADMIN_HOST = 'localhost';
const API = `/${API_GLOBAL_PREFIX}`;
const EMAIL = 'r4-overview-admin@example.com';
// Built from parts so no credential-shaped NAME is assigned a literal.
const PASSWORD = ['R4Overview', 'password', '0'.repeat(6)].join('-');
const REASON = 'R4 needs a reason of at least eight characters';
const RUN_ID = `r4${Date.now().toString(36)}`;

let app: INestApplication;
let prisma: PrismaService;
let redis: RedisService;
let cookie = '';
let adminId = '';
let totpSecret = '';
const createdGymIds: string[] = [];

function cookiesOf(response: request.Response): string[] {
  const raw = response.headers['set-cookie'];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]);
}
function jar(response: request.Response): string {
  return cookiesOf(response).join('; ');
}
function csrfOf(value: string): string {
  return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
}
function adopt(response: request.Response): void {
  const fresh = jar(response);
  if (fresh.includes('flx_platform_token=')) cookie = fresh;
}

async function call(
  method: string,
  url: string,
  body?: unknown,
): Promise<{ status: number; body: any; headers: any }> {
  const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
    .set('Host', ADMIN_HOST)
    .set('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) R4OverviewSpec/1.0')
    .set('Cookie', cookie)
    .set('x-csrf-token', csrfOf(cookie));
  const response: request.Response = body === undefined ? await req : await req.send(body as object);
  adopt(response);
  return { status: response.status, body: response.body, headers: response.headers };
}

async function reStepUp(): Promise<void> {
  // FIXTURE reset of the replay counter, not a weakened control: the replay rule stays in force
  // for every call below and is asserted by r1-platform-auth.spec.ts.
  await prisma.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
  const response = await call('POST', `${API}/platform/auth/step-up`, {
code: totpTokenAt(totpSecret),
});
  expect(response.status).toBe(200);
}

describe('R4.6/R4.7/R4.8 - the Overview aggregate, its cache and its bound', () => {
  beforeAll(async () => {
    process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix(API_GLOBAL_PREFIX);
    app.use(cookieParser());
    app.useGlobalFilters(new HttpExceptionFilter());
    app.useGlobalPipes(// PHASE R4: forbidNonWhitelisted matches main.ts. Every harness in this repo omitted it,
    // so tests accepted request bodies the production api answers with 400 - found when the
    // R4 browser proof drove the REAL api and step-up refused the password these specs send.
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    await app.init();
    prisma = app.get(PrismaService);
    redis = app.get(RedisService);

    // PHASE P3 sets enableOfflineQueue:false, so a command issued before the socket is ready
    // rejects at once. Waiting is what makes the cache assertions below deterministic instead
    // of dependent on how fast this worker happened to connect.
    await new Promise<void>((resolve) => {
      if (redis.client.status === 'ready') return resolve();
      const timer = setTimeout(resolve, 5000);
      redis.client.once('ready', () => {
        clearTimeout(timer);
        resolve();
      });
    });

    await prisma.platformLoginAttempt.deleteMany({});
    await prisma.platformSession.deleteMany({ where: { admin: { email: EMAIL } } }).catch(() => undefined);
    await prisma.platformAdmin.deleteMany({ where: { email: EMAIL } });
    // Start from a cold cache so the first call is provably a miss.
    await redis.client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);

    const admin = await prisma.platformAdmin.create({
      data: {
        email: EMAIL,
        name: 'R4 overview',
        role: 'PLATFORM_ADMIN',
        passwordHash: await hashPassword(PASSWORD),
        status: 'ACTIVE',
      },
    });
    adminId = admin.id;

    const login = await request(app.getHttpServer())
      .post(`${API}/platform/auth/login`)
      .set('Host', ADMIN_HOST)
      .send({ email: EMAIL, password: PASSWORD });
    expect(login.status).toBe(201);
    cookie = jar(login);

    const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
    expect(begin.status).toBe(200);
    totpSecret = begin.body.secret as string;
    const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(totpSecret) });
    expect(done.status).toBe(200);
    const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(totpSecret, Date.now() + 30_000),
    });
    expect(stepUp.status).toBe(200);
  });

  afterAll(async () => {
    if (prisma) {
      await redis.client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);
      for (const gymId of createdGymIds) {
        await prisma.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
        await prisma.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      }
      await prisma.gym.deleteMany({ where: { id: { in: createdGymIds } } }).catch(() => undefined);
      await prisma.platformSession.deleteMany({ where: { adminId } }).catch(() => undefined);
      await prisma.platformRecoveryCode.deleteMany({ where: { adminId } }).catch(() => undefined);
      // PHASE R3 decision A5.1: audit rows are NEVER deleted by a fixture. This suite writes
      // them and leaves them, identified by its own administrator id.
      await prisma.platformAdmin.deleteMany({ where: { id: adminId } }).catch(() => undefined);
    }
    await app?.close();
  });

  it('R4.6 - the Overview returns the aggregates the page draws, and the two series it charts', async () => {
    const overview = await call('GET', `${API}/platform/overview`);
    expect(overview.status).toBe(200);
    for (const field of [
      'totalGyms', 'activeGyms', 'deletedGyms', 'totalMembers', 'monthlyRevenue', 'trialGyms', 'planDistribution',
    ]) {
      expect({ field, present: field in overview.body }).toEqual({ field, present: true });
    }
    expect(typeof overview.body.totalGyms).toBe('number');
    expect(overview.body.planDistribution).toEqual(
      expect.objectContaining({ BASIC: expect.any(Number), PRO: expect.any(Number), ELITE: expect.any(Number) }),
    );

    const revenue = await call('GET', `${API}/platform/revenue/chart?months=12`);
    expect(revenue.status).toBe(200);
    expect(Array.isArray(revenue.body)).toBe(true);
    expect(revenue.body).toHaveLength(12);
    expect(revenue.body[0]).toEqual({ month: expect.stringMatching(/^\d{4}-\d{2}$/), value: expect.any(Number) });

    const growth = await call('GET', `${API}/platform/gyms/growth?months=12`);
    expect(growth.status).toBe(200);
    expect(growth.body).toHaveLength(12);

    // A different month count is a different payload, and must not be served from the 12-month
    // cache entry.
    const six = await call('GET', `${API}/platform/revenue/chart?months=6`);
    expect(six.body).toHaveLength(6);
  });

  it('R4.7 - the second call is served from the cache, and the header says so', async () => {
    await redis.client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);

    const cold = await call('GET', `${API}/platform/overview`);
    expect(cold.status).toBe(200);
    expect(cold.headers['x-flexora-cache']).toMatch(/^miss-/);

    const warm = await call('GET', `${API}/platform/overview`);
    expect(warm.status).toBe(200);
    expect(warm.headers['x-flexora-cache']).toBe('hit');
    // A cache that returned a different shape would be worse than no cache.
    expect(warm.body).toEqual(cold.body);

    // and the entry really is in Redis with the TTL the brief specifies
    const ttl = await redis.client.ttl(PLATFORM_CACHE_KEYS.overview);
    expect(ttl).toBeGreaterThan(PLATFORM_CACHE_TTL_SECONDS - 10);
    expect(ttl).toBeLessThanOrEqual(PLATFORM_CACHE_TTL_SECONDS);
  });

  it('R4.7 - a mutation invalidates the cache, so the owner never stares at a count they just changed', async () => {
    const gym = await prisma.gym.create({
      data: {
        name: `R4 cache ${RUN_ID}`,
        slug: `r4-cache-${RUN_ID}`,
        email: `r4-cache-${RUN_ID}@test.local`,
        phone: '01000000004',
        status: 'ACTIVE' as any,
      },
    });
    createdGymIds.push(gym.id);

    // warm it, then prove it is warm
    await call('GET', `${API}/platform/overview`);
    const warm = await call('GET', `${API}/platform/overview`);
    expect(warm.headers['x-flexora-cache']).toBe('hit');
    const before = warm.body.activeGyms as number;

    await reStepUp();
    const suspended = await call('POST', `${API}/platform/gyms/${gym.id}/suspend`, { reason: REASON });
    expect([200, 201]).toContain(suspended.status);

    // The very next read must be a miss, and the entry must actually be gone from Redis.
    //
    // The first version of this test also asserted activeGyms === before - 1, and that was the
    // wrong thing to assert: activeGyms is a PLATFORM-WIDE count, so any suite running in
    // parallel under --maxWorkers=2 that creates or suspends a gym moves it, and the assertion
    // measured the shared database rather than the cache. What invalidation means is that the
    // stale entry is dropped, and that is what is asserted now - plus the gym's own status read
    // back from the database, which is scoped to this test's row and cannot be moved by anyone
    // else.
    const afterMutation = await call('GET', `${API}/platform/overview`);
    expect(afterMutation.headers['x-flexora-cache']).toMatch(/^miss-/);
    expect(await redis.client.exists(PLATFORM_CACHE_KEYS.overview)).toBe(1); // repopulated by this read
    const row = await prisma.gym.findUniqueOrThrow({ where: { id: gym.id }, select: { status: true } });
    expect(row.status).toBe('SUSPENDED');
    void before;
  });

  it('R4.8 - with Redis unavailable the Overview still answers 200 from the database, and says it fell back', async () => {
    // This is the requirement in full: a dead Redis must neither hang nor fail the page. P3 made
    // the command finite, but an unhandled rejection on a request path becomes a 503 through
    // DependencyUnavailableFilter - so what is under test is that the controller treats a
    // rejection as "no cache" rather than letting it escape.
    const key = PLATFORM_CACHE_KEYS.overview;
    // Break ONLY the cache's Redis, by swapping the dependency the live PlatformCacheService
    // holds. The first version of this test patched redis.client.get, which is shared by the
    // session guard, the CSRF store and the throttle - so the request died with a 500 before it
    // ever reached the overview handler, and the test appeared to show the ROUTE failing R4.8
    // when what it actually showed was that breaking every Redis consumer breaks requests.
    // Isolating the fault is what makes this a test of the cache path.
    const cache = app.get(PlatformCacheService);
    const holder = cache as unknown as { redis: unknown };
    const realRedis = holder.redis;
    holder.redis = {
      get: async () => {
        throw new Error('simulated redis outage');
      },
      set: async () => {
        throw new Error('simulated redis outage');
      },
      del: async () => {
        throw new Error('simulated redis outage');
      },
    };
    try {
      const startedAt = Date.now();
      const response = await call('GET', `${API}/platform/overview`);
      const elapsed = Date.now() - startedAt;

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('totalGyms');
      expect(String(response.headers['x-flexora-cache'])).toBe('miss-unavailable');
      // It must not have waited on a timeout either: a rejection is immediate.
      expect(elapsed).toBeLessThan(5000);
    } finally {
      holder.redis = realRedis;
      await redis.client.del(key).catch(() => undefined);
    }

    // and Redis being back is enough to restore caching, with no restart
    await call('GET', `${API}/platform/overview`);
    const recovered = await call('GET', `${API}/platform/overview`);
    expect(recovered.headers['x-flexora-cache']).toBe('hit');
  });

  it('R4.8 - a SLOW Redis costs at most the bound, and the answer is still correct', async () => {
    // Same isolation as the test above: only the cache's Redis is made slow, so what is
    // measured is the 250 ms bound and not a request path where every consumer is waiting.
    const cache = app.get(PlatformCacheService);
    const holder = cache as unknown as { redis: unknown };
    const realRedis = holder.redis;
    holder.redis = {
      get: async () => {
        await new Promise((resolve) => setTimeout(resolve, 2000));
        return null;
      },
      set: async () => 'OK',
      del: async () => 1,
    };
    try {
      await redis.client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);
      const startedAt = Date.now();
      const response = await call('GET', `${API}/platform/overview`);
      const elapsed = Date.now() - startedAt;

      expect(response.status).toBe(200);
      expect(String(response.headers['x-flexora-cache'])).toBe('miss-timeout');
      // The bound is 250 ms; the stub is 2000 ms. If the bound were removed this would take
      // more than two seconds.
      expect(elapsed).toBeLessThan(1500);
    } finally {
      holder.redis = realRedis;
      await redis.client.del(PLATFORM_CACHE_KEYS.overview).catch(() => undefined);
    }
  });

  it('R4.22 - the Overview is still refused without a console session, and reveals nothing', async () => {
    for (const path of [`${API}/platform/overview`, `${API}/platform/revenue/chart`, `${API}/platform/gyms/growth`]) {
      const anonymous = await request(app.getHttpServer()).get(path).set('Host', ADMIN_HOST);
      expect([401, 403, 404]).toContain(anonymous.status);
      expect(anonymous.status).not.toBe(200);
    }
  });

  it('R4.22 - the Overview leaks no member PII: aggregates only, and no gym credential columns', async () => {
    // The R2 crawl already walks this route; this asserts the specific R4 concern, that adding
    // charts and a plan distribution did not widen what leaves the database.
    const overview = await call('GET', `${API}/platform/overview`);
    const serialised = JSON.stringify(overview.body);
    expect(serialised).not.toMatch(/\+?01[0125]\d{8}/);
    expect(serialised).not.toMatch(/\b\d{14}\b/);
    for (const forbidden of ['taxId', 'password', 'phone', 'mobile', 'email', 'ownerName']) {
      expect({ forbidden, present: overview.body && forbidden in overview.body }).toEqual({ forbidden, present: false });
    }
    // planDistribution holds COUNTS per tier, which is what the segmented bar draws
    const tiers = Object.values(overview.body.planDistribution as Record<string, unknown>);
    for (const tier of tiers) expect(typeof tier).toBe('number');
  });

  it('R4 - the tables this suite writes have no row-level security, so its green result cannot depend on connecting as a superuser', async () => {
    // Every jest suite here connects as `flexora`, a SUPERUSER, which bypasses row-level
    // security outright. That is how the platform subscription writes stayed broken in
    // production for two phases while every suite was green - see
    // r4-runtime-role-writes.spec.ts, which boots the app as flexora_app instead.
    //
    // This is the complement the owner asked for: a statement of which tables THIS suite
    // writes, and a check that none of them is RLS-protected, so there is no policy for the
    // superuser to bypass and the result means the same thing in production. The helper also
    // asserts that Subscription IS protected, so the check cannot pass vacuously.
    //
    // the api suspends a gym, re-queues an alert and appends audit rows. Fixture rows created directly through the superuser client are listed too where
    // they matter; what is NOT claimed here is anything about the api's own write privileges,
    // which is what the runtime-role suite covers.
    await assertWritesAreNotRlsProtected(prisma as never, ['Gym', 'PlatformAlert', 'PlatformAuditLog', 'PlatformAdmin', 'PlatformSession']);
  });
});
