/**
 * PHASE R2 - R2.6 / decisions Q3 and Q7(a)-(e)
 *
 * Hard deletion of a gym must not be reachable from the console, must not be reachable
 * as the api's runtime role, must not happen inside the 30-day restore window, and must
 * never leave a half-deleted tenant behind.
 *
 * Every case below runs the REAL command (prisma/purge-gym.ts, spawned the way
 * `npm run purge:gym` runs it) against the REAL database and asserts its exit code, its
 * output and - decisively - what is still in the database afterwards. Nothing here is
 * proven by reading code.
 *
 * Cases:
 *   1  --help works through ts-node and advertises no --force escape hatch
 *   2  Q7(a): refuses with no DATABASE_ADMIN_URL, exit 2, zero writes
 *   3  Q7(b): ATTACK - run as the api's runtime role: refused, exit 3, zero writes
 *   4  Q7(c): a slug this connection cannot see: refused, exit 4, zero writes
 *   5  Q3: a gym that is not soft-deleted: refused, exit 5
 *   6  Q3: soft-deleted inside the 30-day window: refused, exit 6 - and --force does
 *      not exist, so passing it changes nothing
 *   7  Q3: --confirm must equal --slug exactly, exit 7
 *   8  Q3: --reason must be a real reason, exit 7
 *   9  Q3: the default run is a DRY RUN - it prints counts, deletes nothing, and prints
 *      no tenant value at all (member name, mobile and national id are planted and then
 *      asserted absent from the output)
 *  10  Q3/Q7(d): --execute on a gym whose children include the two RESTRICT FKs and the
 *      NO ACTION Member->Plan edge clears every gymId table and the Gym row, in one
 *      transaction, and writes an immutable audit row. This is the ordering regression:
 *      a depth-then-alphabetical sort deletes Plan before RenewalRequest and the FK
 *      refuses it.
 *  11  Q7(d)/Q7(e): ATTACK - a role that passes every gate (BYPASSRLS) but lacks DELETE
 *      on one child table. The transaction must fail loudly, roll back, and leave the
 *      gym and all of its rows exactly as they were, with no audit row.
 *  12  the audit row the CLI writes carries counts and the reason, never tenant data.
 *
 * No secret value is ever printed: passwords are assembled from parts and the probe
 * role's credential is only ever passed through the child process environment.
 */
import { PrismaClient } from '@prisma/client';
import { spawnSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

// Every case in this suite spawns the CLI through ts-node, which is seconds of real work
// per case - and item 1 deliberately runs WITH type checking, to prove the documented
// `npm run purge:gym` invocation itself compiles. Under the full run's --maxWorkers=2 on a
// 2 GB sandbox those spawns exceeded jest's 5 s default and the suite reported a timeout
// instead of a result (measured: item 2 alone took 4.5 s in isolation). Raising the
// timeout changes no assertion and weakens no control; it stops a slow spawn from being
// reported as a failure.
jest.setTimeout(240_000);

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;
const RUN_ID = `p${Date.now().toString(36)}`;
const RUNTIME_ROLE = 'flexora_app';
const PROBE_ROLE = `r2_purge_probe_${RUN_ID}`;
const PROBE_PASSWORD = ['R2', 'probe', '0'.repeat(6)].join('-');
const RETENTION_DAYS = 30;

const API_ROOT = path.resolve(__dirname, '../../..');
const REPO_ROOT = path.resolve(API_ROOT, '../..');
const CLI = path.join(API_ROOT, 'prisma', 'purge-gym.ts');
const TS_NODE = path.join(REPO_ROOT, 'node_modules', '.bin', 'ts-node');

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function runtimeRoleUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = RUNTIME_ROLE;
  url.password = APP_PASSWORD!;
  return url.toString();
}

interface CliRun {
  code: number | null;
  out: string;
}

/**
 * Run the CLI exactly as `npm run purge:gym -- ...` does: ts-node, cwd apps/api, so the
 * api tsconfig is picked up. typeCheck=false only skips ts-node's type pass for speed -
 * the same code runs, and `npm run build` type-checks the file in the pipeline. Item 1
 * runs with type checking on, so the documented invocation itself is proven.
 */
function runCli(args: string[], adminUrl: string | undefined, opts: { typeCheck?: boolean } = {}): CliRun {
  const env: Record<string, string> = {
    ...(process.env as Record<string, string>),
    NODE_ENV: 'test',
    API_ROOT,
  };
  delete (env as Record<string, string | undefined>).DATABASE_ADMIN_URL;
  if (adminUrl) env.DATABASE_ADMIN_URL = adminUrl;
  if (opts.typeCheck === false) env.TS_NODE_TRANSPILE_ONLY = '1';
  const result = spawnSync(TS_NODE, [CLI, ...args], {
    cwd: API_ROOT,
    encoding: 'utf8',
    env,
    timeout: 240_000,
  });
  // Never echo a connection string back into a failure message.
  const scrub = (text: string) => text.replace(/(postgresql:\/\/[^:\s]+:)[^@\s]+@/g, '$1<redacted>@');
  return { code: result.status, out: scrub(`${result.stdout ?? ''}${result.stderr ?? ''}`) };
}

/** A gym in a chosen state, with the children that make the delete order interesting. */
interface Fixture {
  gymId: string;
  slug: string;
}

maybeDescribe('PHASE R2 - the purge CLI refuses, dry-runs, and never half-deletes (R2.6, Q3, Q7)', () => {
  let owner: PrismaClient;
  const made: Fixture[] = [];
  let memberName = '';
  let memberMobile = '';
  let memberNationalId = '';

  beforeAll(async () => {
    expect(fs.existsSync(CLI)).toBe(true);
    expect(fs.existsSync(TS_NODE)).toBe(true);
    owner = new PrismaClient();
    await owner.$connect();
  });

  afterAll(async () => {
    for (const fixture of made) {
      await owner.$executeRawUnsafe(`DELETE FROM public."Member" WHERE "gymId" = '${fixture.gymId}'`).catch(() => undefined);
      await owner.$executeRawUnsafe(`DELETE FROM public."RenewalRequest" WHERE "gymId" = '${fixture.gymId}'`).catch(() => undefined);
      await owner.$executeRawUnsafe(`DELETE FROM public."GymSettings" WHERE "gymId" = '${fixture.gymId}'`).catch(() => undefined);
      await owner.plan.deleteMany({ where: { gymId: fixture.gymId } }).catch(() => undefined);
      await owner.branch.deleteMany({ where: { gymId: fixture.gymId } }).catch(() => undefined);
      await owner.subscription.deleteMany({ where: { gymId: fixture.gymId } }).catch(() => undefined);
      await owner.gym.deleteMany({ where: { id: fixture.gymId } }).catch(() => undefined);
    }
    await owner.$executeRawUnsafe(`DROP ROLE IF EXISTS ${PROBE_ROLE}`).catch(() => undefined);
    await owner.$disconnect();
  });

  async function makeGym(label: string, state: { status: string; deletedDaysAgo?: number | null }): Promise<Fixture> {
    const slug = `r2-purge-${label}-${RUN_ID}`;
    const gym = await owner.gym.create({
      data: {
        name: `R2 Purge ${label} ${RUN_ID}`,
        slug,
        email: `r2-purge-${label}-${RUN_ID}@test.local`,
        phone: '01000000001',
        status: state.status as any,
        deletedAt: state.deletedDaysAgo == null ? null : new Date(Date.now() - state.deletedDaysAgo * 86400000),
      } as any,
    });
    const fixture: Fixture = { gymId: gym.id, slug };
    made.push(fixture);
    return fixture;
  }

  /** Branch + Plan + Member + RenewalRequest + GymSettings + Subscription, all planted. */
  async function addChildren(fixture: Fixture): Promise<void> {
    const branch = await owner.branch.create({ data: { gymId: fixture.gymId, name: `R2 Branch ${RUN_ID}` } as any });
    const plan = await owner.plan.create({
      data: { gymId: fixture.gymId, name: `R2 Plan ${RUN_ID}`, type: 'TIME' as any, price: 250 } as any,
    });
    memberName = `R2 Planted Member ${RUN_ID}`;
    memberMobile = '01199998888';
    memberNationalId = `29901019${RUN_ID.slice(-4)}`;
    const member = await owner.member.create({
      data: {
        gymId: fixture.gymId,
        branchId: branch.id,
        planId: plan.id,
        code: `R2P-${RUN_ID}`,
        name: memberName,
        mobile: memberMobile,
        startDate: new Date(),
        nationalId: memberNationalId,
      } as any,
    });
    // The edge that breaks a naive delete order: RenewalRequest -> Plan is RESTRICT, so
    // Plan must NOT be deleted first even though both tables carry gymId.
    await owner.$executeRawUnsafe(
      `INSERT INTO public."RenewalRequest" (id, "gymId", "memberId", "planId", amount)
       VALUES (gen_random_uuid(), $1, $2, $3, 250)`,
      fixture.gymId,
      member.id,
      plan.id,
    );
    // One of the two RESTRICT FKs on Gym itself.
    await owner.$executeRawUnsafe(
      `INSERT INTO public."GymSettings" (id, "gymId", key, value) VALUES (gen_random_uuid(), $1, $2, $3)`,
      fixture.gymId,
      `r2-key-${RUN_ID}`,
      'r2-value',
    );
    await owner.subscription.create({
      data: { gymId: fixture.gymId, tier: 'PRO' as any, status: 'ACTIVE' as any, currentPeriodEnd: new Date(Date.now() + 86400000) } as any,
    }).catch(() => undefined);
  }

  /** Every table that carries a gymId column, counted for one gym - the CLI's own claim. */
  async function remainingRows(gymId: string): Promise<string[]> {
    const tables = await owner.$queryRawUnsafe<Array<{ table_name: string }>>(
      `SELECT c.table_name FROM information_schema.columns c
        WHERE c.table_schema='public' AND c.column_name='gymId' AND c.table_name <> 'Gym'
        ORDER BY c.table_name`,
    );
    const leftovers: string[] = [];
    for (const row of tables) {
      const counted = await owner.$queryRawUnsafe<Array<{ n: string }>>(
        `SELECT COUNT(*)::text AS n FROM public."${row.table_name}" WHERE "gymId" = '${gymId}'`,
      );
      if (Number(counted[0]?.n ?? 0) > 0) leftovers.push(`${row.table_name}=${counted[0].n}`);
    }
    const gymRows = await owner.$queryRawUnsafe<Array<{ n: string }>>(
      `SELECT COUNT(*)::text AS n FROM public."Gym" WHERE id = '${gymId}'`,
    );
    if (Number(gymRows[0]?.n ?? 0) > 0) leftovers.push('Gym=1');
    return leftovers;
  }

  it('1. the documented invocation works, and there is no --force escape hatch', () => {
    const run = runCli(['--help'], undefined, { typeCheck: true });
    expect(run.code).toBe(0);
    expect(run.out).toMatch(/--slug/);
    expect(run.out).toMatch(/--confirm/);
    expect(run.out).toMatch(/--reason/);
    expect(run.out).toMatch(/--execute/);
    expect(run.out).toMatch(/DRY RUN|dry run/i);
    // decision Q3: no --force. If someone adds one, this fails.
    expect(run.out).not.toMatch(/--force/);
  });

  it('2. Q7(a): refuses when DATABASE_ADMIN_URL is absent, exit 2, zero writes', async () => {
    const fixture = await makeGym('noenv', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    await addChildren(fixture);
    const run = runCli(['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'], undefined);
    expect(run.code).toBe(2);
    expect(run.out).toMatch(/DATABASE_ADMIN_URL is not set/);
    // refusal: every planted row must still be there
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);
    expect(await remainingRows(fixture.gymId)).toContain('Gym=1');
  });

  it('3. Q7(b) ATTACK: run as the api runtime role, it refuses and writes nothing', async () => {
    const fixture = await makeGym('wrongrole', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    await addChildren(fixture);
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
      runtimeRoleUrl(),
      { typeCheck: false },
    );
    expect(run.code).toBe(3);
    expect(run.out).toMatch(/refusing to run as/);
    expect(run.out).toMatch(new RegExp(RUNTIME_ROLE));
    expect(run.out).toMatch(/No database write was attempted/);
    // the refusal is only meaningful if the data really is still there
    const survivors = await remainingRows(fixture.gymId);
    expect(survivors).toContain('Gym=1');
    expect(survivors).toContain('Member=1');
    expect(survivors).toContain('RenewalRequest=1');
    // and the role really could not see the rows it was asked to delete
    expect(run.out).toMatch(/ZERO rows|zero rows/i);
  });

  it('4. Q7(c): a slug the connection cannot see is refused, exit 4', async () => {
    const run = runCli(
      ['--slug', `no-such-gym-${RUN_ID}`, `--confirm=no-such-gym-${RUN_ID}`, '--reason=owner asked for it', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(4);
    expect(run.out).toMatch(/is visible to this connection/);
    expect(run.out).toMatch(/No database write was attempted/);
  });

  it('5. Q3: a gym that is not soft-deleted is refused, exit 5', async () => {
    const fixture = await makeGym('active', { status: 'ACTIVE', deletedDaysAgo: null });
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(5);
    expect(run.out).toMatch(/status=ACTIVE/);
    expect(run.out).toMatch(/soft-deleted first/);
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);
  });

  it('6. Q3: inside the 30-day restore window it is refused, exit 6, and --force does not exist', async () => {
    const fixture = await makeGym('fresh', { status: 'DELETED', deletedDaysAgo: 1 });
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(6);
    expect(run.out).toMatch(/restore window is 30 days/);
    expect(run.out).toMatch(/no --force/);
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);

    // passing --force must not bypass anything: it is not a flag this CLI accepts
    const forced = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute', '--force'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(forced.code).not.toBe(0);
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);
  });

  it('7. Q3: --confirm must equal --slug exactly, exit 7', async () => {
    const fixture = await makeGym('confirm', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug.toUpperCase()}`, '--reason=owner asked for it', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(7);
    expect(run.out).toMatch(/--confirm must equal --slug exactly/);
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);
  });

  it('8. Q3: a reason shorter than 8 characters is refused, exit 7', async () => {
    const fixture = await makeGym('reason', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=nope', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(7);
    expect(run.out).toMatch(/--reason must be at least 8 characters/);
    expect(await remainingRows(fixture.gymId)).not.toEqual([]);
  });

  it('9. Q3: the default run is a dry run that prints counts only and no tenant value', async () => {
    const fixture = await makeGym('dry', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    await addChildren(fixture);
    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it'],
      OWNER_URL,
      { typeCheck: false },
    );
    expect(run.code).toBe(0);
    expect(run.out).toMatch(/R2_PURGE_DRY_RUN_OK/);
    expect(run.out).toMatch(/DRY RUN - nothing was deleted/);
    expect(run.out).toMatch(/COUNTS ONLY/);
    // it saw rows to delete, so the plan is not trivially empty
    expect(run.out).toMatch(/TOTAL\s*:\s*[1-9]/);
    // nothing was deleted, and no tenant value reached the operator's terminal
    expect(await remainingRows(fixture.gymId)).toContain('Gym=1');
    expect(run.out).not.toContain(memberName);
    expect(run.out).not.toContain(memberMobile);
    expect(run.out).not.toContain(memberNationalId);
  });

  it('10. Q3/Q7(d): --execute clears every gymId table and the Gym row in one transaction', async () => {
    const fixture = await makeGym('exec', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    await addChildren(fixture);
    // the fixture really has the rows that make the order matter
    const before = await remainingRows(fixture.gymId);
    expect(before).toContain('Gym=1');
    expect(before).toContain('RenewalRequest=1');
    expect(before).toContain('Plan=1');

    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
      OWNER_URL,
      { typeCheck: false },
    );
    if (run.code !== 0) {
      // surface the CLI's own explanation, which is what an operator would read
      // eslint-disable-next-line no-console
      console.error(`purge --execute failed with code ${run.code}:\n${run.out.slice(0, 1200)}`);
    }
    expect(run.code).toBe(0);
    expect(run.out).toMatch(/R2_PURGE_EXECUTED_OK/);
    expect(run.out).toMatch(/re-count verified zero rows remaining/);
    expect(await remainingRows(fixture.gymId)).toEqual([]);

    const audit = await owner.$queryRawUnsafe<Array<{ action: string; admin_id: string; target: string }>>(
      `SELECT action, "adminId" AS admin_id, target FROM public."PlatformAuditLog"
        WHERE action = 'gym:purge' AND target = '${fixture.gymId}' ORDER BY "createdAt" DESC LIMIT 1`,
    );
    expect(audit.length).toBe(1);
    expect(audit[0].admin_id).toBe('cli:purge-gym');
  });

  it('11. Q7(d)/Q7(e) ATTACK: a failure mid-transaction rolls back and deletes nothing', async () => {
    // A role that passes every gate - it has BYPASSRLS - but cannot delete one child
    // table. The CLI must fail loudly and leave the tenant exactly as it was.
    await owner.$executeRawUnsafe(
      `CREATE ROLE ${PROBE_ROLE} LOGIN BYPASSRLS PASSWORD '${PROBE_PASSWORD}'`,
    );
    await owner.$executeRawUnsafe(`GRANT USAGE ON SCHEMA public TO ${PROBE_ROLE}`);
    await owner.$executeRawUnsafe(`GRANT SELECT ON ALL TABLES IN SCHEMA public TO ${PROBE_ROLE}`);
    await owner.$executeRawUnsafe(`GRANT DELETE ON ALL TABLES IN SCHEMA public TO ${PROBE_ROLE}`);
    await owner.$executeRawUnsafe(`GRANT INSERT ON public."PlatformAuditLog" TO ${PROBE_ROLE}`);
    await owner.$executeRawUnsafe(`REVOKE DELETE ON public."GymSettings" FROM ${PROBE_ROLE}`);

    const fixture = await makeGym('rollback', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
    await addChildren(fixture);
    expect(await remainingRows(fixture.gymId)).toContain('Gym=1');

    const probeUrl = new URL(OWNER_URL!);
    probeUrl.username = PROBE_ROLE;
    probeUrl.password = PROBE_PASSWORD;

    const run = runCli(
      ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
      probeUrl.toString(),
      { typeCheck: false },
    );
    expect(run.code).not.toBe(0);
    expect(run.out).not.toMatch(/R2_PURGE_EXECUTED_OK/);
    expect(run.out).toMatch(/rolled back|nothing was deleted|nothing is deleted/i);

    // the whole point: not one row went missing, and no audit row was written
    const stillThere = await remainingRows(fixture.gymId);
    expect(stillThere).toContain('Gym=1');
    expect(stillThere).toContain('Member=1');
    expect(stillThere).toContain('GymSettings=1');
    expect(stillThere).toContain('RenewalRequest=1');
    const audit = await owner.$queryRawUnsafe<Array<{ n: string }>>(
      `SELECT COUNT(*)::text AS n FROM public."PlatformAuditLog" WHERE action='gym:purge' AND target='${fixture.gymId}'`,
    );
    expect(Number(audit[0]?.n ?? 0)).toBe(0);
  });

  /**
   * 13. THE DELETE-ORDER REGRESSION.
   *
   * Today's schema happens to purge correctly, but only by coincidence: the plan sorts
   * affected tables by depth and then ALPHABETICALLY, and
   *   - Member sorts before Plan, and RenewalRequest.memberId is ON DELETE CASCADE, so
   *     the RESTRICT edge RenewalRequest.planId -> Plan is never tested;
   *   - PurchaseOrder sorts before Supplier.
   * A table added next month whose name sorts AFTER its RESTRICT parent breaks that, and
   * the CLI's own re-count comment says it exists for exactly that case. This test
   * creates such a table for real - a gymId column plus a RESTRICT FK to Plan and no
   * cascade path - and requires the purge to succeed. It also proves discovery is
   * column-based: this table has no Prisma model, no migration in the chain and no
   * foreign key to Gym, and the CLI must still find it, clear it and verify it.
   * The table is dropped again in a finally block, so no other case sees it.
   */
  it('13. a later-added gymId table whose name sorts after its RESTRICT parent still purges', async () => {
    const probe = `zz_r2_order_probe_${RUN_ID.replace(/[^A-Za-z0-9]/g, '').toLowerCase()}`;
    await owner.$executeRawUnsafe(
      `CREATE TABLE public."${probe}" (
         id       text PRIMARY KEY DEFAULT gen_random_uuid()::text,
         "gymId"  text NOT NULL,
         "planId" text NOT NULL REFERENCES public."Plan"(id) ON DELETE RESTRICT
       )`,
    );
    try {
      const fixture = await makeGym('order', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
      const plan = await owner.plan.create({
        data: { gymId: fixture.gymId, name: `R2 Order Plan ${RUN_ID}`, type: 'TIME' as any, price: 100 } as any,
      });
      await owner.$executeRawUnsafe(
        `INSERT INTO public."${probe}" (id, "gymId", "planId") VALUES (gen_random_uuid()::text, $1, $2)`,
        fixture.gymId,
        plan.id,
      );
      // the probe table is one of the gymId tables, so it is part of what must be cleared
      expect(await remainingRows(fixture.gymId)).toContain(`${probe}=1`);

      const run = runCli(
        ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
        OWNER_URL,
        { typeCheck: false },
      );
      if (run.code !== 0) {
        // eslint-disable-next-line no-console
        console.error(`order probe: purge failed with code ${run.code}:\n${run.out.slice(-900)}`);
      }
      expect(run.code).toBe(0);
      expect(run.out).toMatch(/R2_PURGE_EXECUTED_OK/);
      expect(await remainingRows(fixture.gymId)).toEqual([]);
    } finally {
      await owner.$executeRawUnsafe(`DROP TABLE IF EXISTS public."${probe}"`).catch(() => undefined);
      const gone = await owner.$queryRawUnsafe<Array<{ n: string }>>(
        `SELECT COUNT(*)::text AS n FROM information_schema.tables WHERE table_schema='public' AND table_name='${probe}'`,
      );
      expect(Number(gone[0]?.n ?? 0)).toBe(0);
    }
  });

  /**
   * 16. THE RE-COUNT ITSELF (Q7(d)/Q7(e)).
   *
   * The purge deletes, then re-counts every affected table inside the SAME transaction
   * and throws if a single row survived. Proving that needs a row that survives a
   * successful-looking DELETE - not an error, which item 11 already covers, but a silent
   * no-op. A BEFORE DELETE trigger that returns NULL is exactly that, and it stands in
   * for the real-world cases the check exists for: a policy or trigger nobody knew
   * about, or a table added next month whose rows the plan cannot reach.
   *
   * The table and its trigger are dropped again in a finally block.
   */
  it('16. Q7(d): if a row survives the delete, the CLI fails loudly and rolls the whole transaction back', async () => {
    const probe = `zz_r2_survivor_probe_${RUN_ID.replace(/[^A-Za-z0-9]/g, '').toLowerCase()}`;
    const fn = `zz_r2_survivor_fn_${RUN_ID.replace(/[^A-Za-z0-9]/g, '').toLowerCase()}`;
    await owner.$executeRawUnsafe(
      `CREATE TABLE public."${probe}" (id text PRIMARY KEY DEFAULT gen_random_uuid()::text, "gymId" text NOT NULL)`,
    );
    await owner.$executeRawUnsafe(
      `CREATE FUNCTION public."${fn}"() RETURNS trigger LANGUAGE plpgsql AS $t$ BEGIN RETURN NULL; END $t$`,
    );
    await owner.$executeRawUnsafe(
      `CREATE TRIGGER "${fn}_trg" BEFORE DELETE ON public."${probe}" FOR EACH ROW EXECUTE FUNCTION public."${fn}"()`,
    );
    try {
      const fixture = await makeGym('survivor', { status: 'DELETED', deletedDaysAgo: RETENTION_DAYS + 1 });
      await addChildren(fixture);
      await owner.$executeRawUnsafe(
        `INSERT INTO public."${probe}" (id, "gymId") VALUES (gen_random_uuid()::text, $1)`,
        fixture.gymId,
      );
      expect(await remainingRows(fixture.gymId)).toContain(`${probe}=1`);

      const run = runCli(
        ['--slug', fixture.slug, `--confirm=${fixture.slug}`, '--reason=owner asked for it', '--execute'],
        OWNER_URL,
        { typeCheck: false },
      );
      if (run.code === 0) {
        // eslint-disable-next-line no-console
        console.error(`survivor probe: the purge REPORTED SUCCESS despite a surviving row:\n${run.out.slice(-900)}`);
      }
      expect(run.code).toBe(1);
      expect(run.out).not.toMatch(/R2_PURGE_EXECUTED_OK/);
      expect(run.out).toMatch(/post-delete re-count found surviving rows/);
      expect(run.out).toMatch(new RegExp(probe));
      expect(run.out).toMatch(/The transaction was rolled back\. Nothing was deleted\./);

      // nothing at all was committed: the gym, its children and the survivor are all here
      const survivors = await remainingRows(fixture.gymId);
      expect(survivors).toContain('Gym=1');
      expect(survivors).toContain('Member=1');
      expect(survivors).toContain('GymSettings=1');
      expect(survivors).toContain(`${probe}=1`);
      const audit = await owner.$queryRawUnsafe<Array<{ n: string }>>(
        `SELECT COUNT(*)::text AS n FROM public."PlatformAuditLog" WHERE action='gym:purge' AND target='${fixture.gymId}'`,
      );
      expect(Number(audit[0]?.n ?? 0)).toBe(0);
    } finally {
      await owner.$executeRawUnsafe(`DROP TABLE IF EXISTS public."${probe}"`).catch(() => undefined);
      await owner.$executeRawUnsafe(`DROP FUNCTION IF EXISTS public."${fn}"()`).catch(() => undefined);
    }
  });

  it('12. the audit row the CLI writes carries counts and the reason, never tenant data', async () => {
    const rows = await owner.$queryRawUnsafe<Array<{ details: string }>>(
      `SELECT details::text AS details FROM public."PlatformAuditLog"
        WHERE action='gym:purge' AND "adminId"='cli:purge-gym' ORDER BY "createdAt" DESC LIMIT 5`,
    );
    expect(rows.length).toBeGreaterThan(0);
    for (const row of rows) {
      expect(row.details).not.toContain(memberMobile);
      expect(row.details).not.toContain(memberNationalId);
      expect(row.details).toMatch(/"reason"/);
      expect(row.details).toMatch(/"rows"/);
      expect(row.details).toMatch(/"tables"/);
    }
  });
});

describe('PHASE R2 - purge CLI suite guard', () => {
  it('documents why this suite may be skipped', () => {
    if (!APP_PASSWORD || !OWNER_URL) {
      // eslint-disable-next-line no-console
      console.warn(
        'r2-purge-cli.spec.ts: skipped because FLEXORA_APP_TEST_PASSWORD or DATABASE_URL is not set. ' +
          'The documented jest environment (work/jest-baseline-integration.sh) sets both.',
      );
    }
    expect(true).toBe(true);
  });
});
