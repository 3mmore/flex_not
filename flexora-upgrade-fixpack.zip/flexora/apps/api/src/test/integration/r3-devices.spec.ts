/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 - owner decision A4, the administrator device baseline, including the six cases
 * A4.7 asks for by name: known device, new IP, new user-agent family, minor user-agent
 * update, a device seen only in a FAILED attempt, and seeding twice.
 *
 * BEFORE (work/r3-evidence/00-before.log, B8/B9): PlatformSession stored ip and userAgent
 * and PlatformLoginAttempt stored ip and an outcome, but nothing anywhere compared a login
 * against history, and none of the five alert events had a single owner-channel call in its
 * handler. A login from a brand-new device on the other side of the world was
 * indistinguishable, as far as the platform was concerned, from the owner's own phone.
 */
import { PrismaClient } from '@prisma/client';
import { PlatformDeviceService, DEVICE_KEY_DOMAIN } from '../../modules/platform/platform-device.service';
import { PlatformAlertService, PLATFORM_ALERT_TYPES } from '../../modules/platform/platform-alert.service';

jest.setTimeout(180_000);

const MARKER = 'r3-devices-spec';
const RUN_ID = `${Date.now()}`;
const EMAIL = `${MARKER}-${RUN_ID}@example.com`;
/** Deliberately not a real secret value: the digest is keyed, and the key is derived. */
const DEVICE_SECRET = `${MARKER}-otp-hmac-secret`;

const UA_CHROME_130_A =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.58 Safari/537.36';
const UA_CHROME_130_B =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.120 Safari/537.36';
const UA_FIREFOX =
  'Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0';

const IP_HOME = '203.0.113.10';
const IP_AWAY = '198.51.100.77';

describe('R3.11/A4 - the administrator device baseline', () => {
  let prisma: PrismaClient;
  let service: PlatformDeviceService;
  let adminId: string;
  const raised: Array<{ type: string; severity?: string; targetId?: string | null }> = [];
  const savedSecret = process.env.OTP_HMAC_SECRET;

  /** An alert stub that records instead of sending, so the six cases stay deterministic. */
  const alertStub = {
    raise: jest.fn(async (input: { type: string; severity?: string; targetId?: string | null }) => {
      raised.push(input);
      return { id: `alert-${raised.length}`, status: 'PENDING' as const, deduped: false };
    }),
  } as unknown as PlatformAlertService;

  beforeAll(async () => {
    prisma = new PrismaClient();
    process.env.OTP_HMAC_SECRET = DEVICE_SECRET;

    const admin = await prisma.platformAdmin.create({
      data: {
        email: EMAIL,
        name: 'R3 device spec',
        role: 'PLATFORM_ADMIN',
        // No login is performed by this suite, so the hash is a placeholder. It is never
        // compared against anything and never leaves the fixture.
        passwordHash: `${MARKER}-placeholder-hash`,
        status: 'ACTIVE',
      },
    });
    adminId = admin.id;

    service = new PlatformDeviceService(prisma, alertStub);
  });

  afterAll(async () => {
    // PlatformAdminDevice cascades from PlatformAdmin, so removing the administrator removes
    // every baseline row this suite created. Audit rows written by the alert stub: none.
    await prisma.platformAdmin.deleteMany({ where: { id: adminId } }).catch(() => undefined);
    if (savedSecret === undefined) delete process.env.OTP_HMAC_SECRET;
    else process.env.OTP_HMAC_SECRET = savedSecret;
    await prisma.$disconnect();
  });

  beforeEach(() => {
    raised.length = 0;
    (alertStub.raise as jest.Mock).mockClear();
  });

  it('A4.2 - the device key is derived from an existing secret by domain separation, with no new variable', () => {
    const key = service.deviceKey();
    expect(key).not.toBeNull();
    expect(key).toHaveLength(64);
    expect(key).toMatch(/^[0-9a-f]{64}$/);
    // Deriving from a secret the deployment already requires is what keeps docker-compose,
    // env-validation, the four .env.example files and the owner's setup.ps1 untouched.
    expect(DEVICE_KEY_DOMAIN).toBe('flexora.platform.device.v1');
    // The key is not the secret itself, and the secret never appears in a stored digest.
    expect(key).not.toBe(DEVICE_SECRET);
  });

  it('A4.5 - the FIRST login on an empty baseline records silently and raises no alert', async () => {
    expect(await prisma.platformAdminDevice.count({ where: { adminId } })).toBe(0);

    const observation = await service.observeLogin({
      adminId,
      ip: IP_HOME,
      userAgent: UA_CHROME_130_A,
      auditSeq: null,
    });

    expect(observation.outcome).toBe('baseline-seeded');
    expect(observation.alertRaised).toBe(false);
    expect(raised).toHaveLength(0);
    expect(await prisma.platformAdminDevice.count({ where: { adminId } })).toBe(1);

    // A4.2: what is stored is a digest and the normalised parts, never the raw values.
    const row = await prisma.platformAdminDevice.findFirstOrThrow({ where: { adminId } });
    expect(row.deviceHash).toMatch(/^[0-9a-f]{64}$/);
    expect(row.uaFamily).toBe('Chrome');
    expect(row.uaMajor).toBe(130);
    expect(row.osFamily).toBe('Windows');
    const serialised = JSON.stringify(row);
    expect(serialised).not.toContain(IP_HOME);
    expect(serialised).not.toContain('Mozilla');
    expect(serialised).not.toContain(DEVICE_SECRET);
  });

  it('A4.7 case 1 - a KNOWN device logs in again: no alert, and the entry is updated', async () => {
    const before = await prisma.platformAdminDevice.findFirstOrThrow({ where: { adminId } });

    const observation = await service.observeLogin({
      adminId,
      ip: IP_HOME,
      userAgent: UA_CHROME_130_A,
    });

    expect(observation.outcome).toBe('known');
    expect(raised).toHaveLength(0);
    expect(await prisma.platformAdminDevice.count({ where: { adminId } })).toBe(1);

    const after = await prisma.platformAdminDevice.findFirstOrThrow({ where: { adminId } });
    expect(after.id).toBe(before.id);
    expect(after.loginCount).toBe(before.loginCount + 1);
    expect(after.lastSeenAt.getTime()).toBeGreaterThanOrEqual(before.lastSeenAt.getTime());
  });

  it('A4.7 case 4 - a MINOR user-agent update (Chrome 130.0.6723.58 to .120) is still the same device', async () => {
    const observation = await service.observeLogin({
      adminId,
      ip: IP_HOME,
      userAgent: UA_CHROME_130_B,
    });

    // This is the case that decides whether the feature is usable at all: if a browser
    // patch release alerted, the owner would be woken every few days and would learn to
    // ignore the channel.
    expect(observation.outcome).toBe('known');
    expect(raised).toHaveLength(0);
    expect(await prisma.platformAdminDevice.count({ where: { adminId } })).toBe(1);
  });

  it('A4.7 case 2 - a NEW IP with the same browser is reported, at the lower severity', async () => {
    const observation = await service.observeLogin({
      adminId,
      ip: IP_AWAY,
      userAgent: UA_CHROME_130_A,
      auditSeq: 4242,
    });

    expect(observation.outcome).toBe('new-ip');
    expect(observation.alertRaised).toBe(true);
    expect(raised).toHaveLength(1);
    expect(raised[0].type).toBe('ADMIN_NEW_DEVICE');
    expect(raised[0].severity).toBe('info');
    expect(raised[0].targetId).toBe(adminId);
    expect(PLATFORM_ALERT_TYPES).toContain('ADMIN_NEW_DEVICE');

    // A3.7 - the alert cites the audit row rather than copying anything out of it.
    const row = await prisma.platformAdminDevice.findFirstOrThrow({
      where: { adminId, deviceHash: (await service.fingerprint(IP_AWAY, UA_CHROME_130_A)).deviceHash },
    });
    expect(row.source).toBe('LOGIN');
    expect(row.ipOnly).toBe(false);
    void 4242;
  });

  it('A4.7 case 3 - a NEW user-agent family is reported at the higher severity', async () => {
    const observation = await service.observeLogin({
      adminId,
      ip: IP_HOME,
      userAgent: UA_FIREFOX,
    });

    expect(observation.outcome).toBe('new-device');
    expect(observation.alertRaised).toBe(true);
    expect(raised).toHaveLength(1);
    expect(raised[0].severity).toBe('warning');

    const row = await prisma.platformAdminDevice.findFirstOrThrow({
      where: { adminId, uaFamily: 'Firefox' },
    });
    expect(row.uaMajor).toBe(132);
    expect(row.osFamily).toBe('Linux');
  });

  it('A4.4 - the check can never block or fail a login: no IP, no secret, or a database error all return benignly', async () => {
    // no IP at all
    const noIp = await service.observeLogin({ adminId, ip: null, userAgent: UA_CHROME_130_A });
    expect(noIp.outcome).toBe('skipped');

    // no device key derivable
    delete process.env.OTP_HMAC_SECRET;
    service.resetDeviceKeyCache();
    const noKey = await service.observeLogin({ adminId, ip: IP_HOME, userAgent: UA_CHROME_130_A });
    expect(noKey.outcome).toBe('skipped');
    expect(raised).toHaveLength(0);
    process.env.OTP_HMAC_SECRET = DEVICE_SECRET;
    service.resetDeviceKeyCache();

    // a database that throws: observeLogin resolves, it does not reject
    const broken = new PlatformDeviceService(
      {
        $queryRaw: jest.fn(async () => {
          throw new Error('simulated database failure');
        }),
        $transaction: jest.fn(async () => {
          throw new Error('simulated database failure');
        }),
        platformAdminDevice: {
          findFirst: jest.fn(async () => {
            throw new Error('simulated database failure');
          }),
        },
      } as unknown as PrismaClient,
      alertStub,
    );
    await expect(
      broken.observeLogin({ adminId, ip: IP_HOME, userAgent: UA_CHROME_130_A }),
    ).resolves.toEqual({ outcome: 'skipped', reason: 'error' });
  });

  it('A4.7 case 5 - a device seen ONLY in a FAILED login attempt is never seeded', async () => {
    // A failed attempt is not this administrator's device; seeding from it would let an
    // attacker pre-register their own IP as "known" by simply failing to log in from it.
    const attackerIp = '192.0.2.200';
    await prisma.platformLoginAttempt.create({
      data: { email: EMAIL, ip: attackerIp, outcome: 'BAD_CREDENTIALS', detail: `${MARKER} failed attempt` },
    });
    await prisma.platformLoginAttempt.create({
      data: { email: EMAIL, ip: attackerIp, outcome: 'SUCCESS', detail: `${MARKER} later success` },
    });

    const attackerDigest = await service.fingerprint(attackerIp, null);
    const beforeFailedOnly = await prisma.platformAdminDevice.count({
      where: { adminId, deviceHash: attackerDigest.deviceHash },
    });
    expect(beforeFailedOnly).toBe(0);

    const result = await service.seedBaseline();
    expect(result.skipped).toBe(false);

    // The failed attempt alone must not have created an entry. The SUCCESS row for the same
    // address is a legitimate candidate and may create an ipOnly entry - so the assertion is
    // about provenance, not about the digest being absent: no entry may cite a failed
    // attempt as its source, and the count of entries must equal the count of distinct
    // (successful) candidates.
    const entries = await prisma.platformAdminDevice.findMany({ where: { adminId } });
    for (const entry of entries) {
      expect(['LOGIN', 'MIGRATION_SEED']).toContain(entry.source);
    }
    const failed = await prisma.platformLoginAttempt.count({
      where: { email: EMAIL, outcome: 'BAD_CREDENTIALS', ip: attackerIp },
    });
    expect(failed).toBe(1);

    // Now prove the negative properly: wipe the baseline, leave ONLY the failed attempt, and
    // seed again. Nothing may appear.
    await prisma.platformAdminDevice.deleteMany({ where: { adminId } });
    await prisma.platformLoginAttempt.deleteMany({ where: { email: EMAIL, outcome: 'SUCCESS' } });
    const empty = await service.seedBaseline();
    expect(empty.seeded).toBe(0);
    expect(await prisma.platformAdminDevice.count({ where: { adminId } })).toBe(0);
    void beforeFailedOnly;
  });

  it('A4.7 case 6 - seeding twice is idempotent and additive only', async () => {
    await prisma.platformSession.create({
      data: {
        adminId,
        tokenHash: `${MARKER}-session-${RUN_ID}`,
        ip: IP_HOME,
        userAgent: UA_CHROME_130_A,
        expiresAt: new Date(Date.now() + 3600_000),
        idleExpiresAt: new Date(Date.now() + 900_000),
      },
    }).catch(async () => {
      // The session model may require fields this fixture does not know about; the seeding
      // test below does not depend on it, so fall back to an attempt row instead.
      await prisma.platformLoginAttempt.create({
        data: { email: EMAIL, ip: IP_HOME, outcome: 'SUCCESS', detail: `${MARKER} seed source` },
      });
    });

    const first = await service.seedBaseline();
    const afterFirst = await prisma.platformAdminDevice.findMany({ where: { adminId } });
    const second = await service.seedBaseline();
    const afterSecond = await prisma.platformAdminDevice.findMany({ where: { adminId } });

    expect(first.skipped).toBe(false);
    expect(second.seeded).toBe(0);
    expect(afterSecond).toHaveLength(afterFirst.length);
    // Additive only: seeding never rewrites or removes an entry a login created.
    const idsFirst = afterFirst.map((row) => row.id).sort();
    const idsSecond = afterSecond.map((row) => row.id).sort();
    expect(idsSecond).toEqual(idsFirst);
  });

  it('A4.3 - the normalisation rule is the documented one, and the digest is keyed and stable', async () => {
    const cases: Array<[string, string, number, string]> = [
      [UA_CHROME_130_A, 'Chrome', 130, 'Windows'],
      [UA_CHROME_130_B, 'Chrome', 130, 'Windows'],
      [UA_FIREFOX, 'Firefox', 132, 'Linux'],
      ['curl/8.5.0', 'curl', 8, 'Unknown'],
      ['', 'Unknown', 0, 'Unknown'],
    ];
    for (const [ua, family, major, os] of cases) {
      const fp = await service.fingerprint(IP_HOME, ua);
      expect({ ua: ua.slice(0, 24), family: fp.uaFamily, major: fp.uaMajor, os: fp.osFamily }).toEqual({
        ua: ua.slice(0, 24),
        family,
        major,
        os,
      });
    }

    const a = await service.fingerprint(IP_HOME, UA_CHROME_130_A);
    const sameAgain = await service.fingerprint(IP_HOME, UA_CHROME_130_A);
    const otherIp = await service.fingerprint(IP_AWAY, UA_CHROME_130_A);
    expect(a.deviceHash).toBe(sameAgain.deviceHash);
    expect(a.deviceHash).not.toBe(otherIp.deviceHash);

    // A different install key produces a different digest for the same device, which is what
    // makes the key worth having: a stolen database cannot be used to reconstruct addresses.
    process.env.OTP_HMAC_SECRET = `${DEVICE_SECRET}-rotated`;
    service.resetDeviceKeyCache();
    const rotated = await service.fingerprint(IP_HOME, UA_CHROME_130_A);
    expect(rotated.deviceHash).not.toBe(a.deviceHash);
    process.env.OTP_HMAC_SECRET = DEVICE_SECRET;
    service.resetDeviceKeyCache();
  });
});
