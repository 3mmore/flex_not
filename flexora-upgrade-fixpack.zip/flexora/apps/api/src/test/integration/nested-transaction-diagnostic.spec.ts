/**
 * FLEXORA Gym OS — Nested transaction diagnostic (Step 1 of the follow-up
 * fix to Item 1's RLS race-condition fix).
 *
 * THIS IS A DIAGNOSTIC TEST ONLY. It exists to OBSERVE the actual, current
 * behavior of the Item-1 `$allOperations` extension when application code
 * calls `this.prisma.$transaction(async (tx) => { ... tx.model.op() ... })`
 * — the interactive-transaction pattern used by 11 real service files
 * (paymob.service.ts, billing.service.ts, dunning.service.ts,
 * attendance.service.ts, backups.service.ts, sales.service.ts,
 * expenses.service.ts, classes.service.ts, onboarding.service.ts,
 * invitations.service.ts, transfers.service.ts).
 *
 * The concern: the extension's `$allOperations` hook captures `self`
 * (the ROOT PrismaService) once in the constructor. When `tx.model.op()`
 * is called from inside an interactive transaction, that call still passes
 * through the SAME extension hook (extensions propagate to `tx`), but the
 * hook's `self.$transaction([setConfig, query(args)])` opens a brand new,
 * unrelated transaction on the ROOT client — not the one the calling code
 * intentionally opened. This test observes, against a REAL Postgres
 * instance, whether that:
 *   (a) breaks atomicity (an early write survives a later forced rollback)
 *   (b) breaks RLS visibility (app.gym_id not visible inside tx queries)
 *   (c) throws an explicit Prisma error about nested transactions
 *
 * This spec intentionally does NOT modify prisma.service.ts before running
 * — it tests the code exactly as Item 1 left it, to establish a ground
 * truth before any fix is written.
 */
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { randomBytes } from 'crypto';

const RUN_ID = randomBytes(4).toString('hex');

describe('DIAGNOSTIC (Step 1) — interactive $transaction(async tx => ...) under the Item-1 extension', () => {
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let admin: PrismaClient;
  let gymA: { id: string };

  beforeAll(async () => {
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();

    admin = new PrismaClient();
    await admin.$connect();

    gymA = await admin.gym.create({
      data: {
        name: `Nested TX Diag ${RUN_ID}`,
        slug: `nested-tx-diag-${RUN_ID}`,
        email: `diag-${RUN_ID}@test.com`,
        phone: '0100',
      },
    });
  }, 30000);

  afterAll(async () => {
    await admin.paymentAttempt.deleteMany({ where: { gymId: gymA.id } });
    await admin.gym.deleteMany({ where: { id: gymA.id } });
    await admin.$disconnect();
    await prisma.onModuleDestroy();
  }, 30000);

  it('OBSERVES whether a forced rollback inside this.prisma.$transaction(async tx => ...) actually rolls back an earlier tx.create() in that same block', async () => {
    const txId = `diag-atomicity-${RUN_ID}`;
    let observedError: Error | null = null;

    await tenantContext.run(gymA.id, async () => {
      try {
        await prisma.$transaction(async (tx) => {
          // 1. Create a row using the transaction client.
          await tx.paymentAttempt.create({
            data: {
              gymId: gymA.id,
              provider: 'paymob',
              providerTransactionId: txId,
              status: 'PENDING',
              amount: 100,
              currency: 'EGP',
            },
          });

          // 2. Deliberately force a rollback partway through.
          throw new Error('DIAGNOSTIC_FORCED_ROLLBACK');
        });
      } catch (e) {
        observedError = e as Error;
      }
    });

    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] Error observed from the $transaction call:', observedError?.message, observedError?.constructor?.name);

    // Query with the admin (un-extended) client, bypassing RLS entirely, to
    // see the raw ground truth of whether the row exists in the database.
    const survivingRow = await admin.paymentAttempt.findFirst({
      where: { gymId: gymA.id, providerTransactionId: txId },
    });

    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] Row survives after forced rollback?', survivingRow ? 'YES (BUG: atomicity broken)' : 'NO (correctly rolled back)');

    // This assertion is intentionally written to PASS regardless of outcome
    // — Step 1 is about OBSERVING, not about asserting correctness yet.
    // The real assertions happen in Step 3 after the fix.
    expect(observedError).not.toBeNull();
    // Record the ground truth as a snapshot-style assertion so the real
    // terminal output makes the actual observed behavior undeniable.
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC RESULT] atomicity_broken =', survivingRow !== null);
  }, 30000);

  it('OBSERVES whether app.gym_id (RLS) is correctly visible to tx.findFirst() inside the interactive transaction', async () => {
    // Seed a row directly via the admin client (bypasses RLS) so we have
    // something to look for.
    const txId = `diag-rls-${RUN_ID}`;
    await admin.paymentAttempt.create({
      data: {
        gymId: gymA.id,
        provider: 'paymob',
        providerTransactionId: txId,
        status: 'PENDING',
        amount: 50,
        currency: 'EGP',
      },
    });

    let foundInsideTx: unknown = 'NOT_SET';
    let errorInsideTx: Error | null = null;

    await tenantContext.run(gymA.id, async () => {
      try {
        await prisma.$transaction(async (tx) => {
          const row = await tx.paymentAttempt.findFirst({
            where: { gymId: gymA.id, providerTransactionId: txId },
          });
          foundInsideTx = row;
        });
      } catch (e) {
        errorInsideTx = e as Error;
      }
    });

    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] Error while querying inside tx:', errorInsideTx?.message);
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] tx.findFirst() result (RLS should show this gym\'s row):', JSON.stringify(foundInsideTx));
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC RESULT] rls_visible_inside_tx =', foundInsideTx !== 'NOT_SET' && foundInsideTx !== null);

    // Intentionally non-blocking assertion for the diagnostic phase.
    expect(true).toBe(true);
  }, 30000);
});
