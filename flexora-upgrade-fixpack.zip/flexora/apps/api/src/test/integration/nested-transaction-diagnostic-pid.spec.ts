/**
 * FLEXORA Gym OS — Step 1 diagnostic (part 2): precisely confirms WHY
 * atomicity breaks, by capturing pg_backend_pid() and the Postgres
 * transaction id (txid_current()) both (a) inside the outer
 * `this.prisma.$transaction(async (tx) => ...)` callback directly on `tx`,
 * and (b) as observed by a `tx.model.op()` call that is intercepted by the
 * Item-1 extension's `$allOperations` hook.
 *
 * If the extension's nested `self.$transaction([...])` is really opening a
 * SEPARATE transaction (as nested-transaction-diagnostic.spec.ts's
 * atomicity result already strongly implies), the backend pid and/or
 * txid seen by the `tx.model.op()` call will differ from the pid/txid of
 * the outer transaction itself.
 */
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { randomBytes } from 'crypto';

const RUN_ID = randomBytes(4).toString('hex');

describe('DIAGNOSTIC (Step 1, part 2) — connection/transaction identity inside vs. outside the nested self.$transaction()', () => {
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let admin: PrismaClient;
  let gymA: { id: string };

  beforeAll(async () => {
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();
    admin = new PrismaClient();
    await admin.$connect();
    gymA = await admin.gym.create({
      data: { name: `Nested TX PID Diag ${RUN_ID}`, slug: `nested-tx-pid-diag-${RUN_ID}`, email: `pid-diag-${RUN_ID}@test.com`, phone: '0100' },
    });
  }, 30000);

  afterAll(async () => {
    await admin.paymentAttempt.deleteMany({ where: { gymId: gymA.id } });
    await admin.gym.deleteMany({ where: { id: gymA.id } });
    await admin.$disconnect();
    await prisma.onModuleDestroy();
  }, 30000);

  it('compares pg_backend_pid()/txid_current() seen by the outer tx directly vs. by a tx.model.op() call routed through the extension', async () => {
    let outerPid: number | undefined;
    let outerTxid: string | undefined;
    let innerPid: number | undefined;
    let innerTxid: string | undefined;

    await tenantContext.run(gymA.id, async () => {
      await prisma.$transaction(async (tx) => {
        // (a) Query the outer transaction's own connection/txid DIRECTLY on
        // `tx` via a raw query — this bypasses the model-based
        // $allOperations hook entirely (raw queries on `tx` are NOT
        // intercepted by `query: { $allModels: { $allOperations } } }`,
        // which only hooks model CRUD operations), so this is a clean
        // read of what physical connection/transaction the outer `tx`
        // itself is actually using.
        const [outerRow] = await tx.$queryRawUnsafe<{ pid: number; txid: string }[]>(
          `SELECT pg_backend_pid() as pid, txid_current()::text as txid`,
        );
        outerPid = outerRow.pid;
        outerTxid = outerRow.txid;

        // (b) Now make a real MODEL operation call on the SAME `tx` object.
        // This call passes through the Item-1 extension's $allOperations
        // hook (extensions propagate to `tx` — this is exactly the
        // mechanism the 11 real service files rely on). We can't directly
        // ask a create()/findFirst() call for pg_backend_pid(), so instead
        // we create a row and immediately re-read the backend pid/txid via
        // ANOTHER raw query on `tx` right after — if the model operation
        // used the SAME transaction as the outer one, the database's
        // reported txid should not have advanced/changed and the write
        // should be visible to a subsequent raw query in the same `tx`.
        await tx.paymentAttempt.create({
          data: {
            gymId: gymA.id,
            provider: 'paymob',
            providerTransactionId: `pid-diag-inner-${RUN_ID}`,
            status: 'PENDING',
            amount: 10,
            currency: 'EGP',
          },
        });

        const [innerRow] = await tx.$queryRawUnsafe<{ pid: number; txid: string }[]>(
          `SELECT pg_backend_pid() as pid, txid_current()::text as txid`,
        );
        innerPid = innerRow.pid;
        innerTxid = innerRow.txid;

        // Force rollback of the OUTER transaction after the model op.
        throw new Error('DIAGNOSTIC_FORCED_ROLLBACK_PID_TEST');
      }).catch(() => undefined);
    });

    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] outer tx direct raw query -> pid:', outerPid, 'txid:', outerTxid);
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC] raw query on tx AFTER the tx.paymentAttempt.create() call -> pid:', innerPid, 'txid:', innerTxid);
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC RESULT] same_backend_pid_before_and_after_model_op =', outerPid === innerPid);
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC RESULT] same_txid_before_and_after_model_op =', outerTxid === innerTxid);

    // Ground truth: did the create() survive the outer rollback? (Already
    // established in nested-transaction-diagnostic.spec.ts, re-confirmed
    // here for this specific row.)
    const survives = await admin.paymentAttempt.findFirst({
      where: { gymId: gymA.id, providerTransactionId: `pid-diag-inner-${RUN_ID}` },
    });
    // eslint-disable-next-line no-console
    console.log('[DIAGNOSTIC RESULT] row_survived_outer_rollback =', survives !== null);

    expect(true).toBe(true); // observational only
  }, 30000);
});
