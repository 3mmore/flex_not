/**
 * FLEXORA Gym OS — Step 3 (follow-up to Item 1's nested-transaction fix):
 * real end-to-end simulation of the Paymob webhook flow's interactive
 * transaction, proving BOTH atomicity and tenant isolation against a real
 * Postgres instance.
 *
 * This mirrors the exact real shape of
 * `apps/api/src/modules/billing/paymob.service.ts`'s webhook handler:
 *
 *   return this.prisma.$transaction(async (tx) => {
 *     const existingAttempt = await tx.paymentAttempt.findFirst({ ... });
 *     ... await tx.paymentAttempt.upsert({ ... });
 *     ... await tx.paymentProviderEvent.create({ ... });   // "ingest provider event"
 *     ...
 *   });
 *
 * all performed via `tx.<model>.<op>()` calls inside ONE interactive
 * transaction, with a real gymId set in TenantContextService — the exact
 * pattern that was broken before the nested-transaction fix in
 * prisma.service.ts (see nested-transaction-diagnostic.spec.ts for the
 * isolated root-cause proof).
 *
 * IMPORTANT (RLS requires the real, non-bypassing `flexora_app` role):
 * Row Level Security policies are silently bypassed for any Postgres role
 * with `rolsuper` or `rolbypassrls` set — which is exactly what the
 * default/owner `DATABASE_URL` role (e.g. `postgres`) has in every local
 * dev/test setup in this repo (confirmed directly:
 * `SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = 'postgres'`
 * returns `t | t`). That means the TENANT ISOLATION assertions in this
 * spec are only a real test of RLS if `PrismaService` connects as the
 * dedicated, non-superuser `flexora_app` role created by Item 2's
 * migration (202607050001_flexora_app_role_force_rls) — otherwise every
 * query "passes" the isolation check trivially because RLS never actually
 * runs at all, regardless of whether the nested-transaction fix is present.
 * This spec follows the exact same pattern already used by Item 2's own
 * regression test (db-role-rls-enforcement.spec.ts): build a `flexora_app`
 * connection URL from `FLEXORA_APP_TEST_PASSWORD`, and gracefully SKIP the
 * RLS-dependent tests (not fail) if that env var is not set, so this does
 * not break `npm test` on machines where the role hasn't been provisioned.
 * The ATOMICITY assertions do not depend on RLS and always run.
 */
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { randomBytes } from 'crypto';

const RUN_ID = randomBytes(4).toString('hex');
const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  return url.toString();
}

describe('Paymob webhook flow simulation — Step 3: atomicity + tenant isolation inside one interactive transaction', () => {
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let admin: PrismaClient;

  let gymA: { id: string };
  let gymB: { id: string };

  beforeAll(async () => {
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();

    admin = new PrismaClient();
    await admin.$connect();

    gymA = await admin.gym.create({
      data: { name: `Paymob TX Gym A ${RUN_ID}`, slug: `paymob-tx-a-${RUN_ID}`, email: `paymob-a-${RUN_ID}@test.com`, phone: '0100' },
    });
    gymB = await admin.gym.create({
      data: { name: `Paymob TX Gym B ${RUN_ID}`, slug: `paymob-tx-b-${RUN_ID}`, email: `paymob-b-${RUN_ID}@test.com`, phone: '0200' },
    });
  }, 30000);

  afterAll(async () => {
    await admin.paymentProviderEvent.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await admin.paymentAttempt.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await admin.gym.deleteMany({ where: { id: { in: [gymA.id, gymB.id] } } });
    await admin.$disconnect();
    await prisma.onModuleDestroy();
  }, 30000);


  it('ATOMICITY: a forced failure partway through the webhook transaction rolls back BOTH the paymentAttempt AND the providerEvent writes', async () => {
    const txId = `paymob-atomic-${RUN_ID}`;

    let caughtError: Error | null = null;
    await tenantContext.run(gymA.id, async () => {
      try {
        await prisma.$transaction(async (tx) => {
          // Step 1 of the real webhook flow: look up any existing attempt.
          const existingAttempt = await tx.paymentAttempt.findFirst({
            where: { gymId: gymA.id, provider: 'paymob', providerTransactionId: txId },
          });
          expect(existingAttempt).toBeNull();

          // Step 2: create the payment attempt (mirrors paymob.service.ts's
          // tx.paymentAttempt.upsert(...) on first sight of a transaction).
          await tx.paymentAttempt.create({
            data: {
              gymId: gymA.id,
              provider: 'paymob',
              providerTransactionId: txId,
              providerRef: txId,
              status: 'SUCCESS',
              amount: 250,
              currency: 'EGP',
            },
          });

          // Step 3: "ingest provider event" (mirrors
          // billing.service.ts's ingestProviderEvent recording the raw
          // webhook payload) — same transaction, same tx client.
          await tx.paymentProviderEvent.create({
            data: {
              gymId: gymA.id,
              provider: 'paymob',
              eventId: txId,
              eventType: 'paymob.transaction',
              payload: { simulated: true, txId },
            },
          });

          // Step 4: deliberately force a failure AFTER both writes above,
          // exactly like a real webhook handler that fails on a later step
          // (e.g. subscription update failing) — this must roll back
          // EVERYTHING in this transaction, including the two writes above.
          throw new Error('SIMULATED_PAYMOB_FAILURE_AFTER_WRITES');
        });
      } catch (e) {
        caughtError = e as Error;
      }
    });

    expect(caughtError).not.toBeNull();
    expect(caughtError!.message).toBe('SIMULATED_PAYMOB_FAILURE_AFTER_WRITES');

    // Ground truth, checked via the ADMIN (un-extended, RLS-bypassing)
    // client so we see the real database state regardless of tenant
    // context — both rows must be completely absent if atomicity holds.
    const attemptAfterRollback = await admin.paymentAttempt.findFirst({
      where: { gymId: gymA.id, providerTransactionId: txId },
    });
    const eventAfterRollback = await admin.paymentProviderEvent.findFirst({
      where: { gymId: gymA.id, eventId: txId, provider: 'paymob' },
    });

    expect(attemptAfterRollback).toBeNull();
    expect(eventAfterRollback).toBeNull();
  }, 30000);

  it('SUCCESS PATH: a webhook transaction that completes normally commits BOTH writes together', async () => {
    const txId = `paymob-success-${RUN_ID}`;

    await tenantContext.run(gymA.id, async () => {
      await prisma.$transaction(async (tx) => {
        await tx.paymentAttempt.create({
          data: {
            gymId: gymA.id,
            provider: 'paymob',
            providerTransactionId: txId,
            providerRef: txId,
            status: 'SUCCESS',
            amount: 300,
            currency: 'EGP',
          },
        });
        await tx.paymentProviderEvent.create({
          data: {
            gymId: gymA.id,
            provider: 'paymob',
            eventId: txId,
            eventType: 'paymob.transaction',
            payload: { simulated: true, txId },
          },
        });
      });
    });

    const attempt = await admin.paymentAttempt.findFirst({ where: { gymId: gymA.id, providerTransactionId: txId } });
    const event = await admin.paymentProviderEvent.findFirst({ where: { gymId: gymA.id, eventId: txId, provider: 'paymob' } });
    expect(attempt).not.toBeNull();
    expect(attempt!.status).toBe('SUCCESS');
    expect(event).not.toBeNull();
  }, 30000);

  (APP_PASSWORD && OWNER_URL ? it : it.skip)(
    'TENANT ISOLATION (real RLS, via the non-superuser flexora_app role): gym B never sees rows created inside gym A\'s webhook transaction, and vice versa',
    async () => {
      // A second PrismaService instance, but pointed at flexora_app's
      // connection URL instead of the default owner/superuser DATABASE_URL
      // — see the file-level comment for why this is required for this
      // assertion to mean anything at all.
      const appTenantContext = new TenantContextService();
      const appPrisma = new PrismaService(appTenantContext);
      // Override the datasource URL on the already-constructed instance by
      // re-pointing $connect at a fresh, explicitly-scoped PrismaClient.
      // PrismaService's constructor reads DATABASE_URL directly, so we
      // temporarily swap process.env.DATABASE_URL for the duration of
      // construction (restored immediately after) — the cleanest way to
      // get a flexora_app-authenticated instance of the REAL PrismaService
      // class (extension included) without changing its production
      // constructor signature just for this test.
      const originalUrl = process.env.DATABASE_URL;
      process.env.DATABASE_URL = buildAppUrl();
      const flexoraAppPrisma = new PrismaService(appTenantContext);
      process.env.DATABASE_URL = originalUrl;
      await flexoraAppPrisma.onModuleInit();

      try {
        const txIdA = `paymob-tenant-a-${RUN_ID}`;
        const txIdB = `paymob-tenant-b-${RUN_ID}`;

        // Two "webhook" transactions for two different gyms, run
        // concurrently (interleaved), each inside its own tenant context +
        // interactive transaction — exactly the real production shape (two
        // concurrent incoming Paymob webhooks for two different
        // customers), and both using the flexora_app-authenticated client
        // so RLS is genuinely enforced.
        await Promise.all([
          appTenantContext.run(gymA.id, () =>
            flexoraAppPrisma.$transaction(async (tx) => {
              await tx.paymentAttempt.create({
                data: { gymId: gymA.id, provider: 'paymob', providerTransactionId: txIdA, providerRef: txIdA, status: 'SUCCESS', amount: 111, currency: 'EGP' },
              });
              await tx.paymentProviderEvent.create({
                data: { gymId: gymA.id, provider: 'paymob', eventId: txIdA, eventType: 'paymob.transaction', payload: { gym: 'A' } },
              });

              // While still inside gym A's transaction, read back using the
              // tenant-scoped `tx` client and confirm RLS restricts results
              // to gym A only, even though gym B's row (created
              // concurrently) may already exist in the table by now.
              const rows = await tx.paymentAttempt.findMany({ where: { provider: 'paymob', providerTransactionId: { in: [txIdA, txIdB] } } });
              for (const r of rows) {
                if (r.gymId !== gymA.id) {
                  throw new Error(`TENANT LEAK: gym A's transaction saw a row belonging to gymId=${r.gymId}`);
                }
              }
            }),
          ),
          appTenantContext.run(gymB.id, () =>
            flexoraAppPrisma.$transaction(async (tx) => {
              await tx.paymentAttempt.create({
                data: { gymId: gymB.id, provider: 'paymob', providerTransactionId: txIdB, providerRef: txIdB, status: 'SUCCESS', amount: 222, currency: 'EGP' },
              });
              await tx.paymentProviderEvent.create({
                data: { gymId: gymB.id, provider: 'paymob', eventId: txIdB, eventType: 'paymob.transaction', payload: { gym: 'B' } },
              });

              const rows = await tx.paymentAttempt.findMany({ where: { provider: 'paymob', providerTransactionId: { in: [txIdA, txIdB] } } });
              for (const r of rows) {
                if (r.gymId !== gymB.id) {
                  throw new Error(`TENANT LEAK: gym B's transaction saw a row belonging to gymId=${r.gymId}`);
                }
              }
            }),
          ),
        ]);

        // Final ground truth via the admin (owner, RLS-bypassing) client:
        // both rows exist, each with the correct gymId, and neither
        // transaction cross-contaminated the other's data.
        const attemptA = await admin.paymentAttempt.findFirst({ where: { providerTransactionId: txIdA } });
        const attemptB = await admin.paymentAttempt.findFirst({ where: { providerTransactionId: txIdB } });
        expect(attemptA?.gymId).toBe(gymA.id);
        expect(attemptB?.gymId).toBe(gymB.id);

        // And confirm read-back through the tenant-scoped, RLS-enforcing
        // flexora_app client after the fact: gym A's context must never
        // see gym B's row, and vice versa.
        //
        // NOTE: these two calls intentionally use an `async () => ...`
        // callback rather than a bare sync arrow `() => ...`. Prisma model
        // calls (e.g. `.findMany(...)`) return a lazily-evaluated
        // "PrismaPromise" (see @prisma/client/runtime/library.js's
        // `_createPrismaPromise`/`po()`) whose actual work is deferred until
        // something calls `.then()` on it, rather than a native `Promise`
        // that starts executing immediately. Node's `AsyncLocalStorage.run`
        // only keeps its store active for the synchronous portion of the
        // callback (and any continuation scheduled during that synchronous
        // portion) — a sync arrow `() => prisma.model.findMany(...)` returns
        // that lazy thenable WITHOUT calling `.then()` on it while still
        // inside the `run()` scope, so by the time the *caller* awaits the
        // returned value outside of `run()`, the AsyncLocalStorage context
        // has already been torn down and `TenantContextService.getGymId()`
        // sees `null` inside the extension hook, which is why RLS returned
        // zero rows. Wrapping the same call in a real `async () => ...`
        // function fixes this: a native async function's own promise
        // resolution synchronously calls `.then()` on whatever it returns,
        // while still inside the ALS scope, which keeps the context alive
        // long enough for the extension hook's `getGymId()` to see the right
        // value. This was confirmed directly with isolated Node.js
        // `AsyncLocalStorage` probes reproducing the same lazy-thenable
        // shape as Prisma's, and with `PrismaService`-based probes (see the
        // Step 3 summary) — it is a caller-side (test) gotcha with how
        // `TenantContextService.run()` interacts with lazily-evaluated
        // Prisma promises, not a bug in the nested-transaction fix. Note
        // this is also why the interactive-transaction calls above (e.g.
        // `appTenantContext.run(gymA.id, () => flexoraAppPrisma.$transaction(async (tx) => {...}))`)
        // are unaffected: `$transaction(async (tx) => ...)` is a real
        // `async` function whose returned promise IS eagerly/natively
        // tracked, so the sync arrow wrapping it is safe.
        const gymAView = await appTenantContext.run(gymA.id, async () =>
          flexoraAppPrisma.paymentAttempt.findMany({ where: { provider: 'paymob', providerTransactionId: { in: [txIdA, txIdB] } } }),
        );
        const gymBView = await appTenantContext.run(gymB.id, async () =>
          flexoraAppPrisma.paymentAttempt.findMany({ where: { provider: 'paymob', providerTransactionId: { in: [txIdA, txIdB] } } }),
        );
        expect(gymAView.every((r) => r.gymId === gymA.id)).toBe(true);
        expect(gymBView.every((r) => r.gymId === gymB.id)).toBe(true);
        expect(gymAView.length).toBe(1);
        expect(gymBView.length).toBe(1);
      } finally {
        await flexoraAppPrisma.onModuleDestroy();
      }
    },
    30000,
  );

  it('documents why the TENANT ISOLATION test above may be skipped in some environments', () => {
    if (!APP_PASSWORD) {
      // eslint-disable-next-line no-console
      console.warn(
        'paymob-transaction-atomicity.spec.ts: TENANT ISOLATION test skipped because ' +
          'FLEXORA_APP_TEST_PASSWORD is not set. Set it (and ensure migration ' +
          '202607050001_flexora_app_role_force_rls has been applied) to run it for real. ' +
          'Without the real, non-superuser flexora_app role, RLS is bypassed entirely ' +
          '(Postgres superusers/BYPASSRLS roles always bypass RLS), so the assertion would ' +
          'be meaningless if run against the default owner/superuser DATABASE_URL.',
      );
    }
    expect(true).toBe(true);
  });
});
