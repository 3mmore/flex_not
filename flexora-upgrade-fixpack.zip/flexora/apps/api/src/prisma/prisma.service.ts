import { isDevelopment } from '../config/env-mode';
import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient, Prisma } from '@prisma/client';
import { AsyncLocalStorage } from 'async_hooks';
import { TenantContextService } from '../common/services/tenant-context.service';
import { scopePrismaArgs } from '../common/branch-scope/branch-scope';

const SLOW_QUERY_MS = 3000;

/**
 * F-028: Explicit tenant context for ALL Prisma calls.
 *
 * ARCHITECTURE
 * ────────────
 * Every tenant-scoped table has FORCE ROW LEVEL SECURITY with policy
 * `"gymId" = current_setting('app.gym_id', true)`. If app.gym_id is not
 * set before a query, the query silently returns zero rows (never errors).
 *
 * There are two categories of Prisma calls, each handled differently:
 *
 * 1. STANDALONE calls (794 call sites across the app):
 *    e.g. this.prisma.member.findMany({ where: { gymId } })
 *
 *    These are automatically wrapped by a $extends middleware below that
 *    reads tenantContext.getGymId() (set by TenantContextInterceptor per
 *    request) and wraps the query in a $transaction([set_config, query])
 *    array — a public documented Prisma API. Under pgbouncer transaction-
 *    mode pooling, the array-style $transaction guarantees both statements
 *    run on the same physical connection, so set_config and the query see
 *    the same session state.
 *
 * 2. INTERACTIVE TRANSACTION calls (17 files):
 *    e.g. this.prisma.$transaction(async (tx) => { ... })
 *
 *    These use the explicit withTenant() method, which opens the txn,
 *    calls set_config on that txn's client, and runs the callback.
 *    The middleware detects "are we inside withTenant?" via an internal
 *    AsyncLocalStorage flag and skips its own wrapping to avoid nesting
 *    $transaction calls — which would open a second, independent
 *    connection and break atomicity (the original bug the old
 *    _createItxClient hack was trying to solve).
 *
 * Every mechanism here uses ONLY Prisma's public documented API:
 *   - $extends({ query: { $allModels: { ... } } })  — public
 *   - $transaction([...]) array style                 — public
 *   - $executeRaw tagged template                     — public
 *   - tenantContext.getGymId()                        — our own service
 *
 * No _createItxClient, no __internalParams, no undocumented internals.
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);

  /**
   * Flag to detect when we're inside an interactive transaction opened by
   * withTenant(). When true, the $extends middleware skips its own wrapping
   * (set_config is already handled by withTenant on the correct connection).
   */
  private readonly inInteractiveTransaction = new AsyncLocalStorage<boolean>();

  constructor(private readonly tenantContext: TenantContextService) {
    super({
      datasources: {
        db: {
          url: process.env.DATABASE_URL,
        },
      },
      // PRISMA_QUERY_LOG=off silences per-query logging in dev (low-resource
      // environments); errors are always logged.
      log: isDevelopment() && process.env.PRISMA_QUERY_LOG !== 'off'
        ? ['query', 'error', 'warn']
        : ['error'],
    });

    // ── $extends middleware for STANDALONE calls ─────────────────────
    // Wraps every model query in a $transaction([set_config, query]) to
    // ensure app.gym_id is set under FORCE RLS — using ONLY public APIs.
    // Skips when inside an interactive transaction (withTenant) to avoid
    // nested $transaction() calls that would break connection affinity.
    const self = this;
    const extended = self.$extends({
      name: 'flexora-tenant-rls-standalone',
      query: {
        $allModels: {
          async $allOperations(params) {
            const { args, query } = params;

            // ── PHASE 4: branch-scope **defence in depth** ────────────────
            // TenantGuard already normalises/rejects branch parameters and
            // pins req.branchScope; this layer repeats the rule at the last
            // possible moment, so a *single-record* access (GET /members/:id
            // of another branch, PATCH on it, DELETE on it …) is impossible
            // even if a service forgets the filter. Applies to both standalone
            // and in-transaction calls, and is a no-op for OWNER/MANAGER,
            // background jobs and pre-auth routes (no scope in context).
            // `any` is deliberate: the $allOperations callback is typed against
            // a 1.5k-member union of every model's args, and the rewrite below
            // is intentionally model-agnostic.
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            let effectiveArgs: any = args;
            const forcedBranchId = self.tenantContext.getForcedBranchId();
            if (forcedBranchId && params.model) {
              // NOTE: the Prisma extension API names this field `operation`
              // (see DynamicQueryExtensionArgs in @prisma/client) — not
              // `action`. Using the wrong key silently made every rewrite a
              // no-op, so it is spelled out here on purpose.
              effectiveArgs = scopePrismaArgs(params.model, params.operation, args, forcedBranchId);
            }

            // Are we inside an interactive transaction opened by withTenant()?
            // If so, set_config is already handled there; skip wrapping.
            if (self.inInteractiveTransaction.getStore()) {
              return query(effectiveArgs);
            }

            const gymId = self.tenantContext.getGymId();
            if (!gymId) {
              // No tenant context (pre-auth, platform-wide, @Public()).
              return query(effectiveArgs);
            }

            // Wrap in array-style $transaction — guaranteed same connection
            // under pgbouncer. This is a public documented Prisma API.
            const [, result] = await self.$transaction([
              self.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`,
              query(effectiveArgs),
            ]);
            return result;
          },
        },
      },
    });

    // ── PHASE N2: caller-started interactive transactions are tenant-aware ──
    //
    // THE BUG. The middleware above can only tell "am I inside a transaction I
    // own?" from the AsyncLocalStorage flag that withTenant() sets. Every
    // service that started a transaction the plain Prisma way instead —
    //   this.prisma.$transaction(async (tx) => { ... })
    // — left that flag false, so for EACH `tx.<model>.<op>()` the middleware
    // ran its standalone path: `self.$transaction([set_config, query])` on the
    // ROOT client. Every statement therefore committed immediately, on its own
    // connection, and the caller's transaction was left empty — a throw at the
    // end rolled back NOTHING. Real callers affected: BillingService's
    // Serializable payment/webhook transactions (:152/:410/:431/:552/:657),
    // AuthService's refresh-token rotation (:503) and revocation (:642),
    // TwoFactorService (:166), MembersService.applyPaidRenewal (:1073) —
    // i.e. exactly the money and credential paths where atomicity matters
    // most. Proved against real Postgres by
    // src/test/integration/paymob-transaction-atomicity.spec.ts (a forced
    // failure left the PaymentAttempt row behind) and
    // billing-nested-app-transaction-diagnostic.spec.ts.
    //
    // THE FIX. Shadow $transaction on the extended client (verified possible:
    // Object.defineProperty on an $extends result works, the shadow is invoked,
    // and the TransactionClient handed to the callback STILL carries the query
    // extension, so the PHASE 4 branch-scope rewrite keeps applying inside
    // transactions). The callback form now:
    //   1. sets the interactive-transaction flag, so the middleware stops
    //      wrapping each statement in its own transaction;
    //   2. runs `set_config('app.gym_id', ..., true)` as the FIRST statement of
    //      that same transaction, so FORCE RLS policies see the tenant exactly
    //      as they do under withTenant();
    //   3. passes isolationLevel/timeout options straight through.
    // withTenant() is unaffected (it sets the flag before calling, so this is a
    // pass-through), and a nested $transaction inside a transaction stays a
    // nested transaction — Prisma runs it on its own connection, which is the
    // behaviour billing-nested-app-transaction-diagnostic documents.
    //
    // STILL NOT ATOMIC: the ARRAY form, `$transaction([p1, p2, ...])`. Each
    // element is a PrismaPromise that the middleware has already wrapped and
    // started by the time $transaction sees it, so an array batch is a set of
    // independent transactions. That is acceptable for the read-only
    // report/dashboard batches it is used for, and every WRITE batch has been
    // moved to withTenant() (PlansService.remove in PHASE N1.5; ClassService
    // cancel/complete and ExpensesService.remove in PHASE N2). Do not add new
    // write batches in array form.
    const ext = extended as unknown as PrismaService;
    const originalTransaction = (ext.$transaction as unknown as (
      ...a: unknown[]
    ) => unknown).bind(ext);
    const tenantAwareTransaction = (arg: unknown, options?: unknown): unknown => {
      if (typeof arg !== 'function') return originalTransaction(arg, options);
      if (self.inInteractiveTransaction.getStore()) {
        return originalTransaction(arg, options);
      }
      const gymId = self.tenantContext.getGymId();
      return self.inInteractiveTransaction.run(true, () =>
        originalTransaction(async (tx: Prisma.TransactionClient) => {
          if (gymId) {
            await tx.$executeRaw(
              Prisma.sql`SELECT set_config('app.gym_id', ${gymId}, true)`,
            );
          }
          return (arg as (t: Prisma.TransactionClient) => Promise<unknown>)(tx);
        }, options),
      );
    };
    Object.defineProperty(ext, '$transaction', {
      value: tenantAwareTransaction,
      writable: true,
      configurable: true,
      enumerable: true,
    });

    return ext;
  }

  async onModuleInit() {
    await this.$connect();
    this.logger.log('Database connected successfully');
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }

  /**
   * Execute a callback inside an interactive transaction with app.gym_id set.
   *
   * Sets the interactive-transaction flag so the $extends middleware skips
   * its own wrapping (avoiding nested $transaction calls that would break
   * connection affinity/atomicity). Inside the callback, set_config runs
   * on the exact same transaction client, and all tx.model.op() calls
   * pass through the middleware but are skipped (flag is true).
   *
   * @param gymId - Tenant ID. If null, runs without setting tenant context.
   * @param fn - Callback receiving a Prisma TransactionClient with tenant set.
   * @param opts - Optional { isolationLevel, timeout }.
   */
  async withTenant<T>(
    gymId: string | null | undefined,
    fn: (tx: Prisma.TransactionClient) => Promise<T>,
    opts?: { isolationLevel?: Prisma.TransactionIsolationLevel; timeout?: number },
  ): Promise<T> {
    return this.inInteractiveTransaction.run(true, async () => {
      if (!gymId) {
        return this.$transaction(async (tx) => fn(tx), opts);
      }

      const before = Date.now();
      try {
        return await this.$transaction(async (tx) => {
          await tx.$executeRaw(
            Prisma.sql`SELECT set_config('app.gym_id', ${gymId}, true)`,
          );
          return fn(tx);
        }, opts);
      } finally {
        const elapsed = Date.now() - before;
        if (elapsed > SLOW_QUERY_MS) {
          this.logger.warn(`Slow tenant query (${elapsed}ms): gymId=${gymId}`);
        }
      }
    });
  }

  /** Convenience single-query wrapper. Delegates to withTenant. */
  async withTenantQuery<T>(
    gymId: string | null | undefined,
    queryFn: (tx: Prisma.TransactionClient) => Promise<T>,
  ): Promise<T> {
    return this.withTenant(gymId, queryFn);
  }

  /**
   * PHASE N3 — run a ROOT-CLIENT read as if no interactive transaction were open.
   *
   * `inInteractiveTransaction` tells the $extends middleware "the caller owns a
   * transaction and already ran set_config('app.gym_id', ...) on THAT
   * connection, so do not wrap this statement in its own
   * $transaction([set_config, query])". That is right for statements issued on
   * the transaction client, and wrong for a statement issued on the ROOT client
   * from inside such a callback: the root client takes a different pooled
   * connection where app.gym_id was never set, the wrapping that would have set
   * it is suppressed, and under FORCE ROW LEVEL SECURITY the read silently
   * returns ZERO rows instead of failing.
   *
   * Real consequence, found live in PHASE N3 and reproduced by
   * src/test/integration/refresh-permissions-claim.spec.ts: AuthService.refresh()
   * rotates tokens inside $transaction; issueTokens() then calls
   * PermissionsService.effectivePermissions(), whose `UserPermission` lookup came
   * back empty, so the refreshed access token carried ROLE DEFAULTS ONLY. A
   * permission the owner had granted was missing from the `permissions` claim the
   * web route gate reads, and the employee was bounced from /expenses to
   * /dashboard until they logged out and back in (r14-sec-verify: 2 checks).
   * Before the N2 override the flag was never set on this path, so the middleware
   * wrapped the read and the claim was correct — i.e. N2 fixed rotation atomicity
   * and silently broke the claim. Both now hold.
   *
   * Use this for reads that must see the tenant but do NOT have to be part of the
   * enclosing transaction. It re-enters the AsyncLocalStorage with the flag
   * cleared, so the middleware applies its normal standalone wrapping again
   * (set_config + query, same physical connection). The read runs on its own
   * connection and therefore cannot see the enclosing transaction's uncommitted
   * writes — only use it for data the transaction does not modify.
   */
  async outsideTransaction<T>(fn: () => Promise<T>): Promise<T> {
    return this.inInteractiveTransaction.run(false, fn);
  }
}
