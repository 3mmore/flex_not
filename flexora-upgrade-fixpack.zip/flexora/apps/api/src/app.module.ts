/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { isTest } from './config/env-mode';
import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { BullModule } from "@nestjs/bull";
import { ConfigModule } from "@nestjs/config";
import { ScheduleModule } from "@nestjs/schedule";
import { EventEmitterModule } from "@nestjs/event-emitter";
import { ThrottlerGuard, ThrottlerModule } from "@nestjs/throttler";
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from "@nestjs/core";
import { LicenceAvailabilityGuard } from "./common/guards/licence-availability.guard";
import { AdminHostGuard } from "./common/guards/admin-host.guard";
import { PlatformSessionGuard } from "./common/guards/platform-session.guard";
import { PlatformTotpEnrolmentGuard } from "./common/guards/platform-totp-enrolment.guard";
import { PlatformStepUpGuard } from "./common/guards/platform-step-up.guard";
import { PlatformCsrfGuard } from "./common/guards/platform-csrf.guard";
import { PlatformHeadersInterceptor } from "./common/interceptors/platform-headers.interceptor";
import { DependencyUnavailableFilter } from "./common/filters/dependency-unavailable.filter";
import { probeExclusionsForNest } from "./common/health/probe-routes";

import { PrismaModule } from "./config/prisma.module";
import { RedisModule } from "./config/redis.module";
import { AuditInterceptor } from "./common/interceptors/audit.interceptor";
import { TenantContextInterceptor } from "./common/interceptors/tenant-context.interceptor";
import { JwtAuthGuard } from "./common/guards/jwt-auth.guard";
import { RolesGuard } from "./common/guards/roles.guard";
import { TenantGuard } from "./common/guards/tenant.guard";
import { PermissionsGuard } from "./common/guards/permissions.guard";
import { PermissionsModule } from "./modules/permissions/permissions.module";
import { SecurityMonitorService } from "./common/security/security-monitor.service";
import { CronLeadershipService } from "./common/services/cron-leadership.service";
import { CsrfMiddleware } from "./common/middleware/csrf.middleware";
import { NullByteMiddleware } from "./common/middleware/null-byte.middleware";
import { RequestIdMiddleware } from "./common/middleware/request-id.middleware";

import { QueueModule } from "./modules/queue/queue.module";
import { SecurityModule } from "./common/security/security.module";
import { LicenseModule } from "./modules/license/license.module";
import { LicenseGuard } from "./modules/license/license.guard";

import { LeadsModule } from "./modules/leads/leads.module";
import { LeadsController } from "./modules/leads/leads.controller";
import { BiometricModule } from "./modules/biometric/biometric.module";
import { BiometricController } from "./modules/biometric/biometric.controller";
import { ContractsModule } from "./modules/contracts/contracts.module";
import { ContractsController } from "./modules/contracts/contracts.controller";
import { CampaignsModule } from "./modules/campaigns/campaigns.module";
import { CampaignsController } from "./modules/campaigns/campaigns.controller";
import { StaffAttendanceModule } from "./modules/staff-attendance/staff-attendance.module";
import { StaffAttendanceController } from "./modules/staff-attendance/staff-attendance.controller";
import { PayrollController } from "./modules/staff/payroll.controller";
import { PayrollService } from "./modules/staff/payroll.service";
import { TransfersService } from "./modules/transfers/transfers.service";
import { TransfersController } from "./modules/transfers/transfers.controller";
import { AccountingService } from "./modules/accounting/accounting.service";
import { AccountingController } from "./modules/accounting/accounting.controller";
import { InventoryService } from "./modules/inventory/inventory.service";
import { InventoryController } from "./modules/inventory/inventory.controller";
import { ProcurementController } from "./modules/inventory/procurement.controller";
import { CrmService } from "./modules/crm/crm.service";
import { CrmController } from "./modules/crm/crm.controller";
import { AiAdvancedService } from "./modules/ai-advanced/ai-advanced.service";
import { AiAdvancedController } from "./modules/ai-advanced/ai-advanced.controller";
import { WhiteLabelService } from "./modules/white-label/white-label.service";
import { WhiteLabelController } from "./modules/white-label/white-label.controller";
import { MarketplaceService } from "./modules/marketplace/marketplace.service";
import { MarketplaceController } from "./modules/marketplace/marketplace.controller";
import { EnterpriseService } from "./modules/enterprise/enterprise.service";
import { EnterpriseController } from "./modules/enterprise/enterprise.controller";
import { ReportCacheService } from "./modules/reports/report-cache.service";

import { AuthModule } from "./modules/auth/auth.module";
import { UsersModule } from "./modules/users/users.module";
import { GymsModule } from "./modules/gyms/gyms.module";
import { BranchesModule } from "./modules/branches/branches.module";
import { MembersModule } from "./modules/members/members.module";
import { PlansModule } from "./modules/plans/plans.module";
import { AttendanceModule } from "./modules/attendance/attendance.module";
import { KioskModule } from "./modules/kiosk/kiosk.module";
import { ProductsModule } from "./modules/products/products.module";
import { SalesModule } from "./modules/sales/sales.module";
import { ExpensesModule } from "./modules/expenses/expenses.module";
import { ReportsModule } from "./modules/reports/reports.module";
import { NotificationsModule } from "./modules/notifications/notifications.module";
import { BillingModule } from "./modules/billing/billing.module";
import { BackupsModule } from "./modules/backups/backups.module";
import { AuditModule } from "./modules/audit/audit.module";
import { HealthModule } from "./modules/health/health.module";
import { AiModule } from "./modules/ai/ai.module";
import { PortalModule } from "./modules/portal/portal.module";
import { ExecutionModule } from "./modules/execution/execution.module";
import { SchedulerModule } from "./modules/scheduler/scheduler.module";
import { ClassesModule } from "./modules/classes/classes.module";
import { PtModule } from "./modules/pt/pt.module";
import { MeasurementsModule } from "./modules/measurements/measurements.module";
import { RealtimeModule } from "./modules/realtime/realtime.module";
import { InvitationsModule } from "./modules/invitations/invitations.module";
import { ProductEventsModule } from "./events/product-events.module";
import { WaBotModule } from "./modules/wa-bot/wa-bot.module";
import { OnboardingModule } from "./modules/onboarding/onboarding.module";
import { PlatformAuthModule } from "./modules/platform-auth/platform-auth.module";
import { PlatformModule } from "./modules/platform/platform.module";
import { SecurityShieldModule } from "./modules/security/security.module";
import { MonitoringModule } from "./modules/monitoring/monitoring.module";
import { IpShieldMiddleware } from "./common/middleware/ip-shield.middleware";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    EventEmitterModule.forRoot(),
    // PHASE N1: `forRoot({ url: process.env.REDIS_URL })` read the URL when this
    // file was imported, freezing every queue's Redis connection to whatever the
    // environment held at import time. The factory below runs during module
    // initialisation instead, so REDIS_URL is the configured one.
    BullModule.forRootAsync({
      useFactory: () => ({
        // FIX (Item 2): single source of truth for Redis — Bull queues now
        // use the same REDIS_URL env var that every other Redis client in the
        // codebase uses (redis.service.ts, QueueService, scheduler.service.ts,
        // realtime.gateway.ts). The old REDIS_HOST/REDIS_PORT/REDIS_PASSWORD
        // silent-fallback pattern was NOT in env-validation.ts's REQUIRED_ENV
        // list, so a production deployment that only set REDIS_URL (the
        // officially required, validated way) would have had Bull silently
        // connecting to the wrong Redis instance (redis:6379, no password).
        url: process.env.REDIS_URL,
        defaultJobOptions: {
          attempts: 3,
          backoff: { type: 'exponential', delay: 2000 },
          removeOnComplete: 100,
          removeOnFail: 500,
        },
      }),
    }),
    ScheduleModule.forRoot(),
    ThrottlerModule.forRoot({
      throttlers: [
        { name: "global", ttl: 60000, limit: 1000 },
        // Strict for sensitive operations
        { name: "short", ttl: 60000, limit: 100 },
        // Credential attempts.
        //
        // IMPORTANT (root fix, Phase 4 verification): @nestjs/throttler applies
        // EVERY named throttler to EVERY route unless that route overrides it.
        // This bucket was set to 20/min, so ordinary reads such as /branches
        // and /auth/me were being throttled as if they were login attempts: a
        // normal page-to-page burst — or several staff sharing one IP behind a
        // NAT, which is exactly what the Next.js proxy produces — returned 429
        // and the UI silently lost its branch data.
        //
        // The bucket is now a generous backstop, and every route that actually
        // checks credentials carries its own explicit, much tighter `auth`
        // limit (see auth.controller.ts / two-factor.controller.ts /
        // platform-auth.controller.ts), so brute-force protection is unchanged.
        { name: "auth", ttl: 60000, limit: 120 },
        // Read endpoints (more generous)
        { name: "read", ttl: 60000, limit: 2000 },
        // Write endpoints (stricter)
        { name: "write", ttl: 60000, limit: 500 },
      ],
      // Disable rate limiting ONLY under automated tests (NODE_ENV=test), where
      // the shared in-memory counter would otherwise 429 later test cases.
      // Never skipped in development or production.
      skipIf: () => isTest(),
    }),
    PrismaModule,
    RedisModule,
    PermissionsModule,
    ProductEventsModule,
    QueueModule,
    LicenseModule,
    SecurityModule,
    AuthModule,
    UsersModule,
    GymsModule,
    BranchesModule,
    MembersModule,
    PlansModule,
    AttendanceModule,
    KioskModule,
    ProductsModule,
    SalesModule,
    ExpensesModule,
    ReportsModule,
    NotificationsModule,
    BillingModule,
    BackupsModule,
    AuditModule,
    HealthModule,
    AiModule,
    PortalModule,
    ExecutionModule,
    SchedulerModule,
    ClassesModule,
    PtModule,
    MeasurementsModule,
    RealtimeModule,
    InvitationsModule,
    LeadsModule,
    BiometricModule,
    ContractsModule,
    CampaignsModule,
    StaffAttendanceModule,
    WaBotModule,
    OnboardingModule,
    PlatformAuthModule,
    PlatformModule,
    SecurityShieldModule,
    MonitoringModule,
  ],
  controllers: [
    LeadsController,
    BiometricController,
    ContractsController,
    CampaignsController,
    StaffAttendanceController,
    PayrollController,
    TransfersController,
    AccountingController,
    InventoryController,
    ProcurementController,
    CrmController,
    AiAdvancedController,
    WhiteLabelController,
    MarketplaceController,
    EnterpriseController,
  ],
  providers: [
    // PHASE R0 — the owner-console host gate runs BEFORE everything else, so a
    // request that arrives on a hostname that is not in ADMIN_HOSTS is answered
    // with the plain 404 an unknown route would produce and never reaches:
    //   * LicenceAvailabilityGuard, which would otherwise answer 503
    //     LICENCE_UNVERIFIED for a platform route and thereby confirm it exists;
    //   * ThrottlerGuard (Redis-backed), so a public-host scanner cannot consume
    //     the console's rate-limit budget or lock the owner out;
    //   * JwtAuthGuard / BruteForceGuard, so a public-host login attempt is not
    //     even counted as a failed login.
    // It identifies platform routes by the @PlatformRoute() metadata on the
    // handler/controller — never by URL strings (see the guard's header comment
    // for the two measured prefix-rewrite traps that make strings unreliable).
    { provide: APP_GUARD, useClass: AdminHostGuard },
    // PHASE P3 — order matters. LicenceAvailabilityGuard is registered FIRST
    // (after the PHASE R0 host gate, which only reads request headers) so
    // that, when the licence could not be verified, the 503 + Retry-After answer
    // is produced before any guard that needs Redis or the database
    // (ThrottlerGuard is Redis-backed) can turn the request into a hang or a 500.
    { provide: APP_GUARD, useClass: LicenceAvailabilityGuard },
    // PHASE P3 — turns a bounded Redis rejection on a request path into
    // 503 + Retry-After (code REDIS_UNAVAILABLE) instead of a hang or a 500, and
    // gives the LICENCE_UNVERIFIED 503 its Retry-After header. It re-throws
    // everything it does not recognise, so the app's existing error shape stays
    // authoritative.
    { provide: APP_FILTER, useClass: DependencyUnavailableFilter },
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    // PHASE R1 — the owner console's own credential chain, in this order, each a
    // no-op on any route that is not marked @PlatformRoute():
    //   PlatformSessionGuard       the platform credential (JWT_PLATFORM_SECRET +
    //                              a live PlatformSession row). Registered before
    //                              JwtAuthGuard, which now hands platform routes
    //                              over instead of running the tenant strategy.
    //   PlatformTotpEnrolmentGuard R1.1/review item 3: pending enrolment can only
    //                              reach the routes marked @AllowedBeforeTotp().
    //   PlatformCsrfGuard          R1.6/review item 4: Origin must be an admin host
    //                              and the double-submit token must match. Runs
    //                              before step-up so a forged request is rejected for
    //                              being forged, not for lacking a second factor.
    //   PlatformStepUpGuard        R1.5: @RequireStepUp() needs a fresh assertion.
    // They sit AFTER ThrottlerGuard so a flood of bad tokens is rate limited
    // before it reaches the database, and AFTER LicenceAvailabilityGuard so an
    // unverified licence still answers 503 without touching Postgres.
    { provide: APP_GUARD, useClass: PlatformSessionGuard },
    { provide: APP_GUARD, useClass: PlatformTotpEnrolmentGuard },
    // CSRF before step-up: a request whose origin or token is wrong must be rejected
    // for THAT reason, not answered with a prompt for a second factor. Registering
    // step-up first made a forged change-password request answer STEP_UP_REQUIRED,
    // which is both the wrong reason and a small oracle (it tells the caller that a
    // session was accepted).
    { provide: APP_GUARD, useClass: PlatformCsrfGuard },
    { provide: APP_GUARD, useClass: PlatformStepUpGuard },
    // PHASE R1.8 - the strict header set on every platform API response, selected
    // by the same @PlatformRoute() metadata as the guards above.
    { provide: APP_INTERCEPTOR, useClass: PlatformHeadersInterceptor },
    // SECURITY FIX (default-deny): JwtAuthGuard is now global. Any route that
    // forgets @UseGuards(JwtAuthGuard) is still protected. Public routes must
    // be explicitly marked @Public(). The guard is idempotent (skips if
    // req.user is already set), so controllers that also apply it per-route
    // are unaffected. Portal routes use @Public() + MemberAuthGuard.
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: TenantGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    // ROUND 13 (Phase 5): fine-grained @Permissions gate — runs after the role
    // gate; endpoints without @Permissions metadata pass (any authenticated
    // user), exactly like the @Roles convention before.
    { provide: APP_GUARD, useClass: PermissionsGuard },
    { provide: APP_GUARD, useClass: LicenseGuard },
    // CRITICAL FIX (tenant-context / AsyncLocalStorage E2E investigation
    // -- see TenantContextInterceptor's own doc comment for the full
    // root-cause and fix rationale): this MUST be registered before
    // AuditInterceptor (interceptor order below is also EXECUTION order
    // for the "before handler" phase) so that AuditInterceptor's own
    // Prisma calls, and every other interceptor/handler code that runs
    // after it, execute inside the AsyncLocalStorage context this
    // interceptor establishes via `tenantContext.run(...)`.
    { provide: APP_INTERCEPTOR, useClass: TenantContextInterceptor },
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
    ReportCacheService,
    TransfersService,
    AccountingService,
    InventoryService,
    CrmService,
    AiAdvancedService,
    WhiteLabelService,
    MarketplaceService,
    EnterpriseService,
    SecurityMonitorService,
    CronLeadershipService,
    PayrollService,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(RequestIdMiddleware)
      .forRoutes("*");
    // PHASE Q2 — the liveness and readiness probes are excluded from the IP
    // shield, and the exclusion is DERIVED FROM ROUTE METADATA instead of being
    // spelled out here.
    //
    // PHASE P3 wrote `.exclude("api/health/live", "api/health/ready")`. That was
    // dead code, measured two ways:
    //   * Nest's `RouteInfoPathExtractor.extractPathFrom()` PREPENDS the global
    //     prefix to every non-wildcard path, so those two strings were registered
    //     as `/api/api/health/live` and `/api/api/health/ready`;
    //   * `isMiddlewareRouteExcluded()` matches that against `req.originalUrl`,
    //     which is `/api/health/live` — no match, so the middleware ran.
    // `IpShieldMiddleware.use()` then called `SecurityShieldService.isBlocked()`,
    // one Redis GET, and with Redis unreachable the rejection became the probe's
    // answer: `/api/health/live` returned 503 REDIS_UNAVAILABLE instead of 200.
    //
    // `probeExclusionsForNest()` returns the PREFIX-FREE forms (`health/live`,
    // `health/ready`) of whatever routes carry `@HealthProbe(...)`, which is what
    // Nest's extractor needs in order to produce the real path. The middleware
    // ALSO checks the marker itself (`probeKindOfRequest`), so the exemption does
    // not depend on this Nest quirk staying the way it is.
    consumer
      .apply(IpShieldMiddleware)
      .exclude(...probeExclusionsForNest())
      .forRoutes("*");
    // PHASE R1 / review item 2 - a NUL byte in the request target is refused for
    // every path with the same 400 and the same body. Applied to "*" rather than a
    // prefixed pattern, exactly like IpShieldMiddleware above, because Nest prepends
    // the global prefix to forRoutes() strings: "api/*splat" is registered as
    // /api/api/* and never matches anything (that is the bug CsrfMiddleware below
    // still carries, measured in PHASE R1).
    consumer.apply(NullByteMiddleware).forRoutes("*");
    consumer.apply(CsrfMiddleware).exclude(
      // PHASE Q2 — probes excluded by route identity (see the block above).
      ...probeExclusionsForNest(),
      // NOTE (PHASE Q2, left deliberately unchanged — see FOUND OUTSIDE SCOPE in
      // the delivery report): every string below is subject to the same
      // prefix-prepending, so none of these exclusions has ever matched either.
      // CsrfMiddleware's own internal COOKIE_SETTING_ROUTES / WEBHOOK_ROUTE_PREFIXES
      // lists (which match `req.path` against the full `/api/...` form) are what
      // actually exempts those routes today. Correcting the strings below would
      // change CSRF behaviour on authentication and webhook routes across the whole
      // API, which is a capability change that needs the owner's approval first —
      // it is reported, not silently done.
      "api/auth/login", "api/auth/register", "api/auth/refresh", "api/auth/logout",
      "api/auth/forgot-password", "api/auth/reset-password", "api/auth/2fa/login",
      "api/platform/auth/login",
      "api/portal/request-otp", "api/portal/verify-otp",
      "api/billing/webhook", "api/stripe/webhook", "api/paymob/webhook",
      "api/webhooks", "api/webhooks/*splat", "api/wa-bot/webhook/*splat"
    ).forRoutes("api/*splat");
  }
}