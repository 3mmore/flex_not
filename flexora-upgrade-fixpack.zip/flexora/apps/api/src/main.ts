/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
// MUST stay the first import: it loads apps/api/.env into process.env before
// any module that reads the environment at import time (see config/load-env.ts).
import './config/load-env';
import { isProduction } from './config/env-mode';
import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { Logger, ValidationPipe } from '@nestjs/common';
import { validationException } from './common/validation/validation-errors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import * as express from 'express';
import { Registry, collectDefaultMetrics } from 'prom-client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { enforceEnv, validateEnv } from './config/env-validation';
import { directUrlUserProblem, enforceDbPrivileges } from './config/db-privilege-guard';
import { logTrustProxyHops, trustProxyHops } from './config/trust-proxy.config';
import { PrismaService } from './prisma/prisma.service';
import { initSentry } from './config/sentry.config';
import { IpAllowlist, DEFAULT_METRICS_ALLOWED_CIDRS } from './common/security/ip-allowlist.util';
import { API_GLOBAL_PREFIX } from './config/api-prefix';
import { describeLicenceEnforcement, licenceEnforcementWarning } from './modules/license/licence-policy';

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  // PHASE M1 side-fix: `dist/` does not contain package.json, so this require
  // used to throw and kill the API at boot whenever APP_VERSION was not set —
  // a crash with no relation to the actual misconfiguration. Fall back instead.
  let appVersion = process.env.APP_VERSION;
  if (!appVersion) {
    try {
      appVersion = require('../package.json').version;
    } catch {
      appVersion = 'unknown';
    }
  }
  logger.log(`Starting FLEXORA API version: ${appVersion}`);

  // 1. Sentry first
  await initSentry();

  // 2. Env validation
  const envResult = validateEnv();
  enforceEnv(envResult);

  // 2b. PHASE O1.3 — the API must not hold a migration/owner credential.
  // Migrations run in docker-compose.yml's one-shot `migrate` service now, so in
  // production DIRECT_URL must name the SAME restricted database user as
  // DATABASE_URL. Pure string comparison, no database needed, so it runs before
  // the app is constructed. The message names variables and users, never a
  // password. In development/test the two legitimately differ (owner URL for
  // migrations, app role at runtime), so it warns instead of stopping the boot.
  const directUrlProblem = directUrlUserProblem();
  if (directUrlProblem) {
    if (isProduction()) throw new Error(directUrlProblem);
    logger.warn(directUrlProblem);
  }

  // 3. Logger
  const { WinstonNestAdapter } = await import('./config/logger.config');
  const winstonAdapter = new WinstonNestAdapter();

  // 4. Create app FIRST
  const app = await NestFactory.create(AppModule, {
    cors: false,
    logger: winstonAdapter,
    rawBody: true,
  });
  app.enableShutdownHooks();
  const eventEmitter = app.get(EventEmitter2);
  // PHASE P3 — an UNVERIFIABLE licence is not an expired one.
  //
  // `license.unverified` is emitted when the licence server could not be reached
  // AND the recorded grace could not be read (typically because Redis is down
  // too). The old code had only `license.expired`, so this situation ended in
  // `app.close()` + `process.exit(1)`: a network blip to a dependency killed the
  // process, including `/api/health/live`, which is precisely the endpoint an
  // orchestrator uses to decide whether to restart the container — so the
  // container was killed for something it could still answer.
  //
  // Now the process STAYS UP: liveness and readiness keep answering, and
  // LicenceAvailabilityGuard refuses every licensed route with 503 + Retry-After
  // and the code LICENCE_UNVERIFIED until a verification succeeds again (which
  // clears the state without a restart). An authoritatively REVOKED or EXPIRED
  // licence still emits `license.expired` below and still shuts the process down
  // — that behaviour is deliberately unchanged.
  // PHASE Q3 — say which licence mode this process is in, once, at boot. A
  // self-hosted operator who typo'd FLEXORA_LICENSE_ENABLED for
  // FLEXORA_LICENSE_REQUIRED would otherwise get silent SaaS behaviour with
  // nothing in the log to explain it. Neither line contains a licence key, a
  // server URL or an expiry.
  logger.log(describeLicenceEnforcement());
  const licenceSwitchWarning = licenceEnforcementWarning();
  if (licenceSwitchWarning) logger.warn(licenceSwitchWarning);

  eventEmitter.on('license.unverified', () => {
    logger.error(
      'Licence could not be verified and no grace record was readable — staying up, ' +
      'failing CLOSED: licensed routes answer 503 + Retry-After (LICENCE_UNVERIFIED) ' +
      'until verification succeeds. /api/health/live and /api/health/ready keep answering.',
    );
  });
  eventEmitter.on('license.expired', async () => {
    logger.error('License expired — initiating graceful shutdown.');
    // Force exit after 10 seconds no matter what
    const forceExit = setTimeout(() => { logger.error('Graceful shutdown timed out — forcing exit.'); process.exit(1); }, 10_000);
    forceExit.unref(); // Don't block event loop
    try {
      await app.close();
    } finally {
      clearTimeout(forceExit);
      process.exit(1);
    }
  });

  function bindForcedShutdown(signal: 'SIGTERM' | 'SIGINT') {
    process.on(signal, async () => {
      logger.warn(`${signal} received — starting graceful shutdown.`);
      const forceExit = setTimeout(() => {
        logger.error(`Graceful shutdown on ${signal} timed out after 10s — forcing exit.`);
        process.exit(1);
      }, 10_000);
      forceExit.unref();
      try {
        await app.close();
        clearTimeout(forceExit);
        process.exit(0);
      } catch (err) {
        logger.error(`Error during ${signal} shutdown: ${err}`);
        process.exit(1);
      }
    });
  }

  bindForcedShutdown('SIGTERM');
  bindForcedShutdown('SIGINT');

  const config = app.get(ConfigService);
  app.use(cookieParser());

  // PHASE R1 / review item 2 - the NUL-byte refusal lives in
  // common/middleware/null-byte.middleware.ts, registered from AppModule, so that it
  // applies in the real bootstrap AND in every integration test that builds the app
  // from AppModule. A rule that only exists here cannot be tested.

  app.use('/api/platform/auth/csp-report', express.json({ type: () => true, limit: '32kb' }));

  // 5. THEN setup Prometheus (app exists now)
  const register = new Registry();
  collectDefaultMetrics({ register });
  const httpAdapter = app.getHttpAdapter();
  // SECURITY (Item 8 fix): this used to be its own, independent, and even
  // more broken IP allow-list (`ip?.startsWith('10.')` etc. — not even
  // bounded to octet boundaries, so e.g. "100.0.0.1" or "10999.x" would
  // also match "10."). It now shares the same real-CIDR-arithmetic
  // IpAllowlist used by modules/monitoring/metrics.guard.ts, so there is
  // exactly one implementation of "is this IP allowed to see metrics" in
  // the whole codebase.
  const metricsAllowlist = new IpAllowlist(
    process.env.METRICS_ALLOWED_IPS
      ? process.env.METRICS_ALLOWED_IPS.split(',').map((s) => s.trim())
      : DEFAULT_METRICS_ALLOWED_CIDRS,
  );
  httpAdapter.use('/metrics', async (req: any, res: any, next: any) => {
    // Protect metrics endpoint - only localhost or internal
    const ip = req.ip || req.connection?.remoteAddress;
    if (!metricsAllowlist.isAllowed(ip)) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
  });


  // 6. Rest of setup (helmet, cors, guards, pipes, listen)
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],  // removed unsafe-inline — API has no inline scripts
        styleSrc: ["'self'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "blob:"],
      },
    },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }));

  // 3. CORS — strict, comma-separated allow-list (with validation)
  const rawOrigins = process.env.CORS_ORIGIN || 'http://localhost:3000';
  const allowedOrigins = rawOrigins.split(',').map((s) => s.trim()).filter(Boolean).map((origin) => {
    // Validate each origin: must be a valid URL with protocol and hostname
    try {
      const parsed = new URL(origin);
      if (!parsed.protocol.startsWith('http')) {
        throw new Error(`CORS origin must use http or https: ${origin}`);
      }
      if (!parsed.hostname) {
        throw new Error(`CORS origin missing hostname: ${origin}`);
      }
      // In production, only allow HTTPS origins (except localhost/dev)
      if (isProduction() && parsed.protocol !== 'https:' && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') {
        throw new Error(`CORS origin must use HTTPS in production: ${origin}`);
      }
      // Reject wildcards
      if (origin.includes('*')) {
        throw new Error(`CORS origin must not contain wildcards: ${origin}`);
      }
      // Reject empty/null origins
      if (origin === 'null' || origin === '') {
        throw new Error(`CORS origin must not be 'null' or empty`);
      }
      return origin;
    } catch (e) {
      const message = (e as Error).message;
      throw new Error(`Invalid CORS origin "${origin}": ${message}`);
    }
  });
  app.enableCors({
    origin: allowedOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token'],
  });

  // 4. Global validation pipe
  // Authentication, tenant, authorization, and licensing guards are
  // registered once through APP_GUARD in AppModule so Nest can inject their
  // dependencies. Do not duplicate them with useGlobalGuards here.
  // PHASE Q2 — the prefix lives in config/api-prefix.ts so the probe route
  // registry can derive both the prefixed and the prefix-free form of a route
  // from metadata instead of anyone hardcoding "api/..." strings again.
  app.setGlobalPrefix(API_GLOBAL_PREFIX);
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
      // Structured rejections: the client used to receive `message` as an ARRAY
      // and render "HTTP 400" for every DTO failure (the unreadable add-staff
      // error). One entry per field, with a translationKey when we know it.
      exceptionFactory: (errors) => validationException(errors),
    }),
  );
  app.useGlobalFilters(new HttpExceptionFilter());

  // 5. Swagger / OpenAPI — disabled in production (Phase 1A)
  if (!isProduction()) {
    const { DocumentBuilder, SwaggerModule } = await import('@nestjs/swagger');
    const swaggerConfig = new DocumentBuilder()
      .setTitle('FLEXORA Gym OS API')
      .setDescription('Multi-tenant gym management SaaS API')
      .setVersion('2.0.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, swaggerConfig);
    SwaggerModule.setup('docs', app, document);
    logger.log('Swagger UI mounted at /docs (dev mode)');
  } else {
    logger.log('Swagger UI is DISABLED in production');
  }

  // 5.5 Body parsers with EXPLICIT limits.
  // Nest registers its default express.json/urlencoded parsers during
  // app.listen() (inside init()) — but ONLY if it does not find an already
  // applied parser (isMiddlewareApplied matches the parser function names
  // 'jsonParser' / 'urlencodedParser'). Registering ours here (before listen)
  // therefore replaces the defaults instead of stacking on top of them.
  //
  // WHY THIS EXISTS (Phase 1 regression): the default express.json limit is
  // 100kb. The onboarding wizard sends the uploaded gym logo as a base64
  // data-URL inside the step-1 JSON payload — a genuine image under 1MB is
  // ~1.4MB of JSON, which the 100kb parser rejected with
  // PayloadTooLargeError. The exception filter then masked the 413 as an
  // opaque 500 "server_error", and because the wizard keeps the logo in
  // localStorage, every retry re-sent the oversized body, so the gym could
  // not finish onboarding (hence "cannot log in") until the logo was
  // removed. The verify hook preserves req.rawBody (rawBody: true is used
  // by webhook signature verification).
  const rawBodyVerify = (req: any, _res: unknown, buf: Buffer) => {
    if (Buffer.isBuffer(buf)) req.rawBody = buf;
  };
  app.use(express.json({ limit: '8mb', verify: rawBodyVerify }));
  app.use(express.urlencoded({ extended: true, limit: '1mb', verify: rawBodyVerify }));

  // 6.5 PHASE O4.2 — refuse to serve traffic with a privileged database role.
  // Row Level Security is the boundary between gyms, and Postgres exempts
  // SUPERUSER and BYPASSRLS roles from every policy: with such a role the API
  // would read and write every gym's data unfiltered and nothing in the
  // application could tell. The attributes are read from pg_roles over the same
  // DATABASE_URL the app uses, and this runs before app.listen(), so no request
  // is ever served by a process that failed the check. Production refuses (exit
  // 1 through bootstrap's catch); development/test warn, because a local stack
  // legitimately runs as the owner role. Fail-closed: if the attributes cannot
  // be read at all, production does not start either.
  const guardPrisma = app.get(PrismaService, { strict: false });
  await enforceDbPrivileges((sql) => guardPrisma.$queryRawUnsafe(sql), logger);

  // 6.6 PHASE O4.4 — trust proxy hops come from TRUST_PROXY_HOPS (validated
  // 0..3, default 1) instead of a hardcoded 1, and the effective value is
  // WARN-logged in production so a mis-set hop count is visible in the boot log.
  const trustProxy = trustProxyHops();
  const httpInstanceForProxy = app.getHttpAdapter().getInstance();
  if (typeof httpInstanceForProxy.set === 'function') {
    httpInstanceForProxy.set('trust proxy', trustProxy);
  }
  logTrustProxyHops(logger, trustProxy);

  const port = Number(config.get<number>('API_PORT') || 4000);
  await app.listen(port, '0.0.0.0');
  if (!isProduction()) {
    // eslint-disable-next-line no-console
    logger.log(`FLEXORA API running on :${port} (mode=${process.env.NODE_ENV || 'development'})`);
  }
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  // PHASE M1: hide internals unless we are explicitly in development/test.
    console.error('FATAL: bootstrap failed', isProduction() ? (err as Error).message : err);
  process.exit(1);
});
