import { Injectable } from '@nestjs/common';
import { NormalizedProductEvent } from './PRODUCT_EVENT_SCHEMA';

export interface ProductBusinessSignal {
  id: string;
  tenantId: string;
  kind: 'risk' | 'opportunity' | 'info';
  level: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  detail: string;
  sourceEventId?: string;
}

@Injectable()
export class ProductEventSignalBridge {
  toSignals(event: NormalizedProductEvent & { id?: string }): ProductBusinessSignal[] {
    const base = { id: `signal:${event.type}:${event.entityId || event.timestamp.getTime()}`, tenantId: event.tenantId, sourceEventId: event.id };
    switch (event.type) {
      case 'attendance.missed':
        return [{ ...base, kind: 'risk', level: 'high', title: 'Attendance risk', detail: 'Missed attendance can increase churn risk.' }];
      case 'inventory.low_stock':
        return [{ ...base, kind: 'risk', level: 'high', title: 'Inventory risk', detail: 'Low stock can block revenue capture.' }];
      case 'sale.created':
        return [{ ...base, kind: 'opportunity', level: 'medium', title: 'Revenue signal', detail: 'A sale event can inform inventory and revenue momentum.' }];
      case 'member.risk_detected':
        return [{ ...base, kind: 'risk', level: 'critical', title: 'Member churn risk', detail: 'A member was identified as at risk.' }];
      default:
        return [{ ...base, kind: 'info', level: 'low', title: 'Business event recorded', detail: `${event.type} was recorded.` }];
    }
  }
}
