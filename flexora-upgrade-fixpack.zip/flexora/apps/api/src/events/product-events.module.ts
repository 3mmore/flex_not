import { Global, Module } from '@nestjs/common';
import { PrismaModule } from '../config/prisma.module';
import { RedisModule } from '../config/redis.module';
import { ProductEventBus } from './PRODUCT_EVENT_BUS';
import { ProductEventEmitter } from './PRODUCT_EVENT_EMITTER';
import { ProductEventReplayEngine } from './PRODUCT_EVENT_REPLAY_ENGINE';
import { ProductEventSignalBridge } from './PRODUCT_EVENT_SIGNAL_BRIDGE';
import { ProductEventStore } from './PRODUCT_EVENT_STORE';
import { ProductEventWorker } from '../workers/PRODUCT_EVENT_WORKER';

@Global()
@Module({
  imports: [PrismaModule, RedisModule],
  providers: [ProductEventStore, ProductEventBus, ProductEventEmitter, ProductEventReplayEngine, ProductEventSignalBridge, ProductEventWorker],
  exports: [ProductEventStore, ProductEventBus, ProductEventEmitter, ProductEventReplayEngine, ProductEventSignalBridge, ProductEventWorker],
})
export class ProductEventsModule {}
