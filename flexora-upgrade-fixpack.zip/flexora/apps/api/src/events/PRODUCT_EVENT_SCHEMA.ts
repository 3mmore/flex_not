import { BadRequestException } from '@nestjs/common';

export type ProductEventSource = 'api' | 'system' | 'ai' | 'worker';
export type ProductEventType =
  | 'member.created'
  | 'member.updated'
  | 'member.deleted'
  | 'member.renewed'
  | 'member.risk_detected'
  | 'attendance.checked_in'
  | 'attendance.missed'
  | 'sale.created'
  | 'refund.created'
  | 'inventory.updated'
  | 'inventory.low_stock'
  | 'campaign.executed'
  | 'billing.updated'
  | 'class.booked';

export interface ProductEventInput<TPayload extends Record<string, unknown> = Record<string, unknown>> {
  type: ProductEventType;
  tenantId: string;
  branchId?: string | null;
  userId?: string | null;
  entityId?: string | null;
  payload: TPayload;
  timestamp?: Date;
  source: ProductEventSource;
}

export interface NormalizedProductEvent extends ProductEventInput {
  timestamp: Date;
}

const REQUIRED_PAYLOAD_KEYS: Partial<Record<ProductEventType, string[]>> = {
  'member.created': ['memberId'],
  'member.updated': ['memberId'],
  'member.deleted': ['memberId'],
  'member.renewed': ['memberId'],
  'attendance.checked_in': ['memberId'],
  'sale.created': ['saleId'],
  'refund.created': ['refundId'],
  'inventory.updated': ['productId'],
  'inventory.low_stock': ['productId'],
  'campaign.executed': ['campaignId'],
  'billing.updated': ['gymId'],
  'class.booked': ['sessionId', 'memberId'],
};

export function validateEventSchema(event: ProductEventInput): NormalizedProductEvent {
  if (!event.type) throw new BadRequestException('Product event type is required');
  if (!event.tenantId) throw new BadRequestException('Product event tenantId is required');
  if (!event.source) throw new BadRequestException('Product event source is required');
  if (!event.payload || typeof event.payload !== 'object' || Array.isArray(event.payload)) {
    throw new BadRequestException('Product event payload must be an object');
  }
  const required = REQUIRED_PAYLOAD_KEYS[event.type] || [];
  for (const key of required) {
    if ((event.payload as Record<string, unknown>)[key] == null) {
      throw new BadRequestException(`Product event payload.${key} is required for ${event.type}`);
    }
  }
  return { ...event, timestamp: event.timestamp ? new Date(event.timestamp) : new Date() };
}
