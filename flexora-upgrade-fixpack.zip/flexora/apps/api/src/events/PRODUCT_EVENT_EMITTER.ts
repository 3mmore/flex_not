import { Injectable, Logger } from '@nestjs/common';
import { ProductEventBus } from './PRODUCT_EVENT_BUS';
import { ProductEventStore } from './PRODUCT_EVENT_STORE';
import { ProductEventInput, validateEventSchema } from './PRODUCT_EVENT_SCHEMA';
import { ProductEventWorker } from '../workers/PRODUCT_EVENT_WORKER';

@Injectable()
export class ProductEventEmitter {
  private readonly logger = new Logger(ProductEventEmitter.name);

  constructor(
    private readonly store: ProductEventStore,
    private readonly bus: ProductEventBus,
    private readonly worker: ProductEventWorker,
  ) {}

  async emitEvent(event: ProductEventInput) {
    const normalized = validateEventSchema(event);
    const persisted = await this.store.append(normalized);
    await this.bus.publish(persisted);
    this.worker.processEvent({ ...(normalized as unknown as Record<string, unknown>), id: persisted.id }).catch((e) => this.logger.warn(`Event worker failed: ${(e as Error).message}`));
    return persisted;
  }

  async emitBatchEvents(events: ProductEventInput[]) {
    const normalized = events.map(validateEventSchema);
    const result = await this.store.appendBatch(normalized);
    await Promise.all(normalized.map((event) => this.bus.publish(event)));
    normalized.forEach((event) => this.worker.processEvent(event as unknown as Record<string, unknown>).catch((e) => this.logger.warn(`Event worker failed: ${(e as Error).message}`)));
    return result;
  }

  validateEventSchema(event: ProductEventInput) {
    return validateEventSchema(event);
  }
}
