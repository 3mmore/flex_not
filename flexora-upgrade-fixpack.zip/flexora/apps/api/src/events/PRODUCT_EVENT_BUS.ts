import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { RedisService } from '../config/redis.service';
import { Redis } from 'ioredis';

@Injectable()
export class ProductEventBus implements OnModuleDestroy {
  private readonly logger = new Logger(ProductEventBus.name);
  private readonly channel = 'flexora:product-events';
  private subscriber: Redis | null = null;

  constructor(private readonly redis: RedisService) {}

  async publish(event: unknown) {
    try {
      await this.redis.client.publish(this.channel, JSON.stringify(event));
    } catch (e) {
      this.logger.warn(`Product event publish failed: ${(e as Error).message}`);
    }
  }

  async subscribe(eventType: string, handler: (event: Record<string, unknown>) => void) {
    this.subscriber = this.redis.client.duplicate();
    await this.subscriber.subscribe(this.channel);
    this.subscriber.on('message', (_channel: string, message: string) => {
      try {
        const event = JSON.parse(message) as Record<string, unknown>;
        if (eventType === '*' || event.type === eventType) handler(event);
      } catch (e) {
        this.logger.warn(`Product event subscribe parse failed: ${(e as Error).message}`);
      }
    });
  }

  broadcast(tenantId: string, event: unknown) {
    return this.publish({ tenantId, event });
  }

  streamEvents(tenantId: string) {
    return { channel: this.channel, tenantId };
  }

  onModuleDestroy() {
    if (this.subscriber) this.subscriber.disconnect();
  }
}
