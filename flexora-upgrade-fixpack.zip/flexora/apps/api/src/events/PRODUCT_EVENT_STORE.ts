import { Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../config/prisma.service';
import { NormalizedProductEvent } from './PRODUCT_EVENT_SCHEMA';

@Injectable()
export class ProductEventStore {
  constructor(private readonly prisma: PrismaService) {}

  append(event: NormalizedProductEvent) {
    return this.prisma.productEvent.create({
      data: {
        type: event.type,
        gymId: event.tenantId,
        branchId: event.branchId ?? null,
        userId: event.userId ?? null,
        entityId: event.entityId ?? null,
        payload: event.payload as Prisma.InputJsonValue,
        source: event.source,
        timestamp: event.timestamp,
      },
    });
  }

  appendBatch(events: NormalizedProductEvent[]) {
    if (!events.length) return { count: 0 };
    return this.prisma.productEvent.createMany({
      data: events.map((event) => ({
        type: event.type,
        gymId: event.tenantId,
        branchId: event.branchId ?? null,
        userId: event.userId ?? null,
        entityId: event.entityId ?? null,
        payload: event.payload as Prisma.InputJsonValue,
        source: event.source,
        timestamp: event.timestamp,
      })),
    });
  }

  list(tenantId: string, opts: { from?: Date; to?: Date; type?: string; limit?: number } = {}) {
    return this.prisma.productEvent.findMany({
      where: {
        gymId: tenantId,
        ...(opts.type ? { type: opts.type } : {}),
        ...(opts.from || opts.to ? { timestamp: { ...(opts.from ? { gte: opts.from } : {}), ...(opts.to ? { lte: opts.to } : {}) } } : {}),
      },
      orderBy: { timestamp: 'asc' },
      take: opts.limit ?? 1000,
    });
  }
}
