import { Injectable } from '@nestjs/common';
import { ProductEventStore } from './PRODUCT_EVENT_STORE';

@Injectable()
export class ProductEventReplayEngine {
  constructor(private readonly store: ProductEventStore) {}

  replayEvents(tenantId: string, timeRange: { from?: Date; to?: Date } = {}) {
    return this.store.list(tenantId, timeRange);
  }

  async rebuildBusinessStateFromEvents(tenantId: string) {
    const events = await this.store.list(tenantId, { limit: 10000 });
    return events.reduce<Record<string, number>>((state, event) => {
      state[event.type] = (state[event.type] || 0) + 1;
      return state;
    }, {});
  }

  async simulateSystemState(tenantId: string, timeRange: { from?: Date; to?: Date } = {}) {
    const events = await this.replayEvents(tenantId, timeRange);
    return {
      tenantId,
      eventCount: events.length,
      byType: events.reduce<Record<string, number>>((acc, event) => {
        acc[event.type] = (acc[event.type] || 0) + 1;
        return acc;
      }, {}),
    };
  }
}
