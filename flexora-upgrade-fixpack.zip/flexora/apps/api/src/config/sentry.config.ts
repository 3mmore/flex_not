/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { isProduction } from './env-mode';
import * as Sentry from '@sentry/node';
import { Logger } from '@nestjs/common';
import { maskSensitive } from '../common/security/data-masking';

/**
 * Initialize Sentry error monitoring.
 * Call this early in main.ts, before any other imports.
 * SENTRY_DSN is optional — if missing, Sentry is silently disabled.
 */
export async function initSentry(): Promise<void> {
  const logger = new Logger('Sentry');
  const dsn = process.env.SENTRY_DSN;

  if (!dsn) {
    // No DSN configured — run without error monitoring (acceptable for dev/staging)
    logger.warn('[Sentry] SENTRY_DSN not set — error monitoring disabled');
    return;
  }

  Sentry.init({
    dsn,
    // Environment match (production|staging|development)
    environment: process.env.NODE_ENV || 'development',
    // Release = APP_VERSION or git commit hash
    release: process.env.APP_VERSION || process.env.GIT_SHA || 'unknown',
    // Keep tracing bounded by default; 100% production tracing is a material
    // CPU/network/cost tax at scale. Operators can explicitly tune it.
    tracesSampleRate: Number(process.env.SENTRY_TRACES_SAMPLE_RATE || (isProduction() ? 0.1 : 0.05)),
    integrations: [
      // Capture unhandled promise rejections and uncaught exceptions
      Sentry.onUnhandledRejectionIntegration(),
      Sentry.onUncaughtExceptionIntegration(),
    ],
    // Disable sentry report for health/live endpoints
    ignoreErrors: [
      'Non-Error promise rejection',
    ],
    beforeSend(event) {
      if (event.request?.data) event.request.data = maskSensitive(event.request.data);
      if (event.request?.cookies) event.request.cookies = maskSensitive(event.request.cookies) as Record<string, string>;
      if (event.extra) event.extra = maskSensitive(event.extra);
      return event;
    },
  });

  logger.log(`[Sentry] Initialized — environment: ${process.env.NODE_ENV || 'development'}`);
}

/**
 * Gracefully flush any pending Sentry events before process exit.
 * Call this in OnModuleDestroy or shutdown hooks.
 */
export async function flushSentry(timeoutMs = 2000): Promise<void> {
  await Sentry.flush(timeoutMs);
}