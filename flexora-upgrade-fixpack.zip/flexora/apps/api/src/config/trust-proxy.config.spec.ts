/**
 * PHASE O4.4 — TRUST_PROXY_HOPS.
 *
 * `main.ts` used to hardcode `app.set('trust proxy', 1)`. That number decides how
 * many right-most `X-Forwarded-For` entries express believes when it computes
 * `req.ip`, and `req.ip` is the key for the login rate limiter, the OTP/password
 * reset throttles, the security shield counters and audit entries. Too many
 * trusted hops and a client can spoof its own address (`X-Forwarded-For:
 * 6.6.6.6, <real>`) so no counter ever trips; too few and everybody behind nginx
 * shares one bucket.
 *
 * So the value is configurable, validated at boot (integer 0..3, default 1) and
 * WARN-logged with its effective value every time the API starts in production.
 * The live spoofing behaviour (a throttle key of 203.0.113.9 for
 * `X-Forwarded-For: 6.6.6.6, 203.0.113.9` at hops=1) is proven against a real
 * server in src/test/integration/trust-proxy-throttle.spec.ts.
 */
import { Logger } from '@nestjs/common';

import { validateEnv } from './env-validation';
import {
  DEFAULT_TRUST_PROXY_HOPS,
  MAX_TRUST_PROXY_HOPS,
  MIN_TRUST_PROXY_HOPS,
  TRUST_PROXY_HOPS_VAR,
  logTrustProxyHops,
  trustProxyHops,
  trustProxyProblem,
} from './trust-proxy.config';

const REAL_ENV = { ...process.env } as NodeJS.ProcessEnv;

function withEnv(overrides: Record<string, string | undefined>): void {
  const next: NodeJS.ProcessEnv = { ...REAL_ENV };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === undefined) delete next[key];
    else next[key] = value;
  }
  process.env = next;
}

afterEach(() => {
  process.env = REAL_ENV;
});

describe('PHASE O4.4 — the effective hop count', () => {
  it('defaults to 1 (the shipped nginx config proxies one hop)', () => {
    expect(DEFAULT_TRUST_PROXY_HOPS).toBe(1);
    expect(trustProxyHops({})).toBe(1);
    expect(trustProxyHops({ TRUST_PROXY_HOPS: '' })).toBe(1);
    expect(trustProxyHops({ TRUST_PROXY_HOPS: '   ' })).toBe(1);
  });

  it.each([
    ['0', 0],
    ['1', 1],
    ['2', 2],
    ['3', 3],
    [' 2 ', 2],
  ])('accepts %j -> %i', (raw, expected) => {
    expect(trustProxyHops({ TRUST_PROXY_HOPS: raw })).toBe(expected);
    expect(trustProxyProblem(raw)).toBeNull();
  });

  it.each(['4', '5', '-1', '10', 'abc', '1.5', 'true', '1 hop', '0x1'])(
    'rejects %j and falls back to the documented default',
    (raw) => {
      expect(trustProxyProblem(raw)).not.toBeNull();
      expect(trustProxyHops({ TRUST_PROXY_HOPS: raw })).toBe(DEFAULT_TRUST_PROXY_HOPS);
    },
  );

  it('the rejection message names the variable and the allowed range', () => {
    const problem = trustProxyProblem('7') ?? '';
    expect(problem).toContain(TRUST_PROXY_HOPS_VAR);
    expect(problem).toContain(String(MIN_TRUST_PROXY_HOPS));
    expect(problem).toContain(String(MAX_TRUST_PROXY_HOPS));
    expect(problem).toMatch(/spoof/i);
  });

  it('a non-integer says so, rather than complaining about the range', () => {
    expect(trustProxyProblem('abc')).toContain('not an integer');
  });
});

describe('PHASE O4.4 — validated at boot by env-validation', () => {
  it('an out-of-range value is a production ERROR naming the variable', () => {
    withEnv({ NODE_ENV: 'production', TRUST_PROXY_HOPS: '7' });
    const errors = validateEnv().errors;
    expect(errors.some((e) => e.includes(TRUST_PROXY_HOPS_VAR))).toBe(true);
  });

  it('a non-integer value is a production ERROR too', () => {
    withEnv({ NODE_ENV: 'production', TRUST_PROXY_HOPS: 'many' });
    expect(validateEnv().errors.some((e) => e.includes(TRUST_PROXY_HOPS_VAR))).toBe(true);
  });

  it.each(['development', 'test'])('in %s it is a warning, not a boot failure', (mode) => {
    withEnv({ NODE_ENV: mode, TRUST_PROXY_HOPS: '7' });
    const result = validateEnv();
    expect(result.errors.some((e) => e.includes(TRUST_PROXY_HOPS_VAR))).toBe(false);
    expect(result.warnings.some((w) => w.includes(TRUST_PROXY_HOPS_VAR))).toBe(true);
  });

  it('a valid value adds nothing in any mode', () => {
    for (const mode of ['production', 'development', 'test']) {
      withEnv({ NODE_ENV: mode, TRUST_PROXY_HOPS: '2' });
      const result = validateEnv();
      expect(result.errors.some((e) => e.includes(TRUST_PROXY_HOPS_VAR))).toBe(false);
      expect(result.warnings.some((w) => w.includes(TRUST_PROXY_HOPS_VAR))).toBe(false);
    }
  });
});

describe('PHASE O4.4 — the boot log line', () => {
  const fakeLogger = () => {
    const lines: string[] = [];
    return {
      lines,
      logger: { warn: (m: string) => lines.push(`WARN ${m}`), log: (m: string) => lines.push(`LOG ${m}`) } as unknown as Logger,
    };
  };

  it('WARNs in production with the effective value', () => {
    const { logger, lines } = fakeLogger();
    withEnv({ NODE_ENV: 'production', TRUST_PROXY_HOPS: '2' });
    logTrustProxyHops(logger, trustProxyHops());
    expect(lines).toHaveLength(1);
    expect(lines[0]).toMatch(/^WARN/);
    expect(lines[0]).toContain('trust proxy = 2');
    expect(lines[0]).toContain('TRUST_PROXY_HOPS=2');
    expect(lines[0]).toMatch(/X-Forwarded-For/);
  });

  it('says when the default is in use, so an operator can tell the two apart', () => {
    const { logger, lines } = fakeLogger();
    withEnv({ NODE_ENV: 'production', TRUST_PROXY_HOPS: undefined });
    logTrustProxyHops(logger, trustProxyHops());
    expect(lines[0]).toContain('trust proxy = 1');
    expect(lines[0]).toContain('not set, using the default');
  });

  it('logs (without WARN) outside production, naming the mode', () => {
    const { logger, lines } = fakeLogger();
    withEnv({ NODE_ENV: 'development', TRUST_PROXY_HOPS: '1' });
    logTrustProxyHops(logger, trustProxyHops());
    expect(lines[0]).toMatch(/^LOG/);
    expect(lines[0]).toContain('mode=development');
  });
});
