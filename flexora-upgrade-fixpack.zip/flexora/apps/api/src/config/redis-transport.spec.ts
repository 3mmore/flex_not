/**
 * PHASE O1.4 — Redis transport policy: TLS in production, and a deliberately
 * narrow plaintext opt-out for a genuinely internal Redis.
 *
 * The table below is the one the Phase O brief specifies, verbatim. It exists
 * because the pre-Phase-O rule was `isProduction() && !url.startsWith('rediss://')`
 * in config/redis.service.ts — a string prefix test that (a) made the shipped
 * compose stack impossible to run in production at all, since compose builds a
 * plaintext internal URL, (b) offered no way to say "this Redis is on a private
 * network" other than disabling the check, (c) passed no TLS options, so
 * `rediss://` against a private CA would fail certificate validation anyway, and
 * (d) was not applied at all by two of the three Redis clients
 * (modules/realtime/realtime.gateway.ts and modules/scheduler/
 * scheduler.integration.ts), which would have spoken plaintext in production.
 *
 * NO TEST HERE EVER ASSERTS ON A SECRET VALUE, and several assert that messages
 * do not contain one (the password used below is a fixture, and the rule is that
 * it must never appear in an error).
 */
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

import {
  INTERNAL_HOST_KINDS,
  REDIS_PLAINTEXT_OPT_OUT_VAR,
  assertRedisTransport,
  classifyRedisHost,
  decideRedisTransport,
  hostKindLabel,
  plaintextOptOutEnabled,
  redisConnectionOptions,
  redisTlsOptions,
  redisTransportError,
} from './redis-transport';

const REAL_ENV = { ...process.env } as NodeJS.ProcessEnv;

function withEnv(overrides: Record<string, string | undefined>): void {
  const next: NodeJS.ProcessEnv = { ...REAL_ENV };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === undefined) delete next[key];
    else next[key] = value;
  }
  process.env = next;
}

afterEach(() => {
  process.env = REAL_ENV;
});

/** Fixture credential. It must never appear in a message — several tests say so. */
const PW = 'S3cureRedisPass2026';
const prod = (extra: Record<string, string | undefined> = {}) => ({ NODE_ENV: 'production', ...extra });

describe('PHASE O1.4 — redis transport decision (the brief\'s table)', () => {
  describe('REDIS_ALLOW_PLAINTEXT_INTERNAL=true', () => {
    const accepted: Array<[string, string]> = [
      [`redis://:${PW}@redis:6379`, 'single-label'],
      [`redis://:${PW}@10.0.0.5:6379`, 'private-ip'],
      [`redis://:${PW}@127.0.0.1:6379`, 'loopback'],
      [`redis://:${PW}@localhost:6379`, 'single-label'],
      [`redis://:${PW}@192.168.1.20:6379`, 'private-ip'],
      [`redis://:${PW}@172.16.0.9:6379`, 'private-ip'],
      ['redis://[::1]:6379', 'loopback'],
    ];
    it.each(accepted)('accepts %s (%s)', (url, kind) => {
      withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: 'true' }));
      const d = decideRedisTransport(url);
      expect(d.ok).toBe(true);
      expect(d.tls).toBe(false);
      expect(d.optOutUsed).toBe(true);
      expect(d.hostKind).toBe(kind);
    });

    const refused: Array<[string, string]> = [
      // The trap case: it LOOKS like a private range, but it is a DNS name.
      [`redis://:${PW}@10.evil.com:6379`, 'public-dns'],
      [`redis://:${PW}@redis.example.com:6379`, 'public-dns'],
      [`redis://:${PW}@8.8.8.8:6379`, 'public-ip'],
      [`redis://:${PW}@172.32.0.1:6379`, 'public-ip'],
      [`redis://:${PW}@11.0.0.5:6379`, 'public-ip'],
      [`redis://:${PW}@192.169.1.20:6379`, 'public-ip'],
    ];
    it.each(refused)('REFUSES %s even with the opt-out (%s)', (url, kind) => {
      withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: 'true' }));
      const d = decideRedisTransport(url);
      expect(d.ok).toBe(false);
      expect(d.hostKind).toBe(kind);
      expect(d.reason).toContain(REDIS_PLAINTEXT_OPT_OUT_VAR);
    });

    it('warns loudly when the opt-out is used, naming the variable and the host', () => {
      withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: 'true' }));
      const d = decideRedisTransport(`redis://:${PW}@redis:6379`);
      expect(d.warn).toBeDefined();
      expect(d.warn).toContain(REDIS_PLAINTEXT_OPT_OUT_VAR);
      expect(d.warn).toContain('WITHOUT TLS');
      expect(d.warn).toContain('redis');
    });
  });

  describe('REDIS_ALLOW_PLAINTEXT_INTERNAL unset (the default everywhere)', () => {
    const plain = [
      `redis://:${PW}@redis:6379`,
      `redis://:${PW}@10.0.0.5:6379`,
      `redis://:${PW}@127.0.0.1:6379`,
      `redis://:${PW}@localhost:6379`,
    ];
    it.each(plain)('refuses plaintext %s in production', (url) => {
      withEnv(prod());
      const d = decideRedisTransport(url);
      expect(d.ok).toBe(false);
      expect(d.optOutUsed).toBe(false);
    });

    const tls = [
      `rediss://:${PW}@redis.example.com:6379`,
      `rediss://:${PW}@8.8.8.8:6379`,
      `rediss://:${PW}@redis:6379`,
      `rediss://:${PW}@10.0.0.5:6379`,
      'rediss://[::1]:6379',
    ];
    it.each(tls)('accepts TLS %s regardless of host kind', (url) => {
      withEnv(prod());
      const d = decideRedisTransport(url);
      expect(d.ok).toBe(true);
      expect(d.tls).toBe(true);
      expect(d.optOutUsed).toBe(false);
      expect(d.warn).toBeUndefined();
    });

    it('the refusal says TLS is required AND names the opt-out (the old message did neither)', () => {
      withEnv(prod());
      const reason = redisTransportError(decideRedisTransport(`redis://:${PW}@redis:6379`));
      expect(reason).toContain('REDIS_URL');
      expect(reason).toContain('rediss://');
      expect(reason).toContain('TLS');
      expect(reason).toContain(REDIS_PLAINTEXT_OPT_OUT_VAR);
      expect(reason).toContain('redis-tls'); // the compose profile that ships TLS redis
    });
  });

  it('never enables the opt-out by default, and only the exact string "true" counts', () => {
    expect(plaintextOptOutEnabled({})).toBe(false);
    expect(plaintextOptOutEnabled({ [REDIS_PLAINTEXT_OPT_OUT_VAR]: '' })).toBe(false);
    expect(plaintextOptOutEnabled({ [REDIS_PLAINTEXT_OPT_OUT_VAR]: '1' })).toBe(false);
    expect(plaintextOptOutEnabled({ [REDIS_PLAINTEXT_OPT_OUT_VAR]: 'yes' })).toBe(false);
    expect(plaintextOptOutEnabled({ [REDIS_PLAINTEXT_OPT_OUT_VAR]: 'TRUE' })).toBe(true);
    expect(plaintextOptOutEnabled({ [REDIS_PLAINTEXT_OPT_OUT_VAR]: '  true  ' })).toBe(true);
  });

  it('docker-compose.yml passes the opt-out through but never defaults it to true', () => {
    const compose = readFileSync(join(__dirname, '..', '..', '..', '..', 'docker-compose.yml'), 'utf8');
    // Only real assignments count: the file legitimately *documents* the
    // variable in comments, and a comment is not a default.
    const assignments = compose
      .split('\n')
      .filter((line) => !line.trim().startsWith('#'))
      .filter((line) => /^\s*REDIS_ALLOW_PLAINTEXT_INTERNAL\s*:/.test(line));
    expect(assignments).toHaveLength(1);
    expect(assignments[0]).toContain('${REDIS_ALLOW_PLAINTEXT_INTERNAL:-}');
    expect(assignments.join(' ')).not.toContain(':-true');
    expect(assignments.join(' ')).not.toMatch(/:\s*["']?true/);
  });

  it('development and test keep plaintext Redis working (negative control: the local flow)', () => {
    for (const mode of ['development', 'test']) {
      withEnv({ NODE_ENV: mode, REDIS_URL: `redis://:${PW}@localhost:6379` });
      const d = decideRedisTransport(process.env.REDIS_URL);
      expect(d.ok).toBe(true);
      expect(d.optOutUsed).toBe(false);
      expect(d.warn).toBeUndefined();
    }
    // NODE_ENV unset is PRODUCTION (config/env-mode.ts fails closed), so it refuses.
    withEnv({ NODE_ENV: undefined });
    expect(decideRedisTransport(`redis://:${PW}@localhost:6379`).ok).toBe(false);
  });

  it('no refusal or warning ever contains the password', () => {
    const urls = [
      `redis://:${PW}@redis:6379`,
      `redis://:${PW}@10.evil.com:6379`,
      `redis://:${PW}@8.8.8.8:6379`,
      `rediss://:${PW}@redis.example.com:6379`,
    ];
    for (const flag of [undefined, 'true']) {
      withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: flag, REDIS_URL: urls[0] }));
      for (const url of urls) {
        const d = decideRedisTransport(url);
        for (const text of [d.reason, d.warn, redisTransportError(d)]) {
          if (text) expect(text).not.toContain(PW);
        }
      }
    }
  });
});

describe('PHASE O1.4 — host classification (net.isIP first, never a string prefix)', () => {
  const cases: Array<[string, string]> = [
    ['redis', 'single-label'],
    ['localhost', 'single-label'],
    ['REDIS', 'single-label'],
    ['127.0.0.1', 'loopback'],
    ['127.5.5.5', 'loopback'],
    ['10.0.0.5', 'private-ip'],
    ['10.255.255.255', 'private-ip'],
    ['172.16.0.1', 'private-ip'],
    ['172.31.255.255', 'private-ip'],
    ['172.15.0.1', 'public-ip'],
    ['172.32.0.1', 'public-ip'],
    ['192.168.0.1', 'private-ip'],
    ['192.169.0.1', 'public-ip'],
    ['8.8.8.8', 'public-ip'],
    ['1.1.1.1', 'public-ip'],
    ['10.evil.com', 'public-dns'],
    ['redis.example.com', 'public-dns'],
    ['172.16.0.1.nip.io', 'public-dns'],
    ['redis.internal.', 'public-dns'],
    ['::1', 'loopback'],
    ['[::1]', 'loopback'],
    ['fe80::1', 'public-ip'],
    ['fd00::1', 'public-ip'],
    ['', 'unparseable'],
  ];
  it.each(cases)('classifyRedisHost(%j) === %s', (host, kind) => {
    expect(classifyRedisHost(host)).toBe(kind);
  });

  it('only loopback, private-ip and single-label qualify as internal', () => {
    expect([...INTERNAL_HOST_KINDS].sort()).toEqual(['loopback', 'private-ip', 'single-label']);
    for (const kind of INTERNAL_HOST_KINDS) expect(hostKindLabel(kind)).toBeTruthy();
  });
});

describe('PHASE O1.4 — malformed and wrong-scheme URLs', () => {
  it('an unparseable REDIS_URL is an error naming the variable, never echoing the value', () => {
    withEnv(prod());
    const raw = `redis://:${PW}@bad host:6379`;
    const d = decideRedisTransport(raw);
    expect(d.ok).toBe(false);
    expect(d.hostKind).toBe('unparseable');
    expect(d.reason).toContain('REDIS_URL');
    expect(d.reason).not.toContain(PW);
    expect(() => assertRedisTransport(raw)).toThrow(/REDIS_URL/);
  });

  it('a wrong scheme is refused', () => {
    withEnv(prod());
    const d = decideRedisTransport(`http://:${PW}@redis:6379`);
    expect(d.ok).toBe(false);
    expect(d.reason).toContain('redis://');
    expect(d.reason).not.toContain(PW);
  });

  it('an empty/unset REDIS_URL is refused with the variable name', () => {
    withEnv(prod({ REDIS_URL: undefined }));
    expect(decideRedisTransport(undefined).reason).toContain('REDIS_URL');
    expect(decideRedisTransport('   ').ok).toBe(false);
  });

  it('assertRedisTransport returns the decision when it is acceptable', () => {
    withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: 'true' }));
    expect(assertRedisTransport(`redis://:${PW}@redis:6379`).optOutUsed).toBe(true);
  });
});

describe('PHASE O1.4 — TLS material for rediss://', () => {
  let dir: string;
  beforeAll(() => {
    dir = mkdtempSync(join(tmpdir(), 'redis-tls-spec-'));
  });
  afterAll(() => {
    rmSync(dir, { recursive: true, force: true });
  });

  it('reads a CA file when REDIS_TLS_CA_FILE is set, and verifies by default', () => {
    const ca = join(dir, 'ca.crt');
    writeFileSync(ca, '-----BEGIN CERTIFICATE-----\nfixture\n-----END CERTIFICATE-----\n');
    const options = redisTlsOptions({ REDIS_TLS_CA_FILE: ca });
    expect(options.rejectUnauthorized).toBe(true);
    expect(options.ca).toContain('BEGIN CERTIFICATE');
  });

  it('rejectUnauthorized can be turned off explicitly (private CA, no file)', () => {
    expect(redisTlsOptions({ REDIS_TLS_REJECT_UNAUTHORIZED: 'false' }).rejectUnauthorized).toBe(false);
    expect(redisTlsOptions({ REDIS_TLS_REJECT_UNAUTHORIZED: 'FALSE' }).rejectUnauthorized).toBe(false);
    expect(redisTlsOptions({}).rejectUnauthorized).toBe(true);
  });

  it('a certificate path that does not exist names the VARIABLE, not the contents', () => {
    expect(() => redisTlsOptions({ REDIS_TLS_CA_FILE: join(dir, 'missing.crt') })).toThrow(/REDIS_TLS_CA_FILE/);
    expect(() => redisTlsOptions({ REDIS_TLS_KEY_FILE: join(dir, 'missing.key') })).toThrow(/REDIS_TLS_KEY_FILE/);
  });

  it('redisConnectionOptions attaches tls only for rediss://', () => {
    withEnv(prod());
    const tlsDecision = decideRedisTransport(`rediss://:${PW}@redis.example.com:6379`);
    expect(Object.keys(redisConnectionOptions(tlsDecision))).toEqual(['tls']);
    withEnv(prod({ REDIS_ALLOW_PLAINTEXT_INTERNAL: 'true' }));
    const plainDecision = decideRedisTransport(`redis://:${PW}@redis:6379`);
    expect(redisConnectionOptions(plainDecision)).toEqual({});
  });
});
