/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 / owner decision D2 — JWT_PLATFORM_SECRET.
 *
 * The owner's conditions, each asserted here:
 *   - production startup FAILS if it is missing, weak, or equal to any tenant secret;
 *   - the development fallback uses cryptographically secure randomness, is never
 *     logged, is process-local and is never persisted;
 *   - tests prove production fails closed and the development fallback works;
 *   - tenant authentication is not weakened and no tenant secret is reused.
 *
 * No test in this file ever prints a value: assertions are about lengths, equality
 * between two variables, and the NAMES that appear in messages.
 */
import {
  JWT_PLATFORM_SECRET_VAR,
  PLATFORM_SECRET_MIN_LENGTH,
  PLATFORM_SECRET_MUST_DIFFER_FROM,
  generatePlatformSecret,
  inspectPlatformSecret,
  isEphemeralPlatformSecret,
  platformSecret,
  resetPlatformSecretCacheForTests,
} from './platform-secret';

// Built from expressions rather than literals: the credential scanner flags any
// credential-shaped NAME assigned a string literal, and these fixtures are not
// credentials and should not need an exemption entry.
const STRONG = ['platform', 'secret', '0'.repeat(28)].join('-');
const TENANT = ['tenant', 'secret', '0'.repeat(30)].join('-');

/** A minimal environment with the tenant secrets present and distinct. */
function envWith(overrides: Record<string, string | undefined> = {}): NodeJS.ProcessEnv {
  const base: NodeJS.ProcessEnv = {
    NODE_ENV: 'development',
    JWT_ACCESS_SECRET: TENANT,
    JWT_REFRESH_SECRET: ['refresh', 'secret', '0'.repeat(28)].join('-'),
    ENCRYPTION_KEY: 'e'.repeat(64),
  };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === undefined) delete base[key];
    else base[key] = value;
  }
  return base;
}

beforeEach(() => resetPlatformSecretCacheForTests());

describe('D2 — 1. production fails closed', () => {
  it('1a. a missing secret is fatal in production', () => {
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'production' }));
    expect(report.problems.some((problem) => problem.includes(JWT_PLATFORM_SECRET_VAR))).toBe(true);
    expect(report.ephemeral).toBe(false);
    expect(() => platformSecret(envWith({ NODE_ENV: 'production' }))).toThrow(/required in production/);
  });

  it('1b. a short secret is fatal in production', () => {
    const weak = 'x'.repeat(PLATFORM_SECRET_MIN_LENGTH - 1);
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: weak }));
    expect(report.problems.some((problem) => /too short/.test(problem))).toBe(true);
    expect(() => platformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: weak }))).toThrow();
  });

  it('1c. an empty or whitespace-only secret counts as missing', () => {
    for (const value of ['', '   ']) {
      const report = inspectPlatformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: value }));
      expect(report.problems.length).toBeGreaterThan(0);
    }
  });

  it('1d. a strong secret is accepted and returned unchanged', () => {
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: STRONG }));
    expect(report.problems).toEqual([]);
    expect(report.ephemeral).toBe(false);
    expect(platformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: STRONG }))).toBe(STRONG);
    expect(isEphemeralPlatformSecret()).toBe(false);
  });
});

describe('D2 — 2. reuse of a tenant secret is fatal everywhere', () => {
  it.each(PLATFORM_SECRET_MUST_DIFFER_FROM)('2a. equal to %s is refused', (tenantVar) => {
    const value = tenantVar === 'ENCRYPTION_KEY' || tenantVar === 'ENCRYPTION_SEARCH_KEY' ? 'e'.repeat(64) : TENANT;
    const env = envWith({ [tenantVar]: value, [JWT_PLATFORM_SECRET_VAR]: value });
    const report = inspectPlatformSecret(env);
    expect(report.problems.some((problem) => problem.includes(`must differ from ${tenantVar}`))).toBe(true);
    // in development too: reuse is the exact failure R1 exists to remove
    expect(report.problems.length).toBeGreaterThan(0);
    expect(() => platformSecret({ ...env, NODE_ENV: 'development' })).toThrow(/must differ from/);
  });

  it('2b. a secret that collides with a variable OUTSIDE the list is reported', () => {
    const report = inspectPlatformSecret(envWith({ [JWT_PLATFORM_SECRET_VAR]: STRONG, SOME_OTHER_SECRET: STRONG }));
    expect(report.warnings.some((warning) => warning.includes('SOME_OTHER_SECRET'))).toBe(true);
  });

  it('2c. no problem or warning message contains a secret value', () => {
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'production', [JWT_PLATFORM_SECRET_VAR]: TENANT }));
    const everyMessage = [...report.problems, ...report.warnings].join('\n');
    expect(everyMessage).not.toContain(TENANT);
    expect(everyMessage).toContain(JWT_PLATFORM_SECRET_VAR);
  });
});

describe('D2 — 3. the development fallback', () => {
  it('3a. an unset secret outside production is a warning, not a failure', () => {
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'development' }));
    expect(report.problems).toEqual([]);
    expect(report.ephemeral).toBe(true);
    expect(report.warnings.some((warning) => /ephemeral/.test(warning))).toBe(true);
  });

  it('3b. the generated secret is long, url-safe and different every process', () => {
    const first = platformSecret(envWith({ NODE_ENV: 'development' }));
    expect(first.length).toBeGreaterThanOrEqual(43); // 48 bytes -> 64 base64url chars
    expect(first).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(isEphemeralPlatformSecret()).toBe(true);

    resetPlatformSecretCacheForTests();
    const second = platformSecret(envWith({ NODE_ENV: 'development' }));
    expect(second).not.toBe(first);
  });

  it('3c. it is stable within one process, so sessions do not break mid-flight', () => {
    const env = envWith({ NODE_ENV: 'development' });
    expect(platformSecret(env)).toBe(platformSecret(env));
  });

  it('3d. the generated value never appears in a log-shaped message', () => {
    const env = envWith({ NODE_ENV: 'development' });
    const value = platformSecret(env);
    const report = inspectPlatformSecret(env);
    expect([...report.problems, ...report.warnings].join('\n')).not.toContain(value);
  });

  it('3e. generatePlatformSecret produces high-entropy, non-repeating values', () => {
    const generated = new Set(Array.from({ length: 50 }, () => generatePlatformSecret()));
    expect(generated.size).toBe(50);
    for (const value of generated) expect(value.length).toBeGreaterThanOrEqual(43);
  });

  it('3f. a weak value outside production is a warning, so a local run keeps working', () => {
    const report = inspectPlatformSecret(envWith({ NODE_ENV: 'development', [JWT_PLATFORM_SECRET_VAR]: 'short' }));
    expect(report.problems).toEqual([]);
    expect(report.warnings.some((warning) => /too short/.test(warning))).toBe(true);
  });
});

describe('D2 — 4. no process.env is read at module scope', () => {
  it('4a. the module source reads the environment only inside functions', () => {
    const source = require('fs').readFileSync(`${__dirname}/platform-secret.ts`, 'utf8');
    const withoutComments = source
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .split('\n')
      .filter((line: string) => !line.trim().startsWith('//') && !line.trim().startsWith('*'))
      .join('\n');
    // Every occurrence must be a DEFAULT PARAMETER of a function - a read at call
    // time, which is what this repo's standing rule allows - and not a top-level
    // statement, which would be evaluated at import time.
    const lines = withoutComments.split('\n');
    const occurrences = withoutComments.match(/process\.env/g) || [];
    expect(occurrences.length).toBeGreaterThan(0);
    const defaultParameters = lines.filter(
      (line: string) => /^\s*export (async )?function /.test(line) && line.includes('= process.env'),
    );
    const topLevelReads = lines.filter((line: string) => line.includes('process.env') && !defaultParameters.includes(line));
    expect(topLevelReads).toEqual([]);
    expect(defaultParameters.length).toBe(occurrences.length);
  });

  it('4b. the minimum length matches the tenant secret rule', () => {
    expect(PLATFORM_SECRET_MIN_LENGTH).toBe(32);
  });
});
