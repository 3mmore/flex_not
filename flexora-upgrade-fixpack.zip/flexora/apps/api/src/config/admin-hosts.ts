/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console host allow-list.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * The platform console lives in the SAME api and the SAME web bundle as the gym
 * product, so anyone who can reach the public hostname can ask it for
 * `/api/platform/overview` and learn that an admin console exists (and then attack
 * its login). `ADMIN_HOSTS` is the list of hostnames the console is allowed to be
 * served on; every other hostname gets a plain 404 that is byte-for-byte
 * indistinguishable from an unknown route.
 *
 * THIS IS AN ISOLATION LAYER, NOT AN AUTHENTICATION LAYER (owner decision, R0).
 * An attacker who can open a TCP connection to the api directly can send
 * `Host: localhost` and pass this gate. It exists to keep the console off the
 * public origin - no link, no redirect, no header, no robots entry - so that the
 * authentication, authorization and network controls remain the actual defence.
 * Nothing here may be treated as a substitute for them, and nothing here may
 * introduce implicit trust.
 *
 * HEADER SELECTION (rule: never trust X-Forwarded-Host unless TRUST_PROXY_HOPS
 * says otherwise, and never let a forwarded header WIDEN access):
 *
 *   1. the candidate is always the `Host` header (hostname, port stripped);
 *   2. when TRUST_PROXY_HOPS is 0/unset, X-Forwarded-Host is not consulted at all;
 *   3. when TRUST_PROXY_HOPS > 0 and X-Forwarded-Host IS present, it must agree
 *      with the candidate. A disagreement means somebody is trying to smuggle a
 *      hostname past the gate, so the request is refused either way - including the
 *      case where Host is allowed and the forwarded value is not. Fail closed on
 *      ambiguity; the fix for a legitimate deployment is a proxy that forwards a
 *      consistent Host, never a looser gate.
 *
 * NO process.env IS READ AT MODULE SCOPE. Every function reads the environment at
 * call time, so a test (or a config reload) that changes ADMIN_HOSTS is honoured
 * immediately and no value is captured before `.env` has been loaded.
 */
import { trustProxyHops } from './trust-proxy.config';

/** Name of the variable, exported so the validator and compose guard share it. */
export const ADMIN_HOSTS_VAR = 'ADMIN_HOSTS';

/**
 * Development default. Deliberately loopback-only: a fresh checkout gets "trial
 * mode", where the console is reachable from the owner's own machine and from
 * nowhere else. It is never a wildcard and never empty.
 */
export const ADMIN_HOSTS_DEV_DEFAULT = 'localhost,127.0.0.1';

/** One parsed entry: either a bare hostname or an exact `host:port` pair. */
export interface AdminHostEntry {
  /** Lowercased hostname, no port, no scheme, no path. */
  readonly hostname: string;
  /** Port as written in the entry, or undefined for a bare hostname. */
  readonly port?: string;
}

export interface AdminHostsConfig {
  /** Raw value of ADMIN_HOSTS as seen at call time (trimmed). */
  readonly raw: string;
  /** Parsed entries, in the order written. */
  readonly entries: readonly AdminHostEntry[];
  /** True when the value came from the development default rather than the env. */
  readonly usingDevDefault: boolean;
  /** Entries that could not be parsed, reported verbatim so the operator can fix them. */
  readonly invalid: readonly string[];
}

/** True for a value that means "everything", in any of the shapes people write. */
/**
 * RFC 6761 reserves the `.invalid` top-level domain: a name under it can never
 * resolve, which is exactly why nginx uses `host-gate.denied.invalid` as the Host
 * it hands upstream for a console request that arrived on a public hostname (see
 * nginx/nginx.conf). If that name could be allow-listed through ADMIN_HOSTS, the
 * edge's own denial signal would become an entry ticket, so it is rejected here:
 * a reserved entry is dropped from the allow-list (fail closed, in every NODE_ENV)
 * and reported as a configuration problem.
 */
export const RESERVED_INVALID_HOSTNAME = 'invalid';
export const NGINX_GATE_HOSTNAME = 'host-gate.denied.invalid';

function isReservedInvalidName(hostname: string): boolean {
  const h = hostname.trim().toLowerCase();
  return h === RESERVED_INVALID_HOSTNAME || h.endsWith(`.${RESERVED_INVALID_HOSTNAME}`);
}

function isWildcardToken(token: string): boolean {
  const t = token.trim().toLowerCase();
  return t === '*' || t === '*.*' || t === 'all' || t === 'any' || t.startsWith('*.') || t.endsWith('.*');
}

/**
 * Split and parse the raw value. Parsing never throws: an unparsable entry is
 * collected in `invalid` so the validator can name it, and it is NOT added to the
 * allow-list (an entry we cannot understand must never widen access).
 */
export function parseAdminHosts(raw: string | undefined): AdminHostsConfig {
  const value = String(raw ?? '').trim();
  const entries: AdminHostEntry[] = [];
  const invalid: string[] = [];
  for (const piece of value.split(',')) {
    const token = piece.trim();
    if (!token) continue;
    if (isWildcardToken(token)) {
      invalid.push(token);
      continue;
    }
    // A scheme, a path or a query in an "admin host" is a configuration mistake,
    // not a hostname. Refuse to guess what the operator meant.
    if (/[/?#]/.test(token) || /^[a-z][a-z0-9+.-]*:\/\//i.test(token)) {
      invalid.push(token);
      continue;
    }
    // IPv6 literals may be bracketed (`[::1]`) and may carry a port (`[::1]:8443`).
    let hostname = token.toLowerCase();
    let port: string | undefined;
    if (hostname.startsWith('[')) {
      const close = hostname.indexOf(']');
      if (close === -1) {
        invalid.push(token);
        continue;
      }
      const literal = hostname.slice(1, close);
      const rest = hostname.slice(close + 1);
      if (rest && !rest.startsWith(':')) {
        invalid.push(token);
        continue;
      }
      if (rest.length > 1) port = rest.slice(1);
      hostname = literal;
      if (!isPlainIpv6(hostname)) {
        invalid.push(token);
        continue;
      }
    } else if ((hostname.match(/:/g) || []).length >= 2) {
      // A bare IPv6 literal (`::1`, `2001:db8::5`). Two or more colons can only be
      // IPv6 - treating it as host:port would reject the loopback entry an operator
      // is most likely to write. A port with an IPv6 literal MUST be bracketed
      // (`[::1]:8443`) because `::1:8443` is genuinely ambiguous.
      if (!isPlainIpv6(hostname)) {
        invalid.push(token);
        continue;
      }
    } else if (hostname.includes(':')) {
      const parts = hostname.split(':');
      if (parts.length !== 2 || !parts[1]) {
        invalid.push(token);
        continue;
      }
      hostname = parts[0];
      port = parts[1];
    }
    hostname = stripRootDot(hostname);
    if (!isHostname(hostname)) {
      invalid.push(token);
      continue;
    }
    // A reserved `.invalid` name is never a usable admin host (see above). It is
    // reported through `invalid` so adminHostsProblems() can name it explicitly.
    if (isReservedInvalidName(hostname)) {
      invalid.push(token);
      continue;
    }
    if (port !== undefined && !/^\d{1,5}$/.test(port)) {
      invalid.push(token);
      continue;
    }
    entries.push(port === undefined ? { hostname } : { hostname, port });
  }
  return { raw: value, entries, usingDevDefault: false, invalid };
}

function isPlainIpv6(value: string): boolean {
  return /^[0-9a-f:]+$/.test(value) && value.includes(':');
}

/** A hostname is letters, digits, hyphens and dots - no wildcard, no underscore. */
function isHostname(value: string): boolean {
  if (!value || value.length > 253) return false;
  if (value.includes('*')) return false;
  if (/^[0-9a-f:]+$/.test(value) && value.includes(':')) return true; // bare IPv6
  return /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/.test(
    value,
  );
}

/**
 * The effective configuration at call time. Outside production an unset or empty
 * value falls back to the loopback-only development default; in production that
 * fallback does NOT apply - an unset value is an error the boot validator reports
 * (see `adminHostsProblems`), and this function returns an empty allow-list, which
 * refuses every host. Failing closed beats failing open.
 */
export function adminHostsConfig(nodeEnv: string = process.env.NODE_ENV || ''): AdminHostsConfig {
  const raw = process.env[ADMIN_HOSTS_VAR];
  const production = String(nodeEnv).toLowerCase() === 'production';
  if (!raw || !raw.trim()) {
    if (production) return { raw: '', entries: [], usingDevDefault: false, invalid: [] };
    const fallback = parseAdminHosts(ADMIN_HOSTS_DEV_DEFAULT);
    return { ...fallback, raw: '', usingDevDefault: true };
  }
  return parseAdminHosts(raw);
}

/** The allow-list as a plain array of hostnames (ports kept in their own form). */
export function adminHosts(nodeEnv?: string): string[] {
  return adminHostsConfig(nodeEnv).entries.map((e) => (e.port ? `${e.hostname}:${e.port}` : e.hostname));
}

/**
 * Boot-time problems with ADMIN_HOSTS, as human-readable sentences that name the
 * variable and never echo a secret. Empty array = usable configuration.
 */
export function adminHostsProblems(nodeEnv: string = process.env.NODE_ENV || ''): string[] {
  const production = String(nodeEnv).toLowerCase() === 'production';
  const raw = process.env[ADMIN_HOSTS_VAR];
  const problems: string[] = [];
  const value = String(raw ?? '').trim();

  if (!value) {
    if (production) {
      problems.push(
        `${ADMIN_HOSTS_VAR} is required in production: list the hostname(s) the owner console is served on ` +
          `(for example admin.example.com). It must never be empty and never a wildcard.`,
      );
    }
    return problems;
  }
  for (const piece of value.split(',')) {
    const token = piece.trim();
    if (!token) {
      problems.push(`${ADMIN_HOSTS_VAR} contains an empty entry - remove the stray comma`);
      continue;
    }
    if (isWildcardToken(token)) {
      problems.push(
        `${ADMIN_HOSTS_VAR} must never contain a wildcard ("${token}"): a console that answers on every ` +
          `hostname is a console on the public origin`,
      );
      continue;
    }
    if (isReservedInvalidName(token.replace(/:\d+$/, ''))) {
      problems.push(
        `${ADMIN_HOSTS_VAR} must never contain a reserved ".invalid" name ("${token}"): nginx uses ` +
          `${NGINX_GATE_HOSTNAME} as the denial Host for console requests on a public hostname, so ` +
          `allow-listing it would turn the edge's own refusal into an entry ticket`,
      );
    }
  }
  const parsed = parseAdminHosts(value);
  for (const bad of parsed.invalid) {
    if (!isWildcardToken(bad) && !isReservedInvalidName(bad.replace(/:\d+$/, ''))) {
      problems.push(`${ADMIN_HOSTS_VAR} contains "${bad}", which is not a plain hostname or host:port (no scheme, path or wildcard)`);
    }
  }
  if (parsed.entries.length === 0 && problems.length === 0) {
    problems.push(`${ADMIN_HOSTS_VAR} did not yield a single usable hostname`);
  }
  return problems;
}

/**
 * Split a `Host` header value into hostname and port. Handles bracketed IPv6.
 * The port is returned as written so an entry may pin it.
 */
export function splitHostHeader(value: string | undefined): { hostname: string; port?: string; raw: string } {
  const raw = String(value ?? '').trim().toLowerCase();
  if (!raw) return { hostname: '', raw: '' };
  if (raw.startsWith('[')) {
    const close = raw.indexOf(']');
    if (close === -1) return { hostname: stripRootDot(raw), raw };
    const hostname = raw.slice(1, close);
    const rest = raw.slice(close + 1);
    const port = rest.startsWith(':') && rest.length > 1 ? rest.slice(1) : undefined;
    return { hostname: stripRootDot(hostname), port, raw };
  }
  const idx = raw.lastIndexOf(':');
  if (idx === -1) return { hostname: stripRootDot(raw), raw };
  const maybePort = raw.slice(idx + 1);
  if (!/^\d{1,5}$/.test(maybePort)) return { hostname: stripRootDot(raw), raw };
  return { hostname: stripRootDot(raw.slice(0, idx)), port: maybePort, raw };
}

/**
 * A single trailing dot is the DNS root label: `admin.example.com.` IS
 * `admin.example.com`. It is stripped from both the configured entries and the
 * request, so an operator whose client happens to send the fully-qualified form is
 * not locked out of their own console, and no dotted spelling becomes an oracle.
 * A bare "." collapses to "" and is refused like any other unusable host.
 */
export function stripRootDot(hostname: string): string {
  return hostname.length > 1 && hostname.endsWith('.') ? hostname.slice(0, -1) : hostname;
}

/** The verdict for one request, with the reason - so a refusal can be logged honestly. */
export type AdminHostVerdict =
  | { readonly allowed: true; readonly matched: string }
  | { readonly allowed: false; readonly reason: 'unset' | 'host-mismatch' | 'forwarded-host-disagrees' | 'missing-host' };

export interface GateHeaders {
  readonly host?: string;
  readonly 'x-forwarded-host'?: string;
}

/**
 * Decide whether a request may reach the owner console.
 *
 * `trustProxyHops` is the operator's declared number of proxies (TRUST_PROXY_HOPS).
 * When it is 0 - or unset - X-Forwarded-Host is not consulted at all. When it is
 * >0 the forwarded value must AGREE with Host; disagreement refuses the request
 * rather than picking a winner, so a forwarded header can never widen access.
 */
export function adminHostVerdict(
  headers: GateHeaders,
  config: AdminHostsConfig = adminHostsConfig(),
  trustProxyHops: number = effectiveTrustProxyHops(),
): AdminHostVerdict {
  const hostHeader = String(headers.host ?? '').trim();
  if (!hostHeader) return { allowed: false, reason: 'missing-host' };
  const { hostname, port, raw } = splitHostHeader(hostHeader);

  // The agreement check compares HOSTNAMES, not host:port. A port in a forwarded
  // header is usually the port the client dialed (443) while Host carries the port
  // this server listens on, so requiring the ports to match would refuse legitimate
  // proxy chains and lock the owner out of their own console. The security property
  // the check exists for - a forwarded header must never smuggle a different
  // hostname past the gate - is fully covered by the hostname comparison, and the
  // allow-list match on the Host header still honours a pinned port entry.
  const forwarded = String(headers['x-forwarded-host'] ?? '')
    .trim()
    .toLowerCase();
  if (forwarded && trustProxyHops > 0) {
    // A comma list is possible when several proxies appended to it; with N declared
    // hops the value N-from-the-right is the one the trusted proxy wrote. Anything
    // else is client-supplied noise, and noise must not decide the gate.
    const parts = forwarded.split(',').map((p) => p.trim()).filter(Boolean);
    const idx = Math.max(0, parts.length - trustProxyHops);
    const trusted = splitHostHeader(parts[idx]).hostname;
    if (trusted !== hostname) return { allowed: false, reason: 'forwarded-host-disagrees' };
  }

  if (config.entries.length === 0) return { allowed: false, reason: 'unset' };
  for (const entry of config.entries) {
    if (entry.port) {
      if (entry.hostname === hostname && entry.port === port) return { allowed: true, matched: raw };
      continue;
    }
    if (entry.hostname === hostname) return { allowed: true, matched: raw };
  }
  return { allowed: false, reason: 'host-mismatch' };
}

/** Convenience wrapper used by the guard and by middleware-level code. */
export function isAdminHost(headers: GateHeaders, nodeEnv?: string): boolean {
  return adminHostVerdict(headers, adminHostsConfig(nodeEnv)).allowed;
}

/**
 * The SAME hop count Express is configured with in main.ts (`app.set('trust proxy',
 * trustProxyHops())`), so the gate and `req.ip`/`req.hostname` never disagree about
 * how many proxies are trusted. Unset means the documented default (1 = the shipped
 * nginx config), which is why a forwarded host that contradicts Host is refused
 * rather than believed.
 */
function effectiveTrustProxyHops(): number {
  return trustProxyHops();
}
