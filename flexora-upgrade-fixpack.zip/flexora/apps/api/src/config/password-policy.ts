/**
 * PHASE O3.1 — the credential policy, in one place.
 *
 * WHAT WAS WRONG WITH CLASS-COUNTING
 * ----------------------------------
 * "At least three of lower/upper/digit/symbol" measures how a password is
 * *decorated*, not how hard it is to guess. It rejects `openssl rand -hex 24`
 * (248 bits of entropy, two classes) while accepting `Password123456!` (four
 * classes, and in every attacker's first dictionary). It also rejected
 * `Zq9TxtestK7mWp2RvB4nL8cD` purely because the substring "test" happens to
 * appear in a genuinely random value.
 *
 * WHAT THIS DOES INSTEAD
 * ----------------------
 * length >= 16, an entropy floor, and pattern rules that catch what entropy
 * alone cannot: a single character repeated, a short pattern tiled across the
 * whole value, an alphabetical/numeric run, a keyboard walk. Development tokens
 * are handled in two tiers — as a standalone segment they are always rejected
 * (that is a human writing `flexora_dev_pw`), inside an otherwise random value
 * they are only rejected below 24 characters / the entropy floor (that is
 * `openssl rand` happening to spell "test").
 *
 * Nothing here ever echoes the value it is given: messages carry lengths, counts
 * and — for tokens — the token itself, which comes from a fixed public list.
 */

export const MIN_PASSWORD_LENGTH = 16;
export const MIN_ENTROPY_BITS = 60;
/** Length at which a value is believed to be generated even if it contains a token. */
export const GENERATED_LENGTH = 24;

/** Character pools, summed over the pools the value actually uses. */
const POOLS: ReadonlyArray<{ re: RegExp; size: number }> = [
  { re: /[a-z]/, size: 26 },
  { re: /[A-Z]/, size: 26 },
  { re: /[0-9]/, size: 10 },
  { re: /[^A-Za-z0-9]/, size: 32 },
];

/** Keyboard rows and common walks, both directions. */
const KEYBOARD_RUNS: readonly string[] = [
  'qwertyuiop', 'asdfghjkl', 'zxcvbnm', 'qazwsx', '1qaz2wsx', '1q2w3e4r',
  'zaq1xsw2', 'qweasd', '!@#$%^&*()',
];

export function alphabetPoolSize(value: string): number {
  return POOLS.filter((p) => p.re.test(value)).reduce((n, p) => n + p.size, 0);
}

/**
 * Estimated entropy in bits: length * log2(pool). This is the standard
 * "guessing space" estimate, not Shannon entropy over the observed character
 * distribution — the latter rewards `aaaaaaaaaaaaaaaaaaaaab` for having two
 * distinct characters, which is exactly the wrong answer here.
 */
export function entropyBits(value: string): number {
  const v = value.trim();
  if (!v) return 0;
  const pool = alphabetPoolSize(v);
  if (pool <= 1) return 0;
  return Math.round(v.length * Math.log2(pool));
}

export function distinctCharacters(value: string): number {
  return new Set(value.trim()).size;
}

/** Longest run of consecutive characters ascending or descending by exactly 1. */
export function longestMonotonicRun(value: string): number {
  const v = value.trim();
  let best = 1;
  let run = 1;
  for (let i = 1; i < v.length; i++) {
    const d = v.charCodeAt(i) - v.charCodeAt(i - 1);
    if (d === 1 || d === -1) {
      run += 1;
      if (run > best) best = run;
    } else {
      run = 1;
    }
  }
  return v.length ? best : 0;
}

/** Length of the longest keyboard-row substring present (either direction). */
export function longestKeyboardRun(value: string): number {
  const v = value.trim().toLowerCase();
  let best = 0;
  for (const row of KEYBOARD_RUNS) {
    const rev = [...row].reverse().join('');
    for (let len = Math.min(row.length, v.length); len >= 4; len--) {
      for (let i = 0; i + len <= row.length; i++) {
        const fwd = row.slice(i, i + len);
        const bwd = rev.slice(rev.length - i - len, rev.length - i);
        if (v.includes(fwd) || v.includes(bwd)) {
          if (len > best) best = len;
          break;
        }
      }
    }
  }
  return best;
}

/**
 * The shortest period P such that the whole value is that block tiled at least
 * twice: `Flexora2026!Flexora2026!` has period 12. Entropy alone cannot see this
 * (the tiled value looks diverse), so it gets its own rule.
 */
export function repetitionPeriod(value: string): number | null {
  const v = value.trim();
  for (let p = 1; p <= Math.floor(v.length / 2); p++) {
    if (v.length % p !== 0) continue;
    const block = v.slice(0, p);
    if (block.repeat(v.length / p) === v) return p;
  }
  return null;
}

/** A run of the same character this long is never a generated secret. */
export const MAX_SINGLE_CHAR_RUN = 4;

export function longestSingleCharRun(value: string): number {
  const v = value.trim();
  let best = 0;
  let run = 0;
  let prev = '';
  for (const c of v) {
    run = c === prev ? run + 1 : 1;
    prev = c;
    if (run > best) best = run;
  }
  return best;
}

/**
 * Where a development token appears, if anywhere.
 *  - `segment`: the whole value, or a `_`/`-`/`.`/space-delimited part of it, or a
 *    leading/trailing alphabetic chunk. Always rejected: a human typed it.
 *  - `inner`: buried inside a longer random-looking value. Rejected only when the
 *    value is short or low-entropy, i.e. when it is NOT plausibly generated.
 */
export function devTokenOccurrence(
  value: string,
  tokens: readonly string[],
): { token: string; kind: 'segment' | 'inner' } | null {
  const v = value.trim().toLowerCase();
  if (!v) return null;
  const parts = v.split(/[^a-z0-9]+/).filter(Boolean);
  for (const tok of tokens) {
    const t = tok.toLowerCase();
    if (v === t || parts.includes(t)) return { token: tok, kind: 'segment' };
    if (v.startsWith(t) || v.endsWith(t)) return { token: tok, kind: 'segment' };
  }
  for (const tok of tokens) {
    const t = tok.toLowerCase();
    if (v.includes(t)) return { token: tok, kind: 'inner' };
  }
  return null;
}

/** Is this value plausibly the output of `openssl rand`? */
export function looksGenerated(value: string): boolean {
  const v = value.trim();
  return v.length >= GENERATED_LENGTH && entropyBits(v) >= MIN_ENTROPY_BITS;
}

export interface PasswordPolicyOptions {
  minLength?: number;
  minEntropyBits?: number;
  devTokens?: readonly string[];
  devDefaults?: ReadonlySet<string> | readonly string[];
}

/**
 * Every reason this password fails the policy. Empty array = accepted.
 * Messages never contain the password.
 */
export function passwordPolicyProblems(value: string, opts: PasswordPolicyOptions = {}): string[] {
  const minLen = opts.minLength ?? MIN_PASSWORD_LENGTH;
  const minBits = opts.minEntropyBits ?? MIN_ENTROPY_BITS;
  const tokens = opts.devTokens ?? [];
  const defaults = opts.devDefaults instanceof Set ? opts.devDefaults : new Set(opts.devDefaults ?? []);

  const v = (value ?? '').trim();
  const problems: string[] = [];
  if (!v) {
    problems.push('carries no password — the credential must be password protected');
    return problems;
  }

  if (v.length < minLen) {
    problems.push(`password is too short (minimum ${minLen} characters, got ${v.length})`);
  }

  const distinct = distinctCharacters(v);
  if (distinct < 4) {
    problems.push(`password uses only ${distinct} distinct character(s) — a repeated character is not a secret`);
  }

  const charRun = longestSingleCharRun(v);
  if (charRun > MAX_SINGLE_CHAR_RUN) {
    problems.push(`password repeats one character ${charRun} times in a row (maximum ${MAX_SINGLE_CHAR_RUN})`);
  }

  const period = repetitionPeriod(v);
  if (period !== null) {
    problems.push(`password is a ${period}-character pattern tiled ${Math.round(v.length / period)} times`);
  }

  const mono = longestMonotonicRun(v);
  if (mono >= 8) {
    problems.push(`password contains a ${mono}-character sequential run (e.g. alphabetical or counting)`);
  }

  const keyboard = longestKeyboardRun(v);
  if (keyboard >= 6) {
    problems.push(`password contains a ${keyboard}-character keyboard walk`);
  }

  const bits = entropyBits(v);
  if (bits < minBits) {
    problems.push(`password entropy is about ${bits} bits (minimum ${minBits})`);
  }

  if (defaults.has(v) || defaults.has(v.toLowerCase())) {
    problems.push('password is a known development default');
  }

  const occurrence = devTokenOccurrence(v, tokens);
  if (occurrence) {
    if (occurrence.kind === 'segment') {
      problems.push(
        `password contains the development token "${occurrence.token}" as a standalone segment — ` +
          'generate a unique value (openssl rand -hex 24)',
      );
    } else if (!looksGenerated(v)) {
      problems.push(
        `password contains the development token "${occurrence.token}" and is not long/high-entropy enough ` +
          `to be a generated secret (need >= ${GENERATED_LENGTH} characters and >= ${minBits} bits) — ` +
          'generate a unique value (openssl rand -hex 24)',
      );
    }
  }

  return problems;
}

/**
 * Extract a password from a connection URL using the WHATWG URL parser, the same
 * one browsers and Node use, and percent-decode it. The previous hand-rolled
 * regex stopped at the first `@`, so a password containing an encoded `%40` was
 * truncated and then judged on the wrong characters.
 *
 * Returns either the decoded password or an error that NAMES THE VARIABLE and
 * never repeats the value.
 */
export function parseConnectionUrlPassword(
  raw: string,
  key: string,
): { password: string | null; problem: string | null } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return { password: null, problem: `${key} is not a parseable connection url — check the scheme, the host and any percent-encoding (the value is not echoed here)` };
  }
  if (!url.password) {
    return { password: null, problem: `${key} carries no password — the credential must be password protected` };
  }
  try {
    return { password: decodeURIComponent(url.password), problem: null };
  } catch {
    return {
      password: null,
      problem: `${key} has a password with invalid percent-encoding — encode @ : / ? # % and space (the value is not echoed here)`,
    };
  }
}
