/**
 * PHASE Q1 — the db-compat preflight must not block routine redeploys.
 *
 * What this pins, and why each case is here:
 *
 *  BEFORE (PHASE P1 as shipped): `preflight-db-compat.ts` evaluated R1/R2
 *  against the owner's role attributes ALONE. On a managed database the owner is
 *  a non-superuser, `flexora_app` is created by the first deploy, and from then
 *  on R1 (`SUPERUSER`, or `CREATEROLE` when the runtime role does not exist yet)
 *  can never be satisfied again. So the FIRST deploy passed and EVERY later
 *  deploy was refused — and because the compose `api` service depends on
 *  `migrate` completing, the API never started. Measured, not theorised: that is
 *  exactly the `A preflight refuses EARLY` row profile 2b produced in
 *  scripts/check-db-compat.sh on a cluster where the runtime role already exists.
 *
 *  AFTER (this phase): the preflight reads `public._prisma_migrations` first,
 *  computes the PENDING set the way `prisma migrate deploy` does, derives which
 *  requirements each pending migration actually needs from its own SQL, and
 *  evaluates R1/R2 only for those. Nothing pending needs them -> PASS.
 *
 *  The three cases the PHASE Q1 brief names explicitly are tests 3, 4 and 5:
 *    3. profile 2b redeploy, ZERO pending migrations      -> PASS
 *    4. profile 2b redeploy, one new ordinary migration   -> PASS
 *    5. `202607050001` genuinely pending, same owner      -> REFUSE, and the
 *       refusal still names R1 (the guard was not weakened into a no-op)
 *
 *  Tests 6-9 are the negative controls: an owner that could never have applied
 *  the original chain still passes an ordinary redeploy, and every profile that
 *  was refused on a FRESH database is still refused there. A "pending-aware"
 *  preflight that passed everything would be worse than the one it replaces.
 *
 * No database is touched: `decide`, `detectRequirements` and `classifyMigrations`
 * are pure. The live, end-to-end proof (real roles, real `prisma migrate deploy`)
 * is the D-series in scripts/check-db-compat.sh.
 */
import { readFileSync } from 'fs';
import { join, resolve } from 'path';
import {
  ROLE_MIGRATION,
  canManageRuntimeRole,
  canOwnDefinerFunctions,
  classifyMigrations,
  decide,
  detectRequirements,
  listMigrationDirs,
  stripSqlComments,
  type AppliedRow,
  type MigrationNeed,
  type RoleAttrs,
} from '../../prisma/preflight-db-compat';

const MIGRATIONS_DIR = resolve(__dirname, '..', '..', 'prisma', 'migrations');

/** Owner profiles, with the exact attributes scripts/check-db-compat.sh creates. */
function attrs(over: Partial<RoleAttrs> = {}): RoleAttrs {
  return {
    role_name: 'flexora_c_2b',
    rolsuper: false,
    rolcreaterole: true,
    rolbypassrls: true,
    // The managed-database case: the first deploy already created the runtime role.
    runtime_role_exists: true,
    has_admin_option: false,
    ...over,
  };
}

const need = (name: string, r1 = false, r2 = false): MigrationNeed => ({
  name,
  needsRolePrivilege: r1,
  needsDefinerOwner: r2,
});

/** An ordinary, unprivileged migration: the kind a redeploy actually carries. */
const DUMMY = '99999999999999_q1_dummy_redeploy_probe';

describe('PHASE Q1 — db-compat preflight is pending-aware', () => {
  describe('requirement detection reads the real migration SQL', () => {
    it('flags R1 only for the migration that creates/alters the runtime role', () => {
      const dirs = listMigrationDirs(MIGRATIONS_DIR);
      expect(dirs.length).toBeGreaterThan(50);
      expect(dirs).toContain(ROLE_MIGRATION);

      const roleSql = readFileSync(join(MIGRATIONS_DIR, ROLE_MIGRATION, 'migration.sql'), 'utf8');
      expect(detectRequirements(roleSql).needsRolePrivilege).toBe(true);

      // Exactly ONE migration in the whole chain needs R1. If a future migration
      // starts creating or altering a role, this fails on purpose: the preflight
      // derives its requirements from the SQL, and the matrix in
      // scripts/check-db-compat.sh has to be re-measured when that happens.
      const r1Migrations = dirs.filter((d) =>
        detectRequirements(readFileSync(join(MIGRATIONS_DIR, d, 'migration.sql'), 'utf8'))
          .needsRolePrivilege,
      );
      expect(r1Migrations).toEqual([ROLE_MIGRATION]);
    });

    it('flags R2 for the SECURITY DEFINER migrations and for nothing else that is not one', () => {
      const preauth = readFileSync(
        join(MIGRATIONS_DIR, '202607070001_preauth_lookup_function', 'migration.sql'),
        'utf8',
      );
      expect(detectRequirements(preauth).needsDefinerOwner).toBe(true);
      expect(detectRequirements(preauth).needsRolePrivilege).toBe(false);

      const ordinary = readFileSync(
        join(MIGRATIONS_DIR, '202607200000_add_staff_pin', 'migration.sql'),
        'utf8',
      );
      expect(detectRequirements(ordinary)).toEqual({
        needsRolePrivilege: false,
        needsDefinerOwner: false,
      });
    });

    it('does not mistake a comment or a quoted string for a statement', () => {
      // The role migration itself documents the operator's rotation step as a
      // comment: `--  ALTER ROLE flexora_app WITH PASSWORD '<openssl rand …>'`.
      expect(
        detectRequirements("-- ALTER ROLE flexora_app is documented elsewhere\nSELECT 1;"),
      ).toEqual({ needsRolePrivilege: false, needsDefinerOwner: false });
      expect(
        detectRequirements("/* CREATE ROLE inside a block comment */ SECURITY DEFINER"),
      ).toEqual({ needsRolePrivilege: false, needsDefinerOwner: true });
      expect(detectRequirements("INSERT INTO t VALUES ('ALTER ROLE x');")).toEqual({
        needsRolePrivilege: false,
        needsDefinerOwner: false,
      });
      // … but the real statements are found, in any case and spacing, including
      // inside a plpgsql DO block (dollar-quoted bodies are code, not literals).
      expect(detectRequirements('CREATE ROLE x LOGIN;').needsRolePrivilege).toBe(true);
      expect(detectRequirements('create role flexora_app nosuperuser;').needsRolePrivilege).toBe(true);
      expect(detectRequirements('ALTER   ROLE x NOSUPERUSER;').needsRolePrivilege).toBe(true);
      expect(
        detectRequirements('DO $$ BEGIN\n  CREATE ROLE flexora_app NOSUPERUSER;\nEND $$;')
          .needsRolePrivilege,
      ).toBe(true);
      expect(detectRequirements('security definer').needsDefinerOwner).toBe(true);
      expect(detectRequirements('SECURITY INVOKER').needsDefinerOwner).toBe(false);
    });

    it('stripSqlComments keeps real code and drops prose, including inside DO blocks', () => {
      const stripped = stripSqlComments(
        [
          '-- leading prose: ALTER ROLE flexora_app WITH PASSWORD x',
          'DO $$',
          'BEGIN',
          "  -- inner prose mentioning SECURITY DEFINER",
          "  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'flexora_app') THEN",
          '    CREATE ROLE flexora_app NOSUPERUSER NOBYPASSRLS;',
          '  END IF;',
          'END $$;',
        ].join('\n'),
      );
      expect(stripped).not.toMatch(/leading prose/);
      expect(stripped).not.toMatch(/inner prose/);
      expect(stripped).toMatch(/CREATE ROLE flexora_app NOSUPERUSER NOBYPASSRLS/);
      // a doubled quote inside a string does not end the string
      expect(stripSqlComments("SELECT 'it''s -- fine'; SELECT 2;")).toMatch(/SELECT 2;/);
    });
  });

  describe('the two privilege conditions (measured on PostgreSQL 17)', () => {
    it('R1: superuser always; CREATEROLE only while the runtime role does not exist', () => {
      expect(canManageRuntimeRole(attrs({ rolsuper: true }))).toBe(true);
      // managed database, first deploy done: CREATEROLE is no longer enough
      expect(canManageRuntimeRole(attrs({ runtime_role_exists: true }))).toBe(false);
      // ADMIN OPTION does not help — PostgreSQL refuses any non-superuser
      // ALTER ROLE that mentions the SUPERUSER attribute at all
      expect(
        canManageRuntimeRole(attrs({ runtime_role_exists: true, has_admin_option: true })),
      ).toBe(false);
      // fresh cluster: CREATEROLE may CREATE ROLE ... NOSUPERUSER ...
      expect(canManageRuntimeRole(attrs({ runtime_role_exists: false }))).toBe(true);
      // BYPASSRLS alone cannot create a role
      expect(
        canManageRuntimeRole(attrs({ rolcreaterole: false, runtime_role_exists: false })),
      ).toBe(false);
    });

    it('R2: superuser or BYPASSRLS, never a plain NOBYPASSRLS owner', () => {
      expect(canOwnDefinerFunctions(attrs({ rolsuper: true }))).toBe(true);
      expect(canOwnDefinerFunctions(attrs({ rolbypassrls: true }))).toBe(true);
      expect(canOwnDefinerFunctions(attrs({ rolbypassrls: false }))).toBe(false);
    });
  });

  // ---------------------------------------------------------------------
  // The case the brief names first: profile 2b redeploy, zero pending.
  // ---------------------------------------------------------------------
  it('3. PASSES a redeploy with zero pending migrations for an owner that cannot satisfy R1', () => {
    const owner = attrs(); // NOSUPERUSER BYPASSRLS CREATEROLE, runtime role exists
    expect(canManageRuntimeRole(owner)).toBe(false); // would have been refused pre-Q1

    const d = decide(owner, []);
    expect(d.pass).toBe(true);
    expect(d.r1Required).toBe(false);
    expect(d.r2Required).toBe(false);
    expect(d.missing).toEqual([]);
  });

  it('4. PASSES a redeploy whose only pending migration is an ordinary one', () => {
    const d = decide(attrs(), [need(DUMMY)]);
    expect(d.pass).toBe(true);
    expect(d.r1Required).toBe(false);
    expect(d.r2Required).toBe(false);
  });

  it('5. still REFUSES when the role migration itself is pending for that owner', () => {
    const d = decide(attrs(), [
      need('202607060000_something_ordinary'),
      need(ROLE_MIGRATION, true, false),
      need('202607070001_preauth_lookup_function', false, true),
    ]);
    expect(d.pass).toBe(false);
    expect(d.r1Required).toBe(true);
    expect(d.r1RequiredBy).toEqual([ROLE_MIGRATION]);
    // the refusal must still name the requirement it is refusing for
    expect(d.missing.join('\n')).toMatch(/R1 CREATE\/ALTER ROLE/);
    expect(d.missing.join('\n')).toMatch(new RegExp(ROLE_MIGRATION));
    // R2 is satisfied by this owner (BYPASSRLS), so it must not be blamed
    expect(d.r2Satisfied).toBe(true);
    expect(d.missing.join('\n')).not.toMatch(/R2 BYPASSRLS/);
  });

  // ---------------------------------------------------------------------
  // Negative controls: the guard was not turned into a no-op.
  // ---------------------------------------------------------------------
  it('6. passes the weakest possible owner for an ordinary pending migration', () => {
    const weakest = attrs({
      role_name: 'managed_provider_role',
      rolsuper: false,
      rolcreaterole: false,
      rolbypassrls: false,
      runtime_role_exists: true,
    });
    expect(canManageRuntimeRole(weakest)).toBe(false);
    expect(canOwnDefinerFunctions(weakest)).toBe(false);
    expect(decide(weakest, [need(DUMMY)]).pass).toBe(true);
    expect(decide(weakest, []).pass).toBe(true);
  });

  it('7. still refuses a fresh database for every unsupported profile', () => {
    const wholeChain = [
      need('0001_init'),
      need(ROLE_MIGRATION, true, false),
      need('202607070001_preauth_lookup_function', false, true),
    ];

    // profile 1 — SUPERUSER: supported
    expect(decide(attrs({ rolsuper: true, rolcreaterole: false }), wholeChain).pass).toBe(true);

    // profile 2 — NOSUPERUSER BYPASSRLS, no CREATEROLE, runtime role exists: R1
    const p2 = decide(attrs({ rolcreaterole: false }), wholeChain);
    expect(p2.pass).toBe(false);
    expect(p2.missing.join('\n')).toMatch(/R1 CREATE\/ALTER ROLE/);
    expect(p2.missing.join('\n')).not.toMatch(/R2 BYPASSRLS/);

    // profile 3 — NOSUPERUSER NOBYPASSRLS, no CREATEROLE: R1 AND R2
    const p3 = decide(attrs({ rolcreaterole: false, rolbypassrls: false }), wholeChain);
    expect(p3.pass).toBe(false);
    expect(p3.missing.join('\n')).toMatch(/R1 CREATE\/ALTER ROLE/);
    expect(p3.missing.join('\n')).toMatch(/R2 BYPASSRLS/);

    // fresh 3b — NOSUPERUSER NOBYPASSRLS CREATEROLE on a cluster where the
    // runtime role does NOT exist: R1 is satisfiable, R2 is not. This is the
    // measured "chain applies but nobody can log in" profile.
    const p3b = decide(
      attrs({ rolbypassrls: false, runtime_role_exists: false }),
      wholeChain,
    );
    expect(p3b.pass).toBe(false);
    expect(p3b.r1Satisfied).toBe(true);
    expect(p3b.r2Satisfied).toBe(false);
    expect(p3b.missing.join('\n')).not.toMatch(/R1 CREATE\/ALTER ROLE/);
    expect(p3b.missing.join('\n')).toMatch(/R2 BYPASSRLS/);

    // fresh 2b — NOSUPERUSER BYPASSRLS CREATEROLE, runtime role absent: supported
    expect(decide(attrs({ runtime_role_exists: false }), wholeChain).pass).toBe(true);
  });

  it('8. refuses when only the SECURITY DEFINER migration is pending for a NOBYPASSRLS owner', () => {
    const d = decide(attrs({ rolbypassrls: false }), [
      need('202607160001_restrict_preauth_functions', false, true),
    ]);
    expect(d.pass).toBe(false);
    expect(d.r1Required).toBe(false);
    expect(d.r2Required).toBe(true);
    expect(d.missing.join('\n')).toMatch(/R2 BYPASSRLS/);
  });

  describe('pending-set computation mirrors `prisma migrate deploy`', () => {
    const dirs = ['0001_init', '0002_next', ROLE_MIGRATION, DUMMY];

    it('9. treats a missing bookkeeping table as "everything is pending"', () => {
      const c = classifyMigrations(dirs, []);
      expect(c.tableReadable).toBe(true);
      expect(c.pending).toEqual(dirs);
      expect(c.applied).toEqual([]);
    });

    it('10. fails CLOSED when the bookkeeping table cannot be read', () => {
      const c = classifyMigrations(dirs, null);
      expect(c.tableReadable).toBe(false);
      expect(c.pending).toEqual(dirs);
    });

    it('11. counts applied, failed and rolled-back rows correctly', () => {
      const rows: AppliedRow[] = [
        { migration_name: '0001_init', finished: true, rolled_back: false },
        // a failed migration is retried by Prisma, so its privileges matter again
        { migration_name: '0002_next', finished: false, rolled_back: false },
        { migration_name: ROLE_MIGRATION, finished: true, rolled_back: true },
      ];
      const c = classifyMigrations(dirs, rows);
      expect(c.applied).toEqual(['0001_init']);
      // A row that never finished and was never rolled back is FAILED, reported
      // separately: `prisma migrate deploy` refuses to run at all until the
      // operator resolves it, so it is not part of the set this preflight judges.
      expect(c.failed).toEqual(['0002_next']);
      // ROLE_MIGRATION (rolled back -> Prisma applies it again) and DUMMY (no row)
      expect(c.pending).toEqual([ROLE_MIGRATION, DUMMY]);

      // and the decision follows: a rolled-back role migration needs R1 again
      const d = decide(attrs(), [need(ROLE_MIGRATION, true, false)]);
      expect(d.pass).toBe(false);
    });

    it('12. ignores bookkeeping rows for directories that no longer exist', () => {
      const c = classifyMigrations(dirs, [
        { migration_name: 'deleted_migration', finished: true, rolled_back: false },
        { migration_name: '0001_init', finished: true, rolled_back: false },
      ]);
      expect(c.applied).toEqual(['0001_init']);
      expect(c.pending).toEqual(['0002_next', ROLE_MIGRATION, DUMMY]);
    });
  });

  it('reads the real chain and detects each function-creating migration', () => {
    const dirs = listMigrationDirs(MIGRATIONS_DIR);
    const needs = dirs.map((name) => ({
      name,
      ...detectRequirements(readFileSync(join(MIGRATIONS_DIR, name, 'migration.sql'), 'utf8')),
    }));
    expect(needs.filter((n) => n.needsRolePrivilege).map((n) => n.name)).toEqual([ROLE_MIGRATION]);
    // Only the migrations that CREATE a SECURITY DEFINER function need R2: they
    // are what decides the owner of those functions.
    // PHASE R2 added 20261107000000_platform_privacy_r2, which creates five of them
    // for the owner console. This expected list is the FIXTURE and it is updated
    // because the detector did its job: it picked the new migration up from the SQL
    // with no edit to preflight-db-compat.ts. That is the property this spec exists
    // to protect - a deployment whose owner profile cannot own a SECURITY DEFINER
    // function is refused early, with the new migration named as the reason.
    expect(needs.filter((n) => n.needsDefinerOwner).map((n) => n.name)).toEqual([
      '202607070001_preauth_lookup_function',
      '202607160002_public_invitation_lookup',
      '202607160003_public_messaging_lookup',
        '20261106000000_platform_auth_r1',
        '20261107000000_platform_privacy_r2',
      // PHASE R4 added two more migrations that create SECURITY DEFINER functions: the gyms
      // list sort, and the platform's one sanctioned write path into the FORCE-RLS Subscription
      // table. The preflight correctly detects them, so the expected list grows - this is the
      // fixture being updated for a correct product change, not a check being weakened.
      '20261107150000_platform_gyms_sort_r4',
      '20261107160000_platform_subscription_write_r4',
      // Additive read-only subscription console function, also requiring an authorized owner.
      '20261107170000_platform_subscription_console',
    ]);
    // `202607160001_restrict_preauth_functions` only REVOKEs/GRANTs EXECUTE on
    // functions an earlier migration created; its mention of "SECURITY DEFINER"
    // is prose in a comment. A naive grep flagged it (and would have made R2
    // "required" for a redeploy that creates nothing), which is exactly the
    // false positive stripSqlComments exists to prevent.
    const restrict = needs.find((n) => n.name === '202607160001_restrict_preauth_functions');
    expect(restrict).toBeDefined();
    expect(restrict!.needsDefinerOwner).toBe(false);
    expect(restrict!.needsRolePrivilege).toBe(false);
    expect(
      readFileSync(join(MIGRATIONS_DIR, '202607160001_restrict_preauth_functions', 'migration.sql'), 'utf8'),
    ).toMatch(/SECURITY DEFINER/);
    // A fully-applied database therefore needs NOTHING from the owner:
    expect(decide(attrs(), []).pass).toBe(true);
    expect(decide(attrs({ rolcreaterole: false, rolbypassrls: false }), []).pass).toBe(true);
  });
});
