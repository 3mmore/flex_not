/**
 * PHASE O3.1 / O3.2 / O3.3 — the credential policy, its generation commands and
 * the URL rules.
 *
 * O3.1  length >= 16 + entropy + pattern rules replace character-class counting.
 *       The accept/reject table below is the brief's, verbatim.
 * O3.2  every generation command quoted by the validator's own advice messages,
 *       docs/DEPLOYMENT.md and the four .env.example templates is EXECUTED here
 *       and its output fed to the validator. A documented command that the
 *       validator would reject is a bug, and this is what catches it.
 * O3.3  hex/base64url are the documented alphabets; `$` must be doubled in
 *       compose; `@ : / ? # %` must be percent-encoded inside a URL; an
 *       unparseable URL is an error that NAMES THE VARIABLE and never echoes it.
 *
 * No test in this file prints a candidate password: assertions are on problem
 * counts and message text, and the "never echoes the value" cases assert that
 * explicitly.
 */
import { execSync } from 'child_process';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import {
  GENERATED_LENGTH,
  MIN_ENTROPY_BITS,
  MIN_PASSWORD_LENGTH,
  entropyBits,
  distinctCharacters,
  longestKeyboardRun,
  longestMonotonicRun,
  longestSingleCharRun,
  parseConnectionUrlPassword,
  passwordPolicyProblems,
  repetitionPeriod,
} from './password-policy';
import { DEV_DEFAULT_VALUES, DEV_TOKENS, urlPassword, validateCredentialVar } from './env-validation';

// apps/api/src/config -> apps/api/src -> apps/api -> apps -> repo root (jest runs
// this file from source, so __dirname is the src tree, not dist).
// apps/api/src/config -> apps/api/src -> apps/api -> apps -> repo root
const repoRoot = join(__dirname, '..', '..', '..', '..');
const POLICY = { devTokens: DEV_TOKENS, devDefaults: DEV_DEFAULT_VALUES };
const problems = (v: string) => passwordPolicyProblems(v, POLICY);
const accepted = (v: string) => problems(v).length === 0;

describe('O3.1 the credential policy', () => {
  describe('rejects everything the brief lists', () => {
    // (value, why it must fail) — the reason is asserted too, so the value cannot
    // start passing for the wrong reason (or fail for an unrelated one).
    const cases: Array<[string, RegExp]> = [
      ['Password123456!', /too short/],
      ['Flexora2026!Flexora2026!', /tiled|standalone segment/],
      ['Admin@123456789', /too short/],
      ['Qwerty12345678!', /too short|keyboard walk/],
      ['S3cureFlexoraDb2026!', /development token "flexora"/],
      ['aaaaaaaaaaaaaaaaaaaaaaaa', /distinct character|repeats one character/],
      ['abcdefghijklmnopqrstuvwx', /sequential run/],
      ['1234567890123456', /sequential run|development token "123456"/],
      ['short1A!', /too short/],
      ['0123456789abcde', /too short/],
    ];
    it.each(cases)('rejects %s', (value, why) => {
      const p = problems(value);
      expect(p.length).toBeGreaterThan(0);
      expect(p.join(' | ')).toMatch(why);
    });

    it('rejects anything shorter than 16 characters, whatever its decoration', () => {
      for (const v of ['A1!b', 'Pa55w0rd!', 'X9mQ2vLp7!wR4t', 'abcdefghijklmno']) {
        expect(v.length).toBeLessThan(MIN_PASSWORD_LENGTH);
        expect(problems(v).join(' | ')).toMatch(/too short/);
      }
    });
  });

  describe('accepts everything the brief lists', () => {
    it('accepts a fresh `openssl rand -hex 24` (two character classes, 48 chars)', () => {
      const v = execSync('openssl rand -hex 24').toString().trim();
      expect(v).toHaveLength(48);
      expect(problems(v)).toEqual([]);
      // and the old rule would have rejected it: that is the point of the change
      expect(/[A-Z]/.test(v)).toBe(false);
      expect(/[^A-Za-z0-9]/.test(v)).toBe(false);
    });

    it("accepts a fresh `openssl rand -base64 24 | tr '+/' '-_'` (URL-safe alphabet)", () => {
      const v = execSync("openssl rand -base64 24 | tr '+/' '-_'").toString().trim();
      expect(v).toHaveLength(32);
      expect(problems(v)).toEqual([]);
      expect(v).not.toMatch(/[+/=]/);
    });

    it('accepts Zq9TxtestK7mWp2RvB4nL8cD — high entropy, long, "test" only inside', () => {
      const v = 'Zq9TxtestK7mWp2RvB4nL8cD';
      expect(v).toHaveLength(GENERATED_LENGTH);
      expect(entropyBits(v)).toBeGreaterThanOrEqual(MIN_ENTROPY_BITS);
      expect(problems(v)).toEqual([]);
    });

    it('accepts the sandbox fixture shape used by the boot matrix (X9q<hex>Z7)', () => {
      const v = `X9q${execSync('openssl rand -hex 12').toString().trim()}Z7`;
      expect(problems(v)).toEqual([]);
    });
  });

  describe('the rules individually', () => {
    it('measures entropy as length x log2(pool), not by observed distribution', () => {
      // a repeated-character value must NOT be rewarded for having two distinct chars
      expect(entropyBits('aaaaaaaaaaaaaaaaaaaaaaab')).toBeLessThan(entropyBits('X9mQ2vLp7wR4tZ8yB3nK'));
      expect(distinctCharacters('aaaaaaaaaaaaaaaaaaaaaaab')).toBe(2);
      expect(longestSingleCharRun('aaaaaaaaaaaaaaaaaaaaaaab')).toBe(23);
    });

    it('detects tiling, sequences and keyboard walks', () => {
      expect(repetitionPeriod('Flexora2026!Flexora2026!')).toBe(12);
      expect(repetitionPeriod('abcabcabc')).toBe(3);
      expect(repetitionPeriod('X9mQ2vLp7wR4tZ8y')).toBeNull();
      expect(longestMonotonicRun('abcdefghijklmnopqrstuvwx')).toBe(24);
      expect(longestMonotonicRun('1234567890123456')).toBeGreaterThanOrEqual(8);
      expect(longestMonotonicRun('X9mQ2vLp7wR4tZ8y')).toBeLessThan(8);
      expect(longestKeyboardRun('Qwerty12345678!')).toBeGreaterThanOrEqual(6);
      expect(longestKeyboardRun('pouytrewq')).toBeGreaterThanOrEqual(6); // reversed row
      expect(longestKeyboardRun('X9mQ2vLp7wR4tZ8y')).toBeLessThan(6);
    });

    it('always rejects a token as a standalone segment, whatever the length', () => {
      const long = 'X9mQ2vLp7wR4tZ8yB3nK';           // 20 chars, high entropy
      expect(entropyBits(`${long}flexora`)).toBeGreaterThan(MIN_ENTROPY_BITS);
      expect(problems(`${long}flexora`).join(' | ')).toMatch(/standalone segment/);
      expect(problems(`flexora_${long}`).join(' | ')).toMatch(/standalone segment/);
      expect(problems(`${long}-dev`).join(' | ')).toMatch(/standalone segment/);
    });

    it('accepts a token buried inside a generated-length, high-entropy value', () => {
      expect(problems(`X9mQ2vLp7w${'R4tZ8y'.repeat(3)}`).join(' | ')).not.toMatch(/development token/);
      expect(problems('Zq9TxtestK7mWp2RvB4nL8cD')).toEqual([]);
    });

    it('rejects a known development default exactly', () => {
      expect(problems('flexora_dev_pw').join(' | ')).toMatch(/development token|development default/);
      expect(DEV_DEFAULT_VALUES.has('flexora_dev_pw') || DEV_DEFAULT_VALUES.has('flexora_app_dev_pw')).toBe(true);
    });

    it('never echoes the candidate value in a message', () => {
      const secret = 'Zq9TxUNIQUEVALUE7mWp2RvB4nL8cD';
      const p = problems('aaaaaaaaaaaaaaaaaaaaaaaa').concat(problems(secret.length > 0 ? 'short1A!' : ''));
      expect(p.join(' | ')).not.toContain(secret);
      // a token from the fixed public list MAY appear (it is not the password)
      expect(problems('S3cureFlexoraDb2026!').join(' | ')).toContain('flexora');
      expect(problems('S3cureFlexoraDb2026!').join(' | ')).not.toContain('S3cureFlexoraDb2026!');
    });
  });

  describe('through validateCredentialVar (the validator entry point)', () => {
    it('accepts a strong password inside a postgres url', () => {
      expect(validateCredentialVar('DATABASE_URL', 'postgresql://u:X9mQ2vLp7wR4tZ8yB3nK@h:5432/db', true)).toEqual([]);
    });
    it('accepts a strong password inside a rediss url', () => {
      expect(validateCredentialVar('REDIS_URL', 'rediss://:X9mQ2vLp7wR4tZ8yB3nK@h:6379', true)).toEqual([]);
    });
    it('rejects a weak one, naming the variable', () => {
      const e = validateCredentialVar('DATABASE_URL', 'postgresql://u:Password123456!@h:5432/db', true);
      expect(e.length).toBeGreaterThan(0);
      expect(e.every((x) => x.startsWith('DATABASE_URL '))).toBe(true);
      expect(e.join(' | ')).not.toContain('Password123456!');
    });
    it('rejects a bare weak password and accepts a bare strong one', () => {
      expect(validateCredentialVar('POSTGRES_PASSWORD', 'Password123456!', false).length).toBeGreaterThan(0);
      expect(validateCredentialVar('POSTGRES_PASSWORD', 'X9mQ2vLp7wR4tZ8yB3nK', false)).toEqual([]);
    });
  });
});

describe('O3.2 every documented generation command produces an accepted value', () => {
  const sources: Array<[string, string]> = [
    ['validator advice', join(repoRoot, 'apps', 'api', 'src', 'config', 'env-validation.ts')],
    ['policy advice', join(repoRoot, 'apps', 'api', 'src', 'config', 'password-policy.ts')],
    ['docs/DEPLOYMENT.md', join(repoRoot, 'docs', 'DEPLOYMENT.md')],
    ['root .env.example', join(repoRoot, '.env.example')],
    ['apps/api/.env.example', join(repoRoot, 'apps', 'api', '.env.example')],
    ['apps/web/.env.example', join(repoRoot, 'apps', 'web', '.env.example')],
    ['license-server/.env.example', join(repoRoot, 'license-server', '.env.example')],
    ['README.md', join(repoRoot, 'README.md')],
    ['docs/SECRET_ROTATION.md', join(repoRoot, 'docs', 'SECRET_ROTATION.md')],
    ['the seed advice', join(repoRoot, 'apps', 'api', 'prisma', 'seed.ts')],
    ['the bootstrap advice', join(repoRoot, 'apps', 'api', 'prisma', 'bootstrap-platform-admin.ts')],
  ];
  // A TypeScript string literal escapes its quotes (`tr \'+/\' \'-_\'`), and a
  // markdown table escapes its pipe (`\|`). Both spellings are the same command,
  // so both are captured and normalised before being executed.
  const COMMAND = /openssl rand (?:-hex \d+|-base64 \d+(?: (?:\\\||\|) tr \\?'\+\/\\?' \\?'-_\\?')?)/g;
  const normalise = (cmd: string) => cmd.replace(/\\\|/g, '|').replace(/\\'/g, `'`);

  function commandsIn(path: string): string[] {
    if (!existsSync(path)) return [];
    const text = readFileSync(path, 'utf8');
    const found = text.match(COMMAND) ?? [];
    return [...new Set(found.map((c) => c.trim()))];
  }

  const all = new Map<string, string[]>();
  for (const [label, path] of sources) {
    for (const cmd of commandsIn(path)) {
      const c = normalise(cmd);
      all.set(c, [...(all.get(c) ?? []), label]);
    }
  }

  it('actually found the documented commands (the test cannot pass vacuously)', () => {
    expect(all.size).toBeGreaterThanOrEqual(3);
    expect([...all.keys()].join('\n')).toMatch(/openssl rand -hex 32/);
    expect([...all.keys()].join('\n')).toMatch(/openssl rand -hex 24/);
    expect([...all.keys()].join('\n')).toMatch(/openssl rand -base64 24 \| tr '\+\/' '-_'/);
  });

  it.each([...all.entries()])('`%s` (quoted by %s) passes the validator', (cmd, labels) => {
    const value = execSync(cmd).toString().trim();
    expect(value.length).toBeGreaterThan(0);
    const p = problems(value);
    if (p.length) {
      // Fail loudly and informatively: a documented command must not produce a
      // value the validator rejects. (No value is printed.)
      throw new Error(`documented in ${labels.join(', ')} but rejected: ${p.join(' | ')} (length ${value.length})`);
    }
    expect(validateCredentialVar('POSTGRES_PASSWORD', value, false)).toEqual([]);
  });

  it('documents only hex and base64url alphabets (no shell-hostile output)', () => {
    for (const cmd of all.keys()) {
      expect(cmd).toMatch(/^openssl rand (-hex \d+|-base64 \d+( \| tr '\+\/' '-_')?)$/);
      // plain base64 (with + / =) is only acceptable when piped through tr
      if (cmd.includes('-base64')) expect(cmd).toContain("tr '+/' '-_'");
    }
  });
});

describe('O3.3 URLs, percent-encoding and compose escaping', () => {
  it('parses a password with the WHATWG URL parser and percent-decodes it', () => {
    const r = parseConnectionUrlPassword('postgresql://u:p%40ss%3Aword@h:5432/db', 'DATABASE_URL');
    expect(r.problem).toBeNull();
    expect(r.password).toBe('p@ss:word');
    expect(problems(r.password ?? '').length).toBeGreaterThan(0); // 9 chars: too short, and rightly so
  });

  it('does not truncate at the first @ the way the old regex did', () => {
    // the old implementation stopped at the first '@', judging "p%40ss" instead of the whole password
    const r = parseConnectionUrlPassword('postgresql://u:X9mQ2vLp7%40wR4tZ8yB3nK@h:5432/db', 'DATABASE_URL');
    expect(r.password).toBe('X9mQ2vLp7@wR4tZ8yB3nK');
    expect(problems(r.password ?? '')).toEqual([]);
    expect(urlPassword('postgresql://u:X9mQ2vLp7%40wR4tZ8yB3nK@h:5432/db')).toBe('X9mQ2vLp7@wR4tZ8yB3nK');
  });

  it('names the variable and never echoes the value when a url cannot be parsed', () => {
    const value = 'postgresql://u:Sup3rSecretVALUE!!@host with spaces:5432/db';
    const r = parseConnectionUrlPassword(value, 'DATABASE_URL');
    expect(r.problem).toMatch(/^DATABASE_URL /);
    expect(r.problem).toMatch(/not a parseable connection url/);
    expect(r.problem).not.toContain('Sup3rSecretVALUE');
    expect(r.problem).not.toContain(value);
    expect(r.password).toBeNull();
  });

  it('reports invalid percent-encoding without echoing the value', () => {
    const r = parseConnectionUrlPassword('postgresql://u:abc%zzdefghijklmnop@h:5432/db', 'DIRECT_URL');
    expect(r.problem).toMatch(/^DIRECT_URL /);
    expect(r.problem).toMatch(/percent-encoding/);
    expect(r.problem).not.toContain('abc%zzdefghijklmnop');
  });

  it('reports a url with no password as a problem, not as an empty password', () => {
    expect(parseConnectionUrlPassword('postgresql://h:5432/db', 'DATABASE_URL').problem).toMatch(/carries no password/);
    expect(urlPassword('postgresql://h:5432/db')).toBeNull();
  });

  it('documents the compose $$ rule next to the redis password it protects', () => {
    const compose = readFileSync(join(repoRoot, 'docker-compose.yml'), 'utf8');
    // the redis service must hand the password to the CONTAINER's shell, not to compose
    expect(compose).toMatch(/\$\$REDIS_PASSWORD/);
    // a SINGLE $ would be interpolated away by compose before the container's shell
    // ever saw it; `$$REDIS_PASSWORD` contains `$REDIS_PASSWORD`, hence the lookbehind
    expect(compose.match(/(?<!\$)\$REDIS_PASSWORD/g)).toBeNull();
  });

  it('documents percent-encoding and the $$ rule in the deployment guide', () => {
    const doc = readFileSync(join(repoRoot, 'docs', 'DEPLOYMENT.md'), 'utf8');
    expect(doc).toMatch(/percent-encode/i);
    expect(doc).toMatch(/`\$\$`/);
    expect(doc).toMatch(/openssl rand -hex 32/);
  });
});
