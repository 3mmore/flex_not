/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Winston logger configuration (Phase 14).
 *
 * Emits JSON logs in production, pretty console in development.
 * All logs share one shape so they can be shipped to Sentry /
 * CloudWatch / Loki later without code changes.
 */
import { isProduction } from './env-mode';
import { LoggerService, LogLevel } from '@nestjs/common';
import * as winston from 'winston';
import { requestContext } from '../common/middleware/request-id.middleware';

const isProd = isProduction();

export const winstonLogger: winston.Logger = winston.createLogger({
  level: process.env.LOG_LEVEL || (isProd ? 'info' : 'debug'),
  format: winston.format.combine(
    winston.format((info) => {
      const store = requestContext.getStore();
      if (store?.requestId) {
        info.requestId = store.requestId;
      }
      return info;
    })(),
    isProd
      ? winston.format.combine(
          winston.format.timestamp(),
          winston.format.errors({ stack: true }),
          winston.format.json(),
        )
      : winston.format.combine(
          winston.format.colorize(),
          winston.format.timestamp(),
          winston.format.printf((info) => {
            const { timestamp, level, message, context, requestId, ...rest } = info;
            const ctxStr = context ? ` [${context as string}]` : '';
            const reqIdStr = requestId ? ` (${requestId as string})` : '';
            const meta = Object.keys(rest).length
              ? ' ' + JSON.stringify(rest, (k, v) =>
                  k === 'stack' ? String(v).split('\n')[0] : v,
                )
              : '';
            return `${timestamp as string} ${level}${ctxStr}${reqIdStr} ${message as string}${meta}`;
          }),
        ),
  ),
  defaultMeta: { service: 'flexora-api' },
  transports: [new winston.transports.Console()],
});

/** NestJS-compatible adapter for winston. */
export class WinstonNestAdapter implements LoggerService {
  log(message: unknown, context?: string) {
    if (typeof message === 'string') winstonLogger.info(message, { context });
    else winstonLogger.info('Object log', { context, data: message });
  }
  error(message: unknown, trace?: string, context?: string) {
    if (message instanceof Error) {
      winstonLogger.error(message.message, { context, trace: trace || message.stack });
    } else if (typeof message === 'string') {
      winstonLogger.error(message, { context, trace });
    } else {
      winstonLogger.error('Object error', { context, trace, data: message });
    }
  }
  warn(message: unknown, context?: string) {
    if (typeof message === 'string') winstonLogger.warn(message, { context });
    else winstonLogger.warn('Object warn', { context, data: message });
  }
  debug(message: unknown, context?: string) {
    if (typeof message === 'string') winstonLogger.debug(message, { context });
    else winstonLogger.debug('Object debug', { context, data: message });
  }
  verbose(message: unknown, context?: string) {
    if (typeof message === 'string') winstonLogger.verbose(message, { context });
    else winstonLogger.verbose('Object verbose', { context, data: message });
  }
  setLogLevels?(_levels: LogLevel[]) { /* winston manages levels */ }
}
