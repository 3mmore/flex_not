import * as argon2 from 'argon2';

/**
 * PHASE O1.7 — the single definition of the argon2 parameters this API uses.
 *
 * It used to live as a private const inside modules/auth/auth.service.ts, with a
 * second, DIFFERENT copy in a spec (that one had parallelism: 4 while the service
 * used 1). Verification still worked, because argon2 embeds its parameters in the
 * hash, but two definitions of "how we hash passwords" is exactly how a bootstrap
 * tool ends up producing hashes the API would never create.
 *
 * Both the auth service and prisma/bootstrap-platform-admin.ts import this, so an
 * admin created by the bootstrap is hashed by the same code path — and with the
 * same parameters — as a user created through POST /api/auth/register.
 */
export const PASSWORD_HASH_OPTIONS: argon2.Options & { raw?: false } = {
  type: argon2.argon2id,
  memoryCost: 65536, // 64 MiB
  timeCost: 3,
  parallelism: 1,
};

/** Hash a password the way the API does. Never logs its input or output. */
export function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, PASSWORD_HASH_OPTIONS);
}

/** A human-readable description of the parameters, safe to print. */
export function passwordHashParamsLabel(): string {
  const o = PASSWORD_HASH_OPTIONS;
  return `argon2id m=${o.memoryCost},t=${o.timeCost},p=${o.parallelism}`;
}
