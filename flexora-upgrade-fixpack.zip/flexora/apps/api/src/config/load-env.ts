/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE M4 — explicit `.env` loading, imported for its side effect BEFORE any
 * other module in the process.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * Several modules read `process.env` at *module scope*, i.e. while they are
 * being imported:
 *
 *   modules/members/members-import.controller.ts → IMPORT_UPLOAD_DIR (+ mkdir)
 *   modules/biometric/biometric.service.ts       → WEBAUTHN_RP_NAME / _RP_ID / _ORIGIN
 *   modules/auth/auth-token.config.ts            → REFRESH_TOKEN_TTL_DAYS, JWT_ACCESS_TTL
 *
 * `ConfigModule.forRoot()` only reads `.env` when the Nest container is
 * initialised — long *after* those imports have run. Until now the process saw
 * the right values only because `@prisma/client` happens to inject `.env` when
 * it is imported: an undocumented, transitive side effect that depends on the
 * generated client's baked-in schema path.
 *
 * That accident was observed to break. An API built from the delivery archive
 * booted with IMPORT_UPLOAD_DIR unset, fell back to `/var/backups/flexora/…`
 * and died with `EACCES: permission denied, mkdir` before Nest ever started.
 * The same ordering accident would silently substitute the WebAuthn defaults
 * (rpID `localhost`, origin `http://localhost:3000`) and the default token
 * lifetimes for the operator's real configuration — a passkey relying-party ID
 * of `localhost` in production is not a crash, it is a quiet misconfiguration.
 *
 * SAFETY
 * ------
 * dotenv never overwrites a variable that is already present in the
 * environment, so container / systemd deployments that inject real env vars
 * keep exactly the values they were given. If no `.env` file exists this module
 * is a no-op.
 */
import { config as loadDotenv } from 'dotenv';
import { existsSync } from 'fs';
import { resolve } from 'path';

/**
 * Candidate locations for `apps/api/.env`, in priority order:
 *   src/config/…      (ts-node / jest, running from source)
 *   dist/src/config/… (compiled `node dist/src/main.js`)
 *   process.cwd()     (npm workspace scripts started from apps/api)
 */
const CANDIDATES: readonly string[] = [
  resolve(__dirname, '..', '..', '.env'),
  resolve(__dirname, '..', '..', '..', '.env'),
  resolve(process.cwd(), '.env'),
];

for (const path of CANDIDATES) {
  if (existsSync(path)) {
    loadDotenv({ path });
    break;
  }
}
