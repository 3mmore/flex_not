/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 / owner decision D2 — the owner console's OWN signing secret.
 *
 * Before R1 the platform token was signed with JWT_ACCESS_SECRET, the tenant
 * access secret (platform-auth.service.ts:15, measured in
 * work/r1-evidence/00-before.log B7.5). One leak then compromised both the
 * tenant app and the owner console, and a token minted for one audience was
 * cryptographically acceptable to the other.
 *
 * Rules implemented here, exactly as the owner specified:
 *   - production startup FAILS if JWT_PLATFORM_SECRET is missing, too short, or
 *     equal to any tenant secret;
 *   - development falls back to a cryptographically secure random secret that is
 *     process-local, never persisted and never logged, so console sessions do
 *     not survive an api restart in development;
 *   - tenant authentication is not weakened and no tenant secret is reused.
 *
 * No `process.env` is read at module scope: every reader takes the environment
 * as a parameter and defaults to process.env at CALL time.
 */
import { randomBytes } from 'crypto';
import { isProductionEnv } from './env-mode';

export const JWT_PLATFORM_SECRET_VAR = 'JWT_PLATFORM_SECRET';

/** Minimum accepted length. Matches MIN_SECRET_LEN in config/env-validation.ts. */
export const PLATFORM_SECRET_MIN_LENGTH = 32;

/**
 * Secrets the platform secret must differ from. These are the signing and
 * encryption keys the tenant side uses; the list mirrors DISTINCT_GROUPS and
 * DISTINCT_FROM_ALL in config/env-validation.ts, which enforces the same rule
 * through the existing distinctness machinery at boot.
 *
 * Values are compared with a constant-time equality check and are NEVER logged,
 * returned or interpolated into a message — only variable NAMES are.
 */
export const PLATFORM_SECRET_MUST_DIFFER_FROM: readonly string[] = [
  'JWT_ACCESS_SECRET',
  'JWT_REFRESH_SECRET',
  'JWT_MEMBER_SECRET',
  'ENCRYPTION_KEY',
  'ENCRYPTION_SEARCH_KEY',
  'BACKUP_ENCRYPTION_KEY',
  'OTP_HMAC_SECRET',
];

/** 384 bits of entropy, url-safe, no padding. Process-local and never written down. */
export function generatePlatformSecret(): string {
  return randomBytes(48).toString('base64url');
}

function constantTimeEquals(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  // Imported lazily so this module stays free of any node:crypto side effects at
  // module scope beyond randomBytes, which is already imported above.
  const { timingSafeEqual } = require('crypto') as typeof import('crypto');
  return timingSafeEqual(bufA, bufB);
}

export interface PlatformSecretReport {
  /** True when no value was configured and a per-process secret was generated. */
  ephemeral: boolean;
  /** Fatal: the process must not serve console traffic. Names only, never values. */
  problems: string[];
  /** Non-fatal notes, safe to log. Never contains a value. */
  warnings: string[];
}

/**
 * Inspect the configured platform secret WITHOUT generating or caching one.
 * Returns problems (fatal in the current mode) and warnings (informational).
 * The value itself is deliberately not part of the report, so a caller cannot
 * log it by accident.
 */
export function inspectPlatformSecret(env: NodeJS.ProcessEnv = process.env): PlatformSecretReport {
  const problems: string[] = [];
  const warnings: string[] = [];
  // Production-ness is decided from the INJECTED environment, not from a second read
  // of process.env: the whole point of taking env as a parameter is that a caller (a
  // test, or enforceEnv with a resolved config) can be answered about THAT
  // environment. isProduction() would have silently ignored the argument.
  const production = isProductionEnv(env.NODE_ENV);
  const configured = (env[JWT_PLATFORM_SECRET_VAR] ?? '').trim();

  if (!configured) {
    if (production) {
      problems.push(
        `${JWT_PLATFORM_SECRET_VAR} is required in production — the owner console must not be signed with a tenant secret`,
      );
      return { ephemeral: false, problems, warnings };
    }
    warnings.push(
      `${JWT_PLATFORM_SECRET_VAR} is not set: development is using an ephemeral per-process secret, so console sessions will not survive an api restart`,
    );
    return { ephemeral: true, problems, warnings };
  }

  if (configured.length < PLATFORM_SECRET_MIN_LENGTH) {
    const message = `${JWT_PLATFORM_SECRET_VAR} is too short (${configured.length} characters, minimum ${PLATFORM_SECRET_MIN_LENGTH})`;
    if (production) problems.push(message);
    else warnings.push(message);
  }

  // Reusing a tenant secret is fatal in every mode: it is the exact failure R1
  // exists to remove, and no working deployment depends on it.
  for (const other of PLATFORM_SECRET_MUST_DIFFER_FROM) {
    const otherValue = (env[other] ?? '').trim();
    if (otherValue && constantTimeEquals(configured, otherValue)) {
      problems.push(`${JWT_PLATFORM_SECRET_VAR} must differ from ${other} — reuse means one leak compromises both`);
    }
  }

  // A secret that is also present in another variable NOT on the list above is
  // still a reuse smell; report it as a warning so it can be investigated
  // without refusing to boot on a coincidence.
  for (const [key, value] of Object.entries(env)) {
    if (!value || key === JWT_PLATFORM_SECRET_VAR) continue;
    if (PLATFORM_SECRET_MUST_DIFFER_FROM.includes(key)) continue;
    const trimmed = value.trim();
    if (trimmed.length >= PLATFORM_SECRET_MIN_LENGTH && constantTimeEquals(configured, trimmed)) {
      warnings.push(`${JWT_PLATFORM_SECRET_VAR} has the same value as ${key}`);
    }
  }

  return { ephemeral: false, problems, warnings };
}

let cachedSecret: string | null = null;
let cachedIsEphemeral = false;

/**
 * The signing secret for platform sessions. Generated once per process when the
 * variable is unset outside production; never persisted, never logged.
 *
 * Throws when the configuration is fatal (production without a secret, a secret
 * that is too short in production, or a secret reused from the tenant side).
 */
export function platformSecret(env: NodeJS.ProcessEnv = process.env): string {
  if (cachedSecret) return cachedSecret;
  const report = inspectPlatformSecret(env);
  if (report.problems.length) {
    // Names only. The message never contains a secret value.
    throw new Error(`platform secret configuration refused: ${report.problems.join('; ')}`);
  }
  if (report.ephemeral) {
    cachedSecret = generatePlatformSecret();
    cachedIsEphemeral = true;
  } else {
    cachedSecret = (env[JWT_PLATFORM_SECRET_VAR] ?? '').trim();
    cachedIsEphemeral = false;
  }
  return cachedSecret;
}

/** True when the current process is using a generated, non-persisted secret. */
export function isEphemeralPlatformSecret(): boolean {
  return cachedIsEphemeral;
}

/** Test seam: drop the cached secret so the next call re-evaluates the environment. */
export function resetPlatformSecretCacheForTests(): void {
  cachedSecret = null;
  cachedIsEphemeral = false;
}
