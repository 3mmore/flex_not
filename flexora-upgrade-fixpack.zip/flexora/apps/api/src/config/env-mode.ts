/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 17 (PHASE M1) — what environment is this? Stated exactly once, and it
 * FAILS CLOSED.
 *
 * Before this file, every call site compared `process.env.NODE_ENV === 'production'`
 * — an exact, lowercase string match. That has three ways to silently disable
 * every production safeguard at once:
 *
 *   NODE_ENV unset            -> not production -> validation skipped,
 *                                cookies not flagged secure, TLS on redis not
 *                                required, the whole safety net off
 *   NODE_ENV='Production'     -> same, from a single capital letter
 *   NODE_ENV='prod'/'PROD '   -> same
 *
 * An unset variable is the common case: it happens on a one-off `node dist/main.js`,
 * in a container that forgot to inherit the env, and in any wrapper that does not
 * forward it. Failing *open* there is the worst possible default.
 *
 * THE RULE: development is opt-in. The environment is DEVELOPMENT or TEST only
 * when NODE_ENV (trimmed, lowercased) is exactly "development" or "test".
 * Everything else — unset, "", "Production", "prod", " staging " — is PRODUCTION.
 *
 * Read lazily, never cached at module load: tests mutate process.env, and a
 * cached answer would make those tests lie.
 */
export type EnvMode = 'development' | 'test' | 'production';

/** NODE_ENV normalised: trimmed and lower-cased. Empty string when unset. */
export function rawNodeEnv(): string {
  return (process.env.NODE_ENV || '').trim().toLowerCase();
}

/**
 * The mode implied by ONE raw NODE_ENV value. This is the rule, stated once.
 *
 * PHASE O1.3/O4.2: the boot guards take an explicit `env` object so they can be
 * tested (and reasoned about) without mutating the process environment. They must
 * not restate the rule to do that, so the rule itself is a function of a value,
 * and `envMode()` below is simply that function applied to `process.env`.
 */
export function envModeOf(rawNodeEnvValue: string | undefined): EnvMode {
  const raw = (rawNodeEnvValue || '').trim().toLowerCase();
  if (raw === 'development') return 'development';
  if (raw === 'test') return 'test';
  // Unset, empty, "Production", "prod", "staging", anything unrecognised:
  // the safe answer is production.
  return 'production';
}

export function envMode(): EnvMode {
  return envModeOf(rawNodeEnv());
}

/** `envModeOf(value) === 'production'`, for a caller holding its own env object. */
export function isProductionEnv(rawNodeEnvValue: string | undefined): boolean {
  const mode = envModeOf(rawNodeEnvValue);
  return mode !== 'development' && mode !== 'test';
}

export function isTest(): boolean {
  return envMode() === 'test';
}

export function isDevelopment(): boolean {
  return envMode() === 'development';
}

/** True unless NODE_ENV explicitly says development or test. */
export function isProduction(): boolean {
  return !isDevelopment() && !isTest();
}
