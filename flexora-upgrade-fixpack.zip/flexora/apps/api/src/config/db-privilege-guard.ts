/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE O1.3 + O4.2 — how much database power does THIS process hold?
 *
 * Two separate questions, both answered before the API accepts a single request:
 *
 * 1. O1.3 — does it hold a *migration* credential?
 *    `prisma/schema.prisma` declares `directUrl = env("DIRECT_URL")`, and until
 *    Phase O the api container ran `prisma migrate deploy` in its CMD, so the
 *    internet-facing process was handed the database OWNER's connection string.
 *    Migrations now run in docker-compose.yml's one-shot `migrate` service, and
 *    compose passes the api `DIRECT_URL: ${DATABASE_URL:?required}` — the same
 *    restricted value. This guard makes that invariant explicit: in production
 *    the two URLs must name the SAME database user, otherwise the container has
 *    been given DDL rights it no longer needs (CREATE EXTENSION, ALTER ROLE,
 *    dropping the RLS policies that keep one gym out of another's data).
 *
 * 2. O4.2 — is the role it connects with privileged?
 *    Row Level Security is the tenant boundary. It is enforced by policies, and
 *    Postgres exempts two kinds of role from every policy: SUPERUSER, and any
 *    role with BYPASSRLS. A deployment that points DATABASE_URL at the owner
 *    role therefore has no tenant isolation at all, and nothing in the
 *    application can tell — every query silently returns every gym's rows.
 *    So the role's attributes are read from the catalog at boot
 *    (`SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`)
 *    and production refuses to serve traffic if either is true.
 *
 * Both checks FAIL CLOSED: if the attributes cannot be read in production, the
 * process does not start. A guard that skips itself when the database is
 * unreachable is not a guard.
 *
 * NOTHING HERE EVER PRINTS A PASSWORD. Messages name variables, database users
 * and role attributes — never a connection string, never a secret value.
 */
import { Logger } from '@nestjs/common';

import { envModeOf, isProductionEnv } from './env-mode';

/** Raw-SQL query function (PrismaService.$queryRawUnsafe in production code). */
export type RawQuery = <T = unknown>(sql: string) => Promise<T>;

/** What `pg_roles` says about the role this process actually connected as. */
export interface RuntimeRole {
  rolname: string;
  rolsuper: boolean;
  rolbypassrls: boolean;
}

/**
 * The user part of a connection URL, percent-decoded, or null when there is
 * none / the URL cannot be parsed. Never throws, never logs the value.
 */
export function urlUser(raw: string | undefined | null): string | null {
  if (!raw) return null;
  try {
    const u = new URL(raw.trim());
    if (!u.username) return null;
    try {
      return decodeURIComponent(u.username);
    } catch {
      return u.username; // a malformed escape is still a name; do not throw
    }
  } catch {
    return null;
  }
}

/**
 * O1.3: in production, DIRECT_URL must name the same database user as
 * DATABASE_URL. Returns an error message (naming variables and users, never
 * passwords) or null when the invariant holds.
 *
 * Unset/empty DIRECT_URL is NOT this function's problem — REQUIRED_ENV in
 * env-validation.ts already refuses to boot without it, and that check runs
 * first.
 */
export function directUrlUserProblem(env: NodeJS.ProcessEnv = process.env): string | null {
  if (!isProductionEnv(env.NODE_ENV)) return null;

  const databaseUser = urlUser(env.DATABASE_URL);
  const directUser = urlUser(env.DIRECT_URL);

  if (!databaseUser || !directUser) {
    // One of them has no user at all (e.g. trust auth). That is a different
    // problem and env-validation.ts's URL checks own it; do not guess here.
    return null;
  }
  if (databaseUser === directUser) return null;

  return (
    'DIRECT_URL and DATABASE_URL name different database users ' +
    `(DATABASE_URL user "${databaseUser}", DIRECT_URL user "${directUser}"). ` +
    'Since Phase O the API no longer runs migrations — docker-compose.yml\'s one-shot ' +
    '`migrate` service does, and it is the only place that may hold the owner credential. ' +
    'Point DIRECT_URL at the same restricted runtime role as DATABASE_URL ' +
    '(`DIRECT_URL: ${DATABASE_URL:?required}` in compose), and give the owner URL to the ' +
    'migrate service only.'
  );
}

/** Read the connected role's attributes straight from the catalog. */
export async function fetchRuntimeRole(query: RawQuery): Promise<RuntimeRole> {
  const rows = await query<Array<Record<string, unknown>>>(
    'SELECT current_user AS rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user',
  );
  const row = (rows || [])[0];
  if (!row) {
    throw new Error('pg_roles returned no row for current_user — cannot verify database privileges');
  }
  return {
    rolname: String(row.rolname ?? ''),
    // Postgres booleans come back as JS booleans through Prisma, but a driver
    // could hand back 't'/'f' — normalise instead of trusting the shape.
    rolsuper: toBool(row.rolsuper),
    rolbypassrls: toBool(row.rolbypassrls),
  };
}

function toBool(v: unknown): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') return v.toLowerCase() === 't' || v.toLowerCase() === 'true';
  return false;
}

/** O4.2: is this role allowed to serve production traffic? */
export function runtimeRoleProblem(role: RuntimeRole): string | null {
  const problems: string[] = [];
  if (role.rolsuper) problems.push('it is a SUPERUSER');
  if (role.rolbypassrls) problems.push('it has BYPASSRLS');
  if (!problems.length) return null;

  return (
    `DATABASE_URL connects as "${role.rolname || 'unknown'}" and ${problems.join(' and ')}. ` +
    'Row Level Security is the boundary between gyms, and Postgres exempts SUPERUSER and ' +
    'BYPASSRLS roles from every policy — so with this role the API would read and write ' +
    'every gym\'s data with no tenant filtering and nothing in the application would notice. ' +
    'Point DATABASE_URL at the restricted runtime role instead (NOSUPERUSER NOBYPASSRLS, ' +
    'see apps/api/prisma/migrations/202607050001_flexora_app_role_force_rls and ' +
    'docs/DATABASE_SETUP.md), and keep the owner credential for the one-shot `migrate` ' +
    'service only.'
  );
}

/** One-line, secret-free description for the boot log. */
export function describeRuntimeRole(role: RuntimeRole): string {
  return `database role "${role.rolname || 'unknown'}" (superuser=${role.rolsuper}, bypassrls=${role.rolbypassrls})`;
}

export interface DbPrivilegeReport {
  /** Non-empty only when something must stop the boot (production). */
  errors: string[];
  /** Non-fatal notes (development/test, or a role that could not be read). */
  warnings: string[];
  /** The role attributes, when they could be read. */
  role?: RuntimeRole;
}

/**
 * Run both checks. Pure decision logic: it never exits and never throws for a
 * policy reason, so it is unit-testable without a database — `main.ts` decides
 * what to do with the result (throw in production, warn otherwise).
 */
export async function checkDbPrivileges(
  query: RawQuery,
  env: NodeJS.ProcessEnv = process.env,
): Promise<DbPrivilegeReport> {
  const errors: string[] = [];
  const warnings: string[] = [];
  const mode = envModeOf(env.NODE_ENV);
  const production = mode === 'production';

  const urlProblem = directUrlUserProblem(env);
  if (urlProblem) {
    if (production) errors.push(urlProblem);
    else warnings.push(urlProblem);
  }

  let role: RuntimeRole | undefined;
  try {
    role = await fetchRuntimeRole(query);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    const message =
      `Could not read this process's database role attributes (rolsuper/rolbypassrls) from ` +
      `pg_roles: ${detail}. Refusing to continue in production because tenant isolation ` +
      `cannot be verified (fail closed).`;
    if (production) errors.push(message);
    else warnings.push(message);
    return { errors, warnings };
  }

  const roleProblem = runtimeRoleProblem(role);
  if (roleProblem) {
    if (production) errors.push(roleProblem);
    else warnings.push(`${roleProblem} (allowed in ${mode} mode, refused in production)`);
  }

  return { errors, warnings, role };
}

/**
 * Boot-time enforcement, called from main.ts after the app is constructed and
 * BEFORE `app.listen()`: no request is ever served by a process holding more
 * database power than it needs.
 *
 * Production: any error throws (bootstrap catches it, prints `FATAL: bootstrap
 * failed <message>` and exits 1). Development/test: the same findings are
 * logged as warnings, because a local stack legitimately uses the owner role.
 * The effective role is logged in EVERY mode — that line is the evidence an
 * operator reads to confirm which role the process actually got.
 */
export async function enforceDbPrivileges(
  query: RawQuery,
  logger: Logger,
  env: NodeJS.ProcessEnv = process.env,
): Promise<DbPrivilegeReport> {
  const report = await checkDbPrivileges(query, env);

  for (const w of report.warnings) logger.warn(w);
  if (report.role) {
    logger.log(
      `database privilege check: ${describeRuntimeRole(report.role)} — mode=${envModeOf(env.NODE_ENV)}` +
        (report.errors.length ? ' — REFUSED' : ' — accepted'),
    );
  }
  if (report.errors.length) {
    throw new Error(report.errors.join(' | '));
  }
  return report;
}
