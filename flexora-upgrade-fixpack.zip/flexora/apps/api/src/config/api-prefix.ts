/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE Q2 — ONE definition of the API's global prefix.
 *
 * `main.ts` used to call `app.setGlobalPrefix('api')` with a literal, and
 * `app.module.ts` listed middleware exclusions as `"api/health/live"` literals.
 * Two separate places encoding the same fact is how the PHASE P3 probe exclusion
 * ended up dead: Nest's `RouteInfoPathExtractor` PREPENDS the global prefix to
 * every non-wildcard path handed to `.exclude()` / `.forRoutes()`, so the literal
 * `"api/health/live"` was matched as `/api/api/health/live` and never matched a
 * real request (measured with Nest 11's own extractor — see
 * src/common/health/health-probe-isolation.spec.ts).
 *
 * Everything that needs the prefix now imports it from here, so the probe path
 * registry can derive BOTH the prefixed and the prefix-free form of a route from
 * route metadata instead of anyone having to remember which form a given Nest API
 * expects.
 */
export const API_GLOBAL_PREFIX = 'api';
