/**
 * PHASE O1.3 + O4.2 — how much database power does the API process hold?
 *
 * Two invariants, both enforced before the API accepts a request:
 *
 *  O1.3  the api container must not hold the migration/owner credential: in
 *        production, DIRECT_URL and DATABASE_URL must name the SAME database
 *        user (compose now passes `DIRECT_URL: ${DATABASE_URL:?required}`, and
 *        the one-shot `migrate` service is the only place with the owner URL);
 *  O4.2  the role it connects with must not be SUPERUSER or BYPASSRLS, because
 *        Postgres exempts both from every row-level-security policy — and RLS is
 *        the only thing standing between one gym's data and another's.
 *
 * The second half of this file runs against the REAL database when
 * FLEXORA_APP_TEST_PASSWORD is available (the restricted role created by
 * migration 202607050001_flexora_app_role_force_rls) and skips otherwise, the
 * same convention login-under-rls.spec.ts uses.
 *
 * Messages name variables, database users and role attributes. They never name a
 * password, and three tests below assert exactly that.
 */
import { PrismaClient } from '@prisma/client';
import { Logger } from '@nestjs/common';

import {
  checkDbPrivileges,
  describeRuntimeRole,
  directUrlUserProblem,
  enforceDbPrivileges,
  fetchRuntimeRole,
  runtimeRoleProblem,
  urlUser,
  type RawQuery,
  type RuntimeRole,
} from './db-privilege-guard';

const REAL_ENV = { ...process.env } as NodeJS.ProcessEnv;

function withEnv(overrides: Record<string, string | undefined>): void {
  const next: NodeJS.ProcessEnv = { ...REAL_ENV };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === undefined) delete next[key];
    else next[key] = value;
  }
  process.env = next;
}

afterEach(() => {
  process.env = REAL_ENV;
});

/** Fixture credentials: they must never appear in a message. */
const OWNER_PW = 'OwnerFixturePass2026';
const APP_PW = 'AppFixturePass2026';
const OWNER_URL = `postgresql://flexora:${OWNER_PW}@localhost:5432/flexora?schema=public`;
const APP_URL = `postgresql://flexora_app:${APP_PW}@localhost:5432/flexora?schema=public`;

const queryReturning = (role: Partial<RuntimeRole> & { rolname: string }): RawQuery => async () => [
  { rolname: role.rolname, rolsuper: role.rolsuper ?? false, rolbypassrls: role.rolbypassrls ?? false },
];
const queryThrowing = (message: string): RawQuery => async () => {
  throw new Error(message);
};

describe('PHASE O1.3 — urlUser()', () => {
  it('reads the user out of a connection URL', () => {
    expect(urlUser(OWNER_URL)).toBe('flexora');
    expect(urlUser(APP_URL)).toBe('flexora_app');
  });

  it('percent-decodes the user (a @ in a username arrives as %40)', () => {
    expect(urlUser('postgresql://ops%40flexora:pw@db:5432/app')).toBe('ops@flexora');
  });

  it('returns null for a URL with no user, and for garbage, without throwing', () => {
    expect(urlUser('postgresql://db:5432/app')).toBeNull();
    expect(urlUser('not a url')).toBeNull();
    expect(urlUser('')).toBeNull();
    expect(urlUser(undefined)).toBeNull();
  });
});

describe('PHASE O1.3 — DIRECT_URL must not be an owner credential in production', () => {
  it('refuses when the two URLs name different database users', () => {
    const problem = directUrlUserProblem({
      NODE_ENV: 'production',
      DATABASE_URL: APP_URL,
      DIRECT_URL: OWNER_URL,
    } as NodeJS.ProcessEnv);
    expect(problem).not.toBeNull();
    expect(problem).toContain('DATABASE_URL');
    expect(problem).toContain('DIRECT_URL');
    expect(problem).toContain('flexora_app');
    expect(problem).toContain('flexora');
    expect(problem).toContain('migrate');
  });

  it('accepts the Phase O wiring: DIRECT_URL is the same restricted URL', () => {
    expect(
      directUrlUserProblem({ NODE_ENV: 'production', DATABASE_URL: APP_URL, DIRECT_URL: APP_URL } as NodeJS.ProcessEnv),
    ).toBeNull();
  });

  it('accepts the same user reached through different hosts/ports (the user is the invariant)', () => {
    expect(
      directUrlUserProblem({
        NODE_ENV: 'production',
        DATABASE_URL: APP_URL,
        DIRECT_URL: `postgresql://flexora_app:${APP_PW}@db.internal:6432/flexora`,
      } as NodeJS.ProcessEnv),
    ).toBeNull();
  });

  it('is not applied outside production (a local stack legitimately migrates as the owner)', () => {
    for (const mode of ['development', 'test']) {
      expect(
        directUrlUserProblem({ NODE_ENV: mode, DATABASE_URL: APP_URL, DIRECT_URL: OWNER_URL } as NodeJS.ProcessEnv),
      ).toBeNull();
    }
  });

  it('does not guess when a URL has no user at all (env-validation owns that)', () => {
    expect(
      directUrlUserProblem({
        NODE_ENV: 'production',
        DATABASE_URL: 'postgresql://localhost:5432/flexora',
        DIRECT_URL: OWNER_URL,
      } as NodeJS.ProcessEnv),
    ).toBeNull();
  });

  it('never prints either password', () => {
    const problem = directUrlUserProblem({
      NODE_ENV: 'production',
      DATABASE_URL: APP_URL,
      DIRECT_URL: OWNER_URL,
    } as NodeJS.ProcessEnv);
    expect(problem).not.toContain(APP_PW);
    expect(problem).not.toContain(OWNER_PW);
  });
});

describe('PHASE O4.2 — runtime role attributes', () => {
  it('refuses a SUPERUSER', () => {
    const problem = runtimeRoleProblem({ rolname: 'flexora', rolsuper: true, rolbypassrls: false });
    expect(problem).toContain('SUPERUSER');
    expect(problem).toContain('DATABASE_URL');
    expect(problem).toContain('flexora');
  });

  it('refuses BYPASSRLS even without superuser', () => {
    expect(runtimeRoleProblem({ rolname: 'appish', rolsuper: false, rolbypassrls: true })).toContain('BYPASSRLS');
  });

  it('names both when a role has both', () => {
    const problem = runtimeRoleProblem({ rolname: 'postgres', rolsuper: true, rolbypassrls: true });
    expect(problem).toContain('SUPERUSER');
    expect(problem).toContain('BYPASSRLS');
  });

  it('accepts NOSUPERUSER NOBYPASSRLS (the documented runtime role)', () => {
    expect(runtimeRoleProblem({ rolname: 'flexora_app', rolsuper: false, rolbypassrls: false })).toBeNull();
  });

  it('explains why, so the message is actionable', () => {
    const problem = runtimeRoleProblem({ rolname: 'flexora', rolsuper: true, rolbypassrls: false }) ?? '';
    expect(problem).toMatch(/Row Level Security/i);
    expect(problem).toContain('202607050001_flexora_app_role_force_rls');
  });
});

describe('PHASE O4.2 — fetchRuntimeRole() normalises whatever the driver returns', () => {
  it.each([
    [true, false],
    ['t', 'f'],
    ['true', 'false'],
    [1, 0],
  ])('rolsuper=%j rolbypassrls=%j', async (rolsuper, rolbypassrls) => {
    const query: RawQuery = async () => [{ rolname: 'flexora_app', rolsuper, rolbypassrls }];
    const role = await fetchRuntimeRole(query);
    expect(role).toEqual({ rolname: 'flexora_app', rolsuper: true, rolbypassrls: false });
  });

  it('throws when the catalog returns no row (fail closed, not fail open)', async () => {
    await expect(fetchRuntimeRole(async () => [])).rejects.toThrow(/pg_roles/);
  });

  it('asks for the attributes of the role it actually connected as', async () => {
    let sql = '';
    const query: RawQuery = async (s: string) => {
      sql = s;
      return [{ rolname: 'x', rolsuper: false, rolbypassrls: false }];
    };
    await fetchRuntimeRole(query);
    expect(sql).toContain('rolsuper');
    expect(sql).toContain('rolbypassrls');
    expect(sql).toContain('current_user');
  });
});

describe('PHASE O4.2 — checkDbPrivileges() decision table', () => {
  const env = (mode: string) => ({ NODE_ENV: mode, DATABASE_URL: APP_URL, DIRECT_URL: APP_URL } as NodeJS.ProcessEnv);

  it('production + SUPERUSER => error', async () => {
    withEnv(env('production'));
    const report = await checkDbPrivileges(queryReturning({ rolname: 'flexora', rolsuper: true }));
    expect(report.errors.length).toBeGreaterThan(0);
    expect(report.errors.join(' ')).toContain('SUPERUSER');
  });

  it('production + flexora_app (NOSUPERUSER NOBYPASSRLS) => boots', async () => {
    withEnv(env('production'));
    const report = await checkDbPrivileges(queryReturning({ rolname: 'flexora_app' }));
    expect(report.errors).toEqual([]);
    expect(report.role).toEqual({ rolname: 'flexora_app', rolsuper: false, rolbypassrls: false });
  });

  it.each(['development', 'test'])('%s + SUPERUSER => warning only, no error', async (mode) => {
    withEnv(env(mode));
    const report = await checkDbPrivileges(queryReturning({ rolname: 'flexora', rolsuper: true, rolbypassrls: true }));
    expect(report.errors).toEqual([]);
    expect(report.warnings.length).toBeGreaterThan(0);
    expect(report.role?.rolsuper).toBe(true);
  });

  it('production + an owner-privileged DIRECT_URL => error even with a good role', async () => {
    withEnv({ NODE_ENV: 'production', DATABASE_URL: APP_URL, DIRECT_URL: OWNER_URL } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges(queryReturning({ rolname: 'flexora_app' }));
    expect(report.errors.join(' ')).toContain('DIRECT_URL');
  });

  it('fails CLOSED in production when the attributes cannot be read', async () => {
    withEnv(env('production'));
    const report = await checkDbPrivileges(queryThrowing('connect ECONNREFUSED 127.0.0.1:5432'));
    expect(report.errors.length).toBe(1);
    expect(report.errors[0]).toMatch(/cannot be verified|fail closed/i);
    expect(report.role).toBeUndefined();
  });

  it('warns instead of failing when the attributes cannot be read outside production', async () => {
    withEnv(env('development'));
    const report = await checkDbPrivileges(queryThrowing('connect ECONNREFUSED'));
    expect(report.errors).toEqual([]);
    expect(report.warnings.length).toBe(1);
  });

  it('no message ever contains a password', async () => {
    withEnv({ NODE_ENV: 'production', DATABASE_URL: APP_URL, DIRECT_URL: OWNER_URL } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges(queryReturning({ rolname: 'flexora', rolsuper: true }));
    const all = [...report.errors, ...report.warnings].join(' ');
    expect(all).not.toContain(APP_PW);
    expect(all).not.toContain(OWNER_PW);
  });
});

describe('PHASE O4.2 — enforceDbPrivileges() (what main.ts calls before listen())', () => {
  const env = (mode: string) => ({ NODE_ENV: mode, DATABASE_URL: APP_URL, DIRECT_URL: APP_URL } as NodeJS.ProcessEnv);
  const fakeLogger = () => {
    const lines: string[] = [];
    return {
      lines,
      logger: { warn: (m: string) => lines.push(`WARN ${m}`), log: (m: string) => lines.push(`LOG ${m}`) } as unknown as Logger,
    };
  };

  it('throws in production for a SUPERUSER, so the process exits before serving traffic', async () => {
    withEnv(env('production'));
    const { logger } = fakeLogger();
    await expect(enforceDbPrivileges(queryReturning({ rolname: 'flexora', rolsuper: true }), logger)).rejects.toThrow(
      /SUPERUSER/,
    );
  });

  it('resolves in production for the restricted role, and logs which role it accepted', async () => {
    withEnv(env('production'));
    const { logger, lines } = fakeLogger();
    const report = await enforceDbPrivileges(queryReturning({ rolname: 'flexora_app' }), logger);
    expect(report.errors).toEqual([]);
    expect(lines.join('\n')).toContain('database privilege check');
    expect(lines.join('\n')).toContain('flexora_app');
    expect(lines.join('\n')).toContain('accepted');
  });

  it('warns but resolves outside production', async () => {
    withEnv(env('development'));
    const { logger, lines } = fakeLogger();
    const report = await enforceDbPrivileges(
      queryReturning({ rolname: 'flexora', rolsuper: true, rolbypassrls: true }),
      logger,
    );
    expect(report.errors).toEqual([]);
    expect(lines.some((l) => l.startsWith('WARN'))).toBe(true);
  });

  it('describeRuntimeRole prints attributes only', () => {
    const line = describeRuntimeRole({ rolname: 'flexora_app', rolsuper: false, rolbypassrls: false });
    expect(line).toContain('superuser=false');
    expect(line).toContain('bypassrls=false');
    expect(line).not.toContain(APP_PW);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// REAL database: the owner role must be refused, flexora_app must be accepted.
// ─────────────────────────────────────────────────────────────────────────────
const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const REAL_OWNER_URL = process.env.DATABASE_URL;
const maybeDescribe = APP_PASSWORD && REAL_OWNER_URL ? describe : describe.skip;

maybeDescribe('PHASE O4.2 — against the real database', () => {
  let owner: PrismaClient;
  let app: PrismaClient;

  function appUrl(): string {
    const url = new URL(REAL_OWNER_URL!);
    url.username = 'flexora_app';
    url.password = APP_PASSWORD!;
    url.searchParams.set('connection_limit', '1');
    return url.toString();
  }

  beforeAll(async () => {
    owner = new PrismaClient({ datasources: { db: { url: REAL_OWNER_URL } } });
    app = new PrismaClient({ datasources: { db: { url: appUrl() } } });
    await owner.$connect();
    await app.$connect();
  });

  afterAll(async () => {
    await owner.$disconnect().catch(() => undefined);
    await app.$disconnect().catch(() => undefined);
  });

  it('the owner/superuser role is REFUSED in production', async () => {
    withEnv({
      NODE_ENV: 'production',
      DATABASE_URL: REAL_OWNER_URL,
      DIRECT_URL: REAL_OWNER_URL,
    } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges((sql) => owner.$queryRawUnsafe(sql));
    expect(report.role?.rolsuper).toBe(true);
    expect(report.errors.length).toBeGreaterThan(0);
    expect(report.errors.join(' ')).toContain('SUPERUSER');
  });

  it('flexora_app (NOSUPERUSER NOBYPASSRLS) is ACCEPTED in production', async () => {
    withEnv({ NODE_ENV: 'production', DATABASE_URL: appUrl(), DIRECT_URL: appUrl() } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges((sql) => app.$queryRawUnsafe(sql));
    expect(report.role).toBeDefined();
    expect(report.role?.rolname).toBe('flexora_app');
    expect(report.role?.rolsuper).toBe(false);
    expect(report.role?.rolbypassrls).toBe(false);
    expect(report.errors).toEqual([]);
  });

  it('the same superuser connection is only a warning in development', async () => {
    withEnv({
      NODE_ENV: 'development',
      DATABASE_URL: REAL_OWNER_URL,
      DIRECT_URL: REAL_OWNER_URL,
    } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges((sql) => owner.$queryRawUnsafe(sql));
    expect(report.errors).toEqual([]);
    expect(report.warnings.length).toBeGreaterThan(0);
  });

  it('no message from a real connection contains the real password', async () => {
    withEnv({ NODE_ENV: 'production', DATABASE_URL: REAL_OWNER_URL, DIRECT_URL: appUrl() } as NodeJS.ProcessEnv);
    const report = await checkDbPrivileges((sql) => owner.$queryRawUnsafe(sql));
    const all = [...report.errors, ...report.warnings].join(' ');
    if (APP_PASSWORD) expect(all).not.toContain(APP_PASSWORD);
    const ownerPassword = new URL(REAL_OWNER_URL!).password;
    if (ownerPassword) expect(all).not.toContain(decodeURIComponent(ownerPassword));
  });
});
