/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Global, Module } from '@nestjs/common';
import { RedisService } from './redis.service';
import { CronLeadershipService } from '../common/services/cron-leadership.service';
import { InstanceIdService } from '../common/services/instance-id.service';

@Global()
@Module({
  providers: [RedisService, CronLeadershipService, InstanceIdService],
  exports: [RedisService, CronLeadershipService, InstanceIdService],
})
export class RedisModule {}
