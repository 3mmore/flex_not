/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE O1.4: the "may I talk to Redis this way?" decision moved to
 * config/redis-transport.ts, which every Redis client in this codebase now
 * shares (this service, the socket.io adapter in realtime.gateway.ts, and
 * scheduler.integration.ts). The check that used to live here —
 * `isProduction() && !url.startsWith('rediss://')` — was a string prefix test
 * with a message that named neither the opt-out nor the compose profile, and it
 * was duplicated (badly) elsewhere. TLS material for rediss:// is read there
 * too, from REDIS_TLS_CA_FILE / REDIS_TLS_CERT_FILE / REDIS_TLS_KEY_FILE.
 */
import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import Redis from 'ioredis';

import { assertRedisTransport, redisConnectionOptions } from './redis-transport';

/**
 * PHASE P3 bounds. Both are exported so the resilience spec can assert the
 * client was actually constructed with them (a bound that is silently dropped by
 * a future options spread is exactly the regression worth catching).
 *
 * 1500 ms per command keeps a Redis-dependent request well inside the 2 s budget
 * the PHASE P3 acceptance criteria require, while still tolerating a slow-but-
 * alive server; 2000 ms to establish a connection is enough for a container
 * starting next door, and short enough that an unreachable host is reported
 * instead of hanging.
 */
export const REDIS_COMMAND_TIMEOUT_MS = Number(process.env.REDIS_COMMAND_TIMEOUT_MS || 1500);
export const REDIS_CONNECT_TIMEOUT_MS = Number(process.env.REDIS_CONNECT_TIMEOUT_MS || 2000);

@Injectable()
export class RedisService implements OnModuleDestroy {
  public readonly client: Redis;
  private readonly transportLogger = new Logger('RedisTransport');
  constructor() {
    const url = process.env.REDIS_URL || 'redis://localhost:6379';
    const decision = assertRedisTransport(url);
    // Loud, once, at boot: a deployment relying on the plaintext opt-out should
    // be able to see that in its own logs (never prints the password).
    if (decision.warn) this.transportLogger.warn(decision.warn);
    this.client = new Redis(url, {
      // ---------------------------------------------------------------------
      // PHASE P3 — every Redis interaction on a request path is now BOUNDED.
      //
      // `maxRetriesPerRequest: null` meant "never give up on a command": with the
      // server unreachable, ioredis parked the command in its offline queue and
      // retried forever, so an `await redis.get(...)` in a request handler never
      // settled. The request hung (holding a socket, a DB connection and a
      // worker slot) until the client or the proxy gave up — a Redis outage
      // became an API outage.
      //
      // Now: no offline queue (a command issued while disconnected rejects at
      // once), no per-request retry, and a hard per-command timeout. The
      // *connection* still retries in the background via retryStrategy, so
      // recovery is automatic and nothing has to be restarted.
      //
      // Callers must treat a rejection as "Redis is unavailable", not as "no
      // value": caches fall back to the database, and the fail-closed paths
      // (OTP, access codes, renewal-request limits, brute-force guard) stay
      // fail-closed. DependencyUnavailableFilter turns an unhandled rejection on
      // a request path into 503 + Retry-After instead of a hang or a 500.
      // ---------------------------------------------------------------------
      maxRetriesPerRequest: 0,
      enableOfflineQueue: false,
      commandTimeout: REDIS_COMMAND_TIMEOUT_MS,
      lazyConnect: false,
      retryStrategy: (times) => Math.min(times * 200, 2000),
      connectTimeout: REDIS_CONNECT_TIMEOUT_MS,
      ...redisConnectionOptions(decision),
    });
    this.client.on('error', (err) => {
      console.error('[RedisService] Connection error:', err.message);
    });
  }
  async get(key: string) {
    return this.client.get(key);
  }
  async set(key: string, value: string, ttlSeconds?: number) {
    if (ttlSeconds) return this.client.set(key, value, 'EX', ttlSeconds);
    return this.client.set(key, value);
  }
  async del(key: string) {
    return this.client.del(key);
  }
  /** Delete every key matching `prefix*` using a non-blocking SCAN.
   *  Used to invalidate ALL cached list variants (page/limit/q/status) for a
   *  tenant after a mutation, so freshly-changed data is never served stale. */
  async delByPrefix(prefix: string) {
    try {
      let cursor = '0';
      do {
        const [next, keys] = await this.client.scan(cursor, 'MATCH', `${prefix}*`, 'COUNT', 200);
        cursor = next;
        if (keys.length) await this.client.del(...keys);
      } while (cursor !== '0');
    } catch {
      /* redis down — cache simply expires by TTL instead */
    }
  }
  async onModuleDestroy() {
    try {
      await this.client.quit();
    } catch {
      this.client.disconnect();
    }
  }
}
