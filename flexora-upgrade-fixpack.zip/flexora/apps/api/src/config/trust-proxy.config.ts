/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE O4.4 — how many proxies sit in front of this process?
 *
 * `main.ts` used to hardcode `app.set('trust proxy', 1)`. Express's `trust proxy`
 * decides how many right-most `X-Forwarded-For` entries it believes when it
 * computes `req.ip`, and `req.ip` is the key for:
 *   - the login rate limiter (credential-stuffing protection),
 *   - the OTP/password-reset throttles,
 *   - the security shield's per-address counters,
 *   - audit log entries.
 *
 * Get the hop count wrong and the protection silently disappears in one of two
 * ways:
 *   too MANY hops trusted  -> a client can prepend a fake address
 *                            (`X-Forwarded-For: 6.6.6.6, <real>`) and every
 *                            request looks like it came from a different IP, so
 *                            no counter ever trips;
 *   too FEW hops trusted   -> every client behind nginx shares nginx's own
 *                            address, so one abusive user locks out the whole
 *                            building.
 *
 * So the value is configurable, validated at boot (integer 0..3), and — because
 * a wrong value is invisible in normal operation — WARN-logged with its
 * effective value every time the API starts in production.
 *
 * `1` is the default and matches the shipped nginx config, which proxies with
 * `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;` (one hop).
 * Set 2 only when there is a second trusted proxy in front of nginx (a cloud
 * load balancer or CDN), and 0 when the API is exposed directly.
 *
 * NOTE: the login limiter is per-process. With several API replicas behind a
 * load balancer each replica keeps its own counters unless the limiter's store
 * is shared; this file does not claim cluster-wide enforcement.
 */
import { Logger } from '@nestjs/common';

import { envMode, isProduction } from './env-mode';

export const TRUST_PROXY_HOPS_VAR = 'TRUST_PROXY_HOPS';
export const DEFAULT_TRUST_PROXY_HOPS = 1;
export const MIN_TRUST_PROXY_HOPS = 0;
export const MAX_TRUST_PROXY_HOPS = 3;

/**
 * Why a raw value is unusable, or null when it is fine. Unset/empty is fine —
 * the documented default applies.
 */
export function trustProxyProblem(raw: string | undefined | null): string | null {
  const value = (raw ?? '').trim();
  if (!value) return null;
  if (!/^\d+$/.test(value)) {
    return (
      `${TRUST_PROXY_HOPS_VAR} must be an integer between ${MIN_TRUST_PROXY_HOPS} and ` +
      `${MAX_TRUST_PROXY_HOPS} (a plain number of trusted proxies, no units) — the value ` +
      'set is not an integer'
    );
  }
  const n = Number(value);
  if (n < MIN_TRUST_PROXY_HOPS || n > MAX_TRUST_PROXY_HOPS) {
    return (
      `${TRUST_PROXY_HOPS_VAR} must be between ${MIN_TRUST_PROXY_HOPS} and ${MAX_TRUST_PROXY_HOPS}: ` +
      `0 = no proxy in front of the API, 1 = the shipped nginx config (default), ` +
      `2 = nginx plus one cloud load balancer/CDN, 3 = an extra hop beyond that. ` +
      `Trusting more hops than really exist lets a client spoof its own address and ` +
      `defeat every IP-based rate limit`
    );
  }
  return null;
}

/** The effective hop count: the validated value, or the documented default. */
export function trustProxyHops(env: NodeJS.ProcessEnv = process.env): number {
  const raw = (env[TRUST_PROXY_HOPS_VAR] ?? '').trim();
  if (!raw || trustProxyProblem(raw)) return DEFAULT_TRUST_PROXY_HOPS;
  return Number(raw);
}

/**
 * Boot-time log line. WARN in production (the value silently decides whether
 * IP-based rate limiting works), plain log elsewhere so tests and local runs
 * still show what was chosen. Never prints anything but the number.
 */
export function logTrustProxyHops(logger: Logger, hops: number, env: NodeJS.ProcessEnv = process.env): void {
  const configured = (env[TRUST_PROXY_HOPS_VAR] ?? '').trim();
  const line =
    `trust proxy = ${hops} hop(s) ` +
    `(${configured ? `${TRUST_PROXY_HOPS_VAR}=${configured}` : `${TRUST_PROXY_HOPS_VAR} not set, using the default`}) ` +
    `— req.ip drops this many right-most X-Forwarded-For entries; the login/OTP/security ` +
    `rate limiters key on req.ip`;
  if (isProduction()) logger.warn(line);
  else logger.log(`${line} (mode=${envMode()})`);
}
