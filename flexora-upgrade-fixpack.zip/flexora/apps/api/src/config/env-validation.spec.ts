import { execSync } from 'child_process';
/**
 * ROUND 16 (PHASE L2) — tests for the production startup validator.
 *
 * The point of these tests is the failure mode, not the happy path: a server
 * that boots with a public password, an http-only cookie or a wildcard CORS
 * origin is the bug this phase exists to prevent. Each test asserts on the
 * VARIABLE named in the error, never on the value.
 */
import {
  validateEnv,
  isDevDefault,
  urlPassword,
  validateCorsOrigin,
  DEV_DEFAULT_VALUES,
  validateRuntimeDirs,
  runtimeDirWarnings,
  dirCreationProblem,
  RUNTIME_DIR_VARS,
} from './env-validation';
import { chmodSync, mkdtempSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { isProduction, isDevelopment, isTest, envMode } from './env-mode';
import {
  validateCredentialVar, validateDistinctSecrets, validateCorsOriginHosts,
  containsDevToken, characterClasses, credentialEnvVars, enforceEnv,
} from './env-validation';
import { isCookieSecure } from './cookie-secure';

/**
 * Eight 64-hex secrets, all distinct and none containing a development token.
 * They have to be: the validator now rejects reuse across roles and rejects any
 * value carrying a dev token, so a fixture that repeats one value silently
 * "tests" a failing configuration.
 */
const HEX64 = '5a3c8ca45ae62ad5153cfe4500fe4045666a6973a6bdceb5f8a66acdc6b5175a';
const HEX64_B = '59e037eb63a85137d3775df26fe4d6d79edfd9a6f57a68fdd8eb4195815be7ec';
const HEX64_C = '632711e31a03476082362d8db5f516072e4c42b50d254abe2b2f5a6aacb88e37';
const HEX64_D = 'cef2db84495c5723d33a9c4949ba05f93d074b4b5e78bfb7dfa79308983d83cd';
const HEX64_E = 'ce22a83d6ad79bc9a89838f5cec76ca4dfe931f5c2a111fbe0a01d44a309a0e8';
const HEX64_F = '9d7f77bd1c336fd5724afb99d3c23efc5de30340d4ba9be76f8ade05b3f3fe3e';
const HEX64_G = 'd311a74558002c691b8427662901710805a5a90f8b41caf429b523f7f8f778db';
const HEX64_H = '115eee961464c5e517df412067146a1e11ec5235d82116cf95f27cc488f4191a';
// PHASE R1 / decision D2 - the owner console has its own signing secret, required in
// production and required to differ from every tenant secret, so a "fully configured
// production environment" fixture now has to carry a ninth distinct value.
const HEX64_I = 'a7d41c9e5b2f80643e1d7a9c4b6f2085e3d19a7c5b4f8062e1d3a9c7b5f2408e';

/** A complete, production-valid environment. Tests break one thing at a time. */
function prodEnv(overrides: Record<string, string | undefined> = {}): Record<string, string> {
  const base: Record<string, string> = {
    NODE_ENV: 'production',
    JWT_ACCESS_SECRET: HEX64,
    JWT_REFRESH_SECRET: HEX64_B,
    JWT_MEMBER_SECRET: HEX64_C,
    ENCRYPTION_KEY: HEX64_D,
    ENCRYPTION_SEARCH_KEY: HEX64_E,
    OTP_HMAC_SECRET: HEX64_F,
    WHATSAPP_APP_SECRET: HEX64_G,
    BACKUP_ENCRYPTION_KEY: HEX64_H.slice(0, 32),
    DATABASE_URL: 'postgresql://flexora_app:S3cureDbPassw0rd2026@db.internal:5432/flexora?schema=public',
    DIRECT_URL: 'postgresql://flexora_owner:S3cureDbPassw0rd2026@db.internal:5432/flexora?schema=public',
    REDIS_URL: 'rediss://:S3cureRedisPass2026@redis.internal:6380/0',
    CORS_ORIGIN: 'https://app.example.com',
    COOKIE_SECURE: 'true',
    FLEXORA_LICENSE_KEY: 'LIC-PROD-2026-ABCD-EFGH',
    // PHASE R0: the owner-console hostname allow-list is REQUIRED in production, so a
    // "fully configured production environment" now includes it. See the R0 block at
    // the bottom of this file for what happens when it is missing, empty or a wildcard.
    ADMIN_HOSTS: 'admin.example.com',
    // PHASE R1 / D2: required in production; missing, short or reused is fatal.
    JWT_PLATFORM_SECRET: HEX64_I,
  };
  for (const [k, v] of Object.entries(overrides)) {
    if (v === undefined) delete base[k];
    else base[k] = v;
  }
  return base;
}

const REAL_ENV = process.env;

function withEnv(env: Record<string, string>) {
  process.env = { ...env } as NodeJS.ProcessEnv;
}
afterEach(() => {
  process.env = REAL_ENV;
});

/** Assert the named variable is reported, and that no message leaks a value. */
function expectReportsVariable(errors: string[], variable: string, secretValues: string[] = []) {
  expect(errors.some((e) => e.includes(variable))).toBe(true);
  for (const v of secretValues) {
    for (const e of errors) expect(e).not.toContain(v);
  }
}

describe('validateEnv — production safety switches (PHASE L2)', () => {
  it('accepts a fully configured production environment', () => {
    withEnv(prodEnv());
    const r = validateEnv();
    expect(r.errors).toEqual([]);
    expect(r.ok).toBe(true);
  });

  // ---------------------------------------------------------------- secrets
  it.each([
    ['JWT_ACCESS_SECRET', 'JWT signing secret'],
    ['JWT_MEMBER_SECRET', 'member JWT secret'],
    ['OTP_HMAC_SECRET', 'OTP HMAC secret'],
    ['ENCRYPTION_KEY', 'encryption key'],
  ])('refuses to boot when %s is missing', (key) => {
    withEnv(prodEnv({ [key]: undefined }));
    expectReportsVariable(validateEnv().errors, key);
  });

  it.each([
    'JWT_ACCESS_SECRET',
    'JWT_REFRESH_SECRET',
    'JWT_MEMBER_SECRET',
    'OTP_HMAC_SECRET',
    'ENCRYPTION_KEY',
    'ENCRYPTION_SEARCH_KEY',
    'BACKUP_ENCRYPTION_KEY',
  ])('refuses to boot when %s is a known development default', (key) => {
    withEnv(prodEnv({ [key]: 'SuperAdmin123!' }));
    const r = validateEnv();
    expectReportsVariable(r.errors, key);
    // the value must never be echoed into the log
    expect(r.errors.join(' ')).not.toContain('SuperAdmin123!');
  });

  it('refuses to boot when a secret is shorter than the sane minimum', () => {
    withEnv(prodEnv({ OTP_HMAC_SECRET: 'abc123XYZ' }));
    const r = validateEnv();
    expectReportsVariable(r.errors, 'OTP_HMAC_SECRET');
    expect(r.errors.join(' ')).not.toContain('abc123XYZ');
  });

  it('enforces the longer 64-char minimum on encryption keys', () => {
    // 40 chars: would pass a naive "is it set?" check, must fail here
    withEnv(prodEnv({ ENCRYPTION_SEARCH_KEY: '0123456789abcdef0123456789abcdef01234567' }));
    expectReportsVariable(validateEnv().errors, 'ENCRYPTION_SEARCH_KEY');
  });

  // ------------------------------------------------------------- database
  it('refuses to boot when DATABASE_URL has no password', () => {
    withEnv(prodEnv({ DATABASE_URL: 'postgresql://flexora_app@db.internal:5432/flexora' }));
    expectReportsVariable(validateEnv().errors, 'DATABASE_URL');
  });

  it('refuses to boot when the DATABASE_URL password is a dev default', () => {
    withEnv(
      prodEnv({
        DATABASE_URL: 'postgresql://flexora_app:flexora_app_dev_pw@localhost:5432/flexora?schema=public',
      }),
    );
    const r = validateEnv();
    expectReportsVariable(r.errors, 'DATABASE_URL', ['flexora_app_dev_pw']);
  });

  // ----------------------------------------------------------------- redis
  it('refuses to boot when redis is not password protected', () => {
    withEnv(prodEnv({ REDIS_URL: 'rediss://redis.internal:6380/0', REDIS_PASSWORD: undefined }));
    const r = validateEnv();
    expect(r.errors.some((e) => e.includes('REDIS'))).toBe(true);
  });

  it('refuses to boot when the redis password is a dev default', () => {
    withEnv(prodEnv({ REDIS_URL: 'rediss://:postgres@redis.internal:6380/0' }));
    const r = validateEnv();
    expect(r.errors.some((e) => e.includes('REDIS'))).toBe(true);
    expect(r.errors.join(' ')).not.toContain('postgres');
  });

  it('requires the redis password inside REDIS_URL (REDIS_PASSWORD alone is not enough)', () => {
    // Deliberately strict: a password that is not in the url is a password the
    // client can silently fall back to not using.
    withEnv(prodEnv({ REDIS_URL: 'rediss://redis.internal:6380/0', REDIS_PASSWORD: 'S3cureRedisPass2026' }));
    expect(validateEnv().errors.some((e) => e.includes('REDIS_URL'))).toBe(true);

    withEnv(prodEnv({ REDIS_URL: 'rediss://:S3cureRedisPass2026@redis.internal:6380/0' }));
    expect(validateEnv().errors.filter((e) => e.includes('REDIS'))).toEqual([]);
  });

  // ------------------------------------------------------------------ CORS
  it('refuses to boot when CORS_ORIGIN is http in production', () => {
    withEnv(prodEnv({ CORS_ORIGIN: 'http://app.example.com' }));
    expectReportsVariable(validateEnv().errors, 'CORS_ORIGIN');
  });

  it('refuses to boot when CORS_ORIGIN is a wildcard', () => {
    withEnv(prodEnv({ CORS_ORIGIN: '*' }));
    const r = validateEnv();
    expectReportsVariable(r.errors, 'CORS_ORIGIN');
    expect(r.errors.some((e) => /wildcard/i.test(e))).toBe(true);
  });

  it('accepts several explicit https origins', () => {
    withEnv(prodEnv({ CORS_ORIGIN: 'https://app.example.com,https://admin.example.com' }));
    expect(validateEnv().errors.filter((e) => e.includes('CORS_ORIGIN'))).toEqual([]);
  });

  it('refuses to boot when CORS_ORIGIN is not set at all', () => {
    withEnv(prodEnv({ CORS_ORIGIN: undefined }));
    expectReportsVariable(validateEnv().errors, 'CORS_ORIGIN');
  });

  // ---------------------------------------------------------------- cookie
  it('refuses to boot when COOKIE_SECURE is missing', () => {
    withEnv(prodEnv({ COOKIE_SECURE: undefined }));
    expectReportsVariable(validateEnv().errors, 'COOKIE_SECURE');
  });

  it('refuses to boot when COOKIE_SECURE is explicitly false', () => {
    withEnv(prodEnv({ COOKIE_SECURE: 'false' }));
    expectReportsVariable(validateEnv().errors, 'COOKIE_SECURE');
  });

  // --------------------------------------------------------------- licence
  it('refuses to boot with a development license key', () => {
    withEnv(prodEnv({ FLEXORA_LICENSE_KEY: 'DEV-LOCAL-TEST-0000' }));
    expectReportsVariable(validateEnv().errors, 'FLEXORA_LICENSE_KEY');
  });

  // ------------------------------------------------------- dev is untouched
  it('does NOT apply the production-only gates in development', () => {
    withEnv({
      NODE_ENV: 'development',
      JWT_ACCESS_SECRET: HEX64,
      JWT_REFRESH_SECRET: HEX64_B,
      JWT_MEMBER_SECRET: HEX64_C,
      ENCRYPTION_KEY: HEX64_D,
      ENCRYPTION_SEARCH_KEY: HEX64_E,
      OTP_HMAC_SECRET: HEX64_F,
      WHATSAPP_APP_SECRET: HEX64_G,
      BACKUP_ENCRYPTION_KEY: HEX64_H.slice(0, 32),
      DATABASE_URL: 'postgresql://flexora_app:flexora_app_dev_pw@localhost:5432/flexora?schema=public',
      DIRECT_URL: 'postgresql://flexora:flexora_dev_pw@localhost:5432/flexora?schema=public',
      REDIS_URL: 'redis://localhost:6379',
      CORS_ORIGIN: 'http://localhost:3000',
      FLEXORA_LICENSE_KEY: 'DEV-LOCAL-TEST-0000',
    } as Record<string, string>);
    const r = validateEnv();
    const prodOnly = r.errors.filter((e) =>
      /CORS_ORIGIN|COOKIE_SECURE|DATABASE_URL password|too short for production|development default/.test(e),
    );
    expect(prodOnly).toEqual([]);
  });

  it('never prints any configured value in an error message', () => {
    withEnv(
      prodEnv({
        JWT_ACCESS_SECRET: 'SuperAdmin123!',
        DATABASE_URL: 'postgresql://flexora_app:flexora_app_dev_pw@localhost:5432/flexora',
        COOKIE_SECURE: 'false',
        CORS_ORIGIN: '*',
      }),
    );
    const all = validateEnv().errors.join('\n');
    expect(all).not.toContain('SuperAdmin123!');
    expect(all).not.toContain('flexora_app_dev_pw');
    // and it still says what is wrong
    expect(all).toContain('JWT_ACCESS_SECRET');
    expect(all).toContain('COOKIE_SECURE');
  });
});


describe('PHASE M1 — production is the default (fail closed on NODE_ENV)', () => {
  /**
   * The attack this closes: the production gates used to be gated on
   * `NODE_ENV === 'production'` — an exact, lower-case match. Unset it, or
   * capitalise it, and every safeguard silently switched off. These tests boot
   * the validator with the bad input rather than asserting on the helper alone.
   */

  it('treats an UNSET NODE_ENV as production and enforces every gate', () => {
    const env = prodEnv();
    delete env.NODE_ENV;
    withEnv(env);
    // sanity: with a valid config there is nothing to report either way
    expect(validateEnv().errors).toEqual([]);

    // now break production-only things on top of the unset NODE_ENV
    withEnv({ ...env, CORS_ORIGIN: 'http://app.example.com', COOKIE_SECURE: undefined });
    const r = validateEnv();
    expect(r.ok).toBe(false);
    expectReportsVariable(r.errors, 'CORS_ORIGIN');
    expectReportsVariable(r.errors, 'COOKIE_SECURE');
  });

  it('treats "Production" (capital P) as production, not development', () => {
    withEnv(prodEnv({ NODE_ENV: 'Production', CORS_ORIGIN: 'http://app.example.com', COOKIE_SECURE: undefined }));
    const r = validateEnv();
    expectReportsVariable(r.errors, 'CORS_ORIGIN');
    expectReportsVariable(r.errors, 'COOKIE_SECURE');
  });

  it.each(['prod', 'PRODUCTION', ' production ', 'staging', ''])(
    'treats %p as production',
    (value) => {
      withEnv(prodEnv({ NODE_ENV: value, CORS_ORIGIN: 'http://app.example.com' }));
      expectReportsVariable(validateEnv().errors, 'CORS_ORIGIN');
    },
  );

  it.each(['development', 'test'])('does NOT apply the production gates for %p', (value) => {
    withEnv(
      prodEnv({
        NODE_ENV: value,
        CORS_ORIGIN: 'http://localhost:3000',
        COOKIE_SECURE: undefined,
        DATABASE_URL: 'postgresql://flexora_app:flexora_app_dev_pw@localhost:5432/flexora?schema=public',
        REDIS_URL: 'redis://localhost:6379',
      }),
    );
    const prodOnly = validateEnv().errors.filter((e) =>
      /CORS_ORIGIN|COOKIE_SECURE|DATABASE_URL|REDIS/.test(e),
    );
    expect(prodOnly).toEqual([]);
  });

  it('accepts "development" with surrounding whitespace and mixed case', () => {
    withEnv(prodEnv({ NODE_ENV: '  Development  ', CORS_ORIGIN: 'http://localhost:3000' }));
    expect(isDevelopment()).toBe(true);
    expect(isProduction()).toBe(false);
  });

  it('envMode() reports the normalised mode', () => {
    withEnv({ NODE_ENV: 'test' });
    expect(envMode()).toBe('test');
    expect(isTest()).toBe(true);
    expect(isProduction()).toBe(false);

    process.env = {} as NodeJS.ProcessEnv;
    expect(envMode()).toBe('production');
    expect(isProduction()).toBe(true);
  });

  it('isCookieSecure() defaults to SECURE when NODE_ENV is unset or oddly cased', () => {
    // the old behaviour returned false here — cookies over plain http
    process.env = {} as NodeJS.ProcessEnv;
    expect(isCookieSecure()).toBe(true);

    withEnv({ NODE_ENV: 'Production' });
    expect(isCookieSecure()).toBe(true);

    withEnv({ NODE_ENV: 'development' });
    expect(isCookieSecure()).toBe(false);

    // an explicit flag still wins in either direction
    withEnv({ NODE_ENV: 'development', COOKIE_SECURE: 'true' });
    expect(isCookieSecure()).toBe(true);
    withEnv({ NODE_ENV: 'production', COOKIE_SECURE: 'false' });
    expect(isCookieSecure()).toBe(false);
  });
});


describe('PHASE M2 — every credential-bearing variable', () => {
  // ---------------------------------------------------- M2.1 other variables
  it('validates DIRECT_URL, not just DATABASE_URL', () => {
    withEnv(prodEnv({ DIRECT_URL: 'postgresql://flexora_owner:flexora_dev_pw@db.internal:5432/flexora' }));
    expectReportsVariable(validateEnv().errors, 'DIRECT_URL', ['flexora_dev_pw']);
  });

  it('refuses a DIRECT_URL with no password', () => {
    withEnv(prodEnv({ DIRECT_URL: 'postgresql://flexora_owner@db.internal:5432/flexora' }));
    expectReportsVariable(validateEnv().errors, 'DIRECT_URL');
  });

  it('validates POSTGRES_PASSWORD', () => {
    withEnv(prodEnv({ POSTGRES_PASSWORD: 'SuperAdmin123!' }));
    expectReportsVariable(validateEnv().errors, 'POSTGRES_PASSWORD', ['SuperAdmin123!']);
  });

  it('picks up a credential variable it has never heard of', () => {
    // the whole point of matching dynamically: a variable added next month is
    // validated without anyone remembering to update this file
    withEnv(prodEnv({ SHADOW_DATABASE_URL: 'postgresql://app:postgres@shadow.internal:5432/shadow' }));
    expectReportsVariable(validateEnv().errors, 'SHADOW_DATABASE_URL');

    withEnv(prodEnv({ READONLY_DB_PASSWORD: 'hunter2hunter2' }));
    expectReportsVariable(validateEnv().errors, 'READONLY_DB_PASSWORD');
  });

  it('accepts strong, distinct credentials on every variable', () => {
    withEnv(
      prodEnv({
        DIRECT_URL: 'postgresql://flexora_owner:X9mQ2vLp7!wR4tZ8y@db.internal:5432/flexora',
        POSTGRES_PASSWORD: 'X9mQ2vLp7!wR4tZ8y',
      }),
    );
    expect(validateEnv().errors).toEqual([]);
  });

  // ---------------------------------------------------------- M2.2 distinctness
  it('refuses identical JWT secrets', () => {
    withEnv(prodEnv({ JWT_REFRESH_SECRET: HEX64 })); // same as JWT_ACCESS_SECRET
    const r = validateEnv();
    expectReportsVariable(r.errors, 'JWT_ACCESS_SECRET');
    expectReportsVariable(r.errors, 'JWT_REFRESH_SECRET');
  });

  it('refuses a member JWT secret that reuses the access secret', () => {
    withEnv(prodEnv({ JWT_MEMBER_SECRET: HEX64 }));
    expectReportsVariable(validateEnv().errors, 'JWT_MEMBER_SECRET');
  });

  it('refuses identical encryption keys', () => {
    withEnv(prodEnv({ ENCRYPTION_SEARCH_KEY: HEX64_D })); // identical to ENCRYPTION_KEY
    expectReportsVariable(validateEnv().errors, 'ENCRYPTION_SEARCH_KEY');
  });

  it('refuses a backup key that reuses another secret', () => {
    withEnv(prodEnv({ BACKUP_ENCRYPTION_KEY: HEX64 })); // identical to JWT_ACCESS_SECRET
    const r = validateEnv();
    expectReportsVariable(r.errors, 'BACKUP_ENCRYPTION_KEY');
    expectReportsVariable(r.errors, 'JWT_ACCESS_SECRET');
  });

  it('refuses an OTP HMAC that reuses the encryption key', () => {
    withEnv(prodEnv({ OTP_HMAC_SECRET: HEX64_D })); // identical to ENCRYPTION_KEY
    expectReportsVariable(validateEnv().errors, 'OTP_HMAC_SECRET');
  });

  // --------------------------------------------- M2.3 token + character classes
  it('rejects a password that merely CONTAINS a development token', () => {
    // not an exact match for anything in the list — it just says "flexora"
    expect(containsDevToken('S3cureFlexoraDb2026!')).toBe(true);
    withEnv(prodEnv({ DATABASE_URL: 'postgresql://app:S3cureFlexoraDb2026!@db.internal:5432/flexora' }));
    expectReportsVariable(validateEnv().errors, 'DATABASE_URL', ['S3cureFlexoraDb2026!']);
  });

  // PHASE O3.1: class counting is gone. The value below is still rejected — it is
  // the alphabet followed by a counting run — but for a reason that measures
  // guessability instead of decoration.
  it('rejects a long but guessable database password (patterns/entropy, not class count)', () => {
    withEnv(prodEnv({ DATABASE_URL: 'postgresql://app:abcdefghijklmnop12345678@db.internal:5432/flexora' }));
    const r = validateEnv();
    expectReportsVariable(r.errors, 'DATABASE_URL');
    expect(r.errors.some((e) => /sequential run|entropy|distinct character/i.test(e))).toBe(true);
    expect(r.errors.some((e) => /character classes/i.test(e))).toBe(false);
  });

  it('rejects the same shape in the redis password', () => {
    withEnv(prodEnv({ REDIS_URL: 'rediss://:abcdefghijklmnop12345678@redis.internal:6380/0' }));
    expect(validateEnv().errors.some((e) => /REDIS_URL/.test(e) && /sequential run|entropy/i.test(e))).toBe(true);
  });

  it('accepts what the old class rule rejected: a fresh `openssl rand -hex 24`', () => {
    const v = execSync('openssl rand -hex 24').toString().trim();
    expect(v).toHaveLength(48);
    expect(characterClasses(v)).toBeLessThan(3);          // lowercase + digits only
    expect(validateCredentialVar('DATABASE_URL', `postgresql://u:${v}@h:5432/db`, true)).toEqual([]);
  });

  it('accepts a password with four classes and no dev token', () => {
    expect(validateCredentialVar('DATABASE_URL', 'postgresql://u:X9mQ2vLp7!wR4tZ8y@h:5432/db', true)).toEqual([]);
    expect(characterClasses('X9mQ2vLp7!wR4tZ8y')).toBe(4);
  });

  // ----------------------------------------------------------- M2.4 CORS hosts
  it.each([
    'http://localhost:3000',
    'https://localhost',
    'https://127.0.0.1',
    'https://10.0.0.5',
    'https://[::1]',
    'https://app.example.com,https://192.168.1.10',
  ])('refuses CORS_ORIGIN %p (localhost or IP)', (origin) => {
    withEnv(prodEnv({ CORS_ORIGIN: origin }));
    const r = validateEnv();
    expect(r.errors.some((e) => /CORS_ORIGIN/.test(e))).toBe(true);
  });

  it('accepts public https hostnames', () => {
    withEnv(prodEnv({ CORS_ORIGIN: 'https://app.example.com,https://admin.example.com' }));
    expect(validateEnv().errors.filter((e) => /CORS_ORIGIN/.test(e))).toEqual([]);
  });

  it('never prints any value it rejected', () => {
    withEnv(
      prodEnv({
        DIRECT_URL: 'postgresql://o:SuperAdmin123!@db.internal:5432/flexora',
        SHADOW_DATABASE_URL: 'postgresql://a:S3cureFlexoraDb2026!@shadow:5432/s',
        JWT_REFRESH_SECRET: HEX64,
        CORS_ORIGIN: 'https://10.0.0.5',
      }),
    );
    const all = validateEnv().errors.join('\n');
    for (const secret of ['SuperAdmin123!', 'S3cureFlexoraDb2026!', HEX64]) {
      expect(all).not.toContain(secret);
    }
    expect(all).toMatch(/DIRECT_URL/);
    expect(all).toMatch(/SHADOW_DATABASE_URL/);
  });
});

describe('M2 helpers', () => {
  it('credentialEnvVars() finds the credential variables present', () => {
    const found = credentialEnvVars({
      DATABASE_URL: 'x',
      DIRECT_URL: 'x',
      REDIS_URL: 'x',
      REDIS_PASSWORD: 'x',
      POSTGRES_PASSWORD: 'x',
      SHADOW_DATABASE_URL: 'x',
      REDIS_HOST: 'x', // not a credential
      PORT: '4000', // not a credential
      FRONTEND_URL: 'https://app.example.com', // not a db/redis credential
    } as NodeJS.ProcessEnv);
    expect(found.sort()).toEqual(
      ['DATABASE_URL', 'DIRECT_URL', 'POSTGRES_PASSWORD', 'REDIS_PASSWORD', 'REDIS_URL', 'SHADOW_DATABASE_URL'].sort(),
    );
  });

  it('validateDistinctSecrets() reports each colliding pair once', () => {
    const errors = validateDistinctSecrets({
      JWT_ACCESS_SECRET: 'same',
      JWT_REFRESH_SECRET: 'same',
      JWT_MEMBER_SECRET: 'other',
    } as NodeJS.ProcessEnv);
    expect(errors).toHaveLength(1);
    expect(errors[0]).toContain('JWT_ACCESS_SECRET');
    expect(errors[0]).toContain('JWT_REFRESH_SECRET');
  });

  it('validateCorsOriginHosts() allows public names and blocks localhost/IP', () => {
    expect(validateCorsOriginHosts('https://app.example.com')).toEqual([]);
    expect(validateCorsOriginHosts('https://localhost').length).toBe(1);
    expect(validateCorsOriginHosts('https://127.0.0.1:3000').length).toBe(1);
    expect(validateCorsOriginHosts('https://10.0.0.5').length).toBe(1);
    expect(validateCorsOriginHosts('')).toEqual([]);
  });
});

describe('L2 helpers', () => {
  it('isDevDefault recognises the documented dev passwords', () => {
    expect(isDevDefault('SuperAdmin123!')).toBe(true);
    expect(isDevDefault('flexora_app_dev_pw')).toBe(true);
    expect(isDevDefault('  postgres  ')).toBe(true);
    expect(isDevDefault('S3cureDbPassw0rd2026')).toBe(false);
    expect(DEV_DEFAULT_VALUES.size).toBeGreaterThan(10);
  });

  it('urlPassword extracts a password without exposing it elsewhere', () => {
    expect(urlPassword('postgresql://u:pw@host:5432/db')).toBe('pw');
    expect(urlPassword('postgresql://u@host:5432/db')).toBeNull();
    expect(urlPassword(undefined)).toBeNull();
    expect(urlPassword('not a url')).toBeNull();
  });

  it('validateCorsOrigin accepts https and rejects http, wildcards and junk', () => {
    expect(validateCorsOrigin('https://a.example.com')).toEqual([]);
    expect(validateCorsOrigin('http://a.example.com')).toHaveLength(1);
    expect(validateCorsOrigin('*')).toHaveLength(1);
    expect(validateCorsOrigin('https://*.example.com')).toHaveLength(1);
    expect(validateCorsOrigin('')).toHaveLength(1);
    expect(validateCorsOrigin(undefined)).toHaveLength(1);
  });
});

// ═══════════════════════════════════════════════════════════════════════════
// PHASE N1 — the directories the API writes to are validated up front, so a
// bad path is reported by the validator instead of aborting the boot from a
// module-scope mkdir (PHASE M4.3/M4.8).
//
// Every case below is root-proof: the negatives use a path *under a regular
// file* and a relative path, not a permission bit, so they behave the same
// whether the suite runs as `user` locally or as root in CI.
// ═══════════════════════════════════════════════════════════════════════════
describe('PHASE N1 — runtime directories (IMPORT_UPLOAD_DIR, BACKUP_DIR, CONTRACT_PDF_DIR)', () => {
  let writable: string;
  let aFile: string;

  beforeAll(() => {
    writable = mkdtempSync(join(tmpdir(), 'n1-dirs-'));
    aFile = join(writable, 'not-a-directory.txt');
    writeFileSync(aFile, 'x');
  });

  afterAll(() => {
    try { chmodSync(writable, 0o755); } catch { /* ignore */ }
    rmSync(writable, { recursive: true, force: true });
  });

  it('covers exactly the three directories the API writes to', () => {
    expect([...RUNTIME_DIR_VARS].sort()).toEqual(
      ['BACKUP_DIR', 'CONTRACT_PDF_DIR', 'IMPORT_UPLOAD_DIR'].sort(),
    );
  });

  describe('dirCreationProblem()', () => {
    it('returns null for a directory the process can write to', () => {
      expect(dirCreationProblem(writable)).toBeNull();
    });

    it('returns null for a path that does not exist yet under a writable parent', () => {
      expect(dirCreationProblem(join(writable, 'imports', 'deep'))).toBeNull();
    });

    it('reports a path whose nearest ancestor is a regular file', () => {
      expect(dirCreationProblem(join(aFile, 'imports'))).toMatch(/not a directory/);
    });

    it('reports a relative path', () => {
      expect(dirCreationProblem('relative/imports')).toMatch(/not an absolute path/);
    });

    it('reports an empty path', () => {
      expect(dirCreationProblem('   ')).toMatch(/empty/);
    });
  });

  describe('validateRuntimeDirs()', () => {
    it('reports nothing when the variables are unset (the documented default applies)', () => {
      expect(validateRuntimeDirs({})).toEqual([]);
    });

    it('reports nothing when all three point at writable directories', () => {
      expect(
        validateRuntimeDirs({
          IMPORT_UPLOAD_DIR: join(writable, 'imports'),
          BACKUP_DIR: join(writable, 'backups'),
          CONTRACT_PDF_DIR: join(writable, 'contracts'),
        }),
      ).toEqual([]);
    });

    it.each([
      ['IMPORT_UPLOAD_DIR'],
      ['BACKUP_DIR'],
      ['CONTRACT_PDF_DIR'],
    ])('names %s when it points somewhere the process cannot create', (key) => {
      const errors = validateRuntimeDirs({ [key]: join(aFile, 'sub') });
      expect(errors).toHaveLength(1);
      expectReportsVariable(errors, key);
    });

    it('names the variable for a relative path too', () => {
      const errors = validateRuntimeDirs({ BACKUP_DIR: 'backups/nightly' });
      expectReportsVariable(errors, 'BACKUP_DIR');
    });

    it('reports every unusable directory, not just the first', () => {
      const errors = validateRuntimeDirs({
        IMPORT_UPLOAD_DIR: join(aFile, 'a'),
        BACKUP_DIR: join(aFile, 'b'),
        CONTRACT_PDF_DIR: 'relative/c',
      });
      expect(errors).toHaveLength(3);
      for (const key of RUNTIME_DIR_VARS) expectReportsVariable(errors, key);
    });
  });

  describe('runtimeDirWarnings()', () => {
    it('stays quiet once all three are configured', () => {
      expect(
        runtimeDirWarnings({
          IMPORT_UPLOAD_DIR: writable,
          BACKUP_DIR: writable,
          CONTRACT_PDF_DIR: writable,
        }),
      ).toEqual([]);
    });

    it('never turns an unset variable into a hard error', () => {
      // The default is only usable where the deployment provides it (the
      // compose file mounts backupdata:/var/backups/flexora), so an unset
      // variable may warn but must not block a boot.
      expect(validateRuntimeDirs({})).toEqual([]);
    });
  });

  describe('wired into validateEnv() for production', () => {
    it('accepts a production environment whose directories are writable', () => {
      withEnv(
        prodEnv({
          IMPORT_UPLOAD_DIR: join(writable, 'imports'),
          BACKUP_DIR: join(writable, 'backups'),
          CONTRACT_PDF_DIR: join(writable, 'contracts'),
        }),
      );
      const r = validateEnv();
      expect(r.errors).toEqual([]);
      expect(r.ok).toBe(true);
    });

    it('refuses a production environment whose import directory is unusable, naming the variable and never a secret', () => {
      const env = prodEnv({ IMPORT_UPLOAD_DIR: join(aFile, 'imports') });
      withEnv(env);
      const r = validateEnv();
      expect(r.ok).toBe(false);
      expectReportsVariable(
        r.errors,
        'IMPORT_UPLOAD_DIR',
        Object.values(env).filter((v): v is string => typeof v === 'string'),
      );
    });

    it('still accepts a production environment that sets no directory at all', () => {
      withEnv(prodEnv());
      const r = validateEnv();
      expect(r.errors).toEqual([]);
      expect(r.ok).toBe(true);
    });

    it('reports an unusable configured directory in development too, naming the variable', () => {
      // PHASE N1: the gate is no longer production-only. Nothing creates these
      // directories at import time any more, so the validator is the only place
      // that can tell a developer at boot that the path they configured cannot
      // work — instead of them finding out on the first upload.
      const bad = join(aFile, 'imports');
      const env = { ...prodEnv({ NODE_ENV: 'development' }), IMPORT_UPLOAD_DIR: bad };
      withEnv(env);
      const r = validateEnv();
      expect(r.ok).toBe(false);
      expectReportsVariable(
        r.errors,
        'IMPORT_UPLOAD_DIR',
        Object.values(env).filter((v): v is string => typeof v === 'string'),
      );
    });

    it('does not refuse to boot in development for that same environment', () => {
      const bad = join(aFile, 'imports');
      withEnv({ ...prodEnv({ NODE_ENV: 'development' }), IMPORT_UPLOAD_DIR: bad });
      const r = validateEnv();
      expect(r.ok).toBe(false);
      const exit = jest.spyOn(process, 'exit').mockImplementation(((code?: number) => {
        throw new Error(`process.exit(${code})`);
      }) as never);
      try {
        expect(() => enforceEnv(r)).not.toThrow();
        expect(exit).not.toHaveBeenCalled();
      } finally {
        exit.mockRestore();
      }
    });

    it('does refuse to boot in production for that same environment', () => {
      const bad = join(aFile, 'imports');
      withEnv(prodEnv({ IMPORT_UPLOAD_DIR: bad }));
      const r = validateEnv();
      expect(r.ok).toBe(false);
      const exit = jest.spyOn(process, 'exit').mockImplementation(((code?: number) => {
        throw new Error(`process.exit(${code})`);
      }) as never);
      try {
        expect(() => enforceEnv(r)).toThrow('process.exit(1)');
        expect(exit).toHaveBeenCalledWith(1);
      } finally {
        exit.mockRestore();
      }
    });

    it('stays quiet in development when no directory is configured', () => {
      // A dev container that never set them must not be nagged on every boot:
      // unset variables fall back to the documented defaults and only production
      // warns about those (runtimeDirWarnings).
      withEnv({ NODE_ENV: 'development' });
      const r = validateEnv();
      const dirRelated = (lines: string[]) =>
        lines.filter((l) => RUNTIME_DIR_VARS.some((k) => l.includes(k)));
      expect(dirRelated(r.errors)).toEqual([]);
      expect(dirRelated(r.warnings)).toEqual([]);
    });
  });
});

// =============================================================================
// PHASE R0 — ADMIN_HOSTS: which hostname(s) may serve the owner console
// =============================================================================
// The rule under test lives in config/admin-hosts.ts (wording included) and is wired
// into validateEnv() here: a problem is an ERROR in production and a WARNING outside
// it, because an unset value in development falls back to the loopback-only default
// (trial mode) and a fresh checkout must keep working.
describe('PHASE R0 — ADMIN_HOSTS (owner-console hostnames)', () => {
  const mentions = (messages: string[]) => messages.filter((m) => m.includes('ADMIN_HOSTS'));

  it('accepts a valid production allow-list, with ports and a trailing root dot', () => {
    withEnv(prodEnv({ ADMIN_HOSTS: 'admin.example.com, console.example.com.:8443' }));
    expect(mentions(validateEnv().errors)).toEqual([]);
  });

  it('REFUSES production with ADMIN_HOSTS unset (fail closed, not fail open)', () => {
    withEnv(prodEnv({ ADMIN_HOSTS: undefined }));
    const r = validateEnv();
    expect(r.ok).toBe(false);
    expectReportsVariable(r.errors, 'ADMIN_HOSTS');
    expect(mentions(r.errors).some((m) => m.includes('required in production'))).toBe(true);
  });

  it('REFUSES production with ADMIN_HOSTS empty or whitespace', () => {
    for (const value of ['', '   ']) {
      withEnv(prodEnv({ ADMIN_HOSTS: value }));
      expectReportsVariable(validateEnv().errors, 'ADMIN_HOSTS');
    }
  });

  it.each(['*', '*.*', 'all', 'any', '*.example.com', 'admin.example.com,*'])(
    'REFUSES the wildcard %s in production: a console on every host is a public console',
    (value) => {
      withEnv(prodEnv({ ADMIN_HOSTS: value }));
      const errors = mentions(validateEnv().errors);
      expect(errors.length).toBeGreaterThan(0);
      expect(errors.some((m) => m.includes('wildcard'))).toBe(true);
    },
  );

  it('REFUSES the reserved ".invalid" denial hostname nginx itself sends', () => {
    // nginx hands the api `Host: host-gate.denied.invalid` for a console request that
    // arrived on a public hostname. Allow-listing that name would turn the edge's own
    // refusal into an entry ticket, so the parser drops it and the validator reports it.
    withEnv(prodEnv({ ADMIN_HOSTS: 'host-gate.denied.invalid' }));
    const errors = mentions(validateEnv().errors);
    expect(errors.length).toBeGreaterThan(0);
    expect(errors.some((m) => m.includes('.invalid'))).toBe(true);
  });

  it('REFUSES a scheme, path or otherwise malformed entry', () => {
    for (const value of ['https://admin.example.com', 'admin.example.com/platform', 'a b']) {
      withEnv(prodEnv({ ADMIN_HOSTS: value }));
      expect(mentions(validateEnv().errors).length).toBeGreaterThan(0);
    }
  });

  it('outside production an unset ADMIN_HOSTS is a WARNING naming the dev default, never an error', () => {
    withEnv({ ...prodEnv({ ADMIN_HOSTS: undefined }), NODE_ENV: 'development' });
    const r = validateEnv();
    expect(mentions(r.errors)).toEqual([]);
    const warnings = mentions(r.warnings);
    expect(warnings.length).toBeGreaterThan(0);
    expect(warnings.some((w) => w.includes('localhost,127.0.0.1'))).toBe(true);
  });

  it('outside production a wildcard is still reported (as a warning, and it never opens the console)', () => {
    withEnv({ ...prodEnv({ ADMIN_HOSTS: '*' }), NODE_ENV: 'development' });
    const r = validateEnv();
    expect(mentions(r.errors)).toEqual([]);
    expect(mentions(r.warnings).some((w) => w.includes('wildcard'))).toBe(true);
  });

  it('NEGATIVE CONTROL: the report names the variable and never echoes a credential', () => {
    const secrets = [
      'S3cureDbPassw0rd2026',
      'S3cureRedisPass2026',
      HEX64,
      HEX64_B,
    ];
    withEnv(prodEnv({ ADMIN_HOSTS: undefined }));
    const r = validateEnv();
    expectReportsVariable(r.errors, 'ADMIN_HOSTS', secrets);
    // a hostname is not a credential, so quoting the offending entry is allowed -
    // which is what makes the wildcard and ".invalid" messages actionable.
    withEnv(prodEnv({ ADMIN_HOSTS: '*.example.com' }));
    expect(mentions(validateEnv().errors).join(' ')).toContain('*.example.com');
  });
});
