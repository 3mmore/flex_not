/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE O1.4 — one answer to "may this process talk to Redis this way?".
 *
 * Redis holds refresh-token/session state, rate-limit counters and the queue
 * payloads. Before Phase O the rule lived in three places that could drift:
 * `config/redis.service.ts` (a bare `url.startsWith('rediss://')` test),
 * `config/env-validation.ts` (`isValidRedisUrl`), and two call sites that did
 * not check at all (`modules/realtime/realtime.gateway.ts`'s socket.io adapter
 * clients and `modules/scheduler/scheduler.integration.ts`). Only the first two
 * agreed, and the validator's failure message said "must start with redis:// or
 * rediss://" — which is actively misleading when the real reason is that
 * production requires TLS.
 *
 * THE RULE (owner decision, Phase O — "both"):
 *
 *  1. In production, Redis must be reached over TLS: `rediss://`.
 *     docker-compose.yml ships an opt-in TLS-capable redis
 *     (`docker compose --profile redis-tls up -d`) and any managed Redis works
 *     too; set REDIS_URL=rediss://:<password>@host:6379.
 *
 *  2. There is exactly one opt-out: REDIS_ALLOW_PLAINTEXT_INTERNAL=true, for a
 *     Redis that is genuinely on the same private network (the compose
 *     `internal` network is: that service publishes no ports at all). It is
 *     NEVER defaulted to true anywhere — not in compose, not here.
 *
 *  3. The opt-out is deliberately narrow, because "internal" is a claim about
 *     the network, and a hostname is not evidence of one. It is honoured only
 *     for:
 *        - a single-label host        (redis, localhost — a compose service name
 *                                       or a host resolved through the local
 *                                       search domain), or
 *        - an IP LITERAL that is loopback or RFC1918-private:
 *                                       127.0.0.0/8, 10.0.0.0/8,
 *                                       172.16.0.0/12, 192.168.0.0/16, ::1
 *     It is REFUSED for anything else, in particular:
 *        - `10.evil.com`  — looks like a private range, is a public DNS name.
 *          Deciding by string prefix is how an attacker-controlled name gets
 *          trusted; `net.isIP()` says this is not an IP at all, and a name with
 *          a dot in it is not single-label.
 *        - `redis.example.com` — a public DNS name.
 *        - `8.8.8.8` — a routable public IP.
 *     IPv6 other than ::1 (including ULA/link-local) is refused: use TLS there.
 *
 *  4. When the opt-out IS used, it is logged loudly at boot, naming the variable
 *     and the kind of host that qualified. A deployment that quietly relies on
 *     plaintext Redis should be visible in its own logs.
 *
 * Development and test modes keep plaintext Redis working unchanged: the local
 * stack and the jest suites run `redis://localhost:6379`, and requiring TLS
 * there would only push people to disable the check.
 *
 * NOTHING HERE EVER PRINTS A PASSWORD. Messages name variables, schemes, host
 * kinds and (for the opt-out warning) the hostname — never the credential.
 */
import { existsSync, readFileSync } from 'fs';
import { isIP } from 'net';

import { envModeOf, isProductionEnv } from './env-mode';

export const REDIS_URL_VAR = 'REDIS_URL';
export const REDIS_PLAINTEXT_OPT_OUT_VAR = 'REDIS_ALLOW_PLAINTEXT_INTERNAL';

/** Why a host was or was not treated as internal. */
export type RedisHostKind =
  | 'loopback'
  | 'private-ip'
  | 'single-label'
  | 'public-ip'
  | 'public-dns'
  | 'unparseable';

export interface RedisTlsOptions {
  rejectUnauthorized: boolean;
  ca?: string;
  cert?: string;
  key?: string;
}

export interface RedisTransportDecision {
  /** May this process connect this way? */
  ok: boolean;
  /** Is the connection TLS (`rediss://`)? */
  tls: boolean;
  /** Was plaintext accepted only because of the explicit opt-out? */
  optOutUsed: boolean;
  hostKind: RedisHostKind;
  /** Why it was refused. Names variables and host kinds, never a password. */
  reason?: string;
  /** Loud boot warning when the opt-out was used. */
  warn?: string;
}

/** True only for the exact string `true` (trimmed, any case). */
export function plaintextOptOutEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return (env[REDIS_PLAINTEXT_OPT_OUT_VAR] || '').trim().toLowerCase() === 'true';
}

/** IPv4 ranges that are not routable on the public internet. */
function isPrivateIPv4(h: string): boolean {
  const parts = h.split('.');
  if (parts.length !== 4 || parts.some((p) => !/^\d{1,3}$/.test(p) || Number(p) > 255)) return false;
  const [a, b] = [Number(parts[0]), Number(parts[1])];
  if (a === 10) return true; // 10.0.0.0/8
  if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
  if (a === 192 && b === 168) return true; // 192.168.0.0/16
  return false;
}

function isLoopbackIPv4(h: string): boolean {
  return /^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h) && h.split('.').every((p) => Number(p) <= 255);
}

/**
 * Classify a hostname. `net.isIP()` decides IP-literal-vs-name FIRST: a name
 * that merely starts with digits and dots (`10.evil.com`) is a DNS name and is
 * never treated as a private address.
 */
export function classifyRedisHost(hostname: string): RedisHostKind {
  const host = (hostname || '').replace(/^\[|\]$/g, '').trim().toLowerCase();
  if (!host) return 'unparseable';

  const version = isIP(host);
  if (version === 4) {
    if (isLoopbackIPv4(host)) return 'loopback';
    if (isPrivateIPv4(host)) return 'private-ip';
    return 'public-ip';
  }
  if (version === 6) {
    if (host === '::1') return 'loopback';
    // ULA / link-local are deliberately NOT accepted: the documented opt-out
    // covers the ranges listed in this file's header, and an IPv6 deployment
    // that needs plaintext should say so by using TLS instead.
    return 'public-ip';
  }
  // Not an IP literal. A single label (no dot) can only resolve through the
  // local search domain — a compose service name like `redis`, or `localhost`.
  return host.includes('.') ? 'public-dns' : 'single-label';
}

/** Host kinds the plaintext opt-out is allowed to cover. */
export const INTERNAL_HOST_KINDS: readonly RedisHostKind[] = ['loopback', 'private-ip', 'single-label'];

export function hostKindLabel(kind: RedisHostKind): string {
  switch (kind) {
    case 'loopback':
      return 'a loopback address';
    case 'private-ip':
      return 'a private (RFC1918) IP literal';
    case 'single-label':
      return 'a single-label host (a name with no dot, resolved on the local network)';
    case 'public-ip':
      return 'a routable public IP literal';
    case 'public-dns':
      return 'a public DNS name (it contains a dot, so it is resolved through DNS — a name like 10.evil.com is NOT a private address)';
    default:
      return 'an unparseable host';
  }
}

/**
 * TLS options for `rediss://`, from optional file paths. Certificate material is
 * read at connection setup; a path that is set but unreadable is a hard error
 * naming the variable (never its contents).
 */
export function redisTlsOptions(env: NodeJS.ProcessEnv = process.env): RedisTlsOptions {
  const options: RedisTlsOptions = {
    rejectUnauthorized: (env.REDIS_TLS_REJECT_UNAUTHORIZED || '').trim().toLowerCase() !== 'false',
  };
  const ca = readTlsFileVar('REDIS_TLS_CA_FILE', env);
  if (ca !== undefined) options.ca = ca;
  const cert = readTlsFileVar('REDIS_TLS_CERT_FILE', env);
  if (cert !== undefined) options.cert = cert;
  const key = readTlsFileVar('REDIS_TLS_KEY_FILE', env);
  if (key !== undefined) options.key = key;
  return options;
}

/**
 * Read a certificate file named by an environment variable. A variable that is
 * set but unreadable is a hard error naming the VARIABLE (and its path, which is
 * not a secret) — never the file contents.
 */
function readTlsFileVar(varName: string, env: NodeJS.ProcessEnv): string | undefined {
  const path = (env[varName] || '').trim();
  if (!path) return undefined;
  if (!existsSync(path)) {
    throw new Error(`${varName} points at ${path}, which does not exist — unset ${varName} or fix the path`);
  }
  return readFileSync(path, 'utf8');
}

/**
 * The single decision every Redis client in this codebase must consult before
 * connecting. Pure: no I/O, no logging, no process.env mutation, so it is
 * unit-testable against the whole table in redis-transport.spec.ts.
 */
export function decideRedisTransport(
  rawUrl: string | undefined | null,
  env: NodeJS.ProcessEnv = process.env,
): RedisTransportDecision {
  const refuse = (hostKind: RedisHostKind, reason: string): RedisTransportDecision => ({
    ok: false,
    tls: false,
    optOutUsed: false,
    hostKind,
    reason,
  });

  const raw = (rawUrl || '').trim();
  if (!raw) return refuse('unparseable', `${REDIS_URL_VAR} is not set`);

  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return refuse(
      'unparseable',
      `${REDIS_URL_VAR} is not a parseable URL (expected redis:// or rediss://). The value is not ` +
        'repeated here — check it for unescaped characters: a password containing @ : / ? # or % ' +
        'must be percent-encoded, and a literal $ in docker-compose.yml must be written $$.',
    );
  }

  if (url.protocol !== 'redis:' && url.protocol !== 'rediss:') {
    return refuse(
      'unparseable',
      `${REDIS_URL_VAR} must use the redis:// or rediss:// scheme (found "${url.protocol}//")`,
    );
  }

  const hostKind = classifyRedisHost(url.hostname);
  if (!url.hostname) return refuse('unparseable', `${REDIS_URL_VAR} has no host`);

  if (url.protocol === 'rediss:') {
    return { ok: true, tls: true, optOutUsed: false, hostKind };
  }

  // Plaintext from here on. The mode comes from the SAME env object the caller
  // passed, so the decision is a pure function of its inputs.
  if (!isProductionEnv(env.NODE_ENV)) {
    return { ok: true, tls: false, optOutUsed: false, hostKind };
  }

  const tlsHint =
    `Production requires Redis over TLS: set ${REDIS_URL_VAR}=rediss://:<password>@<host>:<port>. ` +
    'docker-compose.yml ships an opt-in TLS-capable redis (start it with ' +
    '`docker compose --profile redis-tls up -d`, certificates from ./certs/redis — see ' +
    'docs/DEPLOYMENT.md), and any managed Redis with TLS works too.';

  if (!plaintextOptOutEnabled(env)) {
    return refuse(
      hostKind,
      `${REDIS_URL_VAR} uses plaintext redis:// in production. ${tlsHint} The only exception is ` +
        `${REDIS_PLAINTEXT_OPT_OUT_VAR}=true, which is honoured just for ${hostKindLabel('single-label')} ` +
        `or ${hostKindLabel('private-ip')} (it is never set by default, and it refuses public DNS names ` +
        'and routable IPs).',
    );
  }

  if (!INTERNAL_HOST_KINDS.includes(hostKind)) {
    return refuse(
      hostKind,
      `${REDIS_PLAINTEXT_OPT_OUT_VAR}=true is set, but ${REDIS_URL_VAR}'s host is ` +
        `${hostKindLabel(hostKind)}, so the opt-out does not apply and plaintext Redis is refused. ` +
        `The opt-out covers only ${hostKindLabel('single-label')}, ${hostKindLabel('private-ip')} or ` +
        `${hostKindLabel('loopback')}. ${tlsHint}`,
    );
  }

  return {
    ok: true,
    tls: false,
    optOutUsed: true,
    hostKind,
    warn:
      `${REDIS_PLAINTEXT_OPT_OUT_VAR}=true: connecting to Redis WITHOUT TLS at host ` +
      `"${url.hostname}" (${hostKindLabel(hostKind)}). This is only acceptable while that host is ` +
      'unreachable from outside the private network — the compose `redis` service publishes no ' +
      'ports, so it is. Anyone who can reach this network segment can read session and ' +
      'rate-limit state, and inject queue jobs. Prefer rediss:// (compose profile `redis-tls`).',
  };
}

/** ioredis options derived from the decision (the `tls` key, when TLS is on). */
export function redisConnectionOptions(
  decision: RedisTransportDecision,
  env: NodeJS.ProcessEnv = process.env,
): { tls?: RedisTlsOptions } {
  return decision.tls ? { tls: redisTlsOptions(env) } : {};
}

/**
 * The message to throw when a decision refuses. Kept next to the decision so the
 * validator in env-validation.ts and the three client call sites cannot drift.
 */
export function redisTransportError(
  decision: RedisTransportDecision,
  env: NodeJS.ProcessEnv = process.env,
): string {
  return decision.reason || `${REDIS_URL_VAR} was refused (mode=${envModeOf(env.NODE_ENV)})`;
}

/**
 * Convenience for a call site that must not connect when refused: returns the
 * decision and throws in production. Non-production refusals (an unparseable
 * URL, a wrong scheme) throw everywhere — those are configuration bugs, not
 * policy.
 */
export function assertRedisTransport(
  rawUrl: string | undefined | null,
  env: NodeJS.ProcessEnv = process.env,
): RedisTransportDecision {
  const decision = decideRedisTransport(rawUrl, env);
  if (!decision.ok) throw new Error(redisTransportError(decision));
  return decision;
}
