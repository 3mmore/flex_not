/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the ADMIN_HOSTS allow-list: parsing, validation and the verdict.
 *
 * The host cases come from admin-host-cases.json, the SAME table the web app's
 * mirror implementation is tested against (apps/web/src/lib/admin-hosts.spec.ts).
 * The two implementations run in different runtimes and cannot share code, so they
 * share data: if either drifts, one of the two suites fails on the same case name.
 */
import { readFileSync } from 'fs';
import { join } from 'path';

import {
  ADMIN_HOSTS_DEV_DEFAULT,
  ADMIN_HOSTS_VAR,
  adminHosts,
  adminHostsConfig,
  adminHostsProblems,
  adminHostVerdict,
  parseAdminHosts,
  splitHostHeader,
  stripRootDot,
  NGINX_GATE_HOSTNAME,
} from './admin-hosts';

interface HostCase {
  name: string;
  adminHosts: string | null;
  nodeEnv: string;
  hops: number | null;
  host: string | null;
  xfh: string | null;
  allowed: boolean;
  reason?: string;
}

interface PathCase {
  name: string;
  path: string;
  console: boolean;
}

const CASES = JSON.parse(
  readFileSync(join(__dirname, 'admin-host-cases.json'), 'utf8'),
) as { hostCases: HostCase[]; pathCases: PathCase[] };

/** Restore the environment after every test: nothing here may leak into another suite. */
const ENV_KEYS = [ADMIN_HOSTS_VAR, 'TRUST_PROXY_HOPS', 'NODE_ENV'] as const;
let saved: Record<string, string | undefined> = {};

beforeEach(() => {
  saved = {};
  for (const key of ENV_KEYS) saved[key] = process.env[key];
});
afterEach(() => {
  for (const key of ENV_KEYS) {
    if (saved[key] === undefined) delete process.env[key];
    else process.env[key] = saved[key];
  }
});

function setEnv(adminHosts: string | null, nodeEnv: string, hops: number | null) {
  if (adminHosts === null) delete process.env[ADMIN_HOSTS_VAR];
  else process.env[ADMIN_HOSTS_VAR] = adminHosts;
  process.env.NODE_ENV = nodeEnv;
  if (hops === null) delete process.env.TRUST_PROXY_HOPS;
  else process.env.TRUST_PROXY_HOPS = String(hops);
}

describe('PHASE R0 - ADMIN_HOSTS parsing', () => {
  it('1. parses a comma list, trimming spaces and lowercasing', () => {
    const parsed = parseAdminHosts(' Admin.Example.COM , console.internal ');
    expect(parsed.entries.map((e) => e.hostname)).toEqual(['admin.example.com', 'console.internal']);
    expect(parsed.invalid).toEqual([]);
  });

  it('2. never accepts a wildcard, in any of the shapes people write', () => {
    for (const wildcard of ['*', '*.*', 'all', 'any', '*.example.com', 'admin.*']) {
      const parsed = parseAdminHosts(wildcard);
      expect(parsed.entries).toEqual([]);
      expect(parsed.invalid).toContain(wildcard);
    }
  });

  it('3. keeps the usable entries when a wildcard is mixed in, and reports the wildcard', () => {
    const parsed = parseAdminHosts('*,admin.example.com');
    expect(parsed.entries.map((e) => e.hostname)).toEqual(['admin.example.com']);
    expect(parsed.invalid).toEqual(['*']);
    process.env[ADMIN_HOSTS_VAR] = '*,admin.example.com';
    expect(adminHostsProblems('production')).toEqual(
      expect.arrayContaining([expect.stringContaining('must never contain a wildcard')]),
    );
  });

  it('4. refuses a scheme, a path or a query in an entry (an unusable entry never widens access)', () => {
    for (const bad of ['https://admin.example.com', 'admin.example.com/platform', 'admin.example.com?x=1', 'admin.example.com#frag']) {
      expect(parseAdminHosts(bad).entries).toEqual([]);
      expect(parseAdminHosts(bad).invalid).toContain(bad);
    }
  });

  it('5. supports host:port entries, bracketed IPv6 and a bare IPv6 literal', () => {
    expect(parseAdminHosts('admin.example.com:8443').entries).toEqual([{ hostname: 'admin.example.com', port: '8443' }]);
    expect(parseAdminHosts('[::1]:8443').entries).toEqual([{ hostname: '::1', port: '8443' }]);
    expect(parseAdminHosts('::1').entries).toEqual([{ hostname: '::1' }]);
    expect(parseAdminHosts('127.0.0.1').entries).toEqual([{ hostname: '127.0.0.1' }]);
  });

  it('6. refuses a malformed IPv6 or a bracketed literal with junk after it', () => {
    expect(parseAdminHosts('[::1]junk').entries).toEqual([]);
    expect(parseAdminHosts('[::1').entries).toEqual([]);
    expect(parseAdminHosts(':::gg').entries).toEqual([]);
  });

  it('7. treats a single trailing dot as the DNS root label on both sides', () => {
    expect(stripRootDot('admin.example.com.')).toBe('admin.example.com');
    expect(stripRootDot('.')).toBe('.');
    expect(parseAdminHosts('admin.example.com.').entries).toEqual([{ hostname: 'admin.example.com' }]);
    expect(splitHostHeader('ADMIN.example.com.:8443')).toEqual({
      hostname: 'admin.example.com',
      port: '8443',
      raw: 'admin.example.com.:8443',
    });
  });

  it('8. splitHostHeader handles ports, bracketed IPv6 and junk', () => {
    expect(splitHostHeader('localhost:4000')).toEqual({ hostname: 'localhost', port: '4000', raw: 'localhost:4000' });
    expect(splitHostHeader('localhost')).toEqual({ hostname: 'localhost', raw: 'localhost' });
    expect(splitHostHeader('[::1]:4000')).toEqual({ hostname: '::1', port: '4000', raw: '[::1]:4000' });
    expect(splitHostHeader(undefined)).toEqual({ hostname: '', raw: '' });
    // a colon that is not followed by a plain port is part of the name, not a port
    expect(splitHostHeader('weird:notaport')).toEqual({ hostname: 'weird:notaport', raw: 'weird:notaport' });
  });
});

describe('PHASE R0 - ADMIN_HOSTS effective configuration', () => {
  it('9. outside production an unset value falls back to the loopback-only development default (trial mode)', () => {
    delete process.env[ADMIN_HOSTS_VAR];
    const config = adminHostsConfig('development');
    expect(config.usingDevDefault).toBe(true);
    expect(config.entries.map((e) => e.hostname)).toEqual(['localhost', '127.0.0.1']);
    expect(ADMIN_HOSTS_DEV_DEFAULT).toBe('localhost,127.0.0.1');
    expect(adminHosts('development')).toEqual(['localhost', '127.0.0.1']);
  });

  it('10. the development default is never a wildcard and never empty', () => {
    expect(ADMIN_HOSTS_DEV_DEFAULT).not.toContain('*');
    expect(parseAdminHosts(ADMIN_HOSTS_DEV_DEFAULT).entries.length).toBeGreaterThan(0);
  });

  it('11. in production an unset value yields an EMPTY allow-list, i.e. every host is refused (fail closed)', () => {
    delete process.env[ADMIN_HOSTS_VAR];
    const config = adminHostsConfig('production');
    expect(config.entries).toEqual([]);
    expect(config.usingDevDefault).toBe(false);
    expect(adminHostVerdict({ host: 'localhost' }, config).allowed).toBe(false);
    expect(adminHostVerdict({ host: 'admin.example.com' }, config).allowed).toBe(false);
  });

  it('12. reads the environment at CALL time, never at module scope', () => {
    // The rule "no process.env reads at module scope" is what makes this pass: the
    // same function, called twice with a changed environment, gives two answers.
    process.env.NODE_ENV = 'production';
    process.env[ADMIN_HOSTS_VAR] = 'first.example.com';
    expect(adminHostVerdict({ host: 'first.example.com' }).allowed).toBe(true);
    process.env[ADMIN_HOSTS_VAR] = 'second.example.com';
    expect(adminHostVerdict({ host: 'first.example.com' }).allowed).toBe(false);
    expect(adminHostVerdict({ host: 'second.example.com' }).allowed).toBe(true);
    delete process.env[ADMIN_HOSTS_VAR];
    expect(adminHostVerdict({ host: 'second.example.com' }).allowed).toBe(false);
  });
});

describe('PHASE R0 - boot validation (adminHostsProblems)', () => {
  it('13. requires ADMIN_HOSTS in production and says so without echoing a secret', () => {
    delete process.env[ADMIN_HOSTS_VAR];
    const problems = adminHostsProblems('production');
    expect(problems).toHaveLength(1);
    expect(problems[0]).toContain(ADMIN_HOSTS_VAR);
    expect(problems[0]).toContain('required in production');
    expect(problems[0]).not.toContain('=');
  });

  it('14. accepts a valid production value with no problems at all', () => {
    process.env[ADMIN_HOSTS_VAR] = 'admin.example.com,console.internal';
    expect(adminHostsProblems('production')).toEqual([]);
  });

  it('15. reports an empty entry (a stray comma) and a wildcard', () => {
    process.env[ADMIN_HOSTS_VAR] = 'admin.example.com,,*.example.com';
    const problems = adminHostsProblems('production');
    expect(problems.some((p) => p.includes('empty entry'))).toBe(true);
    expect(problems.some((p) => p.includes('wildcard'))).toBe(true);
  });

  it('16. reports an unusable entry that is not a wildcard', () => {
    process.env[ADMIN_HOSTS_VAR] = 'https://admin.example.com';
    const problems = adminHostsProblems('production');
    expect(problems.some((p) => p.includes('not a plain hostname'))).toBe(true);
  });

  it('17. outside production an unset value is not an error (a fresh checkout keeps working)', () => {
    delete process.env[ADMIN_HOSTS_VAR];
    expect(adminHostsProblems('development')).toEqual([]);
    expect(adminHostsProblems('test')).toEqual([]);
  });
});

describe('PHASE R0 - the shared host-case table (parity with the web mirror)', () => {
  it.each(CASES.hostCases)(
    '18. $name',
    ({ adminHosts: hosts, nodeEnv, hops, host, xfh, allowed, reason }) => {
      setEnv(hosts, nodeEnv, hops);
      const headers: { host?: string; 'x-forwarded-host'?: string } = {};
      if (host !== null) headers.host = host;
      if (xfh !== null) headers['x-forwarded-host'] = xfh;
      const verdict = adminHostVerdict(headers);
      expect(verdict.allowed).toBe(allowed);
      if (!allowed && reason) expect((verdict as { reason: string }).reason).toBe(reason);
    },
  );

  it('19. the table is actually loaded and is not empty', () => {
    expect(CASES.hostCases.length).toBeGreaterThanOrEqual(35);
    expect(CASES.pathCases.length).toBeGreaterThanOrEqual(20);
  });

  it('20. the path table is the web mirror\'s concern; the api identifies routes by metadata', () => {
    // Recorded here so nobody "helpfully" adds URL-string matching to the api gate:
    // every console route in this app carries @PlatformRoute(), and the guard reads
    // that marker (see common/guards/admin-host.guard.ts). The api has no path list.
    expect(CASES.pathCases.every((c: PathCase) => typeof c.console === 'boolean')).toBe(true);
  });
});

describe('PHASE R0 - X-Forwarded-Host can never widen access', () => {
  beforeEach(() => {
    process.env.NODE_ENV = 'production';
    process.env[ADMIN_HOSTS_VAR] = 'admin.example.com';
  });

  it('21. a forwarded admin host does not open a public Host', () => {
    process.env.TRUST_PROXY_HOPS = '1';
    const verdict = adminHostVerdict({
      host: 'app.example.com',
      'x-forwarded-host': 'admin.example.com',
    });
    expect(verdict.allowed).toBe(false);
    expect((verdict as { reason: string }).reason).toBe('forwarded-host-disagrees');
  });

  it('22. a forwarded public host does not close an allowed Host silently - it refuses, and says why', () => {
    process.env.TRUST_PROXY_HOPS = '1';
    const verdict = adminHostVerdict({
      host: 'admin.example.com',
      'x-forwarded-host': 'app.example.com',
    });
    expect(verdict.allowed).toBe(false);
    expect((verdict as { reason: string }).reason).toBe('forwarded-host-disagrees');
  });

  it('23. with TRUST_PROXY_HOPS=0 the forwarded header is not consulted at all', () => {
    process.env.TRUST_PROXY_HOPS = '0';
    expect(
      adminHostVerdict({ host: 'admin.example.com', 'x-forwarded-host': 'app.example.com' }).allowed,
    ).toBe(true);
    expect(
      adminHostVerdict({ host: 'app.example.com', 'x-forwarded-host': 'admin.example.com' }).allowed,
    ).toBe(false);
  });

  it('24. with several hops declared, the value that many from the right decides', () => {
    process.env.TRUST_PROXY_HOPS = '2';
    // right-most is the closest proxy; with 2 hops the second-from-right is trusted
    expect(
      adminHostVerdict({
        host: 'admin.example.com',
        'x-forwarded-host': 'attacker.test, admin.example.com, cdn.test',
      }).allowed,
    ).toBe(true);
    expect(
      adminHostVerdict({
        host: 'admin.example.com',
        'x-forwarded-host': 'admin.example.com, attacker.test, cdn.test',
      }).allowed,
    ).toBe(false);
  });

  it('25. the default hop count matches the one Express is configured with (1)', () => {
    delete process.env.TRUST_PROXY_HOPS;
    // unset means the documented default of 1, so a disagreeing forwarded header
    // is refused rather than believed
    expect(
      adminHostVerdict({ host: 'admin.example.com', 'x-forwarded-host': 'app.example.com' }).allowed,
    ).toBe(false);
  });
});

describe('PHASE R0 - the reserved ".invalid" denial hostname can never be allow-listed', () => {
  const setVar = (value: string | undefined) => {
    const env = process.env as Record<string, string | undefined>;
    if (value === undefined) delete env[ADMIN_HOSTS_VAR];
    else env[ADMIN_HOSTS_VAR] = value;
  };

  it('26. nginx substitutes this Host for console requests on a public hostname, and ADMIN_HOSTS refuses to accept it', () => {
    // nginx/nginx.conf sets `Host: host-gate.denied.invalid` ($flexora_gate_host)
    // for a console request that arrived on a non-admin hostname. If that name
    // could be allow-listed, the edge's own denial signal would become an entry
    // ticket, so the parser drops it (fail closed) and the validator reports it.
    expect(NGINX_GATE_HOSTNAME).toBe('host-gate.denied.invalid');
    const parsed = parseAdminHosts(`${NGINX_GATE_HOSTNAME},admin.example.com`);
    expect(parsed.entries.map((e) => e.hostname)).toEqual(['admin.example.com']);
    expect(parsed.invalid).toContain(NGINX_GATE_HOSTNAME);

    setVar(`${NGINX_GATE_HOSTNAME},localhost`);
    try {
      const problems = adminHostsProblems('production');
      expect(problems.some((p) => p.includes('.invalid'))).toBe(true);
      expect(problems.some((p) => p.includes(NGINX_GATE_HOSTNAME))).toBe(true);
      // and the gate itself refuses the denial Host even though it was listed
      expect(adminHostVerdict({ host: NGINX_GATE_HOSTNAME }).allowed).toBe(false);
      expect(adminHostVerdict({ host: 'localhost' }).allowed).toBe(true);
    } finally {
      setVar(undefined);
    }
  });

  it('27. every form of the reserved name is refused: bare label, subdomain, port, trailing dot, upper case', () => {
    for (const entry of ['invalid', 'x.invalid', NGINX_GATE_HOSTNAME, `${NGINX_GATE_HOSTNAME}:8443`, 'HOST-GATE.DENIED.INVALID.', 'a.b.invalid']) {
      const parsed = parseAdminHosts(entry);
      expect(parsed.entries).toEqual([]);
      expect(parsed.invalid.length).toBe(1);
    }
    // and a request carrying such a Host is refused under the development default
    setVar(undefined);
    expect(adminHostVerdict({ host: NGINX_GATE_HOSTNAME }).allowed).toBe(false);
    expect(adminHostVerdict({ host: 'anything.invalid' }).allowed).toBe(false);
  });

  it('28. X-Forwarded-Host can never WIDEN access, and is ignored entirely when no proxy hop is declared', () => {
    setVar('admin.example.com');
    try {
      // a forwarded header claiming an admin host cannot rescue a public Host
      expect(adminHostVerdict({ host: 'r0-public.example', 'x-forwarded-host': 'admin.example.com' }).allowed).toBe(false);
      // with TRUST_PROXY_HOPS=0 the header is client-controlled noise: not read at all
      const env = process.env as Record<string, string | undefined>;
      const savedHops = env.TRUST_PROXY_HOPS;
      env.TRUST_PROXY_HOPS = '0';
      try {
        expect(adminHostVerdict({ host: 'r0-public.example', 'x-forwarded-host': 'admin.example.com' }).allowed).toBe(false);
        expect(adminHostVerdict({ host: 'admin.example.com', 'x-forwarded-host': 'r0-public.example' }).allowed).toBe(true);
      } finally {
        if (savedHops === undefined) delete env.TRUST_PROXY_HOPS;
        else env.TRUST_PROXY_HOPS = savedHops;
      }
    } finally {
      setVar(undefined);
    }
  });
});
