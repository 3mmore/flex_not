import { isProduction } from './env-mode';
/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 16 (PHASE L2) — the session-cookie `secure` flag, decided in ONE place.
 *
 * Before this file, five call sites each recomputed
 * `process.env.NODE_ENV === 'production'` inline, so the flag could not be
 * audited or overridden, nothing stopped a production deploy from shipping
 * `COOKIE_SECURE=false` (cookies then travel over plain http, where any network
 * observer can lift a session) — and any NODE_ENV other than the exact lowercase
 * string "production", including an unset one, silently turned the flag off.
 * The mode now comes from config/env-mode.ts, which fails closed.
 *
 * Resolution order:
 *   1. COOKIE_SECURE, when explicitly set to 'true' or 'false'.
 *   2. otherwise: secure in production, not in development.
 *
 * `validateEnv()` refuses to boot in production unless this resolves to true,
 * so the dangerous combination (production + COOKIE_SECURE=false) never starts.
 */
export function isCookieSecure(): boolean {
  const raw = process.env.COOKIE_SECURE;
  if (raw !== undefined && raw.trim() !== '') {
    return raw.trim().toLowerCase() === 'true';
  }
  return isProduction();
}
