/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { MeasurementsService } from './measurements.service';
import { CreateMeasurementDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('measurements')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('measurements')
export class MeasurementsController {
  constructor(private readonly svc: MeasurementsService) {}

  @Get()
  @Roles('OWNER', 'MANAGER', 'COACH')
  list(@GymId() g: string, @CurrentUser() u: { sub: string; role: string }) {
    return this.svc.list(g, u);
  }

  @Post()
  @Roles('OWNER', 'MANAGER', 'COACH')
  @Audit('create', 'BodyMeasurement')
  createRoot(@GymId() g: string, @Body() dto: CreateMeasurementDto & { memberId: string }, @CurrentUser() u: { sub: string; role: string; name?: string }) {
    return this.svc.create(g, dto.memberId, dto, u);
  }

  @Get('member/:id')
  @Roles('OWNER', 'MANAGER', 'COACH')
  memberHistory(@GymId() g: string, @Param('id') id: string, @CurrentUser() u: { sub: string; role: string }) {
    return this.svc.history(g, id, u);
  }

  @Get(':memberId')
  @Roles('OWNER', 'MANAGER', 'COACH')
  history(
    @GymId() g: string, @Param('memberId') memberId: string,
    @CurrentUser() u: { sub: string; role: string },
  ) {
    return this.svc.history(g, memberId, u);
  }

  @Post(':memberId')
  @Roles('OWNER', 'MANAGER', 'COACH')
  @Audit('create', 'BodyMeasurement')
  create(
    @GymId() g: string, @Param('memberId') memberId: string,
    @Body() dto: CreateMeasurementDto,
    @CurrentUser() u: { sub: string; role: string; name?: string },
  ) {
    return this.svc.create(g, memberId, dto, u);
  }

  @Delete(':id')
  @Roles('OWNER', 'MANAGER')
  @Audit('delete', 'BodyMeasurement')
  remove(@GymId() g: string, @Param('id') id: string) {
    return this.svc.remove(g, id);
  }
}
