/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsBoolean, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateKioskDeviceDto {
  @IsString() @MinLength(2) @MaxLength(80) name!: string;
  @IsString() branchId!: string;
}

export class UpdateKioskDeviceDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(80) name?: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsBoolean() active?: boolean;
}

/** Body of the PUBLIC self-service check-in call (kiosk screen). */
export class KioskCheckinDto {
  /** Member QR payload — the member's code (what the QR encodes). */
  @IsString() @MinLength(1) @MaxLength(80) code!: string;
}

/** Header every public kiosk call must carry. */
export const KIOSK_TOKEN_HEADER = 'x-device-token';
export const KIOSK_TOKEN_RE = /^kio_[a-f0-9]{48}$/;
export const isKioskToken = (v: unknown): v is string =>
  typeof v === 'string' && KIOSK_TOKEN_RE.test(v);
