/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body, Controller, Delete, Get, Headers, Param, Patch, Post, UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { KioskService } from './kiosk.service';
import { CreateKioskDeviceDto, UpdateKioskDeviceDto, KioskCheckinDto, KIOSK_TOKEN_HEADER } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('kiosk')
@Controller('kiosk')
export class KioskController {
  constructor(private readonly svc: KioskService) {}

  // ── Staff-managed (session + tenant + roles) ─────────────────────────────
  @Get('devices')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  list(@GymId() gymId: string) {
    return this.svc.listDevices(gymId);
  }

  @Post('devices')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  @Audit('create', 'KioskDevice')
  create(@GymId() gymId: string, @Body() dto: CreateKioskDeviceDto) {
    return this.svc.createDevice(gymId, dto.name, dto.branchId);
  }

  @Patch('devices/:id')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  @Audit('update', 'KioskDevice')
  update(@GymId() gymId: string, @Param('id') id: string, @Body() dto: UpdateKioskDeviceDto) {
    return this.svc.updateDevice(gymId, id, dto);
  }

  @Post('devices/:id/rotate-token')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  @Audit('rotate-token', 'KioskDevice')
  rotate(@GymId() gymId: string, @Param('id') id: string) {
    return this.svc.rotateToken(gymId, id);
  }

  @Delete('devices/:id')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  @Audit('delete', 'KioskDevice')
  remove(@GymId() gymId: string, @Param('id') id: string) {
    return this.svc.deleteDevice(gymId, id);
  }

  // ── PUBLIC: authenticated ONLY by the device token header (no session). ──
  // @Public() opts out of the default-deny global Jwt/Tenant guards; the
  // tenant is resolved from the device record itself (KioskDevice carries
  // gymId + branchId, so attendance is recorded against the right branch).
  @Get('device')
  @Public()
  whoami(@Headers(KIOSK_TOKEN_HEADER) token: string) {
    return this.svc.whoami(token);
  }

  @Post('checkin')
  @Public()
  checkin(@Headers(KIOSK_TOKEN_HEADER) token: string, @Body() dto: KioskCheckinDto) {
    return this.svc.checkin(token, dto.code);
  }
}
