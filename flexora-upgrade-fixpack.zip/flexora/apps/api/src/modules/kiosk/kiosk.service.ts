/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Self-service QR check-in (P2). A kiosk device is a tablet/scanner physically
 * placed at ONE branch. It authenticates every public request with its secret
 * token (x-device-token header) and attendance is recorded against the branch
 * the device is registered to — no user session involved.
 */
import { BadRequestException, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { AttendanceService } from '../attendance/attendance.service';

@Injectable()
export class KioskService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly attendance: AttendanceService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private maskToken(token: string) {
    return `${token.slice(0, 8)}…${token.slice(-4)}`;
  }

  // ── Staff-managed device CRUD ────────────────────────────────────────────
  async createDevice(gymId: string, name: string, branchId: string) {
    const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
    if (!branch) throw new BadRequestException('Branch not found in this gym');
    const token = `kio_${randomBytes(24).toString('hex')}`;
    const device = await this.prisma.kioskDevice.create({
      data: { gymId, branchId, name: name.trim(), token },
      include: { branch: { select: { id: true, name: true } } },
    });
    // The full token is returned ONLY on creation; lists show it masked.
    return { ...device, token };
  }

  async listDevices(gymId: string) {
    const devices = await this.prisma.kioskDevice.findMany({
      where: { gymId },
      orderBy: { createdAt: 'desc' },
      include: { branch: { select: { id: true, name: true } } },
    });
    return devices.map((d) => ({ ...d, token: this.maskToken(d.token) }));
  }

  async updateDevice(gymId: string, id: string, data: { name?: string; branchId?: string; active?: boolean }) {
    const device = await this.prisma.kioskDevice.findFirst({ where: { id, gymId } });
    if (!device) throw new NotFoundException('Device not found');
    if (data.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: data.branchId, gymId } });
      if (!branch) throw new BadRequestException('Branch not found in this gym');
    }
    return this.prisma.kioskDevice.update({
      where: { id },
      data: {
        ...(data.name !== undefined ? { name: data.name.trim() } : {}),
        ...(data.branchId !== undefined ? { branchId: data.branchId } : {}),
        ...(data.active !== undefined ? { active: data.active } : {}),
      },
      include: { branch: { select: { id: true, name: true } } },
    });
  }

  async deleteDevice(gymId: string, id: string) {
    const res = await this.prisma.kioskDevice.deleteMany({ where: { id, gymId } });
    if (res.count === 0) throw new NotFoundException('Device not found');
    return { ok: true };
  }

  /** Rotate a device token (old token stops working immediately). */
  async rotateToken(gymId: string, id: string) {
    const device = await this.prisma.kioskDevice.findFirst({ where: { id, gymId } });
    if (!device) throw new NotFoundException('Device not found');
    const token = `kio_${randomBytes(24).toString('hex')}`;
    await this.prisma.kioskDevice.update({ where: { id }, data: { token } });
    return { id, token };
  }

  // ── Public (device-token authenticated) ──────────────────────────────────
  /**
   * Resolve a kiosk device from its token.
   *
   * ROUND 14 (security review, PHASE K1 — defect found while live-verifying
   * the kiosk check-in gate): this route is @Public(), so there is NO ambient
   * tenant context, and the Branch/Gym relations are row-level-secured. The
   * single query that included them therefore failed with
   * "Inconsistent query result: Field branch is required to return data, got
   * `null` instead" — EVERY kiosk scan answered 500, so the check-in gate
   * could never even be reached (and the kiosk screen header was dead too).
   *
   * The device row (unfiltered) tells us its gym; the relations are then read
   * INSIDE that gym's tenant scope, which is also where the check-in below
   * runs.
   */
  private async resolveDevice(token: string | undefined) {
    if (!token) throw new UnauthorizedException('Missing device token');
    const bare = await this.prisma.kioskDevice.findUnique({ where: { token } });
    if (!bare) throw new UnauthorizedException('Unknown device token');
    if (!bare.active) throw new UnauthorizedException('Device is deactivated');
    // withTenant() — not just tenantContext.run() — because the Prisma
    // extension only pins app.gym_id for STANDALONE queries through an
    // AsyncLocalStorage read that this @Public() path cannot rely on; the
    // explicit transaction sets it on the connection the include joins run on.
    const device = await this.tenantContext.run(bare.gymId, () =>
      this.prisma.withTenant(bare.gymId, (tx) =>
        tx.kioskDevice.findUnique({
          where: { token },
          include: { branch: { select: { id: true, name: true } }, gym: { select: { id: true, name: true, status: true } } },
        }),
      ),
    );
    if (!device?.branch || !device?.gym) throw new UnauthorizedException('Device is not linked to a branch or gym');
    return device;
  }

  /** Public: who is this device (used by the kiosk screen header). */
  async whoami(token: string | undefined) {
    const device = await this.resolveDevice(token);
    await this.prisma.kioskDevice.update({ where: { id: device.id }, data: { lastSeenAt: new Date() } }).catch(() => undefined);
    return {
      deviceName: device.name,
      gymName: device.gym.name,
      branchId: device.branch.id,
      branchName: device.branch.name,
    };
  }

  /** Public: scan/enter a member QR code → record attendance at the device's branch. */
  async checkin(token: string | undefined, code: string) {
    const device = await this.resolveDevice(token);
    const cleanCode = String(code || '').trim();
    if (!cleanCode) throw new BadRequestException('Missing member code');
    if (device.gym.status !== 'ACTIVE') throw new BadRequestException('Gym is not active');

    // This route is @Public() (no TenantGuard), so there is no ambient tenant
    // context. FORCE RLS would hide every member/attendance row without it —
    // run the whole check-in inside the device's own tenant scope.
    return this.tenantContext.run(device.gymId, async () => {
      // Reuse the exact same attendance logic as staff check-in (session
      // deduction, expiry/frozen checks, realtime emission) — method stays QR,
      // but the actor is the kiosk itself.
      const result = await this.attendance.checkin(
        device.gymId,
        { code: cleanCode },
        'QR',
        `Self-service (${device.name})`,
        device.branchId,
      );
      await this.prisma.kioskDevice.update({ where: { id: device.id }, data: { lastSeenAt: new Date() } }).catch(() => undefined);
      return {
        ok: true,
        member: result.member
          ? {
              id: result.member.id,
              name: result.member.name,
              status: this.attendance.status(result.member),
              planName: result.member.plan?.name ?? null,
              expiry: result.member.expiry,
            }
          : null,
        branchName: device.branch.name,
        at: result.attendance.at,
      };
    });
  }
}
