/**
 * FLEXORA — Autonomous Scheduler LIVE integration check (ts-node).
 * Proves: KPI computation, flow decision, idempotency lock (no duplicate
 * executions), real action persistence, end-to-end via ExecutionService.
 * Runs against the real Postgres + Redis.
 */
// PHASE N1: load apps/api/.env explicitly — this script runs outside main.ts,
// so it must not depend on @prisma/client's import-time injection either.
import '../../config/load-env';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import { assertRedisTransport, redisConnectionOptions } from '../../config/redis-transport';
import { SchedulerService } from './scheduler.service';
import { ExecutionService } from '../execution/execution.service';
import { ReportsService } from '../reports/reports.service';

const prisma = new PrismaClient() as any;
// PHASE O1.4: this standalone entrypoint used to build a client with no
// transport check at all, so it would happily speak plaintext to Redis in
// production. It now consults the same shared decision as the API.
const schedulerRedisDecision = assertRedisTransport(process.env.REDIS_URL || 'redis://127.0.0.1:6379');
if (schedulerRedisDecision.warn) {
  // eslint-disable-next-line no-console
  console.warn(`[scheduler] ${schedulerRedisDecision.warn}`);
}
const redisClient = new Redis(process.env.REDIS_URL || 'redis://127.0.0.1:6379', {
  // PHASE P3 — bounded like every other client in the codebase (see
  // config/redis.service.ts). This one had NO limits at all, so ioredis fell back
  // to its defaults: an offline queue plus 20 retries per command, i.e. a job that
  // touched Redis while the server was down blocked instead of failing.
  maxRetriesPerRequest: 0,
  enableOfflineQueue: false,
  commandTimeout: Number(process.env.REDIS_COMMAND_TIMEOUT_MS || 1500),
  connectTimeout: Number(process.env.REDIS_CONNECT_TIMEOUT_MS || 2000),
  retryStrategy: (times: number) => Math.min(times * 200, 2000),
  ...redisConnectionOptions(schedulerRedisDecision),
});
const redis: any = {
  client: redisClient,
  get: (k: string) => redisClient.get(k),
  set: (k: string, v: string, ttl?: number) => (ttl ? redisClient.set(k, v, 'EX', ttl) : redisClient.set(k, v)),
  del: (k: string) => redisClient.del(k),
};
const reports = new ReportsService(prisma, redis);
const execution = new ExecutionService(prisma);
const waBot = { sendExpiryAlert: () => {}, sendBirthdayMessage: () => {}, sendReply: () => {} } as any;
const scheduler = new SchedulerService(prisma, redis, reports, execution, waBot);

const GYM = 'gym-sched-1';
let pass = 0, fail = 0;
const ok = (n: string, c: boolean) => { if (c) { pass++; process.stdout.write(`  PASS  ${n}\n`); } else { fail++; process.stdout.write(`  FAIL  ${n}\n`); } };

async function main() {
  // ensure scheduler queue is active for this run
  (scheduler as any).onModuleInit();
  // clear any leftover locks for deterministic test
  const keys = await redisClient.keys(`autoexec:lock:${GYM}:*`);
  if (keys.length) await redisClient.del(...keys);
  await (prisma as any).autonomousAction.deleteMany({ where: { gymId: GYM } });
  await (prisma as any).task.deleteMany({ where: { gymId: GYM, description: { startsWith: '[autonomous]' } } });

  process.stdout.write(String('\n=== KPI computation from real data ===') + '\n');
  const signals = await (scheduler as any).computeSignals(GYM);
  ok(`churnRisk computed = 50% (5/10 expiring)`, signals.churnRisk === 50);
  ok(`utilization computed = 0% (all staff checked out)`, signals.utilization === 0);
  ok(`staffCount = 4`, signals.staffCount === 4);

  process.stdout.write(String('\n=== flow decision (brain gating) ===') + '\n');
  const flows = (scheduler as any).decideFlows(signals);
  ok('decides churn flow (churnRisk>=30)', flows.includes('churn'));
  ok('decides utilization flow (util<40, staff>0)', flows.includes('utilization'));
  ok('does NOT decide revenue (no down trend)', !flows.includes('revenue'));

  process.stdout.write(String('\n=== scanGym: enqueue with idempotency lock (run #1) ===') + '\n');
  await (scheduler as any).scanGym(GYM);
  // drain the queue worker (process the enqueued job synchronously-ish)
  await new Promise((r) => setTimeout(r, 1500));
  const after1 = await (prisma as any).autonomousAction.count({ where: { gymId: GYM } });
  ok('actions persisted after first scan (>0)', after1 > 0);
  const lockKeys = await redisClient.keys(`autoexec:lock:${GYM}:*`);
  ok('execution lock present after scan', lockKeys.length === 1);

  process.stdout.write(String('\n=== scanGym AGAIN immediately (run #2) -> must be deduped ===') + '\n');
  await (scheduler as any).scanGym(GYM);
  await new Promise((r) => setTimeout(r, 1000));
  const after2 = await (prisma as any).autonomousAction.count({ where: { gymId: GYM } });
  ok('NO duplicate actions created on second scan (idempotent)', after2 === after1);

  process.stdout.write(String('\n=== Level-2 + approval gating preserved ===') + '\n');
  const acts = await (prisma as any).autonomousAction.findMany({ where: { gymId: GYM } });
  ok('auto actions are EXECUTED at level 2', acts.filter((a: any) => a.status === 'EXECUTED').every((a: any) => a.autonomyLevel === 2));
  ok('no destructive action types persisted', acts.every((a: any) => !['DELETE_MEMBER', 'CANCEL_SUBSCRIPTION'].includes(a.type)));

  process.stdout.write(String('\n=== traceability: signal/decision/owner present ===') + '\n');
  ok('every action carries signal+decision+ownerLabel', acts.every((a: any) => a.signal && a.decision && a.ownerLabel));

  process.stdout.write(String('\n=== flows actually executed (churn + utilization) ===') + '\n');
  ok('churn actions persisted', acts.some((a: any) => a.flow === 'churn'));
  ok('utilization actions persisted', acts.some((a: any) => a.flow === 'utilization'));

  process.stdout.write(String(`\nRESULT: ${pass} passed, ${fail} failed`) + '\n');
  await (scheduler as any).onModuleDestroy();
  await prisma.$disconnect();
  await redisClient.quit();
  process.exit(fail ? 1 : 0);
}
main().catch(async (e) => { console.error(e); try { await prisma.$disconnect(); await redisClient.quit(); } catch {} process.exit(1); });
