/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Autonomous Scheduler (OS Brain Heartbeat).
 *  - Cron every 5 minutes: fetch all active gyms, compute KPIs, run the
 *    validated Brain decisions, and enqueue ExecutionService flows when
 *    actionable.
 *  - Idempotency: a Redis execution lock keyed by (gymId + signalHash + window)
 *    prevents duplicate executions within the same window.
 *  - Queue-based (Bull) with retry/backoff; failures logged to AuditLog.
 *  - Respects Level-2 autonomy + approval gating (delegated to ExecutionService).
 *  - Self-running: no manual API trigger needed for core flows.
 */
import { Injectable, Logger, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import Bull, { Job, Queue as BullQueue } from 'bull';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { ReportsService } from '../reports/reports.service';
import { ExecutionService, THRESHOLDS } from '../execution/execution.service';
import { WaBotService } from '../wa-bot/wa-bot.service';
import { OwnerNotifyService } from '../notifications/owner-notify.service';
import { BackupsService } from '../backups/backups.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

/** Brain decision thresholds — parity with execution.service / validated brain. */
type Flow = 'churn' | 'revenue' | 'utilization' | 'recovery';
interface HeartbeatJob {
  gymId: string;
  flows: Flow[];
  signalHash: string;
  window: string;
  signals: Record<string, number | boolean>;
}

const QUEUE = 'autonomous-execution';
const WINDOW_MINUTES = 30; // dedup window: one execution per signal per 30 min

@Injectable()
export class SchedulerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(SchedulerService.name);
  private queue?: BullQueue<HeartbeatJob>;
  private enabled = false;

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly reports: ReportsService,
    private readonly execution: ExecutionService,
    private readonly waBot: WaBotService,
    private readonly ownerNotify: OwnerNotifyService,
    private readonly backups: BackupsService,
    private readonly cronLeadership: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  onModuleInit() {
    // Master kill-switch: scheduler only runs when explicitly enabled + Redis present.
    const url = process.env.REDIS_URL;
    if (process.env.AUTONOMOUS_SCHEDULER === 'off' || !url) {
      this.logger.warn('Autonomous scheduler disabled (AUTONOMOUS_SCHEDULER=off or no REDIS_URL)');
      return;
    }
    try {
      this.queue = new Bull<HeartbeatJob>(QUEUE, url, {
        defaultJobOptions: {
          attempts: 3,
          backoff: { type: 'exponential', delay: 10000 },
          removeOnComplete: 200,
          removeOnFail: 200,
        },
      });
      this.queue.process((job) => this.processJob(job));
      this.queue.on('failed', (job, err) => this.onJobFailed(job, err));
      this.enabled = true;
      this.logger.log('Autonomous scheduler online (queue=autonomous-execution)');
    } catch (e) {
      this.logger.warn(`Scheduler queue init failed, staying idle: ${(e as Error).message}`);
    }
  }

  async onModuleDestroy() {
    if (this.queue) await this.queue.close().catch(() => undefined);
  }

  /* =====================================================================
     HEARTBEAT — every 5 minutes. Detect -> enqueue (execution happens in
     the queue worker, so cron stays fast and failures get retried).
     ===================================================================== */
  @Cron('*/5 * * * *', { name: 'flexora-brain-heartbeat' })
  async heartbeat() {
    return requestContext.run({ requestId: 'cron:heartbeat' }, async () => {
      if (!this.enabled || !this.queue) return;
      if (!(await this.cronLeadership.acquireLock('scheduler-heartbeat', 180_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({ where: { status: 'ACTIVE' }, select: { id: true }, take: 500 });
        this.logger.log(`Heartbeat: scanning ${gyms.length} active gym(s)`);
        for (const g of gyms) {
          try {
            await this.tenantContext.run(g.id, () => this.scanGym(g.id));
          } catch (e) {
            await this.logFailure(g.id, 'heartbeat_scan', (e as Error).message);
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('scheduler-heartbeat');
      }
    });
  }

  /** Compute KPIs for one gym, decide actionable flows, enqueue with dedup lock. */
  private async scanGym(gymId: string) {
    // Step 3.4 — Proactive WhatsApp messages
    try {
      // Expiry alerts
      const expiring3 = await this.prisma.member.findMany({
        where: {
          gymId,
          expiry: {
            gte: new Date(),
            lte: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          },
          status: 'ACTIVE',
        },
        take: 500,
      });

      for (const m of expiring3) {
        const daysLeft = Math.ceil(
          (new Date(m.expiry!).getTime() - Date.now()) / (1000 * 60 * 60 * 24),
        );
        await this.waBot.sendExpiryAlert(gymId, m, daysLeft);
      }

      // Birthday messages
      const today = new Date();
      const todayMMDD = `${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      const birthdays = await this.prisma.member.findMany({
        where: {
          gymId,
          dob: { not: null },
        },
        take: 500,
      });

      const todayBirthdays = birthdays.filter((m) => {
        if (!m.dob) return false;
        const d = new Date(m.dob);
        const mmdd = `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        return mmdd === todayMMDD;
      });

      for (const m of todayBirthdays) {
        await this.waBot.sendBirthdayMessage(gymId, m);
      }

      // Step 6.5 — Lead follow-up after 24 hours
      const yesterday = new Date(Date.now() - 24 * 3600 * 1000);
      const staleLeads = await this.prisma.lead.findMany({
        where: {
          gymId,
          status: 'TRIAL_REQUESTED',
          createdAt: { lte: yesterday },
          updatedAt: { lte: yesterday }, // no activity in 24h
        },
        take: 500,
      });

      for (const lead of staleLeads) {
        const gym = await this.prisma.gym.findUnique({ where: { id: gymId }, select: { name: true } });
        const name = lead.name.split(' ')[0];
        const message = `مرحباً ${name} 👋\nهل تمكنت من زيارة ${gym?.name || 'الجيم'}؟\nنحن نتطلع لرؤيتك! 💪`;
        await this.waBot.sendReply(gymId, lead.mobile, message);
        // Mark as followed up to avoid duplicate messages
        await this.prisma.lead.update({ where: { id: lead.id }, data: { status: 'FOLLOWED_UP' } });
      }
    } catch (e) {
      this.logger.warn(`Proactive WA messages failed for gym ${gymId}: ${(e as Error).message}`);
    }

    const signals = await this.computeSignals(gymId);
    const flows = this.decideFlows(signals);
    if (flows.length === 0) return;

    const window = this.currentWindow();
    const signalHash = this.hashSignals(gymId, flows, window);
    const lockKey = `autoexec:lock:${gymId}:${signalHash}`;

    // Idempotency lock: SET NX with TTL. If the key exists, this signal was
    // already handled this window -> skip (prevents duplicate actions).
    let acquired = true;
    try {
      const lockVal = randomBytes(8).toString('hex');
      const res = await this.redis.client.set(lockKey, lockVal, 'EX', WINDOW_MINUTES * 60, 'NX');
      acquired = res === 'OK';
    } catch {
      // Redis down: fail safe -> do NOT execute (avoids unbounded duplicates).
      this.logger.warn(`Lock unavailable for ${gymId}; skipping this cycle`);
      return;
    }
    if (!acquired) {
      this.logger.debug(`Skip ${gymId}: signal already executed this window (${signalHash.slice(0, 8)})`);
      return;
    }

    await this.queue!.add(
      { gymId, flows, signalHash, window, signals },
      { jobId: lockKey }, // jobId == lockKey => Bull also dedups identical jobs
    );
    this.logger.log(`Enqueued execution for ${gymId}: [${flows.join(', ')}]`);
  }

  /* =====================================================================
     KPI COMPUTATION — reuses existing ReportsService (no new intelligence).
     ===================================================================== */
  private async computeSignals(gymId: string) {
    const [d, rev, staff] = await Promise.all([
      this.reports.dashboard(gymId),
      this.reports.revenueByMonth(gymId).catch(() => [] as { month: string; value: number }[]),
      this.prisma.staffAttendance.findMany({
        where: { gymId, checkInAt: { gte: this.startOfDay() } },
        select: { checkOutAt: true },
      }).catch(() => [] as { checkOutAt: Date | null }[]),
    ]);

    const totalMembers = d.totalMembers || 0;
    const churnRisk = totalMembers ? Math.round(((d.expiringMembers || 0) / Math.max(totalMembers, 1)) * 100) : 0;
    const retention = totalMembers ? Math.round(((d.activeMembers || 0) / Math.max(totalMembers, 1)) * 100) : 0;

    let revenueTrendDown = false;
    if (rev.length >= 2) {
      const last = rev[rev.length - 1].value;
      const prev = rev[rev.length - 2].value || 0;
      revenueTrendDown = last < prev;
    }

    const staffCount = staff.length;
    const activeStaff = staff.filter((s) => !s.checkOutAt).length;
    const utilization = staffCount ? Math.round((activeStaff / staffCount) * 100) : 0;

    return {
      churnRisk, retention, revenueTrendDown,
      utilization, staffCount,
      expiringMembers: d.expiringMembers || 0,
    };
  }

  /** Map KPI signals -> actionable flows (mirror of brain gating). */
  private decideFlows(s: Record<string, number | boolean>): Flow[] {
    const flows: Flow[] = [];
    if ((s.churnRisk as number) >= THRESHOLDS.CHURN_CRITICAL) flows.push('churn');
    if (s.revenueTrendDown === true) flows.push('revenue');
    if ((s.staffCount as number) > 0 && (s.utilization as number) < THRESHOLDS.UTILIZATION_LOW) flows.push('utilization');
    return flows;
  }

  /* =====================================================================
     QUEUE WORKER — runs the real ExecutionService flows (Level 2 + approval).
     Idempotent: ExecutionService persists; the lock prevented re-enqueue.
     ===================================================================== */
  private async processJob(job: Job<HeartbeatJob>) {
    return requestContext.run({ requestId: `job:heartbeat:${job.id}` }, async () => {
      const { gymId, flows, signals } = job.data;
      const results: Record<string, number> = {};
      for (const flow of flows) {
        try {
          if (flow === 'churn') {
            const actions = await this.execution.runChurnFlow({ gymId, churnRisk: signals.churnRisk as number });
            results.churn = actions.length;
          } else if (flow === 'revenue') {
            const actions = await this.execution.runRevenueFlow({ gymId, revenueTrendDown: true });
            results.revenue = actions.length;
          } else if (flow === 'utilization') {
            const actions = await this.execution.runUtilizationFlow({
              gymId, utilization: signals.utilization as number, staffCount: signals.staffCount as number,
            });
            results.utilization = actions.length;
          }
        } catch (e) {
          await this.logFailure(gymId, `execute_${flow}`, (e as Error).message);
          throw e; // let Bull retry (backoff)
        }
      }
      this.logger.log(`Executed for ${gymId}: ${JSON.stringify(results)}`);
      return results;
    });
  }

  private async onJobFailed(job: Job<HeartbeatJob> | undefined, err: Error) {
    const gymId = job?.data?.gymId;
    await this.logFailure(gymId, 'autonomous_job_failed', `${err.message} (attempt ${job?.attemptsMade})`);
  }

  /* =====================================================================
     FAILURE LOGGING -> AuditLog (traceable, queryable).
     ===================================================================== */
  private async logFailure(gymId: string | undefined, action: string, message: string) {
    try {
      await this.prisma.auditLog.create({
        data: {
          gymId: gymId ?? null,
          actorName: 'autonomous-scheduler',
          action,
          entity: 'AutonomousAction',
          meta: { message },
        },
      });
    } catch {
      this.logger.error(`[${gymId}] ${action}: ${message}`);
    }
  }

  /* ---- helpers ---- */
  private startOfDay() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }
  private currentWindow() {
    const now = new Date();
    const slot = Math.floor(now.getTime() / (WINDOW_MINUTES * 60 * 1000));
    return `w${slot}`;
  }
  private hashSignals(gymId: string, flows: Flow[], window: string) {
    return createHash('sha256').update(`${gymId}:${flows.sort().join(',')}:${window}`).digest('hex');
  }

  @Cron('0 8 * * 0')
  async sendAllWeeklyReports(): Promise<void> {
    return requestContext.run({ requestId: 'cron:weekly-reports' }, async () => {
      if (!(await this.cronLeadership.acquireLock('scheduler-weekly-reports', 3600_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({
          where: { status: 'ACTIVE' },
          select: { id: true, name: true },
          take: 500,
        });

        for (const gym of gyms) {
          try {
            await this.tenantContext.run(gym.id, () =>
              this.sendWeeklyReport(gym.id, gym.name),
            );
          } catch (e) {
            this.logger.error(
              `Weekly report failed for`  +
              `${gym.name}:`  +
              `${(e as Error).message}`);
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('scheduler-weekly-reports');
      }
    });
  }

  private async sendWeeklyReport(
    gymId: string,
    gymName: string,
  ): Promise<void> {
    const now = new Date();
    const weekAgo = new Date(
      now.getTime() - 7*24*60*60*1000);
    const twoWeeksAgo = new Date(
      weekAgo.getTime() - 7*24*60*60*1000);

    const [
      totalMembers, newMembers, expiredMembers,
      weekRevenue, lastWeekRevenue,
      weekCheckins, atRisk,
    ] = await Promise.all([
      this.prisma.member.count({
        where: { gymId, status: 'ACTIVE' }}),
      this.prisma.member.count({
        where: { gymId,
          createdAt: { gte: weekAgo }}}),
      this.prisma.member.count({
        where: { gymId, status: 'EXPIRED',
          expiry: { gte: weekAgo }}}),
      this.prisma.transaction.aggregate({
        where: { gymId, type: 'INCOME',
          createdAt: { gte: weekAgo }},
        _sum: { amount: true }}),
      this.prisma.transaction.aggregate({
        where: { gymId, type: 'INCOME',
          createdAt: {
            gte: twoWeeksAgo, lt: weekAgo }},
        _sum: { amount: true }}),
      this.prisma.attendance.count({
        where: { gymId,
          at: { gte: weekAgo }}}),
      this.prisma.member.count({
        where: { gymId, status: 'ACTIVE',
          expiry: { gte: now,
            lte: new Date(
              now.getTime()+7*24*60*60*1000) }}}),
    ]);

    const rev = Number(
      weekRevenue._sum.amount ?? 0);
    const lastRev = Number(
      lastWeekRevenue._sum.amount ?? 0);
    const revChange = lastRev > 0
      ? Math.round(((rev-lastRev)/lastRev)*100)
      : 0;

    const body =
      `👥 الأعضاء النشطين: ${totalMembers}\n` +
      `🆕 أعضاء جدد: ${newMembers}\n` +
      `❌ اشتراكات انتهت: ${expiredMembers}\n\n`+
      `💰 الإيرادات:`  +
      `${rev.toLocaleString('ar-EG')} ج\n` +
      `${revChange>=0?'📈':'📉'} مقارنة الأسبوع` +
       `الماضي: ${Math.abs(revChange)}%\n\n` +
      `🏃 الزيارات: ${weekCheckins}\n` +
      `⚠️ ينتهي اشتراكهم قريباً: ${atRisk}` +
      (atRisk>0
        ? `\n💡 يُنصح بالتواصل معهم`
        : `\n✅ لا توجد اشتراكات تنتهي قريباً`);

    await this.ownerNotify.notify({
      gymId,
      type: 'WEEKLY_REPORT',
      title: `📊 التقرير الأسبوعي — ${gymName}`,
      body,
      icon: 'chart',
      severity: 'info',
      sendWhatsApp: true,
    });

  }

  @Cron('0 2 * * *')
  async scheduledDailyBackup() {
    return requestContext.run({ requestId: 'cron:daily-backup' }, async () => {
      if (process.env.BACKUP_CRON_ENABLED !== 'true') return;
      if (!(await this.cronLeadership.acquireLock('daily-backup', 7200_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({
          where: { status: 'ACTIVE' },
          select: { id: true, slug: true },
          take: 500,
        });
        
        this.logger.log(`Starting daily backup for ${gyms.length} gyms`);
        
        for (const gym of gyms) {
          try {
            const verified = await this.tenantContext.run(gym.id, async () => {
              await this.backups.generateExcelBackup(gym.id, gym.slug);
              this.logger.log(`Backup complete: ${gym.slug}`);
              return this.backups.verifyLatestBackup(gym.id);
            });
            if (!verified.ok) {
              this.logger.error(`Backup verification FAILED for ${gym.slug}`);
            } else {
              this.logger.log(
                `Backup verified: ${gym.slug} — ${verified.sizeBytes} bytes`
              );
            }
          } catch (e) {
            this.logger.error(
              `Backup failed for ${gym.slug}: ${(e as Error).message}`
            );
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('daily-backup');
      }
    });
  }

  @Cron('0 3 * * *') // Run once daily at 3AM until all migrated
  async migrateNotificationMetadata(): Promise<void> {
    return requestContext.run({ requestId: 'cron:migrate-metadata' }, async () => {
      if (!(await this.cronLeadership.acquireLock('scheduler-migrate-metadata', 3600_000))) return;
      try {
        await this.ownerNotify.migrateUnencryptedMetadata();
      } finally {
        await this.cronLeadership.releaseLock('scheduler-migrate-metadata');
      }
    });
  }

  /** Manual trigger for ops/testing (does not bypass locks). */
  async runOnce(gymId?: string) {
    if (gymId) { await this.scanGym(gymId); return { ok: true, gym: gymId }; }
    await this.heartbeat();
    return { ok: true };
  }
}
