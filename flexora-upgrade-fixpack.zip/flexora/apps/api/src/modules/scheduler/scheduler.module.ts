/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Autonomous Scheduler module (OS Brain Heartbeat). Self-contained: provides
 * ReportsService locally (PrismaModule + RedisModule) and reuses the exported
 * ExecutionService. ScheduleModule.forRoot() is already registered globally.
 */
import { Module } from '@nestjs/common';
import { SchedulerService } from './scheduler.service';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { ExecutionModule } from '../execution/execution.module';
import { ReportsService } from '../reports/reports.service';
import { WaBotModule } from '../wa-bot/wa-bot.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { BackupsModule } from '../backups/backups.module';

@Module({
  imports: [PrismaModule, RedisModule, ExecutionModule, WaBotModule, NotificationsModule, BackupsModule],
  providers: [SchedulerService, ReportsService],
  exports: [SchedulerService],
})
export class SchedulerModule {}
