/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma, PtStatus } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { CreatePtSessionDto, ListPtDto, PtScheduleDto, UpdatePtSessionDto, UpsertCoachProfileDto,
} from './dto';
import { WaBotService } from '../wa-bot/wa-bot.service';

@Injectable()
export class PtService {
  private readonly logger = new Logger(PtService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly waBot: WaBotService,
  ) {}

  // ---- coaches ----
  async listCoaches(gymId: string) {
    const coaches = await this.prisma.user.findMany({
      where: { gymId, role: 'COACH', active: true },
      select: { id: true, name: true, email: true, branchId: true, coachProfile: true },
      orderBy: { name: 'asc' },
      take: 200,
    });
    return coaches.map((c) => ({
      id: c.id, name: c.name, email: c.email, branchId: c.branchId,
      profile: c.coachProfile
        ? {
            specialties: c.coachProfile.specialties,
            bio: c.coachProfile.bio, bioAr: c.coachProfile.bioAr,
            pricePerHour: Number(c.coachProfile.pricePerHour),
            active: c.coachProfile.active,
          }
        : null,
    }));
  }

  async upsertCoachProfile(gymId: string, dto: UpsertCoachProfileDto) {
    const coach = await this.prisma.user.findFirst({ where: { id: dto.userId, gymId, role: 'COACH' } });
    if (!coach) throw new BadRequestException('User is not a coach in this gym');
    const data = {
      specialties: dto.specialties ?? [],
      bio: dto.bio, bioAr: dto.bioAr,
      pricePerHour: dto.pricePerHour ?? 0,
    };
    return this.prisma.coachProfile.upsert({
      where: { userId: dto.userId },
      create: { userId: dto.userId, gymId, ...data },
      update: data,
    });
  }

  /** A coach may only view their own schedule; managers/owners view anyone's. */
  async coachSchedule(gymId: string, coachId: string, q: PtScheduleDto, requester: { sub: string; role: string }) {
    if (requester.role === 'COACH' && requester.sub !== coachId) {
      throw new ForbiddenException('Coaches can only view their own schedule');
    }
    const where: Prisma.PtSessionWhereInput = { gymId, coachId };
    if (q.from || q.to) {
      where.scheduledAt = {};
      if (q.from) (where.scheduledAt as Prisma.DateTimeFilter).gte = new Date(q.from);
      if (q.to) (where.scheduledAt as Prisma.DateTimeFilter).lte = new Date(q.to);
    }
    return this.prisma.ptSession.findMany({
      where,
      include: { member: { select: { id: true, name: true, mobile: true } } },
      orderBy: { scheduledAt: 'asc' },
      take: 50,
    });
  }

  // ---- sessions ----
  async create(gymId: string, dto: CreatePtSessionDto) {
    const [coach, member] = await Promise.all([
      this.prisma.user.findFirst({ where: { id: dto.coachId, gymId, role: 'COACH' } }),
      this.prisma.member.findFirst({ where: { id: dto.memberId, gymId } }),
    ]);
    if (!coach) throw new BadRequestException('Invalid coach');
    if (!member) throw new BadRequestException('Invalid member');
    const profile = await this.prisma.coachProfile.findUnique({ where: { userId: dto.coachId } });
    const price = dto.price ?? Number(profile?.pricePerHour ?? 0);
    return this.prisma.ptSession.create({
      data: {
        gymId, coachId: dto.coachId, memberId: dto.memberId, branchId: dto.branchId,
        scheduledAt: new Date(dto.scheduledAt), durationMin: dto.durationMin ?? 60, price,
      },
    });
  }

  /** Coaches can only update their own sessions (status/notes). */
  async update(gymId: string, id: string, dto: UpdatePtSessionDto, requester: { sub: string; role: string }) {
    const s = await this.prisma.ptSession.findFirst({ where: { id, gymId } });
    if (!s) throw new NotFoundException('PT session not found');
    if (requester.role === 'COACH' && s.coachId !== requester.sub) {
      throw new ForbiddenException('Coaches can only update their own sessions');
    }
    const data: Prisma.PtSessionUpdateInput = {
      notes: dto.notes,
      price: dto.price,
      paid: dto.paid,
      status: dto.status,
      durationMin: dto.durationMin,
      scheduledAt: dto.scheduledAt ? new Date(dto.scheduledAt) : undefined,
    };
    return this.prisma.ptSession.update({ where: { id }, data });
  }

  async list(gymId: string, q: ListPtDto) {
    const where: Prisma.PtSessionWhereInput = { gymId };
    if (q.coachId) where.coachId = q.coachId;
    if (q.memberId) where.memberId = q.memberId;
    if (q.status) where.status = q.status;
    const page = q.page ?? 1;
    const limit = q.limit ?? 20;
    const [items, total] = await this.prisma.$transaction([
      this.prisma.ptSession.findMany({
        where,
        include: {
          coach: { select: { id: true, user: { select: { name: true } } } },
          member: { select: { id: true, name: true } },
        },
        orderBy: { scheduledAt: 'desc' },
        skip: (page - 1) * limit, take: limit,
      }),
      this.prisma.ptSession.count({ where }),
    ]);
    return { items, total, page, limit };
  }

  /** Per-coach sessions this month + revenue (OWNER/MANAGER). */
  async coachStats(gymId: string) {
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
    const grouped = await this.prisma.ptSession.groupBy({
      by: ['coachId'],
      where: { gymId, scheduledAt: { gte: monthStart } },
      _count: { coachId: true },
      _sum: { price: true },
    });
    const rows = grouped as Array<{ coachId: string; _count: { coachId: number }; _sum: { price: Prisma.Decimal | null } }>;
    const coaches = await this.prisma.user.findMany({
      where: { gymId, id: { in: rows.map((r) => r.coachId) } },
      select: { id: true, name: true },
    });
    return rows.map((r) => ({
      coachId: r.coachId,
      coachName: coaches.find((c) => c.id === r.coachId)?.name ?? 'Unknown',
      sessions: r._count.coachId,
      revenue: Number(r._sum.price ?? 0),
    }));
  }

  // ---- Phase 12: Coach self check-in + session notes ----

  /** Coach marks themselves as having arrived for the session. */
  async coachCheckIn(gymId: string, sessionId: string, coachUserId: string) {
    const s = await this.prisma.ptSession.findFirst({ where: { id: sessionId, gymId } });
    if (!s) throw new NotFoundException('Session not found');
    if (s.coachId !== coachUserId) throw new ForbiddenException('Only the assigned coach can check in');
    if (s.coachCheckedIn) return s;
    return this.prisma.ptSession.update({
      where: { id: sessionId },
      data: { coachCheckedIn: true, coachCheckedInAt: new Date() },
    });
  }

  /** Coach records session notes, member progress, exercises, plan, and rating. */
  async completeSession(
    gymId: string,
    sessionId: string,
    coachUserId: string,
    payload: {
      coachSessionNotes?: string;
      memberProgress?: string;
      exercisesDone?: Prisma.InputJsonValue;
      nextSessionPlan?: string;
      rating?: number;
      paid?: boolean;
    },
  ) {
    const s = await this.prisma.ptSession.findFirst({
      where: { id: sessionId, gymId },
      include: {
        coach: { include: { user: { select: { name: true } } } },
        member: true,
      },
    });
    if (!s) throw new NotFoundException('Session not found');
    if (s.coachId !== coachUserId) throw new ForbiddenException('Only the assigned coach can complete');

    const result = await this.prisma.ptSession.update({
      where: { id: sessionId },
      data: {
        status: PtStatus.COMPLETED,
        coachSessionNotes: payload.coachSessionNotes,
        memberProgress: payload.memberProgress,
        exercisesDone: (payload.exercisesDone as Prisma.InputJsonValue) || Prisma.DbNull,
        nextSessionPlan: payload.nextSessionPlan,
        rating: payload.rating,
        paid: payload.paid ?? s.paid,
      },
    });

    // Step 3.5 — Hook PT session summary
    try {
      const nextSession = await this.prisma.ptSession.findFirst({
        where: { gymId, memberId: s.memberId, status: 'SCHEDULED', scheduledAt: { gt: new Date() } },
        orderBy: { scheduledAt: 'asc' },
      });

      await this.waBot.sendPtSessionSummary(gymId, s.member, {
        coachName: s.coach.user.name,
        exercises: Array.isArray(payload.exercisesDone) ? payload.exercisesDone.length : 0,
        nextDate: nextSession?.scheduledAt
          ? new Date(nextSession.scheduledAt).toLocaleDateString('ar-EG')
          : null,
      });
    } catch (e) {
      this.logger.warn(`Post-PT WhatsApp summary failed: ${(e as Error).message}`);
    }

    return result;
  }

  async listMemberSessions(gymId: string, memberId: string, limit = 20) {
    return this.prisma.ptSession.findMany({
      where: { gymId, memberId, status: 'COMPLETED' },
      include: {
        coach: { select: { user: { select: { name: true } } } },
      },
      orderBy: { scheduledAt: 'desc' },
      take: limit,
    });
  }

  async exportMemberSessions(gymId: string, memberId: string) {
    const sessions = await this.listMemberSessions(gymId, memberId, 100);
    const member = await this.prisma.member.findUnique({ where: { id: memberId, gymId } });
    
    // Simple PDF generation with pdfkit
    const PDFDocument = require('pdfkit');
    const doc = new PDFDocument();
    const chunks: Buffer[] = [];
    
    return new Promise<Buffer>((resolve, reject) => {
      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(20).text(`Flexora PT Progress Report - ${member?.name}`, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Date: ${new Date().toLocaleDateString()}`);
      doc.moveDown();

      sessions.forEach((s: { scheduledAt: Date | null; coach: { user: { name: string } }; rating?: number | null; memberProgress?: string | null; nextSessionPlan?: string | null }, i: number) => {
        const date = s.scheduledAt ? new Date(s.scheduledAt).toLocaleDateString() : 'N/A';
        doc.fontSize(14).text(`Session #${sessions.length - i}: ${date}`);
        doc.fontSize(10).text(`Coach: ${s.coach?.user?.name}`);
        doc.text(`Rating: ${s.rating || 'N/A'}/5`);
        doc.text(`Progress: ${s.memberProgress || '—'}`);
        doc.text(`Plan: ${s.nextSessionPlan || '—'}`);
        doc.moveDown();
      });

      doc.moveDown();
      doc.fontSize(8).text('Generated by Flexora Gym OS', { align: 'center' });
      doc.end();
    });
  }

  /** Coach dashboard — today's sessions + recent progress. */
  async coachDashboard(gymId: string, coachId: string) {
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(todayStart); todayEnd.setDate(todayEnd.getDate() + 1);
    const [today, upcoming, completedThisMonth, recentProgress] = await this.prisma.$transaction([
      this.prisma.ptSession.findMany({
        where: { gymId, coachId, scheduledAt: { gte: todayStart, lt: todayEnd } },
        orderBy: { scheduledAt: 'asc' },
        include: { member: { select: { id: true, name: true, mobile: true } } },
      }),
      this.prisma.ptSession.findMany({
        where: { gymId, coachId, scheduledAt: { gt: todayEnd }, status: 'SCHEDULED' },
        orderBy: { scheduledAt: 'asc' },
        take: 10,
        include: { member: { select: { id: true, name: true } } },
      }),
      this.prisma.ptSession.count({
        where: { gymId, coachId, status: 'COMPLETED', scheduledAt: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) } },
      }),
      this.prisma.ptSession.findMany({
        where: { gymId, coachId, status: 'COMPLETED' },
        orderBy: { scheduledAt: 'desc' },
        take: 10,
        include: { member: { select: { id: true, name: true } } },
      }),
    ]);
    return {
      today,
      upcoming,
      completedThisMonth,
      recentProgress: recentProgress.map((s) => ({
        memberName: s.member.name,
        date: s.scheduledAt,
        progress: s.memberProgress,
        plan: s.nextSessionPlan,
      })),
    };
  }
}
