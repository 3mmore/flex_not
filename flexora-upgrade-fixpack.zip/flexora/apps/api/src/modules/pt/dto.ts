/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { PtStatus } from '@prisma/client';
import { Type } from 'class-transformer';
import {
  IsArray, IsBoolean, IsDateString, IsEnum, IsInt, IsNumber, IsOptional, IsString, Min,
} from 'class-validator';

export class UpsertCoachProfileDto {
  @IsString() userId!: string;
  @IsOptional() @IsArray() @IsString({ each: true }) specialties?: string[];
  @IsOptional() @IsString() bio?: string;
  @IsOptional() @IsString() bioAr?: string;
  @IsOptional() @IsNumber() @Min(0) pricePerHour?: number;
}

export class CreatePtSessionDto {
  @IsString() coachId!: string;
  @IsString() memberId!: string;
  @IsDateString() scheduledAt!: string;
  @IsOptional() @IsInt() @Min(15) durationMin?: number;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsNumber() @Min(0) price?: number;
}

export class UpdatePtSessionDto {
  @IsOptional() @IsEnum(PtStatus) status?: PtStatus;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsBoolean() paid?: boolean;
  @IsOptional() @IsNumber() price?: number;
  @IsOptional() @IsInt() durationMin?: number;
  @IsOptional() @IsDateString() scheduledAt?: string;
}

export class PtScheduleDto {
  @IsOptional() @IsDateString() from?: string;
  @IsOptional() @IsDateString() to?: string;
}

export class ListPtDto {
  @IsOptional() @IsString() coachId?: string;
  @IsOptional() @IsString() memberId?: string;
  @IsOptional() @IsEnum(PtStatus) status?: PtStatus;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) page?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) limit?: number;
}
