import { Test, TestingModule } from '@nestjs/testing';
import { PtService } from './pt.service';
import { PrismaService } from '../../config/prisma.service';
import { WaBotService } from '../wa-bot/wa-bot.service';

describe('PtService', () => {
  let service: PtService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PtService,
        { provide: PrismaService, useValue: {} },
        { provide: WaBotService, useValue: { sendPtSessionSummary: jest.fn(), sendReply: jest.fn() } },
      ],
    }).compile();

    service = module.get<PtService>(PtService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
