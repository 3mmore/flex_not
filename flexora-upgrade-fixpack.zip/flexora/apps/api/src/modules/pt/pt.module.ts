/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PtService } from './pt.service';
import { PtController } from './pt.controller';
import { WaBotModule } from '../wa-bot/wa-bot.module';

@Module({
  imports: [JwtModule.register({}), WaBotModule],
  controllers: [PtController],
  providers: [PtService],
  exports: [PtService],
})
export class PtModule {}
