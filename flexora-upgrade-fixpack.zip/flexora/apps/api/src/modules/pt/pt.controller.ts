/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Patch, Post, Query, Res, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PtService } from './pt.service';
import {
  CreatePtSessionDto, ListPtDto, PtScheduleDto, UpdatePtSessionDto, UpsertCoachProfileDto,
} from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { MemberAuthGuard } from '../../common/guards/member-auth.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { CurrentMember } from '../../common/decorators/current-member.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Prisma } from '@prisma/client';
import { Response } from 'express';

@ApiTags('pt')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('pt')
export class PtController {
  constructor(private readonly svc: PtService) {}

  @Get('coaches') @Permissions('classes.manage')
  coaches(@GymId() g: string) { return this.svc.listCoaches(g); }

  @Post('coaches') @Permissions('staff.manage') @Audit('upsert', 'CoachProfile')
  createCoach(@GymId() g: string, @Body() d: UpsertCoachProfileDto) { return this.svc.upsertCoachProfile(g, d); }

  @Post('coaches/profile') @Permissions('staff.manage') @Audit('upsert', 'CoachProfile')
  upsertProfile(@GymId() g: string, @Body() d: UpsertCoachProfileDto) { return this.svc.upsertCoachProfile(g, d); }

  @Get('coaches/:id/schedule') @Permissions('classes.manage')
  schedule(
    @GymId() g: string, @Param('id') id: string, @Query() q: PtScheduleDto,
    @CurrentUser() u: { sub: string; role: string },
  ) {
    return this.svc.coachSchedule(g, id, q, u);
  }

  @Post('sessions') @Permissions('classes.manage') @Audit('create', 'PtSession')
  create(@GymId() g: string, @Body() d: CreatePtSessionDto) { return this.svc.create(g, d); }

  @Patch('sessions/:id') @Permissions('classes.manage') @Audit('update', 'PtSession')
  update(
    @GymId() g: string, @Param('id') id: string, @Body() d: UpdatePtSessionDto,
    @CurrentUser() u: { sub: string; role: string },
  ) {
    return this.svc.update(g, id, d, u);
  }

  @Get('sessions') @Permissions('classes.manage')
  list(@GymId() g: string, @Query() q: ListPtDto) { return this.svc.list(g, q); }

  @Get('coach-stats') @Permissions('classes.manage')
  coachStats(@GymId() g: string) { return this.svc.coachStats(g); }

  // ---- Phase 12: Coach self check-in + completion ----

  @Post('sessions/:id/check-in') @Permissions('classes.manage')
  @Audit('coach_check_in', 'PtSession')
  coachCheckIn(
    @GymId() g: string,
    @Param('id') id: string,
    @CurrentUser('sub') coachId: string,
  ) {
    return this.svc.coachCheckIn(g, id, coachId);
  }

  @Patch('sessions/:id/complete') @Permissions('classes.manage')
  @Audit('session_complete', 'PtSession')
  completePatch(
    @GymId() g: string,
    @Param('id') id: string,
    @CurrentUser('sub') coachId: string,
    @Body() payload: {
      coachSessionNotes?: string;
      memberProgress?: string;
      exercisesDone?: Prisma.InputJsonValue;
      nextSessionPlan?: string;
      rating?: number;
      paid?: boolean;
    },
  ) {
    return this.svc.completeSession(g, id, coachId, payload);
  }

  @Post('sessions/:id/complete') @Permissions('classes.manage')
  @Audit('session_complete', 'PtSession')
  complete(
    @GymId() g: string,
    @Param('id') id: string,
    @CurrentUser('sub') coachId: string,
    @Body() payload: {
      coachSessionNotes?: string;
      memberProgress?: string;
      exercisesDone?: Prisma.InputJsonValue;
      nextSessionPlan?: string;
      rating?: number;
      paid?: boolean;
    },
  ) {
    return this.svc.completeSession(g, id, coachId, payload);
  }

  @Get('sessions/my')
  @Public()
  @UseGuards(MemberAuthGuard)
  getMySessions(
    @CurrentMember('gymId') gymId: string,
    @CurrentMember('sub') memberId: string,
    @Query('limit') limit = 20,
  ) {
    return this.svc.listMemberSessions(gymId, memberId, +limit);
  }

  @Get('sessions/my/export')
  @Public()
  @UseGuards(MemberAuthGuard)
  async exportMySessions(
    @CurrentMember('gymId') gymId: string,
    @CurrentMember('sub') memberId: string,
    @Res() res: Response,
  ) {
    const buffer = await this.svc.exportMemberSessions(gymId, memberId);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=progress.pdf');
    res.setHeader('Content-Length', buffer.length.toString());
    res.send(buffer);
  }

  @Get('coach-dashboard') @Permissions('classes.manage')
  coachDashboard(
    @GymId() g: string,
    @CurrentUser('sub') coachId: string,
  ) {
    return this.svc.coachDashboard(g, coachId);
  }
}
