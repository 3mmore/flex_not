import { SalesService } from './sales.service';
import { PrismaService } from '../../config/prisma.service';
import { BadRequestException } from '@nestjs/common';

describe('SalesService Concurrency Retry Exhaustion', () => {
  it('throws original error if retries are exhausted', async () => {
    let attempt = 0;
    
    const mockPrisma: any = {
      $executeRaw: jest.fn().mockResolvedValue([[], []]),
      $transaction: jest.fn().mockImplementation(async (cb) => {
        attempt++;
        const error: any = new Error('Transaction failed due to a write conflict');
        error.code = '40001';
        throw error;
      })
    };
    mockPrisma.withTenant = jest.fn(async (_gymId: any, cb: any, _opts?: any) => mockPrisma.$transaction(cb, _opts));
    
    const svc = new SalesService(mockPrisma as any);
    (svc as any).normalizeItems = (items: any) => items;
    (svc as any).assertRefs = jest.fn().mockResolvedValue(true);
    (svc as any).afterCheckout = jest.fn().mockResolvedValue(true);
    
    await expect(svc.checkout('g1', 'User', { items: [{ productId: 'p1', qty: 1 }], paymentMethod: 'CASH', paymentStatus: 'PAID' }))
      .rejects.toThrow('write conflict');
    
    // FIX (pagination sweep): maxAttempts increased from 3 to 5 for better
    // serialization conflict handling under high concurrency
    expect(attempt).toBe(5);
    expect(mockPrisma.$transaction).toHaveBeenCalledTimes(5);
  });
});
