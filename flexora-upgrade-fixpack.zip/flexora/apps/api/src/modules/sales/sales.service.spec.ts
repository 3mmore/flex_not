/**
 * FLEXORA Gym OS — Sales service tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException } from '@nestjs/common';
import { SalesService } from './sales.service';

// Global mock for Prisma TransactionIsolationLevel
(global as any).Prisma = {
  TransactionIsolationLevel: {
    Serializable: 'Serializable',
  },
};

function build(extra: any = {}) {
  const prisma = {
    sale: { findFirst: jest.fn(), findMany: jest.fn(), count: jest.fn(), create: jest.fn(({ data }: any) => Promise.resolve({ id: 's1', ...data })) },
    product: { findMany: jest.fn().mockResolvedValue([{ id: 'p1', name: 'P1', sellingPrice: 100, qty: 10, lowStockThreshold: 5 }]), updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
    transaction: { create: jest.fn().mockResolvedValue({}) },
    invoice: { create: jest.fn(({ data }: any) => Promise.resolve({ id: 'i1', ...data })) },
    payment: { create: jest.fn(({ data }: any) => Promise.resolve({ id: 'py1', ...data })) },
    receipt: { create: jest.fn().mockResolvedValue({}) },
    refund: { findMany: jest.fn().mockResolvedValue([]), create: jest.fn(({ data }: any) => Promise.resolve({ id: 'r1', ...data })) },
    refundAudit: { create: jest.fn().mockResolvedValue({}) },
    branch: { findFirst: jest.fn().mockResolvedValue({ id: 'b1' }) },
    member: { findFirst: jest.fn().mockResolvedValue({ id: 'm1' }), findUnique: jest.fn().mockResolvedValue({ id: 'm1', name: 'M1' }) },
    $executeRaw: jest.fn().mockResolvedValue([[], []]),
    withTenant: jest.fn((_gymId: any, fn: any, _opts?: any) => prisma.$transaction(fn, _opts)),
    $transaction: jest.fn((fn: any) => fn(prisma)),
  } as any;
  const svc = new SalesService(prisma, {} as any, { emitToGym: jest.fn() } as any);
  return { svc, prisma };
}

describe('SalesService checkout', () => {
  it('rejects FAILED paymentStatus', async () => {
    const { svc } = build();
    await expect(svc.checkout('g1', 'staff', { paymentStatus: 'FAILED', paymentMethod: 'CARD', items: [{ productId: 'p1', qty: 1 }] } as any as CreateSaleDto)).rejects.toBeInstanceOf(BadRequestException);
  });

  it('returns existing sale if idempotencyKey matches', async () => {
    const existing = { id: 's1' };
    const { svc, prisma } = build();
    (prisma.sale.findFirst as jest.Mock).mockResolvedValue(existing);
    await expect(svc.checkout('g1', 'staff', { idempotencyKey: 'k1', items: [{ productId: 'p1', qty: 1 }] } as any as CreateSaleDto)).resolves.toBe(existing);
  });

  it('creates sale, invoice, payment and transaction on success', async () => {
    const { svc, prisma } = build();
    const sale = await svc.checkout('g1', 'staff', { paymentMethod: 'CARD', tax: 2, items: [{ productId: 'p1', qty: 1 }] } as any as CreateSaleDto);
    expect(sale.id).toBe('s1');
    expect(prisma.sale.create).toHaveBeenCalled();
    expect(prisma.transaction.create).toHaveBeenCalled();
    expect(prisma.invoice.create).toHaveBeenCalled();
  });
});

import { CreateSaleDto } from './dto';
