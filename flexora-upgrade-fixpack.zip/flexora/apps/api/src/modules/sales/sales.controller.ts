/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { SalesService } from './sales.service';
import { CreateSaleDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';
import { Audit } from '../../common/decorators/audit.decorator';
import { ArrayMinSize, IsArray, IsInt, IsOptional, IsString, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class RefundItemDto {
  @IsString() saleItemId!: string;
  @IsInt() @Min(1) qty!: number;
}
class RefundDto {
  @IsString() reason!: string;
  @IsOptional() @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => RefundItemDto)
  items?: RefundItemDto[];
}

@ApiTags('sales')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('pos')
@Controller('sales')
export class SalesController {
  constructor(private readonly svc: SalesService) {}
  @Get() @Permissions('pos.sell') list(@GymId() g: string, @Query('page') p = 1, @Query('limit') l = 20) { return this.svc.list(g, +p, +l); }

  @Get('reports/by-payment-method') @Permissions('reports.view')
  byPaymentMethod(@GymId() g: string, @Query('from') from?: string, @Query('to') to?: string) {
    return this.svc.salesByPaymentMethod(g, from ? new Date(from) : undefined, to ? new Date(to) : undefined);
  }

  @Get(':id') @Permissions('pos.sell')
  getSale(@GymId() g: string, @Param('id') id: string) { return this.svc.getSale(g, id); }
  @Post() @Permissions('pos.sell') @Audit('checkout','Sale')
  checkout(@GymId() g: string, @CurrentUser('name') u: string, @Body() d: CreateSaleDto) { return this.svc.checkout(g, u, d); }

  @Post(':id/refund') @Permissions('sales.refund') @Audit('refund','Sale')
  refund(@GymId() g: string, @Param('id') id: string, @CurrentUser('sub') userId: string, @Body() dto: RefundDto) {
    return this.svc.refund(g, id, userId, dto.reason, dto.items);
  }

  @Post(':id/void') @Permissions('sales.refund') @Audit('void','Sale')
  voidSale(@GymId() g: string, @Param('id') id: string, @CurrentUser('sub') userId: string, @Body() dto: RefundDto) {
    return this.svc.voidSale(g, id, userId, dto.reason);
  }
}
