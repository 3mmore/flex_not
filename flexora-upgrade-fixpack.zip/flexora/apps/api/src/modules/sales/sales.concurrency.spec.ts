import { SalesService } from './sales.service';
import { PrismaService } from '../../config/prisma.service';
import { BadRequestException } from '@nestjs/common';

describe('SalesService Concurrency Retry', () => {
  it('retries on serialization failure and eventually succeeds if stock allows', async () => {
    let attempt = 0;
    
    const mockPrisma = {
      $executeRaw: jest.fn().mockResolvedValue([[], []]),
      withTenant: jest.fn(async (_gymId: any, cb: any, _opts?: any) => mockPrisma.$transaction(cb, _opts)),
      $transaction: jest.fn().mockImplementation(async (cb) => {
        attempt++;
        if (attempt === 1) {
          const error: any = new Error('Transaction failed due to a write conflict');
          error.code = '40001';
          throw error;
        }
        
        // Simulating the transaction callback
        const mockTx = {
          $executeRaw: jest.fn().mockResolvedValue([[], []]),
          product: {
            findMany: jest.fn().mockResolvedValue([{ id: 'p1', name: 'Product 1', qty: 10, sellingPrice: 100 }]),
            updateMany: jest.fn().mockResolvedValue({ count: 1 })
          },
          sale: {
            create: jest.fn().mockResolvedValue({ id: 'sale1', invoiceNo: 'INV-123' })
          },
          invoice: {
            create: jest.fn().mockResolvedValue({ id: 'inv1' })
          },
          payment: {
            create: jest.fn().mockResolvedValue({ id: 'pay1' })
          },
          receipt: {
            create: jest.fn().mockResolvedValue({ id: 'rcpt1' })
          },
          transaction: {
            create: jest.fn().mockResolvedValue({ id: 'tx1' })
          }
        };
        return cb(mockTx);
      })
    };
    
    const svc = new SalesService(mockPrisma as any);
    (svc as any).normalizeItems = (items: any) => items;
    (svc as any).assertRefs = jest.fn().mockResolvedValue(true);
    (svc as any).afterCheckout = jest.fn().mockResolvedValue(true);
    
    const result = await svc.checkout('g1', 'User', { items: [{ productId: 'p1', qty: 1 }], paymentMethod: 'CASH', paymentStatus: 'PAID' });
    
    expect(result).toBeDefined();
    expect(result.id).toBe('sale1');
    expect(attempt).toBe(2);
    expect(mockPrisma.$transaction).toHaveBeenCalledTimes(2);
  });
});
