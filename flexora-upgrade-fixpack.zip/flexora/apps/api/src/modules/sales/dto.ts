/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsIn, IsInt, IsOptional, IsString, Min, ValidateNested } from 'class-validator';

export const PAYMENT_METHODS = ['CASH', 'CARD', 'WALLET', 'BANK', 'OTHER'] as const;
export const PAYMENT_STATUSES = ['PAID', 'FAILED'] as const;
export type PaymentMethod = typeof PAYMENT_METHODS[number];
export type CheckoutPaymentStatus = typeof PAYMENT_STATUSES[number];

export class SaleItemDto {
  @IsString() productId!: string;
  @IsInt() @Min(1) qty!: number;
}

export class CreateSaleDto {
  @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => SaleItemDto)
    items!: SaleItemDto[];

  @IsOptional() @Min(0) discount?: number;
  @IsOptional() @Min(0) tax?: number;

  @IsOptional() @IsIn(PAYMENT_METHODS) paymentMethod?: PaymentMethod;
  @IsOptional() @IsIn(PAYMENT_STATUSES) paymentStatus?: CheckoutPaymentStatus;
  @IsOptional() @IsString() paymentReference?: string;
  @IsOptional() @IsString() idempotencyKey?: string;

  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() memberId?: string;
}
