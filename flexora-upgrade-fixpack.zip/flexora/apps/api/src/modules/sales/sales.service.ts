/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Optional } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { CreateSaleDto } from './dto';
import { ProductEventEmitter } from '../../events/PRODUCT_EVENT_EMITTER';
import { BillingService } from '../billing/billing.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { OwnerNotifyService } from '../notifications/owner-notify.service';

const SALE_STATUS = {
  COMPLETED: 'COMPLETED',
  PARTIALLY_REFUNDED: 'PARTIALLY_REFUNDED',
  REFUNDED: 'REFUNDED',
  VOID: 'VOID',
  VOIDED: 'VOIDED',
} as const;

@Injectable()
export class SalesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly realtime: RealtimeGateway,
    private readonly events?: ProductEventEmitter,
    private readonly billing?: BillingService,
    @Optional() private readonly encryption?: EncryptionService,
    @Optional() private readonly ownerNotify?: OwnerNotifyService,
  ) {}

  private encryptReference(value?: string | null): string | undefined {
    if (!value) return value ?? undefined;
    return this.encryption ? this.encryption.encryptDeterministic(value) : value;
  }

  private async invalidate(gymId: string) {
    try { await this.redis.del(`reports:dashboard:${gymId}`); } catch { /* redis down */ }
  }

  list(gymId: string, page: number, limit: number) {
    return this.prisma.$transaction([
      this.prisma.sale.findMany({
        where: { gymId }, include: { items: true },
        orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: limit,
      }),
      this.prisma.sale.count({ where: { gymId } }),
    ]).then(([items, total]) => ({ items, total, page, limit }));
  }

  private normalizeItems(items: CreateSaleDto['items']) {
    const map = new Map<string, number>();
    for (const item of items) map.set(item.productId, (map.get(item.productId) || 0) + item.qty);
    return Array.from(map, ([productId, qty]) => ({ productId, qty }));
  }

  private async assertRefs(gymId: string, dto: CreateSaleDto) {
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    if (dto.memberId) {
      const member = await this.prisma.member.findFirst({ where: { id: dto.memberId, gymId } });
      if (!member) throw new BadRequestException('Invalid member');
    }
  }

  /** Atomic checkout: validates payment, validates stock, decrements inventory, writes sale + ledger transaction. */
  async getSale(gymId: string, saleId: string) {
    const sale = await this.prisma.sale.findFirst({ where: { id: saleId, gymId }, include: { items: true, transaction: true, member: { select: { id: true, name: true, mobile: true } }, branch: { select: { id: true, name: true } } } });
    if (!sale) throw new BadRequestException('Sale not found');
    return sale;
  }

  async salesByPaymentMethod(gymId: string, from?: Date, to?: Date) {
    const rows = await this.prisma.sale.groupBy({
      by: ['paymentMethod'],
      where: { gymId, status: { notIn: [SALE_STATUS.VOID, SALE_STATUS.VOIDED] }, ...(from || to ? { createdAt: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}) },
      _sum: { total: true },
      _count: { _all: true },
    });
    return rows.map((row) => ({ paymentMethod: row.paymentMethod || 'CASH', total: Number(row._sum.total || 0), count: row._count._all }));
  }

  async checkout(gymId: string, userName: string, dto: CreateSaleDto) {
    if (dto.paymentStatus === 'FAILED') {
      throw new BadRequestException('Payment failed; sale was not created');
    }
    if (dto.paymentStatus && dto.paymentStatus !== 'PAID') {
      throw new BadRequestException('Only paid POS checkouts can be completed');
    }
    await this.assertRefs(gymId, dto);

    if (dto.idempotencyKey) {
      const existing = await this.prisma.sale.findFirst({
        where: { gymId, idempotencyKey: dto.idempotencyKey },
        include: { items: true },
      });
      if (existing) {
        await this.billing?.reconcileSale(gymId, existing.id);
        return existing;
      }
    }

    const normalizedItems = this.normalizeItems(dto.items);
    let attempts = 0;
    const maxAttempts = 5;

    while (attempts < maxAttempts) {
      try {
        const sale = await this.prisma.withTenant(gymId, async (tx) => {
          const ids = normalizedItems.map((i) => i.productId);
        const products = await tx.product.findMany({ where: { gymId, id: { in: ids } } });
        const map = new Map(products.map((p) => [p.id, p]));

        let subtotal = 0;
        const itemsData = normalizedItems.map((i) => {
          const p = map.get(i.productId);
          if (!p) throw new BadRequestException(`Product ${i.productId} not found`);
          if (p.qty < i.qty) throw new BadRequestException(`Insufficient stock for ${p.name}`);
          subtotal += Number(p.sellingPrice ?? 0) * i.qty;
          const price = Number(p.sellingPrice ?? 0);
          return { productId: p.id, name: p.name, price, unitPrice: price, qty: i.qty, total: price * i.qty };
        });

        const discount = Number(dto.discount || 0);
        const tax = Number(dto.tax || 0);
        if (discount > subtotal) throw new BadRequestException('Discount cannot exceed subtotal');
        const total = subtotal - discount + tax;
        if (total < 0) throw new BadRequestException('Sale total cannot be negative');

        const invoiceNo = `INV-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString('hex').toUpperCase()}`;

        const sale = await tx.sale.create({
          data: {
            gymId,
            branchId: dto.branchId,
            memberId: dto.memberId,
            invoiceNo,
            status: SALE_STATUS.COMPLETED,
            paymentStatus: 'PAID',
            method: dto.paymentMethod || 'CASH',
            paymentMethod: dto.paymentMethod || 'CASH',
            paymentReference: this.encryptReference(dto.paymentReference),
            idempotencyKey: dto.idempotencyKey,
            subtotal,
            discount,
            tax,
            total,
            userName,
            items: { create: itemsData },
          },
          include: { items: true },
        });

        for (const i of normalizedItems) {
          const updated = await tx.product.updateMany({
            where: { id: i.productId, gymId, qty: { gte: i.qty } },
            data: { qty: { decrement: i.qty } },
          });
          if (updated.count !== 1) throw new BadRequestException('Insufficient stock');
        }

        /**
         * P4-5: plain-language ledger row for POS sales — the invoice number
         * moves to `reference`, and the description says what was sold.
         */
        const unitsSold = normalizedItems.reduce((s, i) => s + i.qty, 0);
        const productNames = [...new Set(itemsData.map((i) => i.name))].slice(0, 3).join(', ');
        await tx.transaction.create({
          data: {
            gymId,
            type: 'INCOME',
            category: 'product_sale',
            reference: invoiceNo,
            description: `POS sale — ${unitsSold} item${unitsSold === 1 ? '' : 's'}${productNames ? ` (${productNames})` : ''}`,
            amount: Number(sale.total ?? total),
            userName,
            memberId: dto.memberId || undefined,
            saleId: sale.id,
          },
        });

        const posInvoiceNo = `SALE-${invoiceNo}`;
        const receiptNo = `SALE-RCPT-${invoiceNo}`;
        // FIX (launch-readiness, discovered while re-verifying the FULL
        // apps/api test suite is green after the QueueService DI cascade
        // fix — a real, end-to-end POST /api/sales checkout with no
        // memberId (a genuinely valid walk-in/guest sale — Sale.memberId
        // itself is optional in schema.prisma for exactly this reason)
        // could never run before that fix, since the whole app failed to
        // boot): this used to pass `memberId: dto.memberId || ''` — an
        // empty string is not a valid Member id, and once Invoice's real
        // FK constraint to Member is in place (see migration 0015's
        // "EIGHTEENTH GAP"/no-FK-at-all fix), that empty string violates
        // the foreign key outright: "Foreign key constraint violated:
        // `Invoice_memberId_fkey (index)`". The correct fix, now that
        // `Invoice.memberId` is properly optional in schema.prisma
        // (matching the equally-optional `Sale.memberId` this value comes
        // from), is to omit the field entirely (`undefined`) for guest
        // sales rather than coercing to an invalid placeholder value.
        const invoice = await tx.invoice.create({
          data: {
            gymId,
            memberId: dto.memberId || undefined,
            invoiceNo: posInvoiceNo,
            status: 'PAID',
            subtotal,
            total,
            paid: total,
            lines: {
              create: itemsData.map((item) => ({
                description: item.name,
                qty: item.qty,
                unitPrice: item.price,
                total: Number(item.price) * item.qty,
              })),
            },
          },
        });
        const payment = await tx.payment.create({
          data: {
            gymId,
            invoiceId: invoice.id,
            amount: total,
            method: dto.paymentMethod || 'CASH',
            status: 'PAID',
            reference: this.encryptReference(dto.paymentReference),
            createdBy: userName,
            // PHASE I1: a POS sale payment belongs to the sale — never usable
            // as membership proof, never re-pointed to a membership invoice.
            purpose: 'POS_SALE',
            memberId: dto.memberId || null,
          },
        });
        await tx.receipt.create({ data: { gymId, invoiceId: invoice.id, paymentId: payment.id, receiptNo } });

        return sale;
      }, { isolationLevel: 'ReadCommitted' as any });

        await this.afterCheckout(gymId, sale, normalizedItems);
        return sale;
      } catch (e: unknown) {
        const msg = (e as any)?.message || '' || (e as any)?.meta?.cause || '';
        const errCode = (e as any)?.code;
        const isSerializationError = msg.includes('Transaction failed due to a write conflict')
          || msg.includes('serialization')
          || errCode === '40001'
          || errCode === 'P2034';
        if (isSerializationError) {
          attempts++;
          if (attempts < maxAttempts) {
            // Exponential backoff with jitter to de-correlate concurrent retries
            const baseDelay = 50 * Math.pow(2, attempts);
            const jitter = Math.random() * baseDelay;
            await new Promise((resolve) => setTimeout(resolve, jitter));
            continue;
          }
        }
        // Don't retry stock errors — they're real failures
        if (msg.includes('Insufficient stock') || msg.includes('Product') && msg.includes('not found')) {
          throw e;
        }
        if (dto.idempotencyKey && (e as Record<string, any>)?.code === 'P2002') {
          const existing = await this.prisma.sale.findFirst({ where: { gymId, idempotencyKey: dto.idempotencyKey }, include: { items: true } });
          if (existing) {
            await this.billing?.reconcileSale(gymId, existing.id);
            return existing;
          }
        }
        throw e;
      }
    }
    throw new Error('Unreachable');
  }

  private async afterCheckout(gymId: string, sale: Prisma.SaleGetPayload<{}>, items: Array<{ productId: string; qty: number }>) {
    await this.billing?.reconcileSale(gymId, sale.id);
    await this.invalidate(gymId);
    const ids = items.map((i) => i.productId);
    const after = await this.prisma.product.findMany({
      where: { gymId, id: { in: ids } }, select: { id: true, name: true, qty: true, lowStockThreshold: true },
    });
    await this.events?.emitEvent({
      type: 'sale.created',
      tenantId: gymId,
      branchId: sale.branchId,
      entityId: sale.id,
      payload: { saleId: sale.id, invoiceNo: sale.invoiceNo, total: Number(sale.total), paymentMethod: sale.paymentMethod },
      source: 'api',
    });
    for (const p of after) {
      if (p.qty <= p.lowStockThreshold) {
        this.realtime.emitToGym(gymId, 'low_stock', { productName: p.name, qty: p.qty });
        await this.events?.emitEvent({ type: 'inventory.low_stock', tenantId: gymId, entityId: p.id, payload: { productId: p.id, productName: p.name, qty: p.qty }, source: 'api' });
      }
    }

    // Owner notification
    try {
      let memberName = 'عضو';
      if (sale.memberId) {
        const member = await this.prisma.member.findFirst({ where: { id: sale.memberId, gymId }, select: { name: true } });
        if (member?.name) memberName = member.name;
      }
      await this.ownerNotify?.notifySale(gymId, {
        staffName: (sale as any).userName ?? 'موظف',
        memberName,
        amount: Number(sale.total),
        paymentMethod: sale.paymentMethod || sale.method || 'CASH',
        discount: Number(sale.discount ?? 0),
        originalAmount: Number(sale.subtotal ?? sale.total),
        invoiceId: sale.invoiceNo,
      });
    } catch {}
  }

  async refund(
    gymId: string,
    saleId: string,
    actorId: string,
    reason: string,
    requestedItems?: Array<{ saleItemId: string; qty: number }>,
  ) {
    if (!reason?.trim()) throw new BadRequestException('Refund reason is required');
    const refund = await this.prisma.withTenant(gymId, async (tx) => {
      const locked = await tx.$queryRaw<Array<{ id: string }>>`
        SELECT id FROM "Sale"
        WHERE id = ${saleId} AND "gymId" = ${gymId}
        FOR UPDATE
      `;
      if (locked.length !== 1) throw new BadRequestException('Sale not found');
      // Read refund totals only after locking the parent sale. Concurrent
      // refund requests now serialize and cannot both refund/restock the same
      // quantities from the same stale snapshot.
      const sale = await tx.sale.findFirst({ where: { id: saleId, gymId }, include: { items: true } });
      if (!sale) throw new BadRequestException('Sale not found');
      if (sale.status === SALE_STATUS.VOID || sale.status === SALE_STATUS.VOIDED) throw new BadRequestException('Voided sale cannot be refunded');
      if (sale.paymentStatus !== 'PAID') throw new BadRequestException('Only paid sales can be refunded');

      const existing = await tx.refund.findMany({ where: { gymId, saleId }, include: { items: true } });
      const refundedByItem = new Map<string, number>();
      let alreadyRefundedAmount = 0;
      for (const existingRefund of existing) {
        if (existingRefund.status === 'VOIDED') continue;
        alreadyRefundedAmount += Number(existingRefund.amount);
        for (const item of existingRefund.items) refundedByItem.set(item.saleItemId, (refundedByItem.get(item.saleItemId) || 0) + item.qty);
      }

      const items = requestedItems?.length ? requestedItems : sale.items.map((i) => ({ saleItemId: i.id, qty: i.qty - (refundedByItem.get(i.id) || 0) })).filter((i) => i.qty > 0);
      if (!items.length) throw new BadRequestException('Sale has no refundable quantity remaining');

      let amount = 0;
      const subtotal = Number(sale.subtotal || 0);
      const netSaleTotal = Number(sale.total || 0);
      const refundItems: Array<{ saleItemId: string; productId: string | null; qty: number; amount: number }> = [];
      for (const item of items) {
        const saleItem = sale.items.find((i) => i.id === item.saleItemId);
        if (!saleItem) throw new BadRequestException('Refund item is not part of sale');
        const already = refundedByItem.get(saleItem.id) || 0;
        if (item.qty <= 0 || already + item.qty > saleItem.qty) throw new BadRequestException('Refund quantity exceeds sold quantity');
        const grossLine = Number(saleItem.price) * item.qty;
        const lineAmount = subtotal > 0 ? Math.round((grossLine / subtotal) * netSaleTotal * 100) / 100 : grossLine;
        amount += lineAmount;
        refundItems.push({ saleItemId: saleItem.id, productId: saleItem.productId, qty: item.qty, amount: lineAmount });
      }
      amount = Math.round(amount * 100) / 100;
      if (amount <= 0 || alreadyRefundedAmount + amount > netSaleTotal + 0.01) throw new BadRequestException('Refund amount exceeds paid sale total');

      const refund = await tx.refund.create({
        data: {
          gymId,
          saleId,
          amount,
          reason,
          createdBy: actorId,
          staffId: actorId,
          type: requestedItems?.length ? 'PARTIAL' : 'FULL',
          itemSnapshot: refundItems as Prisma.InputJsonValue,
          items: { create: refundItems.map((i) => ({ saleItemId: i.saleItemId, productId: i.productId, qty: i.qty, amount: i.amount })) },
          audits: { create: { gymId, action: 'REFUND_CREATED', actorId, reason } },
        },
        include: { items: true },
      });

      for (const item of refundItems) {
        if (item.productId) {
          const updated = await tx.product.updateMany({ where: { id: item.productId, gymId }, data: { qty: { increment: item.qty } } });
          if (updated.count !== 1) throw new BadRequestException('Refund restock failed');
        }
      }
      // P4-5: readable reference (invoice no) instead of embedding the raw id.
      await tx.transaction.create({ data: { gymId, type: 'EXPENSE', category: 'refund', reference: sale.invoiceNo, description: `Refund of sale ${sale.invoiceNo}`, amount, memberId: sale.memberId || undefined, createdBy: actorId } });

      const allRefunded = sale.items.every((item) => (refundedByItem.get(item.id) || 0) + refundItems.filter((r) => r.saleItemId === item.id).reduce((s, r) => s + r.qty, 0) >= item.qty);
      await tx.sale.update({ where: { id: sale.id }, data: { status: allRefunded ? SALE_STATUS.REFUNDED : SALE_STATUS.PARTIALLY_REFUNDED, refundedAt: new Date() } });
      return refund;
    }, { isolationLevel: 'ReadCommitted' as any });
    await this.invalidate(gymId);
    await this.events?.emitEvent({ type: 'refund.created', tenantId: gymId, entityId: refund.id, payload: { saleId, refundId: refund.id, refundAmount: Number(refund.amount) }, source: 'api' });
    await this.billing?.syncRefund(gymId, refund.id);

    // Owner notification
    try {
      const sale = await this.prisma.sale.findFirst({ where: { id: saleId, gymId }, select: { invoiceNo: true, userName: true } });
      await this.ownerNotify?.notifyRefund(gymId, {
        staffName: sale?.userName ?? 'موظف',
        amount: Number(refund.amount),
        reason: reason ?? '',
        invoiceId: sale?.invoiceNo ?? saleId,
      });
    } catch {}

    return refund;
  }

  async voidSale(gymId: string, saleId: string, actorId: string, reason: string) {
    const existing = await this.prisma.refund.findFirst({ where: { gymId, saleId, status: 'COMPLETED' } });
    if (existing) throw new BadRequestException('Cannot void a refunded sale');
    const sale = await this.prisma.sale.findFirst({ where: { id: saleId, gymId }, include: { items: true } });
    if (!sale) throw new BadRequestException('Sale not found');
    if (sale.status === SALE_STATUS.VOID || sale.status === SALE_STATUS.VOIDED) throw new BadRequestException('Sale already voided');
    if (sale.status !== SALE_STATUS.COMPLETED) throw new BadRequestException('Only completed non-refunded sales can be voided');
    const startOfBusinessDay = new Date();
    startOfBusinessDay.setHours(0, 0, 0, 0);
    if (sale.createdAt < startOfBusinessDay) throw new BadRequestException('Sale can only be voided on the same business day');
    const refund = await this.refund(gymId, saleId, actorId, reason || 'Void sale');
    await this.prisma.sale.update({ where: { id: saleId }, data: { status: SALE_STATUS.VOIDED, voidedAt: new Date(), voidReason: reason || 'Void sale' } });
    await this.prisma.refundAudit.create({ data: { gymId, refundId: refund.id, action: 'SALE_VOIDED', actorId, reason } });
    return { ok: true, refund };
  }
}
