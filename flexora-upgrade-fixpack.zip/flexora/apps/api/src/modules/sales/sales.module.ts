/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { SecurityModule } from '../../common/security/security.module';
import { SalesService } from './sales.service';
import { SalesController } from './sales.controller';
import { PosController } from './pos.controller';
import { BillingModule } from '../billing/billing.module';
import { NotificationsModule } from '../notifications/notifications.module';
@Module({ imports: [JwtModule.register({}), BillingModule, NotificationsModule, SecurityModule], controllers: [SalesController, PosController], providers: [SalesService] })
export class SalesModule {}
