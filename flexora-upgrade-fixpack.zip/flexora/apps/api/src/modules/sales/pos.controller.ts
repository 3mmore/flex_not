/**
 * FLEXORA Gym OS — POS compatibility API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ArrayMinSize, IsArray, IsInt, IsOptional, IsString, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { SalesService } from './sales.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';
import { Audit } from '../../common/decorators/audit.decorator';

class PosRefundItemDto {
  @IsString() saleItemId!: string;
  @IsInt() @Min(1) qty!: number;
}
class PosRefundDto {
  @IsString() reason!: string;
  @IsOptional() @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => PosRefundItemDto)
  items?: PosRefundItemDto[];
}

@ApiTags('pos')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('pos')
@Controller('pos/sales')
export class PosController {
  constructor(private readonly sales: SalesService) {}

  @Get(':id')
  @Permissions('pos.sell')
  getSale(@GymId() gymId: string, @Param('id') id: string) {
    return this.sales.getSale(gymId, id);
  }

  @Post(':id/refund')
  @Permissions('sales.refund')
  @Audit('refund', 'Sale')
  refund(@GymId() gymId: string, @Param('id') id: string, @CurrentUser('sub') userId: string, @Body() dto: PosRefundDto) {
    return this.sales.refund(gymId, id, userId, dto.reason, dto.items);
  }

  @Post(':id/void')
  @Permissions('sales.refund')
  @Audit('void', 'Sale')
  void(@GymId() gymId: string, @Param('id') id: string, @CurrentUser('sub') userId: string, @Body() dto: PosRefundDto) {
    return this.sales.voidSale(gymId, id, userId, dto.reason);
  }
}
