/**
 * ROUND 13 (Phase 5) — the permission catalog.
 *
 * This is the single source of truth for the fine-grained, owner-controlled
 * permission system. Roles keep their coarse meaning (who you ARE); these
 * permissions decide what a user can actually DO. The effective set of a user
 * = ROLE_DEFAULTS[role] adjusted by per-user overrides (UserPermission rows).
 *
 * The catalog is deliberately the fixed list the product owner asked for —
 * endpoints map onto these keys, never the other way round.
 */

export const PERMISSIONS = [
  'members.view',
  'members.create',
  'members.edit',
  'members.delete',
  // ROUND 14 (security review, PHASE K3): importing members as ALREADY-PAID /
  // ACTIVE memberships is a privileged operation. members.create alone may only
  // import rows that cannot train yet (PENDING_PAYMENT or EXPIRED).
  'members.import',
  'plans.view',
  'plans.manage',
  'plans.delete',
  'attendance.manual',
  'pos.sell',
  'sales.refund',
  'inventory.view',
  'inventory.manage',
  'reports.view',
  'accounting.view',
  'accounting.manage',
  'settings.manage',
  'billing.manage',
  'staff.manage',
  'classes.manage',
  'contracts.manage',
  'branches.manage',
  'backups.manage',
  'payroll.manage',
  'profile.self',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export const PERMISSION_SET: ReadonlySet<string> = new Set(PERMISSIONS);

export function isPermission(value: unknown): value is Permission {
  return typeof value === 'string' && PERMISSION_SET.has(value);
}

/** Groups for the Team-page permission panel (and any other grouped UI). */
export interface PermissionGroup {
  key: string;
  label: string;
  permissions: Permission[];
}

export const PERMISSION_GROUPS: PermissionGroup[] = [
  {
    key: 'members',
    label: 'Members',
    permissions: ['members.view', 'members.create', 'members.edit', 'members.delete', 'members.import'],
  },
  {
    key: 'plans',
    label: 'Plans',
    permissions: ['plans.view', 'plans.manage', 'plans.delete'],
  },
  {
    key: 'attendance',
    label: 'Attendance',
    permissions: ['attendance.manual'],
  },
  {
    key: 'pos',
    label: 'Point of Sale',
    permissions: ['pos.sell'],
  },
  {
    key: 'inventory',
    label: 'Inventory',
    permissions: ['inventory.view', 'inventory.manage'],
  },
  {
    key: 'reports',
    label: 'Reports',
    permissions: ['reports.view'],
  },
  {
    key: 'accounting',
    label: 'Accounting',
    permissions: ['accounting.view', 'accounting.manage'],
  },
  {
    key: 'settings',
    label: 'Settings',
    permissions: ['settings.manage'],
  },
  {
    key: 'billing',
    label: 'Billing & License',
    permissions: ['billing.manage'],
  },
  {
    key: 'staff',
    label: 'Staff',
    permissions: ['staff.manage'],
  },
  {
    key: 'classes',
    label: 'Classes',
    permissions: ['classes.manage'],
  },
  {
    key: 'contracts',
    label: 'Contracts',
    permissions: ['contracts.manage'],
  },
  {
    key: 'sales',
    label: 'Sales',
    permissions: ['sales.refund'],
  },
  {
    key: 'branches',
    label: 'Branches',
    permissions: ['branches.manage'],
  },
  {
    key: 'backups',
    label: 'Backups & Restore',
    permissions: ['backups.manage'],
  },
  {
    key: 'payroll',
    label: 'Payroll',
    permissions: ['payroll.manage'],
  },
  {
    key: 'profile',
    label: 'My profile',
    permissions: ['profile.self'],
  },
];

/** Human-readable labels (en) for API consumers / the Team page. */
export const PERMISSION_LABELS: Record<Permission, string> = {
  'members.view': 'View members',
  'members.create': 'Add members & leads',
  'members.edit': 'Edit members, renewals & measurements',
  'members.delete': 'Delete members',
  'members.import': 'Import members as already-paid (active)',
  'plans.view': 'View plans',
  'plans.manage': 'Manage plans',
  'attendance.manual': 'Check-in & attendance',
  'pos.sell': 'Sell at the POS',
  'inventory.view': 'View inventory',
  'inventory.manage': 'Manage inventory & purchase orders',
  'reports.view': 'View reports & campaigns',
  'accounting.view': 'Accounting & expenses',
  'settings.manage': 'Settings & branding',
  'billing.manage': 'Billing & license',
  'staff.manage': 'Manage staff & permissions',
  'classes.manage': 'Classes & coaching',
  'contracts.manage': 'Contracts',
  'plans.delete': 'Delete plans',
  'sales.refund': 'Refund & void sales',
  'accounting.manage': 'Post journals, accounts & expenses',
  'branches.manage': 'Delete branches',
  'backups.manage': 'Backups, export & restore',
  'payroll.manage': 'Approve & pay payroll',
  'profile.self': 'Edit own profile (name, phone, password)',
};

/**
 * Default permission sets per role.
 *
 *   OWNER      — everything (the gym owner always keeps full control).
 *   MANAGER    — everything EXCEPT ownership-level operations: billing
 *                (billing.manage), backups/restore (backups.manage),
 *                payroll approval (payroll.manage), branch deletion
 *                (branches.manage) and plan deletion (plans.delete).
 *                sales.refund and accounting.manage stay with the MANAGER
 *                (the previous access level — a MANAGER could already refund
 *                and post accounting entries).
 *   RECEPTION  — daily front-desk operations.
 *   COACH      — members (view/edit progress), attendance, classes.
 *   ACCOUNTANT — read members + accounting (view AND manage: journal,
 *                accounts, seed, expenses — the previous access level).
 *
 * profile.self (edit your own name/phone/password) belongs to every role —
 * it is self-service, not a staff-management power.
 *
 * These defaults are a SUPERSET of what each role can already do through the
 * hard-coded role lists, so introducing the permission system never locks a
 * role out of something it uses today; the owner can tighten any of them per
 * employee from the Team page.
 */
export const ROLE_DEFAULTS: Record<string, Permission[]> = {
  OWNER: [...PERMISSIONS],
  // ROUND 14 (security review, PHASE K3): 'members.import' is OWNER by
  // default. A manager (or any other role) gets it only when the owner grants
  // it explicitly on the Team page — importing a spreadsheet of live, paid
  // memberships is the single largest way to create members who never paid.
  MANAGER: PERMISSIONS.filter(
    (p) =>
      p !== 'billing.manage' &&
      p !== 'backups.manage' &&
      p !== 'payroll.manage' &&
      p !== 'branches.manage' &&
      p !== 'plans.delete' &&
      p !== 'members.import',
  ),
  RECEPTION: [
    'members.view',
    'members.create',
    'members.edit',
    'plans.view',
    'attendance.manual',
    'pos.sell',
    'inventory.view',
    'classes.manage',
    'profile.self',
  ],
  COACH: [
    'members.view',
    'members.edit',
    'attendance.manual',
    'classes.manage',
    'profile.self',
  ],
  ACCOUNTANT: [
    'members.view',
    'accounting.view',
    'accounting.manage',
    'profile.self',
  ],
};

/** Roles that exist in the tenant (platform SUPER_ADMIN is handled separately). */
export const TENANT_ROLES = ['OWNER', 'MANAGER', 'RECEPTION', 'COACH', 'ACCOUNTANT'] as const;

export function roleDefaults(role: string): Permission[] {
  if (role === 'OWNER') return [...PERMISSIONS];
  return [...(ROLE_DEFAULTS[role] || [])];
}
