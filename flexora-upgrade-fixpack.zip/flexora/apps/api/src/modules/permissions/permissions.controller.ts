/**
 * ROUND 13 (Phase 5) — permissions controller.
 *
 *   GET  /permissions/catalog            the catalog + role defaults (staff.manage)
 *   GET  /permissions/me                 the caller's effective permissions
 *   GET  /permissions/users/:userId      one employee's overrides + effective set
 *   PUT  /permissions/users/:userId      apply override changes   (OWNER only)
 *   POST /permissions/users/:userId/reset reset to role defaults   (OWNER only)
 */
import { Controller, Get, Put, Post, Body, Param, UseGuards, Req } from '@nestjs/common';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { PermissionsService } from './permissions.service';

@Controller('permissions')
@UseGuards(JwtAuthGuard, TenantGuard)
export class PermissionsController {
  constructor(private readonly svc: PermissionsService) {}

  @Get('catalog')
  @Roles('OWNER', 'MANAGER')
  catalog() {
    return this.svc.catalog();
  }

  @Get('me') @Permissions('profile.self')
  async me(@CurrentUser() user: any) {
    return { permissions: await this.svc.effectivePermissions(user) };
  }

  @Get('users/:userId')
  @Roles('OWNER', 'MANAGER')
  describe(@GymId() gymId: string, @Param('userId') userId: string) {
    return this.svc.describeUser(gymId, userId);
  }

  @Put('users/:userId')
  @Roles('OWNER')
  async setOverrides(
    @GymId() gymId: string,
    @CurrentUser() actor: any,
    @Param('userId') userId: string,
    @Body() body: { changes?: Array<{ permission: string; granted: boolean }> },
    @Req() req: any,
  ) {
    return this.svc.setOverrides(gymId, actor, userId, body?.changes || [], req?.ip);
  }

  @Post('users/:userId/reset')
  @Roles('OWNER')
  async reset(
    @GymId() gymId: string,
    @CurrentUser() actor: any,
    @Param('userId') userId: string,
    @Req() req: any,
  ) {
    return this.svc.resetToDefaults(gymId, actor, userId, req?.ip);
  }
}
