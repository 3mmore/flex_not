/**
 * ROUND 13 (Phase 5) — permissions service.
 *
 * Effective permissions = role defaults adjusted by per-user overrides
 * (UserPermission rows). Overrides are:
 *   - stored per user (userId + permission, granted true/false),
 *   - editable ONLY by the OWNER (a MANAGER gets 403 no matter what they try,
 *     so they can never grant a permission they lack nor escalate anyone),
 *   - audit-logged on every change (AuditLog, action 'permission_change').
 *
 * OWNER-role users always keep the full catalog — the owner is the source of
 * truth for the gym and can never be locked out by an override row.
 */
import { Injectable, ForbiddenException, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import {
  PERMISSIONS,
  PERMISSION_GROUPS,
  PERMISSION_LABELS,
  Permission,
  isPermission,
  roleDefaults,
} from './permissions.catalog';

@Injectable()
export class PermissionsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenantContext: TenantContextService,
  ) {}

  /** The full catalog + role defaults (for the Team page and /auth/me). */
  catalog() {
    return {
      permissions: PERMISSIONS.map((key) => ({
        key,
        label: PERMISSION_LABELS[key],
        group: PERMISSION_GROUPS.find((g) => g.permissions.includes(key))?.key || 'other',
      })),
      groups: PERMISSION_GROUPS.map((g) => ({ key: g.key, label: g.label, permissions: [...g.permissions] })),
      roleDefaults: Object.fromEntries(
        Object.entries(
          Object.fromEntries(
            // include every known role so the panel can show defaults
            (['OWNER', 'MANAGER', 'RECEPTION', 'COACH', 'ACCOUNTANT'] as const).map((r) => [r, roleDefaults(r)]),
          ),
        ),
      ),
    };
  }

  /** Effective permissions of a user (OWNER always gets everything). */
  async effectivePermissions(user: { id: string; role: string; gymId: string | null }): Promise<Permission[]> {
    if (!user || !user.id) return [];
    if (user.role === 'OWNER') return [...PERMISSIONS];
    if (user.role === 'SUPER_ADMIN') return [...PERMISSIONS];
    const base = new Set<Permission>(roleDefaults(user.role));
    if (!user.gymId) return [...base];
    const gymId = user.gymId;
    // UserPermission has FORCE RLS (gymId = app.gym_id). Pre-auth call sites
    // (login / register / refresh token issuance) run WITHOUT the tenant ALS
    // context — the interceptor that sets it only runs on tenant-guarded
    // routes — so without this frame the override lookup would be silently
    // filtered to zero rows and tokens would be minted with role defaults
    // only. When a context already exists (controller path) it is kept as-is.
    const queryOverrides = () =>
      this.prisma.userPermission.findMany({
        where: { userId: user.id, gymId },
      });
    // NOTE: Prisma executes queries lazily at AWAIT time, so the await must
    // happen INSIDE the ALS frame — an async callback whose body awaits the
    // query keeps the whole execution (including the extension middleware's
    // tenantContext read) within the frame.
    // PHASE N3 — this lookup goes to the ROOT client, so it must NOT inherit an
    // enclosing interactive transaction's "skip the set_config wrapping" flag:
    // on a different pooled connection with app.gym_id unset, FORCE RLS hides
    // every override row and the caller silently gets role defaults. That is
    // exactly what happened to AuthService.refresh() (which rotates tokens inside
    // $transaction) — refreshed access tokens were minted without the grants the
    // owner had made, so the web route gate kept bouncing the employee to
    // /dashboard. outsideTransaction() clears the flag for this read only.
    const overrides = await this.prisma.outsideTransaction(() =>
      this.tenantContext.getGymId()
        ? queryOverrides()
        : this.tenantContext.run({ gymId }, async () => {
            return await this.prisma.userPermission.findMany({
              where: { userId: user.id, gymId },
            });
          }),
    );
    for (const o of overrides) {
      if (!isPermission(o.permission)) continue;
      if (o.granted) base.add(o.permission);
      else base.delete(o.permission);
    }
    return [...base];
  }

  /** Does the user hold ALL of the listed permissions? (guard helper) */
  async hasAll(user: { id: string; role: string; gymId: string | null }, required: string[]): Promise<boolean> {
    if (!required.length) return true;
    const effective = new Set(await this.effectivePermissions(user));
    return required.every((p) => effective.has(p as Permission));
  }

  /** Overrides + effective set for one employee (Team page). */
  async describeUser(gymId: string, targetUserId: string) {
    const target = await this.prisma.user.findFirst({ where: { id: targetUserId, gymId } });
    if (!target) throw new NotFoundException('User not found');
    const overrides = await this.prisma.userPermission.findMany({
      where: { userId: targetUserId, gymId },
      orderBy: { permission: 'asc' },
    });
    const effective = await this.effectivePermissions(target);
    return {
      user: { id: target.id, name: target.name, email: target.email, role: target.role, active: target.active },
      defaults: roleDefaults(target.role),
      overrides: overrides.map((o) => ({ permission: o.permission, granted: o.granted })),
      effective,
    };
  }

  /**
   * Apply override changes for one employee. OWNER-only. Every change is
   * audit-logged. A MANAGER calling this gets 403 — structurally they can
   * never grant a permission they lack or touch anyone's access.
   */
  async setOverrides(
    gymId: string,
    actor: { id: string; role: string; name?: string },
    targetUserId: string,
    changes: Array<{ permission: string; granted: boolean }>,
    ip?: string,
  ) {
    this.assertOwner(actor);
    const target = await this.prisma.user.findFirst({ where: { id: targetUserId, gymId } });
    if (!target) throw new NotFoundException('User not found');
    if (target.role === 'OWNER') {
      throw new BadRequestException('The owner always keeps full permissions — per-user overrides do not apply to the OWNER role.');
    }
    if (!Array.isArray(changes) || changes.length === 0) {
      throw new BadRequestException('No permission changes supplied');
    }
    // Validate every change against the catalog BEFORE writing anything.
    for (const c of changes) {
      if (!isPermission(c?.permission)) {
        throw new BadRequestException(`Unknown permission: ${String(c?.permission)}`);
      }
      if (typeof c?.granted !== 'boolean') {
        throw new BadRequestException(`Invalid granted flag for ${c.permission}`);
      }
    }

    const before = await this.effectivePermissions(target);
    for (const c of changes) {
      await this.prisma.userPermission.upsert({
        where: { userId_permission: { userId: targetUserId, permission: c.permission } },
        create: { userId: targetUserId, gymId, permission: c.permission, granted: c.granted },
        update: { granted: c.granted },
      });
      await this.audit(gymId, actor, target, c.permission, c.granted, ip);
    }
    const after = await this.effectivePermissions(target);
    return { user: { id: target.id, role: target.role }, before, after };
  }

  /** Remove all overrides — the employee falls back to their role defaults. */
  async resetToDefaults(
    gymId: string,
    actor: { id: string; role: string; name?: string },
    targetUserId: string,
    ip?: string,
  ) {
    this.assertOwner(actor);
    const target = await this.prisma.user.findFirst({ where: { id: targetUserId, gymId } });
    if (!target) throw new NotFoundException('User not found');
    if (target.role === 'OWNER') {
      throw new BadRequestException('The owner always keeps full permissions — nothing to reset.');
    }
    const before = await this.effectivePermissions(target);
    const removed = await this.prisma.userPermission.deleteMany({ where: { userId: targetUserId, gymId } });
    if (removed.count > 0) {
      await this.audit(gymId, actor, target, '*', null, ip);
    }
    const after = await this.effectivePermissions(target);
    return { user: { id: target.id, role: target.role }, removed: removed.count, before, after };
  }

  /** Only the OWNER manages permissions. */
  private assertOwner(actor: { role: string }) {
    if (actor?.role !== 'OWNER') {
      throw new ForbiddenException('Only the gym owner can manage employee permissions');
    }
  }

  private async audit(
    gymId: string,
    actor: { id: string; name?: string },
    target: { id: string; name: string; email: string },
    permission: string,
    granted: boolean | null,
    ip?: string,
  ) {
    try {
      await this.prisma.auditLog.create({
        data: {
          gymId,
          userId: actor.id,
          action: 'permission_change',
          entity: 'User',
          entityId: target.id,
          ip: ip || null,
          metadata: {
            targetName: target.name,
            targetEmail: target.email,
            permission,
            granted,
            note: granted === null ? 'reset to role defaults' : (granted ? 'granted' : 'revoked'),
          },
        },
      });
    } catch {
      // Auditing must never break the permission change itself.
    }
  }
}
