/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { PrismaService } from '../../config/prisma.service';

@ApiTags('audit')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('audit')
export class AuditController {
  constructor(private readonly prisma: PrismaService) {}
  @Get() @Roles('OWNER', 'SUPER_ADMIN')
  list(@GymId() gymId: string, @Query('page') page = 1, @Query('limit') limit = 50) {
    return this.prisma.$transaction([
      this.prisma.auditLog.findMany({ where: { gymId }, orderBy: { createdAt: 'desc' }, skip: (+page - 1) * +limit, take: +limit }),
      this.prisma.auditLog.count({ where: { gymId } }),
    ]).then(([items, total]) => ({ items, total, page: +page, limit: +limit }));
  }
}
