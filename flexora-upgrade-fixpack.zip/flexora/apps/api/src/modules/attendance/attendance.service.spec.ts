/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException } from '@nestjs/common';
import { AttendanceService } from './attendance.service';

const redisMock: any = { del: jest.fn() };
const realtime: any = { emitToGym: jest.fn() };
const day = 86400000;

function buildPrisma(member: any) {
  const memberUpdate = jest.fn().mockResolvedValue({});
  const memberUpdateMany = jest.fn().mockResolvedValue({ count: 1 });
  const tx = {
    $executeRaw: jest.fn().mockResolvedValue([[], []]),
    attendance: { create: jest.fn().mockResolvedValue({ id: 'a1', at: new Date() }) },
    member: { update: memberUpdate, updateMany: memberUpdateMany },
  };
  const prisma: any = {
    member: {
      findFirst: jest.fn().mockResolvedValue(member),
      findUnique: jest.fn().mockResolvedValue({ ...member }),
    },
    withTenant: jest.fn(async (_gymId: any, cb: any, _opts?: any) => cb(tx)),
    $transaction: (fn: any) => fn(tx),
  };
  return { prisma, memberUpdate, memberUpdateMany };
}

function svc(prisma: any) { return new AttendanceService(prisma, redisMock, realtime); }

describe('AttendanceService.checkin', () => {
  it('blocks an expired (TIME) member', async () => {
    const member = { id: 'm1', name: 'X', branchId: null, frozen: false, sessionsLeft: null,
      expiry: new Date(Date.now() - day), plan: { type: 'TIME' } };
    const { prisma } = buildPrisma(member);
    await expect(svc(prisma).checkin('g1', { id: 'm1' }, 'QR', 'staff'))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('blocks a frozen member', async () => {
    const member = { id: 'm1', name: 'X', branchId: null, frozen: true, sessionsLeft: null,
      expiry: new Date(Date.now() + 30 * day), plan: { type: 'TIME' } };
    const { prisma } = buildPrisma(member);
    await expect(svc(prisma).checkin('g1', { id: 'm1' }, 'QR', 'staff'))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('decrements sessionsLeft for SESSION plan', async () => {
    const member = { id: 'm1', name: 'X', branchId: null, frozen: false, sessionsLeft: 3, expiry: null,
      plan: { type: 'SESSION' } };
    const { prisma, memberUpdateMany } = buildPrisma(member);
    await svc(prisma).checkin('g1', { id: 'm1' }, 'QR', 'staff');
    expect(memberUpdateMany).toHaveBeenCalledTimes(1);
    const data = memberUpdateMany.mock.calls[0][0].data;
    expect(data.sessionsLeft).toEqual({ decrement: 1 });
    expect(data.visits).toEqual({ increment: 1 });
  });

  it('blocks SESSION member with 0 sessions left', async () => {
    const member = { id: 'm1', name: 'X', branchId: null, frozen: false, sessionsLeft: 0, expiry: null,
      plan: { type: 'SESSION' } };
    const { prisma } = buildPrisma(member);
    await expect(svc(prisma).checkin('g1', { id: 'm1' }, 'QR', 'staff'))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('allows active TIME member and does not touch sessionsLeft', async () => {
    const member = { id: 'm1', name: 'X', branchId: null, frozen: false, sessionsLeft: 0,
      expiry: new Date(Date.now() + 30 * day), plan: { type: 'TIME' } };
    const { prisma, memberUpdate } = buildPrisma(member);
    const res = await svc(prisma).checkin('g1', { id: 'm1' }, 'MANUAL', 'staff');
    expect(res.attendance.id).toBe('a1');
    expect(memberUpdate.mock.calls[0][0].data.sessionsLeft).toBe(0);
  });
});
