/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { CheckinMethod, Prisma } from '@prisma/client';
import { ProductEventEmitter } from '../../events/PRODUCT_EVENT_EMITTER';
// ROUND 14 (security review, PHASE K1): the ONE membership-state decision.
import { MembershipStatus, membershipStatus, canTrain, trainingDenialReason } from '../members/membership-status';

@Injectable()
export class AttendanceService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly realtime: RealtimeGateway,
    private readonly events?: ProductEventEmitter,
  ) {}

  private async invalidate(gymId: string) {
    try { await this.redis.del(`reports:dashboard:${gymId}`); } catch { /* redis down */ }
  }

  async findAll(gymId: string, page: number, limit: number, search?: string, branchId?: string) {
    return this.list(gymId, page, limit, search, branchId);
  }

  async list(gymId: string, page: number, limit: number, q?: string, branchId?: string) {
    const where: Prisma.AttendanceWhereInput = { gymId };
    if (branchId && branchId !== 'all') where.branchId = branchId;
    if (q) where.member = { name: { contains: q, mode: 'insensitive' } };
    const [items, total] = await this.prisma.$transaction([
      this.prisma.attendance.findMany({
        where, include: { member: true, branch: true },
        orderBy: { at: 'desc' }, skip: (page - 1) * limit, take: limit,
      }),
      this.prisma.attendance.count({ where }),
    ]);
    return { items, total, page, limit };
  }

  /** Membership status helper — public so the self-service kiosk (P2) can
   *  show the same verdict it enforced.
   *
   *  ROUND 14 (security review, PHASE K1): the rule now lives in the SHARED
   *  helper (members/membership-status.ts) and FAILS CLOSED. This copy used to
   *  answer `active` for a member with a TIME plan and a NULL expiry, so any
   *  member created outside the paid flow (a converted lead, an imported row)
   *  could check in and train for free and forever. */
  status(m: Prisma.MemberGetPayload<{ include: { plan: true } }>): MembershipStatus {
    return membershipStatus(m);
  }

  async checkinByMemberId(gymId: string, memberId: string, branchId: string, method: CheckinMethod, staffUserId?: string) {
    return this.checkin(gymId, { id: memberId }, method, staffUserId || 'staff', branchId);
  }

  async manualCheckin(gymId: string, memberId: string, branchId: string, staffUserId: string) {
    return this.checkinByMemberId(gymId, memberId, branchId, 'MANUAL', staffUserId);
  }

  async checkin(
    gymId: string,
    memberRef: { code?: string; id?: string },
    method: CheckinMethod,
    staffName: string,
    branchId?: string,
  ) {
    const member = await this.prisma.member.findFirst({
      where: { gymId, ...(memberRef.code ? { code: memberRef.code } : { id: memberRef.id }) },
      include: { plan: true },
    });
    if (!member) throw new NotFoundException('Member not found');
    if (branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
      if (member.branchId && member.branchId !== branchId) {
        throw new BadRequestException('Member does not belong to this branch');
      }
    }

    // ROUND 14 (security review, PHASE K1): one shared, FAIL-CLOSED gate. An
    // open-ended member (TIME plan, null expiry) or an unpaid PENDING_PAYMENT
    // member is refused on every check-in path — manual, QR, kiosk, device.
    if (!canTrain(member)) {
      throw new BadRequestException(trainingDenialReason(member));
    }
    const st = this.status(member);

    // Atomic: deduct session (if any) + write attendance + bump visits
    const result = await this.prisma.withTenant(gymId, async (tx) => {
      if (member.plan?.type === 'SESSION') {
        const data = { sessionsLeft: (member.sessionsLeft ?? 0) - 1, visits: { increment: 1 }, lastVisit: new Date() };
        const updated = await tx.member.updateMany({ where: { id: member.id, gymId, sessionsLeft: { gt: 0 } }, data: { sessionsLeft: { decrement: 1 }, visits: { increment: 1 }, lastVisit: new Date() } });
        if (updated.count === 0) throw new BadRequestException('No sessions remaining');
      } else {
        // gymId-safe: id already tenant-scoped above
        await tx.member.update({
          where: { id: member.id },
          data: { sessionsLeft: 0, visits: { increment: 1 }, lastVisit: new Date() },
        });
      }
      const att = await tx.attendance.create({
        data: {
          gymId, memberId: member.id, branchId: branchId ?? member.branchId,
          method, staffName,
        },
      });
      return att;
    });

    const fresh = await this.prisma.member.findUnique({
      where: { id: member.id, gymId }, include: { plan: true },
    });
    await this.invalidate(gymId);
    this.realtime.emitToGym(gymId, 'checkin', { memberName: fresh?.name, branchName: null, at: result.at });
    await this.events?.emitEvent({ type: 'attendance.checked_in', tenantId: gymId, branchId: result.branchId, entityId: result.id, payload: { attendanceId: result.id, memberId: result.memberId }, source: 'api' });
    return { attendance: result, member: fresh };
  }
}
