/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { CheckinMethod } from '@prisma/client';
export class CheckinDto {
  @IsString() memberCode!: string;   // scanned QR payload (member.code)
  @IsOptional() @IsEnum(CheckinMethod) method?: CheckinMethod;
  @IsOptional() @IsString() branchId?: string;
}
export class ManualCheckinDto {
  @IsString() memberId!: string;
  @IsOptional() @IsString() branchId?: string;
}
