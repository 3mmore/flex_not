/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { AttendanceService } from './attendance.service';
import { CheckinDto, ManualCheckinDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('attendance')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('attendance')
export class AttendanceController {
  constructor(private readonly svc: AttendanceService) {}

  @Get()
  @Permissions('members.view')
  list(
    @GymId() gymId: string,
    @Query('page') page = 1, @Query('limit') limit = 20,
    @Query('q') q?: string, @Query('branchId') branchId?: string,
  ) {
    return this.svc.list(gymId, +page, +limit, q, branchId);
  }

  @Post('checkin')
  @Permissions('attendance.manual')
  @Audit('checkin', 'Attendance')
  checkin(@GymId() gymId: string, @CurrentUser('name') staff: string, @Body() dto: CheckinDto) {
    return this.svc.checkin(gymId, { code: dto.memberCode }, dto.method || 'QR', staff, dto.branchId);
  }

  @Post('manual')
  @Permissions('attendance.manual')
  @Audit('checkin_manual', 'Attendance')
  manual(@GymId() gymId: string, @CurrentUser('name') staff: string, @Body() dto: ManualCheckinDto) {
    return this.svc.checkin(gymId, { id: dto.memberId }, 'MANUAL', staff, dto.branchId);
  }
}
