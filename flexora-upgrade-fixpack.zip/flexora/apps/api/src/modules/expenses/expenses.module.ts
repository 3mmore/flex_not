/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ExpensesService } from './expenses.service';
import { ExpensesController } from './expenses.controller';
@Module({ imports: [JwtModule.register({})], controllers: [ExpensesController], providers: [ExpensesService] })
export class ExpensesModule {}
