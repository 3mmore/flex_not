/**
 * FLEXORA Gym OS — Branch transfers (Phase 17)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { Prisma, TransferStatus, TransferEntity, StockMovementType } from '@prisma/client';

@Injectable()
export class TransfersService {
  private readonly logger = new Logger(TransfersService.name);
  constructor(private readonly prisma: PrismaService) {}

  list(gymId: string, opts: { entity?: TransferEntity; status?: TransferStatus } = {}) {
    return this.prisma.branchTransfer.findMany({
      where: {
        gymId,
        ...(opts.entity ? { entity: opts.entity } : {}),
        ...(opts.status ? { status: opts.status } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  async create(gymId: string, dto: { entity: TransferEntity; entityId: string; fromBranchId?: string; toBranchId: string; reason?: string; requestedBy: string }) {
    if (dto.fromBranchId === dto.toBranchId) throw new BadRequestException('Source and target branches must differ');
    return this.prisma.branchTransfer.create({
      data: {
        gymId, entity: dto.entity, entityId: dto.entityId,
        fromBranchId: dto.fromBranchId, toBranchId: dto.toBranchId,
        reason: dto.reason, requestedBy: dto.requestedBy, status: TransferStatus.PENDING,
      },
    });
  }

  async approve(gymId: string, id: string, approvedBy: string) {
    const t = await this.get(gymId, id);
    if (t.status !== TransferStatus.PENDING) throw new BadRequestException(`Cannot approve a transfer in ${t.status} state`);
    return this.prisma.branchTransfer.update({ where: { id }, data: { status: TransferStatus.APPROVED, approvedBy } });
  }

  async complete(gymId: string, id: string) {
    return this.prisma.withTenant(gymId, async (tx) => {
      const t = await tx.branchTransfer.findFirst({ where: { id, gymId } });
      if (!t) throw new NotFoundException('Transfer not found');
      if (t.status !== TransferStatus.APPROVED) throw new BadRequestException('Transfer must be approved first');
      
      if (t.entity === TransferEntity.MEMBER) {
        await tx.member.updateMany({ where: { id: t.entityId, gymId }, data: { branchId: t.toBranchId || undefined } });
      } else if (t.entity === TransferEntity.COACH) {
        await tx.user.updateMany({ where: { id: t.entityId, gymId, role: 'COACH' }, data: { branchId: t.toBranchId || undefined } });
      } else if (t.entity === TransferEntity.INVENTORY) {
        // StockMovementType doesn't have TRANSFER_MARKER in DB Enum
        // Migration 0008b had: CREATE TYPE "StockMovementType" AS ENUM ('PURCHASE','SALE','TRANSFER_IN','TRANSFER_OUT','ADJUSTMENT','EXPIRY');
        await tx.stockMovement.create({ data: { gymId, productId: t.entityId, branchId: t.toBranchId || undefined, type: StockMovementType.TRANSFER_IN, qty: 0, reference: t.id } });
      }
      return tx.branchTransfer.update({ where: { id: t.id }, data: { status: TransferStatus.COMPLETED, completedAt: new Date() } });
    });
  }

  async cancel(gymId: string, id: string) {
    const t = await this.get(gymId, id);
    if (t.status === TransferStatus.COMPLETED) throw new BadRequestException('Cannot cancel a completed transfer');
    return this.prisma.branchTransfer.update({ where: { id }, data: { status: TransferStatus.CANCELLED } });
  }

  async get(gymId: string, id: string) {
    const t = await this.prisma.branchTransfer.findFirst({ where: { id, gymId } });
    if (!t) throw new NotFoundException('Transfer not found');
    return t;
  }
}
