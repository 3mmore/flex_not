/**
 * FLEXORA Gym OS — Transfers tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { TransfersService } from './transfers.service';

// Global mock for Prisma TransactionIsolationLevel
(global as any).Prisma = {
  TransactionIsolationLevel: {
    Serializable: 'Serializable',
  },
};

const store: { transfers: any[]; memberUpdates: any[]; userUpdates: any[]; productUpdates: any[]; stockMovements: any[] } = { transfers: [], memberUpdates: [], userUpdates: [], productUpdates: [], stockMovements: [] };

const FakePrisma: any = {
  $executeRaw: jest.fn().mockResolvedValue([[], []]),
  withTenant: jest.fn(async (_gymId: any, cb: any, _opts?: any) => FakePrisma.$transaction(cb, _opts)),
  $transaction: jest.fn(async (cb, opts) => {
    if (typeof cb === 'function') return cb(FakePrisma);
    return cb;
  }),
  branchTransfer: {
    create: ({ data }: any) => {
      const r = { id: 'tx-' + Math.random(), ...data, createdAt: new Date() };
      store.transfers.push(r);
      return r;
    },
    findFirst: ({ where }: any) => store.transfers.find((d: any) => d.id === where?.id && d.gymId === where?.gymId) || null,
    findMany: ({ where }: any) => store.transfers.filter((d: any) => d.gymId === where?.gymId),
    update: ({ where, data }: any) => {
      const r = store.transfers.find((d: any) => d.id === where.id);
      Object.assign(r, data);
      return r;
    },
  },
  member: { updateMany: jest.fn(({ where, data }: any) => { store.memberUpdates.push({ where, data }); return { count: 1 }; }) },
  user: { updateMany: jest.fn(({ where, data }: any) => { store.userUpdates.push({ where, data }); return { count: 1 }; }) },
  product: { update: jest.fn(({ where, data }: any) => { store.productUpdates.push({ where, data }); return { ...where, ...data }; }) },
  stockMovement: { create: jest.fn(({ data }: any) => { store.stockMovements.push(data); return { id: 'sm1', ...data }; }) },
};

describe('TransfersService', () => {
  let svc: TransfersService;
  beforeEach(() => {
    store.transfers = []; store.memberUpdates = []; store.userUpdates = []; store.productUpdates = [];
    svc = new TransfersService(FakePrisma);
  });

  it('creates a PENDING transfer', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    expect(t.status).toBe('PENDING');
    expect(store.transfers.length).toBe(1);
  });

  it('rejects same-branch transfers', async () => {
    await expect(svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b1', requestedBy: 'u1' })).rejects.toThrow(/differ/);
  });

  it('approves a PENDING transfer', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    const a = await svc.approve('g1', t.id, 'owner');
    expect(a.status).toBe('APPROVED');
  });

  it('rejects double-approve', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await svc.approve('g1', t.id, 'owner');
    await expect(svc.approve('g1', t.id, 'owner')).rejects.toThrow(/approve/);
  });

  it('completes a MEMBER transfer and updates branchId', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await svc.approve('g1', t.id, 'owner');
    await svc.complete('g1', t.id);
    expect(store.memberUpdates[0]).toEqual({ where: { id: 'm1', gymId: 'g1' }, data: { branchId: 'b2' } });
  });

  it('completes a COACH transfer', async () => {
    const t = await svc.create('g1', { entity: 'COACH', entityId: 'u1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await svc.approve('g1', t.id, 'owner');
    await svc.complete('g1', t.id);
    expect(store.userUpdates.length).toBe(1);
  });

  it('completes an INVENTORY transfer', async () => {
    const t = await svc.create('g1', { entity: 'INVENTORY', entityId: 'p1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await svc.approve('g1', t.id, 'owner');
    await svc.complete('g1', t.id);
    expect(store.stockMovements.length).toBe(1);
  });

  it('cancels a PENDING transfer', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    const c = await svc.cancel('g1', t.id);
    expect(c.status).toBe('CANCELLED');
  });

  it('cannot cancel COMPLETED transfer', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await svc.approve('g1', t.id, 'owner');
    await svc.complete('g1', t.id);
    await expect(svc.cancel('g1', t.id)).rejects.toThrow(/completed/i);
  });

  it('cannot complete without approval', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await expect(svc.complete('g1', t.id)).rejects.toThrow(/approved/);
  });

  it('isolates by gymId (no cross-tenant)', async () => {
    const t = await svc.create('g1', { entity: 'MEMBER', entityId: 'm1', fromBranchId: 'b1', toBranchId: 'b2', requestedBy: 'u1' });
    await expect(svc.get('g2', t.id)).rejects.toThrow(/not found/);
    const listed = await svc.list('g2');
    expect(listed).toEqual([]);
  });
});
