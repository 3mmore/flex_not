/**
 * FLEXORA Gym OS — Transfers controller (Phase 17)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsEnum, IsIn, IsOptional, IsString } from 'class-validator';
import { TransferEntity, TransferStatus } from '@prisma/client';
import { TransfersService } from './transfers.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class CreateTransferDto {
  @IsEnum(TransferEntity) entity!: TransferEntity;
  @IsString() entityId!: string;
  @IsOptional() @IsString() fromBranchId?: string;
  @IsString() toBranchId!: string;
  @IsOptional() @IsString() reason?: string;
}

@ApiTags('transfers')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('transfers')
export class TransfersController {
  constructor(private readonly svc: TransfersService) {}

  @Get()
  @Permissions('inventory.manage')
  list(@GymId() g: string, @Query('entity') entity?: TransferEntity, @Query('status') status?: TransferStatus) {
    return this.svc.list(g, { entity, status });
  }

  @Post()
  @Permissions('inventory.manage')
  @Audit('create', 'BranchTransfer')
  create(@GymId() g: string, @Body() dto: CreateTransferDto, @CurrentUser('sub') userId: string) {
    return this.svc.create(g, { ...dto, requestedBy: userId });
  }

  @Post(':id/approve')
  @Permissions('inventory.manage')
  @Audit('approve', 'BranchTransfer')
  approve(@GymId() g: string, @Param('id') id: string, @CurrentUser('sub') userId: string) {
    return this.svc.approve(g, id, userId);
  }

  @Post(':id/complete')
  @Permissions('inventory.manage')
  @Audit('complete', 'BranchTransfer')
  complete(@GymId() g: string, @Param('id') id: string) { return this.svc.complete(g, id); }

  @Post(':id/cancel')
  @Permissions('inventory.manage')
  @Audit('cancel', 'BranchTransfer')
  cancel(@GymId() g: string, @Param('id') id: string) { return this.svc.cancel(g, id); }
}
