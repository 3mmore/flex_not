/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { TransfersService } from './transfers.service';

@Module({
  imports: [PrismaModule],
  providers: [TransfersService],
  exports: [TransfersService],
})
export class TransfersModule {}
