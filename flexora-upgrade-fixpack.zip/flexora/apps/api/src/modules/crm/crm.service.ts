/**
 * FLEXORA Gym OS — Full CRM (Phase 20)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { Prisma, LeadStatus, LeadSource, LeadPriority, FollowUpType, PipelineStage, DealStatus, TaskStatus, FollowUpOutcome, ActivityType } from '@prisma/client';
import { WaBotService } from '../wa-bot/wa-bot.service';

const TASK_OPEN_STATUS = TaskStatus.TODO;

@Injectable()
export class CrmService {
  private readonly logger = new Logger(CrmService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly waBot: WaBotService,
  ) {}

  listLeads(gymId: string) {
    return this.prisma.lead.findMany({ where: { gymId }, orderBy: { createdAt: 'desc' }, take: 200 });
  }
  createLead(gymId: string, dto: Omit<Prisma.LeadCreateInput, 'gym'>) {
    return this.prisma.lead.create({ data: { ...dto, gym: { connect: { id: gymId } } } });
  }
  async updateLead(gymId: string, id: string, dto: Prisma.LeadUpdateInput) {
    const updated = await this.prisma.lead.update({
      where: { id, gymId },
      data: dto,
    });

    if (dto.status === LeadStatus.TRIAL_COMPLETED) {
      await this.waBot.sendTrialCompletedMessage(gymId, updated);
    }

    return updated;
  }
  addLeadFollowUp(gymId: string, id: string, dto: { type?: FollowUpType; message: string }) {
    return this.prisma.leadFollowUp.create({ data: { gymId, leadId: id, type: dto.type || FollowUpType.CALL, message: dto.message, outcome: FollowUpOutcome.PENDING } });
  }

  listPipelines(gymId: string) {
    return this.prisma.pipeline.findMany({ where: { gymId }, include: { _count: { select: { deals: true } } }, take: 100 });
  }
  async createPipeline(gymId: string, dto: { name: string; description?: string }) {
    const existing = await this.prisma.pipeline.count({ where: { gymId } });
    return this.prisma.pipeline.create({ data: { gymId, name: dto.name, description: dto.description, isDefault: existing === 0 } });
  }

  listDeals(gymId: string, opts: { pipelineId?: string; stage?: PipelineStage; status?: DealStatus } = {}) {
    return this.prisma.deal.findMany({
      where: { gymId, ...(opts.pipelineId ? { pipelineId: opts.pipelineId } : {}), ...(opts.stage ? { stage: opts.stage } : {}), ...(opts.status ? { status: opts.status } : {}) },
      include: { pipeline: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }
  async createDeal(gymId: string, dto: { pipelineId: string; title: string; contactName?: string; contactEmail?: string; contactPhone?: string; amount?: number; currency?: string; ownerId?: string; expectedCloseDate?: Date; notes?: string }) {
    return this.prisma.deal.create({ data: { gymId, stage: PipelineStage.LEAD, status: DealStatus.OPEN, ...dto } });
  }
  async updateDeal(gymId: string, id: string, data: Prisma.DealUpdateInput) {
    await this.getDeal(gymId, id);
    // gymId-safe: id already tenant-scoped above by getDeal
    return this.prisma.deal.update({ where: { id }, data });
  }
  async advanceStage(gymId: string, id: string, stage: PipelineStage) {
    const where = { id, gymId };
    if (stage === PipelineStage.WON) return this.prisma.deal.update({ where, data: { stage, status: DealStatus.WON, closedAt: new Date() } });
    if (stage === PipelineStage.LOST) return this.prisma.deal.update({ where, data: { stage, status: DealStatus.LOST, closedAt: new Date() } });
    return this.prisma.deal.update({ where, data: { stage } });
  }
  async getDeal(gymId: string, id: string) {
    const d = await this.prisma.deal.findFirst({ where: { id, gymId } });
    if (!d) throw new NotFoundException('Deal not found');
    return d;
  }

  async addActivity(gymId: string, dto: { dealId?: string; leadId?: string; type: ActivityType; subject?: string; body?: string; userId?: string }) {
    return this.prisma.activity.create({ data: { gymId, ...dto } });
  }
  listActivities(gymId: string, dealId: string) {
    return this.prisma.activity.findMany({ where: { gymId, dealId }, orderBy: { occurredAt: 'desc' }, take: 200 });
  }

  async addTask(gymId: string, dto: { dealId?: string; leadId?: string; userId?: string; title: string; description?: string; dueAt?: Date }) {
    return this.prisma.task.create({ data: { gymId, status: TASK_OPEN_STATUS, ...dto } });
  }
  async completeTask(gymId: string, id: string) {
    return this.prisma.task.updateMany({ where: { id, gymId }, data: { status: TaskStatus.DONE, completedAt: new Date() } });
  }
  listTasks(gymId: string, opts: { status?: TaskStatus; userId?: string } = {}) {
    return this.prisma.task.findMany({ where: { gymId, ...(opts.status ? { status: opts.status } : {}), ...(opts.userId ? { userId: opts.userId } : {}) }, orderBy: { dueAt: 'asc' }, take: 200 });
  }

  async funnel(gymId: string, pipelineId?: string): Promise<Array<{ stage: string; count: number; totalAmount: number }>> {
    const stages = [PipelineStage.LEAD, PipelineStage.QUALIFIED, PipelineStage.PROPOSAL, PipelineStage.NEGOTIATION, PipelineStage.WON, PipelineStage.LOST];
    const result: Array<{ stage: string; count: number; totalAmount: number }> = [];
    for (const stage of stages) {
      const where: Prisma.DealWhereInput = { gymId, stage, ...(pipelineId ? { pipelineId } : {}) };
      const [count, agg] = await this.prisma.$transaction([
        this.prisma.deal.count({ where }),
        this.prisma.deal.aggregate({ where, _sum: { amount: true } }),
      ]);
      result.push({ stage, count, totalAmount: Number(agg._sum.amount || 0) });
    }
    return result;
  }
}


