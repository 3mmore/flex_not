/**
 * FLEXORA Gym OS — CRM controller (Phase 20)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsArray, IsDateString, IsEmail, IsEnum, IsIn, IsNumber, IsOptional, IsString, IsNotEmpty, Matches } from 'class-validator';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';
import { LeadStatus, LeadSource, LeadPriority, FollowUpType, PipelineStage, DealStatus, TaskStatus, ActivityType } from '@prisma/client';
import { CrmService } from './crm.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';
import { Audit } from '../../common/decorators/audit.decorator';

// P1: CRM leads previously accepted ANY string as mobile/phone (a 10-digit
// number imported live). Both now enforce the shared Egyptian-mobile rule.
class CreateLeadDto { @IsString() @IsNotEmpty() name!: string; @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string; @IsString() @IsNotEmpty() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) mobile!: string; @IsOptional() @IsEmail() email?: string; @IsOptional() @IsEnum(LeadSource) source?: LeadSource; @IsOptional() @IsString() notes?: string; @IsOptional() @IsEnum(LeadStatus) status?: LeadStatus; }
class UpdateLeadDto { @IsOptional() @IsString() name?: string; @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string; @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) mobile?: string; @IsOptional() @IsEmail() email?: string; @IsOptional() @IsEnum(LeadSource) source?: LeadSource; @IsOptional() @IsEnum(LeadStatus) status?: LeadStatus; @IsOptional() @IsString() notes?: string; }
class LeadFollowUpDto { @IsOptional() @IsString() notes?: string; @IsOptional() @IsString() message?: string; @IsOptional() @IsEnum(FollowUpType) type?: FollowUpType; @IsOptional() @IsDateString() scheduledAt?: string; @IsOptional() @IsString() outcome?: string; }

class CreatePipelineDto { @IsString() name!: string; @IsOptional() @IsString() description?: string; }
class CreateDealDto {
  @IsString() pipelineId!: string; @IsString() title!: string;
  @IsOptional() @IsString() contactName?: string; @IsOptional() @IsString() contactEmail?: string;
  @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) contactPhone?: string; @IsOptional() @IsNumber() amount?: number;
  @IsOptional() @IsString() currency?: string; @IsOptional() @IsString() ownerId?: string;
  @IsOptional() expectedCloseDate?: Date; @IsOptional() @IsString() notes?: string;
}
class AddActivityDto {
  @IsOptional() @IsString() dealId?: string; @IsOptional() @IsString() leadId?: string;
  @IsEnum(ActivityType) type!: ActivityType;
  @IsOptional() @IsString() subject?: string; @IsOptional() @IsString() body?: string;
}
class AdvanceDealDto { @IsEnum(PipelineStage) stage!: PipelineStage; }

class AddTaskDto {
  @IsOptional() @IsString() dealId?: string; @IsOptional() @IsString() leadId?: string;
  @IsOptional() @IsString() userId?: string; @IsString() title!: string;
  @IsOptional() @IsString() description?: string; @IsOptional() dueAt?: Date;
}

@ApiTags('crm')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('crm')
@Controller('crm')
export class CrmController {
  constructor(private readonly svc: CrmService) {}

  @Get('leads') @Permissions('members.create')
  leads(@GymId() g: string) { return this.svc.listLeads(g); }

  @Post('leads') @Permissions('members.create') @Audit('create', 'Lead')
  createLead(@GymId() g: string, @Body() dto: CreateLeadDto) { return this.svc.createLead(g, dto); }

  @Post('leads/:id/follow-up') @Permissions('members.create') @Audit('follow_up', 'Lead')
  leadFollowUp(@GymId() g: string, @Param('id') id: string, @Body() dto: LeadFollowUpDto) { return this.svc.addLeadFollowUp(g, id, { ...dto, message: dto.message || dto.notes || '' }); }

  @Patch('leads/:id') @Permissions('members.create') @Audit('update', 'Lead')
  patchLead(@GymId() g: string, @Param('id') id: string, @Body() dto: UpdateLeadDto) { return this.svc.updateLead(g, id, dto); }

  @Post('leads/:id') @Permissions('members.create') @Audit('update', 'Lead')
  patchLeadCompat(@GymId() g: string, @Param('id') id: string, @Body() dto: UpdateLeadDto) { return this.svc.updateLead(g, id, dto); }

  @Get('pipeline') @Permissions('reports.view')
  pipelineAlias(@GymId() g: string) { return this.svc.listPipelines(g); }

  @Get('pipelines') @Permissions('reports.view')
  pipelines(@GymId() g: string) { return this.svc.listPipelines(g); }

  @Post('pipelines') @Permissions('reports.view') @Audit('create', 'Pipeline')
  createPipeline(@GymId() g: string, @Body() dto: CreatePipelineDto) { return this.svc.createPipeline(g, dto); }

  @Get('deals') @Permissions('members.create')
  deals(@GymId() g: string, @Query('pipelineId') pipelineId?: string, @Query('stage') stage?: PipelineStage, @Query('status') status?: DealStatus) {
    return this.svc.listDeals(g, { pipelineId, stage, status });
  }

  @Post('deals') @Permissions('reports.view') @Audit('create', 'Deal')
  createDeal(@GymId() g: string, @Body() dto: CreateDealDto) { return this.svc.createDeal(g, dto); }

  @Post('deals/:id/advance') @Permissions('reports.view') @Audit('advance', 'Deal')
  advance(@GymId() g: string, @Param('id') id: string, @Body() dto: AdvanceDealDto) { return this.svc.advanceStage(g, id, dto.stage); }

  @Post('activities') @Permissions('members.create') @Audit('log', 'Activity')
  addActivity(@GymId() g: string, @Body() dto: AddActivityDto, @CurrentUser('sub') userId: string) { return this.svc.addActivity(g, { ...dto, userId }); }

  @Get('activities/:dealId') @Permissions('reports.view') activities(@GymId() g: string, @Param('dealId') dealId: string) { return this.svc.listActivities(g, dealId); }

  @Post('tasks') @Permissions('reports.view') @Audit('create', 'Task')
  addTask(@GymId() g: string, @Body() dto: AddTaskDto, @CurrentUser('sub') userId: string) { return this.svc.addTask(g, { ...dto, userId }); }

  @Post('tasks/:id/complete') @Permissions('members.create') @Audit('complete', 'Task')
  completeTask(@GymId() g: string, @Param('id') id: string) { return this.svc.completeTask(g, id); }

  @Get('tasks') @Permissions('reports.view') tasks(@GymId() g: string, @Query('status') status?: TaskStatus, @Query('userId') userId?: string) { return this.svc.listTasks(g, { status, userId }); }

  @Get('funnel') @Permissions('reports.view')
  funnel(@GymId() g: string, @Query('pipelineId') pipelineId?: string) { return this.svc.funnel(g, pipelineId); }
}
