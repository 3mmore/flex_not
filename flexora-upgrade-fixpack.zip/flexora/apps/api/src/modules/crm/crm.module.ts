/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { WaBotModule } from '../wa-bot/wa-bot.module';
import { CrmService } from './crm.service';

@Module({ imports: [WaBotModule], providers: [CrmService], exports: [CrmService] })
export class CrmModule {}
