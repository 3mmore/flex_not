/**
 * FLEXORA Gym OS — CRM service tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { CrmService } from './crm.service';
import { PrismaService } from '../../config/prisma.service';

class FakePrisma {
  leads: any[] = [];
  pipelines: any[] = [];
  deals: any[] = [];

  lead = {
    findMany: jest.fn(({ where }: any) => this.leads.filter(l => l.gymId === where.gymId)),
    create: jest.fn(({ data }: any) => {
      const { gym, ...rest } = data;
      const l = { id: 'l' + Math.random(), gymId: gym.connect.id, ...rest };
      this.leads.push(l);
      return l;
    }),
    updateMany: jest.fn(),
  };

  pipeline = {
    findMany: jest.fn(({ where }: any) => this.pipelines.filter(p => p.gymId === where.gymId)),
    count: jest.fn(({ where }: any) => this.pipelines.filter(p => p.gymId === where.gymId).length),
    create: jest.fn(({ data }: any) => {
      const p = { id: 'p' + Math.random(), ...data };
      this.pipelines.push(p);
      return p;
    }),
  };

  deal = {
    findMany: jest.fn(({ where }: any) => this.deals.filter(d => d.gymId === where.gymId)),
    create: jest.fn(({ data }: any) => {
      const d = { id: 'd' + Math.random(), ...data };
      this.deals.push(d);
      return d;
    }),
    update: jest.fn(),
    findFirst: jest.fn(),
  };
  
  task = {
    findMany: jest.fn(),
    create: jest.fn(),
    updateMany: jest.fn(),
  };
  
  activity = {
    create: jest.fn(),
    findMany: jest.fn(),
  };
  
  leadFollowUp = {
    create: jest.fn(),
  };
}

describe('CrmService', () => {
  let svc: CrmService;
  let prisma: FakePrisma;
  let waBot: any;
  beforeEach(() => {
    prisma = new FakePrisma();
    waBot = { sendTrialCompletedMessage: jest.fn() };
    svc = new CrmService(prisma as any, waBot as any);
  });

  it('lists leads for a gym', async () => {
    prisma.leads.push({ id: 'l1', gymId: 'g1', name: 'L1' });
    const list = await svc.listLeads('g1');
    expect(list.length).toBe(1);
  });

  it('creates a new lead', async () => {
    const l = await svc.createLead('g1', { name: 'New Lead', mobile: '01012345678' });
    expect(l.name).toBe('New Lead');
    expect(prisma.leads.length).toBe(1);
  });

  it('lists pipelines', async () => {
    prisma.pipelines.push({ id: 'p1', gymId: 'g1', name: 'Sales' });
    const list = await svc.listPipelines('g1');
    expect(list.length).toBe(1);
  });
});
