/**
 * FLEXORA Gym OS — AI provider abstraction
 * © 2024 Ammar Allam. All rights reserved.
 */
export interface AiProvider {
  name: string;
  enabled: boolean;
  call(systemPrompt: string, userPrompt: string, maxTokens?: number): Promise<string>;
}
