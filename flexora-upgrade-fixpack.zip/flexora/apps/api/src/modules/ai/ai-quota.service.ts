import { Injectable, Logger } from '@nestjs/common';
import { RedisService } from '../../config/redis.service';

@Injectable()
export class AiQuotaService {
  private readonly logger = new Logger('AiQuota');
  private readonly dailyLimit =
    Number(process.env.AI_DAILY_QUOTA) || 100;

  constructor(private readonly redis: RedisService) {}

  async checkAndIncrement(gymId: string): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    const key = `ai:quota:${gymId}:${today}`;
    
    const count = await this.redis.client.incr(key);
    if (count === 1) {
      await this.redis.client.expire(key, 86400);
    }
    
    if (count > this.dailyLimit) {
      this.logger.warn(
        `AI quota exceeded for gym ${gymId}: ${count}/${this.dailyLimit}`
      );
      throw new Error(
        `Daily AI quota exceeded (${this.dailyLimit} requests/day). 
         Resets at midnight.`
      );
    }
  }

  async getUsage(gymId: string): Promise<{ used: number; limit: number; remaining: number }> {
    const today = new Date().toISOString().split('T')[0];
    const key = `ai:quota:${gymId}:${today}`;
    const used = Number(await this.redis.client.get(key)) || 0;
    return {
      used,
      limit: this.dailyLimit,
      remaining: Math.max(0, this.dailyLimit - used),
    };
  }
}
