import { Test } from '@nestjs/testing';
import { AiQuotaService } from './ai-quota.service';
import { RedisService } from '../../config/redis.service';

describe('AiQuotaService', () => {
  let svc: AiQuotaService;
  let store: Map<string, any>;
  let redisMock: any;

  beforeEach(async () => {
    store = new Map();
    redisMock = {
      client: {
        incr: jest.fn(async (key: string) => {
          const v = (store.get(key) || 0) + 1;
          store.set(key, v);
          return v;
        }),
        expire: jest.fn(async () => 1),
        get: jest.fn(async (key: string) => store.get(key)?.toString() ?? null),
      },
    };

    process.env.AI_DAILY_QUOTA = '3';

    const mod = await Test.createTestingModule({
      providers: [
        AiQuotaService,
        { provide: RedisService, useValue: redisMock },
      ],
    }).compile();

    svc = mod.get(AiQuotaService);
    // override private limit for test
    (svc as any).dailyLimit = 3;
  });

  it('increments quota', async () => {
    await svc.checkAndIncrement('gym1');
    const u = await svc.getUsage('gym1');
    expect(u.used).toBe(1);
    expect(u.remaining).toBe(2);
  });

  it('blocks at limit', async () => {
    await svc.checkAndIncrement('gym2');
    await svc.checkAndIncrement('gym2');
    await svc.checkAndIncrement('gym2');
    await expect(svc.checkAndIncrement('gym2')).rejects.toThrow(/quota exceeded/i);
  });

  it('resets next day key', async () => {
    const realDate = Date;
    const mockDate = (iso: string) => {
      global.Date = class extends realDate {
        constructor(...args: any[]) {
          if (args.length === 0) return new realDate(iso) as any;
          return new realDate(...args as any) as any;
        }
        static now() { return new realDate(iso).getTime(); }
      } as any;
    };
    mockDate('2026-06-25T10:00:00Z');
    await svc.checkAndIncrement('gym3');
    let u = await svc.getUsage('gym3');
    expect(u.used).toBe(1);
    mockDate('2026-06-26T10:00:00Z');
    u = await svc.getUsage('gym3');
    expect(u.used).toBe(0);
    global.Date = realDate;
  });
});
