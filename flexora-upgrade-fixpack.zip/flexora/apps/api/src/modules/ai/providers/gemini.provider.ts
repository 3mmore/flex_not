/**
 * FLEXORA Gym OS — Google Gemini AI provider
 * © 2024 Ammar Allam. All rights reserved.
 */
import { AiProvider } from '../ai.provider';

export class GeminiProvider implements AiProvider {
  readonly name = 'gemini';

  get enabled(): boolean {
    return !!process.env.GEMINI_API_KEY;
  }

  async call(systemPrompt: string, userPrompt: string, maxTokens = 1000): Promise<string> {
    if (!this.enabled) return '';
    try {
      // Gemini free tier is rate-limited around 15 requests/minute; caller-side throttles remain in place.
      const apiKey = encodeURIComponent(process.env.GEMINI_API_KEY as string);
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: `${systemPrompt}\n\n${userPrompt}` },
              ],
            },
          ],
          generationConfig: {
            maxOutputTokens: maxTokens,
            temperature: 0.3,
          },
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) return '';
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text: string }[] } }[] };
      return String(data?.candidates?.[0]?.content?.parts?.[0]?.text || '').trim();
    } catch {
      return '';
    }
  }
}
