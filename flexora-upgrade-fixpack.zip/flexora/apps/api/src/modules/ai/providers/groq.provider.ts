/**
 * FLEXORA Gym OS — Groq Llama AI provider
 * © 2024 Ammar Allam. All rights reserved.
 */
import { AiProvider } from '../ai.provider';

export class GroqProvider implements AiProvider {
  readonly name = 'groq';

  get enabled(): boolean {
    return !!process.env.GROQ_API_KEY;
  }

  async call(systemPrompt: string, userPrompt: string, maxTokens = 1000): Promise<string> {
    if (!this.enabled) return '';
    try {
      // Groq free tier is rate-limited around 30 requests/minute and 14400/day; endpoint throttles remain in place.
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.GROQ_API_KEY as string}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama-3.3-70b-versatile',
          max_tokens: maxTokens,
          temperature: 0.3,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) return '';
      const data = (await res.json()) as { choices?: { message?: { content: string } }[] };
      return String(data?.choices?.[0]?.message?.content || '').trim();
    } catch {
      return '';
    }
  }
}
