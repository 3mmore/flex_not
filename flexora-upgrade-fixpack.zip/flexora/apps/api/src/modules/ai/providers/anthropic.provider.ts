/**
 * FLEXORA Gym OS — Anthropic Claude AI provider
 * © 2024 Ammar Allam. All rights reserved.
 */
import { AiProvider } from '../ai.provider';

export class AnthropicProvider implements AiProvider {
  readonly name = 'anthropic';

  get enabled(): boolean {
    return !!process.env.ANTHROPIC_API_KEY;
  }

  async call(systemPrompt: string, userPrompt: string, maxTokens = 1024): Promise<string> {
    if (!this.enabled) return '';
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': process.env.ANTHROPIC_API_KEY as string,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: maxTokens,
          system: systemPrompt,
          messages: [{ role: 'user', content: userPrompt }],
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) return '';
      const data = (await res.json()) as { content?: { text: string }[] };
      const text = Array.isArray(data?.content)
        ? data.content.map((c) => c?.text || '').join('').trim()
        : '';
      return text;
    } catch {
      return '';
    }
  }
}
