/**
 * FLEXORA Gym OS — Per-gym AI assistant configuration (Phase 6.3 / 6.4)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Before this, an AI provider key could only come from a process-wide env var
 * (ANTHROPIC_API_KEY / GEMINI_API_KEY / GROQ_API_KEY). That is fine for the
 * hosted deployment, but a gym owner had nowhere to enter their OWN key: the
 * onboarding "activate AI" step only had an on/off checkbox and a provider
 * dropdown, so switching it on did nothing.
 *
 * Keys are stored per gym in the existing GymSettings key/value table,
 * encrypted at rest with EncryptionService (AES-256-GCM) — never in plaintext,
 * and never returned to the client. The API only ever reports whether a key is
 * configured plus a masked hint (last 4 characters).
 */
import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { EncryptionService } from '../../common/security/encryption.service';

export type AiProviderId = 'anthropic' | 'gemini' | 'groq';

export const AI_PROVIDERS: Array<{
  id: AiProviderId;
  label: string;
  /**
   * Gemini has a genuinely free tier: a gym owner can create a free key at
   * ai.google.dev and paste it here at no cost. Claude/Groq keys are paid or
   * rate-limited developer accounts. A key is always required — "free tier"
   * means the key costs nothing, NOT that no key is needed.
   */
  freeTier: boolean;
  keyUrl: string;
}> = [
  { id: 'gemini', label: 'Gemini (Google)', freeTier: true, keyUrl: 'https://aistudio.google.com/app/apikey' },
  { id: 'anthropic', label: 'Claude (Anthropic)', freeTier: false, keyUrl: 'https://console.anthropic.com/settings/keys' },
  { id: 'groq', label: 'Groq (Llama)', freeTier: false, keyUrl: 'https://console.groq.com/keys' },
];

const KEY_ENABLED = 'ai.enabled';
const KEY_PROVIDER = 'ai.provider';
const KEY_APIKEY = 'ai.apiKey';

const ENV_KEY_BY_PROVIDER: Record<AiProviderId, string> = {
  anthropic: 'ANTHROPIC_API_KEY',
  gemini: 'GEMINI_API_KEY',
  groq: 'GROQ_API_KEY',
};

export interface AiConfigStatus {
  enabled: boolean;
  provider: AiProviderId;
  /** true when THIS gym saved its own key */
  hasOwnKey: boolean;
  /** masked tail of the gym's own key, e.g. "••••ab12" */
  keyHint: string | null;
  /** true when the server-wide env var supplies a key for this provider */
  serverKeyAvailable: boolean;
  /** the assistant can actually answer right now */
  active: boolean;
  providers: typeof AI_PROVIDERS;
}

@Injectable()
export class AiConfigService {
  private readonly logger = new Logger('AiConfigService');

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  private normalizeProvider(v: string | undefined | null): AiProviderId {
    return AI_PROVIDERS.some((p) => p.id === v) ? (v as AiProviderId) : 'gemini';
  }

  private async readAll(gymId: string): Promise<Record<string, string>> {
    const rows = await this.prisma.gymSettings.findMany({
      where: { gymId, key: { in: [KEY_ENABLED, KEY_PROVIDER, KEY_APIKEY] } },
    });
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  }

  private async write(gymId: string, key: string, value: string) {
    await this.prisma.gymSettings.upsert({
      where: { gymId_key: { gymId, key } },
      update: { value },
      create: { gymId, key, value },
    });
  }

  /** Never returns the key itself — only whether one exists and a masked hint. */
  async getStatus(gymId: string): Promise<AiConfigStatus> {
    const s = await this.readAll(gymId);
    const provider = this.normalizeProvider(s[KEY_PROVIDER]);
    const enabled = s[KEY_ENABLED] === 'true';
    let hasOwnKey = false;
    let keyHint: string | null = null;
    if (s[KEY_APIKEY]) {
      try {
        const plain = this.encryption.decrypt(s[KEY_APIKEY]);
        hasOwnKey = plain.length > 0;
        keyHint = plain.length > 4 ? `••••${plain.slice(-4)}` : '••••';
      } catch {
        this.logger.warn(`Stored AI key for gym ${gymId} could not be decrypted`);
      }
    }
    const serverKeyAvailable = !!process.env[ENV_KEY_BY_PROVIDER[provider]];
    return {
      enabled,
      provider,
      hasOwnKey,
      keyHint,
      serverKeyAvailable,
      active: enabled && (hasOwnKey || serverKeyAvailable),
      providers: AI_PROVIDERS,
    };
  }

  /**
   * Save config. `apiKey` semantics:
   *   undefined → leave the stored key untouched
   *   ''        → delete the stored key
   *   value     → encrypt and store
   */
  async save(
    gymId: string,
    dto: { enabled?: boolean; provider?: string; apiKey?: string },
  ): Promise<AiConfigStatus> {
    if (dto.enabled !== undefined) await this.write(gymId, KEY_ENABLED, dto.enabled ? 'true' : 'false');
    if (dto.provider !== undefined) await this.write(gymId, KEY_PROVIDER, this.normalizeProvider(dto.provider));
    if (dto.apiKey !== undefined) {
      const trimmed = dto.apiKey.trim();
      if (!trimmed) {
        await this.prisma.gymSettings.deleteMany({ where: { gymId, key: KEY_APIKEY } });
      } else {
        await this.write(gymId, KEY_APIKEY, this.encryption.encrypt(trimmed));
      }
    }
    return this.getStatus(gymId);
  }

  /** Resolve the key the AI runtime should use for this gym (own key wins). */
  async resolveKey(gymId: string): Promise<{ provider: AiProviderId; apiKey: string | null; enabled: boolean }> {
    const s = await this.readAll(gymId);
    const provider = this.normalizeProvider(s[KEY_PROVIDER]);
    const enabled = s[KEY_ENABLED] === 'true';
    let apiKey: string | null = null;
    if (s[KEY_APIKEY]) {
      try { apiKey = this.encryption.decrypt(s[KEY_APIKEY]) || null; } catch { apiKey = null; }
    }
    if (!apiKey) apiKey = process.env[ENV_KEY_BY_PROVIDER[provider]] || null;
    return { provider, apiKey, enabled };
  }
}
