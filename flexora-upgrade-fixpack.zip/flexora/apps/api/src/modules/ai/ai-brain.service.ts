/**
 * FLEXORA Gym OS — Intelligence Layer (AI Brain)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { GroqProvider } from './providers/groq.provider';
import { GeminiProvider } from './providers/gemini.provider';
import { AnthropicProvider } from './providers/anthropic.provider';
import { InvoiceStatus, NotifyStatus } from '@prisma/client';

export type AiRole = 'analyst' | 'sales_coach' | 'marketing' | 'backup_assistant' | 'member_support' | 'churn_predictor';

export interface AiBrainContext {
  totalMembers: number;
  activeMembers: number;
  revenueCurrentMonth: number;
  revenueLastMonth: number;
  expiringSoon: { name: string; phone: string }[];
  attendanceRateThisWeek: number;
  attendanceRateLastWeek: number;
  topClasses: { name: string; bookings: number }[];
  pendingRenewals: number;
  unpaidInvoices: number;
  gymName: string;
}

@Injectable()
export class AiBrainService {
  private readonly logger = new Logger('AiBrain');

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly cronLeadership: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private redactName(name: string): string {
    const first = name.trim().split(/\s+/)[0] || 'Member';
    return `${first.slice(0, 1)}***`;
  }

  async buildGymContext(gymId: string): Promise<AiBrainContext> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    
    const startOfThisWeek = new Date(now);
    startOfThisWeek.setDate(now.getDate() - now.getDay());
    const startOfLastWeek = new Date(startOfThisWeek);
    startOfLastWeek.setDate(startOfThisWeek.getDate() - 7);

    const in7Days = new Date(now);
    in7Days.setDate(now.getDate() + 7);

    const [
      gym,
      totalMembers,
      activeMembers,
      revCurrent,
      revLast,
      expiring,
      attThisWeek,
      attLastWeek,
      topClasses,
      pendingRenewals,
      unpaidInvoices
    ] = await Promise.all([
      this.prisma.gym.findUnique({ where: { id: gymId } }),
      this.prisma.member.count({ where: { gymId } }),
      this.prisma.member.count({ where: { gymId, frozen: false, status: 'ACTIVE' } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: startOfMonth } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: startOfLastMonth, lte: endOfLastMonth } }, _sum: { amount: true } }),
      this.prisma.member.findMany({ where: { gymId, expiry: { gte: now, lte: in7Days } }, select: { name: true, mobile: true }, take: 10 }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: startOfThisWeek } } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: startOfLastWeek, lt: startOfThisWeek } } }),
      this.prisma.classBooking.groupBy({ by: ['sessionId'], where: { gymId, createdAt: { gte: startOfThisWeek } }, _count: { id: true }, orderBy: { _count: { id: 'desc' } }, take: 3 }),
      this.prisma.notification.count({ where: { gymId, subject: { contains: 'تجديد' }, status: NotifyStatus.PENDING } }),
      this.prisma.invoice.count({ where: { gymId, status: InvoiceStatus.PENDING } }),
    ]);

    // Fetch class names for top classes
    const classSessions = await this.prisma.classSession.findMany({
      where: { id: { in: topClasses.map(c => c.sessionId) } },
      include: { template: { select: { name: true } } },
      take: 50,
    });

    return {
      gymName: gym?.name || 'Flexora Gym',
      totalMembers,
      activeMembers,
      revenueCurrentMonth: Number(revCurrent._sum.amount || 0),
      revenueLastMonth: Number(revLast._sum.amount || 0),
      expiringSoon: expiring.map((m) => ({ name: this.redactName(m.name), phone: '[REDACTED]' })),
      attendanceRateThisWeek: attThisWeek,
      attendanceRateLastWeek: attLastWeek,
      topClasses: topClasses.map(c => ({
        name: classSessions.find(s => s.id === c.sessionId)?.template.name || 'Unknown Class',
        bookings: c._count.id
      })),
      pendingRenewals,
      unpaidInvoices
    };
  }

  async chat(prompt: string, gymId: string | null, role: AiRole = 'analyst', memberContext?: unknown): Promise<string> {
    // For platform-level calls (gymId=null), skip gym-specific context
    const context = gymId ? await this.buildGymContext(gymId) : null;
    const systemPrompt = this.getSystemPrompt(role, context, memberContext);
    
    const providers = [
      { name: 'Groq', provider: new GroqProvider() },
      { name: 'Gemini', provider: new GeminiProvider() },
      { name: 'Anthropic', provider: new AnthropicProvider() },
    ];

    for (const p of providers) {
      if (!p.provider.enabled) continue;
      
      try {
        const response = await Promise.race([
          p.provider.call(systemPrompt, prompt, 1024),
          new Promise<string>((_, reject) => setTimeout(() => reject(new Error('Timeout')), 10000))
        ]);
        if (response) return response;
      } catch (e: unknown) {
        this.logger.warn(`AI Provider ${p.name} failed: ${(e as Error).message}`);
      }
    }

    return 'عذراً، نظام الذكاء الاصطناعي غير متاح حالياً. يرجى المحاولة لاحقاً أو التواصل مع الدعم الفني.';
  }

  private getSystemPrompt(role: AiRole, context: AiBrainContext | null, memberContext?: unknown): string {
    const ctxStr = context ? JSON.stringify(context) : '{}';
    const memberStr = memberContext ? JSON.stringify(memberContext) : '';

    switch (role) {
      case 'analyst':
        return `أنت محلل بيانات متخصص في إدارة الصالات الرياضية. لديك البيانات التالية: ${ctxStr}. قدم تحليلاً دقيقاً وتوصيات عملية قابلة للتنفيذ.`;
      case 'sales_coach':
        return `أنت مدرب مبيعات محترف${context ? ` لصالة ${context.gymName}` : ' لمنصة الصالات الرياضية'}. مهمتك مساعدة موظفي الاستقبال على إغلاق الاشتراكات. البيانات الحالية: ${ctxStr}. قدم نصائح مباشرة وعملية للتعامل مع العميل الحالي.`;
      case 'marketing':
        return `أنت خبير تسويق رياضي. بناءً على البيانات: ${ctxStr}. اقترح حملات تسويقية محددة مع نصوص الرسائل جاهزة للإرسال عبر واتساب أو SMS.`;
      case 'churn_predictor':
        return `أنت متخصص في تحليل سلوك عملاء الصالات الرياضية. البيانات: ${ctxStr}. حدد الأعضاء الأكثر عرضة للإلغاء واقترح عرضاً مخصصاً لكل منهم.`;
      case 'member_support':
        return `أنت مساعد ذكي${context ? ` لجيم ${context.gymName}` : ' لمنصة إدارة الصالات الرياضية'}. معك بيانات العضو: ${memberStr}. رد باختصار وبالعربي. إذا كان السؤال خارج نطاق الجيم، اطلب منه التواصل مع الاستقبال.`;
      case 'backup_assistant':
        return `أنت مساعد متخصص في نظام النسخ الاحتياطي لـ Flexora. ساعد صاحب الصالة في فهم ملفات الباك أب واسترجاع البيانات. كن واضحاً وودوداً. رد بنفس لغة المستخدم.`;
      default:
        return 'You are a helpful gym management assistant.';
    }
  }

  async churnAnalysis(gymId: string) {
    const context = await this.buildGymContext(gymId);
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    const thirtyDaysAhead = new Date();
    thirtyDaysAhead.setDate(thirtyDaysAhead.getDate() + 30);

    const members = await this.prisma.member.findMany({
      where: {
        gymId,
        frozen: false,
        expiry: { lte: thirtyDaysAhead },
      },
      include: {
        plan: true,
        attendances: { where: { at: { gte: twoWeeksAgo } } },
        sales: { orderBy: { createdAt: 'desc' }, take: 10 },
      },
      take: 200,
    });

    const atRisk = members.filter(m => m.attendances.length < 2).map(m => ({
      name: this.redactName(m.name),
      plan: m.plan.name,
      lastVisit: m.lastVisit,
      sessionsThisMonth: m.attendances.length,
      expiryDate: m.expiry,
      totalSpent: m.sales.reduce((sum, s) => sum + Number(s.total), 0),
    }));

    const aiRecommendations = await this.chat(
      `حلل قائمة الأعضاء الأكثر عرضة للإلغاء وقدم توصية لكل واحد منهم بناءً على تاريخهم: ${JSON.stringify(atRisk)}`,
      gymId,
      'churn_predictor'
    );

    return { atRiskMembers: atRisk, aiRecommendations };
  }

  async generateCampaign(gymId: string, target: 'expiring'|'inactive'|'new'|'all') {
    const now = new Date();
    let members: { name: string; mobile: string }[] = [];
    
    if (target === 'expiring') {
      const next14 = new Date(); next14.setDate(now.getDate() + 14);
      members = await this.prisma.member.findMany({ where: { gymId, expiry: { gte: now, lte: next14 } }, select: { name: true, mobile: true }, take: 500 });
    } else if (target === 'inactive') {
      const monthAgo = new Date(); monthAgo.setDate(now.getDate() - 30);
      members = await this.prisma.member.findMany({ where: { gymId, lastVisit: { lt: monthAgo } }, select: { name: true, mobile: true }, take: 500 });
    } else if (target === 'new') {
      const weekAgo = new Date(); weekAgo.setDate(now.getDate() - 7);
      members = await this.prisma.member.findMany({ where: { gymId, createdAt: { gte: weekAgo } }, select: { name: true, mobile: true }, take: 500 });
    } else {
      members = await this.prisma.member.findMany({ where: { gymId }, select: { name: true, mobile: true }, take: 100 });
    }

    const message = await this.chat(
      `اقترح نص حملة تسويقية تستهدف الفئة: ${target}. عدد المستهدفين: ${members.length}`,
      gymId,
      'marketing'
    );

    return { 
      message, 
      targetCount: members.length, 
      suggestedSendTime: '9:00 AM Tomorrow' 
    };
  }

  @Cron('0 9 * * 1')
  async weeklyInsightsTask() {
    return requestContext.run({ requestId: 'cron:ai-weekly' }, async () => {
      if (!(await this.cronLeadership.acquireLock('ai-brain-weekly', 3600_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({ where: { status: 'ACTIVE' }, take: 500 });
        for (const gym of gyms) {
          try {
            await this.tenantContext.run(gym.id, () => this.generateAndSaveWeeklyInsight(gym.id));
            // Optional: Send via WhatsApp if configured
          } catch (e: unknown) {
            this.logger.error(`Weekly insight failed for ${gym.id}: ${(e as Error).message}`);
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('ai-brain-weekly');
      }
    });
  }

  async generateAndSaveWeeklyInsight(gymId: string) {
    const content = await this.chat("قدم تقرير أسبوعي موجز لأداء الصالة مع 3 توصيات محددة لهذا الأسبوع.", gymId, 'analyst');
    
    const weekOf = new Date();
    weekOf.setDate(weekOf.getDate() - weekOf.getDay() + 1); // Monday
    weekOf.setHours(0, 0, 0, 0);

    return this.prisma.aiInsight.create({
      data: {
        gymId,
        kind: 'WEEKLY_SUMMARY',
        payload: { content, weekOf: weekOf.toISOString() },
        expiresAt: new Date(Date.now() + 14 * 86400000), // 2 weeks
      }
    });
  }

  async getInsights(gymId: string) {
    return this.prisma.aiInsight.findMany({
      where: { gymId, kind: 'WEEKLY_SUMMARY' },
      orderBy: { computedAt: 'desc' },
      take: 8
    });
  }
}
