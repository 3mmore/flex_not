/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger, Optional } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { AiProvider } from './ai.provider';
import { AnthropicProvider } from './providers/anthropic.provider';
import { GeminiProvider } from './providers/gemini.provider';
import { GroqProvider } from './providers/groq.provider';
import { CAMPAIGN_SYSTEM_PROMPT, MAIN_SYSTEM_PROMPT, RETENTION_SYSTEM_PROMPT, REVENUE_SYSTEM_PROMPT } from './ai.system-prompts';
import { AiOfflineService } from './ai-offline.service';
import { AiQuotaService } from './ai-quota.service';

export interface AiDisabled {
  aiEnabled: false;
  message: string;
}

interface MemberLite {
  id: string;
  name: string;
  mobile: string | null;
  vip: boolean;
  visits: number;
  sessionsLeft: number | null;
  startDate: Date;
  lastVisit: Date | null;
  expiry: Date | null;
  plan: { type: 'SESSION' | 'TIME'; name: string } | null;
}

type Risk = 'HIGH' | 'MEDIUM' | 'LOW';

@Injectable()
export class AiService {
  private readonly logger = new Logger('AiService');

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly offline?: AiOfflineService,
    @Optional() private readonly quota?: AiQuotaService,
  ) {}

  private get offlineSvc(): AiOfflineService {
    return this.offline ?? new AiOfflineService(this.prisma);
  }

  private getProvider(): AiProvider | null {
    const provider = process.env.AI_PROVIDER || 'anthropic';
    const providers: Record<string, AiProvider> = {
      anthropic: new AnthropicProvider(),
      gemini: new GeminiProvider(),
      groq: new GroqProvider(),
    };
    const selected = providers[provider] || providers.anthropic;
    if (!selected.enabled) {
      this.logger.warn(`AI provider "${provider}" selected but API key is missing. AI is disabled.`);
      return null;
    }
    return selected;
  }


  private providerSource(): 'claude' | 'gemini' | 'groq' | 'heuristic' {
    const provider = this.getProvider();
    if (!provider) return 'heuristic';
    if (provider.name === 'gemini') return 'gemini';
    if (provider.name === 'groq') return 'groq';
    return 'claude';
  }

  private get enabled(): boolean {
    if (process.env.AI_ENABLED !== 'true') return false;
    const provider = this.getProvider();
    return provider !== null;
  }

  private disabled(): AiDisabled {
    const provider = process.env.AI_PROVIDER || 'anthropic';
    return {
      aiEnabled: false,
      message: `Configure ANTHROPIC_API_KEY or API key for selected AI provider (${provider}) to enable AI insights`,
    };
  }

  providerStatus() {
    const selected = process.env.AI_PROVIDER || 'anthropic';
    const normalized = ['anthropic', 'gemini', 'groq'].includes(selected) ? selected : 'anthropic';
    const keys: Record<string, boolean> = {
      anthropic: !!process.env.ANTHROPIC_API_KEY,
      gemini: !!process.env.GEMINI_API_KEY,
      groq: !!process.env.GROQ_API_KEY,
    };
    return {
      selected: normalized,
      requested: selected,
      active: process.env.AI_ENABLED === 'true' && keys[normalized],
      aiEnabled: process.env.AI_ENABLED === 'true',
      providers: [
        { id: 'anthropic', label: 'Claude (Anthropic)', requiresApiKey: true, configured: keys.anthropic },
        { id: 'gemini', label: 'Gemini (Google)', requiresApiKey: true, configured: keys.gemini },
        { id: 'groq', label: 'Groq (Llama)', requiresApiKey: true, configured: keys.groq },
      ],
    };
  }

  /** cache-aside helper — falls through to fn() if Redis is unavailable. */
  private async cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    try {
      const hit = await this.redis.get(key);
      if (hit) return JSON.parse(hit) as T;
    } catch { /* redis down — ignore */ }
    const fresh = await fn();
    try { await this.redis.set(key, JSON.stringify(fresh), ttl); } catch { /* ignore */ }
    return fresh;
  }

  /** Low-level Claude call. Never throws — returns '' on any failure. */
  async callClaude(systemPrompt: string, userPrompt: string, maxTokens = 1024): Promise<string | null> {
    const answer = await this.ask(systemPrompt, userPrompt, maxTokens);
    return answer || null;
  }

  private async ask(systemPrompt: string, userPrompt: string, maxTokens = 1024): Promise<string> {
    const provider = this.getProvider();
    if (!provider) return '';
    try {
      return await provider.call(systemPrompt, userPrompt, maxTokens);
    } catch (e: unknown) {
      this.logger.error(`AI call failed (${provider.name}): ${(e as Error).message}`);
      return '';
    }
  }

  private days(from: Date | null, to = new Date()): number | null {
    if (!from) return null;
    return Math.round((+to - +new Date(from)) / 86400000);
  }

  /** SECURITY: redact a phone number to its last 4 digits before any PII
   *  leaves the tenant boundary for a third-party LLM. */
  private redactMobile(mobile: string | null): string | null {
    if (!mobile) return null;
    const digits = mobile.replace(/\D/g, '');
    if (digits.length <= 4) return '****';
    return `****${digits.slice(-4)}`;
  }

  /** HIGH FIX 2 — Redact full names (PII) before sending to third-party LLMs */
  private redactName(name: string | null): string {
    if (!name) return 'Member';
    const parts = name.trim().split(' ');
    // Keep first name only, mask surname
    return parts[0] + (parts.length > 1 
      ? ' ' + '*'.repeat(parts[parts.length - 1].length) 
      : '');
  }

  // ===========================================================================
  // Endpoint 1 — Churn risk
  // ===========================================================================
  async churnRisk(gymId: string, limit = 50, offset = 0) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const now = new Date();
    const memberRows = await this.prisma.member.findMany({
      where: { gymId, frozen: false },
      select: {
        id: true, name: true, mobile: true, vip: true, visits: true,
        sessionsLeft: true, startDate: true, lastVisit: true, expiry: true,
        plan: { select: { type: true, name: true } },
      },
      take: 1000,
    });
    const members: MemberLite[] = memberRows.map((m) => ({
      id: m.id, name: this.redactName(m.name), mobile: this.redactMobile(m.mobile), vip: m.vip, visits: m.visits,
      sessionsLeft: m.sessionsLeft, startDate: m.startDate, lastVisit: m.lastVisit, expiry: m.expiry,
      plan: m.plan ? { type: m.plan.type, name: m.plan.name } : null,
    }));

    const scored = members.map((m) => {
      const daysSinceLastVisit = this.days(m.lastVisit) ?? 999;
      const daysUntilExpiry = m.expiry ? this.days(now, m.expiry) : null;
      const tenure = Math.max(1, this.days(m.startDate) ?? 1);
      const visitFrequency = (m.visits || 0) / tenure;

      let risk: Risk = 'LOW';
      if (
        daysSinceLastVisit > 14 ||
        (daysUntilExpiry !== null && daysUntilExpiry >= 0 && daysUntilExpiry <= 7 && visitFrequency < 0.3)
      ) {
        risk = 'HIGH';
      } else if (
        (daysSinceLastVisit >= 7 && daysSinceLastVisit <= 14) ||
        (m.sessionsLeft !== null && m.sessionsLeft <= 2)
      ) {
        risk = 'MEDIUM';
      }
      return {
        id: m.id, name: this.redactName(m.name), mobile: this.redactMobile(m.mobile), vip: m.vip,
        plan: m.plan?.name ?? null, sessionsLeft: m.sessionsLeft,
        risk, daysSinceLastVisit, daysUntilExpiry, visitFrequency: +visitFrequency.toFixed(2),
      };
    });

    const high = scored.filter((s) => s.risk === 'HIGH');
    const medium = scored.filter((s) => s.risk === 'MEDIUM');
    const low = scored.filter((s) => s.risk === 'LOW');

    // Per-member AI re-engagement messages for the top 10 high-risk members.
    let aiMessages: Record<string, string> = {};
    if (this.enabled && high.length) {
      const top = high.slice(0, 10);
      const prompt =
        `هؤلاء أعضاء معرضون لخطر التسرب من الجيم. اكتب لكل عضو رسالة واتساب قصيرة (سطر واحد) ` +
        `ودودة بالعربية لإعادة تفعيله. أعد الإجابة بصيغة JSON فقط: ` +
        `{"<id>":"<رسالة>"} بدون أي نص إضافي.\n\n` +
        JSON.stringify(top.map((t) => ({
          id: t.id, name: this.redactName(t.name), daysSinceLastVisit: t.daysSinceLastVisit,
          plan: t.plan, sessionsLeft: t.sessionsLeft,
        })));
      const raw = await this.ask(MAIN_SYSTEM_PROMPT, prompt);
      aiMessages = this.safeJson<Record<string, string>>(raw) ?? {};
    }

    const decorate = (s: { id: string; name: string; mobile: string; vip: boolean; plan: string | null; sessionsLeft: number | null; risk: Risk; daysSinceLastVisit: number; daysUntilExpiry: number | null; visitFrequency: number }) => ({
      ...s,
      aiMessage:
        aiMessages[s.id] ||
        `مرحباً ${s.name}، اشتقنالك في الجيم! تعالَ كمّل تمرينك ولو سؤال احنا في خدمتك.`,
    });

    const pagedHigh = high.slice(offset, offset + limit).map(decorate);
    return {
      aiEnabled: this.enabled,
      summary: { high: high.length, medium: medium.length, low: low.length },
      total: high.length,
      limit,
      offset,
      highRisk: pagedHigh,
      mediumRisk: medium.slice(0, limit).map((s) => ({ ...s, aiMessage: null })),
      source: this.providerSource(),
      confidence: 'high',
    };
  }

  // ===========================================================================
  // Endpoint 2 — Revenue forecast
  // ===========================================================================
  revenueForecast(gymId: string) {
    if (!this.enabled) return this.offlineSvc.revenueForecastOffline(gymId);
    return this.cached(`ai:revenue-forecast:${gymId}`, 600, () => this.computeRevenueForecast(gymId));
  }
  private async computeRevenueForecast(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const since = new Date();
    since.setMonth(since.getMonth() - 6);
    since.setDate(1);
    since.setHours(0, 0, 0, 0);

    const txns = await this.prisma.transaction.findMany({
      where: { gymId, type: 'INCOME', createdAt: { gte: since } },
      select: { amount: true, createdAt: true },
    });
    const byMonth: Record<string, number> = {};
    for (const t of txns) {
      const k = t.createdAt.toISOString().slice(0, 7);
      byMonth[k] = (byMonth[k] || 0) + Number(t.amount);
    }
    const historicalMonths = Object.entries(byMonth)
      .sort()
      .map(([month, value]) => ({ month, value: Math.round(value) }));

    const growth: number[] = [];
    for (let i = 1; i < historicalMonths.length; i++) {
      const prev = historicalMonths[i - 1].value || 1;
      growth.push(+(((historicalMonths[i].value - prev) / prev) * 100).toFixed(1));
    }

    const now = new Date();
    const next30 = new Date(now); next30.setDate(now.getDate() + 30);
    const [activeCount, upcomingExpiries, topPlans] = await this.prisma.$transaction([
      this.prisma.member.count({ where: { gymId, frozen: false } }),
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: now, lte: next30 } } }),
      this.prisma.member.groupBy({
        by: ['planId'], where: { gymId }, _count: { planId: true },
        orderBy: { _count: { planId: 'desc' } }, take: 3,
      }),
    ]);
    const topPlanRows = topPlans as Array<{ planId: string | null; _count: { planId: number } }>;
    const planNames = await this.prisma.plan.findMany({
      where: { gymId, id: { in: topPlanRows.map((p) => p.planId).filter(Boolean) as string[] } },
      select: { id: true, name: true },
    });
    const top3 = topPlanRows.map((p) => ({
      plan: planNames.find((n) => n.id === p.planId)?.name ?? 'Unknown',
      members: p._count.planId,
    }));

    // Local statistical baseline (works even when AI is off).
    const last = historicalMonths.at(-1)?.value ?? 0;
    const avgGrowth = growth.length ? growth.reduce((a, b) => a + b, 0) / growth.length : 0;
    const projected = Math.round(last * (1 + avgGrowth / 100));
    const expectedMin = Math.round(projected * 0.9);
    const expectedMax = Math.round(projected * 1.12);

    let rawAiInsight = '';
    let mainDriver = top3[0]?.plan ?? 'Membership renewals';
    let recommendation = 'Target upcoming expiries with renewal offers this week.';
    if (this.enabled) {
      const prompt =
        `Forecast next month's gym revenue.\n` +
        `Monthly revenue (EGP): ${JSON.stringify(historicalMonths)}\n` +
        `MoM growth %: ${JSON.stringify(growth)}\n` +
        `Active members: ${activeCount}\n` +
        `Expiries next 30 days: ${upcomingExpiries}\n` +
        `Top plans: ${JSON.stringify(top3)}\n` +
        `Give: expected range, the main revenue driver, and ONE concrete action.`;
      rawAiInsight = await this.ask(MAIN_SYSTEM_PROMPT, prompt);
    }

    return {
      aiEnabled: this.enabled,
      historicalMonths,
      forecast: {
        expectedMin, expectedMax,
        confidence: historicalMonths.length >= 4 ? 'medium' : 'low',
        mainDriver, recommendation,
      },
      rawAiInsight,
      source: rawAiInsight ? this.providerSource() : 'heuristic',
      confidence: rawAiInsight ? 'high' : 'medium',
    };
  }

  // ===========================================================================
  // Endpoint 3 — Product intelligence
  // ===========================================================================
  productInsights(gymId: string) {
    if (!this.enabled) return this.offlineSvc.productInsightsOffline(gymId);
    return this.cached(`ai:product-insights:${gymId}`, 300, () => this.computeProductInsights(gymId));
  }
  private async computeProductInsights(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const products = await this.prisma.product.findMany({ where: { gymId }, take: 200 });
    const since = new Date(); since.setDate(since.getDate() - 30);
    const items = await this.prisma.saleItem.findMany({
      where: { sale: { gymId, createdAt: { gte: since } } },
      select: { productId: true, qty: true, price: true },
    });
    const sold: Record<string, { units: number; revenue: number }> = {};
    for (const it of items) {
      if (!it.productId) continue;
      sold[it.productId] = sold[it.productId] || { units: 0, revenue: 0 };
      sold[it.productId].units += it.qty;
      sold[it.productId].revenue += Number(it.price) * it.qty;
    }

    const enriched = products.map((p) => {
      const s = sold[p.id] || { units: 0, revenue: 0 };
      const price = Number(p.sellingPrice);
      const cost = Number(p.costPrice);
      const profitMargin = price > 0 ? +(((price - cost) / price)).toFixed(2) : 0;
      const velocityPerDay = +(s.units / 30).toFixed(2);
      const daysOfStock = velocityPerDay > 0 ? Math.round(p.qty / velocityPerDay) : null;
      return {
        id: p.id, name: p.name, category: p.category, qty: p.qty, lowStockThreshold: p.lowStockThreshold,
        price, cost, profitMargin, unitsSold: s.units, revenue: Math.round(s.revenue),
        profitContribution: Math.round((price - cost) * s.units),
        velocityPerDay, daysOfStock,
      };
    });

    const topProducts = [...enriched]
      .sort((a, b) => b.profitContribution - a.profitContribution).slice(0, 3);
    const stockAlerts = enriched.filter(
      (p) => p.daysOfStock !== null && p.daysOfStock < 14 && p.velocityPerDay >= 0.5,
    );

    let aiRecommendations = {
      promoteThis: { productName: '', reason: '' },
      discontinueThis: { productName: '', reason: '' },
      insight: '',
    };
    if (this.enabled && enriched.length) {
      const prompt =
        `Analyze this gym shop inventory (last 30 days). For each: margin, units sold, ` +
        `velocity/day, days of stock.\n${JSON.stringify(enriched)}\n` +
        `Return JSON ONLY: {"promoteThis":{"productName":"","reason":""},` +
        `"discontinueThis":{"productName":"","reason":""},"insight":""}. ` +
        `promoteThis = high margin + medium velocity (upside). ` +
        `discontinueThis = low margin + low velocity.`;
      const raw = await this.ask(MAIN_SYSTEM_PROMPT, prompt);
      const parsed = this.safeJson<typeof aiRecommendations>(raw);
      if (parsed) aiRecommendations = parsed;
    }

    return { aiEnabled: this.enabled, topProducts, stockAlerts, aiRecommendations, source: aiRecommendations.insight ? this.providerSource() : 'heuristic', confidence: aiRecommendations.insight ? 'high' : 'medium' };
  }

  // ===========================================================================
  // Endpoint 4 — Daily briefing
  // ===========================================================================
  dailyBriefing(gymId: string, dashboard: { checkinsToday: number; revenueToday: number; activeMembers: number }) {
    if (!this.enabled) return this.offlineSvc.dailyBriefingOffline(gymId, dashboard);
    return this.cached(`ai:daily-briefing:${gymId}`, 300, () => this.computeDailyBriefing(gymId, dashboard));
  }
  private async computeDailyBriefing(gymId: string, dashboard: { checkinsToday: number; revenueToday: number; activeMembers: number }) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const yStart = new Date(start); yStart.setDate(yStart.getDate() - 1);
    const now = new Date();
    const in7 = new Date(now); in7.setDate(now.getDate() + 7);

    const dayEnd = new Date(start); dayEnd.setDate(dayEnd.getDate() + 1);
    const weekStart = new Date(start); weekStart.setDate(weekStart.getDate() - start.getDay());

    const [yIncome, yCheckins, expiring, lowStockProducts, pending, ptSessionsToday, classBookingsToday, ptWeek] =
      await this.prisma.$transaction([
        this.prisma.transaction.aggregate({
          where: { gymId, type: 'INCOME', createdAt: { gte: yStart, lt: start } },
          _sum: { amount: true },
        }),
        this.prisma.attendance.count({ where: { gymId, at: { gte: yStart, lt: start } } }),
        this.prisma.member.findMany({
          where: { gymId, frozen: false, expiry: { gte: now, lte: in7 } },
          select: { name: true, expiry: true }, take: 25,
        }),
        this.prisma.product.findMany({ where: { gymId }, select: { name: true, qty: true, lowStockThreshold: true }, take: 200 }),
        this.prisma.notification.count({ where: { gymId, status: 'PENDING' } }),
        this.prisma.ptSession.count({ where: { gymId, scheduledAt: { gte: start, lt: dayEnd } } }),
        this.prisma.classBooking.count({ where: { gymId, status: 'CONFIRMED', session: { startsAt: { gte: start, lt: dayEnd } } } }),
        this.prisma.ptSession.groupBy({ by: ['coachId'], where: { gymId, scheduledAt: { gte: weekStart } }, _count: { coachId: true }, orderBy: { coachId: 'asc' } }),
      ]);

    const ptWeekRows = ptWeek as Array<{ coachId: string; _count: { coachId: number } }>;
    const coachNames = await this.prisma.user.findMany({
      where: { gymId, id: { in: ptWeekRows.map((r) => r.coachId) } },
      select: { id: true, name: true },
    });
    const coachUtilization = ptWeekRows.map((r) => ({
      coachName: coachNames.find((c) => c.id === r.coachId)?.name ?? 'Unknown',
      sessionCount: r._count.coachId,
    }));

    // Top upsell target: most-frequent member on a monthly plan, 60+ days tenured.
    const sixtyAgo = new Date(now.getTime() - 60 * 86400000);
    const upsellPool = await this.prisma.member.findMany({
      where: { gymId, frozen: false, plan: { type: 'TIME' }, startDate: { lte: sixtyAgo }, expiry: { gte: now } },
      select: { name: true, visits: true, startDate: true },
      take: 200,
    });
    let topUpsell: { name: string; reason: string } | null = null;
    if (upsellPool.length) {
      const best = upsellPool
        .map((m) => ({ name: this.redactName(m.name), freq: (m.visits || 0) / Math.max(1, Math.round((+now - +new Date(m.startDate)) / 86400000)) }))
        .sort((a, b) => b.freq - a.freq)[0];
      if (best && best.freq > 0.5) {
        topUpsell = { name: best.name, reason: `عضو منتظم (${best.freq.toFixed(2)} زيارة/يوم) على باقة شهرية — مرشّح للترقية لباقة أطول.` };
      }
    }

    const lowStock = lowStockProducts.filter((p) => p.qty <= p.lowStockThreshold);
    const yRevenue = Number(yIncome._sum.amount || 0);
    const pct = (a: number, b: number) =>
      b === 0 ? (a > 0 ? '+100%' : '0%') : `${a - b >= 0 ? '+' : ''}${Math.round(((a - b) / b) * 100)}%`;

    const deltaVsYesterday = {
      revenue: pct(dashboard.revenueToday, yRevenue),
      checkins: dashboard.checkinsToday - yCheckins,
    };

    let aiBriefing = '';
    if (this.enabled) {
      const prompt =
        `اكتب إحاطة صباحية قصيرة (٥ جمل كحد أقصى) لمالك الجيم بالعربية.\n` +
        `إيراد اليوم: ${dashboard.revenueToday} ج.م (أمس: ${yRevenue})\n` +
        `حضور اليوم: ${dashboard.checkinsToday} (أمس: ${yCheckins})\n` +
        `أعضاء نشطون: ${dashboard.activeMembers}\n` +
        `اشتراكات تنتهي خلال ٧ أيام: ${expiring.length}\n` +
        `منتجات منخفضة المخزون: ${lowStock.length}\n` +
        `إشعارات معلّقة: ${pending}\n` +
        `وضّح ما تغيّر عن أمس، وما يحتاج انتباهاً اليوم، وأضف ملاحظة تحفيزية أو استراتيجية واحدة.`;
      aiBriefing = await this.ask(MAIN_SYSTEM_PROMPT, prompt);
    }

    return {
      aiEnabled: this.enabled,
      kpis: dashboard,
      deltaVsYesterday,
      ptSessionsToday,
      classBookingsToday,
      coachUtilization,
      topUpsell,
      alerts: { expiringMembers: expiring, lowStock, pendingNotifications: pending },
      aiBriefing:
        aiBriefing ||
        (this.enabled ? '' : 'فعّل مزود الذكاء الاصطناعي المحدد للحصول على الإحاطة الذكية.'),
      source: this.providerSource(),
      confidence: aiBriefing ? 'high' : 'medium',
    };
  }

  // ===========================================================================
  // Endpoint 5 — Free chat
  // ===========================================================================
  /** Auto-pick a data context from the question when none is provided. */
  private detectContext(question: string): string {
    const q = question.toLowerCase();
    if (/إيراد|revenue|مبيعات|sales|ربح|profit|فلوس|money/.test(q)) return 'revenue';
    if (/منتج|product|بضاعة|مخزون|stock|مبيع/.test(q)) return 'products';
    if (/حضور|attend|attendance|زيارة|visit|check.?in/.test(q)) return 'attendance';
    if (/وزن|weight|دهون|body.?fat|قياس|measure|عضل|muscle/.test(q)) return 'measurements';
    if (/كلاس|class|حصة|حصص|zumba|yoga|crossfit/.test(q)) return 'classes';
    if (/مدرب|coach|pt|تدريب شخصي|personal train/.test(q)) return 'pt';
    if (/دعوة|دعوات|زائر|زوار|مدعو|invite|invitation|visitor|referr|free visit/.test(q)) return 'invitations';
    return 'members'; // safe default
  }

  async ask_(gymId: string, question: string, context?: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const dataUsed: string[] = [];
    let payload = '';
    const ctx = context || this.detectContext(question);

    if (ctx === 'members') {
      const now = new Date();
      const members = await this.prisma.member.findMany({
        where: { gymId },
        select: {
          name: true, mobile: true, visits: true, lastVisit: true, expiry: true,
          sessionsLeft: true, frozen: true, plan: { select: { name: true, type: true } },
          branch: { select: { name: true } },
          measurements: {
            orderBy: { measuredAt: 'desc' }, take: 1,
            select: { measuredAt: true, weight: true, bodyFat: true, muscleMass: true },
          },
        },
        take: 500,
        orderBy: { lastVisit: 'desc' },
      });
      dataUsed.push('members', 'measurements');
      // SECURITY FIX: redact PII before sending to the third-party LLM.
      // Only the last 4 digits of the mobile are retained (sufficient for the
      // analyst prompt yet not personally identifiable). Weight/body metrics
      // are kept aggregate since they are the analytical signal.
      payload += `MEMBERS(${members.length}): ${JSON.stringify(
        members.map((m) => ({ ...m, mobile: this.redactMobile(m.mobile) })),
      )}\n`;
      void now;
    }
    if (ctx === 'revenue') {
      const since = new Date(); since.setMonth(since.getMonth() - 6);
      const txns = await this.prisma.transaction.findMany({
        where: { gymId, createdAt: { gte: since } },
        select: { type: true, amount: true, category: true, branchName: true, createdAt: true },
        take: 500,
      });
      dataUsed.push('transactions');
      payload += `TRANSACTIONS: ${JSON.stringify(txns)}\n`;
    }
    if (ctx === 'products') {
      const products = await this.prisma.product.findMany({ where: { gymId }, take: 50 });
      dataUsed.push('products');
      payload += `PRODUCTS: ${JSON.stringify(products)}\n`;
    }
    if (ctx === 'attendance') {
      const since = new Date(); since.setDate(since.getDate() - 30);
      const att = await this.prisma.attendance.findMany({
        where: { gymId, at: { gte: since } },
        select: { at: true, method: true, staffName: true,
          member: { select: { name: true } }, branch: { select: { name: true } } },
        take: 500,
      });
      dataUsed.push('attendance');
      payload += `ATTENDANCE(30d): ${JSON.stringify(att)}\n`;
    }
    if (ctx === 'measurements') {
      const members = await this.prisma.member.findMany({
        where: { gymId },
        select: {
          name: true,
          measurements: {
            orderBy: { measuredAt: 'desc' }, take: 3,
            select: { measuredAt: true, weight: true, bodyFat: true, muscleMass: true },
          },
        },
        take: 200,
      });
      dataUsed.push('measurements');
      payload += `MEMBER_MEASUREMENTS: ${JSON.stringify(members.filter((m) => m.measurements.length))}\n`;
    }
    if (ctx === 'classes') {
      const since = new Date(); since.setDate(since.getDate() - 30);
      const sessions = await this.prisma.classSession.findMany({
        where: { gymId, startsAt: { gte: since } },
        select: {
          startsAt: true, capacity: true,
          template: { select: { name: true } },
          _count: { select: { bookings: { where: { status: { in: ['CONFIRMED', 'ATTENDED'] } } } } },
        },
        take: 300,
      });
      dataUsed.push('classes');
      payload += `CLASSES(30d): ${JSON.stringify(sessions.map((s) => ({ name: s.template?.name, startsAt: s.startsAt, capacity: s.capacity, booked: s._count.bookings })))}\n`;
    }
    if (ctx === 'pt') {
      const since = new Date(); since.setMonth(since.getMonth() - 1);
      const pt = await this.prisma.ptSession.findMany({
        where: { gymId, scheduledAt: { gte: since } },
        select: {
          scheduledAt: true, status: true, price: true,
          coach: { select: { user: { select: { name: true } } } }, member: { select: { name: true } },
        },
        take: 500,
      });
      dataUsed.push('pt');
      payload += `PT_SESSIONS(month): ${JSON.stringify(pt)}\n`;
    }
    if (ctx === 'invitations') {
      const [visits, slots] = await Promise.all([
        this.prisma.invitation.findMany({
          where: { gymId },
          include: { member: { select: { name: true } } },
          orderBy: { visitDate: 'desc' },
          take: 100,
        }),
        this.prisma.invitationSlot.findMany({ where: { gymId } }),
      ]);
      dataUsed.push('invitations', 'slots');
      payload += `INVITATIONS(visits): ${JSON.stringify(visits.map((v) => ({
        invitedBy: v.member?.name, visitorName: v.visitorName, status: v.status,
        converted: v.convertedToMember, score: v.feedbackScore, feedback: v.feedbackText, visitDate: v.visitDate,
      })))}\n`;
      payload += `INVITATION_SLOTS: ${JSON.stringify(slots)}\n`;
    }

    if (!this.enabled) {
      return { aiEnabled: false, answer: this.disabled().message, dataUsed, source: 'heuristic', confidence: 'medium' };
    }

    const answer = await this.ask(
      MAIN_SYSTEM_PROMPT,
      `بيانات الجيم:\n${payload}\n\nسؤال المالك: ${question}\n` +
        `أجب بدقة بناءً على البيانات أعلاه فقط. إن لم تكن البيانات كافية، قل ذلك.\n` +
        `أيًا كان السؤال، لا تُخرج الأرقام الكاملة للهواتف أو بيانات شخصية مفصّلة.`,
    );
    return { aiEnabled: true, answer: answer || 'No answer produced.', dataUsed, source: answer ? this.providerSource() : 'heuristic', confidence: answer ? 'high' : 'medium' };
  }

  // ===========================================================================
  // Endpoint 6 — Auto Upsell Engine
  // ===========================================================================
  async upsellTargets(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    if (!this.enabled) return this.offlineSvc.upsellTargetsOffline(gymId);
    const now = Date.now();
    const sixtyAgo = new Date(now - 60 * 86400000);
    // Active, on a monthly (TIME) plan, joined 60+ days ago.
    const members = await this.prisma.member.findMany({
      where: {
        gymId, frozen: false, plan: { type: 'TIME' },
        startDate: { lte: sixtyAgo }, expiry: { gte: new Date() },
      },
      select: {
        id: true, name: true, mobile: true, visits: true, startDate: true,
        plan: { select: { name: true } },
      },
      take: 500,
    });
    const targets = members
      .map((m) => {
        const tenure = Math.max(1, Math.round((now - +new Date(m.startDate)) / 86400000));
        const freq = (m.visits || 0) / tenure;
        return { ...m, visitFrequency: +freq.toFixed(2), plan: m.plan?.name ?? null };
      })
      .filter((m) => m.visitFrequency > 0.5)
      .sort((a, b) => b.visitFrequency - a.visitFrequency)
      .slice(0, 20);

    let pitches: Record<string, string> = {};
    if (this.enabled && targets.length) {
      const prompt =
        `هؤلاء أعضاء منتظمون على باقة شهرية ومرشّحون للترقية لباقة ربع/سنوية. ` +
        `اكتب لكل عضو رسالة واتساب قصيرة بالعربية تقنعه بالترقية. ` +
        `أعد JSON فقط: {"<id>":"<رسالة>"}.\n\n` +
        JSON.stringify(targets.slice(0, 10).map((t) => ({ id: t.id, name: this.redactName(t.name), visitFrequency: t.visitFrequency, plan: t.plan })));
      pitches = this.safeJson<Record<string, string>>(await this.ask(MAIN_SYSTEM_PROMPT, prompt)) ?? {};
    }
    return {
      aiEnabled: this.enabled,
      total: targets.length,
      targets: targets.map((t) => ({
        ...t,
        pitch: pitches[t.id] || `مرحباً ${t.name}، إنت من أكتر الأعضاء التزامًا! اعرض عليك ترقية لباقة أطول بسعر أوفر.`,
      })),
      source: Object.keys(pitches).length ? this.providerSource() : 'heuristic',
      confidence: Object.keys(pitches).length ? 'high' : 'medium',
    };
  }

  // ===========================================================================
  // Endpoint 7 — Pricing Intelligence
  // ===========================================================================
  async smartPricing(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    if (!this.enabled) return this.offlineSvc.smartPricingOffline(gymId);
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
    const [activeCount, monthIncome, plans] = await this.prisma.$transaction([
      this.prisma.member.count({ where: { gymId, frozen: false } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: monthStart } }, _sum: { amount: true } }),
      this.prisma.plan.findMany({ where: { gymId }, select: { id: true, name: true, price: true, type: true } }),
    ]);
    const dist = await this.prisma.member.groupBy({
      by: ['planId'], where: { gymId, frozen: false }, _count: { planId: true }, orderBy: { planId: 'asc' },
    });
    const distRows = dist as Array<{ planId: string | null; _count: { planId: number } }>;
    const planDistribution = plans.map((p) => ({
      plan: p.name, price: Number(p.price || 0),
      members: distRows.find((d) => d.planId === p.id)?._count.planId ?? 0,
    }));
    const month = new Date().getMonth() + 1; // 1-12
    const season = [6, 7, 8].includes(month) ? 'summer' : 'regular';

    const currentState = {
      activeMembers: activeCount,
      monthlyRevenue: Number(monthIncome._sum.amount || 0),
      planDistribution, season, month,
    };

    let recommendation = 'Review pricing quarterly; promote the most-subscribed plan.';
    let urgency: 'high' | 'medium' | 'low' = 'low';
    let reasoning = 'Local heuristic — enable AI for market-aware advice.';
    if (this.enabled) {
      const prompt =
        `أنت محلل تسعير لجيم مصري. حلّل الحالة واقترح تعديل التسعير المناسب للسوق المصري ` +
        `(اعتبر رمضان والصيف). أعد JSON فقط: ` +
        `{"recommendation":"...","urgency":"high|medium|low","reasoning":"..."}\n\n` +
        JSON.stringify(currentState);
      const parsed = this.safeJson<{ recommendation: string; urgency: 'high' | 'medium' | 'low'; reasoning: string }>(
        await this.ask(MAIN_SYSTEM_PROMPT, prompt),
      );
      if (parsed) { recommendation = parsed.recommendation; urgency = parsed.urgency; reasoning = parsed.reasoning; }
    }
    return { aiEnabled: this.enabled, currentState, recommendation, urgency, reasoning, source: this.providerSource(), confidence: 'high' };
  }

  // ===========================================================================
  // Endpoint 8 — Member Retention Score (0-100)
  // ===========================================================================
  async retentionScore(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    if (!this.enabled) return this.offlineSvc.retentionScoreOffline(gymId);
    const now = Date.now();
    const members = await this.prisma.member.findMany({
      where: { gymId, frozen: false },
      select: {
        id: true, name: true, mobile: true, vip: true, visits: true,
        startDate: true, lastVisit: true, expiry: true,
        plan: { select: { type: true, name: true } },
      },
      take: 1000,
    });

    const scored = members.map((m) => {
      const tenure = Math.max(1, Math.round((now - +new Date(m.startDate)) / 86400000));
      const freq = (m.visits || 0) / tenure; // visits/day
      const daysSince = m.lastVisit ? Math.round((now - +new Date(m.lastVisit)) / 86400000) : 999;
      // components (each 0-1)
      const freqScore = Math.min(1, freq / 0.5);                 // 0.5/day = excellent
      const recencyScore = Math.max(0, 1 - daysSince / 21);      // 0 by 3 weeks idle
      const tenureScore = Math.min(1, tenure / 180);             // matures by 6 months
      const vipBonus = m.vip ? 0.1 : 0;
      const score = Math.round(Math.min(100, (freqScore * 0.4 + recencyScore * 0.4 + tenureScore * 0.2 + vipBonus) * 100));
      return {
        id: m.id, name: this.redactName(m.name), mobile: this.redactMobile(m.mobile), vip: m.vip,
        plan: m.plan?.name ?? null, visitFrequency: +freq.toFixed(2),
        daysSinceLastVisit: daysSince, score,
      };
    });

    const buckets = { excellent: 0, good: 0, atRisk: 0, critical: 0 };
    for (const s of scored) {
      if (s.score >= 75) buckets.excellent++;
      else if (s.score >= 50) buckets.good++;
      else if (s.score >= 25) buckets.atRisk++;
      else buckets.critical++;
    }
    const bottom = [...scored].sort((a, b) => a.score - b.score).slice(0, 20);

    let actionPlan = '';
    if (this.enabled && bottom.length) {
      const prompt =
        `هؤلاء أقل ٢٠ عضوًا في درجة الاحتفاظ (0-100). اكتب خطة عمل موجزة بالعربية ` +
        `(٤-٦ نقاط) لإنقاذهم قبل ما يسيبوا الجيم.\n\n` +
        JSON.stringify(bottom.map((b) => ({ name: b.name, score: b.score, daysSinceLastVisit: b.daysSinceLastVisit })));
      actionPlan = await this.ask(MAIN_SYSTEM_PROMPT, prompt);
    }
    return {
      aiEnabled: this.enabled,
      distribution: buckets,
      averageScore: scored.length ? Math.round(scored.reduce((s, x) => s + x.score, 0) / scored.length) : 0,
      bottom20: bottom,
      actionPlan: actionPlan || (this.enabled ? '' : 'فعّل مزود الذكاء الاصطناعي المحدد للحصول على خطة عمل.'),
      source: actionPlan ? this.providerSource() : 'heuristic',
      confidence: actionPlan ? 'high' : 'medium',
    };
  }


  async suggestCampaign(gymId: string, dto: { target_audience?: string; budget_range?: string; goal?: string; channel?: string }) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const data = await this.collectCampaignData(gymId);
    const fallback = `💡 حملة مقترحة: ابعت واتساب للأعضاء الغايبين والأعضاء اللي اشتراكهم قرب يخلص. الهدف: ${dto.goal || 'تجديد وتنشيط'}. القناة: ${dto.channel || 'WhatsApp'}. الرسالة: "وحشتنا يا بطل، جدد أو ارجع تمرينك الأسبوع ده وخد قياس مجاني".`;
    const prompt = `هدف الحملة: ${dto.goal || 'تنشيط وتجديد'}
الفئة المستهدفة: ${dto.target_audience || 'inactive + expiring'}
الميزانية: ${dto.budget_range || 'منخفضة'}
القناة: ${dto.channel || 'WhatsApp'}
بيانات الجيم: ${JSON.stringify(data)}
اعمل اقتراح حملة كامل بالعامية المصرية.`;
    const answer = this.enabled ? await this.ask(CAMPAIGN_SYSTEM_PROMPT, prompt, 1000) : '';
    return { proposal: answer || fallback, data, source: answer ? this.providerSource() : 'heuristic', confidence: answer ? 'high' : 'medium' };
  }

  async suggestRevenue(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const data = await this.collectRevenueData(gymId);
    const fallback = `الإيرادات آخر 30 يوم ${data.income30d} جنيه. ركّز على تجديد الاشتراكات القريبة، وزوّد upsell للباقات الطويلة، وراجع المنتجات قليلة البيع.`;
    const answer = this.enabled ? await this.ask(REVENUE_SYSTEM_PROMPT, `حلل البيانات دي واقترح خطوات عملية: ${JSON.stringify(data)}`, 1000) : '';
    return { proposal: answer || fallback, data, source: answer ? this.providerSource() : 'heuristic', confidence: answer ? 'high' : 'medium' };
  }

  async suggestRetention(gymId: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    const data = await this.collectRetentionData(gymId);
    const fallback = `ابدأ بالـ ${data.inactive.length} عضو الغايبين. ابعت رسالة شخصية لكل واحد، واعمل متابعة تليفون للأعضاء اللي اشتراكهم قرب يخلص.`;
    const answer = this.enabled ? await this.ask(RETENTION_SYSTEM_PROMPT, `اعمل خطة احتفاظ شخصية من البيانات دي: ${JSON.stringify(data)}`, 1000) : '';
    return { proposal: answer || fallback, data, source: answer ? this.providerSource() : 'heuristic', confidence: answer ? 'high' : 'medium' };
  }

  async chat(gymId: string, message: string, context?: string) {
    try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
    await this.prisma.aiChatMessage.create({ data: { gymId, role: 'user', content: message } });
    const detected = context || this.detectContext(message);
    const relevantData = await this.collectChatContext(gymId, detected, message);
    const lower = message.toLowerCase();
    const systemPrompt = /حملة|campaign|marketing|واتساب|whatsapp/.test(lower)
      ? CAMPAIGN_SYSTEM_PROMPT
      : /إيراد|revenue|price|سعر|أسعار/.test(lower)
        ? REVENUE_SYSTEM_PROMPT
        : /احتفاظ|retention|غايب|inactive|مش شغال/.test(lower)
          ? RETENTION_SYSTEM_PROMPT
          : MAIN_SYSTEM_PROMPT;
    const prompt = `السؤال: ${message}
السياق المكتشف: ${detected}
بيانات الجيم المتاحة: ${JSON.stringify(relevantData)}
رد بشكل محادثة طبيعية، مختصر، وبالعامية المصرية إلا لو السؤال بالإنجليزي.`;
    const answer = this.enabled ? await this.ask(systemPrompt, prompt, 1000) : '';
    const fallback = this.chatFallback(message, detected, relevantData);
    const content = answer || fallback;
    const source = answer ? this.providerSource() : 'heuristic';
    await this.prisma.aiChatMessage.create({ data: { gymId, role: 'assistant', content, source } });
    return { answer: content, context: detected, data: relevantData, source, confidence: answer ? 'high' : 'medium' };
  }

  chatHistory(gymId: string, limit = 50) {
    return this.prisma.aiChatMessage.findMany({ where: { gymId }, orderBy: { createdAt: 'desc' }, take: Math.min(100, Math.max(1, limit)) });
  }

  async dashboardSummary(gymId: string) {
    return this.cached(`ai:dashboard-summary:${gymId}`, 1800, async () => {
      try { await this.quota?.checkAndIncrement(gymId); } catch(e){ throw e; }
      const offline = await this.offlineSvc.dashboardSummaryOffline(gymId);
      if (!this.enabled) return offline;
      const answer = await this.ask(MAIN_SYSTEM_PROMPT, `حوّل ملخص الداشبورد ده لجملة headline قصيرة واقتراح واحد بالعامية المصرية. رجّع JSON فقط: {"headline":"","topSuggestion":""}
${JSON.stringify(offline)}`, 500);
      const parsed = this.safeJson<{ headline: string; topSuggestion: string }>(answer);
      return parsed ? { ...offline, headline: parsed.headline, topSuggestion: parsed.topSuggestion, source: this.providerSource(), confidence: 'high' } : offline;
    });
  }

  private async collectCampaignData(gymId: string) {
    const now = new Date();
    return {
      inactive: await this.prisma.member.count({ where: { gymId, frozen: false, OR: [{ lastVisit: null }, { lastVisit: { lt: new Date(Date.now() - 14 * 86400000) } }] } }),
      expiring7: await this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: now, lte: new Date(Date.now() + 7 * 86400000) } } }),
      recentCampaigns: await this.prisma.campaign.findMany({ where: { gymId }, select: { name: true, channel: true, status: true, statsFailed: true, statsSent: true }, orderBy: { createdAt: 'desc' }, take: 5 }),
    };
  }

  private async collectRevenueData(gymId: string) {
    const start30 = new Date(Date.now() - 30 * 86400000);
    const start60 = new Date(Date.now() - 60 * 86400000);
    const [income30, incomePrev, plans, sales] = await Promise.all([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start30 } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start60, lt: start30 } }, _sum: { amount: true } }),
      this.prisma.plan.findMany({ where: { gymId }, select: { name: true, price: true, type: true } }),
      this.prisma.sale.count({ where: { gymId, createdAt: { gte: start30 } } }),
    ]);
    return { income30d: Number(income30._sum.amount || 0), previous30d: Number(incomePrev._sum.amount || 0), plans, posSales30d: sales };
  }

  private async collectRetentionData(gymId: string) {
    const inactive = await this.prisma.member.findMany({ where: { gymId, frozen: false, OR: [{ lastVisit: null }, { lastVisit: { lt: new Date(Date.now() - 10 * 86400000) } }] }, select: { id: true, name: true, mobile: true, lastVisit: true, expiry: true }, take: 30 });
    const expiring = await this.prisma.member.findMany({ where: { gymId, frozen: false, expiry: { gte: new Date(), lte: new Date(Date.now() + 14 * 86400000) } }, select: { id: true, name: true, expiry: true }, take: 30 });
    return {
      inactive: inactive.map((m) => ({ ...m, name: this.redactName(m.name), mobile: this.redactMobile(m.mobile) })),
      expiring: expiring.map((m) => ({ ...m, name: this.redactName(m.name) })),
    };
  }

  private async collectChatContext(gymId: string, context: string, message: string) {
    const q = message.toLowerCase();
    if (context === 'revenue' || /إيراد|revenue|sales|مبيعات|أسعار|سعر/.test(q)) return this.collectRevenueData(gymId);
    if (context === 'products' || /مخزون|inventory|product|منتج/.test(q)) return this.offlineSvc.productInsightsOffline(gymId);
    if (context === 'classes' || /كلاس|class|حصة/.test(q)) return this.prisma.classSession.findMany({ where: { gymId }, include: { _count: { select: { bookings: true } }, template: { select: { name: true } } }, orderBy: { startsAt: 'desc' }, take: 20 });
    if (context === 'attendance' || /حضور|attendance|check/.test(q)) return { last30Days: await this.prisma.attendance.count({ where: { gymId, at: { gte: new Date(Date.now() - 30 * 86400000) } } }) };
    if (context === 'staff' || /موظف|موظفين|staff/.test(q)) return { staffCheckins7d: await this.prisma.staffAttendance.count({ where: { gymId, checkInAt: { gte: new Date(Date.now() - 7 * 86400000) } } }) };
    if (context === 'campaigns' || /حملة|campaign|marketing/.test(q)) return this.collectCampaignData(gymId);
    return { members: await this.prisma.member.count({ where: { gymId } }), activeMembers: await this.prisma.member.count({ where: { gymId, frozen: false } }) };
  }

  private chatFallback(message: string, context: string, data: Record<string, any>): string {
    if (context === 'revenue') return `بص يا باشا، آخر أرقام الإيراد عندك: ${data.income30d || 0} جنيه في 30 يوم. ركّز على التجديد والـ upsell للباقات الأطول.`;
    if (context === 'products') return `المخزون محتاج متابعة. راجع المنتجات قليلة الكمية واطلب توريد قبل ما تضيع مبيعات.`;
    if (context === 'classes') return `راجع الكلاسات قليلة الحجز وجرّب تغيّر وقتها أو تعمل دعوة مجانية لأعضاء مهتمين.`;
    if (context === 'campaigns') return `أقترح حملة واتساب للأعضاء الغايبين والقريبين من انتهاء الاشتراك برسالة قصيرة وعرض محدود.`;
    return `تمام، أنا شايف البيانات الأساسية. اسألني عن الإيرادات، الأعضاء، المخزون، الكلاسات أو الحملات وأنا أديك خطة عملية.`;
  }

  private safeJson<T>(raw: string): T | null {
    if (!raw) return null;
    try {
      const m = raw.match(/\{[\s\S]*\}/);
      return m ? (JSON.parse(m[0]) as T) : null;
    } catch {
      return null;
    }
  }
}
