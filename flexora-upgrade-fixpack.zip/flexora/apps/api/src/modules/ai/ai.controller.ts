/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { AiService } from './ai.service';
import { AiBrainService } from './ai-brain.service';
import { AskAiDto } from './dto';
import { ReportsService } from '../reports/reports.service';
import { AiSuggestionsService } from './ai-suggestions.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { IsOptional, IsString } from 'class-validator';
import { AiQuotaService } from './ai-quota.service';


class CampaignSuggestionDto {
  @IsOptional() @IsString() target_audience?: string;
  @IsOptional() @IsString() budget_range?: string;
  @IsOptional() @IsString() goal?: string;
  @IsOptional() @IsString() channel?: string;
}

class ChatDto {
  @IsString() message!: string;
  @IsOptional() @IsString() context?: string;
}

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Permissions('reports.view') // insights domain — minimum MANAGER-level access
@RequiresFeature('ai')
@Controller('ai')
export class AiController {
  constructor(
    private readonly ai: AiService,
    private readonly brain: AiBrainService,
    private readonly reports: ReportsService,
    private readonly suggestions: AiSuggestionsService,
    private readonly quota: AiQuotaService,
  ) {}

  @Post('churn-analysis')
  @Permissions('reports.view')
  @Audit('ai_analysis', 'Member')
  churnAnalysis(@GymId() gymId: string) {
    return this.brain.churnAnalysis(gymId);
  }

  @Post('sales-coach')
  @Permissions('members.create')
  salesCoach(@GymId() gymId: string, @Body() dto: { visitorInfo?: string; question: string }) {
    return this.brain.chat(dto.question, gymId, 'sales_coach', dto.visitorInfo);
  }

  @Post('generate-campaign')
  @Permissions('reports.view')
  generateCampaign(@GymId() gymId: string, @Body() dto: { target: 'expiring'|'inactive'|'new'|'all' }) {
    return this.brain.generateCampaign(gymId, dto.target);
  }

  @Get('insights')
  @Permissions('reports.view')
  getInsights(@GymId() gymId: string) {
    return this.brain.getInsights(gymId);
  }

  @Post('insights/generate')
  @Permissions('reports.view')
  @Audit('ai_generate', 'Insight')
  generateInsight(@GymId() gymId: string) {
    return this.brain.generateAndSaveWeeklyInsight(gymId);
  }


  @Get('suggestions')
  suggestionsList(@GymId() g: string) {
    return this.suggestions.getOrCreateDailySuggestions(g);
  }

  @Post('suggestions/:id/dismiss')
  dismiss(@GymId() g: string, @Param('id') id: string) {
    return this.suggestions.dismiss(g, id);
  }

  @Post('suggestions/:id/act')
  act(@GymId() g: string, @Param('id') id: string) {
    return this.suggestions.markActed(g, id);
  }

  @Post('suggest-campaign')
  suggestCampaign(@GymId() g: string, @Body() dto: CampaignSuggestionDto) {
    return this.ai.suggestCampaign(g, dto);
  }

  @Post('suggest-revenue')
  suggestRevenue(@GymId() g: string) {
    return this.ai.suggestRevenue(g);
  }

  @Post('suggest-retention')
  suggestRetention(@GymId() g: string) {
    return this.ai.suggestRetention(g);
  }

  @Throttle({ write: { ttl: 60000, limit: 10 } })
  @Post('chat')
  chat(@GymId() g: string, @Body() dto: ChatDto) {
    return this.ai.chat(g, dto.message, dto.context);
  }

  @Get('chat/history')
  chatHistory(@GymId() g: string, @Query('limit') limit = 50) {
    return this.ai.chatHistory(g, +limit);
  }

  @Get('dashboard-summary')
  dashboardSummary(@GymId() g: string) {
    return this.ai.dashboardSummary(g);
  }

  @Get('provider-status')
  providerStatus() {
    return this.ai.providerStatus();
  }

  @Get('churn-risk')
  churn(@GymId() g: string, @Query('limit') limit = 50, @Query('offset') offset = 0) {
    return this.ai.churnRisk(g, +limit, +offset);
  }

  @Get('revenue-forecast')
  forecast(@GymId() g: string) {
    return this.ai.revenueForecast(g);
  }

  @Get('product-insights')
  products(@GymId() g: string) {
    return this.ai.productInsights(g);
  }

  @Get('daily-briefing')
  async briefing(@GymId() g: string) {
    const dashboard = await this.reports.dashboard(g);
    return this.ai.dailyBriefing(g, dashboard);
  }


  @Get('upsell-targets')
  upsell(@GymId() g: string) {
    return this.ai.upsellTargets(g);
  }

  @Get('smart-pricing')
  pricing(@GymId() g: string) {
    return this.ai.smartPricing(g);
  }

  @Get('retention-score')
  retention(@GymId() g: string) {
    return this.ai.retentionScore(g);
  }

  // SECURITY: per-gym throttle cap on AI calls to limit LLM cost exposure.
  @Throttle({ write: { ttl: 60000, limit: 5 } })
  @Post('ask')
  ask(@GymId() g: string, @Body() dto: AskAiDto) {
    return this.ai.ask_(g, dto.question, dto.context);
  }

  @Get('quota')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('reports.view')
  async getQuota(@GymId() gymId: string) {
    return this.quota.getUsage(gymId);
  }
}
