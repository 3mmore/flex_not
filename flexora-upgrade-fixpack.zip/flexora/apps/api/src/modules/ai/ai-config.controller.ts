/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Phase 6.3/6.4 — gym-owned AI credentials.
 * Deliberately NOT behind @RequiresFeature('ai'): every tier must be able to
 * bring its own API key (Gemini has a free tier), otherwise onboarding step 6
 * silently 403s for BASIC gyms.
 */
import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsBoolean, IsIn, IsOptional, IsString } from 'class-validator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { AiConfigService } from './ai-config.service';

class AiConfigDto {
  @IsOptional() @IsBoolean() enabled?: boolean;
  @IsOptional() @IsIn(['anthropic', 'gemini', 'groq']) provider?: string;
  @IsOptional() @IsString() apiKey?: string;
}

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Roles('OWNER', 'MANAGER')
@Controller('ai/config')
export class AiConfigController {
  constructor(private readonly config: AiConfigService) {}

  @Get()
  get(@GymId() gymId: string) {
    return this.config.getStatus(gymId);
  }

  @Post()
  @Audit('update', 'AiConfig')
  save(@GymId() gymId: string, @Body() dto: AiConfigDto) {
    return this.config.save(gymId, dto);
  }
}
