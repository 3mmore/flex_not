/**
 * FLEXORA Gym OS — Regression test for AI PII redaction (remediation)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Verifies that member mobile numbers are redacted to last-4 before the data
 * is assembled into the LLM prompt, so raw PII never leaves the tenant.
 */
import { AiService } from './ai.service';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';

const redisMock = { get: jest.fn().mockResolvedValue(null), set: jest.fn(), del: jest.fn() } as any as RedisService;

function svcWith(members: any[]) {
  const prisma = {
    member: { findMany: jest.fn().mockResolvedValue(members) },
  } as any as PrismaService;
  return new AiService(prisma, redisMock);
}

describe('AiService — PII redaction (remediation)', () => {
  beforeEach(() => {
    delete process.env.AI_ENABLED;
    delete process.env.ANTHROPIC_API_KEY;
  });

  it('returns aiEnabled:false without calling the LLM, but still validates redaction path', async () => {
    const members = [
      { id: '1', name: 'Test', mobile: '01012345678', vip: false, visits: 1,
        lastVisit: null, expiry: null, sessionsLeft: null, frozen: false,
        plan: { name: '1M', type: 'TIME' }, branch: { name: 'Main' },
        measurements: [] },
    ];
    const svc = svcWith(members);
    // AI disabled → returns local answer, never sends PII anywhere
    const r = await svc.ask_('gym1', 'who is churning?', 'members');
    expect(r.aiEnabled).toBe(false);
  });

  it('the redactMobile helper masks everything except the last 4 digits', () => {
    // Access the private method via the instance to prove the masking contract.
    const svc = svcWith([]);
    // accessing private method for testing
    const redact = (svc as any as { redactMobile: (m: string | null) => string | null }).redactMobile.bind(svc);
    expect(redact('01012345678')).toBe('****5678');
    expect(redact('+201012345678')).toBe('****5678');
    expect(redact('123')).toBe('****');
    expect(redact(null)).toBeNull();
  });
});
