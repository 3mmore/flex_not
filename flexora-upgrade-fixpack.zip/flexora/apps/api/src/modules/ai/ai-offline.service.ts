/**
 * FLEXORA Gym OS — offline heuristic intelligence engine
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';

@Injectable()
export class AiOfflineService {
  constructor(private readonly prisma: PrismaService) {}

  async churnRiskOffline(gymId: string, limit = 50, offset = 0) {
    const now = Date.now();
    const members = await this.prisma.member.findMany({
      where: { gymId, frozen: false },
      select: { id: true, name: true, mobile: true, visits: true, startDate: true, lastVisit: true, expiry: true, frozen: true, sessionsLeft: true, plan: { select: { name: true, type: true } } },
      take: 1000,
    });
    const scored = members.map((m) => {
      const daysSinceLastVisit = m.lastVisit ? Math.round((now - +new Date(m.lastVisit)) / 86400000) : 999;
      const tenureWeeks = Math.max(1, Math.round((now - +new Date(m.startDate)) / (7 * 86400000)));
      const visitsPerWeek = Number(((m.visits || 0) / tenureWeeks).toFixed(2));
      const membershipDaysLeft = m.expiry ? Math.round((+new Date(m.expiry) - now) / 86400000) : null;
      let score = 0;
      const reasons: string[] = [];
      if (daysSinceLastVisit > 21) { score += 45; reasons.push('غايب أكتر من 21 يوم'); }
      else if (daysSinceLastVisit > 14) { score += 35; reasons.push('غايب أكتر من أسبوعين'); }
      else if (daysSinceLastVisit > 7) { score += 20; reasons.push('غايب أكتر من أسبوع'); }
      if (visitsPerWeek < 1) { score += 20; reasons.push('معدل الحضور أقل من مرة في الأسبوع'); }
      if (membershipDaysLeft !== null && membershipDaysLeft < 14) { score += 20; reasons.push('الاشتراك قرب يخلص'); }
      if (m.frozen) { score += 15; reasons.push('العضوية مجمدة'); }
      if (m.plan?.type === 'SESSION') { score += 10; reasons.push('باقة حصص وممكن تخلص بسرعة'); }
      const risk = score >= 61 ? 'HIGH' : score >= 31 ? 'MEDIUM' : 'LOW';
      return { id: m.id, name: m.name, mobile: m.mobile, plan: m.plan?.name || null, riskScore: Math.min(100, score), risk, daysSinceLastVisit, visitsPerWeek, membershipDaysLeft, reasons };
    }).sort((a, b) => b.riskScore - a.riskScore);
    const high = scored.filter((m) => m.risk === 'HIGH');
    const medium = scored.filter((m) => m.risk === 'MEDIUM');
    const low = scored.filter((m) => m.risk === 'LOW');
    return { aiEnabled: false, summary: { high: high.length, medium: medium.length, low: low.length }, total: high.length, limit, offset, highRisk: high.slice(offset, offset + limit), mediumRisk: medium.slice(0, limit), source: 'heuristic', confidence: 'medium' };
  }

  async revenueForecastOffline(gymId: string) {
    const start = new Date();
    start.setDate(start.getDate() - 84);
    const rows = await this.prisma.transaction.findMany({ where: { gymId, type: 'INCOME', createdAt: { gte: start } }, select: { amount: true, createdAt: true }, take: 5000 });
    const weeks = new Map<string, number>();
    for (const row of rows) {
      const d = new Date(row.createdAt);
      const week = `${d.getUTCFullYear()}-W${Math.floor((Number(d) - Number(new Date(Date.UTC(d.getUTCFullYear(), 0, 1)))) / (7 * 86400000))}`;
      weeks.set(week, (weeks.get(week) || 0) + Number(row.amount));
    }
    const series = Array.from(weeks.entries()).sort().map(([week, value]) => ({ week, value: Math.round(value) }));
    const last4 = series.slice(-4);
    const prev4 = series.slice(-8, -4);
    const avg4 = last4.length ? last4.reduce((s, x) => s + x.value, 0) / last4.length : 0;
    const prevAvg = prev4.length ? prev4.reduce((s, x) => s + x.value, 0) / prev4.length : avg4;
    const trendPct = prevAvg > 0 ? Math.round(((avg4 - prevAvg) / prevAvg) * 100) : 0;
    const forecast = Math.max(0, Math.round(avg4 * 4 * (1 + trendPct / 100)));
    return { aiEnabled: false, historicalWeeks: series, forecast: { next4Weeks: forecast, weeklyAverage: Math.round(avg4), trendPct, confidence: series.length >= 8 ? 'medium' : 'low' }, recommendation: trendPct < -10 ? 'الإيراد نازل — اعمل حملة تجديد وعرض محدود 72 ساعة.' : 'الإيراد مستقر — ركز على upsell للباقات الأطول.', source: 'heuristic', confidence: 'medium' };
  }

  async dailyBriefingOffline(gymId: string, dashboard: { checkinsToday: number; revenueToday: number; activeMembers: number }) {
    const startToday = new Date(); startToday.setHours(0, 0, 0, 0);
    const startYesterday = new Date(startToday.getTime() - 86400000);
    const [newMembersToday, expiring7, inactive] = await Promise.all([
      this.prisma.member.count({ where: { gymId, createdAt: { gte: startToday } } }),
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: new Date(), lte: new Date(Date.now() + 7 * 86400000) } } }),
      this.prisma.member.count({ where: { gymId, frozen: false, OR: [{ lastVisit: null }, { lastVisit: { lt: new Date(Date.now() - 7 * 86400000) } }] } }),
    ]);
    const yesterdayCheckins = await this.prisma.attendance.count({ where: { gymId, at: { gte: startYesterday, lt: startToday } } });
    const delta = Number(dashboard?.checkinsToday || 0) - yesterdayCheckins;
    const aiBriefing = `النهارده: ${dashboard?.checkinsToday || 0} دخول، ${delta >= 0 ? 'أكتر من أمس بـ' : 'أقل من أمس بـ'} ${Math.abs(delta)}. الإيرادات: ${dashboard?.revenueToday || 0} جنيه. ${newMembersToday} اشتراكات جديدة. ⚠️ ${inactive} عضو مش ظاهرين من أسبوع و${expiring7} اشتراكات قربت تخلص.`;
    return { aiEnabled: false, kpis: dashboard, aiBriefing, alerts: { inactive, expiring7, newMembersToday }, source: 'heuristic', confidence: 'medium' };
  }

  async smartPricingOffline(gymId: string) {
    const plans = await this.prisma.plan.findMany({ where: { gymId }, select: { id: true, name: true, price: true, type: true } });
    const dist = await this.prisma.member.groupBy({ by: ['planId'], where: { gymId, frozen: false }, _count: { planId: true } });
    const rows = plans.map((p) => ({ plan: p.name, price: Number(p.price || 0), type: p.type, members: (dist as { planId: string | null; _count: { planId: number } }[]).find((d) => d.planId === p.id)?._count.planId || 0 })).sort((a, b) => b.members - a.members);
    const top = rows[0];
    const weak = rows.at(-1);
    return { aiEnabled: false, currentState: { planDistribution: rows }, recommendation: top ? `باقة ${top.plan} شغالة كويس — جرّب تزود سعرها 5% للأعضاء الجدد بس.` : 'ضيف خطط أسعار واضحة عشان نقدر نحلل الأداء.', urgency: top && top.members > 20 ? 'medium' : 'low', reasoning: weak ? `باقة ${weak.plan} محتاجة bundle أو عرض لأنها الأقل مبيعاً.` : 'بيانات الأسعار محدودة.', source: 'heuristic', confidence: 'medium' };
  }

  async upsellTargetsOffline(gymId: string) {
    const members = await this.prisma.member.findMany({ where: { gymId, frozen: false }, select: { id: true, name: true, visits: true, startDate: true, sessionsLeft: true, plan: { select: { name: true, type: true } } }, take: 300 });
    const now = Date.now();
    const targets = members.map((m) => {
      const weeks = Math.max(1, Math.round((now - +new Date(m.startDate)) / (7 * 86400000)));
      const visitsPerWeek = Number(((m.visits || 0) / weeks).toFixed(2));
      const reason = m.plan?.type === 'SESSION' && (m.sessionsLeft || 0) <= 3 ? 'الحصص قربت تخلص' : visitsPerWeek >= 4 ? 'ملتزم جداً ومناسب للترقية' : 'ممكن تعرض عليه PT';
      return { id: m.id, name: m.name, plan: m.plan?.name || null, visitsPerWeek, sessionsLeft: m.sessionsLeft, reason, pitch: `يا ${m.name}، واضح إنك ملتزم 💪 عندنا عرض ترقية مناسب ليك يوفر عليك ويخليك تكمل بدون توقف.` };
    }).filter((m) => m.visitsPerWeek >= 3 || (m.sessionsLeft !== null && m.sessionsLeft <= 3)).sort((a, b) => b.visitsPerWeek - a.visitsPerWeek).slice(0, 25);
    return { aiEnabled: false, total: targets.length, targets, source: 'heuristic', confidence: 'medium' };
  }

  async retentionScoreOffline(gymId: string) {
    const members = await this.prisma.member.findMany({ where: { gymId, frozen: false }, select: { id: true, name: true, vip: true, visits: true, createdAt: true, lastVisit: true }, take: 2000 });
    const scores = members.map((m) => {
      const recency = m.lastVisit ? Math.max(0, 30 - Math.round((Date.now() - +new Date(m.lastVisit)) / 86400000)) : 0;
      const tenureDays = Math.max(1, Math.round((Date.now() - +new Date(m.createdAt)) / 86400000));
      const frequency = Math.min(30, ((m.visits || 0) / tenureDays) * 30);
      const score = Math.max(0, Math.min(100, Math.round(recency + frequency + (m.vip ? 20 : 0) + Math.min(20, tenureDays / 30))));
      return { id: m.id, name: m.name, score, explanation: score < 40 ? 'محتاج متابعة عشان الحضور أو التفاعل قليل' : 'مؤشر الاحتفاظ جيد' };
    });
    const distribution = { high: scores.filter((s) => s.score >= 70).length, medium: scores.filter((s) => s.score >= 40 && s.score < 70).length, low: scores.filter((s) => s.score < 40).length };
    return { aiEnabled: false, distribution, averageScore: scores.length ? Math.round(scores.reduce((sum, s) => sum + s.score, 0) / scores.length) : 0, scores: scores.sort((a, b) => a.score - b.score).slice(0, 50), source: 'heuristic', confidence: 'medium' };
  }

  async productInsightsOffline(gymId: string) {
    const products = await this.prisma.product.findMany({ where: { gymId }, orderBy: { qty: 'asc' }, take: 50 });
    const stockAlerts = products.filter((p) => p.qty <= p.lowStockThreshold || p.qty <= 5);
    return { aiEnabled: false, topProducts: [], stockAlerts, aiRecommendations: stockAlerts.map((p) => ({ productId: p.id, recommendation: `منتج ${p.name} مخزونه ${p.qty}. اطلب توريد قبل ما يخلص.` })), source: 'heuristic', confidence: 'medium' };
  }

  async dashboardSummaryOffline(gymId: string) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today.getTime() - 86400000);
    const [todayCheckins, yesterdayCheckins, revenueToday, inactive, expiring, newMembers] = await Promise.all([
      this.prisma.attendance.count({ where: { gymId, at: { gte: today } } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: yesterday, lt: today } } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: today } }, _sum: { amount: true } }),
      this.prisma.member.count({ where: { gymId, frozen: false, OR: [{ lastVisit: null }, { lastVisit: { lt: new Date(Date.now() - 7 * 86400000) } }] } }),
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: new Date(), lte: new Date(Date.now() + 7 * 86400000) } } }),
      this.prisma.member.count({ where: { gymId, createdAt: { gte: today } } }),
    ]);
    const change = todayCheckins - yesterdayCheckins;
    return {
      headline: `اليوم ${change >= 0 ? 'أحسن' : 'أهدى'} من أمس بـ ${Math.abs(change)} زيارة`,
      alerts: [
        inactive ? { type: 'warning', text: `${inactive} عضو مش شغالين من أسبوع` } : null,
        expiring ? { type: 'danger', text: `${expiring} اشتراكات قربت تخلص` } : null,
        newMembers ? { type: 'success', text: `${newMembers} اشتراكات جديدة النهارده` } : null,
      ].filter(Boolean),
      topSuggestion: expiring ? 'اعمل عرض تجديد للأعضاء اللي هيخلصوا الأسبوع ده' : 'تابع الحضور وشجع الأعضاء الغايبين برسالة ودية',
      data: { todayCheckins, yesterdayCheckins, revenueToday: Number(revenueToday._sum.amount || 0), inactive, expiring, newMembers },
      source: 'heuristic',
      confidence: 'medium',
    };
  }
}
