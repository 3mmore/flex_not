/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
export class AskAiDto {
  // SECURITY: length cap mitigates prompt-injection / cost-amplification abuse.
  @IsString() @MinLength(2) @MaxLength(500) question!: string;
  @IsOptional()
  @IsIn(['members', 'revenue', 'products', 'attendance', 'measurements', 'classes', 'pt'])
  context?: string;
}
