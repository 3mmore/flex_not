/**
 * FLEXORA Gym OS — proactive AI suggestions engine
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { Prisma } from '@prisma/client';

type SuggestionType = 'campaign' | 'revenue' | 'retention' | 'operations' | 'growth';
type SuggestionPriority = 'urgent' | 'high' | 'medium' | 'low';

type SuggestionInput = {
  type: SuggestionType;
  priority: SuggestionPriority;
  title: string;
  description: string;
  action: string;
  impact?: string;
  data: Record<string, unknown>;
};

@Injectable()
export class AiSuggestionsService {
  private readonly logger = new Logger(AiSuggestionsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly cronLeader: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  async getOrCreateDailySuggestions(gymId: string) {
    const now = new Date();
    const existing = await this.prisma.aiSuggestion.findMany({
      where: { gymId, dismissed: false, expiresAt: { gt: now } },
      orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }],
      take: 50,
    });
    if (existing.length) return existing;
    return this.generateDailySuggestions(gymId);
  }

  async generateDailySuggestions(gymId: string) {
    const suggestions = await this.buildDailySuggestions(gymId);
    const expiresAt = new Date(Date.now() + 7 * 86400000);
    await this.prisma.aiSuggestion.deleteMany({ where: { gymId, dismissed: false, actedUpon: false, expiresAt: { lt: new Date() } } });
    if (!suggestions.length) {
      suggestions.push({
        type: 'operations',
        priority: 'low',
        title: 'الجيم مستقر النهارده ✅',
        description: 'المؤشرات الأساسية شكلها مستقرة. كمل متابعة التجديدات والحضور اليومي.',
        action: 'راجع لوحة التحكم آخر اليوم واتأكد إن مفيش أعضاء قربوا يخلصوا من غير متابعة.',
        impact: 'يحافظ على جودة التشغيل ويمنع مشاكل صغيرة تكبر.',
        data: { generatedFallback: true },
      });
    }
    await this.prisma.aiSuggestion.createMany({
      data: suggestions.map((s) => ({ gymId, ...s, expiresAt, data: s.data as Prisma.InputJsonValue })),
    });
    return this.prisma.aiSuggestion.findMany({ where: { gymId, expiresAt }, orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }] });
  }

  async dismiss(gymId: string, id: string) {
    return this.prisma.aiSuggestion.updateMany({ where: { id, gymId }, data: { dismissed: true } });
  }

  async markActed(gymId: string, id: string) {
    return this.prisma.aiSuggestion.updateMany({ where: { id, gymId }, data: { actedUpon: true } });
  }

  @Cron('0 8 * * *', { name: 'ai-daily-analysis' })
  async dailyAiAnalysis() {
    return requestContext.run({ requestId: 'cron:ai-daily' }, async () => {
      const lock = await this.cronLeader.acquireLock('ai-daily-analysis', 3600000);
      if (!lock) return;
      try {
        const gyms = await this.prisma.gym.findMany({ where: { status: 'ACTIVE' }, select: { id: true } });
        for (const gym of gyms) {
          try {
            await this.tenantContext.run(gym.id, () => this.generateDailySuggestions(gym.id));
          } catch (e: unknown) {
            this.logger.warn(`AI daily analysis failed for gym ${gym.id}: ${(e as Error).message}`);
          }
        }
      } finally {
        await this.cronLeader.releaseLock('ai-daily-analysis');
      }
    });
  }

  @Cron('0 6 * * 1', { name: 'ai-weekly-deep-analysis' })
  async weeklyDeepAnalysis() {
    return requestContext.run({ requestId: 'cron:ai-weekly-deep' }, async () => {
      const lock = await this.cronLeader.acquireLock('ai-weekly-deep-analysis', 3600000);
      if (!lock) return;
      try {
        const gyms = await this.prisma.gym.findMany({ where: { status: 'ACTIVE' }, select: { id: true } });
        for (const gym of gyms) {
          await this.tenantContext.run(gym.id, async () => {
            const report = await this.weeklyReport(gym.id);
            await this.prisma.aiInsight.create({
              data: {
                gymId: gym.id,
                kind: 'weekly_deep_analysis',
                payload: report as Prisma.InputJsonValue,
                expiresAt: new Date(Date.now() + 30 * 86400000),
              },
            });
          });
        }
      } finally {
        await this.cronLeader.releaseLock('ai-weekly-deep-analysis');
      }
    });
  }

  private async buildDailySuggestions(gymId: string): Promise<SuggestionInput[]> {
    const now = new Date();
    const start7 = new Date(now.getTime() - 7 * 86400000);
    const prev7Start = new Date(now.getTime() - 14 * 86400000);
    const next7 = new Date(now.getTime() + 7 * 86400000);
    const inactiveSince = new Date(now.getTime() - 10 * 86400000);

    const [membersNow, membersPrev, rev7, revPrev7, attendance7, attendancePrev7, expiring, inactive, lowStock, classes] = await Promise.all([
      this.prisma.member.count({ where: { gymId } }),
      this.prisma.member.count({ where: { gymId, createdAt: { lt: start7 } } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start7 } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: prev7Start, lt: start7 } }, _sum: { amount: true } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: start7 } } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: prev7Start, lt: start7 } } }),
      this.prisma.member.findMany({ where: { gymId, frozen: false, expiry: { gte: now, lte: next7 } }, select: { id: true, name: true, expiry: true }, take: 50 }),
      this.prisma.member.findMany({ where: { gymId, frozen: false, OR: [{ lastVisit: null }, { lastVisit: { lt: inactiveSince } }] }, select: { id: true, name: true, lastVisit: true, mobile: true }, take: 50 }),
      this.prisma.product.findMany({ where: { gymId, qty: { lte: 5 } }, select: { id: true, name: true, qty: true }, take: 20 }),
      this.prisma.classSession.findMany({ where: { gymId, startsAt: { gte: start7 } }, include: { _count: { select: { bookings: true } }, template: { select: { name: true } } }, take: 50 }),
    ]);

    const suggestions: SuggestionInput[] = [];
    const revenue7 = Number(rev7._sum.amount || 0);
    const revenuePrev = Number(revPrev7._sum.amount || 0);
    const revenueDropPct = revenuePrev > 0 ? Math.round(((revenuePrev - revenue7) / revenuePrev) * 100) : 0;
    const attendanceDrop = attendancePrev7 > 0 ? Math.round(((attendancePrev7 - attendance7) / attendancePrev7) * 100) : 0;

    if (inactive.length >= 5) suggestions.push({
      type: 'retention', priority: inactive.length >= 20 ? 'urgent' : 'high',
      title: `${inactive.length} عضو مختفيين من أكتر من 10 أيام`,
      description: `في ${inactive.length} عضو مظهروش في الجيم بقالهم فترة. دول محتاجين متابعة سريعة قبل ما يبعدوا أكتر.`,
      action: 'ابعتلهم رسالة واتساب ودية مع عرض حصة مجانية أو قياس InBody.',
      impact: 'يرفع الرجوع للحضور ويقلل احتمالية إلغاء الاشتراك.',
      data: { inactiveCount: inactive.length, members: inactive.slice(0, 10).map((m) => ({ id: m.id, name: m.name, lastVisit: m.lastVisit })) },
    });

    if (revenueDropPct >= 10) suggestions.push({
      type: 'revenue', priority: revenueDropPct >= 20 ? 'urgent' : 'high',
      title: `إيرادات الأسبوع أقل بـ ${revenueDropPct}%`,
      description: `إيرادات آخر 7 أيام ${Math.round(revenue7)} جنيه مقابل ${Math.round(revenuePrev)} جنيه الأسبوع اللي فات.`,
      action: 'اعمل عرض تجديد 72 ساعة للأعضاء القريبين من الانتهاء وراجع مبيعات المنتجات اليومية.',
      impact: 'ممكن يرجّع جزء من الهبوط بسرعة من غير تغيير الأسعار الأساسية.',
      data: { revenue7, revenuePrev, revenueDropPct },
    });

    if (expiring.length > 0) suggestions.push({
      type: 'campaign', priority: expiring.length >= 10 ? 'high' : 'medium',
      title: `${expiring.length} اشتراك هيخلصوا الأسبوع ده`,
      description: 'دي فرصة ممتازة لحملة تجديد قبل ما العضو يختفي بعد الانتهاء.',
      action: 'جهز رسالة تجديد شخصية مع خصم صغير أو freeze مجاني لو جددوا بدري.',
      impact: 'يرفع معدل التجديد ويقلل الإيراد المفقود.',
      data: { expiringCount: expiring.length, members: expiring.slice(0, 10) },
    });

    if (attendanceDrop >= 15) suggestions.push({
      type: 'operations', priority: 'medium',
      title: `الحضور أقل بـ ${attendanceDrop}% عن الأسبوع اللي فات`,
      description: `الحضور الحالي ${attendance7} زيارة مقابل ${attendancePrev7} الأسبوع السابق.`,
      action: 'راجع مواعيد الذروة والكلاسات، واعمل تحدي حضور 7 أيام للأعضاء.',
      impact: 'يزود الالتزام ويقوي علاقة العضو بالجيم.',
      data: { attendance7, attendancePrev7, attendanceDrop },
    });

    const underused = classes.filter((c) => c.capacity > 0 && (c._count.bookings / c.capacity) < 0.4).slice(0, 5);
    if (underused.length) suggestions.push({
      type: 'operations', priority: 'low',
      title: 'في كلاسات مش مستغلة كويس',
      description: `${underused.length} كلاس أقل من 40% حجز. ممكن الوقت أو التسويق محتاجين تعديل.`,
      action: 'غيّر وقت الكلاس أو اعمل دعوة مجانية لأعضاء مهتمين بنفس النوع.',
      impact: 'يحسن استغلال المدربين والمساحة.',
      data: { classes: underused.map((c) => ({ id: c.id, name: c.template?.name, capacity: c.capacity, bookings: c._count.bookings })) },
    });

    if (lowStock.length) suggestions.push({
      type: 'operations', priority: 'medium',
      title: `${lowStock.length} منتج قرب يخلص`,
      description: 'في منتجات مخزونها قليل وممكن تضيع مبيعات POS لو ما اتعوضتش.',
      action: 'اطلب إعادة توريد للمنتجات قليلة المخزون النهارده.',
      impact: 'يحافظ على مبيعات المنتجات ويمنع نفاد المخزون.',
      data: { lowStock },
    });

    if (membersNow > membersPrev && revenueDropPct <= 0) suggestions.push({
      type: 'growth', priority: 'low',
      title: 'النمو ماشي كويس ✅',
      description: `عدد الأعضاء زاد من ${membersPrev} إلى ${membersNow} والإيراد مش نازل.`,
      action: 'كمل نفس قناة التسويق الحالية واطلب referrals من الأعضاء الجدد.',
      impact: 'يضاعف النمو بتكلفة أقل من الإعلانات.',
      data: { membersNow, membersPrev, revenue7, revenuePrev },
    });

    return suggestions;
  }

  private async weeklyReport(gymId: string) {
    const now = new Date();
    const start = new Date(now.getTime() - 7 * 86400000);
    const previous = new Date(now.getTime() - 14 * 86400000);
    const [revenue, revenuePrevious, newMembers, checkins, staffAttendance, inventoryLow] = await Promise.all([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: previous, lt: start } }, _sum: { amount: true } }),
      this.prisma.member.count({ where: { gymId, createdAt: { gte: start } } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: start } } }),
      this.prisma.staffAttendance.count({ where: { gymId, checkInAt: { gte: start } } }),
      this.prisma.product.count({ where: { gymId, qty: { lte: 5 } } }),
    ]);
    return {
      revenue: Number(revenue._sum.amount || 0),
      revenuePrevious: Number(revenuePrevious._sum.amount || 0),
      newMembers,
      checkins,
      staffAttendance,
      inventoryLow,
      generatedAt: new Date().toISOString(),
      source: 'heuristic',
    };
  }
}
