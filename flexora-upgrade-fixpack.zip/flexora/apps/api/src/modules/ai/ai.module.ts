/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AiService } from './ai.service';
import { AiController } from './ai.controller';
import { AiBrainService } from './ai-brain.service';
import { ReportsService } from '../reports/reports.service';
import { AiSuggestionsService } from './ai-suggestions.service';
import { AiOfflineService } from './ai-offline.service';
import { AiQuotaService } from './ai-quota.service';
import { AiConfigService } from './ai-config.service';
import { AiConfigController } from './ai-config.controller';
import { SecurityModule } from '../../common/security/security.module';

@Module({
  imports: [JwtModule.register({}), SecurityModule],
  controllers: [AiConfigController, AiController],
  providers: [AiService, AiBrainService, AiSuggestionsService, AiOfflineService, ReportsService, AiQuotaService, AiConfigService],
  exports: [AiBrainService, AiService, AiQuotaService, AiConfigService],
})
export class AiModule {}
