/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { AiService } from './ai.service';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';

const redisMock = { get: jest.fn().mockResolvedValue(null), set: jest.fn(), del: jest.fn() } as any as RedisService;
const day = 86400000;

function svcWith(members: any[]) {
  const prisma = { member: { findMany: jest.fn().mockResolvedValue(members) } } as any as PrismaService;
  return new AiService(prisma, redisMock);
}

describe('AiService.churnRisk classification', () => {
  beforeEach(() => { delete process.env.AI_ENABLED; delete process.env.ANTHROPIC_API_KEY; });

  it('classifies HIGH / MEDIUM / LOW correctly and degrades when AI disabled', async () => {
    const now = Date.now();
    const members = [
      // HIGH: idle > 14 days
      { id: 'h', name: 'High', mobile: '1', vip: false, visits: 2, sessionsLeft: null,
        startDate: new Date(now - 100 * day), lastVisit: new Date(now - 20 * day),
        expiry: new Date(now + 30 * day), plan: { type: 'TIME', name: '3M' } },
      // MEDIUM: idle 7-14 days
      { id: 'm', name: 'Med', mobile: '2', vip: false, visits: 5, sessionsLeft: null,
        startDate: new Date(now - 100 * day), lastVisit: new Date(now - 10 * day),
        expiry: new Date(now + 30 * day), plan: { type: 'TIME', name: '3M' } },
      // LOW: recent, frequent
      { id: 'l', name: 'Low', mobile: '3', vip: true, visits: 90, sessionsLeft: null,
        startDate: new Date(now - 100 * day), lastVisit: new Date(now - 1 * day),
        expiry: new Date(now + 60 * day), plan: { type: 'TIME', name: '12M' } },
      // MEDIUM via sessionsLeft <= 2
      { id: 's', name: 'Sess', mobile: '4', vip: false, visits: 12, sessionsLeft: 1,
        startDate: new Date(now - 30 * day), lastVisit: new Date(now - 2 * day),
        expiry: null, plan: { type: 'SESSION', name: '15S' } },
    ];
    const r = await svcWith(members).churnRisk('gym1');
    expect(r.aiEnabled).toBe(false);
    expect(r.summary).toEqual({ high: 1, medium: 2, low: 1 });
    expect(r.highRisk[0].name).toBe('High');
    // graceful fallback message still present
    expect(typeof r.highRisk[0].aiMessage).toBe('string');
    expect(r.highRisk[0].aiMessage.length).toBeGreaterThan(0);
  });

  it('respects limit/offset pagination on highRisk', async () => {
    const now = Date.now();
    const members = Array.from({ length: 5 }, (_, i) => ({
      id: 'x' + i, name: 'M' + i, mobile: '0', vip: false, visits: 1, sessionsLeft: null,
      startDate: new Date(now - 100 * day), lastVisit: new Date(now - 30 * day),
      expiry: new Date(now + 30 * day), plan: { type: 'TIME', name: '3M' },
    }));
    const r = await svcWith(members).churnRisk('gym1', 2, 0);
    expect(r.total).toBe(5);
    expect(r.highRisk.length).toBe(2);
  });
});

describe('AiService graceful fallback', () => {
  it('ask_ returns aiEnabled:false when key missing', async () => {
    delete process.env.ANTHROPIC_API_KEY;
    const prisma = { member: { findMany: jest.fn().mockResolvedValue([]) } } as any as PrismaService;
    const svc = new AiService(prisma, redisMock);
    const r = await svc.ask_('gym1', 'كام عضو عندي؟', 'members');
    expect(r.aiEnabled).toBe(false);
    expect(r.answer).toMatch(/ANTHROPIC_API_KEY/);
  });
});

describe('AiService.detectContext', () => {
  const svc = new AiService({} as any as PrismaService, redisMock);
  // accessing private method for testing
  const detect = (q: string) => (svc as any as { detectContext: (q: string) => string }).detectContext(q);

  it('Arabic + English revenue keywords', () => {
    expect(detect('إيه إيرادي؟')).toBe('revenue');
    expect(detect('show me revenue')).toBe('revenue');
  });
  it('products / attendance / measurements / classes / pt', () => {
    expect(detect('المخزون قليل؟')).toBe('products');
    expect(detect('who attended today')).toBe('attendance');
    expect(detect('مين فقد وزن؟')).toBe('measurements');
    expect(detect('which class is busiest')).toBe('classes');
    expect(detect('coach performance')).toBe('pt');
  });
  it('defaults to members', () => {
    expect(detect('random question')).toBe('members');
  });
});
