/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger, Optional } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from './notifications.service';
import { SmsService } from './sms.service';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

/**
 * Automated renewal reminders:
 *  - Time-based plans: D-7 / D-3 / D-1 / D-0 before expiry.
 *  - Session-based plans: when sessionsLeft is 3 or 1.
 * A member receives at most ONE reminder per cron run (dedup by member id).
 *
 * Outbound proactive messages use whatsappTemplate() (template-safe), with a
 * graceful fallback to plain whatsapp() when no template is configured for the
 * environment (e.g. local/dev), so the flow always works end-to-end.
 */
@Injectable()
export class RemindersService {
  private readonly logger = new Logger('Reminders');

  // Approved template names (configure these in WhatsApp Business Manager).
  private readonly RENEWAL_TEMPLATE = process.env.WA_TEMPLATE_RENEWAL || '';
  private readonly SESSION_TEMPLATE = process.env.WA_TEMPLATE_SESSION || '';

  constructor(
    private readonly prisma: PrismaService,
    private readonly notify: NotificationsService,
    private readonly sms: SmsService,
    private readonly cronLeadership: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
    @Optional() private readonly redis?: RedisService,
  ) {}

  @Cron(CronExpression.EVERY_DAY_AT_9AM)
  async run() {
    return requestContext.run({ requestId: 'cron:reminders' }, async () => {
      if (!(await this.cronLeadership.acquireLock('reminders-daily', 3600_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({
          where: { status: 'ACTIVE' },
          select: { id: true },
          take: 5000,
        });
        for (const gym of gyms) {
          await this.tenantContext.run(gym.id, async () => {
        const notified = new Set<string>(); // member ids already messaged this run
        let expiryCount = 0;
        let sessionCount = 0;

        // ---- 1) Time-based expiry reminders: D-7 / D-3 / D-1 / D-0 ----
        for (const days of [7, 3, 1, 0]) {
          const from = new Date(); from.setHours(0, 0, 0, 0); from.setDate(from.getDate() + days);
          const to = new Date(from); to.setHours(23, 59, 59, 999);
          const members = await this.prisma.member.findMany({
            where: { gymId: gym.id, frozen: false, expiry: { gte: from, lte: to } },
            take: 500,
          });
          for (const m of members) {
            if (notified.has(m.id)) continue;
            const label = days === 0 ? 'today' : `in ${days} day(s)`;
            const fallback = `Hi ${m.name}, your membership expires ${label}. Renew now to keep training!`;
            await this.sendRenewal(m.gymId, m.mobile, m.name, label, fallback);
            notified.add(m.id);
            expiryCount++;
          }
        }

        // ---- 2) Session-based alerts: sessionsLeft IN (3, 1) ----
        const sessionMembers = await this.prisma.member.findMany({
          where: { gymId: gym.id, frozen: false, sessionsLeft: { in: [3, 1] } },
          take: 500,
        });
        for (const m of sessionMembers) {
          if (notified.has(m.id)) continue;
          const left = m.sessionsLeft ?? 0;
          const fallback = `Hi ${m.name}, you have ${left} session(s) left. Renew now to keep training!`;
          await this.sendSession(m.gymId, m.mobile, m.name, String(left), fallback);
          notified.add(m.id);
          sessionCount++;
        }

        this.logger.log(`Reminders sent for gym=${gym.id} — expiry: ${expiryCount}, session: ${sessionCount}`);
          });
        }
      } finally {
        await this.cronLeadership.releaseLock('reminders-daily');
      }
    });
  }

  private async sendRenewal(
    gymId: string, to: string, name: string, when: string, fallback: string,
  ) {
    if (this.RENEWAL_TEMPLATE) {
      await this.notify.whatsappTemplate(gymId, to, this.RENEWAL_TEMPLATE, [
        { type: 'body', parameters: [
          { type: 'text', text: name },
          { type: 'text', text: when },
        ] },
      ]);
    } else {
      await this.notify.whatsapp(gymId, to, fallback);
    }
    // Additive: also SMS when configured — some members only respond to SMS.
    if (this.sms.configured) await this.sms.sms(gymId, to, fallback);
  }

  private async sendSession(
    gymId: string, to: string, name: string, left: string, fallback: string,
  ) {
    if (this.SESSION_TEMPLATE) {
      await this.notify.whatsappTemplate(gymId, to, this.SESSION_TEMPLATE, [
        { type: 'body', parameters: [
          { type: 'text', text: name },
          { type: 'text', text: left },
        ] },
      ]);
    } else {
      await this.notify.whatsapp(gymId, to, fallback);
    }
    if (this.sms.configured) await this.sms.sms(gymId, to, fallback);
  }
}
