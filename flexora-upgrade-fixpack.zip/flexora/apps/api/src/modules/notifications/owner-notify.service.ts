/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from './notifications.service';
import { EncryptionService } from '../../common/security/encryption.service';

@Injectable()
export class OwnerNotifyService {
  private readonly logger = new Logger('OwnerNotify');

  constructor(
    private prisma: PrismaService,
    private notifications: NotificationsService,
    private encryption: EncryptionService,
  ) {}

  async getNotifications(gymId: string, limit = 50, unreadOnly = false) {
    const notifs = await this.prisma.ownerNotification.findMany({
      where: {
        gymId,
        ...(unreadOnly ? { isRead: false } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: Math.min(Number(limit) || 50, 100),
    });

    return notifs.map((notif) => {
      const decryptedMeta = notif.metadata
        ? (() => {
            try {
              return JSON.parse(
                this.encryption.decrypt(notif.metadata as string)
              );
            } catch {
              return notif.metadata; // fallback for unencrypted legacy data
            }
          })()
        : null;
      return { ...notif, metadata: decryptedMeta };
    });
  }

  // ─── Core method ───────────────────────

  async notify(params: {
    gymId: string;
    type: string;
    title: string;
    body: string;
    icon?: string;
    severity?: 'info'|'warning'|'danger'|'success';
    metadata?: Record<string, unknown>;
    sendWhatsApp?: boolean;
  }): Promise<void> {
    const {
      gymId, type, title, body,
      icon = 'info',
      severity = 'info',
      metadata,
      sendWhatsApp = true,
    } = params;

    try {
      const encryptedMeta = metadata
        ? this.encryption.encrypt(JSON.stringify(metadata))
        : undefined;

      // 1. Save to DB (always)
      await this.prisma.ownerNotification.create({
        data: {
          gymId, type, title, body,
          icon, severity,
          metadata: encryptedMeta
            ? (encryptedMeta as unknown as Prisma.InputJsonValue)
            : Prisma.JsonNull,
        },
      });

      // 2. WhatsApp (if enabled)
      if (sendWhatsApp) {
        const gym = await this.prisma.gym
          .findUnique({
            where: { id: gymId },
            select: {
              antiTheftEnabled: true,
              ownerPersonalMobile: true,
            },
          });

        if (!gym?.antiTheftEnabled) return;

        // Use personal mobile first,
        // fallback to owner account mobile if available
        let mobile = gym.ownerPersonalMobile;

        if (!mobile) {
          try {
            const owner = await (this.prisma as any).user
              .findFirst({
                where: { gymId, role: 'OWNER' },
                select: { id: true },
              });
            // User.mobile not in schema in this version – rely on gym.ownerPersonalMobile
            void owner;
          } catch {}
        }

        if (mobile) {
          const wa =
            `${this.severityEmoji(severity)}`  +
            `*${title}*\n\n${body}\n\n` +
            `🕐 ${new Date()
              .toLocaleString('ar-EG')}`;

          await this.notifications.whatsapp(
            gymId, mobile, wa);
        }
      }
    } catch (e) {
      this.logger.error(
        `Owner notify failed:`  +
        `${(e as Error).message}`);
    }
  }

  private severityEmoji(
    severity: string): string {
    const map: Record<string, string> = {
      danger:  '🚨',
      warning: '⚠️',
      success: '✅',
      info:    'ℹ️',
    };
    return map[severity] ?? 'ℹ️';
  }

  // ─── Shortcut methods ──────────────────

  async notifySale(gymId: string, data: {
    staffName: string;
    memberName: string;
    amount: number;
    paymentMethod: string;
    discount: number;
    originalAmount: number;
    invoiceId: string;
  }): Promise<void> {
    const gym = await this.prisma.gym
      .findUnique({
        where: { id: gymId },
        select: {
          notifyOnSale: true,
          notifyOnDiscount: true,
          maxDiscountAlert: true,
          maxCashAlert: true,
          name: true,
        },
      });

    if (!gym) return;

    const discountPct = data.originalAmount > 0
      ? Math.round(
          (data.discount / data.originalAmount)
          * 100)
      : 0;

    const isHighDiscount =
      discountPct > (gym.maxDiscountAlert ?? 30);

    const isHighCash =
      data.paymentMethod === 'CASH' &&
      data.amount > (gym.maxCashAlert ?? 500);

    // Always notify on high discount/cash (danger)
    if (isHighDiscount || isHighCash) {
      const warnings: string[] = [];
      if (isHighDiscount) warnings.push(
        `خصم ${discountPct}%`  +
        `(أعلى من الحد المسموح)`);
      if (isHighCash) warnings.push(
        `كاش ${data.amount} ج`  +
        `(أعلى من الحد المسموح)`);

      await this.notify({
        gymId,
        type: 'SALE_ALERT',
        title: '🚨 تنبيه مبيعات',
        body:
          `الموظف: ${data.staffName}\n` +
          `العضو: ${data.memberName}\n` +
          `المبلغ: ${data.amount} ج\n` +
          `طريقة الدفع: ${data.paymentMethod}\n`+
          `⚠️ ${warnings.join(' | ')}\n` +
          `رقم الفاتورة: ${data.invoiceId}`,
        icon: 'alert',
        severity: 'danger',
        metadata: data as
          Record<string, unknown>,
      });

      return;
    }

    // Normal sale notification
    if (!gym.notifyOnSale) return;

    await this.notify({
      gymId,
      type: 'SALE',
      title: '💰 مبيعة جديدة',
      body:
        `الموظف: ${data.staffName}\n` +
        `العضو: ${data.memberName}\n` +
        `المبلغ: ${data.amount} ج\n` +
        `طريقة الدفع: ${data.paymentMethod}`,
      icon: 'coins',
      severity: 'success',
      metadata: data as Record<string, unknown>,
      sendWhatsApp: false, // only in dashboard
    });
  }

  async notifyNewMember(gymId: string, data: {
    memberName: string;
    mobile: string;
    planName: string;
    staffName: string;
    branchName?: string;
  }): Promise<void> {
    const gym = await this.prisma.gym
      .findUnique({
        where: { id: gymId },
        select: { notifyOnMemberAdd: true },
      });

    if (!gym?.notifyOnMemberAdd) return;

    // FIX (P3: notifications lack branch context): include branch if provided
    const branchLine = data.branchName ? `الفرع: ${data.branchName}\n` : '';

    await this.notify({
      gymId,
      type: 'MEMBER_NEW',
      title: '🆕 عضو جديد',
      body:
        `الاسم: ${data.memberName}\n` +
        `الموبايل: ${data.mobile}\n` +
        `الخطة: ${data.planName}\n` +
        branchLine +
        `سجّله: ${data.staffName}`,
      icon: 'users',
      severity: 'success',
      metadata: data as Record<string, unknown>,
      sendWhatsApp: false,
    });
  }

  async notifyMemberDeleted(gymId: string, data:{
    memberName: string;
    mobile: string;
    deletedBy: string;
  }): Promise<void> {
    const gym = await this.prisma.gym
      .findUnique({
        where: { id: gymId },
        select: { notifyOnMemberDelete: true },
      });

    if (!gym?.notifyOnMemberDelete) return;

    await this.notify({
      gymId,
      type: 'MEMBER_DELETED',
      title: '🗑️ تم حذف عضو',
      body:
        `الاسم: ${data.memberName}\n` +
        `الموبايل: ${data.mobile}\n` +
        `حذفه: ${data.deletedBy}`,
      icon: 'x',
      severity: 'danger',
      metadata: data as Record<string, unknown>,
    });
  }

  async notifyRefund(gymId: string, data: {
    staffName: string;
    amount: number;
    reason: string;
    invoiceId: string;
  }): Promise<void> {
    const gym = await this.prisma.gym
      .findUnique({
        where: { id: gymId },
        select: { notifyOnRefund: true },
      });

    if (!gym?.notifyOnRefund) return;

    await this.notify({
      gymId,
      type: 'REFUND',
      title: '💸 استرداد / إلغاء فاتورة',
      body:
        `الموظف: ${data.staffName}\n` +
        `المبلغ: ${data.amount} ج\n` +
        `السبب: ${data.reason || 'غير محدد'}\n`+
        `رقم الفاتورة: ${data.invoiceId}`,
      icon: 'alert',
      severity: 'warning',
      metadata: data as Record<string, unknown>,
    });
  }

  async notifyRenewal(gymId: string, data: {
    memberName: string;
    planName: string;
    amount: number;
    staffName: string;
    branchName?: string;
  }): Promise<void> {
    // FIX (P3: notifications lack branch context): include branch if provided
    const branchLine = data.branchName ? `الفرع: ${data.branchName}\n` : '';

    await this.notify({
      gymId,
      type: 'RENEWAL',
      title: '🔄 تجديد اشتراك',
      body:
        `العضو: ${data.memberName}\n` +
        `الخطة: ${data.planName}\n` +
        `المبلغ: ${data.amount} ج\n` +
        branchLine +
        `جدّده: ${data.staffName}`,
      icon: 'check',
      severity: 'success',
      metadata: data as Record<string, unknown>,
      sendWhatsApp: false,
    });
  }

  async notifySuspiciousActivity(
    gymId: string,
    data: {
      description: string;
      staffName: string;
      details: string;
    }
  ): Promise<void> {
    await this.notify({
      gymId,
      type: 'SUSPICIOUS',
      title: '🚨 نشاط مريب',
      body:
        `${data.description}\n` +
        `الموظف: ${data.staffName}\n` +
        `التفاصيل: ${data.details}`,
      icon: 'shield',
      severity: 'danger',
      metadata: data as Record<string, unknown>,
    });
  }

  async migrateUnencryptedMetadata(): Promise<void> {
    const notifications = await this.prisma.ownerNotification.findMany({
      where: { metadata: { not: Prisma.JsonNull } },
      select: { id: true, metadata: true },
      take: 5000,
    });
    let migrated = 0;
    for (const notif of notifications) {
      if (typeof notif.metadata !== 'string') continue;
      // Check if already encrypted (encrypted strings won't be valid JSON)
      try {
        JSON.parse(notif.metadata as string);
        // If we get here, it's plaintext JSON — needs encryption
        const encrypted = this.encryption.encrypt(notif.metadata as string);
        await this.prisma.ownerNotification.update({
          where: { id: notif.id },
          data: { metadata: encrypted as unknown as Prisma.InputJsonValue },
        });
        migrated++;
      } catch {
        // Already encrypted — skip
      }
    }
    if (migrated > 0) {
      this.logger.log(
        `Metadata migration: encrypted ${migrated} legacy records.`
      );
    }
  }
}
