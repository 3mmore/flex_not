/**
 * FLEXORA Gym OS — per-gym messaging config DTO
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsArray, IsBoolean, IsIn, IsInt, IsOptional, IsString, IsUrl, Matches, Max, Min } from 'class-validator';
import { Type } from 'class-transformer';

export class UpdateMessagingConfigDto {
  @IsOptional() @IsString() whatsappPhoneId?: string;
  @IsOptional() @IsString() whatsappToken?: string;
  @IsOptional() @IsBoolean() whatsappEnabled?: boolean;
  @IsOptional() @IsUrl({ protocols: ['https'], require_protocol: true }) whatsappUrl?: string;
  @IsOptional() @IsArray() @IsString({ each: true }) whatsappTemplates?: string[];
  @IsOptional() @IsBoolean() aiAutoReply?: boolean;
  @IsOptional() @IsString() aiAutoReplyHours?: string;

  @IsOptional() @IsIn(['vonage', 'twilio', 'custom']) smsProvider?: string;
  @IsOptional() @IsString() smsApiKey?: string;
  @IsOptional() @IsString() smsApiSecret?: string;
  @IsOptional() @IsString() smsFrom?: string;
  @IsOptional() @IsBoolean() smsEnabled?: boolean;

  @IsOptional() @IsString() @Matches(/^(?!(?:https?:\/\/)?(?:10\.|172\.(?:1[6-9]|2[0-9]|3[01])\.|192\.168\.|127\.|169\.254\.|localhost))/i) smtpHost?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(65535) smtpPort?: number;
  @IsOptional() @IsString() smtpUser?: string;
  @IsOptional() @IsString() smtpPass?: string;
  @IsOptional() @IsString() smtpFrom?: string;
  @IsOptional() @IsBoolean() smtpEnabled?: boolean;
}
