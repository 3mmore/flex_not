/**
 * FLEXORA Gym OS — messaging webhooks
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, ForbiddenException, Get, Headers, Post, Query, Req } from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'crypto';
import { ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import type { Request } from 'express';
import { Public } from '../../common/decorators/public.decorator';
import { PrismaService } from '../../config/prisma.service';
import { GymMessagingService } from './gym-messaging.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { Prisma } from '@prisma/client';

@ApiTags('webhooks')
@Controller('webhooks')
export class WebhookController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly gymMessaging: GymMessagingService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private verifySignature(rawBody: Buffer | string | undefined, signature?: string): boolean {
    const secret = process.env.WHATSAPP_APP_SECRET;
    if (!secret) return false;
    if (!signature || !rawBody) return false;
    const expected = 'sha256=' + createHmac('sha256', secret).update(rawBody).digest('hex');
    const a = Buffer.from(expected);
    const b = Buffer.from(signature);
    return a.length === b.length && timingSafeEqual(a, b);
  }

  private verifyToken(actualToken?: string) {
    const expectedValue = process.env.WHATSAPP_VERIFY_TOKEN || '';
    if (!expectedValue) return false;
    const expected = Buffer.from(expectedValue, 'utf8');
    const actual = Buffer.from(actualToken || '', 'utf8');
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  }

  @Public()
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @Post('whatsapp')
  async whatsappWebhook(@Body() body: Record<string, any>, @Headers('x-hub-signature-256') signature: string | undefined, @Req() req: Request & { rawBody?: Buffer }) {
    // Meta signs callback POSTs with X-Hub-Signature-256. The verify token is
    // used only during the GET subscription handshake and is not sent on POST.
    if (!this.verifySignature(req.rawBody, signature)) throw new ForbiddenException('Invalid verification');
    const entry = (body?.entry as Record<string, any>[])?.[0];
    const changes = (entry?.changes as Record<string, any>[])?.[0];
    const value = changes?.value;
    const phoneId = value?.metadata?.phone_number_id as string | undefined;
    const message = (value?.messages as Record<string, any>[])?.[0];
    if (!phoneId || !message) return { status: 'ignored' };

    const tenantRows = await this.prisma.$queryRaw<Array<{ gymId: string | null }>>(
      Prisma.sql`SELECT public_messaging_gym_id(${phoneId}) AS "gymId"`,
    );
    const gymId = tenantRows[0]?.gymId;
    if (!gymId) return { status: 'unknown_gym' };

    return this.tenantContext.run(gymId, async () => {
    const config = await this.prisma.gymMessagingConfig.findFirst({ where: { gymId, whatsappPhoneId: phoneId } });
    if (!config) return { status: 'unknown_gym' };
    const bodyText = message.text?.body || '[non-text message]';
    await this.prisma.notification.create({
      data: {
        gymId: config.gymId,
        channel: 'WHATSAPP_INBOUND',
        to: config.whatsappPhoneId || phoneId,
        from: message.from,
        body: bodyText,
        status: 'RECEIVED',
        sentAt: new Date(),
      },
    });

    if (config.aiAutoReply && this.withinAutoReplyHours(config.aiAutoReplyHours)) {
      const reply = await this.buildAutoReply(config.gymId, message.from, bodyText);
      const result = await this.gymMessaging.sendWhatsAppText(config.gymId, message.from, reply, false);
      await this.prisma.notification.create({
        data: {
          gymId: config.gymId,
          channel: 'WHATSAPP',
          to: message.from,
          body: reply,
          status: result.success ? 'SENT' : 'FAILED',
          error: result.error,
          sentAt: result.success ? new Date() : undefined,
        },
      });
      return { status: 'received', autoReply: result.success ? 'sent' : 'failed' };
    }

    return { status: 'received' };
    });
  }

  @Public()
  @Get('whatsapp')
  verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
  ) {
    if (mode === 'subscribe' && this.verifyToken(token)) return challenge;
    throw new ForbiddenException('Invalid verification');
  }

  private withinAutoReplyHours(window: string) {
    const [start, end] = (window || '08:00-22:00').split('-');
    const now = new Date();
    const mins = now.getHours() * 60 + now.getMinutes();
    const parse = (value: string) => {
      const [h, m] = value.split(':').map((x) => Number(x));
      return h * 60 + (m || 0);
    };
    return mins >= parse(start || '08:00') && mins <= parse(end || '22:00');
  }

  private async buildAutoReply(gymId: string, from: string, text: string) {
    const digits = from.replace(/\D/g, '').slice(-10);
    const member = digits ? await this.prisma.member.findFirst({ where: { gymId, mobile: { contains: digits } }, include: { plan: true } }) : null;
    const q = text.toLowerCase();
    if (/سعر|price|اشتراك|membership|باقات/.test(q)) {
      const plans = await this.prisma.plan.findMany({ where: { gymId }, select: { name: true, price: true }, take: 5 });
      if (plans.length) return `أهلاً بيك 👋 الباقات المتاحة: ${plans.map((p) => `${p.name}: ${p.price} جنيه`).join('، ')}. لو تحب تفاصيل أكتر هيرد عليك الفريق.`;
    }
    if (/ميعاد|schedule|كلاس|class/.test(q)) return 'أهلاً 👋 ابعتلنا نوع التمرين أو الكلاس اللي مهتم بيه، والفريق هيأكدلك أقرب مواعيد متاحة.';
    if (/مكان|location|عنوان|address/.test(q)) return 'أهلاً 👋 ابعتلنا منطقتك وهنبعتلك اللوكيشن وأقرب فرع مناسب ليك.';
    if (member) {
      const expiry = member.expiry ? new Date(member.expiry).toLocaleDateString('ar-EG') : 'غير محدد';
      return `أهلاً يا ${member.name} 👋 اشتراكك على باقة ${member.plan?.name || 'الجيم'}، وتاريخ الانتهاء: ${expiry}. لو محتاج تجديد أو تجميد، الفريق هيتابع معاك.`;
    }
    return 'أهلاً بيك 👋 وصلت رسالتك. لو السؤال بسيط هساعدك هنا، ولو محتاج إجراء على الاشتراك هيرد عليك حد من الفريق في أقرب وقت.';
  }
}
