import { Controller, Get, Patch, Delete, Param, Query, UseGuards, ParseIntPipe, DefaultValuePipe } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Throttle } from '@nestjs/throttler';
import { OwnerNotifyService } from './owner-notify.service';

@Controller('owner/notifications')
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Throttle({ default: { limit: 60, ttl: 60000 } })
export class OwnerNotifyController {
  constructor(private prisma: PrismaService, private svc: OwnerNotifyService) {}

  @Get()
  @Roles('OWNER', 'MANAGER')
  async getAll(
    @GymId() gymId: string,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number = 50,
    @Query('unreadOnly') unreadOnly = 'false',
  ) {
    return this.svc.getNotifications(gymId, limit, unreadOnly === 'true');
  }

  @Get('unread-count')
  @Roles('OWNER', 'MANAGER')
  async getUnreadCount(@GymId() gymId: string) {
    const count = await this.prisma.ownerNotification.count({
      where: { gymId, isRead: false },
    });
    return { count };
  }

  @Patch('read-all')
  @Roles('OWNER', 'MANAGER')
  async markAllRead(@GymId() gymId: string) {
    return this.prisma.ownerNotification.updateMany({
      where: { gymId, isRead: false },
      data: { isRead: true },
    });
  }

  @Patch(':id/read')
  @Roles('OWNER', 'MANAGER')
  async markRead(
    @Param('id') id: string,
    @GymId() gymId: string,
  ) {
    return this.prisma.ownerNotification.updateMany({
      where: { id, gymId },
      data: { isRead: true },
    });
  }

  @Delete('old')
  @Roles('OWNER', 'MANAGER')
  async deleteOld(@GymId() gymId: string) {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    return this.prisma.ownerNotification.deleteMany({
      where: {
        gymId,
        isRead: true,
        createdAt: { lt: thirtyDaysAgo },
      },
    });
  }
}
