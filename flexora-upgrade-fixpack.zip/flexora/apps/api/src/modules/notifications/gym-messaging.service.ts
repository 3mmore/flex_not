/**
 * FLEXORA Gym OS — per-gym messaging credentials and senders
 * © 2024 Ammar Allam. All rights reserved.
 */
import { ConflictException, Injectable, Logger } from '@nestjs/common';
import { randomBytes } from 'crypto';
import * as nodemailer from 'nodemailer';
import { PrismaService } from '../../config/prisma.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { UpdateMessagingConfigDto } from './dto/messaging-config.dto';
import { Prisma } from '@prisma/client';
import { assertAllowedWhatsAppBaseUrl } from '../../common/security/outbound-url.util';

/**
 * PHASE N2 — the field(s) a Prisma P2002 (unique constraint) violation is about.
 *
 * Prisma 5.22 reports `meta.target` as an ARRAY of column names for a
 * multi-column-aware client, as a comma-joined string in older shapes, and —
 * the lesson PHASE N1.5 paid for with P2003 — sometimes leaves `meta` empty,
 * with the constraint named only inside the message. All three are handled so
 * the caller can answer a precise, translated 409 instead of an opaque
 * "unique_constraint_violation" (or a 500 wherever the global
 * HttpExceptionFilter is not registered, e.g. inside test apps).
 */
function uniqueViolationFields(err: unknown): string[] {
  const e = err as { code?: string; meta?: { target?: unknown }; message?: string };
  if (e?.code !== 'P2002') return [];
  const target = e.meta?.target;
  if (Array.isArray(target)) return target.map(String);
  if (typeof target === 'string' && target.trim()) {
    return target.split(',').map((part) => part.trim()).filter(Boolean);
  }
  const fromMessage = /Unique constraint failed on the fields?:\s*\(([^)]*)\)/i.exec(e.message || '');
  if (fromMessage) {
    return fromMessage[1]
      .split(',')
      .map((part) => part.trim().replace(/^[`"]|[`"]$/g, ''))
      .filter(Boolean);
  }
  // A P2002 we cannot attribute: still a conflict, just an unnamed one.
  return ['<unknown>'];
}

type MessagingResult = { success: boolean; error?: string; provider?: string };

@Injectable()
export class GymMessagingService {
  private readonly logger = new Logger(GymMessagingService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  getConfig(gymId: string) {
    return this.prisma.gymMessagingConfig.findUnique({ where: { gymId } });
  }

  async getMaskedConfig(gymId: string) {
    const config = await this.getConfig(gymId);
    if (!config) return { configured: false };
    return {
      ...config,
      configured: true,
      whatsappToken: config.whatsappToken ? this.mask(await this.safeDecrypt(config.whatsappToken)) : null,
      smsApiKey: config.smsApiKey ? this.mask(await this.safeDecrypt(config.smsApiKey)) : null,
      smsApiSecret: config.smsApiSecret ? '****' : null,
      smtpPass: config.smtpPass ? '****' : null,
    };
  }

  async updateConfig(gymId: string, dto: UpdateMessagingConfigDto) {
    const data: Record<string, unknown> = {
      gymId,
    };
    const assign = (key: keyof UpdateMessagingConfigDto) => {
      if (dto[key] !== undefined) data[key] = dto[key];
    };
    for (const key of [
      'whatsappPhoneId', 'whatsappEnabled', 'smsProvider', 'smsFrom', 'smsEnabled',
      'smtpHost', 'smtpPort', 'smtpUser', 'smtpFrom', 'smtpEnabled', 'aiAutoReply', 'aiAutoReplyHours',
    ] as Array<keyof UpdateMessagingConfigDto>) assign(key);
    if (dto.whatsappUrl !== undefined) {
      data.whatsappUrl = assertAllowedWhatsAppBaseUrl(dto.whatsappUrl);
    }
    if (dto.whatsappTemplates !== undefined) data.whatsappTemplates = dto.whatsappTemplates as Prisma.InputJsonValue;
    const existing = await this.getConfig(gymId);
    if ((dto.whatsappPhoneId || dto.whatsappToken) && !existing?.whatsappVerifyToken) data.whatsappVerifyToken = randomBytes(16).toString('hex');
    if (dto.whatsappToken) data.whatsappToken = this.encryption.encrypt(dto.whatsappToken);
    if (dto.smsApiKey) data.smsApiKey = this.encryption.encrypt(dto.smsApiKey);
    if (dto.smsApiSecret) data.smsApiSecret = this.encryption.encrypt(dto.smsApiSecret);
    if (dto.smtpPass) data.smtpPass = this.encryption.encrypt(dto.smtpPass);
    try {
      await this.prisma.gymMessagingConfig.upsert({ where: { gymId }, update: data as Prisma.GymMessagingConfigUpdateInput, create: data as Prisma.GymMessagingConfigCreateInput });
    } catch (err) {
      // PHASE N2 — `GymMessagingConfig.whatsappPhoneId` is UNIQUE *globally*
      // (one WhatsApp Business number can only be bound to one gym), so two
      // gyms configuring the same number is a normal, user-caused conflict.
      // It used to escape as the raw Prisma error: an opaque 409
      // `unique_constraint_violation` in production, and a 500 inside test
      // apps (the global HttpExceptionFilter is registered in main.ts only).
      // Answer what actually happened, translated, with the offending field.
      const fields = uniqueViolationFields(err);
      if (fields.length) {
        if (fields.includes('whatsappPhoneId')) {
          this.logger.warn(
            `PUT /messaging/config for gym ${gymId} rejected: WhatsApp phone id already bound to another gym`,
          );
          throw new ConflictException({
            message:
              'This WhatsApp number is already connected to another gym. Each number can be bound to one gym only.',
            code: 'WHATSAPP_NUMBER_IN_USE',
            translationKey: 'whatsapp_number_in_use',
          });
        }
        this.logger.warn(
          `PUT /messaging/config for gym ${gymId} rejected by a unique constraint on: ${fields.join(', ')}`,
        );
        throw new ConflictException({
          message: 'That messaging setting is already in use by another gym.',
          code: 'MESSAGING_CONFIG_CONFLICT',
          translationKey: 'messaging_config_conflict',
        });
      }
      throw err;
    }
    return this.getMaskedConfig(gymId);
  }

  deleteConfig(gymId: string) {
    return this.prisma.gymMessagingConfig.deleteMany({ where: { gymId } });
  }

  async getStatus(gymId: string) {
    const config = await this.getConfig(gymId);
    return {
      whatsapp: { enabled: !!config?.whatsappEnabled, connected: !!(config?.whatsappEnabled && config.whatsappToken && config.whatsappPhoneId), phoneId: config?.whatsappPhoneId || undefined },
      sms: { enabled: !!config?.smsEnabled, connected: !!(config?.smsEnabled && config.smsApiKey && config.smsApiSecret), provider: config?.smsProvider || undefined },
      email: { enabled: !!config?.smtpEnabled, connected: !!(config?.smtpEnabled && config.smtpHost && config.smtpUser && config.smtpPass), from: config?.smtpFrom || undefined },
    };
  }

  async testWhatsApp(gymId: string, to: string): Promise<MessagingResult> {
    return this.sendWhatsAppText(gymId, to, 'FLEXORA test message ✅', false);
  }

  async testSms(gymId: string, to: string): Promise<MessagingResult> {
    return this.sendSms(gymId, to, 'FLEXORA SMS test ✅', false);
  }

  async testEmail(gymId: string, to: string): Promise<MessagingResult> {
    return this.sendEmail(gymId, to, 'FLEXORA email test', '<p>FLEXORA email test ✅</p>', false);
  }

  async sendWhatsAppText(gymId: string, to: string, body: string, allowGlobalFallback = true): Promise<MessagingResult> {
    const config = await this.getConfig(gymId);
    if (config?.whatsappEnabled && config.whatsappPhoneId && config.whatsappToken) {
      const token = await this.safeDecrypt(config.whatsappToken);
      const baseUrl = assertAllowedWhatsAppBaseUrl(config.whatsappUrl || process.env.WHATSAPP_API_URL || 'https://graph.facebook.com/v17.0');
      return this.callWhatsApp(baseUrl, config.whatsappPhoneId, token, { messaging_product: 'whatsapp', to, type: 'text', text: { body } }, 'gym');
    }
    if (allowGlobalFallback && process.env.WHATSAPP_PHONE_ID && process.env.WHATSAPP_TOKEN) {
      const baseUrl = assertAllowedWhatsAppBaseUrl(process.env.WHATSAPP_API_URL || 'https://graph.facebook.com/v17.0');
      return this.callWhatsApp(baseUrl, process.env.WHATSAPP_PHONE_ID, process.env.WHATSAPP_TOKEN, { messaging_product: 'whatsapp', to, type: 'text', text: { body } }, 'global');
    }
    return { success: false, error: 'not-configured' };
  }

  async sendWhatsAppTemplate(gymId: string, to: string, templateName: string, components: unknown[], languageCode = 'ar'): Promise<MessagingResult> {
    const config = await this.getConfig(gymId);
    const payload = { messaging_product: 'whatsapp', to, type: 'template', template: { name: templateName, language: { code: languageCode }, components } };
    if (config?.whatsappEnabled && config.whatsappPhoneId && config.whatsappToken) {
      const token = await this.safeDecrypt(config.whatsappToken);
      const baseUrl = assertAllowedWhatsAppBaseUrl(config.whatsappUrl || process.env.WHATSAPP_API_URL || 'https://graph.facebook.com/v17.0');
      return this.callWhatsApp(baseUrl, config.whatsappPhoneId, token, payload, 'gym');
    }
    if (process.env.WHATSAPP_PHONE_ID && process.env.WHATSAPP_TOKEN) {
      const baseUrl = assertAllowedWhatsAppBaseUrl(process.env.WHATSAPP_API_URL || 'https://graph.facebook.com/v17.0');
      return this.callWhatsApp(baseUrl, process.env.WHATSAPP_PHONE_ID, process.env.WHATSAPP_TOKEN, payload, 'global');
    }
    return { success: false, error: 'not-configured' };
  }

  async sendSms(gymId: string, to: string, body: string, allowGlobalFallback = true): Promise<MessagingResult> {
    const config = await this.getConfig(gymId);
    if (config?.smsEnabled && config.smsApiKey && config.smsApiSecret) {
      const apiKey = await this.safeDecrypt(config.smsApiKey);
      const apiSecret = await this.safeDecrypt(config.smsApiSecret);
      if ((config.smsProvider || 'vonage') === 'twilio') return this.sendTwilioSms(apiKey, apiSecret, config.smsFrom || '', to, body, 'gym');
      return this.sendVonageSms(apiKey, apiSecret, config.smsFrom || 'FLEXORA', to, body, 'gym');
    }
    if (allowGlobalFallback && process.env.VONAGE_API_KEY && process.env.VONAGE_API_SECRET) {
      return this.sendVonageSms(process.env.VONAGE_API_KEY, process.env.VONAGE_API_SECRET, process.env.SMS_FROM || 'FLEXORA', to, body, 'global');
    }
    return { success: false, error: 'not-configured' };
  }

  async sendEmail(gymId: string, to: string, subject: string, body: string, allowGlobalFallback = true): Promise<MessagingResult> {
    const config = await this.getConfig(gymId);
    if (config?.smtpEnabled && config.smtpHost && config.smtpUser && config.smtpPass) {
      const pass = await this.safeDecrypt(config.smtpPass);
      const transporter = nodemailer.createTransport({ host: config.smtpHost, port: config.smtpPort || 587, secure: (config.smtpPort || 587) === 465, auth: { user: config.smtpUser, pass } });
      await transporter.sendMail({ from: config.smtpFrom || config.smtpUser, to, subject, html: body });
      return { success: true, provider: 'gym' };
    }
    if (allowGlobalFallback && process.env.SMTP_HOST) {
      const transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined });
      await transporter.sendMail({ from: process.env.SMTP_FROM || 'FLEXORA <no-reply@flexora.app>', to, subject, html: body });
      return { success: true, provider: 'global' };
    }
    return { success: false, error: 'not-configured' };
  }

  private async callWhatsApp(baseUrl: string, phoneId: string, token: string, payload: unknown, provider: string): Promise<MessagingResult> {
    const res = await fetch(`${baseUrl}/${phoneId}/messages`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(15000) });
    if (!res.ok) return { success: false, provider, error: `WhatsApp API ${res.status}` };
    return { success: true, provider };
  }

  private async sendVonageSms(apiKey: string, apiSecret: string, from: string, to: string, body: string, provider: string): Promise<MessagingResult> {
    const params = new URLSearchParams({ api_key: apiKey, api_secret: apiSecret, from, to: this.toIntl(to).replace('+', ''), text: body, type: 'unicode' });
    const res = await fetch('https://rest.nexmo.com/sms/json', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString(), signal: AbortSignal.timeout(15000) });
    const data = (await res.json().catch(() => ({}))) as Record<string, any>;
    const msg = (data?.messages as Record<string, any>[])?.[0];
    if (!res.ok || (msg && msg.status !== '0')) return { success: false, provider, error: (msg?.['error-text'] as string) || `Vonage error (${res.status})` };
    return { success: true, provider };
  }

  private async sendTwilioSms(accountSid: string, authToken: string, from: string, to: string, body: string, provider: string): Promise<MessagingResult> {
    if (!from) return { success: false, provider, error: 'twilio-from-required' };
    const params = new URLSearchParams({ To: this.toIntl(to), From: from, Body: body });
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, { method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params, signal: AbortSignal.timeout(15000) });
    if (!res.ok) return { success: false, provider, error: `Twilio error (${res.status})` };
    return { success: true, provider };
  }

  private toIntl(to: string): string {
    const digits = to.replace(/\D/g, '');
    if (digits.startsWith('20')) return '+' + digits;
    if (digits.startsWith('0')) return '+20' + digits.slice(1);
    return '+' + digits;
  }

  private async safeDecrypt(value: string): Promise<string> {
    try { return this.encryption.decrypt(value); } catch (error) { this.logger.warn(`Credential decrypt failed: ${(error as Error).message}`); return ''; }
  }

  private mask(value: string) {
    if (!value || value.length <= 4) return '****';
    return `****${value.slice(-4)}`;
  }
}
