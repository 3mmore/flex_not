/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { GymMessagingService } from './gym-messaging.service';

/**
 * SMS gateway for Egyptian carriers via Vonage (Nexmo) REST API.
 * Egyptian numbers are normalized 01xxxxxxxxx -> +201xxxxxxxxx.
 * Every send is persisted to the Notification table (channel SMS).
 * Degrades gracefully (logs + records) when no credentials are configured.
 */
@Injectable()
export class SmsService {
  private readonly logger = new Logger('SMS');

  constructor(private readonly prisma: PrismaService, private readonly gymMessaging: GymMessagingService) {}

  get configured(): boolean {
    return true;
  }

  /** Normalize local EG mobile to international E.164 (+20...). */
  private toIntl(to: string): string {
    const digits = to.replace(/\D/g, '');
    if (digits.startsWith('20')) return '+' + digits;
    if (digits.startsWith('0')) return '+20' + digits.slice(1);
    return '+' + digits;
  }

  sendSms(gymId: string, to: string, message: string) {
    return this.sms(gymId, to, message);
  }

  async sms(gymId: string, to: string, body: string): Promise<void> {
    const intl = this.toIntl(to);
    const rec = await this.prisma.notification.create({
      data: { gymId, channel: 'SMS', to: intl, body },
    });
    try {
      const result = await this.gymMessaging.sendSms(gymId, to, body);
      if (!result.success) throw new Error(result.error || 'not-configured');
      await this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'SENT', sentAt: new Date(), error: result.provider },
      });
    } catch (e: unknown) {
      await this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'FAILED', error: (e as Error).message },
      });
      this.logger.error(`SMS to ${intl} failed: ${(e as Error).message}`);
    }
  }
}
