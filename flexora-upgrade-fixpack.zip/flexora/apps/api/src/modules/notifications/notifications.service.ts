/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { PrismaService } from '../../config/prisma.service';
import { GymMessagingService } from './gym-messaging.service';

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger('Notifications');
  private mailer: nodemailer.Transporter | null = null;

  constructor(private readonly prisma: PrismaService, private readonly gymMessaging: GymMessagingService) {
    if (process.env.SMTP_HOST) {
      this.mailer = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        auth: process.env.SMTP_USER
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined,
      });
    }
  }

  list(gymId: string) {
    return this.prisma.notification.findMany({
      where: { gymId },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  sendWhatsApp(gymId: string, to: string, message: string) {
    return this.whatsapp(gymId, to, message);
  }

  sendEmail(gymId: string, to: string, subject: string, htmlBody: string) {
    return this.email(gymId, to, subject, htmlBody);
  }

  sendInApp(gymId: string, memberId: string, subject: string, body: string) {
    return this.inApp(gymId, memberId, body, subject);
  }

  async inApp(gymId: string, to: string, body: string, subject?: string) {
    return this.prisma.notification.create({
      data: { gymId, channel: 'INAPP', status: 'SENT', to, body, subject, sentAt: new Date() },
    });
  }

  async email(gymId: string, to: string, subject: string, body: string) {
    const rec = await this.prisma.notification.create({
      data: { gymId, channel: 'EMAIL', to, subject, body },
    });
    try {
      const result = await this.gymMessaging.sendEmail(gymId, to, subject, body);
      if (!result.success) throw new Error(result.error || 'not-configured');
      return this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'SENT', sentAt: new Date(), error: result.provider },
      });
    } catch (e: unknown) {
      return this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'FAILED', error: (e as Error).message },
      });
    }
  }

  /**
   * ROUND 14 (security review, PHASE E): `persistBody` redacts what is stored
   * in the notification log. Code-bearing messages (portal OTPs, one-time
   * access codes) MUST pass it — the audit trail then proves a message was
   * sent without ever persisting the secret. The message that is actually
   * SENT still carries the real body.
   */
  async whatsapp(gymId: string | null, to: string, body: string, persistBody?: string) {
    // For platform-level notifications (gymId=null), skip Notification record creation
    // since there is no gym FK to reference. The WhatsApp message is still sent.
    let rec: { id: string } | undefined;
    if (gymId) {
      rec = await this.prisma.notification.create({
        data: { gymId, channel: 'WHATSAPP', to, body: persistBody ?? body },
      });
    }
    try {
      // gymId=null means platform-level — use platform WhatsApp config from env
      const result = await this.gymMessaging.sendWhatsAppText(
        gymId ?? 'platform', to, body,
      );
      if (!result.success) throw new Error(result.error || 'not-configured');
      if (rec) {
        return this.prisma.notification.update({
          where: { id: rec.id }, data: { status: 'SENT', sentAt: new Date(), error: result.provider },
        });
      }
      return null;
    } catch (e: unknown) {
      if (rec) {
        return this.prisma.notification.update({
          where: { id: rec.id }, data: { status: 'FAILED', error: (e as Error).message },
        });
      }
      throw e;
    }
  }

  /**
   * Template-based WhatsApp message (WhatsApp Cloud API `type: "template"`).
   *
   * WHEN TO USE:
   *  - Use `whatsappTemplate()` for PROACTIVE / outbound business-initiated
   *    messages (renewal reminders, session-left alerts, promotions). WhatsApp
   *    rejects free-form text outside the 24h customer-service window unless an
   *    approved template is used.
   *  - Use the plain `whatsapp()` method ONLY for REACTIVE replies inside an
   *    open 24h conversation window (member messaged the gym first), where free
   *    text is permitted.
   *
   * `components` follows the WhatsApp Cloud API schema, e.g.:
   *   [{ type: 'body', parameters: [{ type: 'text', text: 'Ahmed' }, ...] }]
   */
  async whatsappTemplate(
    gymId: string,
    to: string,
    templateName: string,
    components: unknown[],
    languageCode = 'ar',
  ) {
    const human = `[template:${templateName}] ${JSON.stringify(components)}`;
    const rec = await this.prisma.notification.create({
      data: { gymId, channel: 'WHATSAPP', to, body: human },
    });
    try {
      const result = await this.gymMessaging.sendWhatsAppTemplate(gymId, to, templateName, components, languageCode);
      if (!result.success) throw new Error(result.error || 'not-configured');
      return this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'SENT', sentAt: new Date(), error: result.provider },
      });
    } catch (e: unknown) {
      return this.prisma.notification.update({
        where: { id: rec.id }, data: { status: 'FAILED', error: (e as Error).message },
      });
    }
  }
}
