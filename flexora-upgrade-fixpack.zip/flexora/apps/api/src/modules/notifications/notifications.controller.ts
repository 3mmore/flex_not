/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { NotificationsService } from './notifications.service';
import { SmsService } from './sms.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { IsOptional, IsString } from 'class-validator';

class SendDto {
  @IsString() channel: 'email' | 'whatsapp' | 'sms' | 'inapp';
  @IsString() to!: string;
  @IsString() body!: string;
  // ROUND 14 (Phase E): this field was declared without a validator — with
  // forbidNonWhitelisted the whole request was rejected ("property subject
  // should not exist"), so in-app sends with a subject always 400'd.
  @IsOptional() @IsString() subject?: string;
}

@ApiTags('notifications')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('notifications')
export class NotificationsController {
  constructor(
    private readonly svc: NotificationsService,
    private readonly sms: SmsService,
  ) {}
  // ROUND 14 (security review, PHASE E): the notification log can contain
  // member-facing message bodies — only OWNER+MANAGER (reports.view) may read it.
  @Get() @Permissions('reports.view') list(@GymId() gymId: string) { return this.svc.list(gymId); }
  @Post('send') @Roles('OWNER', 'MANAGER')
  send(@GymId() gymId: string, @Body() dto: SendDto) {
    if (dto.channel === 'email') return this.svc.email(gymId, dto.to, dto.subject || 'FLEXORA', dto.body);
    if (dto.channel === 'whatsapp') return this.svc.whatsapp(gymId, dto.to, dto.body);
    if (dto.channel === 'sms') return this.sms.sms(gymId, dto.to, dto.body);
    return this.svc.inApp(gymId, dto.to, dto.body, dto.subject);
  }
}
