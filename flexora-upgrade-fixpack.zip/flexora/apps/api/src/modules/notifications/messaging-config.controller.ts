/**
 * FLEXORA Gym OS — per-gym messaging configuration API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Post, Put, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { IntegrationBrandingGuard } from '../../common/guards/integration-branding.guard';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { NotificationsService } from './notifications.service';
import { GymMessagingService } from './gym-messaging.service';
import { UpdateMessagingConfigDto } from './dto/messaging-config.dto';

class TestToDto {
  @IsString() to!: string;
}

@Controller('messaging')
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Permissions('settings.manage')
@ApiTags('messaging')
@ApiBearerAuth()
export class MessagingConfigController {
  constructor(
    private readonly gymMessaging: GymMessagingService,
    private readonly notifications: NotificationsService,
  ) {}

  @Get('status')
  status(@GymId() gymId: string) {
    return this.gymMessaging.getStatus(gymId);
  }

  @Get('config')
  getConfig(@GymId() gymId: string) {
    return this.gymMessaging.getMaskedConfig(gymId);
  }

  @Put('config')
  @UseGuards(IntegrationBrandingGuard)
  updateConfig(@GymId() gymId: string, @Body() dto: UpdateMessagingConfigDto) {
    return this.gymMessaging.updateConfig(gymId, dto);
  }

  @Delete('config')
  @UseGuards(IntegrationBrandingGuard)
  deleteConfig(@GymId() gymId: string) {
    return this.gymMessaging.deleteConfig(gymId);
  }

  @Post('test/whatsapp')
  @UseGuards(IntegrationBrandingGuard)
  testWhatsApp(@GymId() gymId: string, @Body() dto: TestToDto) {
    return this.gymMessaging.testWhatsApp(gymId, dto.to);
  }

  @Post('test/sms')
  @UseGuards(IntegrationBrandingGuard)
  testSms(@GymId() gymId: string, @Body() dto: TestToDto) {
    return this.gymMessaging.testSms(gymId, dto.to);
  }

  @Post('test/email')
  @UseGuards(IntegrationBrandingGuard)
  testEmail(@GymId() gymId: string, @Body() dto: TestToDto) {
    return this.gymMessaging.testEmail(gymId, dto.to);
  }

  @Get('history')
  history(@GymId() gymId: string, @Query('channel') channel?: string, @Query('limit') limit = 50) {
    return this.notifications.list(gymId).then((rows) => rows.filter((row) => !channel || row.channel === channel).slice(0, Number(limit) || 50));
  }
}
