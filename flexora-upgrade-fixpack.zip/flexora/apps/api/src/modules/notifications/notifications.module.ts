/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { NotificationsService } from './notifications.service';
import { NotificationsController } from './notifications.controller';
import { RemindersService } from './reminders.service';
import { SmsService } from './sms.service';
import { GymMessagingService } from './gym-messaging.service';
import { MessagingConfigController } from './messaging-config.controller';
import { WebhookController } from './webhook.controller';
import { SecurityModule } from '../../common/security/security.module';
import { OwnerNotifyService } from './owner-notify.service';
import { OwnerNotifyController } from './owner-notify.controller';

@Module({
  imports: [JwtModule.register({}), SecurityModule],
  controllers: [NotificationsController, MessagingConfigController, WebhookController, OwnerNotifyController],
  providers: [NotificationsService, RemindersService, SmsService, GymMessagingService, OwnerNotifyService],
  exports: [NotificationsService, SmsService, GymMessagingService, OwnerNotifyService],
})
export class NotificationsModule {}
