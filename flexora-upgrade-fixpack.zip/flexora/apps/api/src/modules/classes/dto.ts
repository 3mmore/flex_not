/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Type } from 'class-transformer';
import {
  IsDateString, IsHexColor, IsInt, IsOptional, IsString, Min, MinLength,
} from 'class-validator';

export class CreateTemplateDto {
  @IsString() @MinLength(2) name: string;
  @IsOptional() @IsString() nameAr?: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() coachId?: string;
  @IsOptional() @IsInt() @Min(5) durationMin?: number;
  @IsOptional() @IsInt() @Min(1) capacity?: number;
  @IsOptional() @IsHexColor() color?: string;
}

export class CreateSessionDto {
  @IsString() templateId!: string;
  @IsDateString() startsAt!: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() coachId?: string;
  @IsOptional() @IsInt() @Min(1) capacity?: number;
  @IsOptional() @IsInt() @Min(1) durationMin?: number;
}

export class BookDto {
  @IsString() memberId!: string;
}

export class ListSessionsDto {
  @IsOptional() @IsDateString() from?: string;
  @IsOptional() @IsDateString() to?: string;
  @IsOptional() @IsString() branchId?: string;
}
