/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ClassesService } from './classes.service';
import {
  BookDto, CreateSessionDto, CreateTemplateDto, ListSessionsDto,
} from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { RequiresFeature } from '../license/license.module';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('classes')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('classes')
@Controller('classes')
export class ClassesController {
  constructor(private readonly svc: ClassesService) {}

  // templates
  @Get('templates')
  @Permissions('classes.manage')
  templates(@GymId() g: string, @Query('branchId') branchId?: string) { return this.svc.listTemplates(g, branchId); }

  @Post('templates') @Permissions('classes.manage') @Audit('create', 'ClassTemplate')
  createTemplate(@GymId() g: string, @Body() d: CreateTemplateDto) { return this.svc.createTemplate(g, d); }

  @Patch('templates/:id') @Permissions('classes.manage') @Audit('update', 'ClassTemplate')
  updateTemplate(@GymId() g: string, @Param('id') id: string, @Body() d: Partial<CreateTemplateDto>) { return this.svc.updateTemplate(g, id, d); }

  @Delete('templates/:id') @Permissions('classes.manage') @Audit('delete', 'ClassTemplate')
  removeTemplate(@GymId() g: string, @Param('id') id: string, @Query('force') force: string) { 
    return this.svc.removeTemplate(g, id, force === 'true'); 
  }

  // sessions
  @Get('sessions')
  @Permissions('classes.manage')
  sessions(@GymId() g: string, @Query() q: ListSessionsDto) { return this.svc.listSessions(g, q); }

  @Post('sessions') @Permissions('classes.manage') @Audit('create', 'ClassSession')
  createSession(@GymId() g: string, @Body() d: CreateSessionDto) { return this.svc.createSession(g, d); }

  @Patch('sessions/:id') @Permissions('classes.manage') @Audit('update', 'ClassSession')
  updateSession(@GymId() g: string, @Param('id') id: string, @Body() d: Partial<CreateSessionDto>) { return this.svc.updateSession(g, id, d); }

  @Post('sessions/:id/cancel') @Permissions('classes.manage') @Audit('cancel', 'ClassSession')
  cancelSession(@GymId() g: string, @Param('id') id: string) { return this.svc.cancelSession(g, id); }

  @Delete('sessions/:id') @Permissions('classes.manage') @Audit('delete', 'ClassSession')
  removeSession(@GymId() g: string, @Param('id') id: string, @Query('force') force: string) {
    return this.svc.removeSession(g, id, force === 'true');
  }

  @Post('sessions/:id/book') @Permissions('classes.manage') @Audit('book', 'ClassBooking')
  book(@GymId() g: string, @Param('id') id: string, @Body() d: BookDto) { return this.svc.book(g, id, d.memberId); }

  @Post('sessions/:id/cancel-booking') @Permissions('classes.manage') @Audit('cancel_booking', 'ClassBooking')
  cancelBooking(@GymId() g: string, @Param('id') id: string, @Body() d: BookDto) { return this.svc.cancelBooking(g, id, d.memberId); }

  @Post('sessions/:id/complete') @Roles('OWNER', 'MANAGER', 'COACH') @Audit('complete', 'ClassSession')
  complete(@GymId() g: string, @Param('id') id: string) { return this.svc.complete(g, id); }

  @Get('sessions/:id/roster')
  @Permissions('classes.manage')
  roster(@GymId() g: string, @Param('id') id: string) { return this.svc.roster(g, id); }
}
