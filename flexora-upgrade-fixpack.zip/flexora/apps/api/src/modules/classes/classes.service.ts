/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, ClassStatus, BookingStatus } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
// ROUND 14 (security review, PHASE K1): the ONE membership-state decision.
import { canTrain, trainingDenialReason } from '../members/membership-status';
import { RedisService } from '../../config/redis.service';
import {
  CreateSessionDto, CreateTemplateDto, ListSessionsDto,
} from './dto';

@Injectable()
export class ClassesService {
  constructor(private readonly prisma: PrismaService, private readonly redis: RedisService) {}

  private async cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    const cached = await this.redis.get(key);
    if (cached) {
      try { return JSON.parse(cached); } catch { /* ignore */ }
    }
    const result = await fn();
    await this.redis.set(key, JSON.stringify(result), ttl);
    return result;
  }

  /**
   * FIX (classes data never reflecting on screen): listSessions() served a
   * 5-minute Redis cache that NO write operation ever invalidated — so a
   * created/edited/deleted session or a new booking kept showing stale data
   * for up to 5 minutes after the mutation reported success (and survived
   * full page reloads). Every mutating endpoint now clears the gym's whole
   * `classes:sessions:*` cache so the very next list reflects the change.
   */
  private async invalidateSessionsCache(gymId: string) {
    try {
      const keys = await this.redis.client.keys(`classes:sessions:${gymId}:*`);
      if (keys.length) await Promise.all(keys.map((k) => this.redis.client.del(k)));
    } catch { /* redis down — cache is best-effort */ }
  }

  // ---- templates ----
  /**
   * P4-1 FIX: the UI always showed "unassigned" because this list never
   * included the coach relation (only the raw coachId scalar), and branchId
   * was missing from the Prisma model entirely so any branch-scoped create
   * 500'd. Now both relations are returned and the list can be filtered
   * with ?branchId=.
   */
  async listTemplates(gymId: string, branchId?: string) {
    return this.prisma.classTemplate.findMany({
      where: { gymId, active: true, ...(branchId ? { branchId } : {}) },
      include: {
        coach: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
        _count: { select: { sessions: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  /** Coaches/branches assigned to a template must belong to this gym. */
  private async assertTemplateRefs(gymId: string, dto: { coachId?: string | null; branchId?: string | null }) {
    if (dto.coachId) {
      const coach = await this.prisma.user.findFirst({ where: { id: dto.coachId, gymId } });
      if (!coach) throw new BadRequestException('Coach not found in this gym');
    }
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Branch not found in this gym');
    }
  }

  async createTemplate(gymId: string, dto: CreateTemplateDto) {
    await this.assertTemplateRefs(gymId, dto);
    return this.prisma.classTemplate.create({
      data: { ...dto, gymId, capacity: dto.capacity ?? 20 },
      include: {
        coach: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });
  }

  async updateTemplate(gymId: string, id: string, dto: Partial<CreateTemplateDto>) {
    const { id: _id, gymId: _gymId, ...updateData } = dto as any;
    await this.assertTemplateRefs(gymId, updateData);
    return this.prisma.classTemplate.update({
      where: { id, gymId },
      data: updateData,
      include: {
        coach: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });
  }

  async removeTemplate(gymId: string, id: string, force = false) {
    const t = await this.prisma.classTemplate.findFirst({ 
      where: { id, gymId },
      include: { 
        sessions: { 
          where: { startsAt: { gte: new Date() } },
          include: { _count: { select: { bookings: true } } }
        } 
      }
    });
    if (!t) throw new NotFoundException('Template not found');
    
    const affectedBookings = t.sessions.reduce((acc, s) => acc + s._count.bookings, 0);
    
    if (affectedBookings > 0 && !force) {
      throw new BadRequestException({
        message: 'AFFECTED_BOOKINGS',
        count: affectedBookings,
      });
    }

    // Logic: Deactivate template and cancel future sessions
    // PHASE N2 — this was `$transaction([ ... ])` (array form). Under the
    // tenant-RLS $extends middleware every element of an array batch is
    // wrapped in its OWN set_config+query transaction, so the batch was never
    // atomic: if the second statement failed, the first stayed committed.
    // One interactive transaction via withTenant() instead — the same fix
    // PlansService.remove got in PHASE N1.5, and what the doc-comment on
    // PrismaService.$transaction now requires of every write batch.
    await this.prisma.withTenant(gymId, async (tx) => {
      await tx.classSession.updateMany({
        where: { templateId: id, startsAt: { gte: new Date() }, gymId },
        data: { status: ClassStatus.CANCELLED }
      });
      await tx.classTemplate.update({ where: { id }, data: { active: false } });
    });
    
    return { ok: true, affectedBookings };
  }

  // ---- sessions ----
  async listSessions(gymId: string, q: ListSessionsDto) {
    return this.cached(`classes:sessions:${gymId}:${JSON.stringify(q || {})}`, 300, async () => this.computeListSessions(gymId, q));
  }

  private async computeListSessions(gymId: string, q: ListSessionsDto) {
    const where: Prisma.ClassSessionWhereInput = { gymId };
    if (q.branchId && q.branchId !== 'all') where.branchId = q.branchId;
    if (q.from || q.to) {
      where.startsAt = {};
      if (q.from) (where.startsAt as Prisma.DateTimeFilter).gte = new Date(q.from);
      if (q.to) (where.startsAt as Prisma.DateTimeFilter).lte = new Date(q.to);
    }
    const sessions = await this.prisma.classSession.findMany({
      where,
      include: {
        template: { select: { name: true, nameAr: true, color: true } },
        coach: { select: { id: true, name: true } },
        _count: { select: { bookings: true } },
      },
      orderBy: { startsAt: 'asc' },
      take: 200,
    });
    return sessions.map((s) => ({
      ...s,
      booked: s._count.bookings,
      full: s._count.bookings >= s.capacity,
    }));
  }

  async createSession(gymId: string, dto: CreateSessionDto) {
    const template = await this.prisma.classTemplate.findFirst({
      where: { id: dto.templateId, gymId },
    });
    if (!template) throw new BadRequestException('Invalid class template');
    
    let branchId = dto.branchId;
    if (!branchId || branchId === '') {
      const branch = await this.prisma.branch.findFirst({ where: { gymId }, orderBy: { createdAt: 'asc' } });
      if (!branch) throw new BadRequestException('No branch exists for this gym');
      branchId = branch.id;
    }
    await this.assertBranch(gymId, branchId);

    const startsAt = new Date(dto.startsAt);
    if (isNaN(startsAt.getTime())) throw new BadRequestException('Invalid start date');

    const endsAt = new Date(startsAt.getTime() + (dto.durationMin || template.durationMin) * 60000);
    const coachId = dto.coachId && dto.coachId !== '' ? dto.coachId : (template.coachId || undefined);

    const created = await this.prisma.classSession.create({
      data: {
        gymId,
        templateId: template.id,
        branchId,
        coachId,
        startsAt,
        endsAt,
        capacity: dto.capacity ?? template.capacity,
      },
    });
    await this.invalidateSessionsCache(gymId);
    return created;
  }

  private async assertBranch(gymId: string, branchId?: string | null) {
    if (!branchId) return;
    const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
    if (!branch) throw new BadRequestException('Invalid branch');
  }

  async updateSession(gymId: string, id: string, dto: Partial<CreateSessionDto>) {
    const s = await this.prisma.classSession.findFirst({ where: { id, gymId }, include: { template: true } });
    if (!s) throw new NotFoundException('Session not found');
    
    const data: Prisma.ClassSessionUpdateInput = {};
    if (dto.templateId) data.template = { connect: { id: dto.templateId } };
    if (dto.coachId !== undefined) {
      if (dto.coachId) data.coach = { connect: { id: dto.coachId } };
      else data.coach = { disconnect: true };
    }
    if (dto.capacity) data.capacity = dto.capacity;
    if (dto.branchId) data.branch = { connect: { id: dto.branchId } };
    
    if (dto.startsAt) {
      const startsAt = new Date(dto.startsAt);
      const duration = dto.durationMin || s.template.durationMin;
      const endsAt = new Date(startsAt.getTime() + duration * 60000);
      data.startsAt = startsAt;
      data.endsAt = endsAt;
    }
    
    const updated = await this.prisma.classSession.update({ where: { id }, data });
    await this.invalidateSessionsCache(gymId);
    return updated;
  }

  async cancelSession(gymId: string, id: string) {
    const s = await this.prisma.classSession.findFirst({ 
      where: { id, gymId },
      include: { _count: { select: { bookings: true } } }
    });
    if (!s) throw new NotFoundException('Session not found');
    
    // PHASE N2 — this was `$transaction([ ... ])` (array form). Under the
    // tenant-RLS $extends middleware every element of an array batch is
    // wrapped in its OWN set_config+query transaction, so the batch was never
    // atomic: if the second statement failed, the first stayed committed.
    // One interactive transaction via withTenant() instead — the same fix
    // PlansService.remove got in PHASE N1.5, and what the doc-comment on
    // PrismaService.$transaction now requires of every write batch.
    await this.prisma.withTenant(gymId, async (tx) => {
      await tx.classBooking.updateMany({
        where: { sessionId: id, status: BookingStatus.CONFIRMED, gymId }, data: { status: BookingStatus.CANCELLED },
      });
      await tx.classSession.update({ where: { id }, data: { status: ClassStatus.CANCELLED } });
    });
    await this.invalidateSessionsCache(gymId);
    return { ok: true, affectedBookings: s._count.bookings };
  }

  async removeSession(gymId: string, id: string, force = false) {
    const s = await this.prisma.classSession.findFirst({ 
      where: { id, gymId },
      include: { _count: { select: { bookings: true } } }
    });
    if (!s) throw new NotFoundException('Session not found');
    
    if (s._count.bookings > 0 && !force) {
      throw new BadRequestException({ message: 'AFFECTED_BOOKINGS', count: s._count.bookings });
    }
    
    await this.prisma.classSession.delete({ where: { id } });
    await this.invalidateSessionsCache(gymId);
    return { ok: true };
  }

  /** Atomic booking with capacity check + member ownership scope. */
  async book(gymId: string, sessionId: string, memberId: string) {
    const booking = await this.prisma.withTenant(gymId, async (tx) => {
      const locked = await tx.$queryRaw<Array<{ id: string }>>`
        SELECT id FROM "ClassSession"
        WHERE id = ${sessionId} AND "gymId" = ${gymId}
        FOR UPDATE
      `;
      if (locked.length !== 1) throw new NotFoundException('Session not found');
      const session = await tx.classSession.findFirst({ where: { id: sessionId, gymId } });
      if (!session) throw new NotFoundException('Session not found');
      if (session.status !== ClassStatus.SCHEDULED) throw new BadRequestException('Session is not open for booking');

      const member = await tx.member.findFirst({
        where: { id: memberId, gymId },
        include: { plan: true },
      });
      if (!member) throw new BadRequestException('Member not in this gym');
      // ROUND 14 (security review, PHASE K1): the shared, FAIL-CLOSED gate.
      // The inline version let a TIME-plan member with a NULL expiry book a
      // class — training without a paid period.
      if (!canTrain(member)) throw new BadRequestException(trainingDenialReason(member));

      const existing = await tx.classBooking.findFirst({
        where: { sessionId, memberId, gymId },
      });
      if (existing) {
        if (existing.status === BookingStatus.CONFIRMED) throw new BadRequestException('Already booked');
        const confirmed = await tx.classBooking.count({ where: { sessionId, status: BookingStatus.CONFIRMED } });
        if (confirmed >= session.capacity) throw new BadRequestException('Session is full');
        return tx.classBooking.update({ where: { id: existing.id }, data: { status: BookingStatus.CONFIRMED } });
      }

      const confirmed = await tx.classBooking.count({ where: { sessionId, status: BookingStatus.CONFIRMED } });
      if (confirmed >= session.capacity) throw new BadRequestException('Session is full');

      return tx.classBooking.create({ data: { gymId, sessionId, memberId, status: BookingStatus.CONFIRMED } });
    });
    await this.invalidateSessionsCache(gymId);
    return booking;
  }

  async cancelBooking(gymId: string, sessionId: string, memberId: string) {
    const booking = await this.prisma.classBooking.findFirst({
      where: { gymId, sessionId, memberId, status: BookingStatus.CONFIRMED },
    });
    if (!booking) throw new NotFoundException('Booking not found');
    await this.prisma.classBooking.update({ where: { id: booking.id }, data: { status: BookingStatus.CANCELLED } });
    await this.invalidateSessionsCache(gymId);
    return { ok: true };
  }

  /** Mark a session COMPLETED and flip its confirmed bookings to ATTENDED. */
  async complete(gymId: string, sessionId: string) {
    const s = await this.prisma.classSession.findFirst({ where: { id: sessionId, gymId } });
    if (!s) throw new NotFoundException('Session not found');
    // PHASE N2 — this was `$transaction([ ... ])` (array form). Under the
    // tenant-RLS $extends middleware every element of an array batch is
    // wrapped in its OWN set_config+query transaction, so the batch was never
    // atomic: if the second statement failed, the first stayed committed.
    // One interactive transaction via withTenant() instead — the same fix
    // PlansService.remove got in PHASE N1.5, and what the doc-comment on
    // PrismaService.$transaction now requires of every write batch.
    await this.prisma.withTenant(gymId, async (tx) => {
      await tx.classBooking.updateMany({
        where: { gymId, sessionId, status: BookingStatus.CONFIRMED }, data: { status: BookingStatus.ATTENDED },
      });
      await tx.classSession.updateMany({ where: { id: sessionId, gymId }, data: { status: ClassStatus.COMPLETED } });
    });
    await this.invalidateSessionsCache(gymId);
    return { ok: true };
  }

  async roster(gymId: string, sessionId: string) {
    const s = await this.prisma.classSession.findFirst({ where: { id: sessionId, gymId } });
    if (!s) throw new NotFoundException('Session not found');
    return this.prisma.classBooking.findMany({
      where: { sessionId, gymId, status: { in: [BookingStatus.CONFIRMED, BookingStatus.ATTENDED] } },
      include: { member: { select: { id: true, name: true, mobile: true } } },
      orderBy: { createdAt: 'asc' },
      take: 200,
    });
  }
}
