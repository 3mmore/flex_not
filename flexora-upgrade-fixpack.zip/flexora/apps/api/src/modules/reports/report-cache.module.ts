/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { ReportCacheService } from './report-cache.service';

@Module({
  providers: [ReportCacheService],
  exports: [ReportCacheService],
})
export class ReportCacheModule {}
