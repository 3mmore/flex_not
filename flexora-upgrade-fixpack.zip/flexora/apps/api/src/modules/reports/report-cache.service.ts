/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Materialised report cache (Phase 4C).
 *
 * Reports are expensive (KPIs across many tables). This service
 * caches the JSON result in the ReportCache table with an expiresAt
 * timestamp. Stale entries are recomputed on the next read.
 *
 * Nightly jobs run in Phase 5 to pre-warm the cache.
 */
import { Injectable, Logger, Optional } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { Prisma } from '@prisma/client';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

@Injectable()
export class ReportCacheService {
  private readonly logger = new Logger(ReportCacheService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly cronLeadership: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
    @Optional() private readonly redis?: RedisService,
  ) {}

  async get<T = unknown>(gymId: string, reportKey: string): Promise<T | null> {
    const row = await this.prisma.reportCache.findUnique({
      where: { gymId_reportKey: { gymId, reportKey } },
    });
    if (!row) return null;
    if (row.expiresAt < new Date()) return null;
    return row.data as T;
  }

  async set(
    gymId: string,
    reportKey: string,
    data: Prisma.InputJsonValue,
    ttlSeconds: number,
  ): Promise<void> {
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
    await this.prisma.reportCache.upsert({
      where: { gymId_reportKey: { gymId, reportKey } },
      update: { data, expiresAt, computedAt: new Date() },
      create: { gymId, reportKey, data, expiresAt },
    });
  }

  async invalidate(gymId: string, reportKey?: string) {
    if (reportKey) {
      await this.prisma.reportCache.deleteMany({ where: { gymId, reportKey } });
    } else {
      await this.prisma.reportCache.deleteMany({ where: { gymId } });
    }
  }

  /** Pre-warm hot reports every night at 02:30 UTC. */
  @Cron('30 2 * * *')
  async nightlyPrewarm() {
    return requestContext.run({ requestId: 'cron:report-prewarm' }, async () => {
      if (!(await this.cronLeadership.acquireLock('report-cache-nightly', 3600_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({
          where: { status: 'ACTIVE' },
          select: { id: true },
        });
        this.logger.log(`Pre-warming report cache for ${gyms.length} gyms`);
        for (const g of gyms) {
          try {
            await this.tenantContext.run(g.id, () => this.invalidate(g.id));
          } catch (e) {
            this.logger.warn(`invalidate failed for gym=${g.id}: ${(e as Error).message}`);
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('report-cache-nightly');
      }
    });
  }
}
