/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';

@Injectable()
export class ReportsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
  ) {}

  /** cache-aside helper — falls through to fn() if Redis is unavailable. */
  private async cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    try {
      const hit = await this.redis.get(key);
      if (hit) return JSON.parse(hit) as T;
    } catch { /* redis down — ignore */ }
    const fresh = await fn();
    try { await this.redis.set(key, JSON.stringify(fresh), ttl); } catch { /* ignore */ }
    return fresh;
  }

  dashboard(gymId: string) {
    return this.cached(`reports:dashboard:${gymId}`, 60, () => this.computeDashboard(gymId));
  }

  private async computeDashboard(gymId: string) {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
    const now = new Date();
    const in7 = new Date(now); in7.setDate(now.getDate() + 7);

    const [
      incomeToday, incomeMonth, expenseToday, expenseMonth, checkinsToday,
      activeTime, activeSession, expiringMembers, totalMembers,
    ] = await this.prisma.$transaction([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: monthStart } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'EXPENSE', createdAt: { gte: start } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'EXPENSE', createdAt: { gte: monthStart } }, _sum: { amount: true } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: start } } }),
      // active TIME-based: not frozen, expiry >= now
      this.prisma.member.count({ where: { gymId, frozen: false, plan: { type: 'TIME' }, expiry: { gte: now } } }),
      // active SESSION-based: not frozen, sessionsLeft > 0
      this.prisma.member.count({ where: { gymId, frozen: false, plan: { type: 'SESSION' }, sessionsLeft: { gt: 0 } } }),
      // expiring soon: not frozen, expiry within next 7 days
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: now, lte: in7 } } }),
      this.prisma.member.count({ where: { gymId } }),
    ]);

    const activeMembers = activeTime + activeSession;
    const revenueToday = Number(incomeToday._sum.amount || 0);
    const revenueMonth = Number(incomeMonth._sum.amount || 0);
    const expToday = Number(expenseToday._sum.amount || 0);
    const expMonth = Number(expenseMonth._sum.amount || 0);

    return {
      revenueToday, revenueMonth, expensesToday: expToday,
      netProfit: revenueMonth - expMonth, activeMembers,
      expiringMembers, checkinsToday, totalMembers,
    };
  }

  async ledger(gymId: string, page = 1, limit = 50) {
    /**
     * P4-5: NO cache here (was 300s Redis). The "Recent money movements"
     * widget must show a payment the moment it lands; the cached version kept
     * showing an empty/stale list for up to 5 minutes after every sale or
     * membership payment. The query is a paginated read over
     * Transaction(gymId, createdAt) — cheap enough to run uncached.
     */
    const [items, total] = await this.prisma.$transaction([
      this.prisma.transaction.findMany({
        where: { gymId },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        // The UI renders description (plain) + reference (invoice no) and the
        // paying member's name when the row is member-linked.
        include: { member: { select: { id: true, name: true } } },
      }),
      this.prisma.transaction.count({ where: { gymId } }),
    ]);
    return { items, total, page, limit };
  }

  async revenueByMonth(gymId: string) {
    return this.cached(`reports:revenue-by-month:${gymId}`, 300, async () => {
    // Phase 3B: single groupBy query instead of loading every row.
    const grouped = await this.prisma.$queryRaw<Array<{ month: string; total: string }>>`
      SELECT to_char(date_trunc('month', "createdAt"), 'YYYY-MM') AS month,
             COALESCE(SUM("amount"), 0) AS total
      FROM "Transaction"
      WHERE "gymId" = ${gymId} AND "type" = 'INCOME'
      GROUP BY 1
      ORDER BY 1
    `;
    return (grouped || []).map((r) => ({ month: r.month, value: Number(r.total) }));
    });
  }

  async membershipAnalytics(gymId: string) {
    return this.cached(`reports:membership-analytics:${gymId}`, 300, async () => {
    const now = new Date();
    const [activeTime, activeSession, total, loyal] = await this.prisma.$transaction([
      this.prisma.member.count({ where: { gymId, frozen: false, plan: { type: 'TIME' }, expiry: { gte: now } } }),
      this.prisma.member.count({ where: { gymId, frozen: false, plan: { type: 'SESSION' }, sessionsLeft: { gt: 0 } } }),
      this.prisma.member.count({ where: { gymId } }),
      this.prisma.member.count({ where: { gymId, visits: { gt: 10 } } }),
    ]);
    const active = activeTime + activeSession;
    const expired = total - active;
    return { active, expired, total, renewalRate: total ? Math.round((loyal / total) * 100) : 0 };
    });
  }

  async peakHours(gymId: string) {
    return this.cached(`reports:peak-hours:${gymId}`, 300, async () => {
    // Phase 3B: single groupBy query (extract hour in PostgreSQL).
    const grouped = await this.prisma.$queryRaw<Array<{ hour: number; total: string }>>`
      SELECT EXTRACT(HOUR FROM "at")::int AS hour,
             COUNT(*) AS total
      FROM "Attendance"
      WHERE "gymId" = ${gymId}
      GROUP BY 1
    `;
    const map: Record<number, number> = {};
    for (const r of grouped || []) map[Number(r.hour)] = Number(r.total);
    return Array.from({ length: 24 }, (_, h) => ({ hour: h, count: map[h] || 0 }));
    });
  }
}
