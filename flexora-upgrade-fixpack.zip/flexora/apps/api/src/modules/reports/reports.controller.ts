/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { RequiresFeature } from '../license/license.module';

@ApiTags('reports')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('reports')
@Controller('reports')
export class ReportsController {
  constructor(private readonly svc: ReportsService) {}
  @Get('dashboard') @Permissions('reports.view') dashboard(@GymId() g: string) { return this.svc.dashboard(g); }
  @Get('ledger') @Permissions('reports.view') ledger(@GymId() g: string, @Query('page') p = 1, @Query('limit') l = 50) { return this.svc.ledger(g, +p, +l); }
  @Get('revenue-by-month') @Permissions('reports.view') rev(@GymId() g: string) { return this.svc.revenueByMonth(g); }
  @Get('membership-analytics') @Permissions('reports.view') membership(@GymId() g: string) { return this.svc.membershipAnalytics(g); }
  @Get('peak-hours') @Permissions('reports.view') peak(@GymId() g: string) { return this.svc.peakHours(g); }
}
