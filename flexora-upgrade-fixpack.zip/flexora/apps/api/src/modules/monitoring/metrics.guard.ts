import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Request } from 'express';
import { IpAllowlist, DEFAULT_METRICS_ALLOWED_CIDRS } from '../../common/security/ip-allowlist.util';

/**
 * SECURITY (Item 8 fix): the previous implementation matched IPs against
 * CIDR ranges using plain string prefix matching:
 *
 *   ip.startsWith(allowed.split('/')[0].slice(0, -1))
 *
 * For `172.16.0.0/12` this only ever matched IPs literally starting with
 * the string "172.16.0." — i.e. a /24, not the real /12 range (which spans
 * 172.16.0.0 through 172.31.255.255 — 16 whole /16 blocks). That is WRONG
 * in the "too narrow" direction (legitimate internal IPs like 172.20.5.5 or
 * 172.31.255.254 were incorrectly rejected) and not a real CIDR check in
 * general (e.g. it can't correctly reject 172.160.0.1, which also happens
 * to start with the string "172.16" once the trailing "0" of "172.16.0.0"
 * is stripped by `.slice(0, -1)`).
 *
 * FIX: delegate to the shared `IpAllowlist` (see
 * ../../common/security/ip-allowlist.util.ts), which uses `ipaddr.js` for
 * real, boundary-correct CIDR arithmetic and correct IPv4-mapped-IPv6 /
 * IPv6 loopback handling. Honors METRICS_ALLOWED_IPS (documented in
 * .env.example) if set, same as the historically-separate check in
 * main.ts's inline /metrics middleware — both now share this one
 * implementation instead of each having their own (both broken)
 * string-matching logic.
 */
@Injectable()
export class MetricsGuard implements CanActivate {
  private readonly allowlist = new IpAllowlist(
    process.env.METRICS_ALLOWED_IPS
      ? process.env.METRICS_ALLOWED_IPS.split(',').map((s) => s.trim())
      : DEFAULT_METRICS_ALLOWED_CIDRS,
  );

  /** Exposed for direct unit testing without constructing an ExecutionContext. */
  isAllowedIp(rawIp: string | undefined | null): boolean {
    return this.allowlist.isAllowed(rawIp);
  }

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const ip = request.ip || request.socket?.remoteAddress || request.connection?.remoteAddress || '';

    if (!this.isAllowedIp(ip)) {
      throw new ForbiddenException('Metrics endpoint access denied');
    }
    return true;
  }
}

