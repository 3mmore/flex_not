import { Module } from '@nestjs/common';
import { MonitoringService } from './monitoring.service';
import { MonitoringController } from './monitoring.controller';
import { MetricsInterceptor } from './metrics.interceptor';

@Module({
  controllers: [MonitoringController],
  providers: [MonitoringService, MetricsInterceptor],
  exports: [MonitoringService],
})
export class MonitoringModule {}