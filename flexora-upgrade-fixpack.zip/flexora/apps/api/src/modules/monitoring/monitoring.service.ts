import { Injectable, Logger } from '@nestjs/common';
import { Registry, collectDefaultMetrics, Gauge, Counter, Histogram } from 'prom-client';

@Injectable()
export class MonitoringService {
  private readonly logger = new Logger('MonitoringService');
  public readonly register: Registry;

  // Business metrics
  public readonly activeMembers = new Gauge({
    name: 'flexora_active_members_total',
    help: 'Total active (non-frozen) members',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly expiredMembers = new Gauge({
    name: 'flexora_expired_members_total',
    help: 'Total expired members',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly activeSubscriptions = new Gauge({
    name: 'flexora_active_subscriptions_total',
    help: 'Total active subscriptions',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly todayCheckins = new Gauge({
    name: 'flexora_today_checkins_total',
    help: 'Check-ins today',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly monthlyRevenue = new Gauge({
    name: 'flexora_monthly_revenue',
    help: 'Monthly revenue in EGP',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly activeGyms = new Gauge({
    name: 'flexora_active_gyms_total',
    help: 'Total active gyms',
    registers: [],
  });

  public readonly activeUsers = new Gauge({
    name: 'flexora_active_users_total',
    help: 'Total active users',
    registers: [],
  });

  // WhatsApp & AI
  public readonly waMessagesSent = new Counter({
    name: 'flexora_wa_messages_sent_total',
    help: 'WhatsApp messages sent',
    labelNames: ['gym_id', 'type'],
    registers: [],
  });

  public readonly waMessagesFailed = new Counter({
    name: 'flexora_wa_messages_failed_total',
    help: 'WhatsApp messages failed',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly aiRequests = new Counter({
    name: 'flexora_ai_requests_total',
    help: 'AI requests',
    labelNames: ['gym_id', 'type'],
    registers: [],
  });

  public readonly aiFailures = new Counter({
    name: 'flexora_ai_failures_total',
    help: 'AI failures',
    labelNames: ['gym_id'],
    registers: [],
  });

  // Auth & Security
  public readonly loginSuccess = new Counter({
    name: 'flexora_login_success_total',
    help: 'Successful logins',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly loginFailed = new Counter({
    name: 'flexora_login_failed_total',
    help: 'Failed logins',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly twoFaSuccess = new Counter({
    name: 'flexora_2fa_success_total',
    help: 'Successful 2FA',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly twoFaFailed = new Counter({
    name: 'flexora_2fa_failed_total',
    help: 'Failed 2FA',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly rateLimitTriggered = new Counter({
    name: 'flexora_rate_limit_triggered_total',
    help: 'Rate limits triggered',
    labelNames: ['gym_id'],
    registers: [],
  });

  public readonly blockedRequests = new Counter({
    name: 'flexora_blocked_requests_total',
    help: 'Blocked requests',
    labelNames: ['gym_id'],
    registers: [],
  });

  // Database
  public readonly dbQueries = new Counter({
    name: 'flexora_db_queries_total',
    help: 'Database queries',
    labelNames: ['operation'],
    registers: [],
  });

  public readonly dbErrors = new Counter({
    name: 'flexora_db_errors_total',
    help: 'Database errors',
    registers: [],
  });

  // Redis
  public readonly redisHits = new Counter({
    name: 'flexora_redis_hits_total',
    help: 'Redis cache hits',
    registers: [],
  });

  public readonly redisMisses = new Counter({
    name: 'flexora_redis_misses_total',
    help: 'Redis cache misses',
    registers: [],
  });

  public readonly redisErrors = new Counter({
    name: 'flexora_redis_errors_total',
    help: 'Redis errors',
    registers: [],
  });

  constructor() {
    this.register = new Registry();
    collectDefaultMetrics({ register: this.register });

    // Register all custom metrics
    const allMetrics = [
      this.activeMembers, this.expiredMembers, this.activeSubscriptions,
      this.todayCheckins, this.monthlyRevenue, this.activeGyms, this.activeUsers,
      this.waMessagesSent, this.waMessagesFailed, this.aiRequests, this.aiFailures,
      this.loginSuccess, this.loginFailed, this.twoFaSuccess, this.twoFaFailed,
      this.rateLimitTriggered, this.blockedRequests,
      this.dbQueries, this.dbErrors,
      this.redisHits, this.redisMisses, this.redisErrors,
    ];

    allMetrics.forEach(metric => {
      if (!this.register.getSingleMetric((metric as any).name)) {
        this.register.registerMetric(metric as any);
      }
    });

    this.logger.log('Prometheus metrics initialized');
  }

  getMetrics(): Promise<string> {
    return this.register.metrics();
  }
}