/**
 * FLEXORA Gym OS — Item 8 regression test: /metrics endpoint CIDR check.
 *
 * The old implementation did:
 *   ip.startsWith(allowed.split('/')[0].slice(0, -1))
 * For `172.16.0.0/12` this only matched IPs starting with the string
 * "172.16.0." (effectively a /24), not the real /12 range spanning
 * 172.16.0.0 through 172.31.255.255. This suite proves the new
 * ipaddr.js-backed implementation does real, boundary-correct CIDR math.
 */
import { MetricsGuard } from './metrics.guard';
import { ExecutionContext } from '@nestjs/common';

function makeContext(ip: string): ExecutionContext {
  return {
    switchToHttp: () => ({
      getRequest: () => ({ ip, socket: { remoteAddress: ip }, connection: { remoteAddress: ip } }),
    }),
  } as unknown as ExecutionContext;
}

describe('MetricsGuard — Item 8: real CIDR matching', () => {
  let guard: MetricsGuard;

  beforeEach(() => {
    delete process.env.METRICS_ALLOWED_IPS;
    guard = new MetricsGuard();
  });

  describe('172.16.0.0/12 (the exact example from the ticket)', () => {
    it('allows an IP at the START boundary of the /12 range (172.16.0.0)', () => {
      expect(guard.isAllowedIp('172.16.0.0')).toBe(true);
    });

    it('allows an IP at the END boundary of the /12 range (172.31.255.255)', () => {
      expect(guard.isAllowedIp('172.31.255.255')).toBe(true);
    });

    it('allows an IP inside the range that the OLD buggy string-prefix check would have rejected (172.20.5.5)', () => {
      // Old code: '172.20.5.5'.startsWith('172.16.0.') === false -> wrongly rejected.
      // /12 real math: 172.20.5.5 is well inside 172.16.0.0-172.31.255.255 -> must be allowed.
      expect(guard.isAllowedIp('172.20.5.5')).toBe(true);
    });

    it('allows an IP inside the range near the top boundary (172.31.0.1)', () => {
      expect(guard.isAllowedIp('172.31.0.1')).toBe(true);
    });

    it('rejects an IP just OUTSIDE the /12 range, one address above the top boundary (172.32.0.0)', () => {
      expect(guard.isAllowedIp('172.32.0.0')).toBe(false);
    });

    it('rejects an IP just OUTSIDE the /12 range, one address below the bottom boundary (172.15.255.255)', () => {
      expect(guard.isAllowedIp('172.15.255.255')).toBe(false);
    });

    it('rejects an IP the OLD buggy check would have wrongly ACCEPTED (172.160.0.1 — shares the string prefix "172.16" but is a completely different /8 block)', () => {
      expect(guard.isAllowedIp('172.160.0.1')).toBe(false);
    });
  });

  describe('10.0.0.0/8', () => {
    it('allows the start boundary (10.0.0.0)', () => {
      expect(guard.isAllowedIp('10.0.0.0')).toBe(true);
    });
    it('allows the end boundary (10.255.255.255)', () => {
      expect(guard.isAllowedIp('10.255.255.255')).toBe(true);
    });
    it('rejects just outside the range (11.0.0.0)', () => {
      expect(guard.isAllowedIp('11.0.0.0')).toBe(false);
    });
    it('rejects an IP that only shares the "10." string prefix under the old naive check (100.0.0.1)', () => {
      expect(guard.isAllowedIp('100.0.0.1')).toBe(false);
    });
  });

  describe('192.168.0.0/16', () => {
    it('allows the start boundary (192.168.0.0)', () => {
      expect(guard.isAllowedIp('192.168.0.0')).toBe(true);
    });
    it('allows the end boundary (192.168.255.255)', () => {
      expect(guard.isAllowedIp('192.168.255.255')).toBe(true);
    });
    it('rejects just outside the range (192.169.0.0)', () => {
      expect(guard.isAllowedIp('192.169.0.0')).toBe(false);
    });
  });

  describe('localhost / loopback', () => {
    it('allows IPv4 localhost (127.0.0.1)', () => {
      expect(guard.isAllowedIp('127.0.0.1')).toBe(true);
    });

    it('allows IPv6 localhost (::1)', () => {
      expect(guard.isAllowedIp('::1')).toBe(true);
    });

    it('allows IPv4-mapped-IPv6 localhost (::ffff:127.0.0.1) — common real-world Express req.ip value on dual-stack listeners', () => {
      expect(guard.isAllowedIp('::ffff:127.0.0.1')).toBe(true);
    });

    it('allows an IPv4-mapped-IPv6 address inside an allowed CIDR (::ffff:172.20.5.5)', () => {
      expect(guard.isAllowedIp('::ffff:172.20.5.5')).toBe(true);
    });
  });

  describe('public / external IPs are rejected', () => {
    it('rejects a public IP (8.8.8.8)', () => {
      expect(guard.isAllowedIp('8.8.8.8')).toBe(false);
    });

    it('rejects a non-loopback public IPv6 address', () => {
      expect(guard.isAllowedIp('2001:4860:4860::8888')).toBe(false);
    });

    it('rejects empty/undefined input', () => {
      expect(guard.isAllowedIp('')).toBe(false);
      expect(guard.isAllowedIp(undefined)).toBe(false);
      expect(guard.isAllowedIp(null)).toBe(false);
    });

    it('rejects an unparseable garbage string without throwing', () => {
      expect(() => guard.isAllowedIp('not-an-ip-address')).not.toThrow();
      expect(guard.isAllowedIp('not-an-ip-address')).toBe(false);
    });
  });

  describe('canActivate integration (real ExecutionContext shape)', () => {
    it('returns true for an allowed IP', () => {
      expect(guard.canActivate(makeContext('192.168.1.1'))).toBe(true);
    });

    it('throws ForbiddenException for a disallowed IP', () => {
      expect(() => guard.canActivate(makeContext('8.8.8.8'))).toThrow(/access denied/i);
    });
  });

  describe('METRICS_ALLOWED_IPS env override', () => {
    it('respects a custom allow-list from the environment', () => {
      process.env.METRICS_ALLOWED_IPS = '203.0.113.5,198.51.100.0/24';
      const customGuard = new MetricsGuard();
      expect(customGuard.isAllowedIp('203.0.113.5')).toBe(true);
      expect(customGuard.isAllowedIp('198.51.100.42')).toBe(true);
      expect(customGuard.isAllowedIp('198.51.101.1')).toBe(false);
      // Loopback is always allowed regardless of the configured list.
      expect(customGuard.isAllowedIp('127.0.0.1')).toBe(true);
      // The default private ranges are NOT implicitly included once a
      // custom list is provided (env var fully replaces the default).
      expect(customGuard.isAllowedIp('10.1.2.3')).toBe(false);
      delete process.env.METRICS_ALLOWED_IPS;
    });
  });
});
