import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { MonitoringService } from './monitoring.service';
import { Histogram } from 'prom-client';

@Injectable()
export class MetricsInterceptor implements NestInterceptor {
  private readonly httpRequestDuration: Histogram;

  constructor(private readonly monitoringService: MonitoringService) {
    this.httpRequestDuration = new Histogram({
      name: 'http_request_duration_seconds',
      help: 'Duration of HTTP requests in seconds',
      labelNames: ['method', 'route', 'status_code'],
      buckets: [0.1, 0.5, 1, 2, 5],
      registers: [this.monitoringService.register],
    });
  }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const method = req.method;
    const route = req.route?.path || req.url;
    const start = Date.now();

    const endTimer = this.httpRequestDuration.startTimer({
      method,
      route,
    });

    return next.handle().pipe(
      tap(() => {
        endTimer({ status_code: 200 });
      }),
      catchError((err) => {
        const status = err?.status || 500;
        endTimer({ status_code: status });
        return throwError(() => err);
      }),
    );
  }
}