import { Controller, Get, UseGuards, Req, Res } from '@nestjs/common';
import { Response, Request } from 'express';
import { MonitoringService } from './monitoring.service';
import { MetricsGuard } from './metrics.guard';

@Controller('metrics')
@UseGuards(MetricsGuard)
export class MonitoringController {
  constructor(private readonly monitoringService: MonitoringService) {}

  @Get()
  async getMetrics(@Res() res: Response) {
    res.set('Content-Type', this.monitoringService.register.contentType);
    res.end(await this.monitoringService.getMetrics());
  }
}