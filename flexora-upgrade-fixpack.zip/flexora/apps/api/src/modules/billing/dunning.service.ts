/**
 * FLEXORA Gym OS — Billing dunning engine
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { Prisma, MemberStatus, BillingRecoveryStatus, SubscriptionStatus } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { QueueService } from '../queue/queue.module';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

type DunningStage = 'REMINDER_1' | 'REMINDER_2' | 'FINAL_WARNING' | 'SUSPENDED' | 'CANCELED';

@Injectable()
export class DunningService {
  private readonly logger = new Logger(DunningService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
    private readonly cronLeader: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  async checkOverdueSubscriptions(gymId: string) {
    const now = new Date();
    const subscriptions = await this.prisma.subscription.findMany({
      where: { gymId, OR: [{ status: SubscriptionStatus.PAST_DUE }, { currentPeriodEnd: { lt: now } }] },
      include: { gym: true, dunningLogs: { orderBy: { sentAt: 'desc' }, take: 1 } },
    });
    return subscriptions.map((subscription) => ({
      subscriptionId: subscription.id,
      gymId: subscription.gymId,
      gymName: subscription.gym.name,
      status: subscription.status,
      daysOverdue: this.daysOverdue(subscription.currentPeriodEnd),
      stage: this.stageFor(subscription.currentPeriodEnd, subscription.graceDays),
      lastLog: subscription.dunningLogs[0] || null,
    }));
  }

  async processDunningCycle(subscriptionId: string) {
    // Fetch subscription outside withTenant to get the gymId first
    const subRow = await this.prisma.subscription.findUnique({ where: { id: subscriptionId }, include: { gym: true } });
    if (!subRow) return { processed: false, reason: 'subscription_not_found' };
    return this.prisma.withTenant(subRow.gymId, async (tx) => {
      const stage = this.stageFor(subRow.currentPeriodEnd, subRow.graceDays);
      const alreadyLogged = await tx.dunningLog.findFirst({ where: { subscriptionId, stage } });
      if (alreadyLogged) return { processed: false, reason: 'stage_already_processed', stage };

      if (stage === 'SUSPENDED') {
        await tx.subscription.update({ where: { id: subscriptionId }, data: { status: SubscriptionStatus.SUSPENDED, suspendedAt: new Date() } });
        await tx.member.updateMany({ where: { gymId: subRow.gymId, status: { in: [MemberStatus.ACTIVE, MemberStatus.EXPIRED, MemberStatus.FROZEN] } }, data: { status: MemberStatus.SUSPENDED, frozen: true } });
      }
      if (stage === 'CANCELED') {
        await tx.subscription.update({ where: { id: subscriptionId }, data: { status: SubscriptionStatus.CANCELED, cancelledAt: new Date() } });
        await tx.member.updateMany({ where: { gymId: subRow.gymId, status: { not: MemberStatus.CANCELLED } }, data: { status: MemberStatus.CANCELLED, frozen: true } });
      }

      const message = this.messageFor(stage, subRow.gym.name);
      const channels = stage === 'SUSPENDED' || stage === 'CANCELED' ? ['EMAIL'] : ['EMAIL', 'SMS', 'WHATSAPP'];
      for (const channel of channels) {
        await tx.dunningLog.create({ data: { subscriptionId, gymId: subRow.gymId, stage, channel, message } });
        if (channel === 'SMS' || channel === 'WHATSAPP') {
          const queueName = channel === 'SMS' ? 'send-sms' : 'send-whatsapp';
          await this.queue.enqueue(queueName, { gymId: subRow.gymId, to: subRow.gym.phone, body: message });
        }
      }
      await tx.billingRecoveryTask.upsert({
        where: { id: `dunning-${subscriptionId}-${stage}` },
        update: { status: stage === 'CANCELED' ? BillingRecoveryStatus.EXPIRED : BillingRecoveryStatus.PENDING, stage: this.stageNumber(stage), dueAt: new Date(Date.now() + 86400000), notes: message },
        create: { id: `dunning-${subscriptionId}-${stage}`, gymId: subRow.gymId, status: stage === 'CANCELED' ? BillingRecoveryStatus.EXPIRED : BillingRecoveryStatus.PENDING, stage: this.stageNumber(stage), dueAt: new Date(Date.now() + 86400000), notes: message },
      });
      return { processed: true, subscriptionId, stage };
    });
  }

  async dunningStatus(gymId: string) {
    return this.checkOverdueSubscriptions(gymId);
  }

  @Cron('0 9 * * *', { name: 'billing-dunning-daily' })
  async runDailyDunning() {
    return requestContext.run({ requestId: 'cron:dunning-daily' }, async () => {
      const acquired = await this.cronLeader.acquireLock('billing-dunning-daily', 3600000);
      if (!acquired) return;
      try {
      const gyms = await this.prisma.gym.findMany({ where: { status: { in: ['ACTIVE', 'TRIAL'] } }, select: { id: true } });
      for (const gym of gyms) {
        try {
          await this.tenantContext.run(gym.id, async () => {
            const overdue = await this.checkOverdueSubscriptions(gym.id);
            for (const row of overdue) await this.processDunningCycle(row.subscriptionId);
          });
        } catch (error) {
          this.logger.error(`Dunning failed for ${gym.id}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      } finally {
        await this.cronLeader.releaseLock('billing-dunning-daily');
      }
    });
  }

  private daysOverdue(end: Date) {
    return Math.max(0, Math.floor((Date.now() - end.getTime()) / 86400000));
  }

  private stageFor(end: Date, graceDays = 10): DunningStage {
    const days = this.daysOverdue(end);
    if (days >= 30) return 'CANCELED';
    if (days >= graceDays) return 'SUSPENDED';
    if (days >= 7) return 'FINAL_WARNING';
    if (days >= 3) return 'REMINDER_2';
    return 'REMINDER_1';
  }

  private stageNumber(stage: DunningStage) {
    return ({ REMINDER_1: 1, REMINDER_2: 2, FINAL_WARNING: 3, SUSPENDED: 4, CANCELED: 5 })[stage];
  }

  private messageFor(stage: DunningStage, gymName: string) {
    const copy: Record<DunningStage, string> = {
      REMINDER_1: `${gymName}: your FLEXORA subscription payment is overdue. Please update payment today to keep service uninterrupted.`,
      REMINDER_2: `${gymName}: second payment reminder. Your FLEXORA subscription remains past due and requires urgent action.`,
      FINAL_WARNING: `${gymName}: final warning. FLEXORA access will be suspended in 3 days unless payment is completed.`,
      SUSPENDED: `${gymName}: FLEXORA access has been suspended because payment was not completed within the grace period.`,
      CANCELED: `${gymName}: FLEXORA subscription has been canceled after 30 days past due.`,
    };
    return copy[stage];
  }
}
