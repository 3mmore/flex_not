/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { isProduction } from '../../config/env-mode';
import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { MembersService } from '../members/members.service';
import { RedisService } from '../../config/redis.service';
import { BillingService } from './billing.service';
import { Prisma } from '@prisma/client';

export type Tier = 'BASIC' | 'PRO' | 'ELITE';

/** Egyptian market pricing in EGP (piastres handled at order time). */
const EGP_PRICE: Record<Tier, number> = { BASIC: 299, PRO: 599, ELITE: 999 };

/**
 * Paymob (Accept) integration — the dominant Egyptian gateway
 * (Visa, Mastercard, Meeza, Vodafone Cash, Fawry).
 * 3-step flow: auth token -> create order -> payment key -> iframe redirect.
 * Webhook is HMAC-SHA512 verified. Degrades gracefully when unconfigured.
 */
@Injectable()
export class PaymobService {
  private readonly logger = new Logger('Paymob');
  private readonly base = 'https://accept.paymob.com/api';

  constructor(
    private readonly prisma: PrismaService,
    private readonly members: MembersService,
    private readonly redis: RedisService,
    private readonly billing: BillingService,
  ) {}

  get configured(): boolean {
    return !!process.env.PAYMOB_API_KEY && !!process.env.PAYMOB_INTEGRATION_ID;
  }

  priceFor(tier: Tier): number {
    return EGP_PRICE[tier];
  }

  private async authToken(): Promise<string> {
    const res = await fetch(`${this.base}/auth/tokens`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: process.env.PAYMOB_API_KEY }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) throw new BadRequestException(`Paymob auth failed (${res.status})`);
    const data = (await res.json()) as { token: string };
    return data.token;
  }

  /** Creates a Paymob order + payment key, returns the iframe URL for redirect. */
  async createCheckout(gymId: string, tier: Tier) {
    if (!this.configured) {
      if (isProduction()) {
        throw new BadRequestException('Paymob is not configured');
      }
      await this.prisma.subscription.update({
        where: { gymId },
        data: { tier, status: 'ACTIVE', currentPeriodEnd: new Date(Date.now() + 30 * 86400000) },
      });
      return { iframeUrl: null, devApplied: true, tier, amountEGP: this.priceFor(tier) };
    }

    const gym = await this.prisma.gym.findUniqueOrThrow({ where: { id: gymId } });
    const amountCents = this.priceFor(tier) * 100; // Paymob uses piastres
    const token = await this.authToken();

    // Step 2 — create order. merchant_order_id encodes gym+tier for the webhook.
    const merchantOrderId = `${gymId}::${tier}::${Date.now()}`;
    const orderRes = await fetch(`${this.base}/ecommerce/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token,
        delivery_needed: false,
        amount_cents: amountCents,
        currency: 'EGP',
        merchant_order_id: merchantOrderId,
        items: [{ name: `FLEXORA ${tier}`, amount_cents: amountCents, quantity: 1 }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!orderRes.ok) throw new BadRequestException(`Paymob order failed (${orderRes.status})`);
    const order = (await orderRes.json()) as { id: number };
    await this.prisma.paymentAttempt.create({ data: { gymId, provider: 'paymob', providerRef: merchantOrderId, amount: amountCents / 100, currency: 'EGP', status: 'PENDING' } });

    // Step 3 — payment key.
    const keyRes = await fetch(`${this.base}/acceptance/payment_keys`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token,
        amount_cents: amountCents,
        expiration: 3600,
        order_id: order.id,
        currency: 'EGP',
        integration_id: Number(process.env.PAYMOB_INTEGRATION_ID),
        billing_data: {
          email: gym.email || 'owner@flexora.app',
          first_name: gym.name || 'Gym',
          last_name: 'Owner',
          phone_number: gym.phone || '',
          apartment: 'NA', floor: 'NA', street: 'NA', building: 'NA',
          shipping_method: 'NA', postal_code: 'NA', city: 'Cairo',
          country: 'EG', state: 'NA',
        },
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!keyRes.ok) throw new BadRequestException(`Paymob payment key failed (${keyRes.status})`);
    const key = (await keyRes.json()) as { token: string };

    const iframeUrl = `https://accept.paymob.com/api/acceptance/iframes/${process.env.PAYMOB_IFRAME_ID}?payment_token=${key.token}`;
    return { iframeUrl, orderId: order.id, amountEGP: this.priceFor(tier), tier };
  }

  /**
   * ROUND 14 (security review, PHASE F1): member-renewal checkout for the
   * EXACT plan price. The merchant order id binds gym + member + plan, and
   * the webhook only extends the membership after the verified HMAC confirms
   * the payment (amount + member bound, one extension per payment).
   */
  async createRenewalCheckout(gymId: string, memberId: string, planId: string, amountEGP: number) {
    if (!this.configured) throw new BadRequestException('Paymob is not configured');
    const amountCents = Math.round(amountEGP * 100); // Paymob uses piastres
    const token = await this.authToken();
    const merchantOrderId = `RENEWAL::${gymId}::${memberId}::${planId}::${Date.now()}`;
    const orderRes = await fetch(`${this.base}/ecommerce/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token,
        delivery_needed: false,
        amount_cents: amountCents,
        currency: 'EGP',
        merchant_order_id: merchantOrderId,
        items: [{ name: 'Membership renewal', amount_cents: amountCents, quantity: 1 }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!orderRes.ok) throw new BadRequestException(`Paymob order failed (${orderRes.status})`);
    const order = (await orderRes.json()) as { id: number };
    await this.prisma.paymentAttempt.create({
      data: { gymId, provider: 'paymob', providerRef: merchantOrderId, amount: amountEGP, currency: 'EGP', status: 'PENDING' },
    });
    const keyRes = await fetch(`${this.base}/acceptance/payment_keys`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token,
        amount_cents: amountCents,
        expiration: 3600,
        order_id: order.id,
        currency: 'EGP',
        integration_id: Number(process.env.PAYMOB_INTEGRATION_ID),
        billing_data: {
          email: 'member@flexora.app', first_name: 'Member', last_name: 'Renewal',
          phone_number: '', apartment: 'NA', floor: 'NA', street: 'NA', building: 'NA',
          shipping_method: 'NA', postal_code: 'NA', city: 'Cairo', country: 'EG', state: 'NA',
        },
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!keyRes.ok) throw new BadRequestException(`Paymob payment key failed (${keyRes.status})`);
    const key = (await keyRes.json()) as { token: string };
    const iframeUrl = `https://accept.paymob.com/api/acceptance/iframes/${process.env.PAYMOB_IFRAME_ID}?payment_token=${key.token}`;
    return { iframeUrl, orderId: order.id, merchantOrderId, amountEGP };
  }

  /**
   * Verifies the Paymob HMAC-SHA512 signature over the documented ordered
   * field set, then activates the subscription on success.
   */
  async handleWebhook(hmac: string, body: Record<string, unknown>) {
    if (!process.env.PAYMOB_HMAC_SECRET) {
      throw new BadRequestException('Paymob not configured');
    }
    const obj = (body?.obj ?? body) as Record<string, any>;
    const concat = [
      obj.amount_cents, obj.created_at, obj.currency, obj.error_occured,
      obj.has_parent_transaction, obj.id, obj.integration_id, obj.is_3d_secure,
      obj.is_auth, obj.is_capture, obj.is_refunded, obj.is_standalone_payment,
      obj.is_voided, obj.order?.id, obj.owner, obj.pending,
      obj.source_data?.pan, obj.source_data?.sub_type, obj.source_data?.type,
      obj.success,
    ].map((v) => (v === undefined || v === null ? '' : String(v))).join('');

    const expected = createHmac('sha512', process.env.PAYMOB_HMAC_SECRET).update(concat).digest('hex');
    // SECURITY FIX: constant-time comparison prevents timing-attack signature
    // guessing. Length mismatch is handled explicitly first.
    const expectedBuf = Buffer.from(expected, 'hex');
    const gotBuf = Buffer.from(hmac || '', 'hex');
    if (expectedBuf.length !== gotBuf.length || !timingSafeEqual(expectedBuf, gotBuf)) {
      throw new BadRequestException('Invalid Paymob HMAC');
    }

    const merchant: string = (obj.order as Record<string, any>)?.merchant_order_id || '';
    // ROUND 14 (Phase F1): member-renewal orders carry a RENEWAL:: prefix and
    // are confirmed through the renewal-request path (amount + member bound,
    // idempotent — one extension per payment).
    if (merchant.startsWith('RENEWAL::')) {
      const [, gymId, memberId, planId] = merchant.split('::');
      return this.handleRenewalWebhook(gymId, memberId, planId, obj);
    }
    const [gymId, tier] = merchant.split('::');
    if (!gymId) throw new BadRequestException('Paymob webhook missing tenant context');

    const txId = String(obj.id ?? '');
    if (!txId) throw new BadRequestException('Paymob webhook missing transaction id');

    return this.prisma.withTenant(gymId, async (tx) => {
      // ROUND 14 (Phase H4): the (provider, providerTransactionId) claim is
      // unique across the whole platform, not per gym.
      const existingAttempt = await tx.paymentAttempt.findFirst({ where: { provider: 'paymob', OR: [{ providerTransactionId: txId }, { providerRef: txId }] } });
      if (existingAttempt && ['SUCCESS', 'FAILED'].includes(existingAttempt.status)) return { received: true, duplicate: true, status: existingAttempt.status };
      // FIX (Task 1 — nested-transaction atomicity bug): pass THIS
      // transaction's own `tx` down into ingestProviderEvent so it reuses
      // the exact same connection/transaction instead of opening a second,
      // independent one on the root PrismaService. Before this fix, a
      // later failure anywhere else in this handleWebhook transaction body
      // (e.g. the tx.subscription.update / tx.gym.update calls below)
      // would roll back only the calls made directly on `tx`, while
      // ingestProviderEvent's (and, via it, convergeProviderEvent's /
      // reconcileSale's / reconcilePayment's) writes — made through their
      // own separate transaction — stayed committed. Confirmed for real
      // against Postgres in
      // src/test/integration/paymob-billing-nested-transaction-fix.spec.ts.
      const providerEvent = await this.billing.ingestProviderEvent(gymId, 'paymob', txId, 'paymob.transaction', body, tx);
      if (providerEvent.duplicate) {
        this.logger.log(`Paymob webhook ${txId} already processed — skipping`);
        return { received: true, duplicate: true };
      }

      const success = obj.success === true || obj.success === 'true';
      const isRefundOrVoid = obj.is_refunded === true || String(obj.is_refunded) === 'true' || obj.is_voided === true || String(obj.is_voided) === 'true';

      if (isRefundOrVoid) {
        this.logger.log(`Paymob transaction refunded/voided: ${txId}`);
        await tx.paymentAttempt.upsert({
          where: { provider_providerTransactionId: { provider: 'paymob', providerTransactionId: txId } },
          update: { status: 'REFUNDED' },
          create: { gymId, provider: 'paymob', providerRef: txId, providerTransactionId: txId, status: 'REFUNDED', amount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP' },
        });
        if (tier) {
          await tx.subscription.updateMany({
            where: { gymId },
            data: { status: 'CANCELED' },
          });
          await tx.gym.updateMany({ where: { id: gymId }, data: { status: 'SUSPENDED' } });
        }
        return { received: true, applied: true, refunded: true };
      }

      if (!success) {
        this.logger.warn(`Paymob transaction not successful: order ${(obj.order as Record<string, any>)?.id}`);
        await tx.paymentAttempt.upsert({
          where: { provider_providerTransactionId: { provider: 'paymob', providerTransactionId: txId } },
          update: { status: 'FAILED', error: 'Paymob transaction failed' },
          create: { gymId, provider: 'paymob', providerRef: txId, providerTransactionId: txId, status: 'FAILED', amount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP', error: 'Paymob transaction failed' },
        });
        await tx.billingRecoveryTask.create({ data: { gymId, status: 'FAILED', stage: 1, dueAt: new Date(Date.now() + 24 * 3600000), notes: 'Paymob payment failed' } });
        await tx.financialReconciliation.upsert({
          where: { gymId_sourceType_sourceId: { gymId, sourceType: 'SUBSCRIPTION', sourceId: txId } },
          update: { provider: 'paymob', providerRef: txId, expectedAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, providerAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP', status: 'PROVIDER_FAILED', reason: 'Paymob transaction failed' },
          create: { gymId, sourceType: 'SUBSCRIPTION', sourceId: txId, provider: 'paymob', providerRef: txId, expectedAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, providerAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP', status: 'PROVIDER_FAILED', reason: 'Paymob transaction failed' },
        });
        return { received: true, applied: false };
      }

      await tx.paymentAttempt.upsert({
        where: { provider_providerTransactionId: { provider: 'paymob', providerTransactionId: txId } },
        update: { status: 'SUCCESS', amount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP' },
        create: { gymId, orderId: String((obj.order as Record<string, any>)?.id || ''), provider: 'paymob', providerRef: txId, providerTransactionId: txId, status: 'SUCCESS', amount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: (obj.currency as string) || 'EGP' },
      });

      if (tier) {
        await tx.subscription.update({
          where: { gymId },
          data: { tier: tier as Tier, status: 'ACTIVE', currentPeriodEnd: new Date(Date.now() + 30 * 86400000) },
        });
        await tx.gym.update({ where: { id: gymId }, data: { status: 'ACTIVE' } });
        await tx.financialReconciliation.upsert({
          where: { gymId_sourceType_sourceId: { gymId, sourceType: 'SUBSCRIPTION', sourceId: txId } },
          update: { provider: 'paymob', providerRef: txId, expectedAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, providerAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: obj.currency || 'EGP', status: 'RECONCILED', reason: 'Paymob transaction successful' },
          create: { gymId, sourceType: 'SUBSCRIPTION', sourceId: txId, provider: 'paymob', providerRef: txId, expectedAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, providerAmount: obj.amount_cents ? Number(obj.amount_cents) / 100 : 0, currency: obj.currency || 'EGP', status: 'RECONCILED', reason: 'Paymob transaction successful' },
        });
      }
      return { received: true, applied: true };
    }, { isolationLevel: 'Serializable' as any });
  }

  /**
   * ROUND 14 (security review, PHASE F1) + PHASE G1: a verified Paymob webhook
   * for a member-renewal order. The HMAC was already verified by handleWebhook.
   *
   * Idempotency is keyed on the PROVIDER TRANSACTION, not the request: inside
   * the serializable transaction the transaction id is ATOMICALLY CLAIMED by
   * inserting a PaymentAttempt on the unique (gymId, provider,
   * providerTransactionId) key. A re-delivered or replayed signed webhook —
   * even when a NEW open request exists for the same member and plan — hits
   * the unique violation (or an existing SUCCESS row) and applies NOTHING.
   *
   * The membership extends ONLY here, exactly once per provider transaction:
   *   - the open RenewalRequest binds member + plan + amount, and the webhook's
   *     member/plan context must match the request row (and, when bound, the
   *     checkout's merchant order id),
   *   - the paid amount must equal the plan price (amount bound),
   *   - the request transitions PENDING/CHECKOUT → PAID exactly once,
   *   - the claimed transaction is bound to the request that consumed it,
   *   - the extension + invoice + payment + ledger row happen in one tx.
   */
  private async handleRenewalWebhook(gymId: string, memberId: string, planId: string, obj: Record<string, any>) {
    if (!gymId || !memberId || !planId) throw new BadRequestException('Renewal webhook missing context');
    const success = obj.success === true || obj.success === 'true';
    const pending = obj.pending === true || obj.pending === 'true';
    const failedFinal =
      obj.error_occured === true || String(obj.error_occured) === 'true' ||
      obj.is_voided === true || String(obj.is_voided) === 'true';
    const amountPaid = Number(obj.amount_cents || 0) / 100;
    const txId = String(obj.id ?? '');
    if (!txId) throw new BadRequestException('Paymob webhook missing transaction id');
    const merchantOrderId = String((obj.order as Record<string, any>)?.merchant_order_id || '');
    // PHASE H4: the SIGNED order id (order.id is covered by the HMAC —
    // merchant_order_id is NOT). The request must have been created for this
    // exact signed order.
    const signedOrderId = String((obj.order as Record<string, any>)?.id ?? '');
    // PHASE H3: Paymob sends pending=true first and success later for the same
    // transaction id (wallet / cash-collection methods). A pending webhook must
    // NOT claim the transaction id — otherwise the later verified success could
    // never apply. Ignore it entirely.
    if (pending) {
      return { received: true, ignored: true };
    }

    // ══ PHASE J1 — CLAIM AND APPLY IN *ONE* SERIALIZABLE TRANSACTION ═════════
    // The provider-transaction claim used to be committed in its own short
    // transaction BEFORE the apply step ran. Any rejection in the apply step
    // (no CHECKOUT-bound request, signed-order mismatch, amount mismatch,
    // member/plan mismatch) therefore left a PENDING claim behind FOREVER:
    // every later delivery of the same transaction id answered `duplicate` and
    // could never be applied again — a legitimately paid renewal was lost for
    // good, and a tampered replay could poison a real transaction id.
    //
    // The claim and the apply now share ONE serializable transaction, so a
    // rejection rolls the claim back together with everything else and the
    // transaction id stays available for the next (corrected) delivery. ONLY a
    // successful application or a final failure (error_occured / voided) leaves
    // a permanent claim behind.
    //
    // The unique violation (P2002) and the serialization / write-conflict
    // failures Postgres raises under SERIALIZABLE isolation (P2034, 40001,
    // deadlock) are caught OUTSIDE withTenant — a concurrent duplicate delivery
    // still answers 2xx { duplicate: true } and never a 500.
    const MAX_ATTEMPTS = 3;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
      try {
        return await this.prisma.withTenant(gymId, async (tx) => {
          // ── 1. ATOMIC CLAIM of the provider transaction — the idempotency
          //       key, unique across the WHOLE PLATFORM
          //       (provider, providerTransactionId), not per gym (PHASE H4).
          //       This also covers a replayed signed webhook with a tampered
          //       merchant_order_id (a different gym/member): the platform-wide
          //       claim is already held by the legitimate delivery.
          const existing = await tx.paymentAttempt.findFirst({
            where: { provider: 'paymob', providerTransactionId: txId },
          });
          if (existing) return { received: true, duplicate: true }; // already claimed — apply NOTHING
          await tx.paymentAttempt.create({
            data: {
              gymId,
              provider: 'paymob',
              providerTransactionId: txId,
              providerRef: merchantOrderId || txId,
              status: 'PENDING',
              amount: amountPaid,
              currency: 'EGP',
            },
          });

          // ── 2. the request must be CHECKOUT-bound to THIS signed order id ──
          // PHASE I2 — FAIL CLOSED: a renewal webhook is only applied to a
          // request in CHECKOUT status that carries a non-null providerOrderId
          // equal to the signed order.id. merchant_order_id is NOT covered by
          // the Paymob HMAC and is never trusted alone; a request created
          // without a checkout (no providerOrderId) cannot be webhook-renewed
          // at all.
          // PHASE J1: throwing here ROLLS THE CLAIM BACK — the transaction id
          // is not consumed by a rejected delivery.
          const request = await tx.renewalRequest.findFirst({
            where: {
              gymId,
              memberId,
              planId,
              status: 'CHECKOUT',
              providerOrderId: { not: null },
            },
            orderBy: { createdAt: 'desc' },
          });
          if (!request) {
            throw new BadRequestException('No checkout-bound renewal request for this payment');
          }
          // when the request is bound to a checkout, the payment must be that one
          if (request.providerRef && merchantOrderId && request.providerRef !== merchantOrderId) {
            throw new BadRequestException('This payment does not match the open renewal request');
          }
          // PHASE H4+I2: bind the claim to the signed order id — it must match.
          if (signedOrderId !== request.providerOrderId) {
            throw new BadRequestException('This payment does not match the signed order for the open renewal request');
          }

          // ── 3. final failure → the claim becomes permanent FAILED; a later
          //       success for this transaction id is rejected (already claimed) ──
          if (!success || failedFinal) {
            await tx.paymentAttempt.updateMany({
              where: { provider: 'paymob', providerTransactionId: txId },
              data: { status: 'FAILED', error: 'Paymob transaction failed' },
            });
            return { received: true, applied: false };
          }

          // ── 4. amount bound: the paid amount must equal the plan price ──
          if (Math.abs(amountPaid - Number(request.amount)) > 0.01) {
            throw new BadRequestException('Paid amount does not match the renewal amount');
          }

          // ── 5. claim the request (idempotent transition) ──
          const transitioned = await tx.renewalRequest.updateMany({
            where: { id: request.id, status: 'CHECKOUT' },
            data: { status: 'PAID', decidedAt: new Date() },
          });
          if (transitioned.count !== 1) {
            return { received: true, duplicate: true };
          }

          // ── 6. bind the claimed transaction to the request that consumed it ──
          await tx.paymentAttempt.updateMany({
            where: { provider: 'paymob', providerTransactionId: txId },
            data: {
              status: 'SUCCESS',
              providerRef: request.providerRef ?? merchantOrderId ?? txId,
              amount: amountPaid,
              currency: 'EGP',
            },
          });

          // ── 7. extend + book, in this same transaction ──
          const applied = await this.members.applyPaidRenewal(gymId, memberId, planId, {
            amount: amountPaid,
            providerRef: request.providerRef ?? txId,
            method: 'ONLINE',
          }, tx);
          await tx.renewalRequest.update({
            where: { id: request.id },
            data: { invoiceId: applied.invoice.id },
          });
          return { received: true, applied: true, renewalRequestId: request.id };
        }, { isolationLevel: 'Serializable' as any });
      } catch (e: unknown) {
        if (this.isClaimConflict(e) && attempt < MAX_ATTEMPTS) {
          // A concurrent delivery won the claim or hit a write conflict. The
          // retry re-reads the claim: if the competing delivery COMMITTED it,
          // this answers duplicate; if it was rejected and rolled back too, the
          // transaction id is free again and this delivery applies it.
          continue;
        }
        if (this.isClaimConflict(e)) {
          // Retries exhausted — answer duplicate (2xx) so Paymob stops
          // re-delivering, and never surface the conflict as a 500.
          this.logger.warn(`Paymob renewal webhook ${txId}: concurrent claim conflict — answering duplicate`);
          return { received: true, duplicate: true };
        }
        throw e;
      }
    }
    return { received: true, duplicate: true };
  }

  /**
   * PHASE J1: the recoverable "another delivery got there first" failures of
   * the provider-transaction claim — the unique violation on
   * (provider, providerTransactionId) (P2002) and the serialization /
   * write-conflict failures Postgres raises under SERIALIZABLE isolation
   * (Prisma P2034, SQLSTATE 40001 / 40P01, deadlock).
   *
   * Everything else — notably the BadRequestException raised by the apply
   * rules (no checkout-bound request, signed-order mismatch, amount mismatch)
   * — is a REAL error and must propagate (and, thanks to J1, roll the claim
   * back with it).
   */
  private isClaimConflict(e: unknown): boolean {
    const code = String((e as Record<string, any>)?.code || '');
    if (code === 'P2002' || code === 'P2034') return true;
    const msg = String((e as Record<string, any>)?.message || '');
    return /could not serialize access|deadlock detected|write conflict/i.test(msg);
  }
}
