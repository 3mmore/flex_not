/**
 * FLEXORA Gym OS — Billing module (Phase 8)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { forwardRef, Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { BillingService } from './billing.service';
import { DunningService } from './dunning.service';
import { BillingController } from './billing.controller';
import { PaymobService } from './paymob.service';
import { PaymobController } from './paymob.controller';
import { LicenseModule } from '../license/license.module';
import { MembersModule } from '../members/members.module';
import { PrismaModule } from '../../config/prisma.module';
import { QueueModule } from '../queue/queue.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  // ROUND 14 (Phase F1): PaymobService confirms member renewals through
  // MembersService.applyPaidRenewal (verified webhook path). MembersModule
  // does not import BillingModule, so there is no cycle.
  // ROUND 14 (security review, PHASE K4): MembersModule now imports
  // BillingModule (a member activation records its payment in the same
  // transaction), so this side of the cycle needs forwardRef too — otherwise
  // MembersModule is still undefined when BillingModule is scanned.
  imports: [JwtModule.register({}), LicenseModule, PrismaModule, QueueModule, NotificationsModule, forwardRef(() => MembersModule)],
  controllers: [BillingController, PaymobController],
  providers: [BillingService, PaymobService, DunningService],
  exports: [BillingService, PaymobService, DunningService],
})
export class BillingModule {}
