import { BadRequestException } from '@nestjs/common';
import { createHmac } from 'crypto';
import { BillingService } from './billing.service';
import { PaymobService } from './paymob.service';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { EncryptionService } from '../../common/security/encryption.service';

type Db = ReturnType<typeof buildDb>;

function buildDb(seed: Partial<{
  sales: any[];
  refunds: any[];
  subscriptions: any[];
}> = {}) {
  return {
    now: 0,
    events: [] as any[],
    recons: [] as any[],
    sales: seed.sales || [],
    refunds: seed.refunds || [],
    refundAudits: [] as any[],
    invoices: [] as any[],
    payments: [] as any[],
    receipts: [] as any[],
    subscriptions: seed.subscriptions || [{ id: 'sub-local', gymId: 'g1', status: 'ACTIVE', stripeSubscriptionId: 'sub_1' }],
    attempts: [] as any[],
    recoveryTasks: [] as any[],
    gymUpdates: [] as any[],
  };
}

function matchesWhere(row: any, where: any): boolean {
  if (!where) return true;
  return Object.entries(where).every(([key, expected]: [string, any]) => {
    const actual = row[key];
    if (expected && typeof expected === 'object' && !Array.isArray(expected)) {
      if ('in' in expected) return (expected as any).in.includes(actual);
      return JSON.stringify(actual) === JSON.stringify(expected);
    }
    return actual === expected;
  });
}

function prismaFor(db: Db): any {
  const prisma: any = {
    withTenant: jest.fn(async (_gymId: any, cb: any, _opts?: any) => prisma.$transaction(cb, _opts)),
    $executeRaw: jest.fn().mockResolvedValue([[], []]),
    $transaction: jest.fn(async (cb: any, opts?: any) => {
        if (typeof cb === 'function') return cb(prisma);
        return cb;
    }),
    TransactionIsolationLevel: { Serializable: 'Serializable' },
    sale: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.sales.find((s) => matchesWhere(s, where)) || null)),
      findMany: jest.fn(({ where }: any = {}) => Promise.resolve(db.sales.filter((s) => matchesWhere(s, where)))),
    },
    invoice: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.invoices.find((i) => matchesWhere(i, where)) || null)),
      create: jest.fn(({ data }: any) => {
        const row = { id: `inv-${db.invoices.length + 1}`, ...data };
        db.invoices.push(row);
        return Promise.resolve(row);
      }),
    },
    payment: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.payments.find((p) => matchesWhere(p, where)) || null)),
      findMany: jest.fn(({ where }: any = {}) => Promise.resolve(db.payments.filter((p) => matchesWhere(p, where)))),
      create: jest.fn(({ data }: any) => {
        const row = { id: `pay-${db.payments.length + 1}`, ...data };
        db.payments.push(row);
        return Promise.resolve(row);
      }),
    },
    receipt: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.receipts.find((r) => matchesWhere(r, where)) || null)),
      create: jest.fn(({ data }: any) => {
        const row = { id: `receipt-${db.receipts.length + 1}`, ...data };
        db.receipts.push(row);
        return Promise.resolve(row);
      }),
    },
    refund: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.refunds.find((r) => matchesWhere(r, where)) || null)),
      findMany: jest.fn(({ where }: any = {}) => Promise.resolve(db.refunds.filter((r) => matchesWhere(r, where)))),
    },
    refundAudit: {
      create: jest.fn(({ data }: any) => {
        const row = { id: `audit-${db.refundAudits.length + 1}`, ...data };
        db.refundAudits.push(row);
        return Promise.resolve(row);
      }),
    },
    financialReconciliation: {
      upsert: jest.fn(({ where, update, create }: any) => {
        const key = where.gymId_sourceType_sourceId;
        let row = db.recons.find((r) => r.gymId === key.gymId && r.sourceType === key.sourceType && r.sourceId === key.sourceId);
        if (row) {
          Object.assign(row, update, { updatedAt: new Date(++db.now) });
          return Promise.resolve(row);
        }
        row = { id: `fr-${db.recons.length + 1}`, ...create, updatedAt: new Date(++db.now) };
        db.recons.push(row);
        return Promise.resolve(row);
      }),
      findUnique: jest.fn(({ where }: any) => {
        const key = where.gymId_sourceType_sourceId;
        return Promise.resolve(db.recons.find((r) => r.gymId === key.gymId && r.sourceType === key.sourceType && r.sourceId === key.sourceId) || null);
      }),
      findMany: jest.fn(({ where }: any = {}) => Promise.resolve(db.recons.filter((r) => matchesWhere(r, where)))),
    },
    paymentProviderEvent: {
      findUnique: jest.fn(({ where }: any) => {
        const key = where.provider_eventId;
        return Promise.resolve(db.events.find((e) => e.provider === key.provider && e.eventId === key.eventId) || null);
      }),
      create: jest.fn(({ data }: any) => {
        const duplicate = db.events.find((e) => e.provider === data.provider && e.eventId === data.eventId);
        if (duplicate) {
          const err: any = new Error('duplicate');
          err.code = 'P2002';
          throw err;
        }
        const row = { id: `evt-row-${db.events.length + 1}`, receivedAt: new Date(++db.now), ...data };
        db.events.push(row);
        return Promise.resolve(row);
      }),
      findMany: jest.fn(({ where }: any = {}) => {
        const rows = db.events
          .filter((e) => matchesWhere(e, where))
          .sort((a, b) => Number(b.receivedAt) - Number(a.receivedAt));
        return Promise.resolve(rows);
      }),
    },
    subscription: {
      findFirst: jest.fn(({ where }: any) => Promise.resolve(db.subscriptions.find((s) => matchesWhere(s, where)) || null)),
      findMany: jest.fn(({ where }: any = {}) => Promise.resolve(db.subscriptions.filter((s) => matchesWhere(s, where)))),
      update: jest.fn(({ where, data }: any) => {
        const row = db.subscriptions.find((s) => matchesWhere(s, where)) || db.subscriptions[0];
        Object.assign(row, data);
        return Promise.resolve(row);
      }),
      updateMany: jest.fn(({ where, data }: any) => {
        const rows = db.subscriptions.filter((s) => matchesWhere(s, where));
        rows.forEach((row) => Object.assign(row, data));
        return Promise.resolve({ count: rows.length });
      }),
      upsert: jest.fn(({ where, create, update }: any) => {
        let row = db.subscriptions.find((s) => matchesWhere(s, where));
        if (row) {
          Object.assign(row, update);
          return Promise.resolve(row);
        }
        row = { id: `sub-${db.subscriptions.length + 1}`, ...create };
        db.subscriptions.push(row);
        return Promise.resolve(row);
      }),
    },
    paymentAttempt: {
      create: jest.fn(({ data }: any) => {
        const row = { id: `attempt-${db.attempts.length + 1}`, ...data };
        db.attempts.push(row);
        return Promise.resolve(row);
      }),
      findFirst: jest.fn(({ where }: any = {}) => Promise.resolve(db.attempts.find((t) => matchesWhere(t, where)) || null)),
      upsert: jest.fn(({ where, create, update }: any) => {
        let row = db.attempts.find((t) => matchesWhere(t, where));
        if (row) {
          Object.assign(row, update);
          return Promise.resolve(row);
        }
        row = { id: `attempt-${db.attempts.length + 1}`, ...create };
        db.attempts.push(row);
        return Promise.resolve(row);
      }),
    },
    billingRecoveryTask: {
      create: jest.fn(({ data }: any) => {
        const row = { id: `task-${db.recoveryTasks.length + 1}`, ...data };
        db.recoveryTasks.push(row);
        return Promise.resolve(row);
      }),
      findFirst: jest.fn(({ where }: any = {}) => Promise.resolve(db.recoveryTasks.find((t) => matchesWhere(t, where)) || null)),
      findMany: jest.fn(() => Promise.resolve(db.recoveryTasks)),
      update: jest.fn(({ where, data }: any) => {
        const row = db.recoveryTasks.find((t) => matchesWhere(t, where));
        Object.assign(row, data);
        return Promise.resolve(row);
      }),
    },
    gym: {
      update: jest.fn(({ where, data }: any) => {
        db.gymUpdates.push({ where, data });
        return Promise.resolve({ id: where.id, ...data });
      }),
      updateMany: jest.fn(({ where, data }: any) => {
        db.gymUpdates.push({ where, data, many: true });
        return Promise.resolve({ count: 1 });
      }),
      findUnique: jest.fn(({ where }: any) => Promise.resolve({ id: where.id, phone: '0123456789' })),
    },
  };
  return prisma;
}

function billingWithStripe(db: Db, eventFactory: () => any) {
  process.env.STRIPE_WEBHOOK_SECRET = 'whsec_validation';
  const prisma = prismaFor(db);
  const notifications: any = { whatsapp: jest.fn() };
  const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
  const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
  const svc = new BillingService(prisma, notifications, cronLeadership, encryption);
  (svc as any).stripe = {
    webhooks: { constructEvent: jest.fn(() => eventFactory()) },
    subscriptions: { retrieve: jest.fn().mockResolvedValue({ current_period_end: 2_000_000_000 }) },
    refunds: { create: jest.fn().mockResolvedValue({ id: 're_created', amount: 5000, currency: 'egp', status: 'succeeded' }) },
  };
  return { svc, prisma };
}

function sale(id: string, gymId: string, reference: string | null, total = 100, method = 'CARD') {
  return {
    id,
    gymId,
    invoiceNo: `INV-${id}`,
    subtotal: total,
    total,
    paymentMethod: method,
    paymentReference: reference,
    memberId: null,
    userName: 'validation',
    items: [{ id: `item-${id}`, name: 'Validation item', qty: 1, price: total }],
  };
}

async function replayTwice(svc: BillingService) {
  const first = await svc.handleWebhook('sig', Buffer.from('{}'));
  const second = await svc.handleWebhook('sig', Buffer.from('{}'));
  expect(first).toEqual({ received: true });
  expect(second).toEqual({ received: true, duplicate: true });
}

function paymobHmac(obj: any, secret: string) {
  const concat = [
    obj.amount_cents, obj.created_at, obj.currency, obj.error_occured,
    obj.has_parent_transaction, obj.id, obj.integration_id, obj.is_3d_secure,
    obj.is_auth, obj.is_capture, obj.is_refunded, obj.is_standalone_payment,
    obj.is_voided, obj.order?.id, obj.owner, obj.pending,
    obj.source_data?.pan, obj.source_data?.sub_type, obj.source_data?.type,
    obj.success,
  ].map((v) => (v === undefined || v === null ? '' : String(v))).join('');
  return createHmac('sha512', secret).update(concat).digest('hex');
}

function paymobBody(id: string, success: boolean, gymId = 'g1', tier = 'PRO', is_refunded = false) {
  return {
    obj: {
      amount_cents: 59900,
      created_at: '2026-06-16T00:00:00.000Z',
      currency: 'EGP',
      error_occured: !success,
      has_parent_transaction: false,
      id,
      integration_id: 123,
      is_3d_secure: true,
      is_auth: false,
      is_capture: false,
      is_refunded,
      is_standalone_payment: true,
      is_voided: false,
      order: { id: 987, merchant_order_id: `${gymId}::${tier}::validation` },
      owner: 1,
      pending: false,
      source_data: { pan: '2346', sub_type: 'MasterCard', type: 'card' },
      success,
    },
  };
}

describe('External provider validation — Stripe sandbox simulations', () => {
  afterEach(() => delete process.env.STRIPE_WEBHOOK_SECRET);

  it.each([
    ['payment_intent.succeeded', 'pi_ok', 'amount_received'],
    ['charge.succeeded', 'ch_ok', 'amount'],
  ])('%s is idempotent and converges sale/payment reconciliation', async (type, providerRef, amountField) => {
    const db = buildDb({ sales: [sale(`sale-${providerRef}`, 'g1', providerRef)] });
    const { svc } = billingWithStripe(db, () => ({
      id: `evt_${providerRef}`,
      type,
      data: { object: { id: providerRef, [amountField]: 10000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
    }));

    await replayTwice(svc);

    expect(db.events).toHaveLength(1);
    expect(db.invoices).toHaveLength(1);
    expect(db.payments).toHaveLength(1);
    expect(db.receipts).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'SALE' && r.sourceId === `sale-${providerRef}`)?.status).toBe('RECONCILED');
    expect(db.recons.find((r) => r.sourceType === 'PAYMENT')?.status).toBe('RECONCILED');
  });

  it.each([
    ['payment_intent.payment_failed', 'pi_fail'],
    ['charge.failed', 'ch_fail'],
  ])('%s records unmatched provider failure exactly once', async (type, providerRef) => {
    const db = buildDb();
    const { svc } = billingWithStripe(db, () => ({
      id: `evt_${providerRef}`,
      type,
      data: { object: { id: providerRef, amount: 12000, currency: 'egp', status: 'failed', metadata: { gymId: 'g1' } } },
    }));

    await replayTwice(svc);

    expect(db.events).toHaveLength(1);
    expect(db.recons).toHaveLength(1);
    expect(db.recons[0]).toEqual(expect.objectContaining({ sourceType: 'PAYMENT', sourceId: providerRef, provider: 'stripe', providerRef, status: 'PROVIDER_FAILED' }));
  });

  it('checkout.session.completed is idempotent and activates subscription once', async () => {
    const db = buildDb({ subscriptions: [{ id: 'sub-local', gymId: 'g1', status: 'PAST_DUE' }] });
    const { svc, prisma } = billingWithStripe(db, () => ({
      id: 'evt_checkout_validation',
      type: 'checkout.session.completed',
      data: { object: { metadata: { gymId: 'g1', tier: 'PRO' }, customer: 'cus_1', subscription: 'sub_1' } },
    }));

    await replayTwice(svc);

    expect(db.events).toHaveLength(1);
    expect(prisma.subscription.upsert).toHaveBeenCalledTimes(1);
    expect(db.subscriptions[0]).toEqual(expect.objectContaining({ status: 'ACTIVE', tier: 'PRO', stripeCustomerId: 'cus_1', stripeSubscriptionId: 'sub_1' }));
    expect(db.recons.find((r) => r.sourceType === 'SUBSCRIPTION')?.status).toBe('RECONCILED');
  });

  it.each([
    ['active', 'RECONCILED', 0],
    ['past_due', 'PENDING', 1],
    ['canceled', 'RECONCILED', 0],
  ])('customer.subscription.updated status=%s is idempotent and tracked', async (stripeStatus, reconciliationStatus, recoveryTasks) => {
    const db = buildDb({ subscriptions: [{ id: `sub-${stripeStatus}`, gymId: 'g1', status: 'ACTIVE', stripeSubscriptionId: `sub_${stripeStatus}` }] });
    const { svc } = billingWithStripe(db, () => ({
      id: `evt_sub_updated_${stripeStatus}`,
      type: 'customer.subscription.updated',
      data: { object: { id: `sub_${stripeStatus}`, status: stripeStatus, current_period_end: 2_000_000_000, currency: 'egp' } },
    }));

    await replayTwice(svc);

    expect(db.events).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'SUBSCRIPTION')?.status).toBe(reconciliationStatus);
    expect(db.recoveryTasks).toHaveLength(recoveryTasks);
  });

  it('customer.subscription.deleted is idempotent and marks cancellation without duplicate mutation', async () => {
    const db = buildDb({ subscriptions: [{ id: 'sub-local', gymId: 'g1', status: 'ACTIVE', stripeSubscriptionId: 'sub_deleted' }] });
    const { svc } = billingWithStripe(db, () => ({
      id: 'evt_sub_deleted',
      type: 'customer.subscription.deleted',
      data: { object: { id: 'sub_deleted' } },
    }));

    await replayTwice(svc);

    expect(db.events).toHaveLength(1);
    expect(db.subscriptions[0].status).toBe('CANCELED');
    expect(db.recons.find((r) => r.sourceType === 'SUBSCRIPTION')?.status).toBe('PENDING');
  });

  it('refund.created webhook converges a delayed refund reconciliation', async () => {
    const db = buildDb({
      sales: [sale('sale-refund-delayed', 'g1', 'pi_refund_delayed', 50)],
      refunds: [{ id: 'refund-delayed', gymId: 'g1', saleId: 'sale-refund-delayed', amount: 50 }],
    });
    const prisma = prismaFor(db);
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const svc = new BillingService(prisma, notifications, cronLeadership, encryption);
    (svc as any).stripe = null;

    await svc.syncRefund('g1', 'refund-delayed');
    expect(db.recons.find((r) => r.sourceType === 'REFUND')?.status).toBe('PROVIDER_FAILED');

    process.env.STRIPE_WEBHOOK_SECRET = 'whsec_validation';
    (svc as any).stripe = {
      webhooks: { constructEvent: jest.fn(() => ({
        id: 'evt_refund_created',
        type: 'refund.created',
        data: { object: { id: 're_delayed', payment_intent: 'pi_refund_delayed', amount: 5000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
      })) },
    };

    await replayTwice(svc);

    expect(db.events.filter((e) => e.provider === 'stripe' && e.eventId === 'evt_refund_created')).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'REFUND')?.status).toBe('RECONCILED');
  });
});

describe('External provider validation — Paymob sandbox simulations', () => {
  const oldSecret = process.env.PAYMOB_HMAC_SECRET;
  afterEach(() => {
    process.env.PAYMOB_HMAC_SECRET = oldSecret;
    jest.restoreAllMocks();
  });

  it.each([
    [true, 'RECONCILED'],
    [false, 'PROVIDER_FAILED'],
  ])('transaction webhook success=%s validates HMAC, stores once, and reconciles subscription as %s', async (success, status) => {
    process.env.PAYMOB_HMAC_SECRET = 'paymob_secret';
    const db = buildDb({ subscriptions: [{ id: 'sub-paymob', gymId: 'g1', status: 'PAST_DUE' }] });
    const prisma = prismaFor(db);
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const billing = new BillingService(prisma, notifications, cronLeadership, encryption);
    const paymob = new PaymobService(prisma, {} as any, {} as any, billing);
    const body = paymobBody(success ? '700001' : '700002', success);
    const hmac = paymobHmac(body.obj, process.env.PAYMOB_HMAC_SECRET);

    const first = await paymob.handleWebhook(hmac, body);
    const duplicate = await paymob.handleWebhook(hmac, body);

    expect(first).toEqual(expect.objectContaining({ received: true }));
    expect(duplicate).toEqual({ received: true, duplicate: true });
    expect(db.events).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'SUBSCRIPTION')?.status).toBe(status);
    if (!success) expect(db.recoveryTasks).toHaveLength(1);
  });

  it('rejects invalid Paymob HMAC without mutating financial state', async () => {
    process.env.PAYMOB_HMAC_SECRET = 'paymob_secret';
    const db = buildDb();
    const prisma = prismaFor(db);
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const paymob = new PaymobService(prisma, {} as any, {} as any, new BillingService(prisma, notifications, cronLeadership, encryption));
    await expect(paymob.handleWebhook('incorrect_hmac', paymobBody('700003', true))).rejects.toBeInstanceOf(BadRequestException);
    expect(db.events).toHaveLength(0);
    expect(db.recons).toHaveLength(0);
  });

  it('handles refund webhooks by marking as REFUNDED and suspending gym (success: true, is_refunded: true)', async () => {
    process.env.PAYMOB_HMAC_SECRET = 'paymob_secret';
    const db = buildDb({
      subscriptions: [{ id: 'sub-refund', gymId: 'g1', status: 'ACTIVE', tier: 'PRO' }],
      gyms: [{ id: 'g1', status: 'ACTIVE' }],
      paymentAttempts: [],
    });
    const prisma = prismaFor(db);
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const billing = new BillingService(prisma, notifications, cronLeadership, encryption);
    const paymob = new PaymobService(prisma, {} as any, {} as any, billing);
    
    const body = paymobBody('700003', true, 'g1', 'PRO', true); // success: true, is_refunded: true
    const hmac = paymobHmac(body.obj, process.env.PAYMOB_HMAC_SECRET);

    const result = await paymob.handleWebhook(hmac, body);
    
    expect(result).toEqual({ received: true, applied: true, refunded: true });
    
    const attempt = db.attempts.find((a) => a.providerTransactionId === '700003');
    expect(attempt?.status).toBe('REFUNDED');
    
    // We mock updateMany for subscription so let's check it. In buildDb it modifies db.subscriptions for update but not updateMany? 
    // Wait, updateMany in subscription mock:
    // It updates db.subscriptions if it finds it. Let's look at the mock.
    const subscription = db.subscriptions.find((s) => s.gymId === 'g1');
    expect(subscription?.status).toBe('CANCELED');
    
    const gymUpdate = db.gymUpdates.find((g) => g.where.id === 'g1');
    expect(gymUpdate?.data?.status).toBe('SUSPENDED');
  });

  it('refund request success stores provider event and reconciles refund once', async () => {
    process.env.PAYMOB_API_KEY = 'api_key';
    const db = buildDb({
      sales: [sale('sale-paymob-refund', 'g1', '800001', 25)],
      refunds: [{ id: 'refund-paymob-ok', gymId: 'g1', saleId: 'sale-paymob-refund', amount: 25 }],
    });
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const svc = new BillingService(prismaFor(db), notifications, cronLeadership, encryption);
    jest.spyOn(global, 'fetch' as any)
      .mockResolvedValueOnce({ ok: true, json: async () => ({ token: 'token_1' }) } as any)
      .mockResolvedValueOnce({ ok: true, json: async () => ({ id: 'paymob_refund_1', amount_cents: 2500 }) } as any);

    await svc.syncRefund('g1', 'refund-paymob-ok');

    expect(db.events).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'REFUND')).toEqual(expect.objectContaining({ status: 'RECONCILED', provider: 'paymob', providerRef: 'paymob_refund_1' }));
    expect(db.refundAudits).toHaveLength(1);
  });

  it('refund request failure degrades to PROVIDER_FAILED without duplicate financial rows', async () => {
    process.env.PAYMOB_API_KEY = 'api_key';
    const db = buildDb({
      sales: [sale('sale-paymob-refund-fail', 'g1', '800002', 25)],
      refunds: [{ id: 'refund-paymob-fail', gymId: 'g1', saleId: 'sale-paymob-refund-fail', amount: 25 }],
    });
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const svc = new BillingService(prismaFor(db), notifications, cronLeadership, encryption);
    jest.spyOn(global, 'fetch' as any)
      .mockResolvedValueOnce({ ok: true, json: async () => ({ token: 'token_1' }) } as any)
      .mockResolvedValueOnce({ ok: false, status: 502, json: async () => ({ error: 'down' }) } as any);

    await svc.syncRefund('g1', 'refund-paymob-fail');

    expect(db.events).toHaveLength(0);
    expect(db.recons).toHaveLength(1);
    expect(db.recons[0]).toEqual(expect.objectContaining({ sourceType: 'REFUND', status: 'PROVIDER_FAILED', provider: 'paymob' }));
    expect(db.recoveryTasks).toHaveLength(1);
  });

  it('missing providerRef is handled safely for non-cash refunds', async () => {
    const db = buildDb({
      sales: [sale('sale-missing-ref', 'g1', null, 10)],
      refunds: [{ id: 'refund-missing-ref', gymId: 'g1', saleId: 'sale-missing-ref', amount: 10 }],
    });
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const svc = new BillingService(prismaFor(db), notifications, cronLeadership, encryption);

    await svc.syncRefund('g1', 'refund-missing-ref');

    expect(db.recons[0]).toEqual(expect.objectContaining({ sourceType: 'REFUND', status: 'MISSING_PROVIDER' }));
    expect(db.refundAudits[0].action).toBe('REFUND_SYNC_MISSING_PROVIDER');
  });
});

describe('External provider validation — webhook stress and financial integrity', () => {
  afterEach(() => delete process.env.STRIPE_WEBHOOK_SECRET);

  it('survives 1000 duplicate Stripe webhooks with one provider event and one financial record set', async () => {
    const db = buildDb({ sales: [sale('sale-stress', 'g1', 'pi_stress', 42)] });
    const { svc } = billingWithStripe(db, () => ({
      id: 'evt_stress_duplicate',
      type: 'payment_intent.succeeded',
      data: { object: { id: 'pi_stress', amount_received: 4200, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
    }));

    for (let i = 0; i < 1000; i += 1) {
      await svc.handleWebhook('sig', Buffer.from('{}'));
    }

    expect(db.events).toHaveLength(1);
    expect(db.invoices).toHaveLength(1);
    expect(db.payments).toHaveLength(1);
    expect(db.receipts).toHaveLength(1);
    expect(db.recons.filter((r) => r.sourceType === 'SALE')).toHaveLength(1);
    expect(db.recons.filter((r) => r.sourceType === 'PAYMENT')).toHaveLength(1);
  });

  it('out-of-order failed then succeeded delivery converges to latest provider success', async () => {
    const db = buildDb({ sales: [sale('sale-ooo', 'g1', 'pi_ooo', 75)] });
    let currentEvent: any = {
      id: 'evt_ooo_failed',
      type: 'payment_intent.payment_failed',
      data: { object: { id: 'pi_ooo', amount: 7500, currency: 'egp', status: 'failed', metadata: { gymId: 'g1' } } },
    };
    const { svc } = billingWithStripe(db, () => currentEvent);

    await svc.handleWebhook('sig', Buffer.from('{}'));
    expect(db.recons.find((r) => r.sourceType === 'SALE')?.status).toBe('PROVIDER_FAILED');

    currentEvent = {
      id: 'evt_ooo_succeeded',
      type: 'payment_intent.succeeded',
      data: { object: { id: 'pi_ooo', amount_received: 7500, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
    };
    await svc.handleWebhook('sig', Buffer.from('{}'));

    expect(db.events).toHaveLength(2);
    expect(db.recons.find((r) => r.sourceType === 'SALE')?.status).toBe('RECONCILED');
    expect(db.recons.find((r) => r.sourceType === 'PAYMENT')?.status).toBe('RECONCILED');
  });

  it('webhook loss leaves missing provider tracked until delayed provider event converges it', async () => {
    const db = buildDb({ sales: [sale('sale-delayed', 'g1', 'pi_delayed', 33)] });
    const prisma = prismaFor(db);
    const notifications: any = { whatsapp: jest.fn() };
    const encryption: any = { decrypt: jest.fn((v) => v), isEncrypted: jest.fn(() => false) };
    const cronLeadership: any = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) };
    const svc = new BillingService(prisma, notifications, cronLeadership, encryption);

    await svc.reconcileSale('g1', 'sale-delayed');
    expect(db.recons.find((r) => r.sourceType === 'SALE')?.status).toBe('MISSING_PROVIDER');

    process.env.STRIPE_WEBHOOK_SECRET = 'whsec_validation';
    (svc as any).stripe = {
      webhooks: { constructEvent: jest.fn(() => ({
        id: 'evt_delayed_success',
        type: 'payment_intent.succeeded',
        data: { object: { id: 'pi_delayed', amount_received: 3300, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
      })) },
    };
    await svc.handleWebhook('sig', Buffer.from('{}'));

    expect(db.events).toHaveLength(1);
    expect(db.recons.find((r) => r.sourceType === 'SALE')?.status).toBe('RECONCILED');
  });

  it('tracks amount mismatches and prevents cross-tenant leakage for shared provider refs', async () => {
    const db = buildDb({ sales: [sale('sale-g1-mismatch', 'g1', 'pi_shared', 100), sale('sale-g2-shared', 'g2', 'pi_shared', 100)] });
    const { svc } = billingWithStripe(db, () => ({
      id: 'evt_shared_mismatch',
      type: 'payment_intent.succeeded',
      data: { object: { id: 'pi_shared', amount_received: 8000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
    }));

    await svc.handleWebhook('sig', Buffer.from('{}'));

    expect(db.recons.find((r) => r.gymId === 'g1' && r.sourceType === 'SALE')?.status).toBe('AMOUNT_MISMATCH');
    expect(db.recons.find((r) => r.gymId === 'g2')).toBeUndefined();
  });

  it('financial integrity invariants hold after simulated sale, payment, refund, and audit flows', async () => {
    const db = buildDb({
      sales: [sale('sale-integrity', 'g1', 'pi_integrity', 60)],
      refunds: [{ id: 'refund-integrity', gymId: 'g1', saleId: 'sale-integrity', amount: 60 }],
    });
    const { svc } = billingWithStripe(db, () => ({
      id: 'evt_integrity_success',
      type: 'payment_intent.succeeded',
      data: { object: { id: 'pi_integrity', amount_received: 6000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } },
    }));

    await svc.handleWebhook('sig', Buffer.from('{}'));
    (svc as any).stripe = null;
    await svc.syncRefund('g1', 'refund-integrity');

    const saleReconKeys = new Set(db.recons.filter((r) => r.sourceType === 'SALE').map((r) => `${r.gymId}:${r.sourceId}`));
    const refundAuditKeys = new Set(db.refundAudits.map((a) => `${a.gymId}:${a.refundId}`));
    const paymentReconKeys = new Set(db.recons.filter((r) => r.sourceType === 'PAYMENT' && r.provider).map((r) => `${r.gymId}:${r.sourceId}`));

    expect(db.sales.every((s) => saleReconKeys.has(`${s.gymId}:${s.id}`))).toBe(true);
    expect(db.refunds.every((r) => refundAuditKeys.has(`${r.gymId}:${r.id}`))).toBe(true);
    expect(db.payments.every((p) => paymentReconKeys.has(`${p.gymId}:${p.id}`))).toBe(true);
    expect(db.recons.some((r) => ['AMOUNT_MISMATCH', 'CURRENCY_MISMATCH'].includes(r.status) && !r.reason)).toBe(false);
  });
});
