/**
 * FLEXORA Gym OS — SaaS Plans + License API (Phase 8)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Headers, Param, Post, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import type { Request } from 'express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Public } from '../../common/decorators/public.decorator';
import { PrismaService } from '../../config/prisma.service';
import { LicenseService } from '../license/license.module';
import { BillingService } from './billing.service';
import { DunningService } from './dunning.service';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { IsIn, IsNumber, IsOptional, IsString, Min } from 'class-validator';


class CancelSubscriptionDto {
  @IsOptional() @IsString() reason?: string;
}

class BillingCheckoutDto {
  @IsOptional() @IsIn(['BASIC', 'PRO', 'ELITE'])
  tier?: 'BASIC' | 'PRO' | 'ELITE';
  @IsOptional() @IsIn(['PRO', 'ELITE'])
  plan?: 'PRO' | 'ELITE';
}

class ManualPaymentDto {
  @IsNumber() @Min(1) amount!: number;
  @IsString() method!: string;
  @IsOptional() @IsString() memberName?: string;
  @IsOptional() @IsString() notes?: string;
  // PHASE I1: the front-desk member this manual payment is recorded for.
  // It is stored on the payment; the payment is a MANUAL_MEMBERSHIP payment
  // usable as membership proof for that member (and, once consumed, bound to
  // it atomically).
  //
  // PHASE J2 — REQUIRED. A manual MEMBERSHIP payment may never be recorded
  // against nobody: an unbound one could be claimed as the proof of payment
  // for whichever member asked first. From this release on, every new
  // MANUAL_MEMBERSHIP row carries the member it was taken for; the legacy
  // "bind a NULL-memberId row to the first member that uses it" path stays
  // ONLY for rows that already existed before the Phase-I migration.
  @IsString() memberId!: string;
}

@ApiTags('license')
@Controller()
export class BillingController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly license: LicenseService,
    private readonly billing: BillingService,
    private readonly dunning: DunningService,
  ) {}

  /** Public catalog (no auth required). */
  @Public()
  @Get('saas-plans')
  async listPlans() {
    return this.prisma.saasPlan.findMany({
      where: { active: true },
      orderBy: { sortOrder: 'asc' },
      take: 50,
    });
  }


  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/status')
  @Permissions('billing.manage')
  billingStatus(@GymId() gymId: string) {
    return this.billing.getSubscription(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/subscription')
  @Permissions('billing.manage')
  subscription(@GymId() gymId: string) {
    return this.billing.getSubscription(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/subscription/cancel')
  @Permissions('billing.manage')
  cancelSubscription(@GymId() gymId: string, @CurrentUser('sub') userId: string, @Body() dto: CancelSubscriptionDto) {
    return this.billing.cancelSubscription(gymId, userId, dto?.reason);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/cancel')
  @Permissions('billing.manage')
  cancelHosted(@GymId() gymId: string) {
    return this.billing.cancelGymSubscription(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/portal')
  @Permissions('billing.manage')
  portal(@GymId() gymId: string) {
    return this.billing.getPortalUrl(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/checkout')
  @Permissions('billing.manage')
  checkout(@GymId() gymId: string, @Body() dto: BillingCheckoutDto) {
    return this.billing.createCheckout(gymId, dto.plan || dto.tier || 'PRO');
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/reconciliation')
  @Permissions('billing.manage')
  reconciliation(@GymId() gymId: string) {
    return this.billing.listReconciliation(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/reconcile')
  @Permissions('billing.manage')
  reconcile(@GymId() gymId: string) {
    return this.billing.reconcileGym(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/dunning/status')
  @Permissions('billing.manage')
  dunningStatus(@GymId() gymId: string) {
    return this.dunning.dunningStatus(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/dunning/:subscriptionId/process')
  @Permissions('billing.manage')
  processDunning(@Param('subscriptionId') subscriptionId: string) {
    return this.dunning.processDunningCycle(subscriptionId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('billing/recovery-tasks')
  @Permissions('billing.manage')
  recoveryTasks(@GymId() gymId: string) {
    return this.billing.listRecoveryTasks(gymId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/recovery-tasks/:id/retry')
  @Permissions('billing.manage')
  retryRecovery(@GymId() gymId: string, @Param('id') id: string) {
    return this.billing.retryRecoveryTask(gymId, id);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('billing/refunds/:id/sync')
  @Permissions('billing.manage')
  syncRefund(@GymId() gymId: string, @Param('id') id: string) {
    return this.billing.syncRefund(gymId, id);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('license/status')
  @Permissions('billing.manage')
  async status(@GymId() gymId: string) {
    return this.license.getStatus(gymId);
  }

  /**
   * @deprecated F-007 — Direct license renewal via API was a security hole
   * that granted a free 365-day license to any authenticated staff role.
   * License renewal must go through the paid subscription flow (Stripe/Paymob)
   * which reconciles payment before granting a term extension.
   * This endpoint is intentionally removed. Callers receive 404.
   */

  /**
   * Stripe webhook — SECURITY FIX.
   *
   * Previously the BillingService.handleWebhook existed but was never wired to
   * any route, so `checkout.session.completed` (which activates the
   * subscription after payment) could never fire. Customers could pay via
   * Stripe Checkout but the tier was never updated.
   *
   * Now: @Public (Stripe authenticates via HMAC signature over the raw body),
   * reads the exact raw bytes (rawBody enabled in main.ts), and forwards to
   * the existing verified handler.
   */
  @Public()
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @Post('billing/webhook')
  billingWebhook(@Req() req: Request & { rawBody?: Buffer }, @Headers('stripe-signature') signature: string) {
    const raw = req.rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}));
    return this.billing.handleWebhook(signature, raw);
  }

  @Public()
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @Post('stripe/webhook')
  stripeWebhook(
    @Req() req: Request & { rawBody?: Buffer },
    @Headers('stripe-signature') signature: string,
  ) {
    const raw = req.rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}));
    return this.billing.handleWebhook(signature, raw);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('payments/manual')
  @Permissions('pos.sell')
  createManualPayment(
    @GymId() gymId: string,
    @CurrentUser('sub') userId: string,
    @Body() dto: ManualPaymentDto,
  ) {
    return this.billing.createManualPayment(gymId, userId, dto);
  }
}
