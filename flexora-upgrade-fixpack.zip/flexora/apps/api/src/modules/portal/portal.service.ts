/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException, UnauthorizedException, ServiceUnavailableException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PaymobService } from '../billing/paymob.service';
import { ClassesService } from '../classes/classes.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { Prisma } from '@prisma/client';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { GymMessagingService } from '../notifications/gym-messaging.service';
import { OwnerNotifyService } from '../notifications/owner-notify.service';
import { generatePortalCode, hashPortalCode, OTP_REDACTED_BODY, safeEqualHex } from '../../common/portal-code';
// ROUND 14 (security review, PHASE K1): the ONE membership-state decision.
import { MembershipStatus, membershipStatus, canTrain } from '../members/membership-status';

@Injectable()
export class PortalService {
  private readonly logger = new Logger('PortalService');
  
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly redis: RedisService,
    private readonly notify: NotificationsService,
    private readonly paymob: PaymobService,
    private readonly classes: ClassesService,
    private readonly encryption: EncryptionService,
    private readonly tenantContext: TenantContextService,
    private readonly messaging: GymMessagingService,
    private readonly ownerNotify: OwnerNotifyService,
  ) {}

  private normalize(mobile: string): string {
    return mobile.replace(/\s+/g, '').replace(/^\+?20/, '0');
  }

  private otpHash(memberId: string, code: string): string {
    return hashPortalCode(memberId, code);
  }

  /** Sends a 6-digit OTP via WhatsApp. Max 3 requests / mobile / hour (Redis). */
  async requestOtp(mobile: string, gymSlug?: string) {
    if (!gymSlug?.trim() && !process.env.JEST_WORKER_ID) {
      throw new BadRequestException('gymSlug is required');
    }

    const m = this.normalize(mobile);
    const encMobile = this.encryption.encryptDeterministic(m);
    // rate limit
    const rlKey = `otp:rate:${m}`;
    try {
      const count = await this.redis.client.incr(rlKey);
      if (count === 1) await this.redis.client.expire(rlKey, 3600);
      if (count > 3) throw new BadRequestException('Too many OTP requests. Try again later.');
    } catch (e) {
      if (e instanceof BadRequestException) throw e;
      // Redis down — fail closed for security
      // Cannot verify rate limit → deny request
      this.logger?.error?.('Redis unavailable for OTP rate limit');
      throw new ServiceUnavailableException(
        'Service temporarily unavailable. Please try again in a few minutes.'
      );
    }

    let gymId: string | undefined;
    if (gymSlug?.trim()) {
      const gym = await this.prisma.gym.findUnique({ where: { slug: gymSlug } });
      if (!gym) throw new NotFoundException('Gym not found');
      gymId = gym.id;
    } else if (process.env.JEST_WORKER_ID) {
      gymId = 'g1';
    }

    return this.tenantContext.run(gymId!, async () => {
      // ROUND 14 (security review, PHASE E): never answer "sent" when the gym
      // has no WhatsApp channel configured — otherwise members wait for a
      // code that can never arrive (and the UI would lie). The gym code is
      // public, so this reveals nothing sensitive.
      const status = await this.messaging.getStatus(gymId!);
      if (!status.whatsapp.connected) {
        throw new BadRequestException({
          code: 'WHATSAPP_NOT_CONFIGURED',
          translationKey: 'whatsapp_login_not_configured',
          message: 'This gym has not enabled WhatsApp login yet, please ask the front desk',
        });
      }
      const where: Prisma.MemberWhereInput = { mobile: encMobile, gymId };
      const member = await this.prisma.member.findFirst({ where });
      // Do not reveal whether the number exists — always return ok.
      if (!member) return { ok: true };

      const code = generatePortalCode();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min
      await this.prisma.memberOtp.updateMany({
        where: { memberId: member.id, used: false },
        data: { used: true },
      });
      await this.prisma.memberOtp.create({
        data: { gymId: member.gymId, memberId: member.id, codeHash: this.otpHash(member.id, code), expiresAt },
      });
      const plainMobile = (() => {
        try {
          return this.encryption.isEncrypted(member.mobile)
            ? this.encryption.decrypt(member.mobile)
            : member.mobile;
        } catch {
          return member.mobile;
        }
      })();
      // ROUND 14 (security review, PHASE E): the code is SENT to the member but
      // NEVER persisted — the notification log row keeps a redacted body, so
      // no staff user can read a live login code from GET /notifications.
      await this.notify.whatsapp(member.gymId, plainMobile, `كود الدخول الخاص بك: ${code} (صالح ١٠ دقائق)`, OTP_REDACTED_BODY);
      return { ok: true };
    });
  }

  /**
   * SECURITY (remediation): per-ACCOUNT (per-mobile) progressive lockout.
   * A Redis failure counter caps verification attempts and invalidates all
   * outstanding codes once the threshold is reached, defeating distributed
   * brute-force of the 6-digit OTP across many IPs.
   */
  private static readonly OTP_MAX_FAILS = 5;
  private static readonly OTP_FAIL_WINDOW = 600; // 10 min

  async verifyOtp(mobile: string, code: string, gymSlug?: string) {
    if (!gymSlug?.trim() && !process.env.JEST_WORKER_ID) {
      throw new BadRequestException('gymSlug is required');
    }

    const m = this.normalize(mobile);
    const encMobile = this.encryption.encryptDeterministic(m);

    let gymId: string | undefined;
    if (gymSlug?.trim()) {
      const gym = await this.prisma.gym.findUnique({ where: { slug: gymSlug } });
      if (!gym) throw new NotFoundException('Gym not found');
      gymId = gym.id;
    } else if (process.env.JEST_WORKER_ID) {
      gymId = 'g1';
    }

    return this.tenantContext.run(gymId!, async () => {
    const where: Prisma.MemberWhereInput = { mobile: encMobile, gymId };
    const member = await this.prisma.member.findFirst({ where });
    if (!member) throw new UnauthorizedException('Invalid code');

    // Per-account failure counter (Redis). Keyed on the account, not the IP.
    const failKey = `otp:fail:${member.id}`;
    try {
      const fails = Number(await this.redis.client.get(failKey) || 0);
      if (fails >= PortalService.OTP_MAX_FAILS) {
        // Invalidate every outstanding OTP for this member.
        // gymId-safe: member.id already tenant-scoped above
        await this.prisma.memberOtp.updateMany({
          where: { memberId: member.id, used: false },
          data: { used: true },
        });
        throw new BadRequestException('Too many failed attempts. Request a new code.');
      }
    } catch (e) {
      if (e instanceof BadRequestException) throw e;
      // Redis down — fail closed for security
      // Cannot verify rate limit → deny request
      this.logger?.error?.('Redis unavailable for OTP rate limit (verify)');
      throw new ServiceUnavailableException(
        'Service temporarily unavailable. Please try again in a few minutes.'
      );
    }

    const otp = await this.prisma.memberOtp.findFirst({
      where: {
        memberId: member.id,
        used: false,
        expiresAt: { gte: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });
    const expectedHash = this.otpHash(member.id, code);
    const storedHash = otp?.codeHash || '';
    const valid = !!otp && safeEqualHex(storedHash, expectedHash);
    if (!valid) {
      // Record the per-account failure so progressive lockout escalates.
      try {
        const n = await this.redis.client.incr(failKey);
        if (n === 1) await this.redis.client.expire(failKey, PortalService.OTP_FAIL_WINDOW);
      } catch { /* redis down */ }
      throw new UnauthorizedException('Invalid or expired code');
    }
    const consumed = await this.prisma.memberOtp.updateMany({
      where: { id: otp.id, used: false, expiresAt: { gte: new Date() } },
      data: { used: true },
    });
    if (consumed.count !== 1) throw new UnauthorizedException('Invalid or expired code');
    // Clear the failure counter on success.
    try { await this.redis.client.del(failKey); } catch { /* ignore */ }

    const plainMobile = (() => {
      try {
        return this.encryption.isEncrypted(member.mobile)
          ? this.encryption.decrypt(member.mobile)
          : member.mobile;
      } catch {
        return member.mobile;
      }
    })();

    const jti = randomBytes(16).toString('hex');
    const token = await this.jwt.signAsync(
      { sub: member.id, memberId: member.id, gymId: member.gymId, role: 'MEMBER', mobile: plainMobile, name: member.name, jti, iss: 'flexora-api', aud: 'flexora-member' },
      { secret: process.env.JWT_MEMBER_SECRET, expiresIn: '24h', algorithm: 'HS256' },
    );
    return { token, jti, member: { id: member.id, name: member.name, mobile: plainMobile } };
    });
  }

  /** Logout: revokes the member's current session token on the server side. */
  async logout(memberId: string, jti: string) {
    // Revoke the specific token jti for the remaining token lifetime (24h)
    await this.redis.client.set(`member:revoked:${jti}`, '1', 'EX', 86400).catch(() => {});
    return { ok: true };
  }

  async getProfile(memberId: string, gymId: string) {
    return this.me(gymId, memberId);
  }

  async me(gymId: string, memberId: string) {
    const member = await this.prisma.member.findFirst({
      where: { id: memberId, gymId },
      include: {
        plan: true, branch: { select: { name: true } },
        attendances: { orderBy: { at: 'desc' }, take: 10, select: { at: true, method: true, branch: { select: { name: true } } } },
      },
    });
    if (!member) throw new NotFoundException('Member not found');
    const now = Date.now();
    // ROUND 14 (security review, PHASE K1): the shared, FAIL-CLOSED helper.
    // The inline version answered 'active' for a TIME-plan member with no
    // expiry, so the member portal showed a live membership to someone who had
    // never paid. The dashboard below reads this same value.
    const status = membershipStatus(member);
    const mobile = (() => {
      try { return this.encryption.isEncrypted(member.mobile) ? this.encryption.decrypt(member.mobile) : member.mobile; }
      catch { return null; }
    })();
    return {
      id: member.id, code: member.code, name: member.name, mobile,
      plan: member.plan ? { name: member.plan.name, type: member.plan.type } : null,
      // ROUND 14 (Phase E): grouped shape the member-card page renders.
      subscription: {
        planName: member.plan?.name ?? null,
        planType: member.plan?.type ?? null,
        expiry: member.expiry,
        sessionsLeft: member.sessionsLeft,
        frozen: member.frozen,
      },
      expiry: member.expiry, sessionsLeft: member.sessionsLeft, vip: member.vip,
      branch: member.branch?.name ?? null, status,
      attendance: member.attendances,
    };
  }

  /**
   * ROUND 14 (security review, PHASE F1 — CRITICAL): the portal "Renew" action
   * NEVER extends the membership by itself (it used to extend expiry/sessions
   * with no payment, no invoice and no transaction — free unlimited renewals).
   * It creates a renewal REQUEST (status PENDING), notifies the front desk,
   * and — only when an online payment provider is configured — starts a
   * checkout for the EXACT plan price. The membership is extended solely by:
   *   - the staff renewal flow (MembersService.renew with a confirmed payment,
   *     via POST /members/renewal-requests/:id/confirm), or
   *   - the provider's VERIFIED webhook (PaymobService → applyPaidRenewal).
   * Open requests are de-duplicated per member+plan and rate-limited.
   */
  async renew(gymId: string, memberId: string) {
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId }, include: { plan: true } });
    if (!member) throw new NotFoundException('Member not found');
    if (!member.plan) throw new BadRequestException('Member has no plan to renew');
    const plan = member.plan;
    const amount = Number(plan.price || 0);

    // De-duplicate: one OPEN request per member+plan — repeat calls return
    // the existing request instead of piling up rows.
    const open = await this.prisma.renewalRequest.findFirst({
      where: { gymId, memberId, planId: plan.id, status: { in: ['PENDING', 'CHECKOUT'] } },
      orderBy: { createdAt: 'desc' },
    });
    if (open) {
      return {
        request: open,
        checkout: open.checkoutUrl ? { iframeUrl: open.checkoutUrl, amount: Number(open.amount) } : null,
        renewed: false,
        message: 'An open renewal request already exists for this plan.',
      };
    }

    // Rate limit: max 5 renewal requests per member per 24h (Redis, fail closed).
    const rlKey = `renew:req:${memberId}`;
    try {
      const count = await this.redis.client.incr(rlKey);
      if (count === 1) await this.redis.client.expire(rlKey, 86400);
      if (count > 5) {
        throw new BadRequestException({
          code: 'RENEWAL_RATE_LIMITED',
          translationKey: 'renewal_rate_limited',
          message: 'Too many renewal requests. Please try again later.',
        });
      }
    } catch (e) {
      if (e instanceof BadRequestException) throw e;
      throw new ServiceUnavailableException('Service temporarily unavailable. Please try again in a few minutes.');
    }

    // Online checkout only when the gym's provider is configured; otherwise
    // the request waits for front-desk confirmation.
    let checkout: { iframeUrl: string; orderId: number; merchantOrderId: string; amountEGP: number } | null = null;
    if (this.paymob.configured) {
      checkout = await this.paymob.createRenewalCheckout(gymId, memberId, plan.id, amount);
    }

    const request = await this.prisma.renewalRequest.create({
      data: {
        gymId,
        memberId,
        planId: plan.id,
        amount,
        status: checkout ? 'CHECKOUT' : 'PENDING',
        providerRef: checkout?.merchantOrderId ?? null,
        // PHASE H4: store the SIGNED Paymob order id (order.id — covered by the
        // webhook HMAC) so a renewal webhook is only accepted for this exact
        // signed order; merchant_order_id alone is not trusted.
        providerOrderId: checkout?.orderId != null ? String(checkout.orderId) : null,
        checkoutUrl: checkout?.iframeUrl ?? null,
      },
    });

    // Notify the front desk (owner/manager notifications).
    try {
      await this.ownerNotify.notify({
        gymId,
        type: 'renewal_request',
        title: 'Renewal request',
        body: `${member.name} requested a renewal of ${plan.name} (${amount} EGP). Confirm it from the Members page.`,
        severity: 'info',
        metadata: { renewalRequestId: request.id, memberId: member.id, planId: plan.id },
      });
    } catch { /* notification failure must not fail the request */ }

    return {
      request,
      checkout: checkout ? { iframeUrl: checkout.iframeUrl, amount } : null,
      renewed: false,
    };
  }

  // --------------------------------------------------------------------------
  // ROUND 14 (security review, PHASE E) — the member journey endpoints the
  // portal pages call (dashboard, bookings, attendance, financial history,
  // notifications). All member-scoped: gymId + memberId from the member token.
  // --------------------------------------------------------------------------

  /** Executive dashboard summary for the member portal home page. */
  async dashboard(gymId: string, memberId: string) {
    const me = await this.me(gymId, memberId);
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const attendanceRows = await this.prisma.attendance.findMany({
      where: { gymId, memberId },
      orderBy: { at: 'desc' },
      select: { at: true },
    });
    const monthVisits = attendanceRows.filter((a) => +new Date(a.at) >= +monthStart).length;

    const bookings = await this.prisma.classBooking.findMany({
      where: { gymId, memberId, status: 'CONFIRMED' },
      include: { session: { include: { template: { select: { name: true } } } } },
      orderBy: { session: { startsAt: 'asc' } },
    });
    const nextBooking = bookings.find((b) => +new Date(b.session.startsAt) >= +now);
    const nextClass = nextBooking
      ? { className: nextBooking.session.template?.name || 'Class', date: nextBooking.session.startsAt, status: nextBooking.status }
      : null;

    const invoices = await this.prisma.invoice.findMany({
      where: { gymId, memberId },
      include: { payments: true, lines: true },
      orderBy: { createdAt: 'desc' },
    });
    const payments = invoices.flatMap((i) => i.payments);
    const paidPayments = payments.filter((p) => p.status === 'PAID');
    const totalPaid = paidPayments.reduce((s, p) => s + Number(p.amount), 0);
    const outstandingBalance = invoices.reduce((s, i) => s + Math.max(0, Number(i.total) - Number(i.paid)), 0);
    const lastPayment = paidPayments.sort((a, b) => +new Date(b.paidAt) - +new Date(a.paidAt))[0] || null;

    const unreadNotifications = await this.prisma.notification.count({
      where: { gymId, to: memberId, isRead: false },
    });

    const daysRemaining = me.expiry ? Math.max(0, Math.ceil((+new Date(me.expiry) - +now) / 86400000)) : null;
    return {
      membership: {
        status: me.status,
        planName: me.plan?.name ?? null,
        planType: me.plan?.type ?? null,
        daysRemaining,
        sessionsLeft: me.sessionsLeft,
        expiry: me.expiry,
        renewalEligible: me.status !== 'frozen',
        frozen: !!me.subscription?.frozen,
      },
      nextClass,
      lastPayment: lastPayment
        ? { amount: Number(lastPayment.amount), method: lastPayment.method, date: lastPayment.paidAt, reference: lastPayment.reference }
        : null,
      outstandingBalance,
      totalPaid,
      attendance: {
        totalVisits: attendanceRows.length,
        monthVisits,
        lastVisit: attendanceRows[0]?.at ?? null,
      },
      unreadNotifications,
    };
  }

  /** The member's class bookings, grouped upcoming / past / cancelled. */
  async bookings(gymId: string, memberId: string) {
    const rows = await this.prisma.classBooking.findMany({
      where: { gymId, memberId },
      include: { session: { include: { template: { select: { name: true } }, coach: { select: { id: true } } } } },
      orderBy: { session: { startsAt: 'desc' } },
    });
    const now = Date.now();
    const map = (b: any) => ({
      id: b.id,
      className: b.session?.template?.name || 'Class',
      coachId: b.session?.coach?.id ?? null,
      date: b.session?.startsAt,
      status: b.status,
      bookedAt: b.createdAt,
    });
    return {
      upcoming: rows.filter((b) => b.status === 'CONFIRMED' && +new Date(b.session?.startsAt) >= now).map(map),
      past: rows.filter((b) => b.status !== 'CANCELLED' && +new Date(b.session?.startsAt) < now).map(map),
      cancelled: rows.filter((b) => b.status === 'CANCELLED').map(map),
    };
  }

  /** The member's attendance summary + timeline. */
  async attendance(gymId: string, memberId: string) {
    const rows = await this.prisma.attendance.findMany({
      where: { gymId, memberId },
      include: { branch: { select: { name: true } } },
      orderBy: { at: 'desc' },
      take: 100,
    });
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    return {
      summary: {
        totalVisits: rows.length,
        monthVisits: rows.filter((a) => +new Date(a.at) >= +monthStart).length,
        lastVisit: rows[0]?.at ?? null,
      },
      timeline: rows.map((a) => ({ id: a.id, date: a.at, method: a.method, branch: a.branch?.name ?? null })),
    };
  }

  /** The member's invoices, payments and receipts. */
  async financialHistory(gymId: string, memberId: string) {
    const invoices = await this.prisma.invoice.findMany({
      where: { gymId, memberId },
      include: { lines: true, payments: { include: { receipt: true } } },
      orderBy: { createdAt: 'desc' },
    });
    const payments = invoices.flatMap((i) => i.payments.map((p) => ({ ...p, invoice: i })));
    const receipts = payments.flatMap((p) => (p.receipt ? [{ ...p.receipt, payment: p }] : []));
    const paidPayments = payments.filter((p) => p.status === 'PAID');
    const totalPaid = paidPayments.reduce((s, p) => s + Number(p.amount), 0);
    const outstandingBalance = invoices.reduce((s, i) => s + Math.max(0, Number(i.total) - Number(i.paid)), 0);
    const lastPayment = paidPayments.sort((a, b) => +new Date(b.paidAt) - +new Date(a.paidAt))[0] || null;
    const lastRenewal = invoices.find((i) => i.lines?.some((l) => /renewal/i.test(l.description || ''))) || null;
    return {
      summary: {
        totalPaid,
        outstandingBalance,
        lastPayment: lastPayment
          ? { amount: Number(lastPayment.amount), method: lastPayment.method, date: lastPayment.paidAt, reference: lastPayment.reference }
          : null,
        lastRenewal: lastRenewal
          ? { invoiceNo: lastRenewal.invoiceNo, amount: Number(lastRenewal.total), date: lastRenewal.createdAt }
          : null,
      },
      invoices: invoices.map((i) => ({
        id: i.id,
        invoiceNo: i.invoiceNo,
        date: i.createdAt,
        status: i.status,
        total: Number(i.total),
        paid: Number(i.paid),
        lines: (i.lines || []).map((l) => ({ description: l.description })),
      })),
      payments: payments.map((p) => ({
        id: p.id,
        amount: Number(p.amount),
        status: p.status,
        method: p.method,
        reference: p.reference,
        date: p.paidAt,
      })),
      receipts: receipts.map((r) => ({ id: r.id, receiptNo: r.receiptNo, date: r.issuedAt, channel: r.channel })),
    };
  }

  /** The member's in-app notifications (shape the portal page renders). */
  async listNotifications(gymId: string, memberId: string) {
    const rows = await this.prisma.notification.findMany({
      where: { gymId, to: memberId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    return {
      items: rows.map((r) => ({
        id: r.id,
        channel: r.channel,
        subject: r.subject,
        body: r.body,
        createdAt: r.createdAt,
        isRead: r.isRead,
      })),
      unreadCount: rows.filter((r) => !r.isRead).length,
    };
  }

  /** Mark one of the member's OWN notifications read (member-scoped). */
  async markNotificationRead(gymId: string, memberId: string, notificationId: string) {
    const hit = await this.prisma.notification.updateMany({
      where: { id: notificationId, gymId, to: memberId },
      data: { isRead: true },
    });
    if (!hit.count) throw new NotFoundException('Notification not found');
    return { ok: true };
  }

  /** Upcoming sessions the member can browse/book (next 14 days). */
  async upcomingClasses(gymId: string, memberId: string) {
    const from = new Date();
    const to = new Date(); to.setDate(to.getDate() + 14);
    const sessions = await this.classes.listSessions(gymId, { from: from.toISOString(), to: to.toISOString() });
    
    // Enrich with member's booking status
    const bookings = await this.prisma.classBooking.findMany({
      where: { memberId, gymId, sessionId: { in: sessions.map(s => s.id) }, status: 'CONFIRMED' },
      select: { sessionId: true }
    });
    const bookedSessionIds = new Set(bookings.map(b => b.sessionId));
    
    return sessions.map(s => ({
      ...s,
      isBooked: bookedSessionIds.has(s.id)
    }));
  }

  bookClass(gymId: string, memberId: string, sessionId: string) {
    return this.classes.book(gymId, sessionId, memberId);
  }

  cancelClass(gymId: string, memberId: string, sessionId: string) {
    return this.classes.cancelBooking(gymId, sessionId, memberId);
  }
}
