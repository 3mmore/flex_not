/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PortalService } from './portal.service';
import { PushService } from './push.service';
import { PortalController } from './portal.controller';
import { NotificationsModule } from '../notifications/notifications.module';
import { BillingModule } from '../billing/billing.module';
import { ClassesModule } from '../classes/classes.module';
import { SecurityModule } from '../../common/security/security.module';

@Module({
  imports: [JwtModule.register({}), NotificationsModule, BillingModule, ClassesModule, SecurityModule],
  controllers: [PortalController],
  providers: [PortalService, PushService],
})
export class PortalModule {}
