/**
 * ROUND 14 (security review, PHASE E) — regression spec: member-portal login
 * codes must never be persisted in Notification.body, and the staff
 * notification log must be readable only by OWNER+MANAGER (reports.view).
 *
 * The bug this guards: PortalService.requestOtp sent the OTP through
 * NotificationsService.whatsapp, which created a Notification row containing
 * the PLAINTEXT code — and GET /notifications returned full rows to any staff
 * role holding members.view. Any staff member could read a member's live OTP
 * and take over that member's portal session.
 */
import { readFileSync } from 'fs';
import { join } from 'path';
import { NotificationsService } from '../notifications/notifications.service';

const SRC = join(__dirname, '..');

function makeService() {
  const created: any[] = [];
  const prisma: any = {
    notification: {
      create: jest.fn(async ({ data }: any) => { const row = { id: 'n' + created.length, ...data }; created.push(row); return row; }),
      update: jest.fn(async ({ where, data }: any) => ({ id: where.id, ...data })),
    },
  };
  const gymMessaging: any = {
    sendWhatsAppText: jest.fn(async () => ({ success: true, provider: 'mock' })),
  };
  const svc = new NotificationsService(prisma, gymMessaging);
  return { svc, prisma, gymMessaging, created };
}

describe('OTP codes are never persisted in Notification.body', () => {
  it('whatsapp() with a persistBody stores the redacted body but sends the real one', async () => {
    const { svc, prisma, gymMessaging, created } = makeService();
    const realBody = 'كود الدخول الخاص بك: 482913 (صالح ١٠ دقائق)';

    await svc.whatsapp('g1', '01000000001', realBody, 'Login code sent');

    // the notification log row keeps ONLY the redacted placeholder
    expect(created).toHaveLength(1);
    expect(created[0].body).toBe('Login code sent');
    expect(created[0].body).not.toContain('482913');
    expect(created[0].body).not.toMatch(/\d{6}/);
    // the message that is actually SENT carries the real code
    expect(gymMessaging.sendWhatsAppText).toHaveBeenCalledWith('g1', '01000000001', realBody);
    expect(prisma.notification.create).toHaveBeenCalledWith({
      data: { gymId: 'g1', channel: 'WHATSAPP', to: '01000000001', body: 'Login code sent' },
    });
  });

  it('whatsapp() without persistBody keeps the legacy behavior (non-secret messages)', async () => {
    const { svc, created } = makeService();
    await svc.whatsapp('g1', '01000000001', 'Welcome to the gym!');
    expect(created[0].body).toBe('Welcome to the gym!');
  });

  it('a bare 6-digit code body would be redacted by the migration', () => {
    // the migration redacts: bodies that are exactly 6 digits, the Arabic OTP
    // template, and any OTP/access-code-shaped WHATSAPP body
    const migration = readFileSync(
      join(__dirname, '../../../prisma/migrations/20261012100000_round14_portal_security/migration.sql'),
      'utf8',
    );
    expect(migration).toContain("SET \"body\" = 'Login code sent'");
    expect(migration).toContain("'^[0-9]{6}$'");
    expect(migration).toContain('%كود الدخول%');
  });
});

describe('GET /notifications is restricted to OWNER+MANAGER (reports.view)', () => {
  it('the endpoint requires reports.view (default: OWNER + MANAGER only)', () => {
    const src = readFileSync(join(SRC, 'notifications/notifications.controller.ts'), 'utf8');
    expect(src).toContain("@Get() @Permissions('reports.view') list(");
    // and reports.view is not a RECEPTION/COACH/ACCOUNTANT default
    const catalog = readFileSync(join(SRC, 'permissions/permissions.catalog.ts'), 'utf8');
    for (const role of ['RECEPTION: [', 'COACH: [', 'ACCOUNTANT: [']) {
      const start = catalog.indexOf(role);
      const end = catalog.indexOf('],', start);
      expect(catalog.slice(start, end)).not.toContain('reports.view');
    }
  });
});

describe('the member portal exposes the fallback + journey endpoints', () => {
  it('the portal controller wires dashboard/bookings/attendance/financial-history/notifications-read', () => {
    const src = readFileSync(join(SRC, 'portal/portal.controller.ts'), 'utf8');
    for (const route of ["@Get('dashboard')", "@Get('bookings')", "@Get('attendance')", "@Get('financial-history')", "@Post('notifications/:id/read')"]) {
      expect(src).toContain(route);
    }
  });

  it('the staff access-code endpoint exists and is members.edit-gated', () => {
    const src = readFileSync(join(SRC, 'members/members.controller.ts'), 'utf8');
    expect(src).toContain("@Post(':id/access-code')");
    expect(src).toContain("@Permissions('members.edit')");
  });
});
