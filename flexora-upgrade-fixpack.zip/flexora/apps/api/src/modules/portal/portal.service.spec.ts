/**
 * FLEXORA Gym OS — Regression tests for security remediation
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Covers:
 *  - PortalService.verifyOtp per-account progressive lockout (OTP brute-force fix)
 *  - PortalService.verifyOtp clears the counter on success
 */
import { createHmac } from 'crypto';
import { PortalService } from './portal.service';

function makeRedis() {
  const store: Record<string, string> = {};
  return {
    client: {
      get: jest.fn(async (k: string) => (k in store ? store[k] : null)),
      incr: jest.fn(async (k: string) => { store[k] = String((Number(store[k] || 0)) + 1); return Number(store[k]); }),
      expire: jest.fn(async () => 1),
      del: jest.fn(async (k: string) => { delete store[k]; return 1; }),
    },
    get: jest.fn(async (k: string) => (k in store ? store[k] : null)),
    set: jest.fn(async (k: string, v: string) => { store[k] = v; return 'OK'; }),
    del: jest.fn(async (k: string) => { delete store[k]; }),
  } as any;
}

function makeService(redis: any) {
  const memberOtp: any = {
    create: jest.fn(),
    findFirst: jest.fn(),
    update: jest.fn(),
    updateMany: jest.fn(),
  };
  const prisma: any = {
    member: { findFirst: jest.fn() },
    gym: { findUnique: jest.fn() },
    memberOtp,
  };
  const jwt: any = { signAsync: jest.fn().mockResolvedValue('tok') };
  const notify: any = { whatsapp: jest.fn(async () => ({ ok: true })) };
  const paymob: any = {};
  const classes: any = {};
  const encryption: any = {
    encryptDeterministic: jest.fn((m) => `enc_${m}`),
    decrypt: jest.fn((m) => m.replace('enc_', '')),
    isEncrypted: jest.fn((m) => m?.startsWith('enc_')),
  };
  memberOtp.updateMany.mockResolvedValue({ count: 1 });
  const tenantContext: any = { run: (_gymId: string, fn: () => unknown) => fn() };
  // ROUND 14 (Phase E): the 9th dependency is GymMessagingService — requestOtp
  // now refuses to "send" when the gym has no WhatsApp channel configured.
  const messaging: any = {
    getStatus: jest.fn(async () => ({ whatsapp: { enabled: true, connected: true, phoneId: 'p' }, sms: { enabled: false, connected: false }, email: { enabled: false, connected: false } })),
  };
  // ROUND 14 (Phase F1): the 10th dependency is OwnerNotifyService (renewal
  // requests notify the front desk).
  const ownerNotify: any = { notify: jest.fn(async () => undefined) };
  const svc = new PortalService(prisma, jwt, redis, notify, paymob, classes, encryption, tenantContext, messaging, ownerNotify);
  return { svc, prisma, memberOtp, encryption, notify, messaging, ownerNotify };
}

describe('PortalService OTP security', () => {
  beforeEach(() => {
    delete process.env.NODE_ENV;
    process.env.JWT_MEMBER_SECRET = 'test-member-secret-000000000000000000000000';
  });

  it('stores only an OTP hash and invalidates previous active OTPs', async () => {
    const redis = makeRedis();
    const { svc, prisma, memberOtp } = makeService(redis);
    prisma.member.findFirst.mockResolvedValue({ id: 'm0', gymId: 'g1', mobile: '01000000009' });

    await svc.requestOtp('01000000009');

    expect(memberOtp.updateMany).toHaveBeenCalledWith({
      where: { memberId: 'm0', used: false },
      data: { used: true },
    });
    const data = memberOtp.create.mock.calls[0][0].data;
    expect(data.code).toBeUndefined();
    expect(data.codeHash).toMatch(/^[a-f0-9]{64}$/);
  });

  it('ROUND 14 (Phase E): the OTP is sent with a REDACTED persist body — the code never reaches the notification log', async () => {
    const redis = makeRedis();
    const { svc, prisma, notify } = makeService(redis);
    prisma.member.findFirst.mockResolvedValue({ id: 'm0', gymId: 'g1', mobile: '01000000009' });

    await svc.requestOtp('01000000009');

    expect(notify.whatsapp).toHaveBeenCalledTimes(1);
    const [gymId, to, realBody, persistBody] = notify.whatsapp.mock.calls[0];
    expect(gymId).toBe('g1');
    expect(to).toBe('01000000009');
    // the message that is SENT carries the real code …
    expect(realBody).toMatch(/\d{6}/);
    // … but the notification LOG row stores only the redacted placeholder
    expect(persistBody).toBe('Login code sent');
    expect(persistBody).not.toMatch(/\d{6}/);
  });

  it('ROUND 14 (Phase E): requestOtp refuses to answer "sent" when WhatsApp is not configured', async () => {
    const redis = makeRedis();
    const { svc, prisma, messaging, memberOtp } = makeService(redis);
    messaging.getStatus.mockResolvedValue({ whatsapp: { enabled: false, connected: false }, sms: { enabled: false, connected: false }, email: { enabled: false, connected: false } });
    prisma.member.findFirst.mockResolvedValue({ id: 'm0', gymId: 'g1', mobile: '01000000009' });

    await expect(svc.requestOtp('01000000009')).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'WHATSAPP_NOT_CONFIGURED' }),
    });
    expect(memberOtp.create).not.toHaveBeenCalled();
  });
});

describe('PortalService.verifyOtp — per-account lockout (remediation)', () => {
  beforeEach(() => {
    // avoid any env leaking
    delete process.env.NODE_ENV;
    process.env.JWT_MEMBER_SECRET = 'test-member-secret-000000000000000000000000';
  });

  it('records failures and locks the account after the threshold', async () => {
    const redis = makeRedis();
    const { svc, prisma, memberOtp } = makeService(redis);
    prisma.member.findFirst.mockResolvedValue({ id: 'm1', gymId: 'g1', mobile: '01000000000' });
    // No matching OTP → always a failure
    memberOtp.findFirst.mockResolvedValue(null);

    // First 5 failures: should throw Unauthorized, counter increments to 5
    for (let i = 0; i < 5; i++) {
      await expect(svc.verifyOtp('01000000000', '000000')).rejects.toThrow(/Invalid or expired/);
    }
    expect(redis.client.incr).toHaveBeenCalledWith('otp:fail:m1');

    // 6th attempt: counter at threshold → BadRequest + codes invalidated
    await expect(svc.verifyOtp('01000000000', '000000')).rejects.toThrow(/Too many failed/);
    expect(memberOtp.updateMany).toHaveBeenCalledWith({
      where: { memberId: 'm1', used: false },
      data: { used: true },
    });
  });

  it('clears the failure counter on a successful verification', async () => {
    const redis = makeRedis();
    const { svc, prisma, memberOtp } = makeService(redis);
    const memberId = 'm2';
    const code = '123456';
    const secret = process.env.OTP_HMAC_SECRET || process.env.JWT_MEMBER_SECRET || process.env.ENCRYPTION_KEY || '';
    const codeHash = createHmac('sha256', secret).update(`${memberId}:${code}`).digest('hex');

    prisma.member.findFirst.mockResolvedValue({ id: memberId, gymId: 'g1', mobile: '01000000001' });
    memberOtp.findFirst.mockResolvedValue({ id: 'otp1', codeHash, used: false, expiresAt: new Date(Date.now() + 60000) });

    const res = await svc.verifyOtp('01000000001', code);
    expect(res.token).toBe('tok');
    // counter cleared
    expect(redis.client.del).toHaveBeenCalledWith(`otp:fail:${memberId}`);
    expect(memberOtp.updateMany).toHaveBeenCalledWith({
      where: { id: 'otp1', used: false, expiresAt: { gte: expect.any(Date) } },
      data: { used: true },
    });
  });
});
