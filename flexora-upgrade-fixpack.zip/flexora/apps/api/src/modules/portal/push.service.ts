/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';

export interface PushKeys {
  p256dh: string;
  auth: string;
}

@Injectable()
export class PushService {
  private readonly logger = new Logger('PushService');
  constructor(private readonly prisma: PrismaService) {}

  private assertValid(endpoint?: string, keys?: PushKeys): { endpoint: string; p256dh: string; auth: string } {
    if (!endpoint || !endpoint.startsWith('https://')) throw new BadRequestException('Invalid Push endpoint');
    const p256dh = typeof keys?.p256dh === 'string' ? keys.p256dh.trim() : '';
    const auth = typeof keys?.auth === 'string' ? keys.auth.trim() : '';
    if (!p256dh || !auth) throw new BadRequestException('Push subscription keys (p256dh, auth) are required');
    return { endpoint, p256dh, auth };
  }

  async register(
    gymId: string,
    memberId: string,
    endpoint?: string,
    keys?: PushKeys,
  ) {
    const v = this.assertValid(endpoint, keys);
    return this.prisma.notificationSubscription.upsert({
      where: { gymId_memberId_endpoint: { gymId, memberId, endpoint: v.endpoint } },
      update: { p256dh: v.p256dh, auth: v.auth, keys: { p256dh: v.p256dh, auth: v.auth } as any },
      create: { gymId, memberId, endpoint: v.endpoint, p256dh: v.p256dh, auth: v.auth, keys: { p256dh: v.p256dh, auth: v.auth } as any },
    });
  }

  async unregister(gymId: string, memberId: string, endpoint?: string) {
    if (!endpoint) return { ok: true };
    await this.prisma.notificationSubscription.deleteMany({ where: { gymId, memberId, endpoint } });
    return { ok: true };
  }

  async list(gymId: string, memberId: string) {
    return this.prisma.notification.findMany({
      where: { gymId, to: memberId }, // Assuming 'to' can be memberId for in-app or linked mobile
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }
}
