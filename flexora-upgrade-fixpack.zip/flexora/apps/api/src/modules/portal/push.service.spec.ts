/**
 * FLEXORA Gym OS — Push notification service tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { PushService } from './push.service';
import { PrismaService } from '../../config/prisma.service';
import { RegisterPushDto } from './push.dto';

function build() {
  const store: any[] = [];
  const notificationSubscription = {
    findMany: jest.fn(({ where }: any) => Promise.resolve(store.filter(s => s.gymId === where.gymId && s.memberId === where.memberId))),
    findUnique: jest.fn(({ where }: any) => Promise.resolve(store.find(s => s.endpoint === (where.gymId_memberId_endpoint?.endpoint || where.endpoint)))),
    findFirst: jest.fn(({ where }: any) => Promise.resolve(store.find(s => s.endpoint === where.endpoint) || null)),
    create: jest.fn(({ data }: any) => {
      const n = { id: 'p' + Math.random(), ...data }; store.push(n); return Promise.resolve(n);
    }),
    update: jest.fn(({ where, data }: any) => {
      const idx = store.findIndex(s => s.id === where.id);
      if (idx !== -1) { store[idx] = { ...store[idx], ...data }; return Promise.resolve(store[idx]); }
      return Promise.resolve(null);
    }),
    upsert: jest.fn(({ where, create, update }: any) => {
      const idx = store.findIndex(s => s.endpoint === where.gymId_memberId_endpoint.endpoint);
      if (idx !== -1) { store[idx] = { ...store[idx], ...update }; return Promise.resolve(store[idx]); }
      const n = { id: 'p' + Math.random(), ...create }; store.push(n); return Promise.resolve(n);
    }),
    deleteMany: jest.fn(({ where }: any) => {
      const start = store.length;
      const filtered = store.filter(s => !(s.gymId === where.gymId && s.memberId === where.memberId && s.endpoint === where.endpoint));
      store.splice(0, store.length, ...filtered);
      return Promise.resolve({ count: start - store.length });
    }),
  };
  // ROUND 14 (security review, PHASE C): list() reads the in-app Notification
  // model (where.to = memberId), not the subscription table — the mock mirrors
  // the current service contract.
  const notifications: any[] = [];
  const notification = {
    findMany: jest.fn(({ where }: any) => Promise.resolve(notifications.filter((n) => n.gymId === where.gymId && n.to === where.to))),
  };
  const prisma = { notificationSubscription, notification } as any as PrismaService;
  const svc = new PushService(prisma);
  return { svc, prisma, store, notifications };
}

describe('PushService', () => {
  const KEYS = { p256dh: 'p', auth: 'a' };
  const ENDPOINT = 'https://push.example.com/123';

  it('registers a new subscription', async () => {
    const { svc, store } = build();
    await svc.register('g1', 'm1', ENDPOINT, KEYS);
    expect(store.length).toBe(1);
    expect(store[0].endpoint).toBe(ENDPOINT);
  });

  it('updates existing subscription on same endpoint', async () => {
    const { svc, store } = build();
    await svc.register('g1', 'm1', ENDPOINT, KEYS);
    await svc.register('g1', 'm1', ENDPOINT, { ...KEYS, auth: 'new' });
    expect(store.length).toBe(1);
    expect((store[0].keys as any).auth).toBe('new');
  });

  it('unregisters a subscription', async () => {
    const { svc, store } = build();
    await svc.register('g1', 'm1', ENDPOINT, KEYS);
    await svc.unregister('g1', 'm1', ENDPOINT);
    expect(store.length).toBe(0);
  });

  it('lists the member\'s notifications (in-app list reads the Notification model)', async () => {
    const { svc, notifications } = build();
    await svc.register('g1', 'm1', ENDPOINT, KEYS);
    notifications.push({ id: 'n1', gymId: 'g1', to: 'm1', body: 'hello' });
    const list = await svc.list('g1', 'm1');
    expect(list.length).toBe(1);
    expect((list[0] as any).body).toBe('hello');
  });
});
