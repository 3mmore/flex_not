/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, HttpCode, HttpStatus, Param, Post, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { IsIn, IsOptional, IsString, Length, Matches } from 'class-validator';
import { PortalService } from './portal.service';
import { PushService } from './push.service';
import { RegisterPushDto, UnregisterPushDto } from './push.dto';
import { Public } from '../../common/decorators/public.decorator';
import { MemberAuthGuard } from '../../common/guards/member-auth.guard';
import { CurrentMember } from '../../common/decorators/current-member.decorator';
import { BruteForceGuard } from '../../common/guards/brute-force.guard';
import { BruteForce } from '../../common/decorators/brute-force.decorator';
import { Tier } from '../billing/paymob.service';
import { isCookieSecure } from '../../config/cookie-secure';

const EG = /^(010|011|012|015)\d{8}$/;

class RequestOtpDto {
  @Matches(EG, { message: 'Invalid Egyptian mobile' }) mobile!: string;
  @IsOptional() @IsString() gymSlug?: string;
}
class VerifyOtpDto {
  @Matches(EG) mobile!: string;
  @IsString() @Length(6, 6) code!: string;
  @IsOptional() @IsString() gymSlug?: string;
}
class RenewDto {
  @IsOptional() @IsIn(['BASIC', 'PRO', 'ELITE']) tier?: Tier;
}

@ApiTags('portal')
// SECURITY: class-level @Public() so the GLOBAL JwtAuthGuard (staff token,
// JWT_ACCESS_SECRET) does not reject member-portal requests that carry a
// member token (JWT_MEMBER_SECRET). Member auth is enforced per-method by
// MemberAuthGuard below.
@Public()
@Controller('portal')
export class PortalController {
  constructor(
    private readonly svc: PortalService,
    private readonly push: PushService,
  ) {}

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce()
  @Post('request-otp')
  requestOtp(@Body() dto: RequestOtpDto) {
    return this.svc.requestOtp(dto.mobile, dto.gymSlug);
  }

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce()
  @Post('verify-otp')
  async verifyOtp(@Body() dto: VerifyOtpDto, @Res({ passthrough: true }) res: Response) {
    const result = await this.svc.verifyOtp(dto.mobile, dto.code, dto.gymSlug);
    // ROUND 14 (security review, PHASE F2): the member token is ONLY ever set
    // as an HttpOnly, SameSite=Strict cookie with path=/ — so it reaches the
    // /api/portal/* proxy calls, is never readable by JavaScript (no token
    // theft via XSS), and is not exposed to cross-site requests. A separate
    // NON-secret indicator cookie lets the client pages tell logged-in from
    // logged-out without ever seeing the token. The token is NOT returned in
    // the response body.
    res.cookie('flx_member_access', result.token, {
      httpOnly: true,
      secure: isCookieSecure(),
      sameSite: 'strict',
      path: '/',
      maxAge: 86400 * 1000,
    });
    res.cookie('flx_member_session', '1', {
      httpOnly: false,
      secure: isCookieSecure(),
      sameSite: 'strict',
      path: '/',
      maxAge: 86400 * 1000,
    });
    return result.member;
  }

  @UseGuards(MemberAuthGuard)
  @Get('me')
  me(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.getProfile(memberId, gymId);
  }

  @UseGuards(MemberAuthGuard)
  @Post('logout')
  logout(
    @CurrentMember('sub') memberId: string,
    @CurrentMember('jti') jti: string,
    @Res({ passthrough: true }) res: Response,
  ) {
    res.clearCookie('flx_member_access', { path: '/' });
    res.clearCookie('flx_member_session', { path: '/' });
    return this.svc.logout(memberId, jti);
  }

  @UseGuards(MemberAuthGuard)
  @Post('renew')
  renew(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string, @Body() _dto?: RenewDto) {
    // ROUND 14 (Phase E): renews the member's own plan — no tier/payload needed.
    return this.svc.renew(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Get('classes')
  classes(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.upcomingClasses(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Post('classes/:id/book')
  bookClass(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string, @Param('id') id: string) {
    return this.svc.bookClass(gymId, memberId, id);
  }

  @UseGuards(MemberAuthGuard)
  @Post('classes/:id/cancel')
  cancelClass(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string, @Param('id') id: string) {
    return this.svc.cancelClass(gymId, memberId, id);
  }

  // --------------------------------------------------------------------------
  // Web Push subscriptions (member-scoped, tenant-isolated)
  // --------------------------------------------------------------------------
  @UseGuards(MemberAuthGuard)
  @Post('push/register')
  @HttpCode(HttpStatus.CREATED) // 201 — subscription registered/refreshed
  registerPush(
    @CurrentMember('gymId') gymId: string,
    @CurrentMember('sub') memberId: string,
    @Body() dto: RegisterPushDto,
  ) {
    return this.push.register(gymId, memberId, dto.endpoint, dto.keys);
  }

  @UseGuards(MemberAuthGuard)
  @Post('push/unregister')
  @HttpCode(HttpStatus.OK) // 200 — idempotent removal
  unregisterPush(
    @CurrentMember('gymId') gymId: string,
    @CurrentMember('sub') memberId: string,
    @Body() dto: UnregisterPushDto,
  ) {
    return this.push.unregister(gymId, memberId, dto.endpoint);
  }

  @UseGuards(MemberAuthGuard)
  @Get('notifications')
  notifications(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.listNotifications(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Post('notifications/:id/read')
  markNotificationRead(
    @CurrentMember('gymId') gymId: string,
    @CurrentMember('sub') memberId: string,
    @Param('id') id: string,
  ) {
    return this.svc.markNotificationRead(gymId, memberId, id);
  }

  // --------------------------------------------------------------------------
  // ROUND 14 (security review, PHASE E) — the member journey pages.
  // --------------------------------------------------------------------------
  @UseGuards(MemberAuthGuard)
  @Get('dashboard')
  dashboard(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.dashboard(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Get('bookings')
  bookings(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.bookings(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Get('attendance')
  attendance(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.attendance(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Get('financial-history')
  financialHistory(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.svc.financialHistory(gymId, memberId);
  }

  @UseGuards(MemberAuthGuard)
  @Post('subscribe-push')
  @HttpCode(HttpStatus.CREATED)
  subscribePush(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string, @Body() dto: RegisterPushDto) {
    return this.push.register(gymId, memberId, dto.endpoint, dto.keys);
  }

  @UseGuards(MemberAuthGuard)
  @Get('push/subscriptions')
  listPush(@CurrentMember('gymId') gymId: string, @CurrentMember('sub') memberId: string) {
    return this.push.list(gymId, memberId);
  }
}
