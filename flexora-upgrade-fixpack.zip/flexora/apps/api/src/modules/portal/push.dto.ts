/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * DTOs for member-portal Web Push registration. Validation here (combined with
 * the global ValidationPipe) guarantees malformed/empty payloads are rejected
 * with 400 Bad Request before reaching the service — never a 500.
 */
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsObject,
  IsString,
  IsUrl,
  ValidateNested,
} from 'class-validator';

export class PushKeysDto {
  @IsString()
  @IsNotEmpty({ message: 'p256dh key is required' })
    p256dh!: string;

  @IsString()
  @IsNotEmpty({ message: 'auth key is required' })
    auth!: string;
}

export class RegisterPushDto {
  @IsString()
  @IsNotEmpty({ message: 'endpoint is required' })
  // require_tld:false so localhost / push-service hosts validate in dev too
  @IsUrl({ require_tld: false }, { message: 'endpoint must be a valid URL' })
    endpoint!: string;

  @IsObject()
  @ValidateNested()
  @Type(() => PushKeysDto)
    keys: PushKeysDto;
}

export class UnregisterPushDto {
  @IsString()
  @IsNotEmpty({ message: 'endpoint is required' })
    endpoint!: string;
}
