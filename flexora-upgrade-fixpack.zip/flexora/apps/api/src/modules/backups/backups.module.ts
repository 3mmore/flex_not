/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { BackupsService } from './backups.service';
import { BackupsController } from './backups.controller';
import { NotificationsModule } from '../notifications/notifications.module';
// FIX (launch-readiness: found immediately after fixing the QueueService DI
// bug in ContractsModule/LeadsModule/CampaignsModule, which had been
// masking this second, separate module-wiring bug from ever surfacing).
// BackupsModule never exported BackupsService, so even though
// SchedulerModule correctly imports BackupsModule, SchedulerService's own
// direct constructor dependency on BackupsService could not be resolved --
// Nest module boundaries only expose a module's EXPORTED providers to
// modules that import it, not just any provider merely declared in
// `providers`. Confirmed directly: this was the exact next boot-blocking
// error, "Nest can't resolve dependencies of the SchedulerService ...
// Please make sure that the argument BackupsService at index [6] is
// available in the SchedulerModule module", once the QueueService bug was
// fixed and the bootstrap process got further before failing.
// FIX (launch-readiness: fifth bug found in the same masked chain --
// BackupsController's own constructor directly injects NotificationsService,
// but BackupsModule never imported NotificationsModule, the only module
// that provides/exports it. Confirmed directly: "Nest can't resolve
// dependencies of the BackupsController (BackupsService, RedisService, ?).
// Please make sure that the argument NotificationsService at index [2] is
// available in the BackupsModule module.").
@Module({
  imports: [JwtModule.register({}), NotificationsModule],
  controllers: [BackupsController],
  providers: [BackupsService],
  exports: [BackupsService],
})
export class BackupsModule {}
