/**
 * PHASE P2 — `restoreFromExcel` must be ONE atomic transaction that inserts in
 * batches, never silently drops duplicates, re-encrypts with the CURRENT keys,
 * and sizes its transaction timeout from the size of the backup.
 *
 * Why this spec exists (the behaviour it pins):
 *
 *  - BEFORE: every row was written with its own `tx.<model>.create(...)` inside a
 *    `for` loop, in a transaction hard-coded to `{ timeout: 60000 }`. A 10 000
 *    member backup needed 10 000+ round-trips, exceeded 60 s, and Prisma rolled
 *    the whole interactive transaction back — the restore could not complete.
 *  - BEFORE: `mobile`/`nationalId` were written back exactly as exported, i.e. as
 *    the CIPHERTEXT stored when the backup was taken. After a key rotation the
 *    restored rows could no longer be read by any current key, so member search
 *    and portal lookups silently stopped matching them.
 *
 * Each `it` below fails against the pre-P2 implementation:
 *   1. the timeout is derived, not 60 000;
 *   2. rows arrive via `createMany` in chunks of at most RESTORE_BATCH_SIZE and
 *      the per-row `create` is never called;
 *   3. no `createMany` call is given `skipDuplicates`;
 *   4. an old-key ciphertext is re-encrypted with the current key, and a value
 *      that is ALREADY current is left byte-identical (negative control: this is
 *      a re-key, not a double encryption);
 *   5. a failure in the last batch propagates instead of being swallowed, so the
 *      single transaction rolls back.
 */
import * as ExcelJS from 'exceljs';
import { mkdtempSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import {
  BackupsService,
  RESTORE_BATCH_SIZE,
  RESTORE_MAX_TIMEOUT_MS,
  RESTORE_MIN_TIMEOUT_MS,
  restoreTimeoutMs,
} from './backups.service';
import { EncryptionService } from '../../common/security/encryption.service';

const GYM = 'gym-p2-spec';
const BRANCH_ID = 'branch-p2-1';
const PLAN_ID = 'plan-p2-1';

/** The current key stamps values `NEW$…`; a backup taken before the rotation carries `OLD$…`. */
const encryptionStub = {
  isEncrypted: (v: string | null | undefined): boolean =>
    typeof v === 'string' && (v.startsWith('OLD$') || v.startsWith('NEW$')),
  decrypt: (v: string): string => v.replace(/^(OLD|NEW)\$/, ''),
  encryptDeterministic: (plaintext: string): string => `NEW$${plaintext}`,
} as unknown as EncryptionService;

const MODELS = [
  'branch',
  'plan',
  'product',
  'classTemplate',
  'member',
  'classSession',
  'attendance',
  'sale',
  'expense',
] as const;
type Model = (typeof MODELS)[number];

interface Recorded {
  chunkSizes: Record<Model, number[]>;
  createManyArgs: Record<Model, unknown[]>;
  perRowCreates: Model[];
  withTenantCalls: { timeout: number | undefined }[];
  rowsWritten: Record<Model, Record<string, unknown>[]>;
}

/**
 * Build the transaction/Prisma double. `failLastMemberBatch` makes the final
 * member batch throw, which is how the rollback proof is injected.
 */
function buildHarness(opts: { failLastMemberBatch?: boolean } = {}) {
  const recorded: Recorded = {
    chunkSizes: {} as Record<Model, number[]>,
    createManyArgs: {} as Record<Model, unknown[]>,
    perRowCreates: [],
    withTenantCalls: [],
    rowsWritten: {} as Record<Model, Record<string, unknown>[]>,
  };
  for (const model of MODELS) {
    recorded.chunkSizes[model] = [];
    recorded.createManyArgs[model] = [];
    recorded.rowsWritten[model] = [];
  }

  const tx: Record<string, unknown> = {};
  for (const model of MODELS) {
    tx[model] = {
      deleteMany: jest.fn(async () => ({ count: 0 })),
      create: jest.fn(async () => {
        recorded.perRowCreates.push(model);
        return {};
      }),
      createMany: jest.fn(async (arg: { data: Record<string, unknown>[]; skipDuplicates?: boolean }) => {
        recorded.createManyArgs[model].push(arg);
        const sizes = recorded.chunkSizes[model];
        sizes.push(arg.data.length);
        if (
          opts.failLastMemberBatch &&
          model === 'member' &&
          sizes.reduce((a, b) => a + b, 0) >= MEMBER_ROWS
        ) {
          throw new Error('P2 injected failure on the last member batch');
        }
        recorded.rowsWritten[model].push(...arg.data);
        return { count: arg.data.length };
      }),
    };
  }
  // purge-only models the restore deletes from but never re-imports
  for (const model of ['classBooking', 'saleItem', 'stockMovement']) {
    tx[model] = { deleteMany: jest.fn(async () => ({ count: 0 })) };
  }

  const prisma = {
    withTenant: jest.fn(
      async (_gymId: string, fn: (t: unknown) => Promise<unknown>, options?: { timeout?: number }) => {
        recorded.withTenantCalls.push({ timeout: options?.timeout });
        return fn(tx);
      },
    ),
  };

  const service = new BackupsService(
    prisma as never,
    {} as never,
    {} as never,
    { run: (_gymId: string, fn: () => unknown) => fn() } as never,
    undefined,
    encryptionStub,
  );
  return { service, recorded, prisma };
}

const MEMBER_ROWS = 2500;

/** A backup with every sheet the restore requires, and `memberCount` members. */
async function writeBackup(dir: string, memberCount: number, firstMobile: string): Promise<string> {
  const wb = new ExcelJS.Workbook();

  const branches = wb.addWorksheet('Branches');
  branches.addRow(['id', 'name', 'address', 'phone', 'manager', 'createdAt']);
  branches.addRow([BRANCH_ID, 'P2 Branch', '1 Test St', '01000000000', 'Owner', new Date().toISOString()]);

  const plans = wb.addWorksheet('Subscriptions');
  plans.addRow(['id', 'name', 'type', 'sessions', 'days', 'price', 'active', 'invitations', 'maxFreezes', 'freezeDays', 'createdAt']);
  plans.addRow([PLAN_ID, '1 Month', 'TIME', null, 30, 450, true, 0, 0, 0, new Date().toISOString()]);

  for (const name of ['Products', 'ClassTemplates', 'ClassSessions', 'Attendance', 'Sales', 'Expenses', 'Staff']) {
    const sheet = wb.addWorksheet(name);
    sheet.addRow(['id']);
  }

  const members = wb.addWorksheet('Members');
  members.addRow([
    'id', 'gymId', 'branchId', 'planId', 'code', 'name', 'mobile', 'nationalId', 'status',
    'sessionsLeft', 'invitationSlots', 'visits', 'vip', 'frozen', 'startDate', 'createdAt',
  ]);
  for (let i = 0; i < memberCount; i += 1) {
    // the first row carries an OLD-key ciphertext, the second an already-current
    // one, the rest plaintext — all three must end up on the current key
    const mobile = i === 0 ? firstMobile : i === 1 ? 'NEW$01111111111' : `0100000${String(i).padStart(4, '0')}`;
    members.addRow([
      `member-p2-${i}`, GYM, BRANCH_ID, PLAN_ID, `P2${i}`,
      `Member P2 ${i} Test`, mobile, i === 0 ? 'OLD$29900000000001' : null, 'ACTIVE',
      0, 5, 0, false, false, new Date().toISOString(), new Date().toISOString(),
    ]);
  }

  const file = join(dir, `p2-backup-${memberCount}.xlsx`);
  await wb.xlsx.writeFile(file);
  return file;
}

describe('PHASE P2 — restoreFromExcel batching, timeout and re-encryption', () => {
  let dir: string;

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), 'p2-restore-'));
  });

  afterEach(() => {
    rmSync(dir, { recursive: true, force: true });
  });

  describe('restoreTimeoutMs = clamp(60 s, rows * 25 ms, 10 min)', () => {
    it('floors at 60 s for a small backup', () => {
      expect(restoreTimeoutMs(0)).toBe(RESTORE_MIN_TIMEOUT_MS);
      expect(restoreTimeoutMs(10)).toBe(RESTORE_MIN_TIMEOUT_MS);
      expect(restoreTimeoutMs(2400)).toBe(RESTORE_MIN_TIMEOUT_MS); // 2400 * 25 = 60 000
    });

    it('scales with the row count in between', () => {
      expect(restoreTimeoutMs(2401)).toBe(2401 * 25);
      expect(restoreTimeoutMs(10_000)).toBe(250_000); // a 10 000-member backup gets 250 s
      expect(restoreTimeoutMs(20_000)).toBe(500_000);
    });

    it('caps at 10 minutes', () => {
      expect(restoreTimeoutMs(24_000)).toBe(RESTORE_MAX_TIMEOUT_MS); // 24 000 * 25 = 600 000
      expect(restoreTimeoutMs(10_000_000)).toBe(RESTORE_MAX_TIMEOUT_MS);
    });

    it('treats a non-finite row count as the floor, never as Infinity or NaN', () => {
      expect(restoreTimeoutMs(-5)).toBe(RESTORE_MIN_TIMEOUT_MS);
      expect(restoreTimeoutMs(Number.NaN)).toBe(RESTORE_MIN_TIMEOUT_MS);
      // A non-finite count means the caller passed garbage, not that the backup is
      // enormous: fail fast on the 60 s floor rather than hand a broken restore a
      // 10-minute transaction (and its locks). Genuine huge-but-finite counts are
      // covered by the cap test above.
      expect(restoreTimeoutMs(Number.POSITIVE_INFINITY)).toBe(RESTORE_MIN_TIMEOUT_MS);
      expect(Number.isFinite(restoreTimeoutMs(Number.POSITIVE_INFINITY))).toBe(true);
    });
  });

  it('runs ONE withTenant transaction and passes the derived timeout, not 60 000', async () => {
    const { service, recorded } = buildHarness();
    const file = await writeBackup(dir, MEMBER_ROWS, 'OLD$01000000001');

    await service.restoreFromExcel(GYM, file, true);

    // ONE atomic transaction — batching must not turn into several commits
    expect(recorded.withTenantCalls).toHaveLength(1);
    // 2500 members + 1 branch + 1 plan + 9 header rows counted by rowCount-1
    expect(recorded.withTenantCalls[0].timeout).toBeGreaterThan(RESTORE_MIN_TIMEOUT_MS);
    expect(recorded.withTenantCalls[0].timeout).toBe(restoreTimeoutMs(2500 + 1 + 1));
    expect(recorded.withTenantCalls[0].timeout).not.toBe(60_000);
  }, 60_000);

  it('inserts with createMany in batches of at most RESTORE_BATCH_SIZE and never per row', async () => {
    const { service, recorded } = buildHarness();
    const file = await writeBackup(dir, MEMBER_ROWS, 'OLD$01000000001');

    await service.restoreFromExcel(GYM, file, true);

    const sizes = recorded.chunkSizes.member;
    expect(sizes.length).toBe(Math.ceil(MEMBER_ROWS / RESTORE_BATCH_SIZE)); // 2500 -> 3 batches
    expect(sizes.every((n) => n > 0 && n <= RESTORE_BATCH_SIZE)).toBe(true);
    expect(sizes.reduce((a, b) => a + b, 0)).toBe(MEMBER_ROWS);
    expect(recorded.rowsWritten.member).toHaveLength(MEMBER_ROWS);

    // the pre-P2 path: one round-trip per row
    expect(recorded.perRowCreates).toEqual([]);
    expect(recorded.chunkSizes.branch).toEqual([1]);
    expect(recorded.chunkSizes.plan).toEqual([1]);
  }, 60_000);

  it('never passes skipDuplicates — a conflicting row must fail the restore, not vanish', async () => {
    const { service, recorded } = buildHarness();
    const file = await writeBackup(dir, MEMBER_ROWS, 'OLD$01000000001');

    await service.restoreFromExcel(GYM, file, true);

    for (const model of MODELS) {
      for (const arg of recorded.createManyArgs[model]) {
        expect(arg).not.toHaveProperty('skipDuplicates');
        expect(Object.keys(arg)).toEqual(['data']);
      }
    }
  }, 60_000);

  it('re-encrypts an old-key ciphertext with the CURRENT key (and leaves a current value untouched)', async () => {
    const { service, recorded } = buildHarness();
    const file = await writeBackup(dir, 3, 'OLD$01000000001');

    await service.restoreFromExcel(GYM, file, true);

    const mobiles = recorded.rowsWritten.member.map((row) => row.mobile as string);
    // row 0: OLD$ ciphertext -> decrypted, then re-encrypted with the current key
    expect(mobiles[0]).toBe('NEW$01000000001');
    // row 1 (negative control): already on the current key -> byte-identical, so
    // this is a re-key and NOT a double encryption
    expect(mobiles[1]).toBe('NEW$01111111111');
    // row 2: plaintext in the sheet -> encrypted rather than stored in the clear
    expect(mobiles[2]).toBe('NEW$01000000002');

    const nationalIds = recorded.rowsWritten.member.map((row) => row.nationalId as string | null);
    expect(nationalIds[0]).toBe('NEW$29900000000001');
    expect(nationalIds[1]).toBeNull();
  }, 60_000);

  it('propagates a failure from the last batch instead of reporting a partial restore', async () => {
    const { service, recorded } = buildHarness({ failLastMemberBatch: true });
    const file = await writeBackup(dir, MEMBER_ROWS, 'OLD$01000000001');

    await expect(service.restoreFromExcel(GYM, file, true)).rejects.toThrow(/injected failure/);

    // still exactly one transaction: the caller's rollback is what keeps the
    // gym's previous data intact (proved live in the PHASE P2 evidence)
    expect(recorded.withTenantCalls).toHaveLength(1);
    expect(recorded.perRowCreates).toEqual([]);
  }, 60_000);
});
