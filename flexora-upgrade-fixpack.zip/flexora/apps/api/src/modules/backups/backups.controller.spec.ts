/**
 * PHASE N1 — backups controller: the restore-upload storage must not read
 * BACKUP_DIR (or create it) at import time, and its multer callback must never
 * throw, because a throw inside a busboy stream event is an uncaught exception
 * that kills the API process.
 *
 * Asserts on the variable NAME only, never on a secret value (L1/M2).
 */
import { HttpException, ServiceUnavailableException } from '@nestjs/common';
import { existsSync, mkdtempSync, rmSync, statSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

import { backupUploadDestination } from './backups.controller';

const REAL_ENV = { ...process.env };

function withEnv<T>(vars: Record<string, string | undefined>, fn: () => T): T {
  const saved = { ...process.env };
  for (const [k, v] of Object.entries(vars)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  try {
    return fn();
  } finally {
    for (const key of Object.keys(process.env)) delete process.env[key];
    Object.assign(process.env, saved);
  }
}

let root: string;
let unusable: string;
let usable: string;

beforeAll(() => {
  root = mkdtempSync(join(tmpdir(), 'n1-backups-'));
  const blocker = join(root, 'blocker');
  writeFileSync(blocker, 'regular file, not a directory\n');
  unusable = join(blocker, 'uploads');   // cannot ever be created
  usable = join(root, 'ok', 'uploads');  // can be created
});

afterAll(() => {
  Object.keys(process.env).forEach((k) => delete process.env[k]);
  Object.assign(process.env, REAL_ENV);
  try {
    rmSync(root, { recursive: true, force: true });
  } catch {
    /* best effort */
  }
});

function capture() {
  const calls: Array<{ error: Error | null; destination: string }> = [];
  return {
    calls,
    cb: (error: Error | null, destination: string) => calls.push({ error, destination }),
    first: () => calls[0],
  };
}

describe('PHASE N1 — backups.controller: import-time safety', () => {
  it('creates nothing when the module is imported', () => {
    const sentinel = join(root, 'sentinel-uploads');
    withEnv({ BACKUP_DIR: sentinel }, () => {
      jest.isolateModules(() => {
        require('./backups.controller');
      });
    });
    expect(existsSync(sentinel)).toBe(false);
  });
});

describe('PHASE N1 — backups.controller: multer destination never throws', () => {
  it('reports an unusable BACKUP_DIR through the callback as a 503', () => {
    const { calls, cb, first } = capture();
    withEnv({ BACKUP_DIR: unusable }, () => {
      expect(() => backupUploadDestination({}, {}, cb)).not.toThrow();
    });
    expect(calls).toHaveLength(1);
    expect(first().error).toBeInstanceOf(ServiceUnavailableException);
    expect((first().error as HttpException).getStatus()).toBe(503);
    expect(first().destination).toBe('');
  });

  it('names the variable BACKUP_DIR and the failing path, and leaks no secret', () => {
    const SECRET = 'B4ckup-s3cret-that-must-not-be-logged';
    const { cb, first } = capture();
    withEnv({ BACKUP_DIR: unusable, BACKUP_ENCRYPTION_KEY: SECRET }, () => {
      backupUploadDestination({}, {}, cb);
    });
    const message = (first().error as HttpException).message;
    expect(message).toContain('BACKUP_DIR');
    expect(message).toContain(unusable);
    expect(message).toMatch(/ENOTDIR/);
    expect(message).toMatch(/Set BACKUP_DIR to a directory/);
    expect(message).not.toContain(SECRET);
  });

  it('creates and returns BACKUP_DIR when it is usable', () => {
    const { calls, cb, first } = capture();
    withEnv({ BACKUP_DIR: usable }, () => {
      backupUploadDestination({}, {}, cb);
    });
    expect(calls).toHaveLength(1);
    expect(first().error).toBeNull();
    expect(first().destination).toBe(usable);
    expect(statSync(usable).isDirectory()).toBe(true);
  });
});
