/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Body, Controller, Get, Param, Post, Res, ServiceUnavailableException, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { randomBytes } from 'crypto';
import { Response } from 'express';
import { unlink } from 'fs/promises';
import { existsSync, mkdirSync } from 'fs';
import { IsBoolean, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';
import { BackupsService } from './backups.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { RedisService } from '../../config/redis.service';
import { NotificationsService } from '../notifications/notifications.service';

const DEFAULT_BACKUP_DIR = '/var/backups/flexora/uploads';

/**
 * PHASE N1 — multer's `destination` for the restore upload, resolved per
 * request. Two hazards are handled here:
 *
 *   * A decorator argument is evaluated when the class is *defined*, so the old
 *     inline `destination: process.env.BACKUP_DIR || …` froze the value at
 *     import time and made multer create that directory as a side effect of
 *     merely importing this file (observed: requiring the module created
 *     BACKUP_DIR before Nest ever started).
 *   * This callback runs inside a busboy stream event, outside Nest's exception
 *     pipeline. Anything thrown here is an uncaught exception that kills the
 *     process — the same crash that members-import.controller.spec.ts pins down
 *     for IMPORT_UPLOAD_DIR. Errors therefore leave through `cb`.
 */
export function backupUploadDestination(
  _req: unknown,
  _file: unknown,
  cb: (error: Error | null, destination: string) => void,
): void {
  const dir = process.env.BACKUP_DIR || DEFAULT_BACKUP_DIR;
  try {
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    cb(null, dir);
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code || 'unknown error';
    cb(
      new ServiceUnavailableException(
        `BACKUP_DIR is not usable: cannot create the backup directory ` +
        `${dir} (${code}). Set BACKUP_DIR to a directory the API process ` +
        `is allowed to create, or pre-create it.`,
      ),
      '',
    );
  }
}

export class RestoreConfirmDto {
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === 'true' || value === true)
  confirmed?: boolean;

  @IsOptional()
  @IsString()
  confirmToken?: string;
}

export class RestoreTokenRequestDto {
  @IsOptional()
  gymId?: string;
}

@ApiTags('backups')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('backups')
export class BackupsController {
  constructor(
    private readonly svc: BackupsService,
    private readonly redis: RedisService,
    private readonly notify: NotificationsService,
  ) {}
  
  private get backupsService() { return this.svc; }

  @Get('verify')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('backups.manage')
  async verifyBackup(@GymId() gymId: string) {
    return this.backupsService.verifyLatestBackup(gymId);
  }

  @Get('list') @Permissions('backups.manage') list(@GymId() g: string) { return this.svc.list(g); }

  @Get() @Roles('OWNER', 'SUPER_ADMIN') @Permissions('backups.manage') listOld(@GymId() g: string) { return this.svc.list(g); }

  @Get('download/latest')
  @Permissions('backups.manage')
  async downloadLatest(@GymId() gymId: string, @Res() res: Response) {
    const backup = await this.svc.getLatestBackup(gymId);
    res.download(backup.path, backup.filename);
  }

  @Get('download/:filename')
  @Permissions('backups.manage')
  async downloadFile(@GymId() gymId: string, @Param('filename') filename: string, @Res() res: Response) {
    if (!/^[a-zA-Z0-9_.-]+$/.test(filename)) throw new BadRequestException('Invalid filename');
    const backup = await this.svc.getBackupFile(gymId, filename);
    res.download(backup.path, backup.filename);
  }

  @Post('restore/request-token')
  @Permissions('backups.manage')
  @Audit('restore-request-token', 'Backup')
  async requestRestoreToken(@GymId() gymId: string) {
    const token = randomBytes(32).toString('hex');
    await this.redis.set(`restore:token:${gymId}`, token, 300); // 5 min expiry
    
    // Send token to OWNER via WhatsApp (critical safety warning)
    const message = 
      `تحذير: طلب استعادة البيانات\n` +
      `رمز التأكيد: ${token}\n` +
      `هذا الرمز صالح لمدة 5 دقائق فقط.\n` +
      `استعادة البيانات ستحذف جميع بياناتك الحالية.`;
    
    try {
      await this.notify.whatsapp(gymId, '', message); // owner number via context
    } catch (e) {
      // Log but don't fail token generation
    }
    
    return { message: 'Token sent via WhatsApp', expiresIn: 300 };
  }

  @Post('restore')
  @Permissions('backups.manage')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      // PHASE N1: a named function — nothing is read or created at import time,
      // and errors leave through the callback (see backupUploadDestination).
      destination: backupUploadDestination,
      filename: (req, file, cb) => {
        const safe = randomBytes(16).toString('hex');
        cb(null, `restore-${safe}.xlsx`);
      },
    }),
    fileFilter: (req, file, cb) => {
      const allowed = [
        'application/vnd.openxmlformats-officedocument'
          + '.spreadsheetml.sheet',
        'application/octet-stream',
      ];
      if (!allowed.includes(file.mimetype) ||
          !file.originalname.toLowerCase().endsWith('.xlsx')) {
        cb(new BadRequestException(
          'Only .xlsx files are allowed'), false);
        return;
      }
      cb(null, true);
    },
    limits: { fileSize: 10 * 1024 * 1024 }, // compressed XLSX limit; parsing also validates workbook structure
  }))
  @Audit('restore', 'Backup')
  async restoreFromExcel(
    @GymId() gymId: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: RestoreConfirmDto,
  ) {
    if (!file) throw new BadRequestException('No file uploaded');
    try {
      // Require and consume a one-time confirmation token for destructive mode.
      if (dto.confirmed) {
        const saved = await this.redis.get(`restore:token:${gymId}`);
        if (!saved || saved !== dto.confirmToken) {
          throw new BadRequestException('Invalid or expired confirmation token');
        }
        await this.redis.del(`restore:token:${gymId}`);
      }
      return await this.svc.restoreFromExcel(gymId, file.path, dto.confirmed, dto.confirmToken);
    } finally {
      await unlink(file.path).catch(() => undefined);
    }
  }

  @Post('generate')
  @Permissions('backups.manage')
  @Audit('generate', 'Backup')
  async generate(@GymId() gymId: string) {
    const gym = await this.svc.prisma.gym.findUnique({ where: { id: gymId } });
    if (!gym) throw new BadRequestException('Gym not found');
    return this.svc.generateExcelBackup(gymId, gym.slug);
  }
  // Export is exposed on both GET and POST. Stacking @Get + @Post on a single
  // method does not register both routes in Nest, so they are split into two
  // handlers that delegate to the same service. gymId is taken from the token
  // (@GymId), so any gymId in the request body is ignored (tenant isolation).
  @Get('export') @Permissions('backups.manage') @Audit('export','Backup') exportTenantGet(@GymId() g: string) { return this.svc.exportTenant(g); }
  @Post('export') @Permissions('backups.manage') @Audit('export','Backup') exportTenantPost(@GymId() g: string) { return this.svc.exportTenant(g); }
  @Post('run') @Roles('SUPER_ADMIN') @Permissions('backups.manage') @Audit('run','Backup') run() { return this.svc.nightlyDump(); }
  @Post('pgdump') @Roles('SUPER_ADMIN') @Permissions('backups.manage') @Audit('pgdump','Backup') pgdump() { return this.svc.pgdump(); }
  @Post('restore-legacy') @Roles('SUPER_ADMIN') @Permissions('backups.manage') @Audit('restore','Backup') restore(@Body() dto: { backupId: string; confirmationToken?: string }) { return this.svc.restore(dto.backupId, dto.confirmationToken); }
}
