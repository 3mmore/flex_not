import { Test, TestingModule } from '@nestjs/testing';
import { BackupsService } from './backups.service';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { TenantContextService } from '../../common/services/tenant-context.service';

describe('BackupsService', () => {
  let service: BackupsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BackupsService,
        { provide: PrismaService, useValue: {} },
        { provide: RedisService, useValue: {} },
        { provide: CronLeadershipService, useValue: {} },
        { provide: TenantContextService, useValue: { run: (_gymId: string, fn: () => unknown) => fn() } },
      ],
    }).compile();

    service = module.get<BackupsService>(BackupsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
