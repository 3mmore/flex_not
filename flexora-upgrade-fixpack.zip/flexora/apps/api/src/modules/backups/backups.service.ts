/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, NotFoundException, OnModuleInit, Optional, ServiceUnavailableException } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { spawn } from 'child_process';
import { createReadStream, createWriteStream, mkdirSync } from 'fs';
import { mkdir, stat, readdir, unlink, readFile, writeFile } from 'fs/promises';
import { join } from 'path';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import * as ExcelJS from 'exceljs';
import type { CellValue } from 'exceljs';
import { PlanType, Gender, CheckinMethod, Prisma, ClassStatus, MemberStatus } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { RedisService } from '../../config/redis.service';
import { createCipheriv, createDecipheriv, createHash, randomBytes, scryptSync } from 'crypto';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { NotificationsService } from '../notifications/notifications.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

interface SheetConfig {
  name: string;
  data: Record<string, unknown>[];
}

/**
 * FIX (launch-readiness, discovered while re-verifying the FULL apps/api
 * test suite is green after the QueueService DI cascade fix —
 * `restore-drill.spec.ts` could never actually run a real end-to-end
 * backup/restore round-trip before that fix, since the whole app failed to
 * boot): Prisma's `Decimal` fields (e.g. `Plan.price`, `Sale.total`,
 * `Expense.amount`) are instances of `Prisma.Decimal` (decimal.js under the
 * hood), NOT plain JS numbers. When such a value is handed directly to
 * ExcelJS's `worksheet.addRow({ price: decimalInstance, ... })`, ExcelJS's
 * internal cell-value coercion calls `JSON.stringify()` on any object it
 * doesn't recognize as one of its own special value types (date/hyperlink/
 * formula/richText/error) — producing a literal quoted string cell value
 * like `"100"` (five characters: quote, 1, 0, 0, quote), not the number
 * `100`. `restoreFromExcel`'s `getRows(...)` then reads that raw cell value
 * back out and passes it through `Number(row.price)`, and `Number('"100"')`
 * (the string INCLUDING the literal quote characters) is `NaN` — confirmed
 * directly by writing a real `.xlsx` file with `Prisma.Decimal` values via
 * ExcelJS and reading the exact bytes back out. Real error this fix
 * resolves: `Invalid tx.plan.create() invocation ... price: NaN ... Argument
 * gym is missing` (the `NaN` for the required `price` field made Prisma's
 * client-side validation reject the whole call before it ever reached
 * Postgres, and the resulting error message about a missing `gym` argument
 * was Prisma's validator suggesting alternate valid input shapes, not the
 * real root cause). Fix: convert every `Prisma.Decimal` to a plain JS number
 * via `.toNumber()` before handing rows to ExcelJS, so every cell always
 * holds a real numeric value that both Excel and `Number(...)` on read-back
 * interpret correctly.
 */
function decimalsToNumbers(rows: Record<string, unknown>[]): Record<string, unknown>[] {
  return rows.map((row) => {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(row)) {
      out[key] = value instanceof Prisma.Decimal ? value.toNumber() : value;
    }
    return out;
  });
}

/**
 * PHASE P2 — restore batching and transaction-timeout policy.
 *
 * A restore used to issue ONE round-trip per row (`tx.member.create` inside a
 * `for` loop) inside a hard-coded 60 s interactive transaction. A 10 000-member
 * backup therefore needed 10 000+ round-trips and blew the timeout, and because
 * the whole restore is one transaction the gym was left with the purge rolled
 * back — recoverable, but the restore simply could not complete.
 *
 * Rows are now mapped exactly as before, queued, and flushed with `createMany`
 * in batches of RESTORE_BATCH_SIZE, and the timeout is derived from the size of
 * the backup instead of being a fixed guess:
 *
 *     timeout = clamp(60 s, rows * 25 ms, 10 min)
 *
 * 25 ms/row is a deliberately generous per-row budget (a batched insert costs a
 * small fraction of that), the 60 s floor keeps small restores on the old
 * behaviour, and the 10 min ceiling stops a huge or malformed sheet from holding
 * a transaction — and its locks — open indefinitely.
 */
export const RESTORE_BATCH_SIZE = 1000;
export const RESTORE_MS_PER_ROW = 25;
export const RESTORE_MIN_TIMEOUT_MS = 60_000;
export const RESTORE_MAX_TIMEOUT_MS = 600_000;

/** clamp(60 s, rows * 25 ms, 10 min) — see the note above. */
export function restoreTimeoutMs(totalRows: number): number {
  const rows = Number.isFinite(totalRows) && totalRows > 0 ? Math.floor(totalRows) : 0;
  return Math.min(RESTORE_MAX_TIMEOUT_MS, Math.max(RESTORE_MIN_TIMEOUT_MS, rows * RESTORE_MS_PER_ROW));
}

@Injectable()
export class BackupsService implements OnModuleInit {
  private readonly logger = new Logger('Backups');
  private readonly dir = process.env.BACKUP_DIR || '/var/backups/flexora/uploads';

  onModuleInit() {
    // Ensure the backup directory exists on startup
    // This prevents crashes if the directory is missing and also ensures
    // the uploads sub-directory is created for per-gym backup files
    mkdirSync(this.dir, { recursive: true });
    this.logger.log(`Backup dir ready: ${this.dir}`);
  }

  constructor(
    public readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly cronLeader: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
    @Optional() private readonly notify?: NotificationsService,
    @Optional() private readonly encryption?: EncryptionService,
  ) {}

  async pgdump() { return this.nightlyDump(); }

  async restore(backupId: string, confirmationToken?: string, gymId = 'platform') {
    const key = `backup:restore:${gymId}:${backupId}`;
    if (!confirmationToken) {
      const token = randomBytes(24).toString('hex');
      await this.redis.set(key, token, 60);
      return { confirmationToken: token, expiresInSeconds: 60 };
    }
    const expected = await this.redis.get(key);
    if (!expected || expected !== confirmationToken) throw new Error('Invalid or expired confirmation token');
    await this.redis.del(key);
    return { ok: true, restored: backupId };
  }

  async list(gymId: string) {
    // Only local backups are downloadable from this UI — S3-only rows have no
    // local file and previously produced confusing 400 "Backup not found" on
    // download. Keep the list to what the user can actually download.
    return this.prisma.backup.findMany({ where: { gymId, location: 'local' }, orderBy: { createdAt: 'desc' }, take: 50 });
  }

  @Cron('0 */6 * * *')
  async autoBackupTask() {
    return requestContext.run({ requestId: 'cron:auto-backup' }, async () => {
      // FIX (P3: scheduled auto-backup never actually runs): the leadership
      // lock acquisition could silently fail when Redis is unavailable (common
      // in dev/single-instance deployments), blocking the entire task.
      // Attempt the lock but proceed even if it can't be acquired — in a
      // single-instance deployment there's no contention anyway.
      let acquired = false;
      try {
        acquired = await this.cronLeader.acquireLock('auto-backup', 3600_000);
      } catch (e: unknown) {
        this.logger.warn(`Could not acquire auto-backup lock (Redis may be unavailable): ${(e as Error).message}`);
        acquired = true; // proceed without lock in single-instance mode
      }
      if (!acquired) return;
      try {
        const gyms = await this.prisma.gym.findMany({ where: { status: 'ACTIVE' }, select: { id: true, slug: true } });
        this.logger.log(`Auto-backup: processing ${gyms.length} active gyms`);
        for (const gym of gyms) {
          try {
            await this.tenantContext.run(gym.id, () => this.generateExcelBackup(gym.id, gym.slug));
            this.logger.log(`Auto-backup: completed for ${gym.slug}`);
          } catch (e: unknown) {
            this.logger.error(`Auto-backup failed for ${gym.slug}: ${(e as Error).message}`);
          }
        }
      } finally {
        try { await this.cronLeader.releaseLock('auto-backup'); } catch { /* Redis may be down */ }
      }
    });
  }

  async generateExcelBackup(gymId: string, gymSlug: string) {
    const data = await this.exportTenant(gymId);
    const workbook = new ExcelJS.Workbook();
    const dateStr = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `flexora-backup-${gymSlug}-${dateStr}-${randomBytes(3).toString('hex')}.xlsx`;
    const dir = join(this.dir, gymId);
    await mkdir(dir, { recursive: true });
    const path = join(dir, filename);

    // Add GymInfo sheet for restore ownership validation
    const infoSheet = workbook.addWorksheet('GymInfo');
    infoSheet.getCell('A1').value = 'GymId';
    infoSheet.getCell('B1').value = gymId;
    infoSheet.getCell('A2').value = 'GymSlug';
    infoSheet.getCell('B2').value = gymSlug;
    infoSheet.getCell('A3').value = 'ExportedAt';
    infoSheet.getCell('B3').value = new Date().toISOString();

    const staff = await this.prisma.user.findMany({
      where: { gymId },
      select: {
        id: true, name: true, email: true,
        role: true, branchId: true,
        active: true, createdAt: true,
      }
    });

    const membersWithNames = await Promise.all(data.members.map(async (m: any) => {
      const plan = data.plans.find(p => p.id === m.planId);
      const branch = data.branches.find(b => b.id === m.branchId);
      return {
        ...m,
        planName: plan?.name || 'Unknown',
        branchName: branch?.name || 'Unknown',
      };
    }));

    const sheets: SheetConfig[] = [
      { name: 'Members', data: decimalsToNumbers(membersWithNames as unknown as Record<string, unknown>[]) },
      { name: 'Subscriptions', data: decimalsToNumbers(data.plans as unknown as Record<string, unknown>[]) },
      { name: 'Attendance', data: decimalsToNumbers(data.attendance as unknown as Record<string, unknown>[]) },
      { name: 'Sales', data: decimalsToNumbers(data.sales as unknown as Record<string, unknown>[]) },
      { name: 'Expenses', data: decimalsToNumbers(data.expenses as unknown as Record<string, unknown>[]) },
      { name: 'ClassTemplates', data: decimalsToNumbers(data.branches as unknown as any) }, // Temp swap for length calc
      { name: 'Staff', data: staff as unknown as Record<string, unknown>[] },
      { name: 'Products', data: decimalsToNumbers(data.products as unknown as Record<string, unknown>[]) },
      { name: 'ClassSessions', data: decimalsToNumbers(data.transactions as unknown as any) }, // Temp
    ];

    // Better data fetching for specific sheets
    const [classTemplates, classSessions] = await Promise.all([
      this.prisma.classTemplate.findMany({ where: { gymId } }),
      this.prisma.classSession.findMany({ where: { gymId } }),
    ]);
    sheets[5].data = decimalsToNumbers(classTemplates as unknown as Record<string, unknown>[]);
    sheets[8].data = decimalsToNumbers(classSessions as unknown as Record<string, unknown>[]);


    for (const s of sheets) {
      const ws = workbook.addWorksheet(s.name);
      if (s.data.length > 0) {
        const columns = Object.keys(s.data[0]).map(key => ({ header: key, key, width: 20 }));
        ws.columns = columns;
        s.data.forEach(row => ws.addRow(row));

        // Styling
        ws.getRow(1).font = { bold: true };
        ws.columns.forEach(col => {
          col.alignment = { vertical: 'middle', horizontal: 'left' };
        });
        
        // Alternating row colors
        ws.eachRow((row, rowNumber) => {
          if (rowNumber > 1 && rowNumber % 2 === 0) {
            row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F9F9F9' } };
          }
        });
      }
    }

    const wsBranches = workbook.addWorksheet('Branches');
    wsBranches.columns = [
      { header: 'id', key: 'id', width: 30 },
      { header: 'name', key: 'name', width: 25 },
      { header: 'address', key: 'address', width: 35 },
      { header: 'phone', key: 'phone', width: 20 },
    ];
    wsBranches.addRows(data.branches);
    wsBranches.getRow(1).font = { bold: true };

    await workbook.xlsx.writeFile(path);
    const s = await stat(path);

    await this.prisma.backup.create({
      data: { gymId, filename, sizeBytes: s.size, location: 'local' },
    });

    // Retention: keep last 30
    const old = await this.prisma.backup.findMany({
      where: { gymId, location: 'local' },
      orderBy: { createdAt: 'desc' },
      skip: 30,
    });
    for (const b of old) {
      await unlink(join(this.dir, gymId, b.filename)).catch(() => {});
      await this.prisma.backup.delete({ where: { id: b.id } });
    }

    // Optional Cloud Upload
    await this.uploadToCloud(path, filename);

    return { filename, path };
  }

  private async uploadToCloud(path: string, filename: string) {
    // S3/Gdrive/Dropbox implementation placeholder
    const { S3_BUCKET } = process.env;
    if (S3_BUCKET) {
      try {
        // reuse existing uploadToS3 logic or similar
      } catch (e: unknown) {
        this.logger.warn(`Cloud upload failed: ${(e as Error).message}`);
      }
    }
  }

  async getBackupFile(gymId: string, filename: string) {
    if (!/^[a-zA-Z0-9_.-]+$/.test(filename)) throw new BadRequestException('Invalid backup filename');
    const backup = await this.prisma.backup.findFirst({
      where: { gymId, filename, location: 'local' },
    });
    if (!backup) throw new BadRequestException('Backup not found');
    const path = join(this.dir, gymId, filename);
    await stat(path);
    return { path, filename };
  }

  async getLatestBackup(gymId: string) {
    // FIX: only `location: 'local'` rows have a file on this server. The nightly
    // physical dump records `location: 's3'` rows for every gym when S3 is
    // configured, and those rows' files are NOT in the local backup dir — so
    // picking the newest row regardless of location made download/latest
    // `res.download()` an ENOENT → 500 "server_error". Also surface a clean
    // 404 instead of a raw Error (which the exception filter turned into 500).
    const b = await this.prisma.backup.findFirst({
      where: { gymId, location: 'local' },
      orderBy: { createdAt: 'desc' },
    });
    if (!b) throw new NotFoundException('No local backup found for this gym yet');
    const path = join(this.dir, gymId, b.filename);
    try { await stat(path); } catch { throw new NotFoundException('Backup file is missing from disk'); }
    return { ...b, path };
  }

  async restoreFromExcel(gymId: string, filePath: string, confirmed = false, confirmToken?: string) {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);

    // Ownership validation: Check GymInfo sheet if present
    const infoSheet = workbook.getWorksheet('GymInfo');
    if (infoSheet) {
      const fileGymId = String(infoSheet.getCell('B1').value || '');
      if (fileGymId && fileGymId !== gymId) {
        throw new BadRequestException(
          'This backup belongs to a different gym. Restore cancelled for safety.'
        );
      }
    }
    
    const required = ['Members', 'Subscriptions', 'Attendance', 'Sales', 'Expenses', 'ClassTemplates', 'Staff', 'Branches', 'Products'];
    const preview: Record<string, number> = {};
    
    for (const name of required) {
      const sheet = workbook.getWorksheet(name);
      if (!sheet && name !== 'ClassSessions') throw new BadRequestException(`Missing sheet: ${name}`);
      preview[name.toLowerCase()] = sheet ? sheet.rowCount - 1 : 0;
    }

    if (!confirmed) return { preview };

    // ... (snapshot logic)

    const getRows = (sheetName: string): Record<string, unknown>[] => {
      const sheet = workbook.getWorksheet(sheetName);
      if (!sheet) return [];
      const headers: string[] = [];
      const firstRow = sheet.getRow(1);
      if (Array.isArray(firstRow.values)) {
        (firstRow.values as CellValue[]).forEach((v, i) => {
          if (v) headers[i] = String(v);
        });
      }
      const rows: Record<string, unknown>[] = [];
      sheet.eachRow((row, i) => {
        if (i === 1) return;
        const obj: Record<string, unknown> = {};
        if (Array.isArray(row.values)) {
          (row.values as CellValue[]).forEach((v, idx) => {
            if (headers[idx]) obj[headers[idx]] = v;
          });
        }
        rows.push(obj);
      });
      return rows;
    };

    // =====================================================================
    // PHASE N2 — cell coercion for the restore path.
    //
    // ExcelJS does not hand back plain strings/numbers: a cell can be a Date,
    // a boolean, a number, a rich-text object ({ richText: [...] }), a
    // hyperlink object ({ text, hyperlink }) or a formula object ({ formula,
    // result }). The restore code used to do `String(row.x)` on everything,
    // which turns those objects into the literal string "[object Object]" and
    // writes garbage into the database. Backups written before the
    // `decimalsToNumbers` export fix can also hold quoted numbers ('"100"'),
    // which `Number(...)` turns into NaN. Every value read back from a sheet
    // therefore goes through the helpers below.
    // =====================================================================
    const cellText = (v: unknown): string | null => {
      if (v === null || v === undefined) return null;
      if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v.toISOString();
      if (typeof v === 'object') {
        const o = v as { richText?: { text?: unknown }[]; text?: unknown; result?: unknown };
        if (Array.isArray(o.richText)) return o.richText.map((r) => cellText(r?.text) ?? '').join('');
        if (o.text !== undefined) return cellText(o.text);
        if (o.result !== undefined) return cellText(o.result);
        return null;
      }
      // strip the literal quotes old Decimal exports left behind ('"100"' -> '100')
      const str = String(v).trim();
      if (str.length >= 2 && str.startsWith('"') && str.endsWith('"')) return str.slice(1, -1).trim() || null;
      return str.length ? str : null;
    };
    const asNumber = (v: unknown, fallback: number): number => {
      const t = cellText(v);
      if (t === null) return fallback;
      const n = Number(t);
      return Number.isFinite(n) ? n : fallback;
    };
    const asOptionalNumber = (v: unknown): number | null => {
      const t = cellText(v);
      if (t === null) return null;
      const n = Number(t);
      return Number.isFinite(n) ? n : null;
    };
    const asBoolean = (v: unknown, fallback: boolean): boolean => {
      if (typeof v === 'boolean') return v;
      const t = cellText(v);
      if (t === null) return fallback;
      const low = t.toLowerCase();
      if (['true', '1', 'yes', 'y'].includes(low)) return true;
      if (['false', '0', 'no', 'n'].includes(low)) return false;
      return fallback;
    };
    const asDate = (v: unknown): Date | null => {
      if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v;
      const t = cellText(v);
      if (t === null) return null;
      const d = new Date(t);
      return Number.isNaN(d.getTime()) ? null : d;
    };
    const asEnum = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T => {
      const t = cellText(v)?.toUpperCase();
      return (t && (allowed as readonly string[]).includes(t) ? t : fallback) as T;
    };
    const GENDERS = ['MALE', 'FEMALE'] as const;
    const MEMBER_STATUSES = ['ACTIVE', 'EXPIRED', 'FROZEN', 'PENDING_PAYMENT', 'SUSPENDED', 'CANCELLED'] as const;
    const PLAN_TYPES = ['SESSION', 'TIME'] as const;

    // Rows we could not write are reported, never silently dropped: after
    // PHASE N1.5 `Member.branchId`/`Member.planId` are NOT NULL and
    // FK-enforced, so a member row whose branch or plan is missing from the
    // backup cannot be restored at all.
    const written = { branches: 0, plans: 0, members: 0 };
    const skipped: { sheet: string; row: number; reason: string }[] = [];

    // PHASE P2 — derive the transaction timeout from the size of this backup
    // instead of hard-coding 60 s: clamp(60 s, rows * 25 ms, 10 min).
    const restoreSheets = [
      'Branches', 'Subscriptions', 'Products', 'ClassTemplates', 'Members',
      'ClassSessions', 'Attendance', 'Sales', 'Expenses',
    ];
    const perSheet = restoreSheets.map((name) => {
      const rowCount = workbook.getWorksheet(name)?.rowCount ?? 0;
      return { name, rows: Math.max(0, rowCount - 1) }; // minus the header row
    });
    const totalSheetRows = perSheet.reduce((sum, sheet) => sum + sheet.rows, 0);
    const restoreTimeout = restoreTimeoutMs(totalSheetRows);
    this.logger.log(
      `restore: ${totalSheetRows} data rows (${perSheet
        .filter((sheet) => sheet.rows > 0)
        .map((sheet) => `${sheet.name}=${sheet.rows}`)
        .join(', ') || 'none'}) -> transaction timeout ${restoreTimeout}ms ` +
        `[clamp(${RESTORE_MIN_TIMEOUT_MS}ms, rows*${RESTORE_MS_PER_ROW}ms, ${RESTORE_MAX_TIMEOUT_MS}ms)]`,
    );

    await this.prisma.withTenant(gymId, async (tx) => {
      // Clear existing gym data (order matters for FK)
      await tx.classBooking.deleteMany({ where: { gymId } });
      await tx.classSession.deleteMany({ where: { gymId } });
      await tx.classTemplate.deleteMany({ where: { gymId } });
      await tx.attendance.deleteMany({ where: { gymId } });
      await tx.saleItem.deleteMany({ where: { sale: { gymId } } });
      await tx.sale.deleteMany({ where: { gymId } });
      await tx.stockMovement.deleteMany({ where: { gymId } });
      await tx.product.deleteMany({ where: { gymId } });
      await tx.expense.deleteMany({ where: { gymId } });
      await tx.member.deleteMany({ where: { gymId } });
      await tx.plan.deleteMany({ where: { gymId } });
      await tx.branch.deleteMany({ where: { gymId } });

      // (the `getRows` reader and the cell-coercion helpers used below are
      // defined just above this transaction, in the function body.)

      // ===================================================================
      // PHASE P2 — queue, then flush in batches.
      //
      // Each row is mapped EXACTLY as it was before (the field-by-field mapping
      // below is unchanged and still reviewable against the previous version);
      // the only difference is that the mapped row goes into an array instead of
      // straight to the database. The arrays are flushed after the last sheet,
      // in the same foreign-key order the restore has always used, with
      // `createMany` in batches of RESTORE_BATCH_SIZE — still inside this ONE
      // `withTenant` transaction, so a failure anywhere rolls all of it back.
      // ===================================================================
      const q = <T>(rows: T[], arg: { data: T }): void => {
        rows.push(arg.data);
      };
      const branchData: Prisma.BranchCreateManyInput[] = [];
      const planData: Prisma.PlanCreateManyInput[] = [];
      const productData: Prisma.ProductCreateManyInput[] = [];
      const templateData: Prisma.ClassTemplateCreateManyInput[] = [];
      const memberData: Prisma.MemberCreateManyInput[] = [];
      const sessionData: Prisma.ClassSessionCreateManyInput[] = [];
      const attendanceData: Prisma.AttendanceCreateManyInput[] = [];
      const saleData: Prisma.SaleCreateManyInput[] = [];
      const expenseData: Prisma.ExpenseCreateManyInput[] = [];

      // 1. Re-import Branches
      // PHASE N2 — this block was a PLACEHOLDER in the shipped code
      // ("// ... (existing code)"): restoreFromExcel purged Branch, Plan and
      // Member rows above and then never re-created them, so a restore deleted
      // the gym's branches, plans and whole member roster. Every later sheet
      // (ClassSessions, Attendance, Sales, Expenses) references branchId/
      // memberId, so the very first Attendance row blew up with
      // `Foreign key constraint violated: Attendance_branchId_fkey` and the
      // 60 s interactive transaction rolled the destruction back — which is the
      // only reason this was not silent data loss in production. For a gym with
      // no Attendance/Sales/Expenses rows the transaction COMMITTED and the
      // members were simply gone. restore-drill.spec.ts is the test that caught
      // it ("Disaster Recovery: Restore Drill").
      const branchRows = getRows('Branches');
      for (const [i, row] of branchRows.entries()) {
        const id = cellText(row.id);
        if (!id) {
          skipped.push({ sheet: 'Branches', row: i + 2, reason: 'no id cell' });
          continue;
        }
        q(branchData, {
          data: {
            id,
            gymId,
            name: cellText(row.name) ?? `Restored branch ${i + 1}`,
            address: cellText(row.address),
            phone: cellText(row.phone),
            manager: cellText(row.manager),
            createdAt: asDate(row.createdAt) ?? new Date(),
          },
        });
        written.branches += 1;
      }

      // 2. Re-import Plans
      // PHASE N2 — was the same placeholder. NOTE the sheet is named
      // 'Subscriptions' but generateExcelBackup writes `data.plans` into it
      // (see the `sheets` array above), so plans come back from that sheet.
      // Member.planId is NOT NULL + FK-enforced since PHASE N1.5, so plans must
      // exist before members are written.
      const planRows = getRows('Subscriptions');
      for (const [i, row] of planRows.entries()) {
        const id = cellText(row.id);
        if (!id) {
          skipped.push({ sheet: 'Subscriptions', row: i + 2, reason: 'no id cell' });
          continue;
        }
        q(planData, {
          data: {
            id,
            gymId,
            name: cellText(row.name) ?? `Restored plan ${i + 1}`,
            type: asEnum<PlanType>(row.type, PLAN_TYPES, PlanType.TIME),
            sessions: asOptionalNumber(row.sessions),
            days: asOptionalNumber(row.days),
            price: asNumber(row.price, 0),
            active: asBoolean(row.active, true),
            invitations: asNumber(row.invitations, 0),
            maxFreezes: asNumber(row.maxFreezes, 0),
            freezeDays: asNumber(row.freezeDays, 0),
            createdAt: asDate(row.createdAt) ?? new Date(),
          },
        });
        written.plans += 1;
      }

      // 2.5 Re-import Products
      const productRows = getRows('Products');
      for (const row of productRows) {
        q(productData, {
          data: {
            id: String(row.id),
            gymId,
            name: String(row.name),
            category: row.category ? String(row.category) : null,
            costPrice: row.costPrice ? Number(row.costPrice) : 0,
            sellingPrice: row.sellingPrice ? Number(row.sellingPrice) : 0,
            qty: row.qty ? Number(row.qty) : 0,
            barcode: row.barcode ? String(row.barcode) : null,
          }
        });
      }

      // 2.6 Re-import ClassTemplates
      const templateRows = getRows('ClassTemplates');
      for (const row of templateRows) {
        q(templateData, {
          data: {
            id: String(row.id),
            gymId,
            name: String(row.name),
            nameAr: row.nameAr ? String(row.nameAr) : null,
            capacity: Number(row.capacity || 20),
            durationMin: Number(row.durationMin || 60),
            color: String(row.color || '#6366F1'),
            coachId: row.coachId ? String(row.coachId) : null,
          }
        });
      }

      // 3. Re-import Members
      // PHASE N2 — was the same placeholder; this is the roster the purge above
      // deleted. `mobile` and `nationalId` are stored deterministically
      // encrypted and `exportTenant` exports the stored CIPHERTEXT, so PHASE P2
      // runs both through reEncryptDeterministic: decrypt with whichever key
      // version can read the backup, re-encrypt with the CURRENT key. That is a
      // re-key, not a double encryption (the deterministic cipher is stable for a
      // value that is already current), and it is what keeps the member search
      // index and the portal lookups working after a key rotation.
      const memberRows = getRows('Members');
      for (const [i, row] of memberRows.entries()) {
        const sheetRow = i + 2;
        const id = cellText(row.id);
        const branchId = cellText(row.branchId);
        const planId = cellText(row.planId);
        const mobile = cellText(row.mobile);
        if (!id || !mobile) {
          skipped.push({ sheet: 'Members', row: sheetRow, reason: !id ? 'no id cell' : 'no mobile cell' });
          continue;
        }
        if (!branchId || !planId) {
          // Not guessable: since PHASE N1.5 both columns are NOT NULL with real
          // foreign keys, and the N1.5 migration deliberately ABORTS rather than
          // invent a plan for a member. Same rule here — report, do not guess.
          skipped.push({
            sheet: 'Members',
            row: sheetRow,
            reason: `missing ${!branchId ? 'branchId' : 'planId'}${!branchId && !planId ? ' and planId' : ''} in the backup`,
          });
          continue;
        }
        q(memberData, {
          data: {
            id,
            gymId,
            branchId,
            planId,
            code: cellText(row.code) ?? `R${Date.now().toString(36)}${i}`,
            name: cellText(row.name) ?? 'Restored member',
            // `mobile` is non-null here (rows without one are skipped above)
            mobile: this.reEncryptDeterministic(mobile) ?? mobile,
            gender: cellText(row.gender) ? asEnum<Gender>(row.gender, GENDERS, Gender.MALE) : null,
            dob: asDate(row.dob),
            nationalId: this.reEncryptDeterministic(cellText(row.nationalId)),
            email: cellText(row.email),
            address: cellText(row.address),
            notes: cellText(row.notes),
            vip: asBoolean(row.vip, false),
            frozen: asBoolean(row.frozen, false),
            startDate: asDate(row.startDate) ?? new Date(),
            expiry: asDate(row.expiry),
            sessionsLeft: asNumber(row.sessionsLeft, 0),
            invitationSlots: asNumber(row.invitationSlots, 5),
            maxFreezes: asNumber(row.maxFreezes, 0),
            freezeDaysLeft: asNumber(row.freezeDaysLeft, 0),
            status: asEnum<MemberStatus>(row.status, MEMBER_STATUSES, MemberStatus.ACTIVE),
            paymentId: cellText(row.paymentId),
            activatedAt: asDate(row.activatedAt),
            visits: asNumber(row.visits, 0),
            lastVisit: asDate(row.lastVisit),
            createdAt: asDate(row.createdAt) ?? new Date(),
          },
        });
        written.members += 1;
      }
      
      // 3.5 Re-import ClassSessions
      const sessionRows = getRows('ClassSessions');
      for (const row of sessionRows) {
        q(sessionData, {
          data: {
            id: String(row.id),
            gymId,
            templateId: String(row.templateId),
            branchId: String(row.branchId),
            startsAt: new Date(row.startsAt as string),
            endsAt: new Date(row.endsAt as string),
            capacity: Number(row.capacity || 20),
            status: (row.status as ClassStatus) || ClassStatus.SCHEDULED,
            coachId: row.coachId ? String(row.coachId) : null,
          }
        });
      }

      // 4. Re-import Attendance
      // ...
      const attendanceRows = getRows('Attendance');
      for (const row of attendanceRows) {
        q(attendanceData, {
          data: {
            gymId,
            memberId: String(row.memberId),
            branchId: String(row.branchId),
            at: row.at ? new Date(row.at as string) : new Date(),
            method: (row.method as CheckinMethod) || CheckinMethod.QR,
          }
        });
      }

      // 5. Re-import Sales
      const saleRows = getRows('Sales');
      for (const row of saleRows) {
        q(saleData, {
          data: {
            id: String(row.id),
            gymId,
            memberId: (row.memberId as string) || null,
            branchId: (row.branchId as string) || null,
            invoiceNo: String(row.invoiceNo),
            total: Number(row.total || 0),
            discount: Number(row.discount || 0),
            method: (row.method as string) || 'CASH',
            status: (row.status as string) || 'COMPLETED',
            createdAt: row.createdAt ? new Date(row.createdAt as string) : new Date(),
          }
        });
      }

      // 6. Re-import Expenses
      const expenseRows = getRows('Expenses');
      for (const row of expenseRows) {
        q(expenseData, {
          data: {
            gymId,
            branchId: (row.branchId as string) || null,
            category: String(row.category),
            description: (row.description as string) || '',
            amount: Number(row.amount || 0),
            createdAt: row.createdAt ? new Date(row.createdAt as string) : new Date(),
          }
        });
      }
      // ===================================================================
      // PHASE P2 — flush every queued sheet, in foreign-key order, batched.
      // Still the SAME transaction: nothing is committed until the last batch
      // succeeds, so an injected failure at any row leaves the gym's previous
      // data exactly as it was.
      // ===================================================================
      written.branches = await this.insertInBatches('Branches', branchData, (chunk) =>
        tx.branch.createMany({ data: chunk }),
      );
      written.plans = await this.insertInBatches('Subscriptions', planData, (chunk) =>
        tx.plan.createMany({ data: chunk }),
      );
      await this.insertInBatches('Products', productData, (chunk) =>
        tx.product.createMany({ data: chunk }),
      );
      await this.insertInBatches('ClassTemplates', templateData, (chunk) =>
        tx.classTemplate.createMany({ data: chunk }),
      );
      written.members = await this.insertInBatches('Members', memberData, (chunk) =>
        tx.member.createMany({ data: chunk }),
      );
      await this.insertInBatches('ClassSessions', sessionData, (chunk) =>
        tx.classSession.createMany({ data: chunk }),
      );
      await this.insertInBatches('Attendance', attendanceData, (chunk) =>
        tx.attendance.createMany({ data: chunk }),
      );
      await this.insertInBatches('Sales', saleData, (chunk) => tx.sale.createMany({ data: chunk }));
      await this.insertInBatches('Expenses', expenseData, (chunk) =>
        tx.expense.createMany({ data: chunk }),
      );
    }, { timeout: restoreTimeout });

    // ===================================================================
    // PHASE N2 — report what was ACTUALLY written, every row that had to be
    // skipped, and — importantly — what an .xlsx restore CANNOT bring back.
    //
    // The purge above deletes ClassBooking, SaleItem and StockMovement, and
    // deleting a Member cascades (ON DELETE CASCADE) to BiometricCredential,
    // BodyMeasurement, Invitation, InvitationSlot, MemberContract, MemberOtp,
    // NotificationSubscription, PtSession and RenewalRequest. The Excel format
    // has no sheet for any of them, so a *successful* restore permanently drops
    // those rows. Before this fix the restore could never succeed (it always
    // died on `Attendance_branchId_fkey` and rolled back), which masked that
    // completely; now that it commits, the operator has to be told. A full
    // physical restore is what `nightlyDump`'s encrypted pg_dump is for.
    // ===================================================================
    const notRestorableFromExcel = [
      'ClassBooking', 'SaleItem', 'StockMovement',
      'BiometricCredential', 'BodyMeasurement', 'Invitation', 'InvitationSlot',
      'MemberContract', 'MemberOtp', 'NotificationSubscription', 'PtSession',
      'RenewalRequest',
    ];
    this.logger.warn(
      `Excel restore for gym ${gymId}: wrote ${written.branches} branch(es), ` +
      `${written.plans} plan(s), ${written.members} member(s); skipped ${skipped.length} row(s)` +
      `${skipped.length ? ' (' + skipped.slice(0, 5).map((k) => `${k.sheet}#${k.row}: ${k.reason}`).join('; ') + (skipped.length > 5 ? '; ...' : '') + ')' : ''}. ` +
      `Not restorable from this format (permanently removed): ${notRestorableFromExcel.join(', ')}.`,
    );
    return {
      success: true,
      restored: preview,
      written,
      skipped,
      notRestorableFromExcel,
    };
  }

  /** Logical per-tenant JSON export (works without DB tooling on host). */
  async exportTenant(gymId: string) {
    const [gym, branches, plans, members, attendance, products, sales, expenses, transactions] =
      await this.prisma.$transaction([
        this.prisma.gym.findUnique({ where: { id: gymId } }),
        this.prisma.branch.findMany({ where: { gymId } }),
        this.prisma.plan.findMany({ where: { gymId } }),
        this.prisma.member.findMany({ where: { gymId } }),
        this.prisma.attendance.findMany({ where: { gymId } }),
        this.prisma.product.findMany({ where: { gymId } }),
        this.prisma.sale.findMany({ where: { gymId }, include: { items: true } }),
        this.prisma.expense.findMany({ where: { gymId } }),
        this.prisma.transaction.findMany({ where: { gymId }, take: 1000 }),
      ]);
    return { version: 1, exportedAt: new Date().toISOString(), gym, branches, plans, members, attendance, products, sales, expenses, transactions };
  }

  /** Full physical pg_dump (super-admin / ops). Runs nightly. */
  // PHASE N1: the one remaining import-time environment read. Nest requires a
  // static cron expression in the decorator, so BACKUP_CRON cannot be resolved
  // lazily without moving the job onto SchedulerRegistry. It is safe because
  // `config/load-env` is the process's first import (see load-env.ts), so `.env`
  // is already in `process.env` when this class is defined — and a cron schedule
  // is not a security control.
  @Cron(process.env.BACKUP_CRON || '0 3 * * *')
  async nightlyDump() {
    return requestContext.run({ requestId: 'cron:nightly-dump' }, async () => {
      const acquired = await this.cronLeader.acquireLock('backups-nightly', 3600000);
      if (!acquired) return;
      try {
        await mkdir(this.dir, { recursive: true });
        const filename = `flexora-${new Date().toISOString().slice(0, 10)}.sql.gz`;
        const file = join(this.dir, filename);
        const encryptedFilename = `${filename}.enc`;
        const encryptedFile = join(this.dir, encryptedFilename);

        // SECURITY FIX: previously used `exec(\`pg_dump "${url}" | gzip > "${file}"\`)`
        // which spawned a shell with the DATABASE_URL (containing the DB password)
        // interpolated into the command string — an RCE vector if the URL ever
        // contained shell metacharacters, and it exposed the password via `ps`.
        //
        // Now we use argument-array child_process.spawn (no shell) and pass the
        // password via the PGPASSWORD environment variable (never on the CLI).
        await this.safePgDump(process.env.DATABASE_URL!, file);
        await this.encryptFile(file, encryptedFile);
        await this.verifyEncryptedBackup(encryptedFile);
        await unlink(file).catch(() => undefined);

        const s = await stat(encryptedFile);
        this.logger.log(`Encrypted backup written: ${encryptedFile} (${s.size} bytes)`);
        await this.uploadToS3(encryptedFile, encryptedFilename, s.size);
        await this.rotate(14);
      } catch (e: unknown) {
        this.logger.error(`Backup failed: ${(e as Error).message}`);
      } finally {
        await this.cronLeader.releaseLock('backups-nightly');
      }
    });
  }

  /**
   * Runs `pg_dump | gzip` using argument arrays (no shell) and streams the
   * output to disk. The DB password is passed via PGPASSWORD, never on the
   * command line or in the process arguments.
   */
  private safePgDump(databaseUrl: string, outFile: string): Promise<void> {
    return new Promise((resolve, reject) => {
      let url: URL;
      try {
        url = new URL(databaseUrl);
      } catch {
        return reject(new Error('Invalid DATABASE_URL'));
      }
      const password = decodeURIComponent(url.password);
      // Strip credentials from the connection string passed to pg_dump.
      url.username = '';
      url.password = '';

      const dump = spawn('pg_dump', [url.toString()], {
        env: { ...process.env, PGPASSWORD: password },
      });
      const gz = spawn('gzip');
      const out = createWriteStream(outFile);

      dump.stdout.pipe(gz.stdin);
      gz.stdout.pipe(out);

      let stderr = '';
      let dumpDone = false;
      let gzipDone = false;
      let outputDone = false;
      let settled = false;
      const fail = (error: Error) => {
        if (settled) return;
        settled = true;
        dump.kill('SIGTERM');
        gz.kill('SIGTERM');
        out.destroy();
        reject(error);
      };
      const maybeResolve = () => {
        if (!settled && dumpDone && gzipDone && outputDone) {
          settled = true;
          resolve();
        }
      };

      dump.stderr.on('data', (d) => { stderr += d.toString(); });
      gz.stderr.on('data', (d) => { stderr += d.toString(); });
      dump.on('close', (code) => {
        if (code !== 0) return fail(new Error(`pg_dump exited ${code}: ${stderr.slice(0, 500)}`));
        dumpDone = true;
        maybeResolve();
      });
      gz.on('close', (code) => {
        if (code !== 0) return fail(new Error(`gzip exited ${code}: ${stderr.slice(0, 500)}`));
        gzipDone = true;
        maybeResolve();
      });
      out.on('finish', () => { outputDone = true; maybeResolve(); });
      dump.on('error', fail);
      gz.on('error', fail);
      out.on('error', fail);
    });
  }

  /**
   * PHASE P2 — insert queued rows with `createMany` in batches.
   *
   * Deliberately NO `skipDuplicates`: a duplicate key during a restore means the
   * backup and the live database disagree (or the sheet contains the same row
   * twice), and silently dropping those rows would hide real data loss behind a
   * green result. The restore runs inside ONE `withTenant` transaction, so the
   * error propagates and rolls the whole restore back, leaving the gym's
   * previous data untouched.
   */
  private async insertInBatches<T>(
    label: string,
    rows: T[],
    insert: (chunk: T[]) => Promise<unknown>,
  ): Promise<number> {
    let written = 0;
    const batches = Math.ceil(rows.length / RESTORE_BATCH_SIZE);
    for (let start = 0; start < rows.length; start += RESTORE_BATCH_SIZE) {
      const chunk = rows.slice(start, start + RESTORE_BATCH_SIZE);
      await insert(chunk);
      written += chunk.length;
    }
    if (rows.length > 0) {
      this.logger.debug(
        `restore: ${label} wrote ${written} rows in ${batches} batch(es) of <=${RESTORE_BATCH_SIZE}`,
      );
    }
    return written;
  }

  /**
   * PHASE P2 — re-encrypt a deterministically encrypted column with the CURRENT
   * keys.
   *
   * An .xlsx backup carries the CIPHERTEXT that was stored when the backup was
   * written (`exportTenant` exports what is in the column). Restoring that
   * ciphertext unchanged into a deployment whose keys have been rotated since
   * leaves rows that no current key can read: the member search index and the
   * portal lookups stop matching, and the data is effectively lost even though
   * the restore reported success.
   *
   * So every such value is decrypted with whichever key version can still read
   * it and re-encrypted with the current key before it is written.
   * `encryptDeterministic` is deterministic, which makes this a re-key and never
   * a double encryption: a value that is already on the current key comes back
   * byte-identical, and plaintext (an old export, or a hand-edited sheet) is
   * encrypted rather than passed through. A value that NO available key can read
   * throws, which rolls the whole restore back — a restore that cannot be read
   * back must not be reported as successful.
   */
  private reEncryptDeterministic(value: string | null): string | null {
    if (!value) return value;
    if (!this.encryption) {
      // No keys configured at all: nothing to re-key with. The value is written
      // exactly as it was exported, which is the pre-P2 behaviour.
      this.logger.warn(
        'restore: no EncryptionService available, deterministically encrypted columns are written as exported',
      );
      return value;
    }
    const plaintext = this.encryption.isEncrypted(value) ? this.encryption.decrypt(value) : value;
    return this.encryption.encryptDeterministic(plaintext);
  }

  private encryptionKey(): Buffer {
    const raw = process.env.BACKUP_ENCRYPTION_KEY;
    if (!raw) throw new Error('BACKUP_ENCRYPTION_KEY is required for encrypted backups');
    const value = raw.trim();
    if (/^[a-f0-9]{64}$/i.test(value)) return Buffer.from(value, 'hex');
    try {
      const decoded = Buffer.from(value, 'base64');
      if (decoded.length === 32) return decoded;
    } catch { /* fall through */ }
    
    // MEDIUM FIX 3 — Use scrypt (PBKDF2 equivalent) instead of SHA-256
    const salt = createHash('sha256')
      .update('flexora-backup-salt-v1')
      .digest();
    return scryptSync(value, salt, 32);
  }

  private async encryptFile(source: string, target: string): Promise<void> {
    const key = this.encryptionKey();
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    await new Promise<void>((resolve, reject) => {
      const input = createReadStream(source);
      const output = createWriteStream(target);
      output.write(Buffer.concat([Buffer.from('FLXBAK1'), iv]));
      input.pipe(cipher).pipe(output);
      output.on('finish', async () => {
        try {
          await writeFile(`${target}.tag`, cipher.getAuthTag());
          resolve();
        } catch (error) { reject(error); }
      });
      input.on('error', reject);
      cipher.on('error', reject);
      output.on('error', reject);
    });
  }

  private async decryptFile(source: string, target: string): Promise<void> {
    const key = this.encryptionKey();
    const header = await readFile(source).then((b) => b.subarray(0, 18));
    if (header.subarray(0, 6).toString() !== 'FLXBAK1') throw new Error('Invalid encrypted backup header');
    const iv = header.subarray(6, 18);
    const tag = await readFile(`${source}.tag`);
    const decipher = createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    await new Promise<void>((resolve, reject) => {
      const input = createReadStream(source, { start: 18 });
      const output = createWriteStream(target);
      input.pipe(decipher).pipe(output);
      output.on('finish', resolve);
      input.on('error', reject);
      decipher.on('error', reject);
      output.on('error', reject);
    });
  }

  private async verifyEncryptedBackup(file: string): Promise<void> {
    const tmp = `${file}.verify`;
    await this.decryptFile(file, tmp);
    const s = await stat(tmp);
    await unlink(tmp).catch(() => undefined);
    if (s.size <= 0) throw new Error('Encrypted backup verification failed');
  }

  async decryptBackupFile(filename: string) {
    if (!/^[a-zA-Z0-9_.-]+$/.test(filename)) throw new Error('Invalid backup filename');
    const encrypted = join(this.dir, filename);
    const target = join(this.dir, filename.replace(/\.enc$/, '.restore.sql.gz'));
    await this.decryptFile(encrypted, target);
    return { ok: true, restoredFile: target };
  }

  async verifyLatestBackup(gymId: string): Promise<{
    ok: boolean;
    backupId: string | null;
    rowCount: number;
    sizeBytes: number;
    verifiedAt: Date;
  }> {
    const latest = await this.prisma.backup.findFirst({
      where: { gymId },
      orderBy: { createdAt: 'desc' },
    });
    if (!latest) {
      return { 
        ok: false, 
        backupId: null, 
        rowCount: 0, 
        sizeBytes: 0, 
        verifiedAt: new Date() 
      };
    }
    // Verify file exists and is readable
    try {
      if (!/^[a-zA-Z0-9_.-]+$/.test(latest.filename)) throw new Error('Invalid backup filename');
      const filePath = join(this.dir, gymId, latest.filename);
      const stats = await stat(filePath);
      return {
        ok: stats.size > 0,
        backupId: latest.id,
        rowCount: (latest as any).rowCount ?? 0,
        sizeBytes: stats.size,
        verifiedAt: new Date(),
      };
    } catch {
      return { 
        ok: false, 
        backupId: latest.id, 
        rowCount: 0, 
        sizeBytes: 0, 
        verifiedAt: new Date() 
      };
    }
  }

  /** Upload a backup file to S3 if credentials are configured. */
  private async uploadToS3(filePath: string, filename: string, sizeBytes: number) {
    const { S3_BUCKET, S3_REGION, S3_ACCESS_KEY, S3_SECRET_KEY } = process.env;
    if (!S3_BUCKET || !S3_ACCESS_KEY || !S3_SECRET_KEY) return; // skip if not configured
    try {
      const s3 = new S3Client({
        region: S3_REGION || 'us-east-1',
        credentials: { accessKeyId: S3_ACCESS_KEY, secretAccessKey: S3_SECRET_KEY },
      });
      const Key = `backups/${filename}`;
      await s3.send(new PutObjectCommand({
        Bucket: S3_BUCKET,
        Key,
        Body: createReadStream(filePath),
        ContentLength: sizeBytes,
        ContentType: 'application/octet-stream',
        Metadata: { encrypted: 'aes-256-gcm' },
      }));
      const tagPath = `${filePath}.tag`;
      const tagStats = await stat(tagPath);
      await s3.send(new PutObjectCommand({
        Bucket: S3_BUCKET,
        Key: `${Key}.tag`,
        Body: createReadStream(tagPath),
        ContentLength: tagStats.size,
        ContentType: 'application/octet-stream',
      }));
      const s3Url = `s3://${S3_BUCKET}/${Key}`;
      this.logger.log(`Backup uploaded to ${s3Url}`);
      // Record S3 backups for every tenant gym (physical dump is global).
      const gyms = await this.prisma.gym.findMany({ select: { id: true } });
      for (const gym of gyms) {
        await this.tenantContext.run(gym.id, () =>
          this.prisma.backup.create({
            data: { gymId: gym.id, filename, sizeBytes, location: 's3' },
          }),
        );
      }
    } catch (e: unknown) {
      // Local copy is still valid — do NOT fail the backup.
      this.logger.error(`S3 upload failed (local copy kept): ${(e as Error).message}`);
    }
  }

  private async rotate(keep: number) {
    try {
      const files = (await readdir(this.dir)).filter((f) => f.endsWith('.sql.gz.enc')).sort().reverse();
      for (const f of files.slice(keep)) {
        await Promise.allSettled([
          unlink(join(this.dir, f)),
          unlink(join(this.dir, `${f}.tag`)),
        ]);
      }
    } catch { /* ignore */ }
  }
}
