/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { EnterpriseService } from './enterprise.service';

@Module({ imports: [PrismaModule], providers: [EnterpriseService], exports: [EnterpriseService] })
export class EnterpriseModule {}
