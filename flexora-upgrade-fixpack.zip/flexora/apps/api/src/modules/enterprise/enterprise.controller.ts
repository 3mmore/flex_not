/**
 * FLEXORA Gym OS — Enterprise controller (Phase 25)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsArray, IsEnum, IsIn, IsOptional, IsString, MinLength } from 'class-validator';
import { CustomRoleScope, SsoProvider } from '@prisma/client';
import { EnterpriseService } from './enterprise.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class AssignRoleDto { @IsString() userId!: string; @IsString() roleId!: string; }
class CreateScimTokenDto { @IsOptional() @IsString() label?: string; }
class LinkSsoDto { @IsString() userId!: string; @IsEnum(SsoProvider) provider!: SsoProvider; @IsString() subject!: string; @IsOptional() @IsString() email?: string; }

class CreateRoleDto {
  @IsString() @MinLength(2) name!: string;
  @IsOptional() @IsString() description?: string;
  @IsArray() @IsString({ each: true }) permissions!: string[];
  @IsOptional() @IsEnum(CustomRoleScope) scope?: CustomRoleScope;
}

@ApiTags('enterprise')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('priority_support')
@Controller('enterprise')
export class EnterpriseController {
  constructor(private readonly svc: EnterpriseService) {}

  @Get('roles') @Roles('OWNER')
  roles(@GymId() g: string) { return this.svc.listCustomRoles(g); }

  @Post('roles') @Roles('OWNER') @Audit('create', 'CustomRole')
  createRole(@GymId() g: string, @Body() dto: CreateRoleDto) { return this.svc.createCustomRole(g, dto); }

  @Patch('roles/:id') @Roles('OWNER') @Audit('update', 'CustomRole')
  updateRole(@GymId() g: string, @Param('id') id: string, @Body() dto: Partial<CreateRoleDto>) { return this.svc.updateCustomRole(g, id, dto); }

  @Delete('roles/:id') @Roles('OWNER') @Audit('delete', 'CustomRole')
  deleteRole(@GymId() g: string, @Param('id') id: string) { return this.svc.deleteCustomRole(g, id); }

  @Post('roles/assign') @Roles('OWNER') @Audit('assign', 'UserRole')
  assignRole(@GymId() g: string, @Body() dto: AssignRoleDto) { return this.svc.assignRole(g, dto.userId, dto.roleId); }

  @Post('scim/tokens') @Roles('OWNER') @Audit('create', 'ScimToken')
  createScimToken(@GymId() g: string, @Body() dto: CreateScimTokenDto) { return this.svc.createScimToken(g, dto.label); }

  @Get('scim/tokens') @Roles('OWNER')
  listScimTokens(@GymId() g: string) { return this.svc.listScimTokens(g); }

  @Post('sso/link') @Roles('OWNER') @Audit('link', 'SsoIdentity')
  linkSso(@GymId() g: string, @Body() dto: LinkSsoDto) { return this.svc.linkSsoIdentity(g, dto.userId, dto.provider, dto.subject, dto.email); }

  @Delete('scim/tokens/:id') @Roles('OWNER') @Audit('revoke', 'ScimToken')
  revokeScimToken(@GymId() g: string, @Param('id') id: string) { return this.svc.revokeScimToken(g, id); }
}
