/**
 * FLEXORA Gym OS — Enterprise (SSO + SCIM) tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { EnterpriseService } from './enterprise.service';
import { PrismaService } from '../../config/prisma.service';

class FakePrisma {
  customRoles: any[] = [];
  userRoles: any[] = [];
  scimTokens: any[] = [];
  users: any[] = [];
  ssoIdentities: any[] = [];

  customRole = {
    create: jest.fn(({ data }: any) => {
      const { gym, ...rest } = data;
      const gymId = gym?.connect?.id;
      const r = { id: 'r-' + Math.random(), gymId, ...rest };
      this.customRoles.push(r);
      return r;
    }),
    findMany: jest.fn(({ where }: any) => {
      if (!where?.OR) return this.customRoles;
      return this.customRoles.filter((r) => where.OR.some((c: any) =>
        (c.gymId && c.gymId === r.gymId) || (c.scope === 'GLOBAL' && r.scope === 'GLOBAL')));
    }),
    updateMany: jest.fn(),
    deleteMany: jest.fn(),
  };
  userRole = {
    create: jest.fn(({ data }: any) => { const r = { id: 'ur-' + Math.random(), ...data }; this.userRoles.push(r); return r; }),
    findMany: jest.fn(({ where, include }: any) => {
      const rs = this.userRoles.filter((r) => r.userId === where?.userId);
      if (include?.customRole) {
        return rs.map((r) => ({ ...r, customRole: this.customRoles.find((c) => c.id === r.customRoleId) }));
      }
      return rs;
    }),
    deleteMany: jest.fn(({ where }: any) => {
      const before = this.userRoles.length;
      this.userRoles = this.userRoles.filter((r) => !(r.userId === where.userId && r.customRoleId === where.customRoleId));
      return { count: before - this.userRoles.length };
    }),
  };
  scimToken = {
    create: jest.fn(({ data }: any) => { const t = { id: 't-' + Math.random(), ...data, token: 'tok-' + Math.random() }; this.scimTokens.push(t); return t; }),
    findFirst: jest.fn(({ where }: any) => this.scimTokens.find((t) => t.tokenHash === where.tokenHash) || null),
    findUnique: jest.fn(({ where }: any) => this.scimTokens.find((t) => t.id === where.id) || null),
    update: jest.fn(({ where, data }: any) => { const t = this.scimTokens.find((x) => x.id === where.id); Object.assign(t, data); return t; }),
    findMany: jest.fn(({ where }: any) => this.scimTokens.filter((t) => t.gymId === where?.gymId)),
    deleteMany: jest.fn(({ where }: any) => {
      const before = this.scimTokens.length;
      this.scimTokens = this.scimTokens.filter((t) => !(t.id === where.id && t.gymId === where.gymId));
      return { count: before - this.scimTokens.length };
    }),
  };
  ssoIdentity = {
    upsert: jest.fn(({ where, create, update }: any) => {
      const ex = this.ssoIdentities.find((i) => i.provider === where.provider_subject.provider && i.subject === where.provider_subject.subject);
      if (ex) { Object.assign(ex, update); return ex; }
      const n = { id: 'si-' + Math.random(), ...create };
      this.ssoIdentities.push(n);
      return n;
    }),
    findUnique: jest.fn(({ where }: any) => this.ssoIdentities.find((i) => i.provider === where.provider_subject.provider && i.subject === where.provider_subject.subject) || null),
  };
  user = {
    findFirst: jest.fn(({ where }: any) => this.users.find((u) => u.email === where.email && u.gymId === where.gymId) || null),
    findUnique: jest.fn(({ where }: any) => this.users.find((u) => u.id === where.id) || null),
    update: jest.fn(({ where, data }: any) => { const u = this.users.find((x) => x.id === where.id); Object.assign(u, data); return u; }),
    create: jest.fn(({ data }: any) => { const u = { id: 'u-' + Math.random(), ...data, active: true }; this.users.push(u); return u; }),
  };
}

describe('EnterpriseService', () => {
  let svc: EnterpriseService;
  let prisma: FakePrisma;
  beforeEach(() => { prisma = new FakePrisma(); svc = new EnterpriseService(prisma as any as PrismaService); });

  it('creates a custom role', async () => {
    const r = await svc.createCustomRole('g1', { name: 'Front Desk', permissions: ['members:read', 'pos:write'] });
    expect(r.name).toBe('Front Desk');
    expect(r.permissions).toEqual(['members:read', 'pos:write']);
  });

  it('lists GYM + GLOBAL roles for a gym', async () => {
    await svc.createCustomRole('g1', { name: 'Local', permissions: [] });
    await svc.createCustomRole(null, { name: 'Platform', permissions: [], scope: 'GLOBAL' });
    await svc.createCustomRole('g2', { name: 'Other', permissions: [] });
    const list = await svc.listCustomRoles('g1');
    expect(list.length).toBe(2); // local + platform
    expect(list.map((r) => r.name).sort()).toEqual(['Local', 'Platform']);
  });
});
