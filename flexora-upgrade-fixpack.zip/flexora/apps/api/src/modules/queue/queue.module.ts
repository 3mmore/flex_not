/**
 * FLEXORA Gym OS — Backend API
 */
import {
  Injectable,
  Logger,
  Module,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import Bull, { Job, Queue as BullQueue } from 'bull';
import { RedisService } from '../../config/redis.service';
import { PrismaService } from '../../config/prisma.service';
import { GymMessagingService } from '../notifications/gym-messaging.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { TenantContextService } from '../../common/services/tenant-context.service';

export type QueueName =
  | 'send-whatsapp'
  | 'send-sms'
  | 'send-campaign'
  | 'generate-report'
  | 'ai-followup'
  | 'process-backup';

export interface QueuePayloads {
  'send-whatsapp': { gymId: string; to: string; templateKey?: string; body: string; notificationId?: string };
  'send-sms': { gymId: string; to: string; body: string; notificationId?: string };
  'send-campaign': { gymId: string; campaignId: string };
  'generate-report': { gymId: string; reportKey: string };
  'ai-followup': { gymId: string; leadId: string };
  'process-backup': { gymId?: string; destination?: 'local' | 's3' | 'gdrive' | 'all' };
}

@Injectable()
export class QueueService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(QueueService.name);
  private readonly queues: Partial<Record<QueueName, BullQueue>> = {};
  private redisAvailable = false;
  private readonly deadLetters: Array<{ name: QueueName; jobId: string; reason: string; failedAt: string }> = [];

  constructor(
    private readonly redis: RedisService,
    private readonly prisma: PrismaService,
    private readonly gymMessaging: GymMessagingService,
    private readonly tenantContext: TenantContextService,
  ) {}

  onModuleInit() {
    const url = process.env.REDIS_URL;
    if (!url) {
      this.logger.warn('REDIS_URL not set — queues will be no-ops');
      return;
    }
    try {
      const names: QueueName[] = ['send-whatsapp', 'send-sms', 'send-campaign', 'generate-report', 'ai-followup', 'process-backup'];
      for (const name of names) {
        const q = new Bull(name, url, {
          defaultJobOptions: {
            attempts: 3,
            backoff: { type: 'exponential', delay: 5000 },
            removeOnComplete: 100,
            removeOnFail: 100,
          },
        });
        q.process((job) => this.process(name, job as Job<any>));
        q.on('failed', (job, err) => this.recordDeadLetter(name, job, err));
        this.queues[name] = q;
      }
      this.redisAvailable = true;
      this.logger.log(`Bull queue system online with ${names.length} processors`);
    } catch (e) {
      this.logger.warn(`Bull init failed, queues will be no-ops: ${(e as Error).message}`);
    }
  }


  private providerMissing(channel: string): Error {
    return new Error(`FAILED_PROVIDER_MISSING:${channel}`);
  }

  private async sendWhatsappMessage(gymId: string, to: string, body: string): Promise<{ providerRef?: string }> {
    const result = await this.gymMessaging.sendWhatsAppText(gymId, to, body);
    if (!result.success) throw new Error(result.error === 'not-configured' ? 'FAILED_PROVIDER_MISSING:WHATSAPP' : `WHATSAPP_SEND_FAILED:${result.error}`);
    return { providerRef: result.provider };
  }

  private async sendSmsMessage(gymId: string, to: string, body: string): Promise<{ providerRef?: string }> {
    const result = await this.gymMessaging.sendSms(gymId, to, body);
    if (!result.success) throw new Error(result.error === 'not-configured' ? 'FAILED_PROVIDER_MISSING:SMS' : `SMS_SEND_FAILED:${result.error}`);
    return { providerRef: result.provider };
  }

  private async sendEmailMessage(to: string, subject: string, body: string): Promise<{ providerRef?: string }> {
    const host = process.env.SMTP_HOST;
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;
    const from = process.env.SMTP_FROM || process.env.MAIL_FROM;
    if (!host || !user || !pass || !from) throw this.providerMissing('EMAIL');
    if (!to.includes('@')) throw new Error('EMAIL_SEND_FAILED:recipient has no email address');
    const nodemailer = await import('nodemailer');
    const transporter = nodemailer.createTransport({
      host,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      auth: { user, pass },
    });
    const info = await transporter.sendMail({ from, to, subject, text: body });
    return { providerRef: info.messageId };
  }

  private async sendByChannel(gymId: string, channel: string, to: string, subject: string, body: string): Promise<{ providerRef?: string }> {
    const normalized = channel.toUpperCase();
    if (normalized === 'WHATSAPP') return this.sendWhatsappMessage(gymId, to, body);
    if (normalized === 'SMS') return this.sendSmsMessage(gymId, to, body);
    if (normalized === 'EMAIL') return this.sendEmailMessage(to, subject, body);
    return { providerRef: `inapp:${Date.now()}` };
  }

  private async process(name: QueueName, job: Job<QueuePayloads[QueueName]>) {
    const gymId = (job.data as { gymId?: string }).gymId ?? null;
    return requestContext.run({ requestId: `job:${name}:${job.id}` }, () =>
      this.tenantContext.run(gymId, async () => {
      switch (name) {
        case 'send-whatsapp':
        case 'send-sms': {
          const data = job.data as QueuePayloads['send-whatsapp'];
          try {
            const result = await this.sendByChannel(data.gymId, name === 'send-whatsapp' ? 'WHATSAPP' : 'SMS', data.to, data.templateKey || 'Flexora notification', data.body);
            if (data.notificationId) {
              await this.prisma.notification.updateMany({
                where: { id: data.notificationId, gymId: data.gymId },
                data: { status: 'SENT', sentAt: new Date() },
              });
            }
            return { delivered: true, providerRef: result.providerRef };
          } catch (error) {
            if (data.notificationId) {
              await this.prisma.notification.updateMany({
                where: { id: data.notificationId, gymId: data.gymId },
                data: { status: 'FAILED' },
              });
            }
            throw error;
          }
        }
        case 'send-campaign': {
          const data = job.data as QueuePayloads['send-campaign'];
          const campaign = await this.prisma.campaign.findFirst({ where: { id: data.campaignId, gymId: data.gymId } });
          if (!campaign) throw new Error('Campaign not found');
          const recipients = await this.prisma.campaignRecipient.findMany({
            where: { gymId: data.gymId, campaignId: data.campaignId, status: 'PENDING' },
            orderBy: { createdAt: 'asc' },
            take: 100,
          });
          if (recipients.length === 0) {
            // Campaign has no recipients; legacy invariant: campaignRecipient.updateMany is intentionally not used for no-recipient completion: complete without sending provider calls.
            await this.prisma.campaign.update({ where: { id: campaign.id }, data: { status: 'COMPLETED' } });
            return { completed: true, recipients: 0 };
          }
          let sent = 0;
          let failed = 0;
          let providerMissing = false;
          for (const recipient of recipients) {
            const message = await this.prisma.campaignMessage.create({
              data: { gymId: data.gymId, campaignId: campaign.id, memberId: recipient.memberId, recipientId: recipient.id, channel: campaign.channel, status: 'PENDING' },
            });
            try {
              const result = await this.sendByChannel(data.gymId, campaign.channel, recipient.to || '', campaign.name, campaign.body);
              await this.prisma.campaignMessage.update({ where: { id: message.id }, data: { status: 'SENT', providerRef: result.providerRef, sentAt: new Date() } });
              await this.prisma.campaignRecipient.update({ where: { id: recipient.id }, data: { status: 'SENT', sentAt: new Date() } });
              sent += 1;
            } catch (error) {
              const messageText = error instanceof Error ? error.message : String(error);
              providerMissing = providerMissing || messageText.startsWith('FAILED_PROVIDER_MISSING');
              await this.prisma.campaignMessage.update({ where: { id: message.id }, data: { status: providerMissing ? 'FAILED_PROVIDER_MISSING' : 'FAILED', errorMessage: messageText.slice(0, 1000) } });
              await this.prisma.campaignRecipient.update({ where: { id: recipient.id }, data: { status: providerMissing ? 'FAILED_PROVIDER_MISSING' : 'FAILED', error: messageText.slice(0, 1000) } });
              failed += 1;
              if (!providerMissing) throw error;
            }
          }
          const remaining = await this.prisma.campaignRecipient.count({ where: { gymId: data.gymId, campaignId: data.campaignId, status: 'PENDING' } });
          await this.prisma.campaign.update({
            where: { id: campaign.id },
            data: { status: providerMissing ? 'FAILED_PROVIDER_MISSING' : remaining > 0 ? 'SENDING' : failed > 0 ? 'FAILED' : 'COMPLETED', statsFailed: { increment: failed }, statsSent: sent > 0 },
          });
          if (remaining > 0 && !providerMissing) await this.enqueue('send-campaign', data, 1000);
          return { completed: remaining === 0 && !providerMissing, sent, failed, remaining };
        }
        case 'generate-report': {
          const data = job.data as QueuePayloads['generate-report'];
          await this.prisma.reportCache.upsert({
            where: { gymId_reportKey: { gymId: data.gymId, reportKey: data.reportKey } },
            update: { data: { queued: true, generatedAt: new Date().toISOString() }, computedAt: new Date(), expiresAt: new Date(Date.now() + 300000) },
            create: { gymId: data.gymId, reportKey: data.reportKey, data: { queued: true }, expiresAt: new Date(Date.now() + 300000) },
          });
          return { cached: true };
        }
        case 'ai-followup': {
          const data = job.data as QueuePayloads['ai-followup'];
          await this.prisma.leadFollowUp.create({ data: { gymId: data.gymId, leadId: data.leadId, type: 'WHATSAPP', message: 'AI follow-up queued' } });
          return { followup: true };
        }
        case 'process-backup':
          return { accepted: true, destination: (job.data as QueuePayloads['process-backup']).destination || 'local' };
      }
    }));
  }

  private recordDeadLetter(name: QueueName, job: Job | undefined, err: Error) {
    this.deadLetters.push({ name, jobId: String(job?.id ?? 'unknown'), reason: err.message, failedAt: new Date().toISOString() });
    this.logger.error(`Queue ${name} job ${job?.id} failed: ${err.message}`);
  }

  async onModuleDestroy() {
    for (const q of Object.values(this.queues)) {
      if (q) await q.close().catch(() => undefined);
    }
  }

  async enqueue<K extends QueueName>(name: K, payload: QueuePayloads[K], delayMs?: number): Promise<{ id: string | null; queued: boolean }> {
    if (!this.redisAvailable || !this.queues[name]) {
      this.logger.warn(`Queue unavailable, dropping job ${name}`);
      return { id: null, queued: false };
    }
    const job = await this.queues[name]!.add(payload, { delay: delayMs });
    return { id: String(job.id), queued: true };
  }

  status() {
    return { redisAvailable: this.redisAvailable, queues: Object.keys(this.queues), deadLetters: this.deadLetters.slice(-100) };
  }
}

@Module({
  imports: [PrismaModule, RedisModule, NotificationsModule],
  providers: [QueueService],
  exports: [QueueService],
})
export class QueueModule {}
