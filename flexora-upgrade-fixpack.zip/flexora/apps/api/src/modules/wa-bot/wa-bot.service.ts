/**
 * FLEXORA Gym OS — WhatsApp AI Member Bot Service
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { Prisma, LeadSource, LeadStatus } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { AiBrainService } from '../ai/ai-brain.service';

type WaGymConfig = {
  id: string;
  name: string;
  phone?: string | null;
  waBotEnabled: boolean;
  waBotPhoneId?: string | null;
  waBotToken?: string | null;
  waBotLanguage: string;
  waBotGreeting?: string | null;
};

type WaMember = Prisma.MemberGetPayload<{
  include: {
    plan: true;
    attendances: {
      include: { branch: { select: { name: true } } };
    };
    ptSessions: {
      include: { coach: { select: { user: { select: { name: true } } } } };
    };
    measurements: {
      select: { weight: true; measuredAt: true };
    };
  }
}>;

interface WaMessageLite {
  direction: string;
  content: string;
}

@Injectable()
export class WaBotService {
  private readonly logger = new Logger(WaBotService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly encryption: EncryptionService,
    private readonly aiBrain: AiBrainService,
  ) {}

  verifyWebhook(mode: string, token: string, challenge: string, gymVerifyToken: string): string | null {
    if (mode === 'subscribe' && token === gymVerifyToken) return challenge;
    return null;
  }

  async processIncoming(gymId: string, from: string, messageText: string, waMessageId: string): Promise<void> {
    try {
      const rateKey = `wa:rate:${gymId}:${from}`;
      const count = await this.redis.client.incr(rateKey);
      if (count === 1) await this.redis.client.expire(rateKey, 3600);
      if (count > 20) {
        await this.sendReply(gymId, from, 'عذراً، تجاوزت الحد المسموح به. حاول بعد ساعة.');
        return;
      }

      const gym = await this.prisma.gym.findUnique({
        where: { id: gymId },
        select: {
          id: true,
          name: true,
          phone: true,
          waBotEnabled: true,
          waBotPhoneId: true,
          waBotToken: true,
          waBotLanguage: true,
          waBotGreeting: true,
        },
      });
      if (!gym?.waBotEnabled || !gym.waBotToken) return;

      const normalizedPhone = this.normalizePhone(from);
      const encryptedFrom = this.encryption.encryptDeterministic(from);
      const encryptedNormalized = this.encryption.encryptDeterministic(normalizedPhone);

      const member = await this.prisma.member.findFirst({
        where: {
          gymId,
          OR: [
            { mobile: from },
            { mobile: normalizedPhone },
            { mobile: encryptedFrom },
            { mobile: encryptedNormalized },
          ],
        },
        include: {
          plan: true,
          attendances: {
            orderBy: { at: 'desc' },
            take: 10,
            include: { branch: { select: { name: true } } },
          },
          ptSessions: {
            where: { status: 'SCHEDULED' },
            orderBy: { scheduledAt: 'asc' },
            take: 3,
            include: { coach: { select: { user: { select: { name: true } } } } },
          },
          measurements: {
            orderBy: { measuredAt: 'desc' },
            take: 1,
            select: { weight: true, measuredAt: true },
          },
        },
      });

      if (!member) {
        await this.handleLeadFlow(gymId, from, messageText, gym);
        return;
      }

      const sessionKey = `wa:session:${gymId}:${from}`;
      const sessionData = await this.redis.get(sessionKey);
      const session = sessionData ? JSON.parse(sessionData) : { level: 'MAIN' };

      const conversation = await this.prisma.waConversation.upsert({
        where: { gymId_memberPhone: { gymId, memberPhone: from } },
        update: { lastMessageAt: new Date(), memberId: member.id },
        create: { gymId, memberPhone: from, memberId: member.id },
      });

      await this.prisma.waMessage.create({
        data: { conversationId: conversation.id, gymId, direction: 'INBOUND', content: messageText, waMessageId },
      });

      // Handle input based on session state
      let reply = '';
      let nextSession = { ...session };

      if (session.level === 'MAIN') {
        if (messageText === '1') {
          reply = await this.handleSubscriptionInfo(member);
        } else if (messageText === '2') {
          const { text, state } = await this.handleClassBookingList(gymId);
          reply = text;
          nextSession = state;
        } else if (messageText === '3') {
          reply = await this.handlePtBalance(member);
        } else if (messageText === '4') {
          reply = await this.handleRenewalRequest(member);
          nextSession = { level: 'RENEW_CONFIRM' };
        } else if (messageText === '5') {
          reply = await this.handleLastReceipt(gymId, member.id);
        } else if (messageText === '0') {
          reply = 'تم إرسال طلبك للاستقبال، وسيتم التواصل معك قريباً. شكراً لصبرك.';
          await this.notifyReception(gymId, member, 'طلب تحدث مع الاستقبال عبر واتساب');
        } else {
          // Fallback to AI if not a menu option
          const historyList = await this.prisma.waMessage.findMany({
            where: { conversationId: conversation.id, gymId },
            orderBy: { createdAt: 'desc' },
            take: 5,
          });
          reply = await this.handleFreeText(gym, member, messageText, historyList.reverse(), gym.waBotLanguage);
        }
      } else if (session.level === 'BOOKING') {
        const choice = parseInt(messageText);
        if (!isNaN(choice) && session.classes && session.classes[choice - 1]) {
          reply = await this.handleClassBookingConfirm(gymId, member.id, session.classes[choice - 1]);
          nextSession = { level: 'MAIN' };
        } else {
          reply = 'اختيار غير صحيح. من فضلك اختر رقم الكلاس أو أرسل 0 للعودة للقائمة الرئيسية.';
          if (messageText === '0') nextSession = { level: 'MAIN' };
        }
      } else if (session.level === 'RENEW_CONFIRM') {
        if (messageText === '1' || messageText.includes('نعم') || messageText.includes('yes')) {
          await this.notifyReception(gymId, member, 'طلب تجديد اشتراك');
          reply = 'تم تسجيل طلب التجديد. سيقوم موظف الاستقبال بمراجعته والتواصل معك.';
        } else {
          reply = 'تم إلغاء طلب التجديد.';
        }
        nextSession = { level: 'MAIN' };
      }

      if (reply === '') {
        reply = this.buildMainMenu(member.name);
      } else if (nextSession.level === 'MAIN' && reply !== this.buildMainMenu(member.name)) {
        reply += '\n\n' + this.buildMainMenu(member.name);
      }

      await this.sendReply(gymId, from, reply, gym);
      await this.redis.set(sessionKey, JSON.stringify(nextSession), 600); // 10 min TTL

      await this.prisma.waMessage.create({
        data: { conversationId: conversation.id, gymId, direction: 'OUTBOUND', content: reply, aiGenerated: true },
      });
    } catch (err) {
      const e = err as Error;
      this.logger.error(`WaBot processIncoming error: ${e.message}`, e.stack);
    }
  }

  private buildMainMenu(name: string): string {
    return `أهلاً يا ${name?.split(' ')[0] || 'بطل'} في جيم Flexora 💪\nمن فضلك اختر من القائمة التالية:\n\n1️⃣ اشتراكي / My Subscription\n2️⃣ حجز كلاس / Book a Class\n3️⃣ رصيد الجلسات / PT Sessions Balance\n4️⃣ تجديد الاشتراك / Renew Subscription\n5️⃣ إيصال آخر دفعة / Last Payment Receipt\n0️⃣ تحدث مع الاستقبال / Talk to Reception`;
  }

  private async handleSubscriptionInfo(member: WaMember): Promise<string> {
    const planName = member.plan?.name || 'غير محدد';
    const start = member.startDate ? new Date(member.startDate).toLocaleDateString('ar-EG') : '—';
    const expiry = member.expiry ? new Date(member.expiry) : null;
    const expiryStr = expiry ? expiry.toLocaleDateString('ar-EG') : '—';
    const daysLeft = expiry ? Math.round((+expiry - Date.now()) / 86400000) : 0;
    
    let text = `بيانات اشتراكك:\n📌 الباقة: ${planName}\n📅 البداية: ${start}\n⏳ الانتهاء: ${expiryStr}\n🗓️ المتبقي: ${daysLeft} يوم.`;
    if (daysLeft >= 0 && daysLeft < 7) {
      text += '\n\n⚠️ اشتراكك ينتهي قريباً، يرجى التجديد لتجنب انقطاع الخدمة.';
    } else if (daysLeft < 0) {
      text += '\n\n❌ اشتراكك منتهي. يرجى التجديد.';
    }
    return text;
  }

  private async handleClassBookingList(gymId: string): Promise<{ text: string; state: { level: string, classes: { id: string, name: string, time: Date }[] } }> {
    const now = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(now.getDate() + 7);

    const classes = await this.prisma.classSession.findMany({
      where: {
        gymId,
        startsAt: { gte: now, lte: nextWeek },
        status: 'SCHEDULED',
      },
      include: { template: true, branch: true },
      orderBy: { startsAt: 'asc' },
      take: 10,
    });

    if (classes.length === 0) {
      return { text: 'لا توجد كلاسات متاحة في الـ 7 أيام القادمة.', state: { level: 'MAIN', classes: [] } };
    }

    let text = 'الكلاسات المتاحة (اختر الرقم للحجز):\n';
    classes.forEach((c, i) => {
      text += `${i + 1}️⃣ ${c.template.name} - ${new Date(c.startsAt).toLocaleString('ar-EG', { weekday: 'long', hour: 'numeric', minute: 'numeric' })}\n`;
    });
    text += '\n0️⃣ للعودة للقائمة الرئيسية';

    return {
      text,
      state: { level: 'BOOKING', classes: classes.map(c => ({ id: c.id, name: c.template.name, time: c.startsAt })) }
    };
  }

  private async handleClassBookingConfirm(gymId: string, memberId: string, classInfo: { id: string, name: string, time: Date }): Promise<string> {
    try {
      // Check capacity
      const session = await this.prisma.classSession.findUnique({
        where: { id: classInfo.id, gymId },
        include: { _count: { select: { bookings: true } } }
      });

      if (!session || session._count.bookings >= session.capacity) {
        return `عذراً، الكلاس ${classInfo.name} مكتمل العدد.`;
      }

      // Check if already booked
      const existing = await this.prisma.classBooking.findFirst({
        where: { sessionId: classInfo.id, memberId, gymId }
      });
      if (existing) return `أنت مسجل بالفعل في كلاس ${classInfo.name}.`;

      await this.prisma.classBooking.create({
        data: { gymId, sessionId: classInfo.id, memberId }
      });

      return `تم حجز كلاس ${classInfo.name} بنجاح ✅\nالموعد: ${new Date(classInfo.time).toLocaleString('ar-EG')}`;
    } catch (e) {
      return 'عذراً، حدث خطأ أثناء الحجز. يرجى المحاولة لاحقاً.';
    }
  }

  private async handlePtBalance(member: WaMember): Promise<string> {
    const balance = member.sessionsLeft ?? 0;
    const nextSession = member.ptSessions[0];

    let text = `رصيد جلسات التدريب الخاص: ${balance} جلسة.`;
    if (nextSession) {
      text += `\n\n🗓️ جلستك القادمة:\nمع الكوتش: ${nextSession.coach.user.name}\nالموعد: ${new Date(nextSession.scheduledAt).toLocaleString('ar-EG')}`;
    }
    return text;
  }

  private async handleRenewalRequest(member: WaMember): Promise<string> {
    const planName = member.plan?.name || 'باقتك الحالية';
    const price = member.plan?.price || 0;
    return `هل ترغب في طلب تجديد باقة (${planName}) بسعر ${price} EGP؟\n\n1️⃣ نعم، أرسل الطلب\n0️⃣ إلغاء`;
  }

  private async handleLastReceipt(gymId: string, memberId: string): Promise<string> {
    const sale = await this.prisma.sale.findFirst({
      where: { gymId, memberId, status: 'COMPLETED' },
      orderBy: { createdAt: 'desc' },
      include: { items: true },
    });

    if (!sale) return 'لم يتم العثور على عمليات دفع سابقة.';

    return `تفاصيل آخر دفعة:\n📄 رقم الفاتورة: ${sale.invoiceNo}\n📅 التاريخ: ${new Date(sale.createdAt).toLocaleDateString('ar-EG')}\n💰 المبلغ: ${sale.total} EGP\n💳 الطريقة: ${sale.paymentMethod}\n🛒 الطلب: ${sale.items.map(i => i.name).join(', ')}`;
  }

  private async notifyReception(gymId: string, member: WaMember, subject: string) {
    // Implement internal notification to RECEPTION role
    // This could be via the RealtimeGateway or by creating a task/notification in DB
    try {
      await this.prisma.notification.create({
        data: {
          gymId,
          channel: 'INAPP',
          to: 'RECEPTION', // Role-based routing handled by frontend/gateway
          subject,
          body: `عضو: ${member.name}\nرقم: ${member.mobile}\nالطلب: ${subject}`,
        }
      });
    } catch (e) {
      this.logger.error('Failed to notify reception', e);
    }
  }

  private async handleFreeText(
    gym: WaGymConfig,
    member: WaMember,
    messageText: string,
    history: WaMessageLite[],
    language: string
  ): Promise<string> {
    const memberContext = {
      name: member.name,
      planName: member.plan?.name || 'غير محدد',
      expiryDate: member.expiry
        ? new Date(member.expiry).toLocaleDateString('ar-EG')
        : 'غير محدد',
      sessionsLeft: member.sessionsLeft ?? null,
      status: member.status || 'UNKNOWN',
    };

    return this.generateAIReply({
      gym,
      member,
      memberContext,
      question: messageText,
      history,
      language,
    });
  }

  private async generateAIReply(ctx: { 
    gym: WaGymConfig; 
    member: WaMember; 
    memberContext: { name: string; planName: string; expiryDate: string; sessionsLeft: number | null; status: string };
    question: string; 
    history: WaMessageLite[]; 
    language: string 
  }): Promise<string> {
    const { gym, member, memberContext, question, history, language } = ctx;
    const isAr = language === 'ar';
    
    const systemPrompt = `أنت مساعد ذكي لجيم ${gym.name}.
معلومات العضو:
- الاسم: ${memberContext.name}
- الخطة: ${memberContext.planName}
- تاريخ الانتهاء: ${memberContext.expiryDate}
- الجلسات المتبقية: ${memberContext.sessionsLeft ?? 'غير محدود'}

أجب باختصار وبنفس لغة العضو. إذا كان السؤال خارج نطاق الجيم، اطلب منه التواصل مع الاستقبال.`;

    if (!member) {
      return isAr
        ? `أهلاً بك في ${gym.name}. لم أتعرف على رقمك، من فضلك تواصل مع الجيم مباشرة لتأكيد بياناتك.`
        : `Welcome to ${gym.name}. I could not identify your number. Please contact the gym directly.`;
    }

    if (!process.env.ANTHROPIC_API_KEY) return this.localFallbackReply(member, question, gym, isAr);

    const prompt = `Recent history:\n${history.map((m: WaMessageLite) => `${m.direction}: ${m.content}`).join('\n')}\n\nQuestion: ${question}\nAnswer briefly.`;

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY!,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: process.env.ANTHROPIC_MODEL || 'claude-3-haiku-20240307',
          max_tokens: 300,
          system: systemPrompt,
          messages: [{ role: 'user', content: prompt }],
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error(`Anthropic ${res.status}`);
      const data = (await res.json()) as { content?: { text: string }[] };
      return String(data?.content?.[0]?.text || this.localFallbackReply(member, question, gym, isAr)).slice(0, 1200);
    } catch (e) {
      this.logger.warn(`AI fallback used: ${(e as Error).message}`);
      return this.localFallbackReply(member, question, gym, isAr);
    }
  }

  private buildMemberContext(member: WaMember, gym: WaGymConfig, isAr: boolean) {
    if (!member) return 'Unknown member';
    const expiry = member.expiry ? new Date(member.expiry).toLocaleDateString(isAr ? 'ar-EG' : 'en-US') : 'N/A';
    const lastVisit = member.lastVisit ? new Date(member.lastVisit).toLocaleString(isAr ? 'ar-EG' : 'en-US') : 'N/A';
    const pt = member.ptSessions?.[0];
    const measurement = member.measurements?.[0];
    return JSON.stringify({
      gym: gym.name,
      member: member.name,
      mobile: member.mobile,
      plan: member.plan?.name,
      planType: member.plan?.type,
      sessionsLeft: member.sessionsLeft,
      expiry,
      visits: member.visits,
      lastVisit,
      nextPt: pt ? { coach: pt.coach?.user?.name, scheduledAt: pt.scheduledAt } : null,
      latestWeight: measurement ? { weight: String(measurement.weight), measuredAt: measurement.measuredAt } : null,
    });
  }

  private localFallbackReply(member: WaMember, question: string, gym: WaGymConfig, isAr: boolean) {
    const q = question.toLowerCase();
    const name = member?.name?.split(' ')[0] || (isAr ? 'يا بطل' : 'there');
    if (q.includes('جلس') || q.includes('session')) return isAr ? `باقيلك ${member.sessionsLeft ?? 0} جلسات يا ${name} 💪` : `You have ${member.sessionsLeft ?? 0} sessions left, ${name}.`;
    if (q.includes('ينتهي') || q.includes('expiry') || q.includes('expire')) {
      const expiry = member.expiry ? new Date(member.expiry).toLocaleDateString(isAr ? 'ar-EG' : 'en-US') : null;
      return expiry ? (isAr ? `اشتراكك بينتهي في ${expiry} يا ${name}` : `Your membership expires on ${expiry}, ${name}.`) : (isAr ? `مش لاقي تاريخ انتهاء واضح يا ${name}.` : `I could not find a clear expiry date, ${name}.`);
    }
    if (q.includes('آخر') || q.includes('last visit')) return isAr ? `آخر زيارة ليك كانت ${member.lastVisit ? new Date(member.lastVisit).toLocaleString('ar-EG') : 'غير مسجلة'} 💪` : `Your last visit was ${member.lastVisit ? new Date(member.lastVisit).toLocaleString('en-US') : 'not recorded'}.`;
    if (q.includes('pt') || q.includes('مدرب') || q.includes('موعد')) {
      const pt = member.ptSessions?.[0];
      const scheduledAt = pt?.scheduledAt;
      return (pt && scheduledAt) ? (isAr ? `موعدك الجاي مع ${pt.coach?.user?.name || 'المدرب'} يوم ${new Date(scheduledAt).toLocaleString('ar-EG')} 🗓️` : `Your next PT session is with ${pt.coach?.user?.name || 'your coach'} on ${new Date(scheduledAt).toLocaleString('en-US')}.`) : (isAr ? `مفيش موعد PT مجدول حالياً يا ${name}.` : `No PT session is currently scheduled, ${name}.`);
    }
    if (q.includes('سعر') || q.includes('price')) return isAr ? `للأسعار، تواصل مع الجيم على ${gym.phone || 'رقم الريسبشن'}` : `For prices, please contact the gym at ${gym.phone || 'reception'}.`;
    return isAr ? `${gym.waBotGreeting || `أهلاً يا ${name} 👋`} أنا هنا بس للإجابة عن أسئلة الجيم 😊` : `${gym.waBotGreeting || `Hi ${name} 👋`} I can help with your gym membership questions.`;
  }

  private normalizePhone(phone: string) {
    let p = String(phone || '').replace(/[^0-9]/g, '');
    if (p.startsWith('00')) p = p.slice(2);
    if (p.startsWith('01')) p = `20${p.slice(1)}`;
    return p;
  }

  async sendReply(gymId: string, to: string, text: string, gymConfig?: WaGymConfig | null) {
    const gym = gymConfig || await this.prisma.gym.findUnique({ where: { id: gymId }, select: { id: true, name: true, phone: true, waBotEnabled: true, waBotPhoneId: true, waBotToken: true, waBotLanguage: true, waBotGreeting: true } });
    if (!gym?.waBotToken || !gym.waBotPhoneId) return;
    const token = (() => { try { return this.encryption.decrypt(gym.waBotToken!); } catch { return gym.waBotToken!; } })();
    await fetch(`https://graph.facebook.com/v19.0/${gym.waBotPhoneId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body: text.slice(0, 1200) } }),
      signal: AbortSignal.timeout(10000),
    }).catch((e) => this.logger.warn(`WhatsApp send failed: ${(e as Error).message}`));
  }


  async getVerifyToken(gymId: string) {
    const config = await this.prisma.gymMessagingConfig.findUnique({ where: { gymId } });
    if (config?.whatsappVerifyToken) return config.whatsappVerifyToken;
    const token = randomBytes(16).toString('hex');
    await this.prisma.gymMessagingConfig.upsert({
      where: { gymId },
      update: { whatsappVerifyToken: token },
      create: { gymId, whatsappVerifyToken: token },
    });
    return token;
  }

  async getBotSettings(gymId: string) {
    const gym = await this.prisma.gym.findUnique({
      where: { id: gymId },
      select: { waBotEnabled: true, waBotPhoneId: true, waBotGreeting: true, waBotLanguage: true },
    });
    return { ...gym, waBotToken: gym ? '••••••' : undefined };
  }

  async updateBotSettings(gymId: string, dto: { enabled?: boolean; phoneId?: string; token?: string; greeting?: string; language?: string }) {
    const data: Prisma.GymUpdateInput = {};
    if (dto.enabled !== undefined) data.waBotEnabled = dto.enabled;
    if (dto.phoneId !== undefined) data.waBotPhoneId = dto.phoneId;
    if (dto.token) data.waBotToken = this.encryption.encrypt(dto.token);
    if (dto.greeting !== undefined) data.waBotGreeting = dto.greeting;
    if (dto.language) data.waBotLanguage = dto.language;
    await this.prisma.gym.update({ where: { id: gymId }, data });
    if (dto.phoneId || dto.token) {
      const existing = await this.prisma.gymMessagingConfig.findUnique({ where: { gymId } });
      await this.prisma.gymMessagingConfig.upsert({
        where: { gymId },
        update: {
          whatsappPhoneId: dto.phoneId ?? existing?.whatsappPhoneId,
          whatsappToken: dto.token ? this.encryption.encrypt(dto.token) : existing?.whatsappToken,
          whatsappEnabled: dto.enabled ?? existing?.whatsappEnabled ?? true,
          whatsappVerifyToken: existing?.whatsappVerifyToken || randomBytes(16).toString('hex'),
        },
        create: {
          gymId,
          whatsappPhoneId: dto.phoneId,
          whatsappToken: dto.token ? this.encryption.encrypt(dto.token) : undefined,
          whatsappEnabled: dto.enabled ?? true,
          whatsappVerifyToken: randomBytes(16).toString('hex'),
        },
      });
    }
    await this.redis.client.del(`gym:bot:${gymId}`);
    return { ok: true };
  }

  async getBotStats(gymId: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [totalConversations, totalMessages, todayMessages, membersContacted, recentConversations] = await Promise.all([
      this.prisma.waConversation.count({ where: { gymId } }),
      this.prisma.waMessage.count({ where: { gymId } }),
      this.prisma.waMessage.count({ where: { gymId, direction: 'INBOUND', createdAt: { gte: today } } }),
      this.prisma.waConversation.count({ where: { gymId, memberId: { not: null } } }),
      this.prisma.waConversation.findMany({
        where: { gymId },
        orderBy: { lastMessageAt: 'desc' },
        take: 10,
        include: { member: { select: { name: true } }, messages: { orderBy: { createdAt: 'desc' }, take: 20 } },
      }),
    ]);
    return { totalConversations, totalMessages, todayMessages, membersContacted, responseRate: 'فوري ⚡', recentConversations };
  }

  private async handleLeadFlow(gymId: string, from: string, messageText: string, gym: WaGymConfig) {
    const sessionKey = `wa:lead:${gymId}:${from}`;
    const sessionData = await this.redis.get(sessionKey);
    const session = sessionData ? JSON.parse(sessionData) : { step: 'WELCOME' };

    let reply = '';
    let nextStep = session.step;
    const data = { ...session.data };

    if (session.step === 'WELCOME') {
      reply = `مرحباً! 👋 أهلاً بك في ${gym.name}\nيبدو أنك لست مسجلاً معنا بعد.\nهل تريد الانضمام؟ أرسل:\n1️⃣ نعم، أريد التسجيل\n2️⃣ أريد معرفة المزيد والأسعار\n3️⃣ لا شكراً`;
      nextStep = 'JOIN_OR_INFO';
    } else if (session.step === 'JOIN_OR_INFO') {
      if (messageText === '1' || messageText === '2') {
        reply = 'ما اسمك الكريم؟';
        nextStep = 'COLLECT_NAME';
      } else {
        reply = 'شكراً لتواصلك معنا. نتمنى لك يوماً سعيداً!';
        await this.redis.del(sessionKey);
        await this.sendReply(gymId, from, reply, gym);
        return;
      }
    } else if (session.step === 'COLLECT_NAME') {
      data.name = messageText;
      reply = `شكراً ${data.name}! ما هو هدفك؟\n1️⃣ تخسيس وتنحيف\n2️⃣ بناء العضلات\n3️⃣ لياقة عامة\n4️⃣ كروس فيت\n5️⃣ أخرى`;
      nextStep = 'COLLECT_GOAL';
    } else if (session.step === 'COLLECT_GOAL') {
      const goals: Record<string, string> = { '1': 'تخسيس وتنحيف', '2': 'بناء العضلات', '3': 'لياقة عامة', '4': 'كروس فيت', '5': 'أخرى' };
      data.goal = goals[messageText] || messageText;
      
      const plans = await this.prisma.plan.findMany({ where: { gymId, active: true }, take: 5 });
      const recommendation = await this.aiBrain.chat(
        `Member goal: ${data.goal}\nAvailable plans: ${JSON.stringify(plans)}\nRecommend the best 2 plans for this goal. Reply in Arabic, mention price and benefits. Be persuasive but honest. Max 200 chars.`,
        gymId, 'sales_coach'
      );
      
      reply = `${recommendation}\n\nهل تريد تجربة مجانية لمدة يوم؟\n1️⃣ نعم، احجز لي تجربة مجانية\n2️⃣ أريد الاشتراك مباشرة`;
      nextStep = 'TRIAL_OR_JOIN';
    } else if (session.step === 'TRIAL_OR_JOIN') {
      if (messageText === '1') {
        // Create Lead in CRM
        await this.prisma.lead.create({
          data: {
            gymId,
            name: data.name,
            mobile: from,
            source: LeadSource.WHATSAPP,
            status: LeadStatus.TRIAL_REQUESTED,
            notes: `الهدف: ${data.goal} | يريد تجربة مجانية`,
          }
        });
        
        // Notify Reception
        await this.notifyReception(gymId, { name: data.name, mobile: from } as unknown as WaMember, 'طلب تجربة مجانية عبر واتساب');
        
        reply = 'تم! سيتواصل معك أحد موظفينا خلال ساعة لتحديد موعد تجربتك المجانية 🎉';
        await this.redis.del(sessionKey);
      } else if (messageText === '2') {
        reply = 'ممتاز! يمكنك زيارتنا في الاستقبال لإتمام الاشتراك، أو إرسال 0 للتحدث مع أحد موظفينا الآن.';
        nextStep = 'MAIN'; // Fallback to normal bot menu
      } else {
        reply = 'اختيار غير صحيح. يرجى اختيار 1 أو 2.';
      }
    }

    await this.sendReply(gymId, from, reply, gym);
    if (nextStep !== 'MAIN') {
      await this.redis.set(sessionKey, JSON.stringify({ step: nextStep, data }), 86400);
    }
  }

  async sendExpiryAlert(gymId: string, member: Prisma.MemberGetPayload<{}>, daysLeft: number) {
    const gym = await this.prisma.gym.findUnique({ where: { id: gymId }, select: { name: true } });
    const name = member.name.split(' ')[0];
    const message = `مرحباً ${name} 👋\nاشتراكك في ${gym?.name || 'الجيم'} ينتهي بعد ${daysLeft} أيام.\nلتجديد اشتراكك، أرسل 4️⃣ الآن أو تواصل مع الاستقبال.\nنتمنى لك تمريناً موفقاً 💪`;
    await this.sendReply(gymId, member.mobile, message);
  }

  async sendBirthdayMessage(gymId: string, member: Prisma.MemberGetPayload<{}>) {
    const name = member.name.split(' ')[0];
    const message = `عيد ميلاد سعيد ${name} 🎂🎉\nكل عام وأنت بصحة وعافية!\nهدية FLEXORA لك: خصم 20% على تجديد اشتراكك هذا الشهر.\nتواصل مع الاستقبال للاستفادة من العرض 🎁`;
    await this.sendReply(gymId, member.mobile, message);
  }

  async sendPtSessionSummary(gymId: string, member: Prisma.MemberGetPayload<{}>, sessionData: { coachName: string; exercises: number; nextDate: string | null }) {
    const name = member.name.split(' ')[0];
    const completedCount = await this.prisma.ptSession.count({ where: { memberId: member.id, gymId, status: 'COMPLETED' } });
    const message = `أحسنت ${name}! 💪 تم تسجيل جلستك مع ${sessionData.coachName}.\nالجلسات المكتملة: ${completedCount}\n${sessionData.nextDate ? 'جلستك القادمة: ' + sessionData.nextDate : ''}\nاستمر في التقدم! 🏋️`;
    await this.sendReply(gymId, member.mobile, message);
  }

  async sendTrialCompletedMessage(gymId: string, lead: Prisma.LeadGetPayload<{}>) {
    const gym = await this.prisma.gym.findUnique({
      where: { id: gymId },
      select: { name: true }
    });
    const gymName = gym?.name || 'الجيم';
    const message = `أتمنى أن تكون قد استمتعت بتجربتك في ${gymName}! 🌟

للانضمام بسعر خاص اليوم فقط:

1️⃣ اشترك الآن
2️⃣ تحدث مع الاستقبال`;

    await this.sendReply(gymId, lead.mobile, message);
  }

  async testBot(gymId: string, phone: string, message: string) {
    const gym = await this.prisma.gym.findUnique({ where: { id: gymId }, select: { id: true, name: true, phone: true, waBotEnabled: true, waBotPhoneId: true, waBotToken: true, waBotLanguage: true, waBotGreeting: true } });
    if (!gym) return { reply: 'Gym not found' };
    const normalizedPhone = this.normalizePhone(phone);
    const encPhone = this.encryption.encryptDeterministic(normalizedPhone);
    const member = await this.prisma.member.findFirst({
      where: {
        gymId,
        OR: [
          { mobile: phone },
          { mobile: normalizedPhone },
          { mobile: `+${normalizedPhone}` },
          { mobile: encPhone },
        ]
      },
      include: {
        plan: true,
        attendances: { orderBy: { at: 'desc' }, take: 10, include: { branch: { select: { name: true } } } },
        ptSessions: { where: { status: 'SCHEDULED' }, orderBy: { scheduledAt: 'asc' }, take: 3, include: { coach: { select: { user: { select: { name: true } } } } } },
        measurements: { orderBy: { measuredAt: 'desc' }, take: 1, select: { weight: true, measuredAt: true } }
      }
    });
    
    if (!member) return { reply: 'Member not found' };

    const memberContext = {
      name: member.name,
      planName: member.plan?.name || 'غير محدد',
      expiryDate: member.expiry
        ? new Date(member.expiry).toLocaleDateString('ar-EG')
        : 'غير محدد',
      sessionsLeft: member.sessionsLeft ?? null,
      status: member.status || 'UNKNOWN',
    };

    return { reply: await this.generateAIReply({ gym, member: member as WaMember, memberContext, question: message, history: [], language: gym.waBotLanguage || process.env.WA_BOT_DEFAULT_LANGUAGE || 'ar' }) };
  }
}
