/**
 * FLEXORA Gym OS — WhatsApp Bot Controller
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body,
  Controller,
  Get,
  HttpCode,
  Logger,
  Param,
  Patch,
  Post,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { Response, Request } from 'express';
import { Throttle } from '@nestjs/throttler';
import { createHmac, timingSafeEqual } from 'crypto';
import { WaBotService } from './wa-bot.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { IntegrationBrandingGuard } from '../../common/guards/integration-branding.guard';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { TenantContextService } from '../../common/services/tenant-context.service';

@Controller('wa-bot')
export class WaBotController {
  private readonly logger = new Logger(WaBotController.name);
  constructor(
    private readonly svc: WaBotService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private verifyWhatsAppSignature(rawBody: Buffer | string | undefined, signature?: string): boolean {
    const secret = process.env.WHATSAPP_APP_SECRET;
    if (!secret) return false;
    if (!signature || !rawBody) return false;
    const expected = 'sha256=' + createHmac('sha256', secret).update(rawBody).digest('hex');
    const a = Buffer.from(expected);
    const b = Buffer.from(signature);
    return a.length === b.length && timingSafeEqual(a, b);
  }

  @Public()
  @Get('webhook/:gymId')
  async verifyWebhook(
    @Param('gymId') gymId: string,
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: Response,
  ) {
    const gymVerifyToken = await this.tenantContext.run(gymId, () => this.svc.getVerifyToken(gymId));
    const result = this.svc.verifyWebhook(mode, token, challenge, gymVerifyToken);
    if (result) return res.status(200).send(result);
    return res.status(403).send('Forbidden');
  }

  @Public()
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @Post('webhook/:gymId')
  @HttpCode(200)
  async receiveWebhook(@Param('gymId') gymId: string, @Body() body: Record<string, any>, @Req() req: Request & { rawBody?: Buffer }) {
    if (!this.verifyWhatsAppSignature(req.rawBody, req.headers['x-hub-signature-256'] as string | undefined)) return { status: 'forbidden' };
    return this.tenantContext.run(gymId, async () => {
    try {
      const entry = (body?.entry as Record<string, any>[])?.[0];
      const change = (entry?.changes as Record<string, any>[])?.[0];
      const message = change?.value?.messages?.[0];
      if (!message) return { status: 'no_message' };
      const phoneId = String(change?.value?.metadata?.phone_number_id || '');
      const settings = await this.svc.getBotSettings(gymId);
      if (!phoneId || settings?.waBotPhoneId !== phoneId) {
        this.logger.warn(`Webhook phone id does not belong to gym ${gymId}`);
        return { status: 'forbidden' };
      }
      if (message.type !== 'text') {
        await this.svc.sendReply(gymId, message.from, 'عذراً، أنا بفهم النصوص فقط. اكتب سؤالك وأنا هساعدك 😊');
        return { status: 'non_text' };
      }
      const from = message.from;
      const text = message.text?.body ?? '';
      const waMessageId = message.id;
      setImmediate(() => {
        this.svc.processIncoming(gymId, from, text, waMessageId).catch((err) =>
          this.logger.error(`Webhook processing error: ${err.message}`),
        );
      });
      return { status: 'received' };
    } catch (err) {
      this.logger.error(`Webhook parse error: ${(err as Error).message}`);
      return { status: 'error' };
    }
    });
  }

  @Get('settings')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  getSettings(@GymId() gymId: string) {
    return this.svc.getBotSettings(gymId);
  }

  @Patch('settings')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard, IntegrationBrandingGuard)
  @Permissions('settings.manage')
  updateSettings(
    @GymId() gymId: string,
    @Body() dto: { enabled?: boolean; phoneId?: string; token?: string; greeting?: string; language?: string },
  ) {
    return this.svc.updateBotSettings(gymId, dto);
  }

  @Get('stats')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  getStats(@GymId() gymId: string) {
    return this.svc.getBotStats(gymId);
  }

  @Post('test')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard, IntegrationBrandingGuard)
  @Permissions('settings.manage')
  testBot(@GymId() gymId: string, @Body() dto: { phone: string; message: string }) {
    return this.svc.testBot(gymId, dto.phone, dto.message);
  }

  @Get('verify-token/:gymId')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  async getVerifyToken(@Param('gymId') gymId: string) {
    return { verifyToken: await this.svc.getVerifyToken(gymId) };
  }
}
