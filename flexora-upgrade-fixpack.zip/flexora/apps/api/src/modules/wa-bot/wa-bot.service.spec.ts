import { Test, TestingModule } from '@nestjs/testing';
import { WaBotService } from './wa-bot.service';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { AiBrainService } from '../ai/ai-brain.service';

describe('WaBotService', () => {
  let service: WaBotService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        WaBotService,
        { provide: PrismaService, useValue: {} },
        { provide: RedisService, useValue: { client: { incr: jest.fn(), expire: jest.fn() }, get: jest.fn(), set: jest.fn() } },
        { provide: EncryptionService, useValue: { encryptDeterministic: jest.fn(), decrypt: jest.fn(), isEncrypted: jest.fn() } },
        { provide: AiBrainService, useValue: { chat: jest.fn() } },
      ],
    }).compile();

    service = module.get<WaBotService>(WaBotService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
