/**
 * FLEXORA Gym OS — WhatsApp AI Member Bot Module
 * © 2024 Ammar Allam. All rights reserved.
 * WhatsApp Support: FLEXORA support
 */
import { Module } from "@nestjs/common";
import { WaBotService } from "./wa-bot.service";
import { WaBotController } from "./wa-bot.controller";
import { SecurityModule } from "../../common/security/security.module";
import { AiModule } from "../ai/ai.module";

// PRE-EXISTING BUG FIX (out of scope for items 1-13, fixed only because it
// blocked Item 12's requirement that the full test suite — all 32 spec
// files — actually pass in CI): WaBotService's constructor takes
// AiBrainService (exported by AiModule), but this module never imported
// AiModule. Nest can resolve that fine when a spec mocks WaBotService's
// dependencies directly (all the *.service.spec.ts unit tests do this,
// which is why they always passed), but booting the real, full AppModule
// (as flexora-critical-flows.spec.ts and restore-drill.spec.ts both do)
// failed with "Nest can't resolve dependencies of the WaBotService
// (PrismaService, RedisService, EncryptionService, ?)." This was broken
// identically before any of items 1-13 were touched — see
// flexora_evidence/00-BASELINE-NOTES.md. No other changes were made to
// this module or to AiModule.
@Module({
  imports: [SecurityModule, AiModule],
  controllers: [WaBotController],
  providers: [WaBotService],
  exports: [WaBotService],
})
export class WaBotModule {}
