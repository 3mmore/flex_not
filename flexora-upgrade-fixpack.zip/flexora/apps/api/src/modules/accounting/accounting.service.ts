/**
 * FLEXORA Gym OS — Accounting system (Phase 18)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { AccountType, Prisma } from '@prisma/client';

@Injectable()
export class AccountingService {
  private readonly logger = new Logger(AccountingService.name);
  constructor(private readonly prisma: PrismaService) {}

  async summary(gymId: string) {
    const [income, expense, entries] = await this.prisma.$transaction([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: AccountType.EXPENSE }, _sum: { amount: true } }),
      this.prisma.journalEntry.count({ where: { gymId } }),
    ]);
    const revenue = Number(income._sum.amount || 0);
    const expenses = Number(expense._sum.amount || 0);
    return { revenue, expenses, netProfit: revenue - expenses, journalEntries: entries };
  }

  entries(gymId: string) {
    return this.listJournals(gymId);
  }

  journal(gymId: string, dto: {
    date?: Date; memo?: string; reference?: string;
    lines: Array<{ accountId: string; debit?: number; credit?: number; memo?: string }>;
  }, userId: string) {
    return this.postJournal(gymId, dto, userId);
  }

  listAccounts(gymId: string, skip = 0, take = 500) {
    return this.prisma.chartOfAccount.findMany({ where: { gymId }, orderBy: { code: 'asc' }, skip, take });
  }

  async createAccount(gymId: string, dto: { code: string; name: string; type: AccountType; parentId?: string }) {
    if (dto.parentId) {
      const parent = await this.prisma.chartOfAccount.findFirst({ where: { id: dto.parentId, gymId } });
      if (!parent) throw new BadRequestException('Invalid parent account');
    }
    return this.prisma.chartOfAccount.create({ data: { gymId, ...dto } });
  }

  async seedDefaults(gymId: string) {
    const defaults: Array<{ code: string; name: string; type: AccountType }> = [
      { code: '1000', name: 'Cash', type: AccountType.ASSET },
      { code: '1100', name: 'Bank', type: AccountType.ASSET },
      { code: '1200', name: 'Accounts Receivable', type: AccountType.ASSET },
      { code: '1300', name: 'Inventory', type: AccountType.ASSET },
      { code: '2000', name: 'Accounts Payable', type: AccountType.LIABILITY },
      { code: '3000', name: 'Owner Equity', type: AccountType.EQUITY },
      { code: '4000', name: 'Membership Revenue', type: AccountType.REVENUE },
      { code: '4100', name: 'PT Revenue', type: AccountType.REVENUE },
      { code: '4200', name: 'POS Revenue', type: AccountType.REVENUE },
      { code: '5000', name: 'Rent Expense', type: AccountType.EXPENSE },
      { code: '5100', name: 'Salaries Expense', type: AccountType.EXPENSE },
      { code: '5200', name: 'Utilities Expense', type: AccountType.EXPENSE },
      { code: '5300', name: 'Supplies Expense', type: AccountType.EXPENSE },
    ];
    for (const a of defaults) {
      await this.prisma.chartOfAccount.upsert({
        where: { gymId_code: { gymId, code: a.code } },
        update: {},
        create: { gymId, ...a },
      });
    }
    return this.listAccounts(gymId);
  }

  async postJournal(gymId: string, dto: {
    date?: Date; memo?: string; reference?: string;
    lines: Array<{ accountId: string; debit?: number; credit?: number; memo?: string }>;
  }, createdBy: string) {
    if (!dto.lines || dto.lines.length < 2) throw new BadRequestException('A journal needs at least 2 lines');
    const totalDebit = dto.lines.reduce((s, l) => s + (l.debit || 0), 0);
    const totalCredit = dto.lines.reduce((s, l) => s + (l.credit || 0), 0);
    if (Math.abs(totalDebit - totalCredit) > 0.01) {
      throw new BadRequestException(`Unbalanced: debits=${totalDebit} credits=${totalCredit}`);
    }
    const accountIds = Array.from(new Set(dto.lines.map(l => l.accountId)));
    const validAccounts = await this.prisma.chartOfAccount.count({ where: { id: { in: accountIds }, gymId } });
    if (validAccounts !== accountIds.length) throw new BadRequestException('Invalid account in journal lines');
    const entryNo = `JE-${Date.now().toString(36).toUpperCase()}`;
    return this.prisma.journalEntry.create({
      data: {
        gymId, entryNo,
        date: dto.date || new Date(),
        memo: dto.memo, reference: dto.reference,
        postedAt: new Date(), createdBy,
        lines: { create: dto.lines.map((l) => ({ accountId: l.accountId, debit: l.debit || 0, credit: l.credit || 0, memo: l.memo })) },
      },
      include: { lines: true },
    });
  }

  listJournals(gymId: string, opts: { from?: Date; to?: Date; skip?: number; take?: number } = {}) {
    return this.prisma.journalEntry.findMany({
      where: {
        gymId,
        ...(opts.from || opts.to ? { date: { ...(opts.from ? { gte: opts.from } : {}), ...(opts.to ? { lte: opts.to } : {}) } } : {}),
      },
      orderBy: { date: 'desc' },
      take: opts.take || 200,
      skip: opts.skip || 0,
      include: { lines: { include: { account: true } } },
    });
  }

  async profitAndLoss(gymId: string, from: Date, to: Date) {
    const accounts = await this.prisma.chartOfAccount.findMany({ where: { gymId, type: { in: ['REVENUE', 'EXPENSE'] } } });
    const map = new Map<string, { code: string; name: string; type: string; balance: number }>();
    for (const a of accounts) map.set(a.id, { code: a.code, name: a.name, type: a.type, balance: 0 });

    // FIX (pagination sweep): fetch journal lines in batches of 2000 using
    // cursor pagination to avoid unbounded memory on large date ranges.
    const BATCH = 2000;
    let cursor: string | null | undefined;
    while (cursor !== null) {
      const batch = await this.prisma.journalLine.findMany({
        where: { accountId: { in: accounts.map((a) => a.id) }, journalEntry: { gymId, date: { gte: from, lte: to } } },
        orderBy: { id: 'asc' },
        take: BATCH,
        ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      });
      for (const l of batch) {
        const e = map.get(l.accountId); if (!e) continue;
        if (e.type === 'REVENUE') e.balance += Number(l.credit) - Number(l.debit);
        else e.balance += Number(l.debit) - Number(l.credit);
      }
      cursor = batch.length < BATCH ? null : batch[batch.length - 1].id;
    }

    const revenues = Array.from(map.values()).filter((e) => e.type === 'REVENUE');
    const expenses = Array.from(map.values()).filter((e) => e.type === 'EXPENSE');
    const totalRevenue = revenues.reduce((s, e) => s + e.balance, 0);
    const totalExpense = expenses.reduce((s, e) => s + e.balance, 0);
    return { from, to, revenues, expenses, totalRevenue, totalExpense, netIncome: totalRevenue - totalExpense };
  }

  async balanceSheet(gymId: string, asOf: Date) {
    const accounts = await this.prisma.chartOfAccount.findMany({ where: { gymId, type: { in: ['ASSET', 'LIABILITY', 'EQUITY'] } } });
    const map = new Map<string, { code: string; name: string; type: string; balance: number }>();
    for (const a of accounts) map.set(a.id, { code: a.code, name: a.name, type: a.type, balance: 0 });

    // FIX (pagination sweep): fetch journal lines in batches of 2000 using
    // cursor pagination to avoid unbounded memory on large date ranges.
    const BATCH = 2000;
    let cursor: string | null | undefined;
    while (cursor !== null) {
      const batch = await this.prisma.journalLine.findMany({
        where: { accountId: { in: accounts.map((a) => a.id) }, journalEntry: { gymId, date: { lte: asOf } } },
        orderBy: { id: 'asc' },
        take: BATCH,
        ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      });
      for (const l of batch) {
        const e = map.get(l.accountId); if (!e) continue;
        if (e.type === 'ASSET') e.balance += Number(l.debit) - Number(l.credit);
        else e.balance += Number(l.credit) - Number(l.debit);
      }
      cursor = batch.length < BATCH ? null : batch[batch.length - 1].id;
    }

    const assets = Array.from(map.values()).filter((e) => e.type === 'ASSET');
    const liabilities = Array.from(map.values()).filter((e) => e.type === 'LIABILITY');
    const equity = Array.from(map.values()).filter((e) => e.type === 'EQUITY');
    const totalAssets = assets.reduce((s, e) => s + e.balance, 0);
    const totalLiabilities = liabilities.reduce((s, e) => s + e.balance, 0);
    const totalEquity = equity.reduce((s, e) => s + e.balance, 0);
    return { asOf, assets, liabilities, equity, totalAssets, totalLiabilities, totalEquity, balanced: Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01 };
  }

  async cashFlow(gymId: string, from: Date, to: Date) {
    const cashAccounts = await this.prisma.chartOfAccount.findMany({
      where: { gymId, type: AccountType.ASSET, OR: [{ code: { startsWith: '10' } }, { name: { contains: 'cash' } }, { name: { contains: 'Cash' } }] },
    });
    const cashIds = cashAccounts.map((a) => a.id);
    const inflows = await this.prisma.journalLine.aggregate({ where: { accountId: { in: cashIds }, journalEntry: { gymId, date: { gte: from, lte: to } } }, _sum: { debit: true } });
    const outflows = await this.prisma.journalLine.aggregate({ where: { accountId: { in: cashIds }, journalEntry: { gymId, date: { gte: from, lte: to } } }, _sum: { credit: true } });
    return {
      from, to,
      cashAccounts: cashAccounts.map((a) => a.name),
      totalInflows: Number(inflows._sum.debit || 0),
      totalOutflows: Number(outflows._sum.credit || 0),
      netCashFlow: Number(inflows._sum.debit || 0) - Number(outflows._sum.credit || 0),
    };
  }
}
