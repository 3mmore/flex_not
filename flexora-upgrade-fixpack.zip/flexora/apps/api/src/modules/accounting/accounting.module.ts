/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { AccountingService } from './accounting.service';

@Module({ imports: [PrismaModule], providers: [AccountingService], exports: [AccountingService] })
export class AccountingModule {}
