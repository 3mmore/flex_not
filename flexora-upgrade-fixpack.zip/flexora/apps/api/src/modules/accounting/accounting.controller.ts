/**
 * FLEXORA Gym OS — Accounting controller (Phase 18)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Post, Query, UseGuards, Req } from '@nestjs/common';
import { Request } from 'express';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsArray, IsIn, IsNumber, IsOptional, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { AccountingService } from './accounting.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class AccountDto {
  @IsString() code!: string;
  @IsString() name!: string;
  @IsIn(['ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE']) type!: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  @IsOptional() @IsString() parentId?: string;
}

class JournalLineDto {
  @IsString() accountId!: string;
  @IsOptional() @IsNumber() debit?: number;
  @IsOptional() @IsNumber() credit?: number;
  @IsOptional() @IsString() memo?: string;
}

class PostJournalDto {
  @IsOptional() date?: Date;
  @IsOptional() @IsString() memo?: string;
  @IsOptional() @IsString() reference?: string;
  @IsArray() @ValidateNested({ each: true }) @Type(() => JournalLineDto)
  lines!: JournalLineDto[];
}

@ApiTags('accounting')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('accounting')
export class AccountingController {
  constructor(private readonly svc: AccountingService) {}

  @Get('summary') @Permissions('accounting.view')
  summary(@GymId() g: string) { return this.svc.summary(g); }

  @Get('entries') @Permissions('accounting.view')
  entries(@GymId() g: string) { return this.svc.entries(g); }

  @Post('journal') @Permissions('accounting.manage') @Audit('post_journal', 'JournalEntry')
  journal(@GymId() g: string, @Body() dto: PostJournalDto, @CurrentUser('sub') userId: string) { return this.svc.journal(g, dto, userId); }

  @Get('accounts') @Permissions('accounting.view')
  accounts(@GymId() g: string, @Query('skip') skip?: string, @Query('take') take?: string) { return this.svc.listAccounts(g, skip ? parseInt(skip) : 0, take ? parseInt(take) : 500); }

  @Post('accounts/seed') @Permissions('accounting.manage') @Audit('seed', 'ChartOfAccount')
  seed(@GymId() g: string) { return this.svc.seedDefaults(g); }

  @Post('accounts') @Permissions('accounting.manage') @Audit('create', 'ChartOfAccount')
  create(@GymId() g: string, @Body() dto: AccountDto) { return this.svc.createAccount(g, dto); }

  @Get('journals') @Permissions('accounting.view')
  journals(@GymId() g: string, @Req() req: Request, @Query('from') from?: string, @Query('to') to?: string) {
    return this.svc.listJournals(g, { from: from ? new Date(from) : undefined, to: to ? new Date(to) : undefined, skip: req.query.skip ? parseInt(req.query.skip as string) : 0, take: req.query.take ? parseInt(req.query.take as string) : 200 });
  }

  @Post('journals') @Permissions('accounting.manage') @Audit('post_journal', 'JournalEntry')
  postJournal(@GymId() g: string, @Body() dto: PostJournalDto, @CurrentUser('sub') userId: string) {
    return this.svc.postJournal(g, dto, userId);
  }

  @Get('reports/profit-loss') @Permissions('accounting.view')
  pl(@GymId() g: string, @Query('from') from: string, @Query('to') to: string) {
    return this.svc.profitAndLoss(g, new Date(from), new Date(to));
  }

  @Get('reports/balance-sheet') @Permissions('accounting.view')
  bs(@GymId() g: string, @Query('asOf') asOf?: string) {
    return this.svc.balanceSheet(g, asOf ? new Date(asOf) : new Date());
  }

  @Get('reports/cash-flow') @Permissions('accounting.view')
  cf(@GymId() g: string, @Query('from') from: string, @Query('to') to: string) {
    return this.svc.cashFlow(g, new Date(from), new Date(to));
  }
}
