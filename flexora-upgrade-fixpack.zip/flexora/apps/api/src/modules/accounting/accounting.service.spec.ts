/**
 * FLEXORA Gym OS — Accounting tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { AccountingService } from './accounting.service';
import { PrismaService } from '../../config/prisma.service';

interface FakeAccount { id: string; code: string; name: string; type: string }
interface FakeLine { id: string; accountId: string; debit: number; credit: number; journalEntry: { gymId: string; date: Date } }

class FakePrisma {
  accounts: FakeAccount[] = [
    { id: 'a-rev', code: '4000', name: 'Revenue', type: 'REVENUE', gymId: 'g1' } as any,
    { id: 'a-exp', code: '5000', name: 'Rent', type: 'EXPENSE', gymId: 'g1' } as any,
  ];
  lines: FakeLine[] = [
    { id: 'l1', accountId: 'a-rev', debit: 0, credit: 1000, journalEntry: { gymId: 'g1', date: new Date('2026-01-15') } },
    { id: 'l2', accountId: 'a-exp', debit: 400, credit: 0, journalEntry: { gymId: 'g1', date: new Date('2026-01-20') } },
  ];
  chartOfAccount = {
    count: ({ where }: { where: { id: { in: string[] }, gymId: string } }) => {
      return this.accounts.filter(a => where.id.in.includes(a.id) && (a as any).gymId === where.gymId).length;
    },
    findFirst: ({ where }: { where: { id: string, gymId: string } }) => {
      return this.accounts.find(a => a.id === where.id && (a as any).gymId === where.gymId);
    },
    findMany: ({ where }: { where?: { type?: { in?: string[] } } }) => {
      const types = (where?.type?.in ?? []) as string[];
      return this.accounts.filter((a: FakeAccount) => types.length === 0 || types.includes(a.type));
    },
    upsert: jest.fn(),
    create: ({ data }: { data: any }) => { const a = { id: 'a-' + Math.random(), ...data }; this.accounts.push(a); return a; },
  };
  journalEntry = {
    findMany: ({ where }: { where?: { gymId: string } }) => this.lines.filter((l: FakeLine) => l.journalEntry.gymId === where?.gymId),
    create: ({ data }: { data: any }) => {
      const e: any = { id: 'je-' + Math.random(), ...data, lines: [] };
      for (const l of data.lines.create) e.lines.push(l);
      return Promise.resolve(e);
    },
  };
  journalLine = {
    findMany: ({ where }: { where?: { accountId?: { in?: string[] } } }) => {
      const ids = (where?.accountId?.in ?? []) as string[];
      return this.lines.filter((l: FakeLine) => ids.includes(l.accountId));
    },
    aggregate: () => ({ _sum: { debit: 0, credit: 0 } }),
  };
  $transaction = jest.fn(async (ops: any[]) => Promise.all(ops.map((op: any) => typeof op === 'function' ? op() : op)));
  $queryRaw = jest.fn();
}

describe('AccountingService', () => {
  let svc: AccountingService;
  let prisma: FakePrisma;
  beforeEach(() => { prisma = new FakePrisma(); svc = new AccountingService(prisma as any as PrismaService); });

  it('seeds default chart of accounts', async () => {
    await svc.seedDefaults('g1');
    expect(prisma.chartOfAccount.upsert).toHaveBeenCalled();
  });

  it('rejects unbalanced journal entry', async () => {
    await expect(svc.postJournal('g1', {
      lines: [{ accountId: 'a-rev', debit: 100, credit: 0 }, { accountId: 'a-exp', debit: 0, credit: 50 }],
    }, 'u1')).rejects.toThrow(/Unbalanced/);
  });

  it('rejects journals with fewer than 2 lines', async () => {
    await expect(svc.postJournal('g1', { lines: [{ accountId: 'a', debit: 100, credit: 0 }] }, 'u1'))
      .rejects.toThrow(/at least 2/);
  });

  it('posts balanced journals', async () => {
    const e = await svc.postJournal('g1', {
      lines: [{ accountId: 'a-rev', debit: 0, credit: 100 }, { accountId: 'a-exp', debit: 100, credit: 0 }],
    }, 'u1');
    expect(e.entryNo).toMatch(/^JE-/);
  });

  it('computes P&L correctly (revenue 1000 - expense 400 = 600)', async () => {
    const pl = await svc.profitAndLoss('g1', new Date('2026-01-01'), new Date('2026-01-31'));
    expect(pl.totalRevenue).toBe(1000);
    expect(pl.totalExpense).toBe(400);
    expect(pl.netIncome).toBe(600);
  });

  it('returns zeros when no data', async () => {
    prisma.lines = [];
    const pl = await svc.profitAndLoss('g1', new Date('2026-01-01'), new Date('2026-01-31'));
    expect(pl.totalRevenue).toBe(0);
    expect(pl.totalExpense).toBe(0);
    expect(pl.netIncome).toBe(0);
  });
});
