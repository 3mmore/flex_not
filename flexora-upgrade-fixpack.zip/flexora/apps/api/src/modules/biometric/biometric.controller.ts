/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { BiometricService } from './biometric.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { RequiresFeature } from '../license/license.module';
import { RolesGuard } from '../../common/guards/roles.guard';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { BruteForceGuard } from '../../common/guards/brute-force.guard';
import type { RegistrationResponseJSON, AuthenticationResponseJSON } from '@simplewebauthn/types';

class VerifyRegistrationDto {
  @IsNotEmpty() response!: RegistrationResponseJSON;
  @IsOptional() @IsString() deviceName?: string;
}

class VerifyAuthDto {
  @IsNotEmpty() response!: AuthenticationResponseJSON;
  @IsOptional() @IsString() branchId?: string;
}

class BiometricMemberDto { @IsString() @IsNotEmpty() memberId!: string; }

class BiometricLoginDto {
  @IsString() @IsNotEmpty() gymId!: string;
  @IsString() @IsNotEmpty() memberId!: string;
}

@ApiTags('biometric')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('biometric')
@Controller('biometric')
export class BiometricController {
  constructor(private readonly bio: BiometricService) {}

  @Permissions('members.edit')
  @Post('register')
  registerAlias(@GymId() gymId: string, @Body() dto: BiometricMemberDto) { return this.bio.registrationOptions(gymId, dto.memberId); }

  @Public()
  @UseGuards(BruteForceGuard)
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  @Post('login')
  loginAlias(@Body() dto: BiometricLoginDto) { return this.bio.authenticationOptions(dto.gymId, dto.memberId); }

  @Permissions('members.edit')
  @Post('members/:memberId/registration-options')
  registrationOptions(@GymId() gymId: string, @Param('memberId') memberId: string) {
    return this.bio.registrationOptions(gymId, memberId);
  }

  @Permissions('members.edit')
  @Post('members/:memberId/verify-registration')
  verifyRegistration(
    @GymId() gymId: string,
    @Param('memberId') memberId: string,
    @Body() dto: VerifyRegistrationDto,
  ) {
    return this.bio.verifyRegistration(gymId, memberId, dto.response, dto.deviceName);
  }

  @Permissions('members.edit')
  @Post('kiosk/:memberId/authentication-options')
  kioskAuthOptions(@GymId() gymId: string, @Param('memberId') memberId: string) {
    return this.bio.authenticationOptions(gymId, memberId);
  }

  @Permissions('members.edit')
  @Post('kiosk/:memberId/verify-authentication')
  kioskVerify(@GymId() gymId: string, @Param('memberId') memberId: string, @Body() dto: VerifyAuthDto) {
    return this.bio.verifyAuthentication(gymId, memberId, dto.response, dto.branchId);
  }

  @Permissions('members.edit')
  @Get('members/:memberId/credentials')
  list(@GymId() gymId: string, @Param('memberId') memberId: string) {
    return this.bio.listCredentials(gymId, memberId);
  }

  @Permissions('members.edit')
  @Delete('members/:memberId/credentials/:credentialId')
  remove(@GymId() gymId: string, @Param('memberId') memberId: string, @Param('credentialId') credentialId: string) {
    return this.bio.removeCredential(gymId, memberId, credentialId);
  }
}
