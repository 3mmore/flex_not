/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE N1 — the WebAuthn relying-party configuration is read at call time.
 *
 * A credential created for one rpID can never be used against another, so a
 * module-scope `const RP_ID = process.env.WEBAUTHN_RP_ID || 'localhost'` was not
 * a harmless default: whenever the environment had not been injected before the
 * service file was imported, production passkeys were issued for `localhost` and
 * ceremonies were verified against `http://localhost:3000`. Registration looks
 * fine locally and is wrong in production — a silent misconfiguration rather than
 * a crash. These tests pin the behaviour that prevents it.
 */
import { rpId, rpName, webauthnOrigins } from './biometric.config';

const REAL_ENV = process.env;

function withEnv(env: Record<string, string | undefined>) {
  process.env = { ...env } as NodeJS.ProcessEnv;
}

afterEach(() => {
  process.env = REAL_ENV;
});

describe('PHASE N1 — WebAuthn relying party is read at call time', () => {
  it('falls back to the development values only when nothing is configured', () => {
    withEnv({});
    expect(rpName()).toBe('FLEXORA Gym OS');
    expect(rpId()).toBe('localhost');
    expect(webauthnOrigins()).toEqual(['http://localhost:3000']);
  });

  it('honours configuration set after this module was imported', () => {
    withEnv({
      WEBAUTHN_RP_NAME: 'Nile Fitness',
      WEBAUTHN_RP_ID: 'gym.example.com',
      WEBAUTHN_ORIGIN: 'https://gym.example.com',
    });
    expect(rpName()).toBe('Nile Fitness');
    expect(rpId()).toBe('gym.example.com');
    expect(webauthnOrigins()).toEqual(['https://gym.example.com']);
  });

  it('follows the environment when it changes between calls', () => {
    withEnv({ WEBAUTHN_RP_ID: 'first.example.com' });
    expect(rpId()).toBe('first.example.com');
    withEnv({ WEBAUTHN_RP_ID: 'second.example.com' });
    expect(rpId()).toBe('second.example.com');
    withEnv({});
    expect(rpId()).toBe('localhost');
  });

  it('accepts every origin in a comma-separated WEBAUTHN_ORIGIN list', () => {
    withEnv({
      WEBAUTHN_ORIGIN: 'https://gym.example.com,https://admin.gym.example.com',
    });
    expect(webauthnOrigins()).toEqual([
      'https://gym.example.com',
      'https://admin.gym.example.com',
    ]);
  });

  it('never invents an rpID from an empty value', () => {
    // An empty WEBAUTHN_RP_ID must not become '' (which would break every
    // ceremony); the documented default is used instead.
    withEnv({ WEBAUTHN_RP_ID: '' });
    expect(rpId()).toBe('localhost');
  });
});
