/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * WebAuthn relying-party configuration.
 *
 * PHASE N1: these were module-scope constants inside `biometric.service.ts`,
 * i.e. their values were frozen the moment that file was imported. Because
 * `ConfigModule` loads `.env` only when the Nest container is initialised —
 * after imports — the constants were correct solely by accident of
 * `@prisma/client` injecting `.env` first (see `config/load-env.ts`). When that
 * accident did not happen, passkeys were silently issued for the DEVELOPMENT
 * relying party (`rpID: 'localhost'`) and verified against
 * `http://localhost:3000`, which is a wrong-RP-id misconfiguration rather than
 * a crash: registration appears to work locally and fails — or worse, is
 * accepted for the wrong origin — in production.
 *
 * They are functions now, read at call time, in their own module so they can be
 * tested without instantiating the service.
 */

/** Human-readable relying-party name shown in the browser's passkey prompt. */
export function rpName(): string {
  return process.env.WEBAUTHN_RP_NAME || 'FLEXORA Gym OS';
}

/**
 * Relying-party ID: the origin's *host*. A credential created for one rpID can
 * never be used against another, so a stale `localhost` here silently breaks
 * every production passkey.
 */
export function rpId(): string {
  return process.env.WEBAUTHN_RP_ID || 'localhost';
}

/** Allowed origins for ceremony verification (comma-separated, all honoured). */
export function webauthnOrigins(): string[] {
  return (process.env.WEBAUTHN_ORIGIN || 'http://localhost:3000').split(',');
}
