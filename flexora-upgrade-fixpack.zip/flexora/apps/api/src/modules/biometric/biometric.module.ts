/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { BiometricService } from './biometric.service';

@Module({
  imports: [PrismaModule, RedisModule],
  providers: [BiometricService],
  exports: [BiometricService],
})
export class BiometricModule {}
