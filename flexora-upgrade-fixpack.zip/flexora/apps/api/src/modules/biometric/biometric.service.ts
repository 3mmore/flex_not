/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * WebAuthn / biometric check-in (Phase 11).
 *
 * Registers a member's authenticator (fingerprint / face / security
 * key) and verifies subsequent check-ins.
 *
 * Requires HTTPS in production (enforced by main.ts and nginx).
 */
import { isProduction } from '../../config/env-mode';
import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from '@simplewebauthn/server';
import type {
  AuthenticatorDevice,
  RegistrationResponseJSON,
  AuthenticationResponseJSON,
  PublicKeyCredentialCreationOptionsJSON,
  PublicKeyCredentialRequestOptionsJSON,
} from '@simplewebauthn/types';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
// ROUND 14 (security review, PHASE K1): the ONE membership-state decision.
import { canTrain, trainingDenialReason } from '../members/membership-status';
import { RedisService } from '../../config/redis.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { rpId, rpName, webauthnOrigins } from './biometric.config';

// Inline base64url helpers to avoid depending on @simplewebauthn/helpers.
function fromB64u(b: string): Buffer { return Buffer.from(b.replace(/-/g, '+').replace(/_/g, '/'), 'base64'); }
function toB64u(buf: Buffer): string { return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }

// PHASE N1 — WebAuthn relying-party config is read at call time, in its own
// module, so no import order can freeze it to the development defaults.

@Injectable()
export class BiometricService {
  private readonly logger = new Logger(BiometricService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private assertHttps() {
    if (isProduction()) {
      const ok = webauthnOrigins().some((o) => o.startsWith('https://'));
      if (!ok) throw new BadRequestException('WebAuthn requires HTTPS in production');
    }
  }

  /** Step 1: issue a challenge to the browser to create a credential. */
  async registrationOptions(gymId: string, memberId: string): Promise<PublicKeyCredentialCreationOptionsJSON> {
    this.assertHttps();
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new NotFoundException('Member not found');

    const existing = await this.prisma.biometricCredential.findMany({
      where: { memberId, gymId },
      take: 100,
    });

    const opts = await generateRegistrationOptions({
      rpName: rpName(),
      rpID: rpId(),
      userID: memberId,
      userName: member.name,
      userDisplayName: member.name,
      attestationType: 'none',
      authenticatorSelection: { residentKey: 'preferred', userVerification: 'required' },
      excludeCredentials: existing.map((c) => ({ id: fromB64u(c.credentialId), type: 'public-key' as const })),
    });

    // Persist challenge for verification step (10 minutes)
    await this.redis.set(`webauthn:reg:${gymId}:${memberId}`, opts.challenge, 600);
    return opts;
  }

  /** Step 2: verify the browser's response and store the credential. */
  async verifyRegistration(gymId: string, memberId: string, response: RegistrationResponseJSON, deviceName?: string) {
    this.assertHttps();
    const challenge = await this.redis.client.getdel(`webauthn:reg:${gymId}:${memberId}`);
    if (!challenge) throw new BadRequestException('Registration challenge expired');

    const verification = await verifyRegistrationResponse({
      response,
      expectedChallenge: challenge,
      expectedOrigin: webauthnOrigins(),
      expectedRPID: rpId(),
    });

    if (!verification.verified || !verification.registrationInfo) {
      throw new BadRequestException('Registration could not be verified');
    }
    const { credentialPublicKey, credentialID, counter } = verification.registrationInfo;
    const credentialId = toB64u(Buffer.from(credentialID));
    const publicKey = toB64u(Buffer.from(credentialPublicKey));

    await this.prisma.biometricCredential.create({
      data: {
        gymId,
        memberId,
        credentialId,
        publicKey,
        counter: BigInt(counter),
        deviceName: deviceName || 'Unknown device',
      },
    });
    return { ok: true, credentialId };
  }

  /** Step 1: issue a challenge for an authentication ceremony. */
  async authenticationOptions(gymId: string, memberId: string): Promise<PublicKeyCredentialRequestOptionsJSON> {
    this.assertHttps();
    return this.tenantContext.run(gymId, async () => {
      const creds = await this.prisma.biometricCredential.findMany({
        where: { memberId, gymId },
      });
      if (creds.length === 0) throw new BadRequestException('No registered authenticators');

      const opts = await generateAuthenticationOptions({
        rpID: rpId(),
        userVerification: 'required',
        allowCredentials: creds.map((c) => ({ id: fromB64u(c.credentialId), type: 'public-key' as const })),
      });
      await this.redis.set(`webauthn:auth:${gymId}:${memberId}`, opts.challenge, 300);
      return opts;
    });
  }

  /**
   * Step 2: verify the response and create an Attendance row.
   * Returns the new attendance record on success.
   */
  async verifyAuthentication(gymId: string, memberId: string, response: AuthenticationResponseJSON, branchId?: string) {
    this.assertHttps();
    const challenge = await this.redis.client.getdel(`webauthn:auth:${gymId}:${memberId}`);
    if (!challenge) throw new BadRequestException('Authentication challenge expired');

    const cred = await this.prisma.biometricCredential.findUnique({
      where: { credentialId: response.id, gymId },
    });
    if (!cred || cred.gymId !== gymId || cred.memberId !== memberId) {
      throw new BadRequestException('Unknown authenticator');
    }

    const device: AuthenticatorDevice = {
      credentialID: fromB64u(cred.credentialId),
      credentialPublicKey: fromB64u(cred.publicKey),
      counter: Number(cred.counter),
    };
    const verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: challenge,
      expectedOrigin: webauthnOrigins(),
      expectedRPID: rpId(),
      authenticator: device,
    });

    if (!verification.verified) throw new BadRequestException('Authentication failed');

    const member = await this.prisma.member.findFirst({
      where: { id: memberId, gymId },
      include: { plan: true },
    });
    if (!member) throw new BadRequestException('Member not found');
    const targetBranchId = branchId || member.branchId;
    const branch = await this.prisma.branch.findFirst({ where: { id: targetBranchId, gymId } });
    if (!branch) throw new BadRequestException('Invalid branch');
    // ROUND 14 (security review, PHASE K1): the shared, FAIL-CLOSED gate
    // (same one the manual/QR/kiosk check-in uses). The inline version let a
    // TIME-plan member with a NULL expiry in through the device check-in.
    if (!canTrain(member)) throw new BadRequestException(trainingDenialReason(member));

    return this.prisma.withTenant(gymId, async (tx) => {
      // A cloned/replayed authenticator response must not win a concurrent
      // counter update and create a second attendance record.
      const counterUpdate = await tx.biometricCredential.updateMany({
        where: { id: cred.id, counter: cred.counter },
        data: { counter: BigInt(verification.authenticationInfo.newCounter), lastUsedAt: new Date() },
      });
      if (counterUpdate.count !== 1) throw new BadRequestException('Authenticator replay detected');

      const memberUpdate = await tx.member.updateMany({
        where: {
          id: memberId,
          gymId,
          ...(member.plan.type === 'SESSION' ? { sessionsLeft: { gt: 0 } } : {}),
        },
        data: {
          ...(member.plan.type === 'SESSION' ? { sessionsLeft: { decrement: 1 } } : {}),
          visits: { increment: 1 },
          lastVisit: new Date(),
        },
      });
      if (memberUpdate.count !== 1) throw new BadRequestException('Membership is not active');

      return tx.attendance.create({
        data: {
          gymId,
          memberId,
          branchId: targetBranchId,
          method: 'QR',
          staffName: 'Biometric Kiosk',
        },
      });
    });
  }

  async listCredentials(gymId: string, memberId: string) {
    return this.prisma.biometricCredential.findMany({
      where: { gymId, memberId },
      orderBy: { createdAt: 'desc' },
      select: { id: true, credentialId: true, deviceName: true, lastUsedAt: true, createdAt: true },
    });
  }

  async removeCredential(gymId: string, memberId: string, credentialId: string) {
    return this.prisma.biometricCredential.deleteMany({
      where: { credentialId, gymId, memberId },
    });
  }
}
