/**
 * FLEXORA Gym OS — Staff payroll API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Get, Header, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PayrollService } from './payroll.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';

@ApiTags('staff')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('payroll')
@Controller('staff/payroll')
export class PayrollController {
  constructor(private readonly payroll: PayrollService) {}

  @Get()
  @Permissions('staff.manage')
  list(@GymId() gymId: string, @Query('month') month: string, @Query('year') year: string) {
    return this.payroll.listPayroll(gymId, Number(month), Number(year));
  }

  @Post(':id/approve')
  @Permissions('payroll.manage')
  approve(@GymId() gymId: string, @Param('id') id: string, @CurrentUser('sub') userId: string) {
    return this.payroll.approve(gymId, id, userId);
  }

  @Post(':id/pay')
  @Permissions('payroll.manage')
  pay(@GymId() gymId: string, @Param('id') id: string) {
    return this.payroll.markPaid(gymId, id);
  }

  @Get(':id/export')
  @Permissions('staff.manage')
  @Header('Content-Type', 'text/csv; charset=utf-8')
  export(@GymId() gymId: string, @Param('id') id: string) {
    return this.payroll.exportCsv(gymId, id);
  }
}
