/**
 * FLEXORA Gym OS — Staff payroll engine
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PayrollDetailType } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';

@Injectable()
export class PayrollService {
  constructor(private readonly prisma: PrismaService) {}

  async calculatePayroll(staffId: string, month: number, year: number, gymId?: string) {
    this.assertPeriod(month, year);
    const staff = await this.prisma.user.findFirst({ where: { id: staffId, ...(gymId ? { gymId } : {}) } });
    if (!staff) throw new NotFoundException('Staff member not found');
    const profile = await this.prisma.staffPayProfile.findFirst({ where: { userId: staffId, gymId: staff.gymId, active: true } });
    const hourlyRate = Number(profile?.hourlyRate || 0);
    const { start, end } = this.monthRange(month, year);
    const attendance = await this.prisma.staffAttendance.findMany({ where: { gymId: staff.gymId, userId: staffId, checkInAt: { gte: start, lt: end } }, orderBy: { checkInAt: 'asc' } });

    let regularMinutes = 0;
    let overtimeMinutes = 0;
    let lateDeductions = 0;
    for (const row of attendance) {
      if (!row.checkOutAt) continue;
      const minutes = Math.max(0, Math.round((row.checkOutAt.getTime() - row.checkInAt.getTime()) / 60000));
      const regular = Math.min(minutes, 8 * 60);
      const overtime = Math.max(0, minutes - 8 * 60);
      regularMinutes += regular;
      overtimeMinutes += overtime;
      const shiftStart = new Date(row.checkInAt);
      shiftStart.setHours(9, 15, 0, 0);
      if (row.checkInAt > shiftStart) lateDeductions += hourlyRate * 0.25;
    }

    const regularHours = regularMinutes / 60;
    const overtimeHours = overtimeMinutes / 60;
    const grossPay = regularHours * hourlyRate + overtimeHours * hourlyRate * 1.5;
    const statutoryDeductions = grossPay * Number(process.env.PAYROLL_DEDUCTION_RATE || 0);
    const deductions = statutoryDeductions + lateDeductions;
    const netPay = Math.max(0, grossPay - deductions);
    return {
      staffId,
      gymId: staff.gymId,
      month,
      year,
      regularHours: this.money(regularHours),
      overtimeHours: this.money(overtimeHours),
      totalHours: this.money(regularHours + overtimeHours),
      grossPay: this.money(grossPay),
      deductions: this.money(deductions),
      netPay: this.money(netPay),
      currency: profile?.currency || 'EGP',
      lineItems: [
        { type: PayrollDetailType.SALARY, description: 'Regular working hours', hours: this.money(regularHours), amount: this.money(regularHours * hourlyRate) },
        { type: PayrollDetailType.OVERTIME, description: 'Overtime at 1.5x after 8h/day', hours: this.money(overtimeHours), amount: this.money(overtimeHours * hourlyRate * 1.5) },
        { type: PayrollDetailType.DEDUCTION, description: 'Late arrivals and statutory deductions', amount: this.money(deductions) },
      ],
    };
  }

  async generatePayrollBatch(gymId: string, month: number, year: number) {
    this.assertPeriod(month, year);
    const staff = await this.prisma.user.findMany({ where: { gymId, active: true, role: { in: ['MANAGER', 'RECEPTION', 'COACH'] } }, select: { id: true } });
    const records: unknown[] = [];
    for (const user of staff) {
      const calc = await this.calculatePayroll(user.id, month, year, gymId);
      const record = await this.prisma.payrollRecord.upsert({
        where: { staffId_month_year_gymId: { staffId: user.id, month, year, gymId } },
        update: { totalHours: calc.totalHours, overtimeHours: calc.overtimeHours, grossPay: calc.grossPay, deductions: calc.deductions, netPay: calc.netPay },
        create: { staffId: user.id, gymId, month, year, totalHours: calc.totalHours, overtimeHours: calc.overtimeHours, grossPay: calc.grossPay, deductions: calc.deductions, netPay: calc.netPay },
      });
      await this.prisma.payrollDetail.deleteMany({ where: { payrollRecordId: record.id } });
      for (const line of calc.lineItems) {
        await this.prisma.payrollDetail.create({ data: { payrollRecordId: record.id, gymId, type: line.type, description: line.description, hours: 'hours' in line ? line.hours : undefined, amount: line.amount } });
      }
      records.push(record);
    }
    return records;
  }

  async listPayroll(gymId: string, month: number, year: number) {
    await this.generatePayrollBatch(gymId, month, year);
    return this.prisma.payrollRecord.findMany({ where: { gymId, month, year }, include: { staff: { select: { id: true, name: true, role: true } }, details: true }, orderBy: { staffId: 'asc' } });
  }

  async approve(gymId: string, id: string, approvedBy: string) {
    const record = await this.getRecord(gymId, id);
    if (record.status !== 'DRAFT') throw new BadRequestException('Only draft payroll can be approved');
    return this.prisma.payrollRecord.update({ where: { id }, data: { status: 'APPROVED', approvedBy, approvedAt: new Date() } });
  }

  async markPaid(gymId: string, id: string) {
    const record = await this.getRecord(gymId, id);
    if (record.status !== 'APPROVED') throw new BadRequestException('Only approved payroll can be marked paid');
    // P4-5: show the employee's name in the ledger, not the raw staff id.
    const staff = await this.prisma.user.findFirst({ where: { id: record.staffId, gymId }, select: { name: true } });
    await this.prisma.transaction.create({ data: { gymId, type: 'EXPENSE', category: 'payroll', reference: `PAYROLL-${record.month}/${record.year}`, description: `Salary ${record.month}/${record.year} — ${staff?.name || 'staff member'}`, amount: Number(record.netPay) } });
    return this.prisma.payrollRecord.update({ where: { id }, data: { status: 'PAID', paidAt: new Date() } });
  }

  async exportCsv(gymId: string, id: string) {
    const record = await this.prisma.payrollRecord.findFirst({ where: { id, gymId }, include: { staff: true, details: true } });
    if (!record) throw new NotFoundException('Payroll record not found');
    const rows = [
      ['Staff', 'Month', 'Year', 'Total Hours', 'Overtime Hours', 'Gross Pay', 'Deductions', 'Net Pay', 'Status'],
      [record.staff.name, record.month, record.year, record.totalHours, record.overtimeHours, record.grossPay, record.deductions, record.netPay, record.status],
      [],
      ['Type', 'Description', 'Hours', 'Amount'],
      ...record.details.map((detail) => [detail.type, detail.description, detail.hours || '', detail.amount]),
    ];
    return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  }

  private async getRecord(gymId: string, id: string) {
    const record = await this.prisma.payrollRecord.findFirst({ where: { id, gymId } });
    if (!record) throw new NotFoundException('Payroll record not found');
    return record;
  }

  private assertPeriod(month: number, year: number) {
    if (!Number.isInteger(month) || month < 1 || month > 12) throw new BadRequestException('Invalid payroll month');
    if (!Number.isInteger(year) || year < 2020 || year > 2100) throw new BadRequestException('Invalid payroll year');
  }

  private monthRange(month: number, year: number) {
    return { start: new Date(Date.UTC(year, month - 1, 1)), end: new Date(Date.UTC(year, month, 1)) };
  }

  private money(value: number) {
    return Math.round(value * 100) / 100;
  }
}
