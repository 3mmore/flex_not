/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsIn, IsObject, IsOptional, IsString, MinLength } from 'class-validator';
import { CampaignsService } from './campaigns.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Prisma, NotifyChannel } from '@prisma/client';

class CreateCampaignDto {
  @IsString() @MinLength(3) name!: string;
  @IsIn(['INAPP', 'EMAIL', 'WHATSAPP', 'SMS']) channel!: NotifyChannel;
  @IsString() @MinLength(5) body!: string;
  @IsOptional() @IsString() templateKey?: string;
  @IsOptional() scheduledAt?: Date;
  @IsOptional() @IsObject() audienceFilter?: Record<string, unknown>;
}

@ApiTags('campaigns')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('campaigns')
@Controller('campaigns')
export class CampaignsController {
  constructor(private readonly svc: CampaignsService) {}

  @Get()
  @Permissions('reports.view')
  list(@GymId() gymId: string) { return this.svc.list(gymId); }

  @Get(':id/stats') @Permissions('reports.view')
  stats(@GymId() gymId: string, @Param('id') id: string) { return this.svc.stats(gymId, id); }

  @Get(':id')
  @Permissions('reports.view')
  get(@GymId() gymId: string, @Param('id') id: string) { return this.svc.get(gymId, id); }

  @Post() @Permissions('reports.view') @Audit('create', 'Campaign')
  create(
    @GymId() gymId: string,
    @Body() dto: CreateCampaignDto,
    @CurrentUser('sub') userId: string,
  ) { return this.svc.create(gymId, { ...dto, audienceFilter: dto.audienceFilter as Prisma.InputJsonValue }, userId); }

  @Post(':id/send') @Permissions('reports.view') @Audit('send', 'Campaign')
  send(@GymId() gymId: string, @Param('id') id: string) { return this.svc.send(gymId, id); }

  @Post(':id/cancel') @Permissions('reports.view')
  cancel(@GymId() gymId: string, @Param('id') id: string) { return this.svc.cancel(gymId, id); }

  @Delete(':id') @Permissions('reports.view') @Audit('delete', 'Campaign')
  remove(@GymId() gymId: string, @Param('id') id: string) { return this.svc.delete(gymId, id); }
}
