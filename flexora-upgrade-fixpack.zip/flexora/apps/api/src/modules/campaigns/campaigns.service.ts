/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Campaigns (Phase 13).
 * - Draft a WhatsApp/SMS/Email campaign
 * - Schedule or send immediately via the Bull queue
 * - Track delivery stats
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { QueueService } from '../queue/queue.module';
import { Prisma, NotifyChannel, CampaignStatus, CampaignRecipientStatus } from '@prisma/client';

@Injectable()
export class CampaignsService {
  private readonly logger = new Logger(CampaignsService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
  ) {}

  list(gymId: string) {
    return this.prisma.campaign.findMany({
      where: { gymId },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  async get(gymId: string, id: string) {
    const c = await this.prisma.campaign.findFirst({ where: { id, gymId } });
    if (!c) throw new NotFoundException('Campaign not found');
    return c;
  }

  async create(gymId: string, dto: { name: string; channel: NotifyChannel; body: string; templateKey?: string; scheduledAt?: Date; audienceFilter?: Prisma.InputJsonValue }, createdBy?: string) {
    return this.prisma.campaign.create({
      data: {
        gymId,
        name: dto.name,
        type: 'CAMPAIGN',
        channel: dto.channel,
        body: dto.body,
        templateKey: dto.templateKey,
        scheduledAt: dto.scheduledAt,
        audienceFilter: (dto.audienceFilter as Prisma.InputJsonValue) || Prisma.DbNull,
        createdBy,
      },
    });
  }

  async send(gymId: string, id: string) {
    const c = await this.get(gymId, id);
    if (c.status !== CampaignStatus.DRAFT && c.status !== CampaignStatus.SCHEDULED) {
      throw new BadRequestException(`Cannot send a campaign in ${c.status} state`);
    }
    await this.prisma.campaign.update({
      where: { id },
      data: { status: CampaignStatus.SENDING },
    });
    const filter = (c.audienceFilter as Record<string, unknown>)?.segment || 'all';
    const now = new Date();
    const in30 = new Date(Date.now() + 30 * 86400000);
    const memberWhere: Prisma.MemberWhereInput = { gymId };
    if (filter === 'expiring') memberWhere.expiry = { gte: now, lte: in30 };
    if (filter === 'inactive') memberWhere.OR = [{ lastVisit: null }, { lastVisit: { lt: new Date(Date.now() - 30 * 86400000) } }];
    if (filter === 'vip') memberWhere.vip = true;

    const BATCH_SIZE = 500;
    let skip = 0;
    let batch: { id: string; mobile: string }[];

    do {
      batch = await this.prisma.member.findMany({
        where: memberWhere,
        select: { id: true, mobile: true },
        take: BATCH_SIZE,
        skip,
      });

      if (batch.length > 0) {
        await this.prisma.campaignRecipient.createMany({
          data: batch.map((m) => ({
            gymId,
            campaignId: id,
            memberId: m.id,
            to: m.mobile,
            status: CampaignRecipientStatus.PENDING,
          })),
          skipDuplicates: true,
        });
      }
      skip += BATCH_SIZE;
    } while (batch.length === BATCH_SIZE);

    const job = await this.queue.enqueue('send-campaign', { gymId, campaignId: id });
    return { ok: true, jobId: job.id };
  }

  async stats(gymId: string, id: string) {
    await this.get(gymId, id);
    const [total, sent, failed] = await Promise.all([
      this.prisma.campaignRecipient.count({ where: { gymId, campaignId: id } }),
      this.prisma.campaignRecipient.count({ where: { gymId, campaignId: id, status: CampaignRecipientStatus.SENT } }),
      this.prisma.campaignRecipient.count({ where: { gymId, campaignId: id, status: CampaignRecipientStatus.FAILED } }),
    ]);
    return { total, sent, failed, pending: total - sent - failed };
  }

  async cancel(gymId: string, id: string) {
    await this.get(gymId, id);
    return this.prisma.campaign.update({
      where: { id },
      data: { status: CampaignStatus.CANCELLED },
    });
  }

  async delete(gymId: string, id: string) {
    await this.get(gymId, id);
    return this.prisma.campaign.deleteMany({ where: { id, gymId } });
  }
}
