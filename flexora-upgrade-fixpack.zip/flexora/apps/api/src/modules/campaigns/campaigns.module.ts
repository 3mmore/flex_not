/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { QueueModule } from '../queue/queue.module';
import { CampaignsService } from './campaigns.service';

@Module({
  imports: [QueueModule],
  providers: [CampaignsService],
  exports: [CampaignsService],
})
export class CampaignsModule {}
