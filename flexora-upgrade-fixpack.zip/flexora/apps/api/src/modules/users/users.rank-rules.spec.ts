/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 13 (security review, PHASE A) — rank rules for staff management.
 *
 * Rank: OWNER > MANAGER > RECEPTION = COACH = ACCOUNTANT. The acting user is
 * passed into create/update/assignBranch/toggle/remove and the service
 * enforces, with a mocked Prisma (no DB needed):
 *
 *  R1  nobody may create an OWNER (only the ownership-transfer flow may);
 *      only an OWNER may create a MANAGER; a missing actor fails closed.
 *  R2  PATCH /users/:id, /branch, /toggle and DELETE /users/:id — the actor
 *      may only act on accounts of STRICTLY LOWER rank (peers allowed inside
 *      the front-desk tier); the OWNER account is untouchable.
 *  R3  nobody may deactivate or delete the OWNER; nobody may deactivate or
 *      delete themselves.
 *  R4  nobody may change their own role.
 *  R5  role changes by an OWNER stay allowed and are audit-logged.
 *  R6  UpdateUserDto active:false via PATCH revokes the user's refresh tokens
 *      exactly like toggle()/remove() do.
 */
import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { UsersService, ROLE_RANK, rankOf } from './users.service';

const GYM = 'gym-a';
const BRANCH = 'branch-1';

const OWNER_ACTOR = { id: 'u-owner', role: 'OWNER' };
const MANAGER_ACTOR = { id: 'u-mgr', role: 'MANAGER' };
const RECEPTION_ACTOR = { id: 'u-rec', role: 'RECEPTION' };

const ownerTarget = { id: 'u-owner', role: 'OWNER', gymId: GYM, branchId: BRANCH, active: true, name: ' Gym Owner Person', email: 'owner@gym.test' };
const managerTarget = { id: 'u-mgr2', role: 'MANAGER', gymId: GYM, branchId: BRANCH, active: true, name: 'Second Manager Person', email: 'mgr2@gym.test' };
const receptionTarget = { id: 'u-rec2', role: 'RECEPTION', gymId: GYM, branchId: BRANCH, active: true, name: 'Front Desk Person', email: 'rec2@gym.test' };
const coachTarget = { id: 'u-coach', role: 'COACH', gymId: GYM, branchId: BRANCH, active: true, name: 'Coach Person One', email: 'coach@gym.test' };
const accountantTarget = { id: 'u-acc', role: 'ACCOUNTANT', gymId: GYM, branchId: BRANCH, active: true, name: 'Accountant Person One', email: 'acc@gym.test' };

function buildPrisma(overrides: Record<string, any> = {}) {
  const prisma: any = {
    branch: { findFirst: jest.fn().mockResolvedValue({ id: BRANCH, gymId: GYM, name: 'Nasr City' }) },
    license: { findUnique: jest.fn().mockResolvedValue(null) },
    subscription: { findUnique: jest.fn().mockResolvedValue({ tier: 'ELITE' }) },
    user: {
      count: jest.fn().mockResolvedValue(0),
      create: jest.fn().mockImplementation(async ({ data }: any) => ({ id: 'u-new', ...data, active: true })),
      findFirst: jest.fn(),
      update: jest.fn().mockImplementation(async ({ data }: any) => ({ id: 'u-x', ...data })),
    },
    refreshToken: { updateMany: jest.fn().mockResolvedValue({ count: 2 }) },
    auditLog: { create: jest.fn().mockResolvedValue({ id: 'a-1' }) },
    ...overrides,
  };
  return prisma;
}

const createDto = (role: string, email = 'new@gym.test'): any => ({
  name: 'New Staff Person',
  email,
  password: 'Str0ng!Passw0rd',
  role,
  branchId: BRANCH,
});

describe('ROUND 13 PHASE A — rank rules: ROLE_RANK ordering', () => {
  it('OWNER outranks MANAGER, which outranks the front-desk tier; the tier is flat', () => {
    expect(rankOf('OWNER')).toBeGreaterThan(rankOf('MANAGER'));
    expect(rankOf('MANAGER')).toBeGreaterThan(rankOf('RECEPTION'));
    expect(rankOf('RECEPTION')).toBe(rankOf('COACH'));
    expect(rankOf('COACH')).toBe(rankOf('ACCOUNTANT'));
    expect(ROLE_RANK.SUPER_ADMIN).toBeGreaterThan(ROLE_RANK.OWNER);
    expect(rankOf('UNKNOWN')).toBe(0);
  });
});

describe('ROUND 13 PHASE A — R1: nobody may create an OWNER; only an OWNER may create a MANAGER', () => {
  it('an OWNER actor creating role=OWNER → 403 OWNER_CREATION_FORBIDDEN', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    await expect(svc.create(GYM, createDto('OWNER'), OWNER_ACTOR)).rejects.toMatchObject({
      constructor: ForbiddenException,
      response: expect.objectContaining({ code: 'OWNER_CREATION_FORBIDDEN' }),
    });
    expect(prisma.user.create).not.toHaveBeenCalled();
  });

  it('a MANAGER creating role=OWNER → 403 (a MANAGER can no longer mint an OWNER)', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    await expect(svc.create(GYM, createDto('OWNER'), MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.create).not.toHaveBeenCalled();
  });

  it('a RECEPTION (even with staff.manage) creating role=OWNER → 403', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    await expect(svc.create(GYM, createDto('OWNER'), RECEPTION_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.create).not.toHaveBeenCalled();
  });

  it('a MANAGER creating role=MANAGER → 403 (only an OWNER may)', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    await expect(svc.create(GYM, createDto('MANAGER'), MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.create).not.toHaveBeenCalled();
  });

  it('an OWNER creating role=MANAGER → allowed', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    const created = await svc.create(GYM, createDto('MANAGER'), OWNER_ACTOR);
    expect(created.role).toBe('MANAGER');
    expect(prisma.user.create).toHaveBeenCalledTimes(1);
  });

  it('a missing actor fails closed (no rank rules bypass without the JWT user)', async () => {
    const prisma = buildPrisma();
    const svc = new UsersService(prisma);
    await expect(svc.create(GYM, createDto('RECEPTION'), undefined)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.create).not.toHaveBeenCalled();
  });
});

describe('ROUND 13 PHASE A — R2/R4: PATCH only strictly-lower accounts; never your own role; never role=OWNER', () => {
  it('a MANAGER PATCHing the OWNER (password/email/role/active) → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(ownerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, ownerTarget.id, { password: 'Hacked123!' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.update(GYM, ownerTarget.id, { email: 'evil@gym.test' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.update(GYM, ownerTarget.id, { active: false } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.update(GYM, ownerTarget.id, { role: 'RECEPTION' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
    expect(prisma.refreshToken.updateMany).not.toHaveBeenCalled();
  });

  it('a MANAGER PATCHing another MANAGER → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, managerTarget.id, { password: 'Hacked123!' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.update(GYM, managerTarget.id, { role: 'COACH' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a RECEPTION PATCHing a MANAGER → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, managerTarget.id, { name: 'X Y Z' } as any, RECEPTION_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('nobody may change their own role (R4) — front-desk tier reaches the SELF_ROLE_FORBIDDEN rule', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...receptionTarget, id: RECEPTION_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, RECEPTION_ACTOR.id, { role: 'COACH' } as any, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'SELF_ROLE_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a MANAGER changing their own role → 403 as well (rank rule fires first, still blocked)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...managerTarget, id: MANAGER_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, MANAGER_ACTOR.id, { role: 'RECEPTION' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('nobody may PATCH a role to OWNER — only the ownership-transfer flow may', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, receptionTarget.id, { role: 'OWNER' } as any, OWNER_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'OWNER_CREATION_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('peers inside the front-desk tier are allowed (a RECEPTION may manage a COACH)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(coachTarget);
    const svc = new UsersService(prisma);
    const updated = await svc.update(GYM, coachTarget.id, { name: 'Renamed Coach Person' } as any, RECEPTION_ACTOR);
    expect(updated.name).toBe('Renamed Coach Person');
    expect(prisma.user.update).toHaveBeenCalledTimes(1);
  });
});

describe('ROUND 13 PHASE A — R5/R6: OWNER management stays allowed, audited, and deactivation revokes sessions', () => {
  it('an OWNER role change on a MANAGER is allowed and audit-logged (staff_role_change)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    const updated = await svc.update(GYM, managerTarget.id, { role: 'RECEPTION', branchId: BRANCH } as any, OWNER_ACTOR);
    expect(updated.role).toBe('RECEPTION');
    expect(prisma.auditLog.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({
        gymId: GYM,
        action: 'staff_role_change',
        entity: 'User',
        entityId: managerTarget.id,
        metadata: expect.objectContaining({ fromRole: 'MANAGER', toRole: 'RECEPTION', actorRole: 'OWNER' }),
      }),
    }));
  });

  it('PATCH active:false revokes the refresh tokens exactly like toggle()/remove() (R6)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    await svc.update(GYM, receptionTarget.id, { active: false } as any, OWNER_ACTOR);
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith({
      where: { userId: receptionTarget.id, revoked: false },
      data: { revoked: true, reusedAt: expect.any(Date) },
    });
    expect(prisma.auditLog.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ action: 'staff_deactivated', entityId: receptionTarget.id, metadata: expect.objectContaining({ via: 'patch' }) }),
    }));
  });

  it('PATCH active:true (reactivate) does NOT revoke sessions', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...receptionTarget, active: false });
    const svc = new UsersService(prisma);
    await svc.update(GYM, receptionTarget.id, { active: true } as any, OWNER_ACTOR);
    expect(prisma.refreshToken.updateMany).not.toHaveBeenCalled();
  });
});

describe('ROUND 13 PHASE A — R3: toggle/remove — never the OWNER, never yourself', () => {
  it('a MANAGER toggling or deleting the OWNER → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(ownerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.toggle(GYM, ownerTarget.id, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.remove(GYM, ownerTarget.id, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
    expect(prisma.refreshToken.updateMany).not.toHaveBeenCalled();
  });

  it('nobody may deactivate or delete themselves — front-desk tier reaches the SELF_FORBIDDEN rule', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...receptionTarget, id: RECEPTION_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.toggle(GYM, RECEPTION_ACTOR.id, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'SELF_FORBIDDEN' }),
    });
    await expect(svc.remove(GYM, RECEPTION_ACTOR.id, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'SELF_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a MANAGER deactivating/deleting themselves → 403 as well (rank rule fires first, still blocked)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...managerTarget, id: MANAGER_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.toggle(GYM, MANAGER_ACTOR.id, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    await expect(svc.remove(GYM, MANAGER_ACTOR.id, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('an OWNER toggling a RECEPTION off revokes their sessions and audits', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    await svc.toggle(GYM, receptionTarget.id, OWNER_ACTOR);
    expect(prisma.user.update).toHaveBeenCalledWith(expect.objectContaining({ data: { active: false } }));
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: { userId: receptionTarget.id, revoked: false } }));
    expect(prisma.auditLog.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ action: 'staff_deactivated', metadata: expect.objectContaining({ via: 'toggle' }) }),
    }));
  });

  it('an OWNER deleting a RECEPTION deactivates + revokes (soft delete)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    const res = await svc.remove(GYM, receptionTarget.id, OWNER_ACTOR);
    expect(res).toEqual({ ok: true });
    expect(prisma.user.update).toHaveBeenCalledWith(expect.objectContaining({ data: { active: false } }));
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: { userId: receptionTarget.id, revoked: false } }));
  });

  it('a MANAGER deleting another MANAGER → 403', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.remove(GYM, managerTarget.id, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });
});

describe('ROUND 13 PHASE A — branch assignment follows the same rank rules', () => {
  it('nobody may re-assign their own branch (self-granted data-scope escalation)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...receptionTarget, id: RECEPTION_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.assignBranch(GYM, RECEPTION_ACTOR.id, BRANCH, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'SELF_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a MANAGER re-assigning another MANAGER → 403', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.assignBranch(GYM, managerTarget.id, BRANCH, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('an OWNER re-assigning a RECEPTION → allowed', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    const res = await svc.assignBranch(GYM, receptionTarget.id, BRANCH, OWNER_ACTOR);
    expect(res.branchId).toBe(BRANCH);
  });
});

describe('ROUND 14 (security review, PHASE A) — R1b: role promotion through PATCH follows the creation rule', () => {
  it('a RECEPTION (staff.manage) PATCHing a COACH {role:MANAGER} → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(coachTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, coachTarget.id, { role: 'MANAGER' } as any, RECEPTION_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a MANAGER PATCHing a RECEPTION {role:MANAGER} → 403 (only an OWNER may assign MANAGER)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, receptionTarget.id, { role: 'MANAGER' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('an OWNER promoting a RECEPTION to MANAGER → allowed (and audit-logged)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    const updated = await svc.update(GYM, receptionTarget.id, { role: 'MANAGER' } as any, OWNER_ACTOR);
    expect(updated.role).toBe('MANAGER');
    expect(prisma.auditLog.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ action: 'staff_role_change', entityId: receptionTarget.id, metadata: expect.objectContaining({ fromRole: 'RECEPTION', toRole: 'MANAGER' }) }),
    }));
  });

  it('front-desk peers may not change each other\'s roles at all (RECEPTION PATCH COACH {role:RECEPTION} → 403)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(coachTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, coachTarget.id, { role: 'RECEPTION' } as any, RECEPTION_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('nobody may PATCH a role to OWNER through update either', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, receptionTarget.id, { role: 'OWNER' } as any, OWNER_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'OWNER_CREATION_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });
});

describe('ROUND 14 (security review, PHASE A) — R2b: password/email changes need MANAGER+ on a strictly-lower account', () => {
  it('a RECEPTION (staff.manage) PATCHing an ACCOUNTANT password → 403, no write', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(accountantTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, accountantTarget.id, { password: 'Hacked12345!' } as any, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'CREDENTIAL_CHANGE_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a RECEPTION (staff.manage) PATCHing an ACCOUNTANT email → 403', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(accountantTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, accountantTarget.id, { email: 'evil@gym.test' } as any, RECEPTION_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('front-desk peers may not reset each other\'s passwords (RECEPTION PATCH COACH password → 403)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(coachTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, coachTarget.id, { password: 'Hacked12345!' } as any, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'CREDENTIAL_CHANGE_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('nobody may change their OWN password/email through staff management (use /users/me)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue({ ...receptionTarget, id: RECEPTION_ACTOR.id });
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, RECEPTION_ACTOR.id, { password: 'NewPass12345!' } as any, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'CREDENTIAL_CHANGE_FORBIDDEN' }),
    });
    await expect(svc.update(GYM, RECEPTION_ACTOR.id, { email: 'me@gym.test' } as any, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'CREDENTIAL_CHANGE_FORBIDDEN' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('a MANAGER changing a strictly-lower account\'s password/email → allowed (existing behaviour kept)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(receptionTarget);
    const svc = new UsersService(prisma);
    const a = await svc.update(GYM, receptionTarget.id, { password: 'MgrReset12345!' } as any, MANAGER_ACTOR);
    expect(a.id).toBe('u-x');
    const b = await svc.update(GYM, receptionTarget.id, { email: 'moved@gym.test' } as any, MANAGER_ACTOR);
    expect(b.id).toBe('u-x');
    expect(prisma.user.update).toHaveBeenCalledTimes(2);
  });

  it('an OWNER changing a MANAGER\'s password → allowed (strictly higher rank)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await svc.update(GYM, managerTarget.id, { password: 'OwnerReset12345!' } as any, OWNER_ACTOR);
    expect(prisma.user.update).toHaveBeenCalledTimes(1);
  });

  it('a MANAGER changing another MANAGER\'s password → 403 (rank rule fires first)', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(managerTarget);
    const svc = new UsersService(prisma);
    await expect(svc.update(GYM, managerTarget.id, { password: 'Hacked12345!' } as any, MANAGER_ACTOR)).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });
});

describe('ROUND 14 (security review, PHASE A) — the self-service profile endpoint (updateSelf)', () => {
  const selfTarget = async (password = 'CurrentPass123!') => ({
    ...receptionTarget,
    id: RECEPTION_ACTOR.id,
    passwordHash: await argon2.hash(password),
  });

  it('updates the actor\'s own name/phone', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    const updated = await svc.updateSelf(GYM, RECEPTION_ACTOR.id, { name: 'New Name Person', phone: '01000000001' } as any);
    expect(prisma.user.update).toHaveBeenCalledWith(expect.objectContaining({
      where: { id: RECEPTION_ACTOR.id },
      data: { name: 'New Name Person', phone: '01000000001' },
    }));
    expect(updated.id).toBe('u-x');
    expect(prisma.auditLog.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ action: 'staff_self_profile_update', entityId: RECEPTION_ACTOR.id }),
    }));
  });

  it('rejects a password change with a WRONG current password → 403', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    await expect(svc.updateSelf(GYM, RECEPTION_ACTOR.id, { password: 'NewPass12345!', currentPassword: 'WrongPass999!' } as any)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'CURRENT_PASSWORD_INVALID' }),
    });
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('rejects a password change without the current password → 400', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    await expect(svc.updateSelf(GYM, RECEPTION_ACTOR.id, { password: 'NewPass12345!' } as any)).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('changes the password with the correct current password → writes a HASH, never plaintext', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    await svc.updateSelf(GYM, RECEPTION_ACTOR.id, { password: 'NewPass12345!', currentPassword: 'CurrentPass123!' } as any);
    const call = prisma.user.update.mock.calls[0][0];
    expect(call.data.passwordHash).toBeDefined();
    expect(call.data.passwordHash).not.toBe('NewPass12345!');
    expect(await argon2.verify(call.data.passwordHash, 'NewPass12345!')).toBe(true);
  });

  it('ignores staff-management fields — role/email in the body change nothing', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    // a body with ONLY forbidden fields → nothing to update → 400
    await expect(svc.updateSelf(GYM, RECEPTION_ACTOR.id, { role: 'OWNER', email: 'evil@gym.test' } as any)).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('rejects an empty payload → 400', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(await selfTarget());
    const svc = new UsersService(prisma);
    await expect(svc.updateSelf(GYM, RECEPTION_ACTOR.id, {} as any)).rejects.toBeInstanceOf(BadRequestException);
  });

  it('404 for a user outside the gym', async () => {
    const prisma = buildPrisma();
    prisma.user.findFirst.mockResolvedValue(null);
    const svc = new UsersService(prisma);
    await expect(svc.updateSelf(GYM, 'u-missing', { name: 'New Name Person' } as any)).rejects.toBeInstanceOf(NotFoundException);
  });
});
