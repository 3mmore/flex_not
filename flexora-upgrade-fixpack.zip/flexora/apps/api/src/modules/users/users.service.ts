/**
 * ROUND 13 (security review, PHASE A) — role rank rules for staff management.
 *
 * Rank: OWNER > MANAGER > RECEPTION = COACH = ACCOUNTANT (SUPER_ADMIN is the
 * platform role, above everything).
 *
 * The rules enforced here (UsersService / UsersController):
 *
 *  1. POST /users — nobody may create an OWNER (only the dedicated
 *     ownership-transfer flow may); only an OWNER may create a MANAGER.
 *  2. PATCH /users/:id, /branch, /toggle and DELETE /users/:id — the actor
 *     may only act on accounts of strictly lower rank, EXCEPT that within the
 *     front-desk tier (RECEPTION = COACH = ACCOUNTANT) a staff.manage holder
 *     may manage peers. A MANAGER can therefore never touch an OWNER or
 *     another MANAGER — no password, email, role, active flag, branch or
 *     permission changes.
 *  3. Nobody may deactivate or delete the OWNER, and nobody may deactivate
 *     or delete themselves. The gym always keeps at least one active OWNER.
 *  4. Nobody may change their own role.
 *  5. Role or permission changes by an OWNER stay allowed, and are
 *     audit-logged.
 *  6. Setting active:false through PATCH /users/:id revokes the user's
 *     refresh tokens immediately, exactly like toggle()/remove() do.
 */
import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '../../config/prisma.service';
import { CreateUserDto, UpdateSelfProfileDto, UpdateUserDto } from './dto';
import { Prisma } from '@prisma/client';
import { BRANCH_UNRESTRICTED_ROLES } from '../../common/branch-scope/branch-scope';
const PLAN_STAFF_LIMITS: Record<string, number> = { BASIC: 3, PRO: 10, ELITE: Number.POSITIVE_INFINITY };

/** Role rank: higher may manage lower. RECEPTION = COACH = ACCOUNTANT. */
export const ROLE_RANK: Record<string, number> = {
  SUPER_ADMIN: 4,
  OWNER: 3,
  MANAGER: 2,
  RECEPTION: 1,
  COACH: 1,
  ACCOUNTANT: 1,
};

export function rankOf(role?: string | null): number {
  return ROLE_RANK[String(role || '').toUpperCase()] ?? 0;
}

/** The acting staff user (from the JWT). Fails closed when absent. */
export interface StaffActor {
  id: string;
  role: string;
}

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}
  list(gymId: string) {
    return this.prisma.user.findMany({
      where: { gymId },
      select: {
        id: true, name: true, email: true, phone: true, role: true, branchId: true, active: true, createdAt: true,
        // FIX: the staff list UI renders u.branch?.name (falling back to "الكل"/All
        // when missing) — without selecting the relation every employee's branch
        // column always showed "All" even when a branch WAS assigned at creation.
        branch: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'asc' },
    });
  }

  // ── ROUND 13 (PHASE A): rank rules ────────────────────────────────────────

  /** Rule 1 — who may create which role. */
  private assertCanCreateRole(actor: StaffActor | undefined, role: string) {
    if (!actor || !actor.id || !actor.role) {
      throw new ForbiddenException('Authenticated staff context is required');
    }
    if (role === 'SUPER_ADMIN') throw new BadRequestException('Cannot create super admin here');
    if (role === 'OWNER') {
      throw new ForbiddenException({
        code: 'OWNER_CREATION_FORBIDDEN',
        message: 'Nobody may create an OWNER account here — only the dedicated ownership-transfer flow may.',
      });
    }
    if (role === 'MANAGER' && rankOf(actor.role) < rankOf('OWNER')) {
      throw new ForbiddenException({
        code: 'MANAGER_CREATION_FORBIDDEN',
        message: 'Only the gym owner can create a MANAGER account.',
      });
    }
  }

  /**
   * Rule 1b — role PROMOTION through PATCH /users/:id follows the same rule as
   * creation: the NEW role's rank must be strictly lower than the actor's rank
   * (only an OWNER may assign MANAGER; nobody may assign OWNER). Front-desk
   * peers (RECEPTION = COACH = ACCOUNTANT) may not change each other's roles
   * at all — a RECEPTION holding staff.manage must not be able to promote a
   * COACH to MANAGER.
   */
  private assertCanAssignRole(actor: StaffActor | undefined, newRole: string) {
    // Reuses the creation rule: OWNER is never assignable here, and MANAGER
    // requires an OWNER actor.
    this.assertCanCreateRole(actor, newRole);
    if (!actor) throw new ForbiddenException('Authenticated staff context is required');
    if (rankOf(newRole) >= rankOf(actor.role)) {
      throw new ForbiddenException({
        code: 'ROLE_PROMOTION_FORBIDDEN',
        message: 'You may only assign a role of strictly lower rank than your own.',
      });
    }
  }

  /**
   * Rule 2 — may the actor act on the target account at all?
   * Strictly-lower rank, with peer management allowed inside the front-desk
   * tier (RECEPTION = COACH = ACCOUNTANT). The OWNER account is untouchable
   * through staff management (rules 3+5: the ownership-transfer flow is the
   * only path that changes ownership).
   */
  private assertCanActOn(actor: StaffActor | undefined, target: { id: string; role: string }) {
    if (!actor || !actor.id || !actor.role) {
      throw new ForbiddenException('Authenticated staff context is required');
    }
    if (target.role === 'OWNER') {
      throw new ForbiddenException({
        code: 'OWNER_PROTECTED',
        message: 'The OWNER account cannot be managed from the staff page.',
      });
    }
    const actorRank = rankOf(actor.role);
    const targetRank = rankOf(target.role);
    if (targetRank >= rankOf('MANAGER')) {
      // MANAGER (and OWNER) targets: only a strictly-higher rank may act.
      if (actorRank <= targetRank) {
        throw new ForbiddenException({
          code: 'RANK_FORBIDDEN',
          message: 'You may only manage staff accounts of a strictly lower rank than your own.',
        });
      }
      return;
    }
    // Front-desk tier (RECEPTION = COACH = ACCOUNTANT): peers may manage peers.
    if (actorRank < targetRank) {
      throw new ForbiddenException({
        code: 'RANK_FORBIDDEN',
        message: 'You may only manage staff accounts of your own rank or lower.',
      });
    }
  }

  /** Rule 3 — the OWNER can never be deactivated or deleted, and neither can
   *  the actor themselves (the gym always keeps at least one active OWNER). */
  private assertCanDeactivate(actor: StaffActor | undefined, target: { id: string; role: string }) {
    this.assertCanActOn(actor, target);
    if (actor && target.id === actor.id) {
      throw new ForbiddenException({
        code: 'SELF_FORBIDDEN',
        message: 'You cannot deactivate or delete your own account.',
      });
    }
  }

  /** Revoke every live refresh-token family of a user — used by toggle(),
   *  remove() AND PATCH with active:false (rule 6). */
  private async revokeSessions(userId: string) {
    await this.prisma.refreshToken.updateMany({
      where: { userId, revoked: false },
      data: { revoked: true, reusedAt: new Date() },
    });
  }

  private async auditAction(
    gymId: string,
    actor: StaffActor | undefined,
    action: string,
    target: { id: string; name: string; email: string },
    metadata: Record<string, unknown>,
  ) {
    try {
      await this.prisma.auditLog.create({
        data: {
          gymId,
          userId: actor?.id || null,
          action,
          entity: 'User',
          entityId: target.id,
          metadata: { actorRole: actor?.role || null, targetName: target.name, targetEmail: target.email, ...metadata },
        },
      });
    } catch { /* auditing must never break the operation */ }
  }

  // ── existing branch validation (unchanged) ────────────────────────────────

  /**
   * PHASE 4: OWNER and MANAGER work across every branch, so their own `branch`
   * is only a *home* branch and stays optional. Every other role is pinned to
   * exactly one branch by the branch-scope rules, so creating/updating such a
   * user without a branch would silently create an account that can see
   * nothing — refuse it with an actionable message instead.
   */
  private assertBranchForRole(role: string | undefined | null, branchId: string | null | undefined) {
    if (!role) return;
    const unrestricted = BRANCH_UNRESTRICTED_ROLES.has(String(role).toUpperCase());
    if (unrestricted) return;
    if (branchId) return;
    throw new BadRequestException({
      code: 'STAFF_BRANCH_REQUIRED',
      translationKey: 'error_staff_branch_required',
      message:
        'This role is limited to a single branch, so a branch must be selected. ' +
        'Only an Owner or a General Manager can work across all branches.',
      role,
    });
  }

  async create(gymId: string, dto: CreateUserDto, actor?: StaffActor) {
    // RULE 1: rank rules for creation.
    this.assertCanCreateRole(actor, dto.role);
    this.assertBranchForRole(dto.role, dto.branchId);
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    const lic = await this.prisma.license.findUnique({ where: { gymId } });
    const count = await this.prisma.user.count({ where: { gymId } });
    const sub = await this.prisma.subscription.findUnique({ where: { gymId } }).catch(() => null);
    const tier = sub?.tier || 'BASIC';
    const planLimit = PLAN_STAFF_LIMITS[tier] ?? 3;
    // Staff capacity: subscription tier limit AND the license's staff-seat
    // count (License.seats is a STAFF concept — it must never be used to cap
    // members or plans; see members.service.ts / plans.service.ts history).
    // Errors carry code/translationKey + real numbers so the UI renders a
    // translated, specific message (see web src/lib/safe-error.ts).
    if (count >= planLimit) {
      throw new BadRequestException({
        code: 'STAFF_LIMIT_REACHED',
        translationKey: 'error_staff_limit',
        message: `Staff limit reached: this gym already has ${count} staff members, which is the maximum for the ${tier} plan. Upgrade the plan to add more staff.`,
        current: count,
        limit: planLimit,
        tier,
      });
    }
    if (lic && count >= lic.seats) {
      throw new BadRequestException({
        code: 'STAFF_SEAT_LIMIT_REACHED',
        translationKey: 'error_staff_seats',
        message: `Staff seat limit reached: your license allows ${lic.seats} staff seats and all of them are used (${count}). Contact support to upgrade your license.`,
        current: count,
        limit: lic.seats,
        tier,
      });
    }

    try {
      return await this.prisma.user.create({
        data: { gymId, name: dto.name, email: dto.email, phone: dto.phone || null, role: dto.role, branchId: dto.branchId || null, passwordHash: await argon2.hash(dto.password) },
        select: { id: true, name: true, email: true, phone: true, role: true, branchId: true, active: true },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'USER_ALREADY_EXISTS',
          translationKey: 'error_email_exists',
          message: 'User with this email already exists.',
        });
      }
      throw error;
    }
  }

  async update(gymId: string, id: string, dto: UpdateUserDto, actor?: StaffActor) {
    const u = await this.prisma.user.findFirst({ where: { id, gymId } });
    if (!u) throw new NotFoundException('User not found');
    // RULE 2: the actor may only act on strictly-lower-rank accounts (peers
    // allowed inside the front-desk tier); the OWNER account is untouchable.
    this.assertCanActOn(actor, u);
    // RULE 2b (ROUND 14 security review, PHASE A): changing another user's
    // password or email is a manager-level operation AND requires a strictly
    // higher rank than the target. Front-desk peers must NOT be able to reset
    // each other's credentials — a RECEPTION holding staff.manage could
    // otherwise reset an ACCOUNTANT's password and inherit accounting access.
    // (Self password/email changes go through the self-service profile
    // endpoint PATCH /users/me — see updateSelf below.)
    if (dto.password !== undefined || dto.email !== undefined) {
      const actorRank = actor ? rankOf(actor.role) : 0;
      const targetRank = rankOf(u.role);
      const isSelf = !!actor && id === actor.id;
      if (isSelf || actorRank < rankOf('MANAGER') || actorRank <= targetRank) {
        throw new ForbiddenException({
          code: 'CREDENTIAL_CHANGE_FORBIDDEN',
          message:
            'Only a MANAGER or higher, of strictly higher rank than the account, may change a staff password or email. ' +
            'Change your own credentials from the self-service profile page.',
        });
      }
    }
    // RULE 4: nobody may change their own role.
    if (dto.role && dto.role !== u.role && actor && id === actor.id) {
      throw new ForbiddenException({
        code: 'SELF_ROLE_FORBIDDEN',
        message: 'You cannot change your own role.',
      });
    }
    // Nobody may mint an OWNER through a role patch — only the dedicated
    // ownership-transfer flow may (rule 1, applied to updates too).
    if (dto.role === 'OWNER') {
      throw new ForbiddenException({
        code: 'OWNER_CREATION_FORBIDDEN',
        message: 'Nobody may assign the OWNER role here — only the dedicated ownership-transfer flow may.',
      });
    }
    // RULE 1b (ROUND 14 security review, PHASE A): a role CHANGE must satisfy
    // the creation rule — the new role's rank strictly lower than the actor's
    // (only an OWNER may promote to MANAGER; peers may not change roles).
    if (dto.role && dto.role !== u.role) {
      this.assertCanAssignRole(actor, dto.role);
    }
    // PHASE 4: validate the RESULTING role/branch pair, not just the patch —
    // switching a RECEPTION user to MANAGER (or vice versa) must not be able
    // to leave a restricted role without a branch.
    this.assertBranchForRole(dto.role ?? u.role, dto.branchId !== undefined ? dto.branchId : u.branchId);
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    // RULE 6: deactivating through PATCH invalidates the sessions immediately,
    // exactly like toggle()/remove() do.
    const deactivating = dto.active === false && u.active === true;
    if (deactivating) {
      await this.revokeSessions(u.id);
      await this.auditAction(gymId, actor, 'staff_deactivated', u, { via: 'patch' });
    }
    // RULE 5: role changes are audit-logged (the @Audit decorator also logs).
    const roleChanging = !!dto.role && dto.role !== u.role;
    // FIX: never write a raw password into passwordHash — hash it like create() does.
    const { password, ...rest } = dto;
    const updated = await this.prisma.user.update({
      where: { id, gymId },
      data: { ...rest, ...(password ? { passwordHash: await argon2.hash(password) } : {}) },
      select: { id: true, name: true, phone: true, role: true, branchId: true, active: true },
    });
    if (roleChanging) {
      await this.auditAction(gymId, actor, 'staff_role_change', u, {
        fromRole: u.role,
        toRole: dto.role,
        actorRole: actor?.role,
      });
    }
    return updated;
  }

  /**
   * ROUND 14 (security review, PHASE A): self-service profile updates. The
   * OWNER account is untouchable through staff management (OWNER_PROTECTED),
   * so an owner edits their own name/phone/password HERE instead. Only the
   * actor's own row is touched; a password change requires the current
   * password (same rule as POST /auth/change-password). No role, email,
   * branch or active changes are possible through this endpoint.
   */
  async updateSelf(gymId: string, userId: string, dto: UpdateSelfProfileDto) {
    const u = await this.prisma.user.findFirst({ where: { id: userId, gymId } });
    if (!u) throw new NotFoundException('User not found');
    const data: Record<string, unknown> = {};
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.phone !== undefined) data.phone = dto.phone;
    if (dto.password !== undefined) {
      if (!dto.currentPassword) {
        throw new BadRequestException('Current password is required to set a new password');
      }
      const ok = await argon2.verify(u.passwordHash, dto.currentPassword);
      if (!ok) {
        throw new ForbiddenException({
          code: 'CURRENT_PASSWORD_INVALID',
          message: 'Current password is incorrect.',
        });
      }
      data.passwordHash = await argon2.hash(dto.password);
    }
    if (!Object.keys(data).length) throw new BadRequestException('Nothing to update');
    const updated = await this.prisma.user.update({
      where: { id: u.id },
      data,
      select: { id: true, name: true, phone: true, role: true, branchId: true, active: true },
    });
    await this.auditAction(gymId, { id: u.id, role: u.role }, 'staff_self_profile_update', u, {
      fields: Object.keys(data).map((k) => (k === 'passwordHash' ? 'password' : k)),
    });
    return updated;
  }

  /**
   * Phase 4 (4.4): dedicated staff-to-branch assignment. Branch assignment is
   * NOT collected during onboarding any more — it is managed here, from the
   * dashboard staff page, against branches that actually exist. Passing null
   * un-assigns the employee ("all branches").
   */
  async assignBranch(gymId: string, id: string, branchId: string | null, actor?: StaffActor) {
    const u = await this.prisma.user.findFirst({ where: { id, gymId } });
    if (!u) throw new NotFoundException('User not found');
    // RULE 2 (+ no self re-assignment: moving yourself to another branch would
    // be a self-granted data-scope escalation).
    this.assertCanActOn(actor, u);
    if (actor && id === actor.id) {
      throw new ForbiddenException({
        code: 'SELF_FORBIDDEN',
        message: 'You cannot change your own branch assignment.',
      });
    }
    this.assertBranchForRole(u.role, branchId);
    if (branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    return this.prisma.user.update({
      where: { id, gymId },
      data: { branchId },
      select: { id: true, branchId: true },
    });
  }

  async toggle(gymId: string, id: string, actor?: StaffActor) {
    const u = await this.prisma.user.findFirst({ where: { id, gymId } });
    if (!u) throw new NotFoundException('User not found');
    // RULE 3: nobody may deactivate the OWNER, nor themselves.
    this.assertCanDeactivate(actor, u);
    const nextActive = !u.active;
    const updated = await this.prisma.user.update({ where: { id, gymId }, data: { active: nextActive }, select: { id: true, active: true } });
    // Deactivating an employee must invalidate their sessions IMMEDIATELY
    // (ROUND 13 Phase 5): the JwtStrategy re-checks the active flag on every
    // request; here we also revoke every refresh-token family so
    // /auth/refresh cannot mint a new session either.
    if (!nextActive) {
      await this.revokeSessions(u.id);
      await this.auditAction(gymId, actor, 'staff_deactivated', u, { via: 'toggle' });
    } else {
      await this.auditAction(gymId, actor, 'staff_activated', u, { via: 'toggle' });
    }
    return updated;
  }

  async remove(gymId: string, id: string, actor?: StaffActor) {
    const u = await this.prisma.user.findFirst({ where: { id, gymId } });
    if (!u) throw new NotFoundException('User not found');
    // RULE 3: nobody may delete the OWNER, nor themselves.
    this.assertCanDeactivate(actor, u);
    await this.prisma.user.update({ where: { id, gymId }, data: { active: false } });
    // Same immediate invalidation as toggle-off.
    await this.revokeSessions(u.id);
    await this.auditAction(gymId, actor, 'staff_deactivated', u, { via: 'delete' });
    return { ok: true };
  }
}
