/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE P3 — the GLOBAL licence state, kept in process memory.
 *
 * Before this, "can we still serve licensed routes?" was answered only by
 * `license-check.service.ts` at boot and once an hour, and the answer lived in
 * Redis (`…:license:…:last_valid`). Two consequences, both observed:
 *
 *   1. If the licence server was unreachable AND Redis had no grace key, the
 *      service emitted `license.expired`, and `main.ts` responded by closing the
 *      app and calling `process.exit(1)`. A network blip to the licence server
 *      therefore took the whole API down — including `/api/health/live`, which
 *      is what an orchestrator uses to decide whether to restart the container,
 *      so the container was killed for a dependency it does not need to serve
 *      that answer.
 *   2. Because the grace period lived in Redis, a Redis outage destroyed the
 *      grace period: `checkGracePeriod()` caught the Redis error, logged "System
 *      continues" and returned TRUE (fail-open). So losing Redis silently turned
 *      "we could not verify the licence" into "the licence is fine".
 *
 * This service is the single in-memory source of truth for that state:
 *
 *   - `markVerified()`   an authoritative verification succeeded. Clears any
 *                        unverified state immediately, with no restart.
 *   - `markUnverified()` the licence could not be verified (server unreachable,
 *                        DNS, TLS, timeout) or the grace record could not be
 *                        read. Starts/keeps an in-memory grace window; when the
 *                        window expires the state becomes `unverified`, and the
 *                        LicenceAvailabilityGuard answers 503 + Retry-After on
 *                        every licensed route until verification succeeds again.
 *   - `markRefused()`    an authoritative REVOKED/EXPIRED verdict. This keeps the
 *                        pre-P3 behaviour: `license.expired` is emitted and the
 *                        process shuts down. An UNREACHABLE licence server must
 *                        never be able to produce this state — that is the
 *                        fail-closed direction that matters, and it is tested.
 *
 * The grace window is deliberately in memory and NOT in Redis: the whole point is
 * that a Redis outage cannot erase it (and cannot manufacture it either — the
 * window only ever starts when a verification attempt actually failed).
 */
import { Injectable, Logger } from '@nestjs/common';

export type LicenceState = 'unknown' | 'verified' | 'unverified' | 'refused';

/**
 * How long the process keeps serving licensed routes after verification starts
 * failing, before it fails closed. Documented because it is a policy decision an
 * operator has to be able to reason about: long enough to ride out a licence
 * server restart or a DNS blip, short enough that a genuinely cut-off
 * deployment stops serving licensed work the same day.
 */
export const LICENCE_GRACE_MS = Number(process.env.LICENCE_GRACE_MS || 48 * 60 * 60 * 1000); // 48 h, matching the pre-P3 Redis grace record
/** How often the guard may log the same state transition (noise control). */
const LOG_THROTTLE_MS = 60_000;

@Injectable()
export class LicenceStateService {
  private readonly logger = new Logger('LicenceState');
  private state: LicenceState = 'unknown';
  private stateSince = Date.now();
  /** When the current run of failed verifications started (0 = none). */
  private failingSince = 0;
  private lastVerifiedAt = 0;
  private lastReason = '';
  private lastLogAt = 0;

  getState(): LicenceState {
    return this.state;
  }

  /** True when licensed routes must be refused with 503 + Retry-After. */
  isUnverified(): boolean {
    return this.state === 'unverified';
  }

  /**
   * The only question enforcement needs: may this process serve licensed routes
   * right now? True solely after an authoritative verification succeeded, so a
   * freshly booted process (`unknown`) and a refused one both answer false.
   */
  isServingLicensedRoutes(): boolean {
    return this.state === 'verified';
  }

  /** True when the licence was authoritatively refused (revoked/expired). */
  isRefused(): boolean {
    return this.state === 'refused';
  }

  /**
   * Seconds until the in-memory grace window expires, or 0 once it has.
   * Exposed so `/api/health/ready` can REPORT the state without blocking on it.
   */
  graceRemainingSeconds(): number {
    // No last-known-good means no grace to report: the state fails closed
    // immediately, so the honest answer is 0 and not "48 h of window left".
    if (this.lastVerifiedAt === 0) return 0;
    if (!this.failingSince) return Math.round(LICENCE_GRACE_MS / 1000);
    const elapsed = Date.now() - this.failingSince;
    return Math.max(0, Math.round((LICENCE_GRACE_MS - elapsed) / 1000));
  }

  /**
   * Reasons end up in logs and in the (authenticated) health snapshot, so they
   * are reduced to a short classification: no URL, no licence key, no token.
   */
  private sanitise(reason: string): string {
    return String(reason || '')
      .replace(/https?:\/\/\S+/gi, 'url-redacted')
      .replace(/\bFLEX-[A-Za-z0-9-]+/g, 'key-redacted')
      .replace(/[A-Za-z0-9+/]{32,}={0,2}/g, 'secret-redacted')
      .slice(0, 80);
  }

  snapshot(): { state: LicenceState; since: number; lastVerifiedAt: number; graceRemainingSeconds: number; reason: string } {
    return {
      state: this.state,
      since: this.stateSince,
      lastVerifiedAt: this.lastVerifiedAt,
      graceRemainingSeconds: this.graceRemainingSeconds(),
      // a short, non-secret reason ("unreachable", "redis-unavailable") — never a
      // URL, key, token or licence detail
      reason: this.lastReason,
    };
  }

  markVerified(source = 'licence-server'): void {
    const was = this.state;
    this.failingSince = 0;
    this.lastVerifiedAt = Date.now();
    this.lastReason = '';
    if (this.state !== 'verified') {
      this.state = 'verified';
      this.stateSince = Date.now();
      this.logger.log(`licence verified (${source}) — state ${was} -> verified; licensed routes served normally`);
    }
  }

  /**
   * Record a failed verification. Returns true when the grace window has now
   * expired, i.e. when the caller must fail closed.
   */
  markUnverified(reason: string): boolean {
    // A REFUSAL is sticky in this direction: an authoritative REVOKED/EXPIRED
    // verdict must never be downgraded to "we could not check" by a later
    // transport failure. (markVerified can still clear it — that is an
    // authoritative verdict from the licence server, which is the only thing
    // allowed to un-refuse a licence.)
    if (this.state === 'refused') {
      this.lastReason = this.lastReason || this.sanitise(reason);
      return true;
    }
    const now = Date.now();
    if (!this.failingSince) this.failingSince = now;
    this.lastReason = this.sanitise(reason);
    // A grace period protects a state the process ACTUALLY observed. If this
    // process has never verified the licence (it booted with the licence server
    // and/or Redis unreachable), there is no last-known-good to serve from and
    // nothing to be gracious about: fail closed immediately. When it HAS
    // verified before, the window matches the pre-P3 Redis grace record (48 h)
    // and starts at the first failure, so it can never expire EARLIER than the
    // grace this deployment already had.
    const expired = this.lastVerifiedAt === 0 || now - this.failingSince >= LICENCE_GRACE_MS;
    if (expired && this.state !== 'unverified') {
      this.state = 'unverified';
      this.stateSince = now;
      this.throttledWarn(
        `licence could not be verified for ${Math.round((now - this.failingSince) / 60000)}min ` +
          `(reason: ${this.lastReason}); grace period of ${Math.round(LICENCE_GRACE_MS / 3600000)}h exhausted — ` +
          `failing CLOSED: licensed routes answer 503 + Retry-After until verification succeeds`,
      );
    } else if (!expired) {
      this.throttledWarn(
        `licence verification failed (reason: ${this.lastReason}); serving from the in-memory grace window, ` +
          `${this.graceRemainingSeconds()}s left before licensed routes fail closed`,
      );
    }
    return expired;
  }

  /** Authoritative REVOKED/EXPIRED: no grace, fail closed immediately. */
  markRefused(reason: string): void {
    this.failingSince = 0;
    this.lastReason = this.sanitise(reason);
    if (this.state !== 'refused') {
      this.state = 'refused';
      this.stateSince = Date.now();
      this.logger.error(`licence REFUSED by the licence server (${this.lastReason}) — no grace period applies`);
    }
  }

  private throttledWarn(message: string): void {
    const now = Date.now();
    if (now - this.lastLogAt < LOG_THROTTLE_MS) return;
    this.lastLogAt = now;
    this.logger.warn(message);
  }
}
