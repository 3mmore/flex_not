import { Controller, Get, UseGuards } from '@nestjs/common';
import { LicenseService } from './license.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';

@Controller('license')
@UseGuards(JwtAuthGuard, TenantGuard)
export class LicenseController {
  constructor(private readonly svc: LicenseService) {}

  @Get('status') @Permissions('billing.manage')
  getStatus(@GymId() gymId: string) {
    return this.svc.getStatus(gymId);
  }
}
