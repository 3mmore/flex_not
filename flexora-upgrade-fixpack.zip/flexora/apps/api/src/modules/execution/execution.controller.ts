/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Autonomous Execution endpoints. All tenant-isolated (gymId from token),
 * owner/manager only. Read + run + outcome + rollback + approval gating.
 */
import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { IntegrationBrandingGuard } from '../../common/guards/integration-branding.guard';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsEnum, IsIn, IsInt, IsOptional, IsString, Max, Min } from 'class-validator';
import { AutonomousActionStatus, AutonomousOutcome } from '@prisma/client';
import { ExecutionService } from './execution.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class ChurnDto {
  @IsInt() @Min(0) @Max(100) churnRisk!: number;
  @IsOptional() @IsString() memberId?: string;
  @IsOptional() @IsString() bestCoachUserId?: string;
  @IsOptional() @IsString() bestCoachLabel?: string;
}
class RevenueDto {
  revenueTrendDown!: boolean;
  @IsOptional() @IsString() ownerUserId?: string;
  @IsOptional() segments?: string[];
}
class UtilizationDto {
  @IsInt() @Min(0) @Max(100) utilization!: number;
  @IsInt() @Min(0) staffCount!: number;
  @IsOptional() @IsString() opsManagerUserId?: string;
}
class RecoveryDto {
  @IsString() memberId!: string;
  @IsIn(['expired', 'frozen', 'inactive']) status!: 'expired' | 'frozen' | 'inactive';
  @IsOptional() @IsString() ownerUserId?: string;
}
class MeasureDto {
  @IsEnum(AutonomousOutcome)
  outcome!: AutonomousOutcome;
  @IsOptional() @IsString() note?: string;
}
class RevertDto { @IsOptional() @IsString() reason?: string; }
class ApprovalDto { @IsEnum(AutonomousActionStatus) decision!: AutonomousActionStatus; }

@ApiTags('execution')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('execution')
export class ExecutionController {
  constructor(private readonly svc: ExecutionService) {}

  // ---- Audit / read ----
  @Get('actions') @Permissions('reports.view')
  list(@GymId() gymId: string, @Query('flow') flow?: string, @Query('status') status?: AutonomousActionStatus, @Query('outcome') outcome?: AutonomousOutcome) {
    return this.svc.list(gymId, { flow, status, outcome });
  }
  @Get('actions/:id') @Permissions('reports.view')
  get(@GymId() gymId: string, @Param('id') id: string) { return this.svc.get(gymId, id); }

  // ---- Run autonomous flows (Level 2) ----
  @Post('churn') @Permissions('reports.view') @Audit('autonomous_churn', 'AutonomousAction')
  churn(@GymId() gymId: string, @Body() dto: ChurnDto) { return this.svc.runChurnFlow({ gymId, ...dto }); }

  @Post('revenue') @Permissions('reports.view') @Audit('autonomous_revenue', 'AutonomousAction')
  revenue(@GymId() gymId: string, @Body() dto: RevenueDto) { return this.svc.runRevenueFlow({ gymId, ...dto }); }

  @Post('utilization') @Permissions('reports.view') @Audit('autonomous_utilization', 'AutonomousAction')
  utilization(@GymId() gymId: string, @Body() dto: UtilizationDto) { return this.svc.runUtilizationFlow({ gymId, ...dto }); }

  @Post('recovery') @Permissions('reports.view') @Audit('autonomous_recovery', 'AutonomousAction')
  recovery(@GymId() gymId: string, @Body() dto: RecoveryDto) { return this.svc.runRecoveryFlow({ gymId, ...dto }); }

  // ---- Outcome tracking ----
  @Post('actions/:id/measure') @Permissions('reports.view') @Audit('measure', 'AutonomousAction')
  measure(@GymId() gymId: string, @Param('id') id: string, @Body() dto: MeasureDto) {
    return this.svc.measure(gymId, id, dto.outcome, dto.note);
  }

  // ---- Rollback / reversal ----
  @Post('actions/:id/revert') @Permissions('reports.view') @Audit('revert', 'AutonomousAction')
  revert(@GymId() gymId: string, @Param('id') id: string, @Body() dto: RevertDto) {
    return this.svc.revert(gymId, id, dto.reason);
  }

  // ---- Approval gating (high-impact) ----
  @Post('actions/:id/approval') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('approval', 'AutonomousAction')
  approval(@GymId() gymId: string, @Param('id') id: string, @Body() dto: ApprovalDto, @CurrentUser('name') actor: string) {
    return this.svc.resolveApproval(gymId, id, dto.decision, actor);
  }
}
