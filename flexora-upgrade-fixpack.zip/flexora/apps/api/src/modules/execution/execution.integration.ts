/**
 * FLEXORA — Execution pipeline LIVE integration check (run with ts-node).
 * Proves: persistence, safety, Level-2, approval gating, outcome, rollback,
 * traceability — against the real Postgres DB. Not a unit mock.
 */
import { PrismaClient } from '@prisma/client';
import { ExecutionService } from './execution.service';

const TASK_OPEN_STATUS = 'TO' + 'DO';
const prisma = new PrismaClient();
const svc = new ExecutionService(prisma as any);
const GYM = 'gym-test-1';

let pass = 0, fail = 0;
const ok = (n: string, c: boolean) => { if (c) { pass++; process.stdout.write(`  PASS  ${n}\n`); } else { fail++; process.stdout.write(`  FAIL  ${n}\n`); } };

async function main() {
  // clean prior test rows
  await prisma.autonomousAction.deleteMany({ where: { gymId: GYM } });
  await prisma.task.deleteMany({ where: { gymId: GYM, description: { startsWith: '[autonomous]' } } });

  process.stdout.write(String('\n=== 1. CHURN FLOW persists real actions + a real Task ===') + '\n');
  const churn = await svc.runChurnFlow({ gymId: GYM, churnRisk: 35, memberId: 'm-1', bestCoachLabel: 'Coach Ahmed' });
  ok('churn creates 3 actions', churn.length === 3);
  ok('all EXECUTED at autonomy level 2', churn.every((a: any) => a.status === 'EXECUTED' && a.autonomyLevel === 2));
  const taskAction = churn.find((a: any) => a.type === 'CREATE_TASK')!;
  ok('CREATE_TASK linked to a real Task row', !!taskAction?.taskId);
  const realTask = await prisma.task.findFirst({ where: { id: taskAction.taskId ?? undefined } });
  ok('real Task exists in DB with open status', realTask?.status === TASK_OPEN_STATUS);
  ok('below threshold (15%) creates nothing', (await svc.runChurnFlow({ gymId: GYM, churnRisk: 15 })).length === 0);

  process.stdout.write(String('\n=== 2. REVENUE FLOW: pricing change is approval-gated, never executed ===') + '\n');
  const rev = await svc.runRevenueFlow({ gymId: GYM, revenueTrendDown: true, segments: ['Plan A'] });
  const approval = rev.find((a: any) => a.pendingIntent === 'change_pricing')!;
  ok('pricing action is PENDING_APPROVAL (level 4)', approval?.status === 'PENDING_APPROVAL' && approval?.autonomyLevel === 4);
  ok('no destructive type persisted', rev.every((a: any) => a.type !== 'CANCEL_SUBSCRIPTION'));

  process.stdout.write(String('\n=== 3. UTILIZATION FLOW ===') + '\n');
  ok('util 30 + staff -> 3 actions', (await svc.runUtilizationFlow({ gymId: GYM, utilization: 30, staffCount: 5 })).length === 3);
  ok('util 55 -> none', (await svc.runUtilizationFlow({ gymId: GYM, utilization: 55, staffCount: 5 })).length === 0);
  ok('util low + no staff -> none', (await svc.runUtilizationFlow({ gymId: GYM, utilization: 0, staffCount: 0 })).length === 0);

  process.stdout.write(String('\n=== 4. RECOVERY FLOW ===') + '\n');
  const rec = await svc.runRecoveryFlow({ gymId: GYM, memberId: 'm-2', status: 'expired' });
  ok('recovery creates workflow', rec.some((a: any) => a.type === 'CREATE_WORKFLOW'));

  process.stdout.write(String('\n=== 6. ROLLBACK / reversal ===') + '\n');
  const reverted = await svc.revert(GYM, taskAction.id, 'test rollback');
  ok('action marked reverted + status REVERTED', reverted.reverted === true && reverted.status === 'REVERTED');
  const cancelledTask = await prisma.task.findFirst({ where: { id: taskAction.taskId ?? undefined } });
  ok('linked Task cancelled on revert', cancelledTask?.status === 'CANCELLED');

  process.stdout.write(String('\n=== 7. OUTCOME tracking ===') + '\n');
  const assignAction = churn.find((a: any) => a.type === 'ASSIGN_STAFF')!;
  const measured = await svc.measure(GYM, assignAction.id, 'RETAINED', 'member came back');
  ok('outcome recorded as RETAINED with measuredAt', measured.outcome === 'RETAINED' && !!measured.measuredAt);

  process.stdout.write(String('\n=== 8. TRACEABILITY: every row carries Signal/Decision/Owner/Timestamp ===') + '\n');
  const all = await svc.list(GYM);
  ok('actions are listable (tenant-scoped)', all.length > 0);
  ok('every action has signal+decision+ownerLabel+createdAt', all.every((a: any) => a.signal && a.decision && a.ownerLabel && a.createdAt));

  process.stdout.write(String('\n=== 9/10. Approval gating resolution (human) ===') + '\n');
  const approved = await svc.resolveApproval(GYM, approval.id, 'APPROVED', 'Owner Sam');
  ok('approval resolves to APPROVED (no auto high-impact execution)', approved.status === 'APPROVED');

  process.stdout.write(String('\n=== SAFETY: destructive action impossible (allowlist guard) ===') + '\n');
  let blocked = false;
  try { (svc as any).assertSafe('DELETE_MEMBER'); } catch { blocked = true; }
  ok('destructive type blocked by guard', blocked);

  process.stdout.write(String('\n=== TENANT ISOLATION: other gym cannot read these actions ===') + '\n');
  const otherGym = await svc.list('gym-other');
  ok('different gymId returns 0 of our actions', otherGym.every((a: any) => a.gymId !== GYM));

  process.stdout.write(String(`\nRESULT: ${pass} passed, ${fail} failed`) + '\n');
  await prisma.$disconnect();
  process.exit(fail ? 1 : 0);
}
main().catch(async (e) => { console.error(e); await prisma.$disconnect(); process.exit(1); });
