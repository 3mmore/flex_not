/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { CreateProductDto, UpdateProductDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('products')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('products')
export class ProductsController {
  constructor(private readonly svc: ProductsService) {}
  @Get() @Permissions('inventory.view') list(@GymId() g: string, @Query('q') q?: string, @Query('category') c?: string) { return this.svc.list(g, q, c); }
  @Get('stats') @Permissions('inventory.view') stats(@GymId() g: string, @Query('branchId') branchId?: string) { return this.svc.stats(g, branchId); }
  @Post() @Permissions('inventory.manage') @Audit('create','Product') create(@GymId() g: string, @Body() d: CreateProductDto) { return this.svc.create(g, d); }
  @Patch(':id') @Permissions('inventory.manage') @Audit('update','Product') update(@GymId() g: string, @Param('id') id: string, @Body() d: UpdateProductDto) { return this.svc.update(g, id, d); }
  @Delete(':id') @Permissions('inventory.manage') @Audit('delete','Product') remove(@GymId() g: string, @Param('id') id: string) { return this.svc.remove(g, id); }
}
