/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ProductsService } from './products.service';
import { ProductsController } from './products.controller';
@Module({ imports: [JwtModule.register({})], controllers: [ProductsController], providers: [ProductsService] })
export class ProductsModule {}
