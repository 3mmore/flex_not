/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.4 / review item 1 — the platform session service.
 *
 * The properties that matter here are the ones an attacker probes: a tenant token
 * must not verify, a revoked session must die immediately, idle and absolute
 * expiry must both be real, rotation must not smuggle an enrolment exemption, and
 * the database must never hold something presentable.
 */
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../config/prisma.service';
import {
  PLATFORM_ABSOLUTE_TIMEOUT_MS,
  PLATFORM_IDLE_TIMEOUT_MS,
  PLATFORM_STEP_UP_TTL_MS,
  PLATFORM_TOKEN_AUDIENCE,
  PLATFORM_TOKEN_ISSUER,
  PlatformSessionService,
  hashPlatformToken,
  platformCookieOptions,
} from './platform-session.service';
import { platformSecret, resetPlatformSecretCacheForTests } from '../../config/platform-secret';

const ADMIN = { id: 'admin-1', role: 'PLATFORM_ADMIN', email: 'owner@example.com', name: 'Owner', status: 'ACTIVE', lockedUntil: null };

type Row = Record<string, unknown>;

/** A Prisma stub that keeps the session table in memory. */
function makePrisma() {
  const sessions = new Map<string, Row>();
  const prisma = {
    platformSession: {
      create: jest.fn(async ({ data }: { data: Row }) => {
        sessions.set(String(data.id), { ...data });
        return { ...data };
      }),
      findUnique: jest.fn(async ({ where }: { where: { id: string } }) => {
        const row = sessions.get(where.id);
        return row ? { ...row } : null;
      }),
      update: jest.fn(async ({ where, data }: { where: { id: string }; data: Row }) => {
        const row = sessions.get(where.id);
        if (!row) throw new Error('session not found');
        const next = { ...row, ...data };
        sessions.set(where.id, next);
        return { ...next };
      }),
      updateMany: jest.fn(async ({ where, data }: { where: Row; data: Row }) => {
        let count = 0;
        for (const [id, row] of sessions.entries()) {
          if (where.adminId && row.adminId !== where.adminId) continue;
          if (where.revokedAt === null && row.revokedAt) continue;
          sessions.set(id, { ...row, ...data });
          count++;
        }
        return { count };
      }),
      findMany: jest.fn(async () => Array.from(sessions.values())),
      deleteMany: jest.fn(async () => ({ count: 0 })),
    },
    platformAdmin: {
      findUnique: jest.fn(async () => ({ ...ADMIN })),
    },
  };
  return { prisma: prisma as unknown as PrismaService, sessions };
}

function makeService() {
  const { prisma, sessions } = makePrisma();
  const jwt = new JwtService({});
  return { service: new PlatformSessionService(prisma, jwt), sessions, jwt, prisma };
}

beforeEach(() => resetPlatformSecretCacheForTests());

describe('R1.4 platform sessions — 1. the published limits', () => {
  it('1a. idle 15 minutes, absolute 8 hours, step-up 5 minutes', () => {
    expect(PLATFORM_IDLE_TIMEOUT_MS).toBe(15 * 60 * 1000);
    expect(PLATFORM_ABSOLUTE_TIMEOUT_MS).toBe(8 * 60 * 60 * 1000);
    expect(PLATFORM_STEP_UP_TTL_MS).toBe(5 * 60 * 1000);
  });

  it('1b. the cookie is HttpOnly, SameSite=Strict, path=/ and lives no longer than the session', () => {
    const options = platformCookieOptions();
    expect(options.httpOnly).toBe(true);
    expect(options.sameSite).toBe('strict');
    expect(options.path).toBe('/');
    expect(options.maxAge).toBe(PLATFORM_ABSOLUTE_TIMEOUT_MS);
  });

  it('1c. the token audience and issuer are the platform ones', () => {
    expect(PLATFORM_TOKEN_AUDIENCE).toBe('flexora-platform-admin');
    expect(PLATFORM_TOKEN_ISSUER).toBe('flexora-api');
  });
});

describe('R1.4 platform sessions — 2. what is stored', () => {
  it('2a. the row stores a sha256 of the token, never the token', async () => {
    const { service, sessions } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    const row = sessions.get(created.sessionId) as Row;
    expect(row.tokenHash).toBe(hashPlatformToken(created.token));
    expect(String(row.tokenHash)).toHaveLength(64);
    expect(JSON.stringify(row)).not.toContain(created.token);
    expect(created.token.split('.')).toHaveLength(3);
  });

  it('2b. the token names the session, and the row names the administrator', async () => {
    const { service, jwt } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: true });
    const payload = (await jwt.verifyAsync(created.token, {
      secret: platformSecret(),
      algorithms: ['HS256'],
      audience: PLATFORM_TOKEN_AUDIENCE,
      issuer: PLATFORM_TOKEN_ISSUER,
    })) as Record<string, unknown>;
    expect(payload.sid).toBe(created.sessionId);
    expect(payload.sub).toBe(ADMIN.id);
    expect(payload.type).toBe('platform');
  });
});

describe('review item 1 — a tenant credential cannot become a platform session', () => {
  it('3a. a token signed with a different secret is refused', async () => {
    const { service, jwt } = makeService();
    const tenantSigned = await jwt.signAsync(
      { sub: ADMIN.id, sid: 'whatever', role: ADMIN.role, type: 'platform', iss: PLATFORM_TOKEN_ISSUER, aud: PLATFORM_TOKEN_AUDIENCE },
      { secret: ['tenant', 'secret', '0'.repeat(34)].join('-'), algorithm: 'HS256', expiresIn: 3600 },
    );
    const checked = await service.verifyToken(tenantSigned);
    expect(checked.ok).toBe(false);
  });

  it('3b. a token with a tenant audience is refused even when correctly signed', async () => {
    const { service, jwt } = makeService();
    const wrongAudience = await jwt.signAsync(
      { sub: ADMIN.id, sid: 'whatever', role: 'OWNER', type: 'user', iss: 'flexora-api', aud: 'flexora-tenant' },
      { secret: platformSecret(), algorithm: 'HS256', expiresIn: 3600 },
    );
    const checked = await service.verifyToken(wrongAudience);
    expect(checked.ok).toBe(false);
    if (!checked.ok) expect(['wrong-audience', 'bad-signature', 'wrong-type', 'unknown-session']).toContain(checked.reason);
  });

  it('3c. a correctly signed token with no session row is refused', async () => {
    const { service, jwt } = makeService();
    const orphan = await jwt.signAsync(
      { sub: ADMIN.id, sid: 'session-that-was-never-created', role: ADMIN.role, type: 'platform', iss: PLATFORM_TOKEN_ISSUER, aud: PLATFORM_TOKEN_AUDIENCE },
      { secret: platformSecret(), algorithm: 'HS256', expiresIn: 3600 },
    );
    const checked = await service.verifyToken(orphan);
    expect(checked.ok).toBe(false);
    if (!checked.ok) expect(checked.reason).toBe('unknown-session');
  });

  it('3d. a token whose type is not "platform" is refused', async () => {
    const { service, jwt } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    const forged = await jwt.signAsync(
      { sub: ADMIN.id, sid: created.sessionId, role: ADMIN.role, type: 'user', iss: PLATFORM_TOKEN_ISSUER, aud: PLATFORM_TOKEN_AUDIENCE },
      { secret: platformSecret(), algorithm: 'HS256', expiresIn: 3600 },
    );
    const checked = await service.verifyToken(forged);
    expect(checked.ok).toBe(false);
    if (!checked.ok) expect(checked.reason).toBe('wrong-type');
  });

  it('3e. a valid token presented for somebody else\'s session is refused', async () => {
    const { service } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    const tampered = `${created.token.slice(0, created.token.lastIndexOf('.') - 1)}x.${created.token.split('.')[2]}`;
    const checked = await service.verifyToken(tampered);
    expect(checked.ok).toBe(false);
  });

  it('3f. garbage, empty and non-JWT input is refused without throwing', async () => {
    const { service } = makeService();
    for (const value of [null, undefined, '', 'not-a-jwt', 'a.b', '...', Buffer.from('x').toString('base64')]) {
      const checked = await service.verifyToken(value as string);
      expect(checked.ok).toBe(false);
    }
  });
});

describe('R1.4 platform sessions — 4. lifetimes and revocation', () => {
  it('4a. a live session verifies and slides its idle window', async () => {
    const { service, sessions } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    const at = Date.now() + 60_000;
    const checked = await service.verifyToken(created.token, at);
    expect(checked.ok).toBe(true);
    if (checked.ok) {
      expect(checked.admin.email).toBe(ADMIN.email);
      expect((sessions.get(created.sessionId) as Row).idleExpiresAt).toEqual(new Date(at + PLATFORM_IDLE_TIMEOUT_MS));
    }
  });

  it('4b. an idle session is refused after 15 minutes', async () => {
    // Two separate sessions on purpose: a SUCCESSFUL check slides the idle window,
    // which is the required behaviour, so probing "just inside" and then "just
    // outside" on one session would measure the slide rather than the timeout.
    const { service } = makeService();
    const inside = await service.createSession({ admin: ADMIN, totpPending: false });
    const justInside = await service.verifyToken(inside.token, Date.now() + PLATFORM_IDLE_TIMEOUT_MS - 1000);
    expect(justInside.ok).toBe(true);

    const outside = await service.createSession({ admin: ADMIN, totpPending: false });
    const afterIdle = await service.verifyToken(outside.token, Date.now() + PLATFORM_IDLE_TIMEOUT_MS + 1000);
    expect(afterIdle.ok).toBe(false);
    if (!afterIdle.ok) expect(afterIdle.reason).toBe('idle-expired');
  });

  it('4b2. a session that is used keeps sliding, and an abandoned one dies', async () => {
    const { service } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    const start = Date.now();
    // used every 10 minutes for an hour: still alive, well past one idle window
    for (let minute = 10; minute <= 60; minute += 10) {
      const touched = await service.verifyToken(created.token, start + minute * 60 * 1000);
      expect(touched.ok).toBe(true);
    }
    // then abandoned for 16 minutes
    const abandoned = await service.verifyToken(created.token, start + 76 * 60 * 1000);
    expect(abandoned.ok).toBe(false);
    if (!abandoned.ok) expect(abandoned.reason).toBe('idle-expired');
  });

  it('4c. activity cannot extend a session past 8 hours', async () => {
    const { service } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    // keep touching it every 14 minutes for nine hours
    let last = Date.now();
    for (let step = 0; step < 40; step++) {
      last += 14 * 60 * 1000;
      const touched = await service.verifyToken(created.token, last);
      if (!touched.ok) {
        expect(touched.reason).toBe('absolute-expired');
        expect(last - Date.now()).toBeGreaterThan(PLATFORM_ABSOLUTE_TIMEOUT_MS - PLATFORM_IDLE_TIMEOUT_MS);
        return;
      }
    }
    throw new Error('the session never hit its absolute expiry');
  });

  it('4d. revocation takes effect on the very next request', async () => {
    const { service } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    expect((await service.verifyToken(created.token)).ok).toBe(true);
    await service.revoke(created.sessionId, 'logout');
    const after = await service.verifyToken(created.token);
    expect(after.ok).toBe(false);
    if (!after.ok) expect(after.reason).toBe('revoked');
  });

  it('4e. revoking every session for an administrator ends all of them', async () => {
    const { service } = makeService();
    const first = await service.createSession({ admin: ADMIN, totpPending: false });
    const second = await service.createSession({ admin: ADMIN, totpPending: false });
    const result = await service.revokeAllForAdmin(ADMIN.id, 'admin-removed');
    expect(result.count).toBe(2);
    expect((await service.verifyToken(first.token)).ok).toBe(false);
    expect((await service.verifyToken(second.token)).ok).toBe(false);
  });

  it('4f. a removed or locked administrator loses access immediately', async () => {
    const { service, prisma } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    (prisma.platformAdmin.findUnique as jest.Mock).mockResolvedValueOnce({ ...ADMIN, status: 'REMOVED' });
    const removed = await service.verifyToken(created.token);
    expect(removed.ok).toBe(false);
    if (!removed.ok) expect(removed.reason).toBe('admin-not-active');

    (prisma.platformAdmin.findUnique as jest.Mock).mockResolvedValueOnce({ ...ADMIN, lockedUntil: new Date(Date.now() + 60_000) });
    const locked = await service.verifyToken(created.token);
    expect(locked.ok).toBe(false);
    if (!locked.ok) expect(locked.reason).toBe('admin-locked');
  });

  it('4g. rotation issues a new token, kills the old one and keeps the enrolment state', async () => {
    const { service, sessions } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: true });
    const row = sessions.get(created.sessionId) as Row;
    const rotated = await service.rotate({ session: row as never, admin: ADMIN as never, reason: 'step-up-rotation' });
    expect(rotated.token).not.toBe(created.token);
    expect((await service.verifyToken(created.token)).ok).toBe(false);
    const fresh = await service.verifyToken(rotated.token);
    expect(fresh.ok).toBe(true);
    // Rotating must never be a way to skip TOTP enrolment.
    expect((sessions.get(rotated.sessionId) as Row).totpPending).toBe(true);
  });
});

describe('R1.5 step-up claims', () => {
  it('5a. a claim is valid for five minutes and then is not', async () => {
    const { service } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    expect(service.stepUpIsValid({ stepUpExpiresAt: null })).toBe(false);
    const at = Date.now();
    await service.recordStepUp(created.sessionId, at);
    const expiresAt = new Date(at + PLATFORM_STEP_UP_TTL_MS);
    // valid one second before the claim expires, invalid one second after
    expect(service.stepUpIsValid({ stepUpExpiresAt: expiresAt }, at + PLATFORM_STEP_UP_TTL_MS - 1000)).toBe(true);
    expect(service.stepUpIsValid({ stepUpExpiresAt: expiresAt }, at + PLATFORM_STEP_UP_TTL_MS + 1000)).toBe(false);
    expect(service.stepUpIsValid({ stepUpExpiresAt: null }, at)).toBe(false);
  });

  it('5b. a spent claim can be cleared so it cannot be reused', async () => {
    const { service, sessions } = makeService();
    const created = await service.createSession({ admin: ADMIN, totpPending: false });
    await service.recordStepUp(created.sessionId);
    expect((sessions.get(created.sessionId) as Row).stepUpExpiresAt).toBeTruthy();
    await service.clearStepUp(created.sessionId);
    expect((sessions.get(created.sessionId) as Row).stepUpExpiresAt).toBeNull();
  });
});
