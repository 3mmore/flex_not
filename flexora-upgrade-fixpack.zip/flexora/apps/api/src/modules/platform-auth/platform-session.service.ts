/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.4 — revocable server-side console sessions.
 *
 * Before R1 the console cookie was a stateless JWT signed with the TENANT access
 * secret and valid for 8 h (platform-auth.service.ts:15, measured in
 * work/r1-evidence/00-before.log B7.5/B7.8). Nothing could revoke it: logging out
 * was a client-side cookie deletion, a removed administrator kept access for up to
 * eight hours, and there was no idle timeout at all.
 *
 * Now the cookie still carries a signed token — so the console stays stateless to
 * read — but the token names a PlatformSession row, and THAT row is the authority:
 *
 *   - 15 minutes idle, slid on every accepted request;
 *   - 8 hours absolute, never slid;
 *   - revocation is a single UPDATE and takes effect on the next request;
 *   - step-up (R1.5) is a claim on the session, so it dies with the session and
 *     cannot be replayed from another device;
 *   - only the sha256 of the token is stored, so a database leak yields nothing
 *     an attacker can present.
 *
 * The token is signed with JWT_PLATFORM_SECRET (config/platform-secret.ts), which
 * the boot validator refuses to let equal any tenant secret — so a tenant token is
 * not merely rejected by a role check, it cannot be verified here at all.
 */
import { createHash, randomBytes } from 'crypto';
import { Injectable, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import type { PlatformAdmin, PlatformSession } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { isCookieSecure } from '../../config/cookie-secure';
import { platformSecret } from '../../config/platform-secret';

/** Idle timeout: a console left open on a phone locks itself (R1.4). */
export const PLATFORM_IDLE_TIMEOUT_MS = 15 * 60 * 1000;
/** Absolute timeout: no session outlives this, however active it is. */
export const PLATFORM_ABSOLUTE_TIMEOUT_MS = 8 * 60 * 60 * 1000;
/** How long a step-up assertion authorises the sensitive actions in R1.5. */
export const PLATFORM_STEP_UP_TTL_MS = 5 * 60 * 1000;

export const PLATFORM_COOKIE_NAME = 'flx_platform_token';
/** Readable double-submit partner for the CSRF check (R1.6). Not httpOnly: the
 *  console's own script must be able to read it and echo it back in a header. */
export const PLATFORM_CSRF_COOKIE_NAME = 'flx_platform_csrf';
export const PLATFORM_CSRF_HEADER = 'x-csrf-token';

export const PLATFORM_TOKEN_AUDIENCE = 'flexora-platform-admin';
export const PLATFORM_TOKEN_ISSUER = 'flexora-api';
export const PLATFORM_TOKEN_TYPE = 'platform';

export interface PlatformTokenPayload {
  sub: string;
  sid: string;
  role: string;
  email?: string;
  name?: string;
  type: string;
  jti: string;
  iss: string;
  aud: string;
  iat?: number;
  exp?: number;
}

export type SessionRefusal =
  | 'malformed'
  | 'bad-signature'
  | 'wrong-audience'
  | 'wrong-type'
  | 'unknown-session'
  | 'revoked'
  | 'idle-expired'
  | 'absolute-expired'
  | 'admin-missing'
  | 'admin-not-active'
  | 'admin-locked'
  | 'token-session-mismatch';

export type SessionCheck =
  | { ok: true; session: PlatformSessionRow; admin: PlatformAdminRow; payload: PlatformTokenPayload }
  | { ok: false; reason: SessionRefusal };

// The generated Prisma model types, so a row read here and a row passed to a
// guard are the same type and cannot drift apart.
type PlatformSessionRow = PlatformSession;
type PlatformAdminRow = PlatformAdmin;

/** sha256 of the presented token. The database never stores the token itself. */
export function hashPlatformToken(token: string): string {
  return createHash('sha256').update(String(token ?? ''), 'utf8').digest('hex');
}

/** The cookie options for every platform cookie, in one place (R1.4). */
export function platformCookieOptions(maxAgeMs: number = PLATFORM_ABSOLUTE_TIMEOUT_MS) {
  return {
    httpOnly: true,
    secure: isCookieSecure(),
    sameSite: 'strict' as const,
    path: '/',
    maxAge: maxAgeMs,
  };
}

@Injectable()
export class PlatformSessionService {
  private readonly logger = new Logger(PlatformSessionService.name);

  constructor(private readonly prisma: PrismaService, private readonly jwt: JwtService) {}

  /**
   * Create a session and the token that carries it. `totpPending` is true when
   * the administrator has not finished TOTP enrolment, and it is what makes the
   * enrolment gate (R1.1) survive a restart: the state lives in the row, not in
   * the token, so it cannot be edited out by the client.
   */
  async createSession(params: {
    admin: { id: string; role: string; email: string; name?: string | null };
    totpPending: boolean;
    ip?: string | null;
    userAgent?: string | null;
    atMs?: number;
  }): Promise<{ token: string; sessionId: string; expiresAt: Date; idleExpiresAt: Date }> {
    const now = params.atMs ?? Date.now();
    const expiresAt = new Date(now + PLATFORM_ABSOLUTE_TIMEOUT_MS);
    const idleExpiresAt = new Date(now + PLATFORM_IDLE_TIMEOUT_MS);
    const sessionId = randomBytes(16).toString('hex');

    const token = await this.jwt.signAsync(
      {
        sub: params.admin.id,
        sid: sessionId,
        role: params.admin.role,
        email: params.admin.email,
        name: params.admin.name ?? undefined,
        type: PLATFORM_TOKEN_TYPE,
        jti: randomBytes(16).toString('hex'),
        iss: PLATFORM_TOKEN_ISSUER,
        aud: PLATFORM_TOKEN_AUDIENCE,
      },
      {
        secret: platformSecret(),
        algorithm: 'HS256',
        expiresIn: Math.floor(PLATFORM_ABSOLUTE_TIMEOUT_MS / 1000),
      },
    );

    await this.prisma.platformSession.create({
      data: {
        id: sessionId,
        adminId: params.admin.id,
        tokenHash: hashPlatformToken(token),
        createdAt: new Date(now),
        lastSeenAt: new Date(now),
        expiresAt,
        idleExpiresAt,
        ip: params.ip ?? null,
        userAgent: params.userAgent ? String(params.userAgent).slice(0, 300) : null,
        totpPending: params.totpPending,
      },
    });

    return { token, sessionId, expiresAt, idleExpiresAt };
  }

  /**
   * Validate a presented token end to end. Every refusal is named internally so
   * it can be audit-logged and tested, but the guard collapses all of them into
   * one 401: an attacker must not be able to distinguish "unknown session" from
   * "idle-expired" from "wrong audience".
   */
  async verifyToken(token: string | null | undefined, atMs: number = Date.now()): Promise<SessionCheck> {
    if (!token || typeof token !== 'string' || !token.includes('.')) return { ok: false, reason: 'malformed' };

    let payload: PlatformTokenPayload;
    try {
      payload = (await this.jwt.verifyAsync(token, {
        secret: platformSecret(),
        algorithms: ['HS256'],
        audience: PLATFORM_TOKEN_AUDIENCE,
        issuer: PLATFORM_TOKEN_ISSUER,
      })) as PlatformTokenPayload;
    } catch (error) {
      const message = String((error as Error)?.name ?? error);
      // jsonwebtoken reports audience/issuer mismatches distinctly; both must not
      // become a distinguishable answer at the HTTP layer, but they are useful here.
      return { ok: false, reason: message === 'JsonWebTokenError' ? 'wrong-audience' : 'bad-signature' };
    }
    if (!payload || payload.type !== PLATFORM_TOKEN_TYPE) return { ok: false, reason: 'wrong-type' };
    if (!payload.sid || !payload.sub) return { ok: false, reason: 'malformed' };

    const session = await this.prisma.platformSession.findUnique({ where: { id: payload.sid } });
    if (!session) return { ok: false, reason: 'unknown-session' };
    if (session.tokenHash !== hashPlatformToken(token)) return { ok: false, reason: 'token-session-mismatch' };
    if (session.revokedAt) return { ok: false, reason: 'revoked' };
    if (session.idleExpiresAt.getTime() <= atMs) return { ok: false, reason: 'idle-expired' };
    if (session.expiresAt.getTime() <= atMs) return { ok: false, reason: 'absolute-expired' };

    const admin = await this.prisma.platformAdmin.findUnique({ where: { id: session.adminId } });
    if (!admin) return { ok: false, reason: 'admin-missing' };
    if (admin.status !== 'ACTIVE') return { ok: false, reason: 'admin-not-active' };
    if (admin.lockedUntil && admin.lockedUntil.getTime() > atMs) return { ok: false, reason: 'admin-locked' };
    if (payload.sub !== admin.id) return { ok: false, reason: 'token-session-mismatch' };

    // The session is live: slide the idle window. One indexed UPDATE per request
    // is affordable for an owner console and is what makes the 15-minute idle
    // timeout exact rather than approximate.
    const idleExpiresAt = new Date(atMs + PLATFORM_IDLE_TIMEOUT_MS);
    const touched = await this.prisma.platformSession.update({
      where: { id: session.id },
      data: { lastSeenAt: new Date(atMs), idleExpiresAt },
    });

    return { ok: true, session: touched, admin, payload };
  }

  /**
   * Record that this session's administrator finished TOTP enrolment, so the
   * enrolment gate stops refusing it. The guard re-reads the admin row on every
   * request and is the real authority; this keeps the stored flag honest for the
   * security centre.
   */
  async setTotpPending(sessionId: string, totpPending: boolean) {
    return this.prisma.platformSession.update({ where: { id: sessionId }, data: { totpPending } });
  }

  /** A fresh step-up assertion on this session (R1.5). */
  async recordStepUp(sessionId: string, atMs: number = Date.now()) {
    return this.prisma.platformSession.update({
      where: { id: sessionId },
      data: { stepUpAt: new Date(atMs), stepUpExpiresAt: new Date(atMs + PLATFORM_STEP_UP_TTL_MS), lastSeenAt: new Date(atMs) },
    });
  }

  /** Is the session's step-up claim still inside its 5-minute life? */
  stepUpIsValid(session: { stepUpExpiresAt: Date | null }, atMs: number = Date.now()): boolean {
    return !!session.stepUpExpiresAt && session.stepUpExpiresAt.getTime() > atMs;
  }

  /** Clear a spent step-up claim, so it cannot be reused after the action. */
  async clearStepUp(sessionId: string) {
    return this.prisma.platformSession.update({
      where: { id: sessionId },
      data: { stepUpAt: null, stepUpExpiresAt: null },
    });
  }

  /**
   * Rotate a session (R1.4: rotated on login and step-up). The old row is
   * revoked, a new token is issued, and the enrolment state carries over — a
   * rotation must never become a way to skip TOTP enrolment.
   */
  async rotate(params: { session: PlatformSessionRow; admin: PlatformAdminRow; reason: string; ip?: string | null; userAgent?: string | null }) {
    await this.revoke(params.session.id, params.reason);
    return this.createSession({
      admin: params.admin,
      totpPending: params.session.totpPending,
      ip: params.ip ?? params.session.ip,
      userAgent: params.userAgent ?? params.session.userAgent,
    });
  }

  async revoke(sessionId: string, reason: string) {
    return this.prisma.platformSession.update({
      where: { id: sessionId },
      data: { revokedAt: new Date(), revokeReason: reason.slice(0, 120) },
    });
  }

  /** Every session for one administrator: logout-everywhere, removal, lockout. */
  async revokeAllForAdmin(adminId: string, reason: string) {
    return this.prisma.platformSession.updateMany({
      where: { adminId, revokedAt: null },
      data: { revokedAt: new Date(), revokeReason: reason.slice(0, 120) },
    });
  }

  /** The live sessions of one administrator, for the security centre. */
  async listForAdmin(adminId: string) {
    return this.prisma.platformSession.findMany({
      where: { adminId, revokedAt: null, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  /** Housekeeping: drop rows that can never be used again. */
  async cleanupExpired(atMs: number = Date.now()) {
    const result = await this.prisma.platformSession.deleteMany({
      where: { OR: [{ expiresAt: { lt: new Date(atMs) } }, { revokedAt: { lt: new Date(atMs - PLATFORM_ABSOLUTE_TIMEOUT_MS) } }] },
    });
    if (result.count) this.logger.log(`removed ${result.count} expired platform session row(s)`);
    return result.count;
  }
}
