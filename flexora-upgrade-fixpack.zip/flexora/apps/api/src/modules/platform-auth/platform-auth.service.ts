/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.1-R1.4 — console authentication.
 *
 * WHAT THIS REPLACED (measured in work/r1-evidence/00-before.log):
 *   B7.5  the token was signed with JWT_ACCESS_SECRET, the tenant secret;
 *   B7.8  there was no session table, so nothing could be revoked;
 *   S3    an unknown email answered in 1.6 ms and a wrong password in 148.9 ms —
 *         a 147 ms enumeration oracle, because line 13 threw before any
 *         argon2.verify when the email did not exist;
 *   B7.1  passwords were hashed with bare argon2.hash, not the shared options;
 *   B1.1  and the whole thing 401'd anyway, because the tenant JWT strategy
 *         resolved the platform subject against the "User" table.
 *
 * What it does now:
 *   - one argon2id verify on EVERY failed login, real or not, so unknown-email and
 *     wrong-password are indistinguishable in both body and timing;
 *   - per-account lockout: 5 failures, then exponential from 1 minute, capped at
 *     1 hour, stored in Postgres so a Redis outage cannot disable it;
 *   - per-IP limiting over a sliding window, also in Postgres, so the two cannot
 *     be traded off against each other;
 *   - a revocable PlatformSession (15 min idle, 8 h absolute) signed with
 *     JWT_PLATFORM_SECRET;
 *   - TOTP mandatory: a session for an admin who has not enrolled is created
 *     "pending" and can reach the enrolment routes only;
 *   - every attempt, lockout, login, logout and password change is written to
 *     PlatformLoginAttempt and/or PlatformAuditLog, with no credential in either.
 *
 * No secret value is ever logged, returned in an error, or written to an audit row.
 */
import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import * as argon2 from 'argon2';
import type { PlatformAdmin } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { PlatformSessionService } from './platform-session.service';
import { PlatformTotpService } from './platform-totp.service';

/** Failures before an account locks (R1.3). */
export const PLATFORM_LOGIN_MAX_FAILURES = 5;
/** First lockout length; doubles per further failure. */
export const PLATFORM_LOCKOUT_BASE_MS = 60_000;
/** Lockout ceiling: one hour (R1.3). */
export const PLATFORM_LOCKOUT_MAX_MS = 60 * 60 * 1000;
/** Sliding window for the per-IP counter. */
export const PLATFORM_IP_WINDOW_MS = 15 * 60 * 1000;
/** Attempts per IP per window, across ALL accounts. */
export const PLATFORM_IP_MAX_ATTEMPTS = 30;
/** Minimum platform password length (R1.2). The tenant policy is separate and unchanged. */
export const PLATFORM_PASSWORD_MIN_LENGTH = 16;

/** One message for every credential failure, so the body cannot be fingerprinted. */
export const PLATFORM_CREDENTIALS_MESSAGE = 'Invalid credentials';

export type LoginOutcome = 'SUCCESS' | 'BAD_CREDENTIALS' | 'LOCKED' | 'IP_LIMITED';

import { PlatformAuditService } from '../platform/platform-audit.service';
import { PlatformAlertService } from '../platform/platform-alert.service';
import { PlatformDeviceService } from '../platform/platform-device.service';

/**
 * R3.11 - three or more failed console logins inside this window alert the owner. It is a
 * separate constant from PLATFORM_IP_WINDOW_MS on purpose: the IP cap is a rate limit that
 * must stay tight, while an alert window that is too short tells the owner about every
 * typo and one that is too long tells them after the attack is over.
 */
export const PLATFORM_ALERT_BURST_WINDOW_MS = 10 * 60 * 1000;
export const PLATFORM_ALERT_BURST_THRESHOLD = 3;

export interface LoginContext {
  ip?: string | null;
  userAgent?: string | null;
}

export interface LoginResult {
  token: string;
  sessionId: string;
  admin: { id: string; email: string; name: string; role: string };
  /** True while TOTP enrolment is outstanding; the console must enrol first. */
  totpPending: boolean;
  totpEnabled: boolean;
  expiresAt: Date;
  idleExpiresAt: Date;
}

@Injectable()
export class PlatformAuthService {
  private readonly logger = new Logger(PlatformAuthService.name);
  /**
   * A hash of a random value, computed once per process, used to spend the same
   * argon2id time on an unknown email as on a known one. Never logged.
   */
  private dummyHash: string | null = null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly sessions: PlatformSessionService,
    private readonly totp: PlatformTotpService,
    // PHASE R3 - the single audit writer, the alert outbox and the device baseline.
    private readonly auditLog: PlatformAuditService,
    private readonly alerts: PlatformAlertService,
    private readonly devices: PlatformDeviceService,
  ) {}

  /** The lockout an account faces after `failures` consecutive failures. */
  static lockoutDurationMs(failures: number): number {
    if (failures < PLATFORM_LOGIN_MAX_FAILURES) return 0;
    const exponent = failures - PLATFORM_LOGIN_MAX_FAILURES;
    return Math.min(PLATFORM_LOCKOUT_BASE_MS * 2 ** exponent, PLATFORM_LOCKOUT_MAX_MS);
  }

  async login(rawEmail: string, password: string, context: LoginContext = {}): Promise<LoginResult> {
    const email = String(rawEmail ?? '').trim().toLowerCase();
    const ip = context.ip ?? null;
    const startedAt = Date.now();

    // Per-IP first: it is the cheapest check and it stops a flood from reaching
    // argon2 at all. The answer is the same generic 401.
    const recentFromIp = await this.prisma.platformLoginAttempt.count({
      where: { ip: ip ?? undefined, createdAt: { gte: new Date(startedAt - PLATFORM_IP_WINDOW_MS) } },
    });
    if (ip && recentFromIp >= PLATFORM_IP_MAX_ATTEMPTS) {
      await this.recordAttempt({ email, ip, outcome: 'IP_LIMITED', detail: `attempts=${recentFromIp}` });
      await this.auditSystem('admin:login-ip-limited', { ip, attempts: recentFromIp }, context);
      throw new UnauthorizedException(PLATFORM_CREDENTIALS_MESSAGE);
    }

    const admin = email ? await this.prisma.platformAdmin.findUnique({ where: { email } }) : null;

    // Spend one argon2id verify either way. This is the whole of the timing fix:
    // without it an unknown email answered 147 ms faster (measured, S3).
    const passwordAccepted = admin
      ? await argon2.verify(admin.passwordHash, String(password ?? ''))
      : await this.verifyAgainstDummy(String(password ?? ''));

    if (!admin || !passwordAccepted) {
      await this.registerFailure(admin, email, ip, startedAt, context);
      throw new UnauthorizedException(PLATFORM_CREDENTIALS_MESSAGE);
    }

    // A locked account is refused even with the right password. Checked AFTER the
    // verify so that the lock state cannot be read from the response time.
    if (admin.lockedUntil && admin.lockedUntil.getTime() > startedAt) {
      await this.recordAttempt({ email, ip, outcome: 'LOCKED', detail: 'correct-password-while-locked' });
      throw new UnauthorizedException(PLATFORM_CREDENTIALS_MESSAGE);
    }
    if (admin.status !== 'ACTIVE') {
      await this.recordAttempt({ email, ip, outcome: 'LOCKED', detail: `status=${admin.status}` });
      throw new UnauthorizedException(PLATFORM_CREDENTIALS_MESSAGE);
    }

    const refreshed = await this.prisma.platformAdmin.update({
      where: { id: admin.id },
      data: { lastLoginAt: new Date(startedAt), failedLoginCount: 0, lockedUntil: null },
    });
    await this.recordAttempt({ email, ip, outcome: 'SUCCESS' });
    const loginRow = await this.audit(refreshed, 'admin:login', refreshed.id, { ip }, context);

    // R3.11 and owner decision A4. The device baseline is consulted ONLY on a successful
    // login (A4.1: a device seen in a failed attempt is not this administrator's device),
    // it references the audit row written just above (A3.7), and observeLogin cannot throw
    // - every failure path inside it returns a benign observation, so a database hiccup or
    // a missing OTP_HMAC_SECRET can never lock an administrator out (A4.4).
    await this.devices.observeLogin({
      adminId: refreshed.id,
      ip,
      userAgent: context.userAgent ?? null,
      auditSeq: loginRow?.seq ?? null,
    });

    const session = await this.sessions.createSession({
      admin: refreshed,
      totpPending: refreshed.totpEnabled !== true,
      ip,
      userAgent: context.userAgent ?? null,
    });

    return {
      token: session.token,
      sessionId: session.sessionId,
      admin: { id: refreshed.id, email: refreshed.email, name: refreshed.name, role: refreshed.role },
      totpPending: refreshed.totpEnabled !== true,
      totpEnabled: refreshed.totpEnabled === true,
      expiresAt: session.expiresAt,
      idleExpiresAt: session.idleExpiresAt,
    };
  }

  /**
   * R1.2: changing a console password needs the current password AND a TOTP
   * assertion. The assertion is the route's @RequireStepUp() claim (verified
   * within the last five minutes on this very session), so the admin is not asked
   * for the same code twice in one form.
   */
  async changePassword(adminId: string, currentPassword: string, newPassword: string): Promise<{ ok: true }> {
    const admin = await this.prisma.platformAdmin.findUnique({ where: { id: adminId } });
    if (!admin) throw new UnauthorizedException(PLATFORM_CREDENTIALS_MESSAGE);
    if (!admin.totpEnabled) throw new UnauthorizedException('totp-not-enrolled');

    const currentAccepted = await argon2.verify(admin.passwordHash, String(currentPassword ?? ''));
    if (!currentAccepted) {
      await this.recordAttempt({ email: admin.email, ip: null, outcome: 'BAD_CREDENTIALS', detail: 'password-change' });
      await this.audit(admin, 'admin:password-change-refused', admin.id, { reason: 'current-password-incorrect' });
      throw new UnauthorizedException('Current password incorrect');
    }

    const problem = platformPasswordProblem(String(newPassword ?? ''));
    if (problem) {
      await this.audit(admin, 'admin:password-change-refused', admin.id, { reason: 'policy' });
      throw new UnauthorizedException(problem);
    }

    await this.prisma.platformAdmin.update({
      where: { id: adminId },
      data: { passwordHash: await hashPassword(String(newPassword)), mustChangePassword: false },
    });
    // A password change invalidates every other session: whoever else was signed
    // in with the old credential should not stay signed in.
    const revoked = await this.sessions.revokeAllForAdmin(adminId, 'password-changed');
    await this.audit(admin, 'admin:password-changed', adminId, { sessionsRevoked: revoked.count });
    return { ok: true };
  }

  /** The console's own profile endpoint. Contains no secret and no code. */
  async describeSession(admin: PlatformAdmin, sessionId: string) {
    const [remainingCodes, sessions] = await Promise.all([
      this.totp.remainingRecoveryCodes(admin.id),
      this.sessions.listForAdmin(admin.id),
    ]);
    return {
      admin: {
        id: admin.id,
        email: admin.email,
        name: admin.name,
        role: admin.role,
        status: admin.status,
        totpEnabled: admin.totpEnabled,
        totpEnrolledAt: admin.totpEnrolledAt,
        mustChangePassword: admin.mustChangePassword,
        lastLoginAt: admin.lastLoginAt,
      },
      recoveryCodesRemaining: remainingCodes,
      currentSessionId: sessionId,
      // Other sessions are listed without their token hashes: id, age, ip, agent.
      sessions: sessions.map((session) => ({
        id: session.id,
        createdAt: session.createdAt,
        lastSeenAt: session.lastSeenAt,
        expiresAt: session.expiresAt,
        ip: session.ip,
        userAgent: session.userAgent,
        current: session.id === sessionId,
      })),
    };
  }

  async logout(
    sessionId: string,
    admin: PlatformAdmin | null,
    reason = 'logout',
    // PHASE R3 (R3.6) - a logout row with no IP and no user agent was the last gap in the
    // coverage table: every other row the smoke run produced carried both.
    context: LoginContext = {},
  ): Promise<{ ok: true }> {
    await this.sessions.revoke(sessionId, reason);
    if (admin) await this.audit(admin, 'admin:logout', admin.id, {}, context);
    return { ok: true };
  }

  // --- internals -----------------------------------------------------------

  private async verifyAgainstDummy(password: string): Promise<boolean> {
    if (!this.dummyHash) {
      this.dummyHash = await hashPassword(randomBytes(24).toString('base64url'));
    }
    try {
      // Always false: the value hashed here was random and discarded.
      return await argon2.verify(this.dummyHash, password);
    } catch {
      return false;
    }
  }

  private async registerFailure(
    admin: PlatformAdmin | null,
    email: string,
    ip: string | null,
    atMs: number,
    context: LoginContext = {},
  ) {
    let lockedUntil: Date | null = null;
    let failures = 0;
    if (admin) {
      failures = admin.failedLoginCount + 1;
      const duration = PlatformAuthService.lockoutDurationMs(failures);
      lockedUntil = duration > 0 ? new Date(atMs + duration) : null;
      await this.prisma.platformAdmin.update({
        where: { id: admin.id },
        data: { failedLoginCount: failures, lockedUntil },
      });
      // A lockout also kills live sessions: an account under attack should not
      // keep a session that was established before the attack started.
      if (lockedUntil) await this.sessions.revokeAllForAdmin(admin.id, 'account-locked');
    }
    await this.recordAttempt({ email, ip, outcome: 'BAD_CREDENTIALS', detail: admin ? `failures=${failures}` : 'unknown-email' });
    if (lockedUntil && admin) {
      await this.audit(
        admin,
        'admin:account-locked',
        admin.id,
        {
          failures,
          lockedUntil: lockedUntil.toISOString(),
          durationMs: lockedUntil.getTime() - atMs,
        },
        context,
      );
      this.logger.warn(`platform account locked after ${failures} failures: ${admin.email}`);
    }

    // R3.11 - three or more failed console logins alert the owner. Counted from the attempt
    // table over a window rather than from this account's own counter, so an attack spread
    // across several addresses or several guessed emails is still visible. The count runs
    // AFTER recordAttempt above, so the failure that crosses the threshold is included.
    await this.raiseLoginBurstAlert(admin, email, ip, atMs);
  }

  /** Never throws. A detection feature must not be able to break the login it observes. */
  private async raiseLoginBurstAlert(
    admin: PlatformAdmin | null,
    email: string,
    ip: string | null,
    atMs: number,
  ): Promise<void> {
    try {
      const orClauses: Array<Record<string, string>> = [];
      if (email) orClauses.push({ email });
      if (ip) orClauses.push({ ip });
      if (!orClauses.length) return;
      const recentFailures = await this.prisma.platformLoginAttempt.count({
        where: {
          createdAt: { gte: new Date(atMs - PLATFORM_ALERT_BURST_WINDOW_MS) },
          outcome: { in: ['BAD_CREDENTIALS', 'BAD_TOTP', 'IP_LIMITED'] },
          OR: orClauses,
        },
      });
      if (recentFailures < PLATFORM_ALERT_BURST_THRESHOLD) return;
      // A3.5 - the dedupe key folds in the window, so one burst produces one alert and a
      // fourth, fifth or fiftieth failure inside the same ten minutes produces none.
      await this.alerts.raise({
        type: 'ADMIN_LOGIN_BURST',
        severity: 'warning',
        targetKind: admin ? 'admin' : 'platform',
        targetId: admin ? admin.id : null,
      });
    } catch (error) {
      this.logger.warn(`could not evaluate the failed-login burst: ${(error as Error).message}`);
    }
  }

  private async recordAttempt(params: { email: string | null; ip: string | null; outcome: string; detail?: string }) {
    await this.prisma.platformLoginAttempt
      .create({
        data: {
          email: params.email ? params.email.slice(0, 254) : null,
          ip: params.ip ? params.ip.slice(0, 64) : null,
          outcome: params.outcome,
          detail: params.detail ? params.detail.slice(0, 200) : null,
        },
      })
      .catch((error: Error) => this.logger.error(`could not record a platform login attempt: ${error.message}`));
  }

  /**
   * PHASE R3 (R3.6). Before this, an authentication-side audit row carried no IP, no user
   * agent, no reason field and no step-up flag - measured in work/r3-evidence/00-before.log
   * (B4): six of eight genuine rows had no IP at all. It also swallowed a failed write with
   * nothing but a log line.
   *
   * The write still must not break a login: locking the owner out of their own console
   * because an audit INSERT failed is the worse outcome. So the failure is caught, but it is
   * no longer silent - it raises an AUDIT_WRITE_FAILED alert through the outbox, which is
   * visible in the console and retries, and it is logged with an error CODE rather than the
   * driver's text (A3.1).
   *
   * Returns the created row so a caller can pass its chain position to an alert (A3.7).
   */
  private async audit(
    admin: PlatformAdmin,
    action: string,
    target: string,
    details: Record<string, unknown>,
    context: LoginContext & { reason?: string | null; stepUpUsed?: boolean } = {},
  ) {
    return this.auditLog.recordBestEffort(
      {
        adminId: admin.id,
        adminName: admin.name,
        action,
        target,
        details,
        reason: context.reason ?? null,
        ip: context.ip ?? null,
        userAgent: context.userAgent ?? null,
        stepUpUsed: context.stepUpUsed === true,
      },
      async (failedAction, code) => {
        this.logger.error(`audit write failed for ${failedAction}: ${code}`);
        await this.alerts.raise({
          type: 'AUDIT_WRITE_FAILED',
          severity: 'danger',
          targetKind: 'admin',
          targetId: admin.id,
        });
      },
    );
  }

  /** An audit row for an event with no authenticated administrator behind it. */
  private async auditSystem(
    action: string,
    details: Record<string, unknown>,
    context: LoginContext = {},
  ) {
    return this.auditLog.recordBestEffort(
      {
        adminId: 'system',
        adminName: 'system',
        action,
        target: null,
        details,
        ip: context.ip ?? null,
        userAgent: context.userAgent ?? null,
      },
      async (failedAction, code) => {
        this.logger.error(`audit write failed for ${failedAction}: ${code}`);
        await this.alerts.raise({
          type: 'AUDIT_WRITE_FAILED',
          severity: 'danger',
          targetKind: 'platform',
          targetId: null,
        });
      },
    );
  }
}

/**
 * The platform password policy (R1.2): at least 16 characters and at least three
 * character classes. Deliberately NOT the shared @PasswordStrength() decorator,
 * whose minimum is 8 and which applies to tenant users — raising that one would
 * change tenant behaviour, which is out of scope for PHASE R.
 */
export function platformPasswordProblem(password: string): string | null {
  const value = String(password ?? '');
  if (value.length < PLATFORM_PASSWORD_MIN_LENGTH) {
    return `password must be at least ${PLATFORM_PASSWORD_MIN_LENGTH} characters`;
  }
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((pattern) => pattern.test(value)).length;
  if (classes < 3) return 'password must contain at least three of: lower case, upper case, digit, symbol';
  return null;
}
