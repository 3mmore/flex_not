import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PlatformAuthController } from './platform-auth.controller';
import { PlatformAuthService } from './platform-auth.service';
import { PlatformSessionService } from './platform-session.service';
import { PlatformTotpService } from './platform-totp.service';
import { PlatformBootChecks } from './platform-boot-checks';
// PHASE R3 - audit rows for login, step-up and TOTP enrolment are written here, the
// failed-login burst and new-device alerts are raised here, and the device baseline is
// seeded at boot from here. Importing a leaf module keeps the graph acyclic.
import { PlatformAuditModule } from '../platform/platform-audit.module';

/**
 * PHASE R1 — the console's authentication module.
 *
 * PlatformSessionService is EXPORTED because the global guards in app.module.ts
 * (PlatformSessionGuard) inject it, and PlatformTotpService because the platform
 * module's own controllers need to verify a second factor. JwtModule is registered
 * with no secret on purpose: every sign and verify passes the secret explicitly, so
 * the platform token can never be minted with the tenant secret by accident.
 */
@Module({
  imports: [JwtModule.register({}), PlatformAuditModule],
  controllers: [PlatformAuthController],
  providers: [PlatformAuthService, PlatformSessionService, PlatformTotpService, PlatformBootChecks],
  exports: [PlatformAuthService, PlatformSessionService, PlatformTotpService, PlatformAuditModule],
})
export class PlatformAuthModule {}
