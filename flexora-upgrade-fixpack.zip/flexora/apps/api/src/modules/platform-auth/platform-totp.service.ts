/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.1 — mandatory TOTP for the owner console.
 *
 * Enrolment is two calls and the secret exists in plain text exactly once, in the
 * response of the first: beginEnrolment() stores an ENCRYPTED pending secret and
 * returns the base32 key plus an otpauth:// QR payload; completeEnrolment() checks
 * a code the admin's authenticator app produced, promotes the secret to enabled,
 * and issues ten single-use recovery codes whose plain text is returned once and
 * never stored (only argon2id hashes are).
 *
 * Replay protection is by STEP, not by token (R1.1). Storing the last accepted
 * step and refusing any step at or below it closes the hole a "have I seen this
 * exact code" check leaves open: inside a +/-1 window, a code from the previous
 * step is still arithmetically valid, so it would be accepted a second time.
 *
 * Recovery-code verification costs one argon2id verify per stored code, worst case
 * ten. That is deliberate: it is a rare path, and it makes an offline guess
 * against a stolen hash table as expensive as an online guess against the API.
 *
 * The at-rest key is the product's ENCRYPTION_KEY through the existing
 * EncryptionService — the same mechanism that protects tenant 2FA secrets, and
 * already covered by the distinctness validator. Introducing a separate
 * PLATFORM_TOTP_KEY would add a required secret to every deployment, which is a
 * change to the owner's local run and was not decided, so it is reported in the
 * delivery report rather than done silently.
 */
import { BadRequestException, ForbiddenException, Injectable, Logger } from '@nestjs/common';
import * as argon2 from 'argon2';
import * as QRCode from 'qrcode';
import type { PlatformAdmin } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
// PHASE R3 (R3.6) - TOTP enrolment, enrolment refusal, enrolment completion, recovery code
// regeneration and the CLI reset all write audit rows, and none of them used to carry the
// IP, the user agent, a first-class reason or whether a step-up authorised the action.
import { PlatformAuditService } from '../platform/platform-audit.service';
import { PlatformAlertService } from '../platform/platform-alert.service';

/** Where an audit row came from. Optional and trailing, so every existing caller works. */
export interface TotpAuditContext {
  ip?: string | null;
  userAgent?: string | null;
  reason?: string | null;
  stepUpUsed?: boolean;
}
import { EncryptionService } from '../../common/security/encryption.service';
import { PlatformSessionService } from './platform-session.service';
import { hashPassword } from '../../config/password-hash';
import {
  RECOVERY_CODE_LENGTH,
  TOTP_ISSUER,
  currentTotpStep,
  generateRecoveryCode,
  generateTotpSecret,
  looksLikeRecoveryCode,
  normaliseRecoveryCode,
  totpKeyUri,
  verifyTotpCode,
} from '../../common/security/platform-totp';

/** R1.1: ten single-use recovery codes per enrolment. */
export const RECOVERY_CODE_COUNT = 10;

export type TotpRefusalReason = 'no-secret' | 'malformed-code' | 'invalid' | 'replayed' | 'not-enrolled';
export interface TotpVerificationResult {
  ok: boolean;
  reason?: TotpRefusalReason;
  /** Which factor satisfied the check, for the audit row. Never a code itself. */
  via?: 'totp' | 'recovery';
  /** The non-secret position label of a spent recovery code ("code 4"). */
  recoveryLabel?: string;
}

@Injectable()
export class PlatformTotpService {
  private readonly logger = new Logger(PlatformTotpService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
    private readonly auditLog: PlatformAuditService,
    private readonly alerts: PlatformAlertService,
    private readonly sessions?: PlatformSessionService,
  ) {}

  hasEnrolled(admin: Pick<PlatformAdmin, 'totpEnabled'>): boolean {
    return admin.totpEnabled === true;
  }

  /**
   * Step one of first-login enrolment. Returns the plain-text secret, the
   * otpauth:// URI and a QR data URL — the only moment any of them exist outside
   * the authenticator app. The secret is stored encrypted and NOT yet enabled, so
   * an admin who abandons enrolment halfway has no second factor and remains
   * locked out of everything except the enrolment routes.
   */
  async beginEnrolment(adminId: string, context: TotpAuditContext = {}): Promise<{ secret: string; otpauthUrl: string; qrCodeDataUrl: string; issuer: string }> {
    const admin = await this.prisma.platformAdmin.findUnique({ where: { id: adminId } });
    if (!admin) throw new BadRequestException('admin-not-found');
    if (admin.totpEnabled) {
      // Re-enrolling would silently invalidate the codes an admin already carries.
      // Regeneration is a separate, TOTP-authorised action.
      throw new ForbiddenException('totp-already-enrolled');
    }
    const secret = generateTotpSecret();
    await this.prisma.platformAdmin.update({
      where: { id: adminId },
      data: { totpSecret: this.encryption.encrypt(secret), totpEnabled: false },
    });
    const otpauthUrl = totpKeyUri({ accountName: admin.email, secret, issuer: TOTP_ISSUER });
    const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl, { margin: 1, width: 320 });
    await this.audit(admin, 'admin:totp-enrolment-started', adminId, {}, context);
    return { secret, otpauthUrl, qrCodeDataUrl, issuer: TOTP_ISSUER };
  }

  /**
   * Step two: prove the admin really has the secret in an authenticator app, then
   * enable TOTP and issue the recovery codes.
   */
  async completeEnrolment(adminId: string, code: string, context: TotpAuditContext = {}): Promise<{ recoveryCodes: string[]; enrolledAt: Date }> {
    const admin = await this.prisma.platformAdmin.findUnique({ where: { id: adminId } });
    if (!admin) throw new BadRequestException('admin-not-found');
    if (admin.totpEnabled) throw new ForbiddenException('totp-already-enrolled');
    const secret = this.readSecret(admin);
    if (!secret) throw new ForbiddenException('totp-enrolment-not-started');

    const result = verifyTotpCode({ secret, code, lastUsedStep: admin.totpLastUsedStep });
    if (!result.ok) {
      await this.audit(admin, 'admin:totp-enrolment-failed', adminId, { reason: result.reason }, context);
      throw new ForbiddenException(`totp-${result.reason}`);
    }

    const enrolledAt = new Date();
    await this.prisma.platformAdmin.update({
      where: { id: adminId },
      data: { totpEnabled: true, totpEnrolledAt: enrolledAt, totpLastUsedStep: result.step },
    });
    const recoveryCodes = await this.issueRecoveryCodes(adminId);
    await this.audit(admin, 'admin:totp-enrolled', adminId, { recoveryCodesIssued: recoveryCodes.length }, context);
    return { recoveryCodes, enrolledAt };
  }

  /**
   * Verify a presented second factor for an ALREADY ENROLLED admin: a TOTP code,
   * or one of the single-use recovery codes. On success the last-used step is
   * advanced (TOTP) or the code is marked spent (recovery), so neither can be
   * presented twice.
   */
  async verifySecondFactor(admin: PlatformAdmin, presented: string): Promise<TotpVerificationResult> {
    if (!admin.totpEnabled) return { ok: false, reason: 'not-enrolled' };
    const code = String(presented ?? '').trim();
    if (!code) return { ok: false, reason: 'malformed-code' };

    if (looksLikeRecoveryCode(code)) {
      const spent = await this.consumeRecoveryCode(admin.id, code);
      if (!spent) return { ok: false, reason: 'invalid', via: 'recovery' };
      return { ok: true, via: 'recovery', recoveryLabel: spent };
    }

    const secret = this.readSecret(admin);
    if (!secret) return { ok: false, reason: 'no-secret' };
    const result = verifyTotpCode({ secret, code, lastUsedStep: admin.totpLastUsedStep });
    if (!result.ok) return { ok: false, reason: result.reason, via: 'totp' };
    await this.prisma.platformAdmin.update({ where: { id: admin.id }, data: { totpLastUsedStep: result.step } });
    return { ok: true, via: 'totp' };
  }

  /**
   * Regenerate the recovery-code set. R1.1 requires a valid TOTP code for this —
   * a recovery code may NOT authorise its own replacement, or losing the
   * authenticator and one leaked code would be enough to lock the owner out
   * permanently.
   */
  async regenerateRecoveryCodes(admin: PlatformAdmin, totpCode: string, context: TotpAuditContext = {}): Promise<{ recoveryCodes: string[] }> {
    if (!admin.totpEnabled) throw new ForbiddenException('totp-not-enrolled');
    const secret = this.readSecret(admin);
    if (!secret) throw new ForbiddenException('totp-unavailable');
    const result = verifyTotpCode({ secret, code: totpCode, lastUsedStep: admin.totpLastUsedStep });
    if (!result.ok) {
      await this.audit(admin, 'admin:recovery-regeneration-refused', admin.id, { reason: result.reason }, context);
      throw new ForbiddenException(`totp-${result.reason}`);
    }
    await this.prisma.platformAdmin.update({ where: { id: admin.id }, data: { totpLastUsedStep: result.step } });
    const recoveryCodes = await this.issueRecoveryCodes(admin.id);
    await this.audit(admin, 'admin:recovery-codes-regenerated', admin.id, { count: recoveryCodes.length }, context);
    return { recoveryCodes };
  }

  /**
   * Clear an enrolment so the next login re-enrols from scratch. This is the ONLY
   * recovery path (owner decision D4): it is reachable from
   * `npm run bootstrap:admin -- --reset-totp <email>` and from no HTTP route, and
   * it always writes an audit row naming the actor and the reason.
   */
  async resetEnrolment(params: {
    adminId: string;
    actor: string;
    reason: string;
    /** PHASE R3 - a CLI reset has no request, so ip and userAgent stay null. */
    context?: TotpAuditContext;
  }): Promise<{ cleared: boolean; codesInvalidated: number; sessionsRevoked: number }> {
    const admin = await this.prisma.platformAdmin.findUnique({ where: { id: params.adminId } });
    if (!admin) throw new BadRequestException('admin-not-found');
    const codes = await this.prisma.platformRecoveryCode.updateMany({
      where: { adminId: admin.id, usedAt: null, replacedAt: null },
      data: { replacedAt: new Date() },
    });
    await this.prisma.platformAdmin.update({
      where: { id: admin.id },
      data: { totpSecret: null, totpEnabled: false, totpLastUsedStep: null, totpEnrolledAt: null },
    });
    await this.auditLog.recordBestEffort(
      {
        adminId: admin.id,
        adminName: admin.name,
        action: 'admin:totp-reset-by-cli',
        target: admin.id,
        details: {
          actor: params.actor.slice(0, 120),
          reason: params.reason.slice(0, 200),
          codesInvalidated: codes.count,
        },
        // R3.6 - the justification is now a first-class column, not only a detail. A CLI
        // reset has no HTTP request behind it, so ip and userAgent are honestly null.
        reason: params.reason.slice(0, 500),
        ip: params.context?.ip ?? null,
        userAgent: params.context?.userAgent ?? null,
        stepUpUsed: params.context?.stepUpUsed === true,
      },
      async (failedAction, code) => {
        this.logger.error(`audit write failed for ${failedAction}: ${code}`);
        await this.alerts.raise({
          type: 'AUDIT_WRITE_FAILED',
          severity: 'danger',
          targetKind: 'admin',
          targetId: admin.id,
        });
      },
    );
    // A cleared second factor must also end every live session: an attacker who
    // was already signed in should not keep a session that outlives the reset.
    const revoked = this.sessions ? await this.sessions.revokeAllForAdmin(admin.id, 'totp-reset-by-cli') : { count: 0 };
    this.logger.log(`TOTP enrolment cleared for ${admin.email} by ${params.actor}; ${revoked.count} session(s) revoked`);
    return { cleared: true, codesInvalidated: codes.count, sessionsRevoked: revoked.count };
  }

  /** How many unused recovery codes an admin still has. Never returns the codes. */
  async remainingRecoveryCodes(adminId: string): Promise<number> {
    return this.prisma.platformRecoveryCode.count({ where: { adminId, usedAt: null, replacedAt: null } });
  }

  // --- internals -----------------------------------------------------------

  private readSecret(admin: PlatformAdmin): string | null {
    if (!admin.totpSecret) return null;
    try {
      return this.encryption.decrypt(admin.totpSecret);
    } catch {
      // A rotated or wrong ENCRYPTION_KEY leaves the ciphertext unreadable. That
      // must present as "no second factor available", never as a 500, and it must
      // be visible in the log so the operator can rotate back.
      this.logger.error('platform TOTP secret could not be decrypted for this administrator');
      return null;
    }
  }

  private async issueRecoveryCodes(adminId: string): Promise<string[]> {
    // Supersede anything outstanding first, so a regenerated set is the only one
    // that works. The rows stay for the audit trail.
    await this.prisma.platformRecoveryCode.updateMany({
      where: { adminId, usedAt: null, replacedAt: null },
      data: { replacedAt: new Date() },
    });
    const codes: string[] = [];
    const seen = new Set<string>();
    while (codes.length < RECOVERY_CODE_COUNT) {
      const code = generateRecoveryCode();
      if (seen.has(code)) continue; // astronomically unlikely; do not store a duplicate
      seen.add(code);
      codes.push(code);
    }
    for (let index = 0; index < codes.length; index++) {
      await this.prisma.platformRecoveryCode.create({
        data: {
          adminId,
          codeHash: await hashPassword(normaliseRecoveryCode(codes[index])),
          label: `code ${index + 1}`,
        },
      });
    }
    return codes;
  }

  private async consumeRecoveryCode(adminId: string, presented: string): Promise<string | null> {
    const candidates = await this.prisma.platformRecoveryCode.findMany({
      where: { adminId, usedAt: null, replacedAt: null },
      orderBy: { createdAt: 'asc' },
    });
    const normalised = normaliseRecoveryCode(presented);
    if (normalised.length !== RECOVERY_CODE_LENGTH) return null;
    for (const candidate of candidates) {
      // argon2.verify is self-describing: the parameters live in the stored hash.
      // eslint-disable-next-line no-await-in-loop
      if (await argon2.verify(candidate.codeHash, normalised)) {
        await this.prisma.platformRecoveryCode.update({ where: { id: candidate.id }, data: { usedAt: new Date() } });
        return candidate.label ?? 'recovery code';
      }
    }
    return null;
  }

  /**
   * An audit row for a TOTP event. Details carry reasons and counts only: never a
   * secret, never a code, never a hash.
   */
  private async audit(
    admin: PlatformAdmin,
    action: string,
    target: string,
    details: Record<string, unknown>,
    context: TotpAuditContext = {},
  ): Promise<void> {
    await this.auditLog.recordBestEffort(
      {
        adminId: admin.id,
        adminName: admin.name,
        action,
        target,
        details,
        reason: context.reason ?? null,
        ip: context.ip ?? null,
        userAgent: context.userAgent ?? null,
        stepUpUsed: context.stepUpUsed === true,
      },
      async (failedAction, code) => {
        this.logger.error(`audit write failed for ${failedAction}: ${code}`);
        await this.alerts.raise({
          type: 'AUDIT_WRITE_FAILED',
          severity: 'danger',
          targetKind: 'admin',
          targetId: admin.id,
        });
      },
    );
  }
}

/** Re-exported so callers do not have to import two modules for one concept. */
export { currentTotpStep };
