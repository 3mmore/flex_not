/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — checks that belong at boot rather than per request.
 *
 * D3 (owner decision): the seeded default administrator must exist in development
 * only. This does not delete anything — deleting a row in the owner's database is a
 * change to stored data, and the decision was to keep the existing one — but outside
 * development a known-default administrator email is now LOUD: an error in the log
 * and an immutable row in the platform audit trail, so it cannot survive unnoticed
 * into production.
 *
 * D2 (owner decision): when JWT_PLATFORM_SECRET is unset outside production the
 * process generates an ephemeral secret. That is worth one warning line at boot, so
 * nobody is surprised that console sessions do not survive a restart. The warning
 * names the variable and never contains a value.
 *
 * It also drops platform session rows that can never be used again, which keeps the
 * revocation index small without needing a scheduler.
 */
import { Injectable, Logger, OnApplicationBootstrap } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { isProduction } from '../../config/env-mode';
import { inspectPlatformSecret } from '../../config/platform-secret';
import { PlatformSessionService } from './platform-session.service';
// PHASE R3 - the audit row below goes through the single writer, and the device baseline
// is seeded here because this is the one place that already runs once per boot.
import { PlatformAuditService } from '../platform/platform-audit.service';
import { PlatformDeviceService } from '../platform/platform-device.service';

/** Emails a development seed has historically created. Names, not credentials. */
export const KNOWN_DEFAULT_ADMIN_EMAILS: readonly string[] = ['admin@flexora.com'];

@Injectable()
export class PlatformBootChecks implements OnApplicationBootstrap {
  private readonly logger = new Logger(PlatformBootChecks.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly sessions: PlatformSessionService,
    private readonly auditLog: PlatformAuditService,
    private readonly devices: PlatformDeviceService,
  ) {}

  async onApplicationBootstrap(): Promise<void> {
    await this.reportDefaultAdministrators();
    this.reportPlatformSecretPosture();
    await this.sessions.cleanupExpired().catch((error: Error) => {
      // Housekeeping must never stop the api from serving.
      this.logger.warn(`expired platform session cleanup skipped: ${error.message}`);
    });
    await this.seedDeviceBaseline();
  }

  /**
   * PHASE R3, owner decision A4.6: seed the administrator device baseline from history so
   * that an existing deployment does not alert about every administrator's normal device
   * the first time the feature runs. Set-based in SQL, idempotent, additive - it inserts
   * one row per distinct administrator and device digest and does nothing on conflict, so
   * running it on every boot is free after the first. Only SUCCESSFUL logins and live
   * sessions are considered; a device seen in a failed attempt is not seeded (A4.1).
   *
   * It cannot stop the api from serving: seedBaseline catches everything and reports
   * skipped, and a missing OTP_HMAC_SECRET disables the baseline rather than failing boot.
   */
  private async seedDeviceBaseline(): Promise<void> {
    const result = await this.devices.seedBaseline();
    if (result.skipped) {
      this.logger.warn(
        'administrator device baseline not seeded (no device key available, or the seed query failed)',
      );
      return;
    }
    this.logger.log(
      `administrator device baseline: ${result.seeded} new entr(y/ies) from ${result.considered} historical login(s)`,
    );
  }

  private async reportDefaultAdministrators(): Promise<void> {
    if (!isProduction()) {
      // In development the seeded administrator is expected and stays usable; it is
      // still subject to mandatory TOTP enrolment like every other administrator.
      return;
    }
    const rows = await this.prisma.platformAdmin
      .findMany({
        where: { email: { in: [...KNOWN_DEFAULT_ADMIN_EMAILS] } },
        select: { id: true, email: true, status: true },
      })
      .catch(() => [] as Array<{ id: string; email: string; status: string }>);

    for (const row of rows) {
      this.logger.error(
        `a known default console administrator (${row.email}) exists in production. Remove it and create a named administrator with: npm run bootstrap:admin`,
      );
      // R3.6: through the single writer, so the row gets a chain position. There is no
      // request behind a boot check, so ip and userAgent are honestly null.
      await this.auditLog.recordBestEffort({
        adminId: row.id,
        adminName: row.email,
        action: 'admin:default-administrator-present-in-production',
        target: row.id,
        details: { email: row.email, status: row.status },
      });
    }
    if (!rows.length) this.logger.log('no known default console administrator present');
  }

  private reportPlatformSecretPosture(): void {
    // inspectPlatformSecret() already words the ephemeral-secret warning, and it
    // does so without generating anything: isEphemeralPlatformSecret() only becomes
    // true after the first call to platformSecret(), so reading it here would
    // report "not ephemeral" at boot and be wrong.
    const report = inspectPlatformSecret();
    for (const warning of report.warnings) this.logger.warn(warning);
    for (const problem of report.problems) this.logger.error(problem);
  }
}
