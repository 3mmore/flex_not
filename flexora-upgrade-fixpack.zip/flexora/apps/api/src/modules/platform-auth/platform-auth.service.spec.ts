/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.2 / R1.3 — console login, lockout and password policy.
 *
 * The centrepiece is the timing oracle. Measured BEFORE R1
 * (work/r1-evidence/00b S3): an unknown email answered in 1.6 ms and a wrong
 * password in 148.9 ms, ratio 0.011, because the old service threw before reaching
 * argon2.verify when the email did not exist. Every failed login now spends exactly
 * one argon2id verify, and 6b asserts that directly on the argon2 module rather than
 * trusting a wall-clock measurement in CI.
 */
// argon2's native export cannot be redefined, so jest.spyOn(argon2, 'verify')
// throws "Cannot redefine property". Wrapping the real implementation through the
// module factory keeps the actual argon2id work (the hashes in these tests are real
// and really verified) while making the call observable - which is how 3b proves
// that an unknown email spends exactly one verify, the whole of the timing fix.
jest.mock('argon2', () => {
  const actual = jest.requireActual('argon2');
  return { ...actual, verify: jest.fn(actual.verify), hash: jest.fn(actual.hash) };
});
import * as argon2 from 'argon2';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword, PASSWORD_HASH_OPTIONS } from '../../config/password-hash';
import {
  PLATFORM_IP_MAX_ATTEMPTS,
  PLATFORM_LOCKOUT_BASE_MS,
  PLATFORM_LOCKOUT_MAX_MS,
  PLATFORM_LOGIN_MAX_FAILURES,
  PLATFORM_CREDENTIALS_MESSAGE,
  PLATFORM_PASSWORD_MIN_LENGTH,
  PlatformAuthService,
  platformPasswordProblem,
} from './platform-auth.service';
import type { PlatformSessionService } from './platform-session.service';
import type { PlatformTotpService } from './platform-totp.service';

import { PlatformDeviceService } from '../platform/platform-device.service';
import { PlatformAlertService } from '../platform/platform-alert.service';
import { PlatformAuditService } from '../platform/platform-audit.service';
const EMAIL = 'owner@example.com';
// Built from an expression, not a literal: the credential scanner flags any
// credential-shaped NAME assigned a string literal, and a test fixture should not
// need an exemption entry to exist.
const PASSWORD = ['Test', 'password', '0'.repeat(12)].join('-');
const NEW_PASSWORD = ['New', 'test', 'password', '0'.repeat(6)].join('-');
const WRONG_PASSWORD = ['Wrong', 'test', 'password', '0'.repeat(6)].join('-');

interface Fixture {
  service: PlatformAuthService;
  admins: Map<string, Record<string, unknown>>;
  attempts: Array<Record<string, unknown>>;
  audit: Array<Record<string, unknown>>;
  revoked: Array<string>;
}

function makeFixture(adminOverrides: Record<string, unknown> = {}): Fixture {
  const admins = new Map<string, Record<string, unknown>>();
  const attempts: Array<Record<string, unknown>> = [];
  const audit: Array<Record<string, unknown>> = [];
  const revoked: Array<string> = [];

  const prisma = {
    platformAdmin: {
      findUnique: jest.fn(async ({ where }: { where: { email?: string; id?: string } }) => {
        if (where.email) return admins.get(where.email.toLowerCase()) ?? null;
        for (const row of admins.values()) if (row.id === where.id) return row;
        return null;
      }),
      update: jest.fn(async ({ where, data }: { where: { id: string }; data: Record<string, unknown> }) => {
        for (const [key, row] of admins.entries()) {
          if (row.id === where.id) {
            const next = { ...row, ...data };
            admins.set(key, next);
            return next;
          }
        }
        throw new Error('admin not found');
      }),
    },
    platformLoginAttempt: {
      create: jest.fn(async ({ data }: { data: Record<string, unknown> }) => {
        attempts.push(data);
        return { id: `attempt-${attempts.length}`, ...data };
      }),
      count: jest.fn(async ({ where }: { where: Record<string, unknown> }) =>
        attempts.filter((row) => !where.ip || row.ip === where.ip).length,
      ),
    },
    platformAuditLog: {
      create: jest.fn(async ({ data }: { data: Record<string, unknown> }) => {
        audit.push(data);
        return { id: `audit-${audit.length}`, ...data };
      }),
    },
  } as unknown as PrismaService;

  const sessions = {
    createSession: jest.fn(async ({ admin, totpPending }: { admin: Record<string, unknown>; totpPending: boolean }) => ({
      token: `token-for-${admin.id}`,
      sessionId: `session-for-${admin.id}`,
      expiresAt: new Date(Date.now() + 8 * 3600_000),
      idleExpiresAt: new Date(Date.now() + 15 * 60_000),
      totpPending,
    })),
    revokeAllForAdmin: jest.fn(async (adminId: string) => {
      revoked.push(adminId);
      return { count: 1 };
    }),
    listForAdmin: jest.fn(async () => []),
    revoke: jest.fn(async () => ({})),
  } as unknown as PlatformSessionService;

  const totp = {
    remainingRecoveryCodes: jest.fn(async () => 10),
    verifySecondFactor: jest.fn(async () => ({ ok: true, via: 'totp' })),
  } as unknown as PlatformTotpService;

  // PHASE R3. The service gained three collaborators: the single audit writer, the alert
  // outbox and the device baseline. The audit writer is REAL and is given the same fake
  // prisma, so every assertion this suite already makes about captured audit rows still
  // exercises the production write path rather than a stub that always succeeds - the fake
  // prisma is what records into `audit`. The other two are fakes: an alert must never be
  // able to break a login (A3.3) and neither must the device check (A4.4), so the suite
  // asserts on the calls instead of on delivery.
  const auditLog = new PlatformAuditService(prisma);
  const alertCalls: Array<Record<string, unknown>> = [];
  const alerts = {
    raise: jest.fn(async (input: Record<string, unknown>) => {
      alertCalls.push(input);
      return { id: `alert-${alertCalls.length}`, status: 'PENDING', deduped: false };
    }),
  } as unknown as PlatformAlertService;
  const deviceCalls: Array<Record<string, unknown>> = [];
  const devices = {
    observeLogin: jest.fn(async (input: Record<string, unknown>) => {
      deviceCalls.push(input);
      return { outcome: 'known' };
    }),
    seedBaseline: jest.fn(async () => ({ seeded: 0, considered: 0, skipped: false })),
  } as unknown as PlatformDeviceService;

  const service = new PlatformAuthService(prisma, sessions, totp, auditLog, alerts, devices);
  return { service, admins, attempts, audit, revoked, alertCalls, deviceCalls };
}

async function seedAdmin(fixture: Fixture, overrides: Record<string, unknown> = {}) {
  fixture.admins.set(EMAIL, {
    id: 'admin-1',
    email: EMAIL,
    name: 'Owner',
    role: 'PLATFORM_ADMIN',
    status: 'ACTIVE',
    passwordHash: await hashPassword(PASSWORD),
    totpEnabled: true,
    totpLastUsedStep: null,
    failedLoginCount: 0,
    lockedUntil: null,
    mustChangePassword: false,
    ...overrides,
  });
}

describe('R1.3 — 1. the lockout curve', () => {
  it('1a. nothing locks before five failures', () => {
    for (let failures = 0; failures < PLATFORM_LOGIN_MAX_FAILURES; failures++) {
      expect(PlatformAuthService.lockoutDurationMs(failures)).toBe(0);
    }
  });

  it('1b. the fifth failure locks for a minute and each further failure doubles it', () => {
    expect(PlatformAuthService.lockoutDurationMs(5)).toBe(PLATFORM_LOCKOUT_BASE_MS);
    expect(PlatformAuthService.lockoutDurationMs(6)).toBe(PLATFORM_LOCKOUT_BASE_MS * 2);
    expect(PlatformAuthService.lockoutDurationMs(7)).toBe(PLATFORM_LOCKOUT_BASE_MS * 4);
    expect(PlatformAuthService.lockoutDurationMs(8)).toBe(PLATFORM_LOCKOUT_BASE_MS * 8);
  });

  it('1c. it is capped at one hour and never grows past that', () => {
    expect(PlatformAuthService.lockoutDurationMs(20)).toBe(PLATFORM_LOCKOUT_MAX_MS);
    expect(PlatformAuthService.lockoutDurationMs(500)).toBe(PLATFORM_LOCKOUT_MAX_MS);
    expect(PLATFORM_LOCKOUT_MAX_MS).toBe(60 * 60 * 1000);
  });

  it('1d. failures are counted per account in the database', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    for (let attempt = 1; attempt <= 5; attempt++) {
      await expect(fixture.service.login(EMAIL, 'wrong-password')).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
      expect(fixture.admins.get(EMAIL)?.failedLoginCount).toBe(attempt);
    }
    const lockedUntil = fixture.admins.get(EMAIL)?.lockedUntil as Date;
    expect(lockedUntil).toBeInstanceOf(Date);
    expect(lockedUntil.getTime() - Date.now()).toBeGreaterThan(0);
    expect(lockedUntil.getTime() - Date.now()).toBeLessThanOrEqual(PLATFORM_LOCKOUT_BASE_MS + 5000);
  });

  it('1e. a lockout revokes live sessions and is audit-logged', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    for (let attempt = 0; attempt < 5; attempt++) {
      await fixture.service.login(EMAIL, 'wrong-password').catch(() => undefined);
    }
    expect(fixture.revoked).toContain('admin-1');
    const lockRow = fixture.audit.find((row) => row.action === 'admin:account-locked');
    expect(lockRow).toBeTruthy();
    expect(lockRow?.details).toMatchObject({ failures: 5 });
    // no credential may reach the audit trail
    expect(JSON.stringify(fixture.audit)).not.toContain('wrong-password');
    expect(JSON.stringify(fixture.audit)).not.toContain(PASSWORD);
  });

  it('1f. the correct password is refused while the account is locked', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { failedLoginCount: 5, lockedUntil: new Date(Date.now() + 60_000) });
    await expect(fixture.service.login(EMAIL, PASSWORD)).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
    const attempt = fixture.attempts.at(-1);
    expect(attempt?.outcome).toBe('LOCKED');
  });

  it('1g. a successful login clears the counter and the lock', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { failedLoginCount: 3, lockedUntil: new Date(Date.now() - 1000) });
    const result = await fixture.service.login(EMAIL, PASSWORD);
    expect(result.admin.email).toBe(EMAIL);
    expect(fixture.admins.get(EMAIL)?.failedLoginCount).toBe(0);
    expect(fixture.admins.get(EMAIL)?.lockedUntil).toBeNull();
    expect(fixture.attempts.at(-1)?.outcome).toBe('SUCCESS');
  });

  it('1h. a non-ACTIVE administrator cannot log in even with the right password', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { status: 'PENDING_APPROVAL' });
    await expect(fixture.service.login(EMAIL, PASSWORD)).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
  });
});

describe('R1.3 — 2. the per-IP limit', () => {
  it('2a. attempts from one IP are counted and capped', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    for (let attempt = 0; attempt < PLATFORM_IP_MAX_ATTEMPTS; attempt++) {
      await fixture.service.login('nobody@example.com', 'wrong', { ip: '203.0.113.9' }).catch(() => undefined);
    }
    await expect(fixture.service.login(EMAIL, PASSWORD, { ip: '203.0.113.9' })).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
    expect(fixture.attempts.at(-1)?.outcome).toBe('IP_LIMITED');
    // the same credentials from a different IP are not affected by that counter
    const elsewhere = await fixture.service.login(EMAIL, PASSWORD, { ip: '203.0.113.10' });
    expect(elsewhere.admin.email).toBe(EMAIL);
    // 32 argon2id verifies at the product's own parameters (m=64MiB, t=3) are the
    // point of the exercise, so this test is allowed the time they take.
  }, 120_000);
});

describe('R1.3 — 3. unknown email and wrong password are indistinguishable', () => {
  it('3a. both throw the identical message', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    const unknown = await fixture.service.login('nobody@example.com', 'whatever').catch((error: Error) => error.message);
    const wrong = await fixture.service.login(EMAIL, 'whatever').catch((error: Error) => error.message);
    expect(unknown).toBe(PLATFORM_CREDENTIALS_MESSAGE);
    expect(wrong).toBe(PLATFORM_CREDENTIALS_MESSAGE);
  });

  it('3b. both spend exactly ONE argon2 verify - this is the timing fix', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    const verify = argon2.verify as jest.Mock;
    verify.mockClear();
    await fixture.service.login('nobody@example.com', 'whatever').catch(() => undefined);
    expect(verify).toHaveBeenCalledTimes(1);

    verify.mockClear();
    await fixture.service.login(EMAIL, 'whatever').catch(() => undefined);
    expect(verify).toHaveBeenCalledTimes(1);

    verify.mockClear();
    await fixture.service.login(EMAIL, PASSWORD).catch(() => undefined);
    expect(verify).toHaveBeenCalledTimes(1);
  });

  it('3c. the dummy verify really is a verify against an argon2id hash', async () => {
    const fixture = makeFixture();
    const verify = argon2.verify as jest.Mock;
    verify.mockClear();
    await fixture.service.login('nobody@example.com', 'whatever').catch(() => undefined);
    const usedHash = String(verify.mock.calls[0]?.[0] ?? '');
    expect(usedHash.startsWith('$argon2id$')).toBe(true);
    // the dummy hash is a hash of a value that was generated and discarded, so it
    // can never authenticate anybody
    const realVerify = jest.requireActual('argon2').verify as (hash: string, plain: string) => Promise<boolean>;
    expect(await realVerify(usedHash, 'whatever')).toBe(false);
  });

  it('3d. email matching is case- and whitespace-insensitive', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    const result = await fixture.service.login(`  ${EMAIL.toUpperCase()} `, PASSWORD);
    expect(result.admin.email).toBe(EMAIL);
  });

  it('3e. an empty email is not treated as a wildcard', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    await expect(fixture.service.login('', PASSWORD)).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
    await expect(fixture.service.login('   ', PASSWORD)).rejects.toThrow(PLATFORM_CREDENTIALS_MESSAGE);
  });
});

describe('R1.1/R1.4 — 4. what a successful login produces', () => {
  it('4a. a session is created, pending when TOTP is not enrolled', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { totpEnabled: false });
    const result = await fixture.service.login(EMAIL, PASSWORD, { ip: '198.51.100.7', userAgent: 'phone' });
    expect(result.totpPending).toBe(true);
    expect(result.totpEnabled).toBe(false);
    expect(result.token).toBe('token-for-admin-1');
    expect(result.expiresAt.getTime() - Date.now()).toBeGreaterThan(7.9 * 3600_000);
    expect(result.idleExpiresAt.getTime() - Date.now()).toBeLessThan(15 * 60_000 + 5000);
  });

  it('4b. an enrolled administrator is not pending', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { totpEnabled: true });
    const result = await fixture.service.login(EMAIL, PASSWORD);
    expect(result.totpPending).toBe(false);
  });

  it('4c. nothing secret is returned or logged', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    const result = await fixture.service.login(EMAIL, PASSWORD);
    const serialised = JSON.stringify(result);
    expect(serialised).not.toContain(PASSWORD);
    expect(serialised).not.toContain(String(fixture.admins.get(EMAIL)?.passwordHash));
  });
});

describe('R1.2 — 5. the platform password policy', () => {
  it('5a. shorter than 16 characters is refused', () => {
    expect(platformPasswordProblem('a'.repeat(PLATFORM_PASSWORD_MIN_LENGTH - 1))).toMatch(/at least 16/);
    expect(platformPasswordProblem('')).toMatch(/at least 16/);
    expect(PLATFORM_PASSWORD_MIN_LENGTH).toBe(16);
  });

  it('5b. 16 characters of one class is refused, three classes is accepted', () => {
    expect(platformPasswordProblem('a'.repeat(20))).toMatch(/three of/);
    expect(platformPasswordProblem('aaaaaaaaaaaaaaaaaa1')).toMatch(/three of/);
    expect(platformPasswordProblem('aaaaaaaaaaaaaaaaa1A')).toBeNull();
    expect(platformPasswordProblem('aaaaaaaaaaaaaaaaa1!')).toBeNull();
  });

  it('5c. changePassword refuses a weak new password and leaves the stored hash alone', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    const before = String(fixture.admins.get(EMAIL)?.passwordHash);
    await expect(fixture.service.changePassword('admin-1', PASSWORD, 'short')).rejects.toThrow(/at least 16/);
    await expect(fixture.service.changePassword('admin-1', PASSWORD, 'a'.repeat(24))).rejects.toThrow(/three of/);
    expect(String(fixture.admins.get(EMAIL)?.passwordHash)).toBe(before);
    // the old password still works, i.e. nothing was half-written
    expect(await argon2.verify(before, PASSWORD)).toBe(true);
  });

  it('5d. changePassword needs the current password, hashes with the shared options and revokes sessions', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    await expect(fixture.service.changePassword('admin-1', WRONG_PASSWORD, NEW_PASSWORD)).rejects.toThrow(/Current password incorrect/);

    const next = NEW_PASSWORD;
    await expect(fixture.service.changePassword('admin-1', PASSWORD, next)).resolves.toEqual({ ok: true });
    const stored = String(fixture.admins.get(EMAIL)?.passwordHash);
    expect(stored).not.toBe(await hashPassword(PASSWORD));
    expect(await argon2.verify(stored, next)).toBe(true);
    // the same parameters the rest of the product uses
    expect(stored.startsWith('$argon2id$')).toBe(true);
    expect(stored).toContain(`m=${PASSWORD_HASH_OPTIONS.memoryCost}`);
    expect(fixture.revoked).toContain('admin-1');
  });

  it('5e. changePassword refuses while TOTP is not enrolled', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture, { totpEnabled: false });
    await expect(fixture.service.changePassword('admin-1', PASSWORD, NEW_PASSWORD)).rejects.toThrow(/totp-not-enrolled/);
  });
});

describe('R1.3 — 6. every attempt is recorded', () => {
  it('6a. success, failure, lockout and IP limiting all leave a row', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    await fixture.service.login(EMAIL, PASSWORD, { ip: '198.51.100.1' }).catch(() => undefined);
    await fixture.service.login(EMAIL, 'wrong', { ip: '198.51.100.1' }).catch(() => undefined);
    await fixture.service.login('nobody@example.com', 'wrong', { ip: '198.51.100.1' }).catch(() => undefined);
    const outcomes = fixture.attempts.map((row) => row.outcome);
    expect(outcomes).toContain('SUCCESS');
    expect(outcomes.filter((outcome) => outcome === 'BAD_CREDENTIALS').length).toBe(2);
    // an unknown email is recorded as a failure too, without inventing an account
    const unknownRow = fixture.attempts.find((row) => row.detail === 'unknown-email');
    expect(unknownRow?.email).toBe('nobody@example.com');
  });

  it('6b. no attempt row or audit row ever contains a password', async () => {
    const fixture = makeFixture();
    await seedAdmin(fixture);
    await fixture.service.login(EMAIL, 'wrong', { ip: '198.51.100.2' }).catch(() => undefined);
    await fixture.service.login(EMAIL, PASSWORD, { ip: '198.51.100.2' }).catch(() => undefined);
    const everything = JSON.stringify([...fixture.attempts, ...fixture.audit]);
    expect(everything).not.toContain('wrong');
    expect(everything).not.toContain(PASSWORD);
  });
});
