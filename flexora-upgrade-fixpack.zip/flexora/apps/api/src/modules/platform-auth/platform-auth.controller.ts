/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — the console's authentication endpoints.
 *
 * Authentication itself is done by the global guards, in this order:
 *   AdminHostGuard (R0) -> LicenceAvailabilityGuard -> PlatformSessionGuard
 *   -> PlatformTotpEnrolmentGuard -> PlatformStepUpGuard -> PlatformCsrfGuard.
 * So this controller declares WHAT each route needs by metadata — @PlatformRoute(),
 * @Public(), @AllowedBeforeTotp('why'), @RequireStepUp('why'),
 * @PlatformCsrfExempt('why') — and never re-implements a credential check. The one
 * guard still applied per-controller is PlatformAdminGuard, which enforces the
 * PLATFORM_VIEWER read-only rule.
 *
 * Route map (all under /api/platform/auth):
 *   POST login                public, CSRF-exempt (Origin still checked)
 *   GET  me                   allowed before TOTP, so the console can learn its state
 *   POST logout               allowed before TOTP; revoking must always work
 *   POST totp/enrol           allowed before TOTP: this is the enrolment flow
 *   POST totp/verify          allowed before TOTP: completing enrolment
 *   POST step-up              requires an enrolled admin; rotates the session
 *   POST change-password      requires step-up (R1.2, R1.5)
 *   POST recovery-codes       requires step-up (R1.1)
 *   POST csp-report           public, CSRF-exempt: a browser posts this without credentials
 *
 * No response and no log line from this file contains a password, a TOTP secret, a
 * recovery code or a session token.
 */
import { Body, Controller, Get, HttpCode, Post, Req, Res, UnauthorizedException, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { IsEmail, IsString, Matches, MaxLength } from 'class-validator';
import { Request, Response } from 'express';
import { randomBytes } from 'crypto';
import { PlatformAdminGuard } from '../../common/guards/platform-admin.guard';
import { Public } from '../../common/decorators/public.decorator';
import { PlatformRoute } from '../../common/decorators/platform-route.decorator';
import {
  AllowedBeforeTotp,
  PlatformCsrfExempt,
  RequireStepUp,
} from '../../common/decorators/platform-auth.decorators';
import { BruteForceGuard } from '../../common/guards/brute-force.guard';
import { BruteForceService } from '../../common/security/brute-force.service';
import { isCookieSecure } from '../../config/cookie-secure';
import { PrismaService } from '../../config/prisma.service';
import { PlatformAuthService } from './platform-auth.service';
import { PlatformTotpService } from './platform-totp.service';
import { PlatformAuditService } from '../platform/platform-audit.service';
import {
  PLATFORM_COOKIE_NAME,
  PLATFORM_CSRF_COOKIE_NAME,
  PlatformSessionService,
  platformCookieOptions,
} from './platform-session.service';
import type { PlatformRequest } from '../../common/guards/platform-session.guard';

class PlatformLoginDto {
  @IsEmail()
  @MaxLength(254)
  email!: string;

  @IsString()
  @MaxLength(256)
  password!: string;
}

class TotpCodeDto {
  /** Six digits, or a 25-character recovery code with optional dashes/spaces. */
  @IsString()
  @MaxLength(64)
  code!: string;
}

class ChangePasswordDto {
  @IsString()
  @MaxLength(256)
  currentPassword!: string;

  @IsString()
  @MaxLength(256)
  newPassword!: string;
}

class StepUpDto {
  @IsString()
  @Matches(/^\d{6}$/, { message: 'code must be the six digits from your authenticator' })
  code!: string;
}

@ApiTags('platform-auth')
@Controller('platform/auth')
/**
 * PHASE R0 — the class-level marker puts every route in this controller behind the
 * host gate. PHASE R1 relies on the same marker for the credential, enrolment,
 * step-up and CSRF guards, which is why review item 4 can be enforced by a test
 * that enumerates controllers rather than URLs.
 */
@PlatformRoute()
@UseGuards(PlatformAdminGuard)
export class PlatformAuthController {
  constructor(
    private readonly auth: PlatformAuthService,
    private readonly totp: PlatformTotpService,
    private readonly sessions: PlatformSessionService,
    private readonly bruteForceService: BruteForceService,
    private readonly prisma: PrismaService,
    // PHASE R3 (R3.6) - the two step-up audit rows this controller writes directly now go
    // through the single writer, so they carry ip, user agent and stepUpUsed.
    private readonly auditLog: PlatformAuditService,
  ) {}

  @Public()
  @PlatformCsrfExempt('pre-authentication: no session cookie exists yet to double-submit. The Origin/Referer check still applies, and BruteForceGuard plus the per-account and per-IP lockouts cover credential stuffing.')
  @UseGuards(BruteForceGuard)
  @Throttle({ auth: { limit: 5, ttl: 60000 }, default: { limit: 5, ttl: 60000 } })
  @Post('login')
  async login(
    @Body() dto: PlatformLoginDto,
    @Res({ passthrough: true }) res: Response,
    @Req() req: PlatformRequest & { __bruteForce?: { scope: string; key: string } },
  ) {
    try {
      const result = await this.auth.login(dto.email, dto.password, {
        ip: req.ip ?? null,
        userAgent: req.headers['user-agent'] ?? null,
      });
      if (req.__bruteForce) {
        await this.bruteForceService.reset(req.__bruteForce.scope, req.__bruteForce.key).catch(() => undefined);
      }
      this.setSessionCookies(res, result.token);
      return {
        admin: result.admin,
        totpPending: result.totpPending,
        totpEnabled: result.totpEnabled,
        expiresAt: result.expiresAt,
        idleExpiresAt: result.idleExpiresAt,
      };
    } catch (error) {
      if (req.__bruteForce) {
        await this.bruteForceService.registerFailure(req.__bruteForce.scope, req.__bruteForce.key).catch(() => undefined);
      }
      throw error;
    }
  }

  @Get('me')
  @AllowedBeforeTotp('the console must be able to ask whether enrolment is outstanding, or it cannot render the enrolment screen')
  async me(@Req() req: PlatformRequest) {
    const admin = await this.prisma.platformAdmin.findUniqueOrThrow({ where: { id: req.user?.id ?? '' } });
    return this.auth.describeSession(admin, req.platformSessionId ?? '');
  }

  @Post('logout')
  @HttpCode(200)
  @AllowedBeforeTotp('revoking a session must work in every state, including a pending one')
  async logout(@Req() req: PlatformRequest, @Res({ passthrough: true }) res: Response) {
    const admin = req.user ? await this.prisma.platformAdmin.findUnique({ where: { id: req.user.id } }) : null;
    await this.auth.logout(req.platformSessionId ?? '', admin, 'logout', {
      ip: req.ip ?? null,
      userAgent: req.headers['user-agent'] ?? null,
    });
    this.clearSessionCookies(res);
    return { ok: true };
  }

  /** Step one of enrolment: the QR payload and the manual key, shown exactly once. */
  @Post('totp/enrol')
  @HttpCode(200)
  @AllowedBeforeTotp('this is the enrolment flow itself')
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  async beginTotpEnrolment(@Req() req: PlatformRequest) {
    const enrolment = await this.totp.beginEnrolment(req.user?.id ?? '', { ip: req.ip ?? null, userAgent: req.headers['user-agent'] ?? null });
    // The secret and the QR are returned once and never stored in plain text.
    return {
      secret: enrolment.secret,
      otpauthUrl: enrolment.otpauthUrl,
      qrCodeDataUrl: enrolment.qrCodeDataUrl,
      issuer: enrolment.issuer,
    };
  }

  /** Step two: prove possession, enable TOTP, issue the ten recovery codes once. */
  @Post('totp/verify')
  @HttpCode(200)
  @AllowedBeforeTotp('completing enrolment is what ends the pending state')
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  async completeTotpEnrolment(@Body() dto: TotpCodeDto, @Req() req: PlatformRequest) {
    const result = await this.totp.completeEnrolment(req.user?.id ?? '', dto.code, { ip: req.ip ?? null, userAgent: req.headers['user-agent'] ?? null });
    if (req.platformSessionId) await this.sessions.setTotpPending(req.platformSessionId, false);
    return {
      enrolled: true,
      enrolledAt: result.enrolledAt,
      // Shown once. There is no endpoint that returns these again.
      recoveryCodes: result.recoveryCodes,
    };
  }

  /**
   * R1.5: a fresh TOTP assertion, valid for five minutes on THIS session. The
   * session is rotated (R1.4), so the assertion is bound to a new token and the
   * old one stops working immediately.
   */
  @Post('step-up')
  @HttpCode(200)
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  async stepUp(
    @Body() dto: StepUpDto,
    @Req() req: PlatformRequest,
    @Res({ passthrough: true }) res: Response,
  ) {
    const admin = await this.prisma.platformAdmin.findUniqueOrThrow({ where: { id: req.user?.id ?? '' } });
    const verified = await this.totp.verifySecondFactor(admin, dto.code);
    if (!verified.ok) {
      await this.auditLog.record({
        adminId: admin.id,
        adminName: admin.name,
        action: 'admin:step-up-refused',
        target: admin.id,
        details: { reason: verified.reason ?? 'invalid' },
        reason: verified.reason ?? 'invalid',
        ip: req.ip ?? null,
        userAgent: req.headers['user-agent'] ?? null,
        // A refused step-up is by definition not step-up authorised.
        stepUpUsed: false,
      });
      // Same status and shape as a bad password at login: no oracle here either.
      throw new UnauthorizedException('Invalid credentials');
    }

    const current = await this.prisma.platformSession.findUniqueOrThrow({ where: { id: req.platformSessionId ?? '' } });
    const rotated = await this.sessions.rotate({
      session: current,
      admin,
      reason: 'step-up-rotation',
      ip: req.ip ?? null,
      userAgent: req.headers['user-agent'] ?? null,
    });
    const stamped = await this.sessions.recordStepUp(rotated.sessionId);
    this.setSessionCookies(res, rotated.token);
    await this.auditLog.record({
      adminId: admin.id,
      adminName: admin.name,
      action: 'admin:step-up',
      target: admin.id,
      details: { via: verified.via ?? 'totp', expiresAt: stamped.stepUpExpiresAt?.toISOString() ?? null },
      ip: req.ip ?? null,
      userAgent: req.headers['user-agent'] ?? null,
      // R3.6 - the row records that a fresh second factor authorised this action, which is
      // what lets an auditor separate a step-up-protected change from an ordinary one.
      stepUpUsed: true,
    });
    return { ok: true, stepUpExpiresAt: stamped.stepUpExpiresAt, rotated: true };
  }

  @Post('change-password')
  @RequireStepUp('change the console password')
  async changePassword(@Body() dto: ChangePasswordDto, @Req() req: PlatformRequest, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.changePassword(req.user?.id ?? '', dto.currentPassword, dto.newPassword);
    // changePassword revoked every session for this administrator, including this
    // one, so the cookie must go: the next action is a fresh login.
    this.clearSessionCookies(res);
    return result;
  }

  @Post('recovery-codes')
  @HttpCode(200)
  @RequireStepUp('regenerate recovery codes')
  async regenerateRecoveryCodes(@Body() dto: StepUpDto, @Req() req: PlatformRequest) {
    const admin = await this.prisma.platformAdmin.findUniqueOrThrow({ where: { id: req.user?.id ?? '' } });
    const result = await this.totp.regenerateRecoveryCodes(admin, dto.code, { ip: req.ip ?? null, userAgent: req.headers['user-agent'] ?? null, stepUpUsed: true });
    return { recoveryCodes: result.recoveryCodes };
  }

  /**
   * R1.8 / decision D1: the sink for console Content-Security-Policy violations.
   * Public because a browser posts these without credentials, and CSRF-exempt for
   * the same reason — but it is still behind the R0 host gate, so it only exists on
   * an admin hostname, and it is throttled so it cannot be used to fill the log.
   */
  @Public()
  @PlatformCsrfExempt('a browser posts a CSP report without credentials and without a CSRF cookie; the route is behind the R0 host gate and throttled')
  @Throttle({ default: { limit: 30, ttl: 60000 } })
  @Post('csp-report')
  @HttpCode(204)
  async cspReport(@Body() body: unknown) {
    const report = (body as { 'csp-report'?: Record<string, unknown> })?.['csp-report'] ?? (body as Record<string, unknown>) ?? {};
    const pick = (key: string) => {
      const value = report[key];
      return typeof value === 'string' ? value.slice(0, 300) : null;
    };
    await this.prisma.platformLog
      .create({
        data: {
          type: 'csp-violation',
          content: pick('violated-directive') ?? 'csp-violation',
          meta: {
            blockedURI: pick('blocked-uri'),
            documentURI: pick('document-uri'),
            effectiveDirective: pick('effective-directive'),
            originalPolicy: null, // the policy is known; storing it would only bloat the row
            sourceFile: pick('source-file'),
            statusCode: typeof report['status-code'] === 'number' ? report['status-code'] : null,
          } as object,
        },
      })
      .catch(() => undefined);
    // 204 with no body: nothing here may echo the report back.
    return undefined;
  }

  // --- cookie handling, in one place ---------------------------------------

  private setSessionCookies(res: Response, token: string) {
    res.cookie(PLATFORM_COOKIE_NAME, token, platformCookieOptions());
    // Readable on purpose: this is the double-submit partner for R1.6. It carries
    // no identity and is useless without the httpOnly session cookie beside it.
    res.cookie(PLATFORM_CSRF_COOKIE_NAME, randomBytes(24).toString('hex'), {
      httpOnly: false,
      secure: isCookieSecure(),
      sameSite: 'strict',
      path: '/',
      maxAge: platformCookieOptions().maxAge,
    });
  }

  private clearSessionCookies(res: Response) {
    res.clearCookie(PLATFORM_COOKIE_NAME, { path: '/' });
    res.clearCookie(PLATFORM_CSRF_COOKIE_NAME, { path: '/' });
  }
}
