/**
 * FLEXORA Gym OS — Gym onboarding wizard API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, ParseIntPipe, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { OnboardingService } from './onboarding.service';
import { IsObject } from 'class-validator';

class SaveStepDto {
  @IsObject() data!: Record<string, unknown>;
}

@Controller('onboarding')
@UseGuards(JwtAuthGuard, TenantGuard)
@ApiTags('onboarding')
@ApiBearerAuth()
export class OnboardingController {
  constructor(private readonly onboarding: OnboardingService) {}

  @Post('step/:step') @Permissions('profile.self')
  saveStep(@CurrentUser('sub') userId: string, @Param('step', ParseIntPipe) step: number, @Body() dto: SaveStepDto) {
    return this.onboarding.saveStep(userId, step, dto.data);
  }

  @Get('progress') @Permissions('profile.self')
  getProgress(@CurrentUser('sub') userId: string) {
    return this.onboarding.getProgress(userId);
  }

  @Post('complete') @Permissions('profile.self')
  complete(@CurrentUser('sub') userId: string) {
    return this.onboarding.complete(userId);
  }
}
