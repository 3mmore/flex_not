/**
 * FLEXORA Gym OS — Onboarding regression tests.
 *
 * P0 (live round, 2026-09):
 *  - The theme color chosen during onboarding (step 2) MUST be persisted to
 *    Gym.accentColor — a previous regression left every new gym on the
 *    default blue (#6366F1) despite the owner picking a custom color.
 *  - The logo uploaded during onboarding (step 1) MUST be persisted to
 *    Gym.logo.
 *  - ONLY the branches the owner typed in step 5 are created — seeded demo
 *    branches (Maadi/Nasr City) must never appear for a real signup.
 */
import { OnboardingService } from './onboarding.service';

function makeService() {
  const gymUpdate = jest.fn().mockResolvedValue({});
  const branchFindFirst = jest.fn().mockResolvedValue(null);
  const branchCreate = jest.fn().mockResolvedValue({ id: 'b' });
  const planFindFirst = jest.fn().mockResolvedValue(null);
  const planCreate = jest.fn().mockResolvedValue({ id: 'p' });
  const progressUpsert = jest.fn().mockResolvedValue({});
  const userUpdate = jest.fn().mockResolvedValue({});

  // tenant transaction client handed to the withTenant callback
  const tx: any = {
    gym: { update: gymUpdate },
    branch: { findFirst: branchFindFirst, create: branchCreate },
    plan: { findFirst: planFindFirst, create: planCreate },
    onboardingProgress: { upsert: progressUpsert },
    user: { update: userUpdate },
  };

  const prisma: any = {
    user: {
      findUnique: jest.fn().mockResolvedValue({
        id: 'u1',
        gymId: 'g1',
        onboardingCompleted: false,
        gym: { name: 'Old Name', accentColor: '#6366F1', logo: null, phone: '01000000000', address: null },
      }),
    },
    onboardingProgress: { findUnique: jest.fn() },
    withTenant: jest.fn(async (_gymId: string, cb: (t: unknown) => Promise<unknown>) => cb(tx)),
  };

  const svc = new OnboardingService(prisma);
  return { svc, prisma, tx, gymUpdate, branchCreate, branchFindFirst };
}

describe('OnboardingService.complete — branding + branches persistence', () => {
  it('persists the step-2 accent color and step-1 logo onto the gym (theme regression)', async () => {
    const { svc, prisma, gymUpdate } = makeService();
    prisma.onboardingProgress.findUnique.mockResolvedValue({
      userId: 'u1',
      currentStep: 7,
      step1Data: { gymName: 'Red Gym', phone: '01011112222', logo: 'data:image/png;base64,AAA' },
      step2Data: { primaryColor: '#ff0000' },
      step3Data: { plans: [] },
      step5Data: { branches: [{ name: 'الفرع الوحيد' }] },
    });

    await svc.complete('u1');

    expect(gymUpdate).toHaveBeenCalledTimes(1);
    const data = gymUpdate.mock.calls[0][0].data;
    expect(data.accentColor).toBe('#ff0000'); // NOT the #6366F1 default
    expect(data.logo).toBe('data:image/png;base64,AAA');
  });

  it('creates exactly the branches from step 5 — never any demo branches', async () => {
    const { svc, prisma, branchCreate } = makeService();
    prisma.onboardingProgress.findUnique.mockResolvedValue({
      userId: 'u1',
      currentStep: 7,
      step1Data: { gymName: 'My Gym', phone: '01011112222' },
      step2Data: { primaryColor: '#00ff00' },
      step3Data: { plans: [] },
      step5Data: { branches: [{ name: 'الفرع الوحيد', address: 'X', phone: '01099998888' }] },
    });

    await svc.complete('u1');

    const createdNames = branchCreate.mock.calls.map((c) => c[0].data.name);
    expect(createdNames).toEqual(['الفرع الوحيد']);
    // The seeded demo branches must never be created for a real signup.
    for (const n of createdNames) {
      expect(n).not.toMatch(/المعادي|معادي|ماادي|نصر سيتي|نصر سيتي|Maadi|Nasr/i);
    }
  });

  it('does not overwrite a chosen color with the default when step 2 was saved', async () => {
    const { svc, prisma, gymUpdate } = makeService();
    prisma.onboardingProgress.findUnique.mockResolvedValue({
      userId: 'u1',
      currentStep: 7,
      step1Data: { gymName: 'G', phone: '01011112222' },
      step2Data: { primaryColor: '#123456' },
      step3Data: { plans: [] },
      step5Data: { branches: [] },
    });

    await svc.complete('u1');
    expect(gymUpdate.mock.calls[0][0].data.accentColor).toBe('#123456');
  });
});
