/**
 * FLEXORA Gym OS — Gym onboarding wizard service
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { normalizeHexColor } from '../../common/validation/color';
import { PrismaService } from '../../config/prisma.service';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';

import { Prisma } from '@prisma/client';

@Injectable()
export class OnboardingService {
  constructor(private readonly prisma: PrismaService) {}

  /** P1: the wizard used to persist ANY string as the gym/branch phone.
   *  Validate at save time so the owner gets an immediate, clear error. */
  private assertEgyptianPhone(value: unknown, label: string) {
    if (value === undefined || value === null || value === '') return; // optional
    if (typeof value !== 'string' || !EG_PHONE.test(value.trim())) {
      throw new BadRequestException(`${label}: ${EG_PHONE_MESSAGE}`);
    }
  }

  async saveStep(userId: string, step: number, data: unknown) {
    if (!Number.isInteger(step) || step < 1 || step > 6) throw new BadRequestException('Invalid onboarding step');
    const d = (data && typeof data === 'object' ? data : {}) as Record<string, any>;
    if (step === 1) this.assertEgyptianPhone(d.phone, 'gym phone');
    if (step === 5 && Array.isArray(d.branches)) {
      for (const b of d.branches as Array<Record<string, any>>) {
        this.assertEgyptianPhone(b?.phone, 'branch phone');
      }
    }
    const key = `step${step}Data` as 'step1Data' | 'step2Data' | 'step3Data' | 'step4Data' | 'step5Data' | 'step6Data';
    return this.prisma.onboardingProgress.upsert({
      where: { userId },
      update: { currentStep: Math.min(step + 1, 7), [key]: data as Prisma.InputJsonValue },
      create: { userId, currentStep: Math.min(step + 1, 7), [key]: data as Prisma.InputJsonValue },
    });
  }

  async getProgress(userId: string) {
    const progress = await this.prisma.onboardingProgress.findUnique({ where: { userId } });
    if (progress) return progress;
    return this.prisma.onboardingProgress.create({ data: { userId, currentStep: 1 } });
  }

  async complete(userId: string): Promise<{ gymId: string; dashboardUrl: string }> {
    const user = await this.prisma.user.findUnique({ where: { id: userId }, include: { gym: true } });
    if (!user) throw new NotFoundException('User not found');
    if (user.onboardingCompleted) return { gymId: user.gymId, dashboardUrl: '/dashboard' };

    const progress = await this.prisma.onboardingProgress.findUnique({ where: { userId } });
    const step1 = (progress?.step1Data as Record<string, any>) || {};
    const step2 = (progress?.step2Data as Record<string, any>) || {};
    const step3 = (progress?.step3Data as Record<string, any>) || {};
    const step5 = (progress?.step5Data as Record<string, any>) || {};
    if (!step1.gymName && !user.gym?.name) throw new BadRequestException('Gym name is required');
    // Defensive re-check: drafts saved before phone validation existed must
    // not be able to write an invalid phone into the gym record at completion.
    this.assertEgyptianPhone(step1.phone, 'gym phone');
    if (Array.isArray(step5.branches)) {
      for (const b of step5.branches as Array<Record<string, any>>) {
        this.assertEgyptianPhone(b?.phone, 'branch phone');
      }
    }
    const plans = Array.isArray(step3.plans) ? (step3.plans as Record<string, any>[]) : [];

    await this.prisma.withTenant(user.gymId, async (tx) => {
      const cityLabel = step1.city === 'other' ? step1.otherCity : step1.city;
      const fullAddress = [cityLabel, step1.address].filter(Boolean).join(', ');
      
      try {
        await tx.gym.update({
          where: { id: user.gymId },
          data: {
            name: step1.gymName || user.gym.name,
            phone: step1.phone || user.gym.phone,
            address: fullAddress || user.gym.address,
            // The wizard's color is what the gym will see everywhere; ignore
            // anything that is not a hex color instead of writing a value the
            // shell cannot derive --brand-rgb from.
            accentColor: normalizeHexColor(step2.primaryColor) || user.gym.accentColor,
            logo: step1.logo || user.gym.logo,
            status: 'ACTIVE',
          },
        });
      } catch (error) {
        if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
          throw new ConflictException({
            code: 'GYM_UPDATE_CONFLICT',
            translationKey: 'error_already_exists',
            message: 'A conflict occurred while updating gym data.',
          });
        }
        throw error;
      }

      // Phase 4 (4.2 + 4.4): the onboarding step that used to be a free-text
      // "add your team" textarea persisted NOTHING. It is replaced by a real
      // branches step, and those branches are actually created here. Staff are
      // added — and assigned to these real branches — from the dashboard staff
      // page, which is the single coherent place for staff-to-branch mapping.
      const branchDrafts = Array.isArray(step5.branches) ? (step5.branches as Record<string, any>[]) : [];
      for (const draft of branchDrafts) {
        const name = String(draft?.name || '').trim();
        if (!name) continue;
        const existingBranch = await tx.branch.findFirst({ where: { gymId: user.gymId, name } });
        if (existingBranch) continue;
        await tx.branch.create({
          data: {
            gymId: user.gymId,
            name,
            address: draft.address ? String(draft.address) : null,
            phone: draft.phone ? String(draft.phone) : null,
          },
        });
      }

      for (const plan of plans) {
        if (!plan.name || Number(plan.price) < 0) continue;
        const planType = plan.accessType === 'sessions' ? 'SESSION' : 'TIME';
        const planPrice = Number(plan.price || 0);
        const existingPlan = await tx.plan.findFirst({
          where: { gymId: user.gymId, name: String(plan.name), type: planType, price: planPrice }
        });
        if (existingPlan) continue;

        try {
          await tx.plan.create({
            data: {
              gymId: user.gymId,
              name: String(plan.name),
              type: planType,
              price: planPrice,
              days: Number(plan.duration || 30),
              sessions: planType === 'SESSION' ? Number(plan.maxSessions || 12) : null,
            },
          });
        } catch (error) {
          if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') continue;
          throw error;
        }
      }
      await tx.onboardingProgress.upsert({ where: { userId }, update: { completed: true, completedAt: new Date(), currentStep: 7 }, create: { userId, completed: true, completedAt: new Date(), currentStep: 7 } });
      await tx.user.update({ where: { id: userId }, data: { onboardingCompleted: true } });
    });
    return { gymId: user.gymId, dashboardUrl: '/dashboard' };
  }
}
