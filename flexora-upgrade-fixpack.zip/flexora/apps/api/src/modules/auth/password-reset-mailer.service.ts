/**
 * FLEXORA Gym OS — Password reset email delivery
 */
import { isProduction } from '../../config/env-mode';
import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

@Injectable()
export class PasswordResetMailer {
  private transporter: nodemailer.Transporter | null = null;

  constructor() {
    if (process.env.SMTP_HOST) {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: Number(process.env.SMTP_PORT || 587) === 465,
        auth: process.env.SMTP_USER
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined,
      });
    }
  }

  async sendPasswordReset(to: string, token: string): Promise<void> {
    const baseUrl = process.env.PUBLIC_BASE_URL || process.env.CORS_ORIGIN || 'http://localhost:3000';
    const resetUrl = `${baseUrl.replace(/\/$/, '')}/reset-password?token=${encodeURIComponent(token)}`;

    if (!this.transporter) {
      if (isProduction()) {
        throw new ServiceUnavailableException('Password reset email provider is not configured');
      }
      // Non-production delivery: do not log reset tokens or URLs.
      if (!isProduction()) {
        // eslint-disable-next-line no-console
        console.warn(`[dev] password reset email provider is not configured for ${to}`);
      }
      return;
    }

    await this.transporter.sendMail({
      from: process.env.SMTP_FROM || 'FLEXORA <no-reply@flexora.app>',
      to,
      subject: 'Reset your FLEXORA password',
      text: `Reset your FLEXORA password: ${resetUrl}\n\nThis link expires in 30 minutes and can be used once.`,
      html: `<p>Reset your FLEXORA password:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>This link expires in 30 minutes and can be used once.</p>`,
    });
  }
}
