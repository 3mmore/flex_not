/**
 * FLEXORA Gym OS — JwtStrategy unit tests
 * Tests cover: constructor validation, token extraction, payload validation
 */
import { JwtStrategy } from './jwt.strategy';
import { ConfigService } from '@nestjs/config';

function createMockConfig(secret?: string) {
  return {
    get: jest.fn((key: string) => (key === 'JWT_ACCESS_SECRET' ? secret : undefined)),
  } as unknown as ConfigService;
}

/**
 * ROUND 14 (security review, PHASE C): the strategy re-checks the user's
 * active flag on every request through the SECURITY DEFINER function
 * preauth_find_user_by_id (a plain prisma.user.findUnique would be filtered
 * to zero rows by FORCE RLS — see jwt.strategy.ts). The mock mirrors that
 * contract: $queryRaw resolves the active user row.
 */
function createMockPrisma(userId: string, active = true) {
  return {
    $queryRaw: jest.fn(async () => [{ id: userId, active }]),
  } as any;
}

describe('JwtStrategy', () => {
  describe('constructor', () => {
    it('throws if JWT_ACCESS_SECRET is not set', () => {
      const config = createMockConfig(undefined);
      expect(() => new JwtStrategy(config)).toThrow('JWT_ACCESS_SECRET is required');
    });

    it('constructs successfully with a valid secret', () => {
      const config = createMockConfig('test-secret-key-min-32-chars!!');
      const strategy = new JwtStrategy(config);
      expect(strategy).toBeDefined();
    });
  });

  describe('validate', () => {
    it('extracts user fields from JWT payload', async () => {
      const config = createMockConfig('test-secret-key-min-32-chars!!');
      const strategy = new JwtStrategy(config, createMockPrisma('user-123'));

      const result = await strategy.validate({
        sub: 'user-123',
        email: 'test@gym.com',
        role: 'OWNER',
        gymId: 'gym-456',
      });

      expect(result).toEqual(expect.objectContaining({
        id: 'user-123',
        sub: 'user-123',
        email: 'test@gym.com',
        role: 'OWNER',
        gymId: 'gym-456',
      }));
    });

    it('passes null gymId for platform-level users', async () => {
      const config = createMockConfig('test-secret-key-min-32-chars!!');
      const strategy = new JwtStrategy(config, createMockPrisma('admin-1'));

      const result = await strategy.validate({
        sub: 'admin-1',
        email: 'admin@platform.com',
        role: 'SUPER_ADMIN',
        gymId: null,
      });

      expect(result.gymId).toBeNull();
      expect(result.role).toBe('SUPER_ADMIN');
    });

    it('maps sub to id correctly', async () => {
      const config = createMockConfig('test-secret-key-min-32-chars!!');
      const strategy = new JwtStrategy(config, createMockPrisma('abc-def-ghi'));

      const result = await strategy.validate({
        sub: 'abc-def-ghi',
        email: 'x@y.com',
        role: 'STAFF',
        gymId: 'gym-1',
      });

      expect(result.id).toBe('abc-def-ghi');
    });
    it('rejects an INACTIVE user (the per-request active re-check)', async () => {
      const config = createMockConfig('test-secret-key-min-32-chars!!');
      const strategy = new JwtStrategy(config, createMockPrisma('user-123', false));
      const result = await strategy.validate({
        sub: 'user-123',
        email: 'test@gym.com',
        role: 'OWNER',
        gymId: 'gym-456',
      });
      expect(result).toBeNull();
    });

  });
});
