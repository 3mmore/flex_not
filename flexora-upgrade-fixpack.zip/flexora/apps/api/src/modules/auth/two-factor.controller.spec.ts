/**
 * FLEXORA Gym OS — TwoFactorController unit tests
 * Tests cover: setup (auth-gated), loginStep (temp token verification, lockout, code check), disable
 */
import { HttpException, HttpStatus, UnauthorizedException } from '@nestjs/common';
import { TwoFactorController } from './two-factor.controller';
import { Response } from 'express';

function createMockTwoFactorService() {
  return {
    setup: jest.fn(),
    verifySetup: jest.fn(),
    verifyCode: jest.fn(),
    disable: jest.fn(),
  };
}

function createMockAuthService() {
  return {
    verifyTwoFaLogin: jest.fn(),
  };
}

function createMockJwtService() {
  return {
    verifyAsync: jest.fn(),
  };
}

function createMockBruteForceService() {
  return {
    check: jest.fn(),
    checkAndIncrement: jest.fn(),
    reset: jest.fn(),
  };
}

function createMockConfigService() {
  return {
    get: jest.fn((key: string) => {
      if (key === 'JWT_ACCESS_SECRET') return 'test-secret';
      return undefined;
    }),
  };
}

function createMockResponse(): Response {
  return {
    cookie: jest.fn(),
  } as unknown as Response;
}

describe('TwoFactorController', () => {
  let controller: TwoFactorController;
  let twofa: ReturnType<typeof createMockTwoFactorService>;
  let auth: ReturnType<typeof createMockAuthService>;
  let jwt: ReturnType<typeof createMockJwtService>;
  let bf: ReturnType<typeof createMockBruteForceService>;
  let config: ReturnType<typeof createMockConfigService>;

  beforeEach(() => {
    twofa = createMockTwoFactorService();
    auth = createMockAuthService();
    jwt = createMockJwtService();
    bf = createMockBruteForceService();
    config = createMockConfigService();
    controller = new TwoFactorController(twofa as any, auth as any, jwt as any, bf as any, config as any);
  });

  describe('setup', () => {
    it('delegates to TwoFactorService.setup with userId', () => {
      twofa.setup.mockResolvedValue({ secret: 'SEC', otpauthUrl: 'otpauth://...', qrCodeDataUrl: 'data:...', backupCodes: [] });
      controller.setup('user-1');
      expect(twofa.setup).toHaveBeenCalledWith('user-1');
    });
  });

  describe('verifySetup', () => {
    it('delegates to TwoFactorService.verifySetup', () => {
      twofa.verifySetup.mockResolvedValue({ ok: true });
      controller.verifySetup('user-1', { code: '123456' });
      expect(twofa.verifySetup).toHaveBeenCalledWith('user-1', '123456');
    });
  });

  describe('loginStep', () => {
    const mockRes = createMockResponse();

    it('rejects invalid/expired temp token with 401', async () => {
      jwt.verifyAsync.mockRejectedValue(new Error('invalid'));
      await expect(
        controller.loginStep({ tempToken: 'bad', code: '123456' }, mockRes),
      ).rejects.toThrow(HttpException);

      try {
        await controller.loginStep({ tempToken: 'bad', code: '123456' }, mockRes);
      } catch (e: any) {
        expect(e.getStatus()).toBe(HttpStatus.UNAUTHORIZED);
      }
    });

    it('rejects temp token with wrong stage', async () => {
      jwt.verifyAsync.mockResolvedValue({ sub: 'user-1', stage: 'access' });
      await expect(
        controller.loginStep({ tempToken: 'tok', code: '123456' }, mockRes),
      ).rejects.toThrow(HttpException);
    });

    it('returns 429 when per-account lockout is active', async () => {
      jwt.verifyAsync.mockResolvedValue({ sub: 'user-1', stage: '2fa' });
      bf.check.mockResolvedValue({ allowed: false, retryAfterSeconds: 300 });

      try {
        await controller.loginStep({ tempToken: 'tok', code: '123456' }, mockRes);
      } catch (e: any) {
        expect(e.getStatus()).toBe(HttpStatus.TOO_MANY_REQUESTS);
        expect(e.getResponse().retryAfterSeconds).toBe(300);
      }
    });

    it('returns 401 on invalid TOTP code and records failure', async () => {
      jwt.verifyAsync.mockResolvedValue({ sub: 'user-1', stage: '2fa' });
      bf.check.mockResolvedValue({ allowed: true });
      auth.verifyTwoFaLogin.mockRejectedValue(new UnauthorizedException('Invalid TOTP code'));
      bf.checkAndIncrement.mockResolvedValue(undefined);

      try {
        await controller.loginStep({ tempToken: 'tok', code: '000000' }, mockRes);
      } catch (e: any) {
        expect(e.getStatus()).toBe(HttpStatus.UNAUTHORIZED);
        expect(bf.checkAndIncrement).toHaveBeenCalledWith('2fa:user-1');
      }
    });

    it('issues tokens on valid code and resets lockout counter', async () => {
      jwt.verifyAsync.mockResolvedValue({ sub: 'user-1', stage: '2fa' });
      bf.check.mockResolvedValue({ allowed: true });
      twofa.verifyCode.mockResolvedValue(true);
      auth.verifyTwoFaLogin.mockResolvedValue({
        accessToken: 'at',
        refreshToken: 'rt',
        requires2FA: false,
      });

      const result = await controller.loginStep({ tempToken: 'tok', code: '123456' }, mockRes);

      expect(bf.reset).toHaveBeenCalledWith('2fa:user-1');
      expect(auth.verifyTwoFaLogin).toHaveBeenCalledWith('tok', '123456');
      expect(mockRes.cookie).toHaveBeenCalledWith('flx_access', 'at', expect.any(Object));
      expect(result).toEqual({ requires2FA: false });
    });
  });

  describe('disable', () => {
    it('delegates to TwoFactorService.disable', () => {
      twofa.disable.mockResolvedValue({ ok: true });
      controller.disable('user-1', { code: '123456' });
      expect(twofa.disable).toHaveBeenCalledWith('user-1', '123456');
    });
  });
});
