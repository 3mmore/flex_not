/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  ConflictException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { PermissionsService } from '../permissions/permissions.service';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { LoginDto, RegisterGymDto } from './dto';
import { PasswordResetMailer } from './password-reset-mailer.service';
import { Prisma } from '@prisma/client';
import { refreshTokenJwtExpiresIn, refreshTokenTtlSeconds } from './auth-token.config';
// PHASE O1.7: the parameters live in config/password-hash.ts so that
// prisma/bootstrap-platform-admin.ts hashes with exactly the same settings.
import { PASSWORD_HASH_OPTIONS } from '../../config/password-hash';

import { TwoFactorService } from './two-factor.service';
import { TenantContextService } from '../../common/services/tenant-context.service';


export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    name: string;
    email: string;
    role: string;
    gymId: string | null;
    branchId?: string | null;
    onboardingCompleted: boolean;
  };
}

export interface TwoFaLoginResponse {
  requiresTwoFa: true;
  tempToken: string;
  user: { id: string; email: string; role: string; gymId: string | null };
}

// Shape returned by the preauth_find_users_by_email / preauth_find_user_by_id
// / preauth_find_user_by_refresh_token_hash SECURITY DEFINER Postgres
// functions (migration 202607070001_preauth_lookup_function) — see that
// migration's own extensive comment for the full root-cause and fix
// rationale (CRITICAL FIX: real login was completely broken under the
// real flexora_app + FORCE ROW LEVEL SECURITY production configuration,
// since every pre-authentication flow necessarily runs its first User
// lookup with no tenant context yet established).
interface PreAuthUserRow {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: string;
  gymId: string | null;
  branchId: string | null;
  active: boolean;
  onboardingCompleted: boolean;
  twoFaEnabled: boolean;
  twoFaSecret: string | null;
  twoFaBackupCodes: string | null;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly resetMailer: PasswordResetMailer,
    // SECURITY (Item 11 fix): injected so verifyTwoFaLogin can verify the
    // TOTP/backup code itself — see the comment on verifyTwoFaLogin below.
    private readonly twoFactor: TwoFactorService,
    // CRITICAL FIX: injected so registerGym can explicitly enter the
    // newly-created gym's tenant context for its remaining child-table
    // writes (User/Branch/Plan/License/Subscription), the exact same
    // mechanism TenantGuard already uses for every authenticated request
    // — see registerGym's own comment below and migration
    // 202607070001_preauth_lookup_function's comment for the full
    // root-cause and fix rationale.
    private readonly tenantContext: TenantContextService,
    private readonly config: ConfigService,
    // ROUND 13 (Phase 5): effective permissions are signed into the access
    // token (see issueTokens) so the edge middleware can gate routes.
    private readonly permissions: PermissionsService,
  ) {}

  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): every
   * pre-authentication User lookup in this service now goes through this
   * helper, which calls the real, narrowly-scoped SECURITY DEFINER
   * Postgres function `preauth_find_users_by_email` instead of a normal
   * `this.prisma.user.findMany({ where: { email } })`. A normal Prisma
   * call would be silently filtered to zero rows by "User"'s real
   * FORCE ROW LEVEL SECURITY policy (`"gymId" = current_setting(...)`,
   * which is never true when no tenant is known yet) under the real,
   * correctly-hardened `flexora_app` production role — confirmed directly
   * against a real Postgres database before this fix. `$queryRaw` calls
   * are NOT tenant-scoped by prisma.service.ts's Prisma Client Extension
   * (that extension only rewrites calls that carry a Prisma `model` name;
   * raw SQL calls pass through unchanged), so this correctly runs with
   * flexora_app's own ordinary privileges plus the one, explicit,
   * `GRANT EXECUTE` this migration adds — not a blanket RLS bypass.
   */
  private async preAuthFindUsersByEmail(email: string, gymId?: string | null): Promise<PreAuthUserRow[]> {
    return this.prisma.$queryRaw<PreAuthUserRow[]>(
      Prisma.sql`SELECT * FROM preauth_find_users_by_email(${email}, ${gymId ?? null})`,
    );
  }

  private async preAuthFindUserById(userId: string): Promise<PreAuthUserRow | undefined> {
    const rows = await this.prisma.$queryRaw<PreAuthUserRow[]>(
      Prisma.sql`SELECT * FROM preauth_find_user_by_id(${userId})`,
    );
    return rows[0];
  }

  private hashToken(token: string) {
    return createHash('sha256').update(token).digest('hex');
  }

  private ttlSeconds(value: string | undefined, fallbackSeconds: number): number {
    if (!value) return fallbackSeconds;
    const m = value.trim().match(/^(\d+)([smhd])?$/i);
    if (!m) return fallbackSeconds;
    const n = Number(m[1]);
    const unit = (m[2] || 's').toLowerCase();
    if (unit === 'm') return n * 60;
    if (unit === 'h') return n * 3600;
    if (unit === 'd') return n * 86400;
    return n;
  }

  private async issueTokens(user: {
    id: string;
    gymId: string | null;
    role: string;
    name: string;
    email: string;
    branchId?: string | null;
    onboardingCompleted?: boolean;
  }, familyId = randomBytes(16).toString('hex'), tx?: Prisma.TransactionClient,
     // PHASE N3 — callers that issue tokens from INSIDE a transaction pass the
     // claim they computed BEFORE opening it (see refresh()). The read must not
     // happen in there: it runs on the root client, and with the
     // interactive-transaction flag set the middleware skips its set_config
     // wrapping, so FORCE RLS hides the `UserPermission` overrides and the token
     // would be minted with role defaults only. PermissionsService is hardened
     // for that case too (outsideTransaction) — this keeps the transaction short
     // and the refresh path independent of that plumbing.
     precomputedPermissions?: Awaited<ReturnType<PermissionsService['effectivePermissions']>>) {
    const jti = randomBytes(16).toString('hex');
    // ROUND 13 (Phase 5): carry the effective permissions in the access token
    // so the edge middleware can gate routes. The PermissionsGuard re-computes
    // them live from the DB on every API call — this claim is a convenience
    // copy, never the authority.
    const effectivePermissions =
      precomputedPermissions ?? (await this.permissions.effectivePermissions(user));
    const payload = {
      sub: user.id,
      jti,
      iss: 'flexora-api',
      aud: 'flexora-staff',
      gymId: user.gymId,
      role: user.role,
      name: user.name,
      email: user.email,
      branchId: user.branchId ?? null,
      onboardingCompleted: user.onboardingCompleted ?? false,
      permissions: effectivePermissions,
    };
    const accessToken = await this.jwt.signAsync(payload, {
      secret: this.config.get<string>('JWT_ACCESS_SECRET'),
      expiresIn: this.ttlSeconds(this.config.get<string>('JWT_ACCESS_TTL'), 900),
      algorithm: 'HS256', // SECURITY: pin signing algorithm (HS256)
    });
    // SECURITY (Item 3 fix): the JWT lifetime, the DB expiry, and the
    // `flx_refresh` cookie's maxAge (set in auth.controller.ts /
    // two-factor.controller.ts) must always agree — all three now derive
    // from the single REFRESH_TOKEN_* constants in ./auth-token.config.
        const refreshToken = await this.jwt.signAsync(
      { sub: user.id, jti: randomBytes(16).toString('hex'), familyId, iss: 'flexora-api', aud: 'flexora-staff' },
      { secret: this.config.get<string>('JWT_REFRESH_SECRET'), expiresIn: refreshTokenJwtExpiresIn(), algorithm: 'HS256' },
    );
    const refreshTokenHash = this.hashToken(refreshToken);
    const expiresAt = new Date(Date.now() + refreshTokenTtlSeconds() * 1000);
    const db = tx ?? this.prisma;
    await db.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: refreshTokenHash,
        familyId,
        expiresAt,
      },
    });
    return { accessToken, refreshToken, refreshTokenHash, familyId };
  }

  /**
   * Issues a short-lived (5 min) temp token used to complete 2FA.
   * Has no refresh token attached and carries the userId only.
   */
  private async issueTwoFaTempToken(userId: string): Promise<string> {
    return this.jwt.signAsync(
      { sub: userId, stage: '2fa', jti: randomBytes(16).toString('hex'), iss: 'flexora-api', aud: 'flexora-staff' },
      {
        secret: this.config.get<string>('JWT_ACCESS_SECRET'),
        expiresIn: '300s',
        algorithm: 'HS256', // SECURITY: pin signing algorithm (HS256)
      },
    );
  }

  async login(dto: LoginDto): Promise<AuthResponse | TwoFaLoginResponse> {
    // CRITICAL FIX: see preAuthFindUsersByEmail's own doc comment and
    // migration 202607070001_preauth_lookup_function for the full
    // root-cause/rationale. This used to be a plain
    // `this.prisma.user.findMany({ where, take: 5 })`, which the real
    // FORCE ROW LEVEL SECURITY policy on "User" always filtered to ZERO
    // rows under the real flexora_app production role — no tenant is
    // known yet at login time, so `current_setting('app.gym_id', true)`
    // (what the RLS policy compares "gymId" against) is always NULL, and
    // "gymId" = NULL is never true for ANY row, correct credentials or
    // not. Confirmed directly: a real POST /api/auth/login with 100%
    // correct real credentials always returned 401 "Invalid credentials"
    // under the real flexora_app role before this fix.
    let gymId: string | null | undefined;
    if (dto.gymSlug) {
      const gym = await this.prisma.gym.findUnique({
        where: { slug: dto.gymSlug },
      });
      gymId = gym?.id ?? '00000000-0000-0000-0000-000000000000';
    }
    const users = await this.preAuthFindUsersByEmail(dto.email, gymId);
    const activeUsers = users.filter((u) => u.active);
    if (activeUsers.length > 1 && !dto.gymSlug) {
      // Multiple active accounts exist across gyms with this email.
      // Require gymSlug to disambiguate before password verification.
      throw new UnauthorizedException('Multiple accounts found. Please provide gymSlug.');
    }
    const user = activeUsers[0];
    if (!user) throw new UnauthorizedException('Invalid credentials');

    const ok = await argon2.verify(user.passwordHash, dto.password);
    if (!ok) throw new UnauthorizedException('Invalid credentials');

    // Phase 1D — if user has 2FA enabled, require TOTP step for privileged roles
    const PRIVILEGED_ROLES = ['OWNER', 'MANAGER', 'SUPER_ADMIN'];
    if (user.twoFaEnabled && PRIVILEGED_ROLES.includes(user.role)) {
      const tempToken = await this.issueTwoFaTempToken(user.id);
      return {
        requiresTwoFa: true,
        tempToken,
        user: { id: user.id, email: user.email, role: user.role, gymId: user.gymId },
      };
    }

    const tokens = await this.issueTokens(user);
    return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken, user: this.publicUser(user) };
  }

  /**
   * Phase 1D — exchanges the temp token for full tokens after TOTP verification.
   */
  /**
   * SECURITY (Item 11 fix): this used to trust that the caller (only ever
   * TwoFactorController today) had already verified the TOTP/backup code
   * via TwoFactorService.verifyCode before calling this method — the
   * comment literally said "here we just trust it since the controller
   * already called it." That is a landmine: ANY future caller of
   * verifyTwoFaLogin (a new controller, a script, a different auth flow)
   * that forgets to independently call verifyCode first would issue full,
   * valid access+refresh tokens for an account WITHOUT ever checking the
   * 2FA code at all — a complete 2FA bypass with no code changes required
   * to two-factor.controller.ts itself.
   *
   * FIX: verifyTwoFaLogin now calls TwoFactorService.verifyCode itself, so
   * the service is the single source of truth and is safe to call
   * directly regardless of what the caller did or didn't check first. The
   * check in two-factor.controller.ts is left in place as defense-in-depth
   * (it also drives the per-account BruteForceService lockout tracking,
   * which is a controller-level concern), but it is no longer the ONLY
   * place the code is verified.
   */
  async verifyTwoFaLogin(tempToken: string, code: string): Promise<AuthResponse> {
    let payload: { sub: string; stage: string };
    try {
      payload = await this.jwt.verifyAsync(tempToken, {
        secret: this.config.get<string>('JWT_ACCESS_SECRET'),
        algorithms: ['HS256'],
      });
    } catch {
      throw new UnauthorizedException('Invalid or expired 2FA session');
    }
    if (payload.stage !== '2fa' || !payload.sub) {
      throw new UnauthorizedException('Invalid 2FA session');
    }
    // CRITICAL FIX: see preAuthFindUserById's own doc comment -- the caller
    // here only has a temp 2FA token (payload.sub), not a full session, so
    // there is still no app.gym_id in context. A plain
    // `this.prisma.user.findUnique` would be silently filtered to
    // undefined by "User"'s real FORCE ROW LEVEL SECURITY policy under the
    // real flexora_app production role.
    const user = await this.preAuthFindUserById(payload.sub);
    if (!user || !user.active || !user.twoFaEnabled || !user.twoFaSecret) {
      throw new UnauthorizedException('2FA not enabled for this user');
    }
    const isValidCode = await this.twoFactor.verifyCode(user.id, code);
    if (!isValidCode) {
      throw new UnauthorizedException('Invalid TOTP code');
    }
    const tokens = await this.issueTokens(user);
    return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken, user: this.publicUser(user) };
  }

  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment, and its own note on registerGym specifically, for
   * the full root-cause/rationale): this used to be a single
   * `this.prisma.gym.create({ data: { ..., users: { create: {...} },
   * branches: { create: {...} }, ... } })` nested-write call, and a plain
   * `this.prisma.user.findFirst({ where: { email, role: 'OWNER' } })` for
   * the pre-flight duplicate-email check. BOTH are broken under the real
   * flexora_app + FORCE ROW LEVEL SECURITY production role with no tenant
   * context yet (there IS no gym yet -- that's the whole point of this
   * endpoint): the duplicate-email findFirst always silently returned
   * null (so duplicate OWNER signups were never actually caught), and the
   * nested Gym.create(...) failed outright with a real Postgres error
   * ("new row violates row-level security policy for table \"User\"")
   * the instant it tried to INSERT the nested User row, because "Gym"
   * itself has no RLS but "User" does, and Prisma issues the nested
   * INSERTs inside the SAME implicit transaction/session with no
   * app.gym_id ever set.
   *
   * FIX: the duplicate-email check now goes through the same
   * SECURITY DEFINER preauth_find_users_by_email(...) function every
   * other pre-auth User lookup in this file uses (see
   * preAuthFindUsersByEmail's doc comment). The write is split in two:
   * "Gym" (which carries no RLS -- there is no tenant "above" Gym to
   * isolate it from) is created first, on its own, with no child User/
   * Branch/Plan/License/Subscription rows yet. Then, now that we have a
   * real gym.id, the remaining child-table creates are wrapped in
   * `this.tenantContext.run(gym.id, async () => { ... })` -- the EXACT
   * SAME AsyncLocalStorage-based mechanism TenantGuard already uses for
   * every authenticated request's Prisma calls, just entered explicitly
   * here (since no JWT/guard exists yet during signup) instead of derived
   * from one. Verified directly against a real Postgres database (real
   * flexora_app role, real FORCE RLS) with a standalone reproduction
   * script before choosing this approach: a raw Gym insert followed by
   * `tenantContext.run(gymId, () => { create user; create branch; })`
   * succeeds correctly, while the original single nested-write attempt
   * reliably reproduced the RLS violation error above.
   */
  async registerGym(dto: RegisterGymDto): Promise<AuthResponse> {
    const existingRows = await this.preAuthFindUsersByEmail(dto.email);
    const exists = existingRows.find((u) => u.role === 'OWNER');
    if (exists) throw new ConflictException('Email already registered');

    const slug =
      dto.gymName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') +
      '-' +
      randomBytes(2).toString('hex');

    const passwordHash = await argon2.hash(dto.password, PASSWORD_HASH_OPTIONS);
    const licenseKey = this.makeLicenseKey();

    // Step 1: create the Gym row alone. "Gym" itself carries no RLS, so
    // this succeeds with no tenant context in play at all.
    let gym: any;
    try {
      gym = await this.prisma.gym.create({
        data: {
          name: dto.gymName,
          slug,
          status: 'ACTIVE',
          email: dto.email,
          phone: dto.phone || '',
        },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'GYM_ALREADY_EXISTS',
          translationKey: 'error_already_exists',
          message: 'A gym with this name or slug already exists.',
        });
      }
      throw error;
    }

    // Step 2: now that we have a real gym.id, enter that tenant's context
    // explicitly (same mechanism TenantGuard uses) for every remaining
    // RLS-protected child-table write.
    const owner = await this.tenantContext.run(gym.id, async () => {
      let createdOwner: any;
      try {
        createdOwner = await this.prisma.user.create({
          data: {
            name: dto.ownerName,
            email: dto.email,
            passwordHash,
            role: 'OWNER',
            gymId: gym.id,
          },
        });
      } catch (error) {
        if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
          throw new ConflictException({
            code: 'USER_ALREADY_EXISTS',
            translationKey: 'error_email_exists',
            message: 'User with this email already exists in this gym.',
          });
        }
        throw error;
      }
      // FIX (round 8): a freshly registered gym must have ZERO branches,
      // zero plans, and zero everything until the owner explicitly creates
      // their own. Previously a default "Main Branch" was auto-created here,
      // which leaked into the branches list even when the owner skipped the
      // branches step during onboarding.
      await this.prisma.license.create({
        data: {
          gymId: gym.id,
          key: licenseKey,
          status: 'ACTIVE',
          seats: 5,
          branchesAllowed: 2,
          expiresAt: new Date(Date.now() + 30 * 86400000),
        },
      });
      // Subscription at signup: a 14-day PRO trial (same entitlement the
      // billing service grants when the first payment is set up — see
      // billing.service.ts createCustomer).
      //
      // BUG FIX (2026-09 live round): this used to `create` a BASIC
      // subscription and then `upsert` with `update: {}` (an EMPTY update) —
      // the row always existed by then, so the upsert's PRO `create` branch
      // was dead code and every freshly onboarded gym silently stayed on
      // BASIC with no trialEndDate. Consequences: POS/Classes/Reports/AI
      // were 403 "feature_upgrade_required" immediately after signup, and
      // the gym hit the BASIC limits (50 members / 3 staff) while the
      // License.seats=5 misuse (see members.service.ts history) blocked
      // member creation at 5 members with the opaque
      // "License member capacity reached" error.
      const trialStart = new Date();
      const trialEnd = new Date(Date.now() + 14 * 86400000);
      await this.prisma.subscription.create({
        data: { gymId: gym.id, tier: 'PRO', status: 'TRIALING', trialStartDate: trialStart, trialEndDate: trialEnd, currentPeriodEnd: trialEnd },
      });
      return createdOwner;
    });

    const tokens = await this.issueTokens(owner);
    return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken, user: this.publicUser(owner) };
  }

  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): the original
   * `this.prisma.refreshToken.findFirst({ where: { tokenHash: hash },
   * include: { user: true } })` call's OWN "RefreshToken" row lookup is
   * fine ("RefreshToken" is not RLS-protected -- confirmed directly:
   * relrowsecurity=false, relforcerowsecurity=false), but the joined
   * `user: true` relation IS protected, and with no app.gym_id yet known
   * (this is a pre-auth, @Public() endpoint -- refreshing a session is by
   * definition happening before TenantGuard could ever run), that join
   * would silently come back null. FIX: look up the RefreshToken row
   * itself with an ordinary Prisma call (unaffected either way), then
   * resolve its joined User via the SECURITY DEFINER
   * preauth_find_user_by_refresh_token_hash(...) function instead of a
   * Prisma `include`.
   */
  async refresh(refreshToken: string): Promise<AuthResponse> {
    try {
      await this.jwt.verifyAsync(refreshToken, { secret: this.config.get<string>('JWT_REFRESH_SECRET'), algorithms: ['HS256'] });
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }
    const hash = this.hashToken(refreshToken);
    const rows = await this.prisma.$queryRaw<Array<PreAuthUserRow & {
      refreshTokenId: string;
      refreshTokenExpiresAt: Date;
      refreshTokenRevoked: boolean;
      refreshTokenFamilyId: string;
    }>>(
      Prisma.sql`SELECT * FROM preauth_find_user_by_refresh_token_hash(${hash})`,
    );
    const stored = rows[0];
    if (!stored || stored.refreshTokenExpiresAt < new Date() || !stored.active) {
      throw new UnauthorizedException('Invalid refresh token');
    }
    if (stored.refreshTokenRevoked) {
      await this.prisma.refreshToken.updateMany({
        where: { familyId: stored.refreshTokenFamilyId },
        data: { revoked: true, reusedAt: new Date() },
      });
      throw new UnauthorizedException('Refresh token reuse detected');
    }

    const user = { id: stored.id, name: stored.name, email: stored.email, role: stored.role, gymId: stored.gymId, branchId: stored.branchId, onboardingCompleted: stored.onboardingCompleted };
    // PHASE N3 — compute the permissions claim OUTSIDE the rotation transaction
    // (see issueTokens). Regression proof:
    // src/test/integration/refresh-permissions-claim.spec.ts, and live via
    // work/n3-r14-repro.js (before: the web gate sent a granted employee to
    // /dashboard; after: /expenses, write buttons still hidden).
    const effectivePermissions = await this.permissions.effectivePermissions(user);
    const rotated = await this.prisma.$transaction(async (tx) => {
      // Claim the presented token atomically. Only one concurrent refresh can
      // transition it from active to revoked; all losers are treated as reuse.
      const claimed = await tx.refreshToken.updateMany({
        where: {
          id: stored.refreshTokenId,
          revoked: false,
          expiresAt: { gt: new Date() },
        },
        data: { revoked: true },
      });
      if (claimed.count !== 1) {
        // Return a marker instead of throwing inside the transaction so this
        // family-wide revocation is committed rather than rolled back.
        await tx.refreshToken.updateMany({
          where: { familyId: stored.refreshTokenFamilyId },
          data: { revoked: true, reusedAt: new Date() },
        });
        return null;
      }

      const tokens = await this.issueTokens(user, stored.refreshTokenFamilyId, tx, effectivePermissions);
      await tx.refreshToken.update({
        where: { id: stored.refreshTokenId },
        data: { replacedByTokenHash: tokens.refreshTokenHash },
      });
      return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken, user: this.publicUser(user) };
    });
    if (!rotated) throw new UnauthorizedException('Refresh token reuse detected');
    return rotated;
  }

  async logout(refreshToken: string) {
    const hash = this.hashToken(refreshToken);
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash: hash },
      data: { revoked: true },
    });
    return { ok: true };
  }

  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): despite the
   * caller here already holding a valid JWT (this is reached via
   * AuthController's `change-password` route), that route only applies
   * `@UseGuards(JwtAuthGuard)` -- NOT the global TenantGuard -- so
   * app.gym_id is still never set by the time this method runs. The
   * original `this.prisma.user.findUniqueOrThrow`/`.update` calls would
   * therefore fail under the real flexora_app + FORCE ROW LEVEL SECURITY
   * production role: the findUniqueOrThrow throws "No User found", and
   * (were that not already throwing) the update would fail with
   * "Record to update not found" -- Prisma's phrasing for "the WHERE
   * clause matched zero rows after RLS filtering".
   */
  async changePassword(userId: string, current: string, next: string) {
    const user = await this.preAuthFindUserById(userId);
    if (!user) throw new UnauthorizedException('User not found');
    const ok = await argon2.verify(user.passwordHash, current);
    if (!ok) throw new UnauthorizedException('Current password incorrect');
    await this.prisma.$queryRaw(
      Prisma.sql`SELECT preauth_update_user_password(${userId}, ${await argon2.hash(next, PASSWORD_HASH_OPTIONS)})`,
    );
    await this.prisma.refreshToken.updateMany({
      where: { userId },
      data: { revoked: true },
    });
    return { ok: true };
  }

  /**
   * Phase 1C — Password reset request.
   * Generates a single-use token valid for 30 minutes.
   * Always returns ok:true to avoid email enumeration.
   */
  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): the original
   * `this.prisma.user.findFirst({ where, take: 1 })` always silently
   * returned null under the real flexora_app + FORCE ROW LEVEL SECURITY
   * production role, since no app.gym_id can exist yet at this
   * genuinely pre-auth, @Public() step -- meaning forgotPassword's
   * "always return ok:true" behavior was accidentally ALSO true when the
   * account genuinely existed (no reset email was ever actually queued,
   * for ANY account, not just nonexistent ones).
   */
  async forgotPassword(dto: { email: string; gymSlug?: string }) {
    let gymId: string | null | undefined;
    if (dto.gymSlug) {
      const gym = await this.prisma.gym.findUnique({ where: { slug: dto.gymSlug } });
      gymId = gym?.id ?? '00000000-0000-0000-0000-000000000000';
    }
    const users = await this.preAuthFindUsersByEmail(dto.email, gymId);
    const user = users[0];
    if (!user) return { ok: true };
    const token = randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
    // Stash the hashed token on the refresh-token table space
    await this.prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: this.hashToken(`pwreset:${token}`),
        familyId: `pwreset:${user.id}:${randomBytes(8).toString('hex')}`,
        expiresAt,
      },
    });
    await this.resetMailer.sendPasswordReset(user.email, token);
    this.logger.log(`Password reset email queued for user=${user.id}`);
    return { ok: true };
  }

  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): the same
   * "RefreshToken" (not RLS-protected) + joined "user: true" (RLS-
   * protected, and no tenant known yet at this genuinely pre-auth,
   * @Public() step) pattern as `refresh()` above -- the join would
   * silently come back null, and the subsequent `user.update` would fail
   * with "Record to update not found".
   */
  async resetPassword(dto: { token: string; newPassword: string }) {
    const hash = this.hashToken(`pwreset:${dto.token}`);
    // Atomically claim the reset token: only one concurrent request can
    // transition it from unexpired+unrevoked to revoked. This prevents a
    // race where two concurrent requests both read the token as valid and
    // each sets a different password (F-017).
    const now = new Date();
    const claimResult = await this.prisma.refreshToken.updateMany({
      where: { tokenHash: hash, revoked: false, expiresAt: { gt: now } },
      data: { revoked: true },
    });
    if (claimResult.count === 0) {
      throw new UnauthorizedException('Invalid or expired reset token');
    }
    // After claiming, we need the userId. Re-read the (now revoked) token.
    const claimed = await this.prisma.refreshToken.findFirst({ where: { tokenHash: hash } });
    if (!claimed) {
      throw new UnauthorizedException('Invalid or expired reset token');
    }
    await this.prisma.$transaction(async (tx) => {
      await tx.$queryRaw(
        Prisma.sql`SELECT preauth_update_user_password(${claimed.userId}, ${await argon2.hash(dto.newPassword, PASSWORD_HASH_OPTIONS)})`,
      );
      await tx.refreshToken.updateMany({
        where: { userId: claimed.userId },
        data: { revoked: true },
      });
    });
    return { ok: true };
  }

  private makeLicenseKey() {
    const block = () => randomBytes(2).toString('hex').toUpperCase();
    return `FLEX-${block()}-${block()}-${block()}`;
  }

  /** Set or update a staff member's identity-confirmation PIN.
   *  PIN is hashed with argon2 — never stored in plaintext. */
  async setPin(userId: string, pin: string) {
    if (!pin || pin.length < 4 || pin.length > 8 || !/^\d+$/.test(pin)) {
      throw new UnauthorizedException('PIN must be 4–8 digits');
    }
    const pinHash = await argon2.hash(pin, PASSWORD_HASH_OPTIONS);
    await this.prisma.user.update({ where: { id: userId }, data: { pinHash } });
    return { ok: true };
  }

  /** Verify a specific staff member's PIN for per-action identity
   *  confirmation (e.g. registering or renewing a member). The target
   *  user must belong to the same gym as the calling user. */
  async verifyPinForAction(gymId: string, callingUserId: string, targetUserId: string, pin: string) {
    if (!gymId || gymId === 'unknown') throw new UnauthorizedException('Valid gym session required');
    if (!targetUserId || !pin) throw new UnauthorizedException('User ID and PIN are required');

    // Look up the target user — must be same gym
    const targetUser = await this.prisma.user.findFirst({
      where: { id: targetUserId, gymId },
      select: { id: true, name: true, pinHash: true, active: true },
    });
    if (!targetUser || !targetUser.active) throw new UnauthorizedException('Staff member not found');
    if (!targetUser.pinHash) throw new UnauthorizedException('Staff member has not set a PIN yet');

    const ok = await argon2.verify(targetUser.pinHash, pin);
    if (!ok) throw new UnauthorizedException('Incorrect PIN');

    return { ok: true, userId: targetUser.id, userName: targetUser.name };
  }

  private publicUser(u: { id: string; name: string; email: string; role: string; gymId: string | null; branchId?: string | null; onboardingCompleted?: boolean }) {
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      gymId: u.gymId,
      branchId: u.branchId,
      onboardingCompleted: u.onboardingCompleted ?? false,
    };
  }
}
