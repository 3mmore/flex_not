/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE N1 — token lifetimes are read when they are used, not when the file is
 * imported.
 *
 * These used to be module-scope constants. `ConfigModule` loads `.env` only when
 * the Nest container is initialised, i.e. *after* imports, so the constants held
 * the operator's values solely because `@prisma/client` happened to inject `.env`
 * first (see `config/load-env.ts`). When that accident did not happen, a
 * configured `REFRESH_TOKEN_TTL_DAYS=1` was silently ignored and BOTH the JWT and
 * the `flx_refresh` cookie were issued for 7 days — the exact mismatch this file
 * was created to prevent, reintroduced by import order.
 *
 * The tests below therefore assert the property that matters: changing the
 * environment *after* import changes what the next call returns.
 */
import {
  accessTokenCookieMaxAgeMs,
  refreshTokenCookieMaxAgeMs,
  refreshTokenJwtExpiresIn,
  refreshTokenTtlDays,
  refreshTokenTtlSeconds,
} from './auth-token.config';

const DAY_MS = 24 * 60 * 60 * 1000;
const REAL_ENV = process.env;

function withEnv(env: Record<string, string | undefined>) {
  process.env = { ...env } as NodeJS.ProcessEnv;
}

afterEach(() => {
  process.env = REAL_ENV;
});

describe('PHASE N1 — refresh token lifetime is read at call time', () => {
  it('defaults to 7 days for the JWT, the DB expiry and the cookie alike', () => {
    withEnv({});
    expect(refreshTokenTtlDays()).toBe(7);
    expect(refreshTokenTtlSeconds()).toBe(7 * 24 * 60 * 60);
    expect(refreshTokenJwtExpiresIn()).toBe(7 * 24 * 60 * 60);
    expect(refreshTokenCookieMaxAgeMs()).toBe(7 * DAY_MS);
  });

  it('honours REFRESH_TOKEN_TTL_DAYS set after this module was imported', () => {
    withEnv({ REFRESH_TOKEN_TTL_DAYS: '1' });
    expect(refreshTokenTtlDays()).toBe(1);
    expect(refreshTokenTtlSeconds()).toBe(86400);
    expect(refreshTokenJwtExpiresIn()).toBe(86400);
    expect(refreshTokenCookieMaxAgeMs()).toBe(DAY_MS);
  });

  it('follows the environment when it changes between calls (the whole point of N1)', () => {
    withEnv({ REFRESH_TOKEN_TTL_DAYS: '3' });
    expect(refreshTokenCookieMaxAgeMs()).toBe(3 * DAY_MS);
    withEnv({ REFRESH_TOKEN_TTL_DAYS: '30' });
    expect(refreshTokenCookieMaxAgeMs()).toBe(30 * DAY_MS);
    withEnv({});
    expect(refreshTokenCookieMaxAgeMs()).toBe(7 * DAY_MS);
  });

  it('keeps the JWT and the cookie identical for any configured lifetime', () => {
    for (const days of ['1', '2', '14', '90']) {
      withEnv({ REFRESH_TOKEN_TTL_DAYS: days });
      expect(refreshTokenJwtExpiresIn() * 1000).toBe(refreshTokenCookieMaxAgeMs());
      expect(refreshTokenTtlSeconds()).toBe(Number(days) * 24 * 60 * 60);
    }
  });

  it.each([['abc'], ['0'], ['-3'], [''], ['7d'], [NaN as unknown as string]])(
    'falls back to 7 days for an unusable REFRESH_TOKEN_TTL_DAYS (%p)',
    (value) => {
      withEnv({ REFRESH_TOKEN_TTL_DAYS: String(value) });
      expect(refreshTokenTtlDays()).toBe(7);
      expect(refreshTokenCookieMaxAgeMs()).toBe(7 * DAY_MS);
    },
  );
});

describe('PHASE N1 — access token cookie lifetime is read at call time', () => {
  it('defaults to 900 seconds (15 minutes)', () => {
    withEnv({});
    expect(accessTokenCookieMaxAgeMs()).toBe(900 * 1000);
  });

  it.each([
    ['900', 900],
    ['15m', 900],
    ['1h', 3600],
    ['12h', 43200],
    ['1d', 86400],
    ['2D', 172800],
  ])('parses JWT_ACCESS_TTL=%s as %s seconds', (raw, seconds) => {
    withEnv({ JWT_ACCESS_TTL: raw });
    expect(accessTokenCookieMaxAgeMs()).toBe(seconds * 1000);
  });

  it.each([['nonsense'], [''], ['  ']])('falls back to 900s for JWT_ACCESS_TTL=%p', (raw) => {
    withEnv({ JWT_ACCESS_TTL: raw });
    expect(accessTokenCookieMaxAgeMs()).toBe(900 * 1000);
  });

  it('follows the environment when it changes between calls', () => {
    withEnv({ JWT_ACCESS_TTL: '5m' });
    expect(accessTokenCookieMaxAgeMs()).toBe(300 * 1000);
    withEnv({ JWT_ACCESS_TTL: '30m' });
    expect(accessTokenCookieMaxAgeMs()).toBe(1800 * 1000);
  });
});
