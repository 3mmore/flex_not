import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { PrismaModule } from '../../prisma/prisma.module';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { TwoFactorController } from './two-factor.controller';
import { TwoFactorService } from './two-factor.service';
import { JwtStrategy } from './jwt.strategy';
import { SecurityModule } from '../../common/security/security.module';
import { PasswordResetMailer } from './password-reset-mailer.service';

@Module({
  imports: [JwtModule.register({}), PassportModule, PrismaModule, SecurityModule],
  controllers: [AuthController, TwoFactorController],
  providers: [AuthService, JwtStrategy, TwoFactorService, PasswordResetMailer],
  exports: [AuthService],
})
export class AuthModule {}
