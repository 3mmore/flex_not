/**
 * FLEXORA Gym OS — TwoFactorService unit tests
 * Tests cover: setup (owner-only), verifySetup (TOTP check), verifyCode (TOTP + backup + reuse prevention), disable
 */
import { ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { TwoFactorService } from './two-factor.service';
import { authenticator } from 'otplib';

authenticator.options = { window: 1, step: 30 };

function createMockPrisma() {
  const prisma: any = {
    user: {
      findUnique: jest.fn(),
      update: jest.fn(),
    },
    $queryRaw: jest.fn(),
    $transaction: jest.fn(),
  };
  // $transaction callback receives `tx` which is the mock itself
  prisma.$transaction.mockImplementation(async (cb: Function | any[]) => {
    if (typeof cb === 'function') return cb(prisma);
    return cb;
  });
  return prisma;
}

function createMockEncryption() {
  return {
    encrypt: jest.fn((v: string) => `enc:${v}`),
    decrypt: jest.fn((v: string) => v?.replace(/^enc:/, '') || ''),
  };
}

describe('TwoFactorService', () => {
  let service: TwoFactorService;
  let prisma: ReturnType<typeof createMockPrisma>;
  let encryption: ReturnType<typeof createMockEncryption>;

  beforeEach(() => {
    prisma = createMockPrisma();
    encryption = createMockEncryption();
    service = new TwoFactorService(prisma as any, encryption as any);
  });

  describe('setup', () => {
    it('throws UnauthorizedException if user not found', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      await expect(service.setup('user-1')).rejects.toThrow(UnauthorizedException);
    });

    it('throws ForbiddenException for non-OWNER role', async () => {
      prisma.user.findUnique.mockResolvedValue({ id: 'user-1', role: 'STAFF', email: 'a@b.com' });
      await expect(service.setup('user-1')).rejects.toThrow(ForbiddenException);
    });

    it('generates secret, QR code, and backup codes for OWNER', async () => {
      prisma.user.findUnique.mockResolvedValue({ id: 'user-1', role: 'OWNER', email: 'owner@test.com' });
      prisma.user.update.mockResolvedValue({});

      const result = await service.setup('user-1');

      expect(result.secret).toBeTruthy();
      expect(result.otpauthUrl).toContain('otpauth://totp/');
      expect(result.otpauthUrl).toContain('FLEXORA');
      expect(result.qrCodeDataUrl).toMatch(/^data:image\/png;base64,/);
      expect(result.backupCodes).toHaveLength(8);
      // Backup codes should be in XXXX-XXXX format
      result.backupCodes.forEach((code: string) => {
        expect(code).toMatch(/^[0-9A-F]{4}-[0-9A-F]{4}$/);
      });
      // Should persist encrypted secret
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: 'user-1' },
          data: expect.objectContaining({
            twoFaEnabled: false,
            twoFaLastCode: null,
          }),
        }),
      );
    });
  });

  describe('verifySetup', () => {
    it('throws if no setup in progress (no secret stored)', async () => {
      prisma.user.findUnique.mockResolvedValue({ id: 'u1', role: 'OWNER', email: 'a@b.com', twoFaSecret: null });
      await expect(service.verifySetup('u1', '123456')).rejects.toThrow(UnauthorizedException);
    });

    it('throws UnauthorizedException for invalid TOTP code', async () => {
      const secret = authenticator.generateSecret();
      prisma.user.findUnique.mockResolvedValue({
        id: 'u1', role: 'OWNER', email: 'a@b.com',
        twoFaSecret: `enc:${secret}`, twoFaEnabled: false,
      });
      prisma.user.update.mockResolvedValue({});
      await expect(service.verifySetup('u1', '000000')).rejects.toThrow('Invalid TOTP code');
    });

    it('enables 2FA with valid TOTP code', async () => {
      const secret = authenticator.generateSecret();
      const code = authenticator.generate(secret);
      prisma.user.findUnique.mockResolvedValue({
        id: 'u1', role: 'OWNER', email: 'a@b.com',
        twoFaSecret: `enc:${secret}`, twoFaEnabled: false,
      });
      prisma.user.update.mockResolvedValue({});

      const result = await service.verifySetup('u1', code);
      expect(result).toEqual({ ok: true });
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ twoFaEnabled: true }),
        }),
      );
    });
  });

  describe('disable', () => {
    it('throws UnauthorizedException if code is invalid', async () => {
      // verifyCode returns false → disable throws
      prisma.$queryRaw.mockResolvedValue([]);
      await expect(service.disable('u1', '000000')).rejects.toThrow(UnauthorizedException);
    });
  });
});
