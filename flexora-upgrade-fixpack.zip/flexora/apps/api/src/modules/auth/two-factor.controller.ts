/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body, Controller, HttpException, HttpStatus, Post, Res, UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { JwtService } from '@nestjs/jwt';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { isCookieSecure } from '../../config/cookie-secure';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { BruteForceService } from '../../common/security/brute-force.service';
import { BruteForceGuard } from '../../common/guards/brute-force.guard';
import { BruteForce } from '../../common/decorators/brute-force.decorator';
import { TwoFactorService } from './two-factor.service';
import { AuthService } from './auth.service';
import { IsString, Length, Matches } from 'class-validator';
import { Response } from 'express';
import { refreshTokenCookieMaxAgeMs, accessTokenCookieMaxAgeMs } from './auth-token.config';


// PHASE L2: one decision for every session cookie; validated at boot so
// production can never run with secure cookies switched off.
const COOKIE_SECURE = isCookieSecure();
function setAuthCookies(res: Response, tokens: { accessToken: string; refreshToken: string }) {
  res.cookie('flx_access', tokens.accessToken, { httpOnly: true, secure: COOKIE_SECURE, sameSite: 'strict', path: '/', maxAge: accessTokenCookieMaxAgeMs() });
  // SECURITY (Item 3 fix): matches the refresh JWT's real `expiresIn` — see
  // auth-token.config.ts (previously hardcoded to 30 days vs the JWT's 7d).
  res.cookie('flx_refresh', tokens.refreshToken, { httpOnly: true, secure: COOKIE_SECURE, sameSite: 'strict', path: '/', maxAge: refreshTokenCookieMaxAgeMs() });
}

class CodeDto {
  @IsString()
  @Length(6, 9)
  @Matches(/^[0-9A-Z\-]+$/, { message: 'Code must be 6 digits or a backup code' })
  code!: string;
}

class TwoFaLoginDto {
  @IsString() tempToken!: string;
  @IsString() @Length(6, 9) code!: string;
}

import { ConfigService } from '@nestjs/config';

@ApiTags('auth/2fa')
@ApiBearerAuth()
@Controller('auth/2fa')
export class TwoFactorController {
  constructor(
    private readonly twofa: TwoFactorService,
    private readonly auth: AuthService,
    private readonly jwt: JwtService,
    private readonly bf: BruteForceService,
    private readonly config: ConfigService,
  ) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('OWNER')
  @Post('setup')
  @Audit('2fa_setup', 'User')
  setup(@CurrentUser('sub') userId: string) {
    return this.twofa.setup(userId);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('OWNER')
  @Post('verify')
  @Audit('2fa_verify_setup', 'User')
  verifySetup(@CurrentUser('sub') userId: string, @Body() dto: CodeDto) {
    return this.twofa.verifySetup(userId, dto.code);
  }

  /**
   * 2FA login completion step.
   *
   * SECURITY (remediation):
   *  - The temp token is verified server-side to extract the userId (sub).
   *  - Per-ACCOUNT progressive lockout (BruteForceService, scope='2fa') is
   *    enforced BEFORE the TOTP check, keyed on the userId — not just the IP.
   *    This stops a distributed (multi-IP) attacker who already has the
   *    password from brute-forcing the 6-digit TOTP.
   *  - Failures are recorded; the account is locked after the configured
   *    thresholds (default 3->30s, 5->5m, 10->24h).
   *  - Errors throw Nest HTTP exceptions (401/429) — never bare `Error`,
   *    which previously produced misleading 500 responses.
   *
   * The credential is verified exactly once by AuthService. The controller
   * owns only the per-account failure counter; verifying here as well would
   * consume a one-time TOTP/backup code and make the service-level check fail
   * as a replay.
   */
  @Public()
  @Throttle({ auth: { ttl: 60000, limit: 5 }, short: { ttl: 60000, limit: 5 } })
  @UseGuards(BruteForceGuard)
  @BruteForce()
  @Post('login')
  @Audit('2fa_login', 'User')
  async loginStep(@Body() dto: TwoFaLoginDto, @Res({ passthrough: true }) res: Response) {
    let userId: string;

    // 1. Verify + decode the temp token (stage=2fa) to identify the account.
    try {
      const payload = await this.jwt.verifyAsync<{ sub: string; stage: string }>(
        dto.tempToken,
        { secret: this.config.get<string>('JWT_ACCESS_SECRET'), algorithms: ['HS256'] },
      );
      if (payload.stage !== '2fa' || !payload.sub) {
        throw new Error('bad stage');
      }
      userId = payload.sub;
    } catch {
      // A bad/expired temp token is not an account failure — just reject.
      throw new HttpException(
        { statusCode: HttpStatus.UNAUTHORIZED, message: 'Invalid or expired 2FA session' },
        HttpStatus.UNAUTHORIZED,
      );
    }

    // 2. Per-account lockout check (distributed-brute-force defence).
    const lock = await this.bf.check('2fa', userId);
    if (!lock.allowed) {
      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: `Too many 2FA attempts. Retry in ${lock.retryAfterSeconds}s.`,
          retryAfterSeconds: lock.retryAfterSeconds,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    // Verify exactly once in AuthService. TOTP and backup codes are one-time
    // credentials; pre-verifying here and then verifying again in AuthService
    // consumes the credential on the first call and makes every login fail on
    // the second call as a replay.
    try {
      const result = await this.auth.verifyTwoFaLogin(dto.tempToken, dto.code);
      await this.bf.reset(`2fa:${userId}`);
      setAuthCookies(res, result);
      const { accessToken, refreshToken, ...body } = result;
      return body;
    } catch (error) {
      await this.bf.checkAndIncrement(`2fa:${userId}`);
      throw error;
    }
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('OWNER')
  @Post('disable')
  @Audit('2fa_disable', 'User')
  disable(@CurrentUser('sub') userId: string, @Body() dto: CodeDto) {
    return this.twofa.disable(userId, dto.code);
  }
}
