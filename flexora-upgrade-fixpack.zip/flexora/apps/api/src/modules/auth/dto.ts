/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsEmail, IsString, MinLength, IsOptional, Matches } from 'class-validator';
import { PasswordStrength } from '../../common/decorators/password-strength.decorator';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';

export class LoginDto {
  @IsEmail() email!: string;
  @IsString() @MinLength(1) password!: string;
  @IsOptional() @IsString() gymSlug?: string;
}

export class RefreshDto {
  @IsString() refreshToken!: string;
}

export class RegisterGymDto {
  @IsString() @MinLength(2) gymName!: string;
  @IsString() @MinLength(2) ownerName!: string;
  @IsEmail() email!: string;
  @IsString() @PasswordStrength() password!: string;
  @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
}

export class ChangePasswordDto {
  @IsString() currentPassword!: string;
  @IsString() @PasswordStrength() newPassword!: string;
}

export class ForgotPasswordDto {
  @IsEmail() email!: string;
  @IsOptional() @IsString() gymSlug?: string;
}

export class ResetPasswordDto {
  @IsString() token!: string;
  @IsString() @PasswordStrength() newPassword!: string;
}
