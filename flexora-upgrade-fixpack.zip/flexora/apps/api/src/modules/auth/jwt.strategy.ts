import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { PrismaService } from '../../config/prisma.service';
import { Prisma } from '@prisma/client';

interface AccessTokenPayload {
  sub: string;
  email: string;
  role: string;
  gymId: string | null;
  name?: string;
  branchId?: string | null;
  onboardingCompleted?: boolean;
  type?: 'platform';
  stage?: string;
  // ROUND 13 (Phase 5): effective permissions at sign time. The authoritative
  // check is the PermissionsGuard (live from the DB); this claim only lets the
  // edge middleware gate routes without a DB round-trip.
  permissions?: string[];
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(config: ConfigService, private readonly prisma: PrismaService) {
    const secret = config.get<string>('JWT_ACCESS_SECRET');
    if (!secret) throw new Error('JWT_ACCESS_SECRET is required');

    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        // PHASE R1 / review item 1 — flx_platform_token is deliberately GONE from
        // this extractor. It was read here before R1, which meant the tenant
        // strategy was the thing validating a platform credential; it only ever
        // failed by accident, because validate() below resolves the subject
        // against the "User" table. The platform cookie is now read only by
        // PlatformSessionGuard, and only on @PlatformRoute() handlers.
        (request: any) => request.cookies?.flx_access || request.headers.authorization?.split(' ')[1] || null,
      ]),
      ignoreExpiration: false,
      secretOrKey: secret,
      algorithms: ['HS256'],
    });
  }

  async validate(payload: AccessTokenPayload) {
    if (!payload.sub || !payload.role) return null;
    // ROUND 13 (Phase 5): deactivating a user must invalidate their sessions
    // IMMEDIATELY — the access token alone would stay valid until it expires,
    // so the strategy re-checks the active flag on every request. (Refresh
    // tokens are revoked on deactivation in UsersService.toggle/remove.)
    // 2FA temp tokens carry no role and are validated by the 2FA flow itself.
    // NOTE: the lookup goes through the narrowly-scoped SECURITY DEFINER
    // function preauth_find_user_by_id — a plain prisma.user.findUnique here
    // would be silently filtered to ZERO rows by "User"'s FORCE ROW LEVEL
    // SECURITY policy (no tenant is in context inside the strategy), which
    // would 401 every valid token.
    if (payload.stage !== '2fa') {
      const rows = await this.prisma.$queryRaw<Array<{ id: string; active: boolean }>>(
        Prisma.sql`SELECT id, active FROM preauth_find_user_by_id(${payload.sub})`,
      );
      const dbUser = rows[0];
      if (!dbUser || !dbUser.active) return null;
    }
    return {
      id: payload.sub,
      sub: payload.sub,
      email: payload.email,
      name: payload.name,
      role: payload.role,
      gymId: payload.gymId ?? null,
      branchId: payload.branchId ?? null,
      onboardingCompleted: payload.onboardingCompleted ?? false,
      type: payload.type,
      permissions: Array.isArray(payload.permissions) ? payload.permissions : undefined,
    };
  }
}
