import { createHash } from 'crypto';
import { UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';

const sha = (s: string) => createHash('sha256').update(s).digest('hex');

function makeService() {
  const prisma: any = {
    gym: { findUnique: jest.fn(), create: jest.fn() },
    user: { findFirst: jest.fn(), findMany: jest.fn(), findUnique: jest.fn(), findUniqueOrThrow: jest.fn(), create: jest.fn(), update: jest.fn(), updateMany: jest.fn() },
    branch: { create: jest.fn() },
    plan: { createMany: jest.fn() },
    license: { create: jest.fn() },
    subscription: { create: jest.fn(), upsert: jest.fn() },
    refreshToken: { create: jest.fn(), findUnique: jest.fn(), findFirst: jest.fn(), update: jest.fn(), updateMany: jest.fn() },
    // CRITICAL FIX (tenant-context / preauth-lookup-function investigation):
    // AuthService's pre-auth flows (login, verifyTwoFaLogin, refresh,
    // changePassword, resetPassword, forgotPassword) now go through
    // `this.prisma.$queryRaw(...)` calling the real, migration-defined
    // SECURITY DEFINER preauth_* Postgres functions instead of ordinary
    // Prisma model calls -- see auth.service.ts's own extensive comments
    // and migration 202607070001_preauth_lookup_function for the full
    // root-cause/rationale. Tests mock $queryRaw directly and assert on
    // its call arguments/return value instead of the old
    // user.findMany/findUnique/update mocks.
    $queryRaw: jest.fn(),
  };
  prisma.refreshToken.updateMany.mockResolvedValue({ count: 1 });
  prisma.$transaction = jest.fn(async (callback: (tx: any) => unknown) => callback(prisma));
  const jwt: any = { signAsync: jest.fn(async () => 'access'), verifyAsync: jest.fn() };
  const mailer: any = { sendPasswordReset: jest.fn(async () => undefined) };
  const config: any = { get: jest.fn((k) => process.env[k]) };
  // Real-shaped mock of TwoFactorService — tests control verifyCode's
  // return value directly to prove AuthService.verifyTwoFaLogin calls it
  // itself, rather than trusting an external caller already did.
  const twoFactor: any = { verifyCode: jest.fn() };
  // CRITICAL FIX: TenantContextService is now injected into AuthService
  // (used by registerGym to enter the newly-created gym's tenant context
  // for its remaining child-table writes -- see registerGym's own
  // comment). `run` just invokes the callback directly for test purposes
  // (no real AsyncLocalStorage needed here — that mechanism itself is
  // proven correct via real, end-to-end HTTP tests, not unit tests).
  const tenantContext: any = { run: jest.fn((_gymId: unknown, cb: () => unknown) => cb()), enter: jest.fn(), getGymId: jest.fn() };
  // ROUND 13 (Phase 5): AuthService signs the caller's effective permissions
  // into the access token (issueTokens) — the mock mirrors that contract.
  const permissions: any = { effectivePermissions: jest.fn(async () => ['members.view']) };
  const svc = new AuthService(prisma, jwt, mailer, twoFactor, tenantContext, config, permissions);
  return { svc, prisma, jwt, mailer, twoFactor, tenantContext, permissions };
}

describe('AuthService refresh token family security', () => {
  beforeEach(() => {
    process.env.JWT_ACCESS_SECRET = 'access-secret-000000000000000000000000';
  });

  it('rotates a valid refresh token in the same family and links the replacement hash', async () => {
    const { svc, prisma } = makeService();
    // CRITICAL FIX: refresh() now resolves the joined User row via the
    // SECURITY DEFINER preauth_find_user_by_refresh_token_hash(...)
    // function through $queryRaw, not `refreshToken.findFirst({ include:
    // { user: true } })` -- see refresh()'s own doc comment.
    prisma.$queryRaw.mockResolvedValue([{
      id: 'u1', name: 'Owner', email: 'o@test.com', role: 'OWNER', gymId: 'g1', branchId: null,
      active: true, onboardingCompleted: false,
      refreshTokenId: 'rt1', refreshTokenExpiresAt: new Date(Date.now() + 60_000),
      refreshTokenRevoked: false, refreshTokenFamilyId: 'fam1',
    }]);

    const result = await svc.refresh('old');

    expect(result.accessToken).toBe('access');
    expect(result.refreshToken).toBeTruthy();
    expect(prisma.refreshToken.create.mock.calls[0][0].data.familyId).toBe('fam1');
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({ id: 'rt1', revoked: false }),
      data: { revoked: true },
    }));
    expect(prisma.refreshToken.update.mock.calls[0][0].data.replacedByTokenHash).toMatch(/^[a-f0-9]{64}$/);
  });

  it('revokes an entire token family on refresh-token reuse', async () => {
    const { svc, prisma } = makeService();
    prisma.$queryRaw.mockResolvedValue([{
      id: 'u1', name: 'Owner', email: 'o@test.com', role: 'OWNER', gymId: 'g1', branchId: null,
      active: true, onboardingCompleted: false,
      refreshTokenId: 'rt1', refreshTokenExpiresAt: new Date(Date.now() + 60_000),
      refreshTokenRevoked: true, refreshTokenFamilyId: 'fam1',
    }]);

    await expect(svc.refresh('old')).rejects.toBeInstanceOf(UnauthorizedException);
    expect(prisma.refreshToken.updateMany).toHaveBeenCalledWith({
      where: { familyId: 'fam1' },
      data: { revoked: true, reusedAt: expect.any(Date) },
    });
  });
});

describe('AuthService.verifyTwoFaLogin — Item 11: service verifies the code itself', () => {
  const ACCESS_SECRET = 'access-secret-000000000000000000000000';

  beforeEach(() => {
    process.env.JWT_ACCESS_SECRET = ACCESS_SECRET;
  });

  const validTempTokenPayload = { sub: 'u1', stage: '2fa' };
  const enabledUser = {
    id: 'u1',
    gymId: 'g1',
    role: 'OWNER',
    name: 'Owner',
    email: 'owner@test.com',
    active: true,
    twoFaEnabled: true,
    twoFaSecret: 'encrypted-secret',
  };

  it('calling verifyTwoFaLogin DIRECTLY with a WRONG code throws Unauthorized WITHOUT ever reaching a controller-level check', async () => {
    // This test calls AuthService.verifyTwoFaLogin exactly as a
    // hypothetical future caller would — with NO TwoFactorController, no
    // controller-level verifyCode call, nothing. There is no
    // TwoFactorController anywhere in this test file/module graph. If the
    // service still throws Unauthorized for a wrong code, that proves the
    // service itself is the source of truth for 2FA verification, per
    // Item 11 — not something only enforced by a caller that could be
    // skipped or forgotten.
    //
    // CRITICAL FIX: verifyTwoFaLogin now resolves the user via
    // preAuthFindUserById(), which calls the SECURITY DEFINER
    // preauth_find_user_by_id(...) function through $queryRaw -- see
    // verifyTwoFaLogin's own doc comment.
    const { svc, prisma, jwt, twoFactor } = makeService();
    jwt.verifyAsync.mockResolvedValue(validTempTokenPayload);
    prisma.$queryRaw.mockResolvedValue([enabledUser]);
    twoFactor.verifyCode.mockResolvedValue(false); // wrong code

    await expect(svc.verifyTwoFaLogin('temp-token', '000000')).rejects.toBeInstanceOf(UnauthorizedException);
    await expect(svc.verifyTwoFaLogin('temp-token', '000000')).rejects.toThrow(/invalid totp code/i);

    // Proves the service actually called verifyCode itself (the fix) —
    // not merely trusting that some external caller already had.
    expect(twoFactor.verifyCode).toHaveBeenCalledWith('u1', '000000');

    // And, critically, no tokens were ever issued for the wrong code.
    expect(jwt.signAsync).not.toHaveBeenCalled();
  });

  it('calling verifyTwoFaLogin directly with a CORRECT code succeeds and issues tokens', async () => {
    const { svc, prisma, jwt, twoFactor } = makeService();
    jwt.verifyAsync.mockResolvedValue(validTempTokenPayload);
    prisma.$queryRaw.mockResolvedValue([enabledUser]);
    twoFactor.verifyCode.mockResolvedValue(true); // correct code

    const result = await svc.verifyTwoFaLogin('temp-token', '123456');

    expect(twoFactor.verifyCode).toHaveBeenCalledWith('u1', '123456');
    expect(result.accessToken).toBe('access');
    expect(result.user.id).toBe('u1');
  });

  it('rejects with Unauthorized if 2FA is not enabled for the user, WITHOUT ever calling verifyCode', async () => {
    const { svc, prisma, jwt, twoFactor } = makeService();
    jwt.verifyAsync.mockResolvedValue(validTempTokenPayload);
    prisma.$queryRaw.mockResolvedValue([{ ...enabledUser, twoFaEnabled: false }]);

    await expect(svc.verifyTwoFaLogin('temp-token', '123456')).rejects.toBeInstanceOf(UnauthorizedException);
    expect(twoFactor.verifyCode).not.toHaveBeenCalled();
  });

  it('rejects with Unauthorized for an invalid/expired temp token, WITHOUT ever calling verifyCode', async () => {
    const { svc, jwt, twoFactor } = makeService();
    jwt.verifyAsync.mockRejectedValue(new Error('jwt expired'));

    await expect(svc.verifyTwoFaLogin('bad-token', '123456')).rejects.toBeInstanceOf(UnauthorizedException);
    expect(twoFactor.verifyCode).not.toHaveBeenCalled();
  });
});

describe('AuthService password reset delivery', () => {
  it('creates a one-time reset token and sends it via the reset mailer', async () => {
    // CRITICAL FIX: forgotPassword now resolves the user via
    // preAuthFindUsersByEmail(), which calls the SECURITY DEFINER
    // preauth_find_users_by_email(...) function through $queryRaw -- see
    // forgotPassword's own doc comment.
    const { svc, prisma, mailer } = makeService();
    prisma.$queryRaw.mockResolvedValue([{ id: 'u1', email: 'owner@test.com' }]);

    await expect(svc.forgotPassword({ email: 'owner@test.com' })).resolves.toEqual({ ok: true });

    expect(prisma.refreshToken.create).toHaveBeenCalled();
    const data = prisma.refreshToken.create.mock.calls[0][0].data;
    expect(data.tokenHash).toMatch(/^[a-f0-9]{64}$/);
    expect(data.familyId).toMatch(/^pwreset:u1:/);
    expect(mailer.sendPasswordReset).toHaveBeenCalledWith('owner@test.com', expect.any(String));
  });
});
