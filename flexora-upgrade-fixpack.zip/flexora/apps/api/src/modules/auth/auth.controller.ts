/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { PermissionsService } from '../permissions/permissions.service';
import { Response, Request } from 'express';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { AuthService, AuthResponse, TwoFaLoginResponse } from './auth.service';
import {
  ChangePasswordDto,
  ForgotPasswordDto,
  LoginDto,
  RefreshDto,
  RegisterGymDto,
  ResetPasswordDto,
} from './dto';
import { Public } from '../../common/decorators/public.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { BruteForce } from '../../common/decorators/brute-force.decorator';
import { BruteForceGuard } from '../../common/guards/brute-force.guard';
import { BruteForceService } from '../../common/security/brute-force.service';
import { SecurityMonitorService } from '../../common/security/security-monitor.service';
import { refreshTokenCookieMaxAgeMs, accessTokenCookieMaxAgeMs } from './auth-token.config';
import { isCookieSecure } from '../../config/cookie-secure';


// PHASE L2: one decision for every session cookie; validated at boot so
// production can never run with secure cookies switched off.
const COOKIE_SECURE = isCookieSecure();
function setAuthCookies(res: Response, tokens: { accessToken: string; refreshToken: string }) {
  res.cookie('flx_access', tokens.accessToken, { httpOnly: true, secure: COOKIE_SECURE, sameSite: 'strict', path: '/', maxAge: accessTokenCookieMaxAgeMs() });
  // SECURITY (Item 3 fix): maxAge now matches the refresh JWT's actual
  // `expiresIn` exactly (both come from auth-token.config.ts) instead of
  // being hardcoded to a different, longer value (30d vs the JWT's 7d).
  res.cookie('flx_refresh', tokens.refreshToken, { httpOnly: true, secure: COOKIE_SECURE, sameSite: 'strict', path: '/', maxAge: refreshTokenCookieMaxAgeMs() });
}
function clearAuthCookies(res: Response) {
  res.clearCookie('flx_access', { path: '/' });
  res.clearCookie('flx_refresh', { path: '/' });
}
function readCookie(req: Request, name: string) {
  const request = req as Request & { cookies?: Record<string, string> };
  return request.cookies?.[name] || String(req.headers?.cookie || '').split(';').map((v: string) => v.trim()).find((v: string) => v.startsWith(`${name}=`))?.slice(name.length + 1);
}

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly bf: BruteForceService,
    private readonly monitor: SecurityMonitorService,
    // ROUND 13 (Phase 5): /auth/me returns the caller's effective permissions.
    private readonly permissions: PermissionsService,
  ) {}

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce('invitation-register')
  @Throttle({ auth: { ttl: 60000, limit: 10 }, short: { ttl: 60000, limit: 10 } })
  @Post('register')
  @Audit('register', 'Gym')
  async register(@Req() req: Request & { __bruteForce?: { scope: string; key: string } }, @Res({ passthrough: true }) res: Response, @Body() dto: RegisterGymDto) {
    try {
      const result = await this.auth.registerGym(dto);
      setAuthCookies(res, result);
      const { accessToken, refreshToken, ...body } = result;
      return body;
    } catch (e) {
      await this.maybeBumpFailure(req, 'invitation-register');
      throw e;
    }
  }

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce('login')
  @Throttle({ auth: { ttl: 900000, limit: 5 }, default: { ttl: 900000, limit: 5 }, short: { ttl: 900000, limit: 5 } })
  @Post('login')
  @Audit('login', 'User')
  async login(@Req() req: Request & { __bruteForce?: { scope: string; key: string } }, @Res({ passthrough: true }) res: Response, @Body() dto: LoginDto) {
    try {
      const result = await this.auth.login(dto);
      if (req.__bruteForce) {
        await this.bf.reset(req.__bruteForce.scope, req.__bruteForce.key);
      }
      
      if ('requiresTwoFa' in result) {
        this.monitor.loginSucceeded(req.ip || '', result.user?.gymId || null, result.user?.id);
        return result;
      }

      this.monitor.loginSucceeded(req.ip || '', result.user?.gymId || null, result.user?.id);
      setAuthCookies(res, result);
      const { accessToken, refreshToken, ...body } = result;
      return body;
    } catch (e) {
      await this.maybeBumpFailure(req, 'login');
      await this.monitor.loginFailed(req.ip || '', null, dto.email, (e as Error).message);
      throw e;
    }
  }

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce('reset-password')
  @Throttle({ auth: { ttl: 3600000, limit: 5 }, short: { ttl: 3600000, limit: 5 } })
  @Post('forgot-password')
  @Audit('forgot_password', 'User')
  forgotPassword(@Req() req: Request & { __bruteForce?: { scope: string; key: string } }, @Body() dto: ForgotPasswordDto) {
    return this.auth.forgotPassword(dto).catch(async (e) => {
      await this.maybeBumpFailure(req, 'reset-password');
      throw e;
    });
  }

  @Public()
  @UseGuards(BruteForceGuard)
  @BruteForce('reset-password')
  @Throttle({ auth: { ttl: 3600000, limit: 5 }, short: { ttl: 3600000, limit: 5 } })
  @Post('reset-password')
  @Audit('reset_password', 'User')
  resetPassword(@Req() req: Request & { __bruteForce?: { scope: string; key: string } }, @Body() dto: ResetPasswordDto) {
    return this.auth.resetPassword(dto).catch(async (e) => {
      await this.maybeBumpFailure(req, 'reset-password');
      throw e;
    });
  }

  @Public()
  @Throttle({ auth: { limit: 20, ttl: 60000 }, default: { limit: 20, ttl: 60000 } })
  @Post('refresh')
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const token = readCookie(req, 'flx_refresh');
    const result = await this.auth.refresh(token);
    setAuthCookies(res, result);
    const { accessToken, refreshToken, ...body } = result;
    return body;
  }

  @Public()
  @Throttle({ auth: { limit: 20, ttl: 60000 }, default: { limit: 20, ttl: 60000 } })
  @Post('logout')
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const token = readCookie(req, 'flx_refresh');
    clearAuthCookies(res);
    return token ? this.auth.logout(token) : { ok: true };
  }


  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  /**
   * ROOT FIX (Phase 4 verification): every named throttler in this app applies
   * to every route, so without an explicit override `/auth/me` inherited the
   * `auth` bucket that exists for CREDENTIAL checks (20 requests/minute/IP).
   * The web app legitimately reads the signed-in identity on each page load,
   * so a normal browsing burst — worse, a whole gym behind one NAT — would 429
   * the identity call. The UI then rendered as if the user had no branch
   * (owners lost their branch picker and the kiosk device manager).
   *
   * `/auth/me` only echoes the already-verified JWT user and touches nothing
   * sensitive, so it gets a read-scale bucket while login/refresh/2FA keep the
   * strict 20/min limits.
   */
  @Throttle({ auth: { ttl: 60000, limit: 240 }, short: { ttl: 60000, limit: 240 } })
  @Get('me')
  // ROUND 14 (security review): self-service endpoint — explicitly gated so
  // every tenant endpoint carries @Roles/@Permissions/@Public metadata.
  @Permissions('profile.self')
  async me(@CurrentUser() user: any) {
    // ROUND 13 (Phase 5): /auth/me returns the caller's EFFECTIVE permissions
    // (role defaults + owner-controlled overrides), computed live — the web
    // shell drives its sidebar, buttons and routes from this list.
    const permissions = await this.permissions.effectivePermissions(user);
    return { user: { ...(user as object), permissions } };
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Throttle({ auth: { limit: 10, ttl: 60000 } })
  @Post('change-password')
  @Permissions('profile.self')
  @Audit('change_password', 'User')
  changePassword(
    @CurrentUser('sub') userId: string,
    @Body() dto: ChangePasswordDto,
  ) {
    return this.auth.changePassword(userId, dto.currentPassword, dto.newPassword);
  }

  /** Set or update a staff PIN (hashed, never stored in plaintext). */
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Post('pin')
  @Permissions('profile.self')
  @Throttle({ auth: { limit: 10, ttl: 60000 }, default: { limit: 10, ttl: 60000 } })
  setPin(@CurrentUser('sub') userId: string, @Body('pin') pin: string) {
    return this.auth.setPin(userId, pin);
  }

  /** Verify a specific staff member's PIN — used for per-action identity
   *  confirmation during member registration/renewal. The calling user
   *  (who is logged in) provides a target userId (which must belong to
   *  the same gym) and that user's PIN. Returns `{ ok: true }` on success. */
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Post('verify-pin')
  @Permissions('profile.self')
  @Throttle({ auth: { limit: 20, ttl: 60000 }, default: { limit: 20, ttl: 60000 } })
  verifyPin(
    @CurrentUser('sub') callingUserId: string,
    @CurrentUser('gymId') gymId: string,
    @Body('userId') userId: string,
    @Body('pin') pin: string,
  ) {
    return this.auth.verifyPinForAction(gymId, callingUserId, userId, pin);
  }

  private async maybeBumpFailure(req: Request & { __bruteForce?: { scope: string; key: string } }, scope: string) {
    const ctx = req.__bruteForce;
    if (!ctx || ctx.scope !== scope) return;
    await this.bf.checkAndIncrement(`${scope}:${ctx.key}`);
  }
}
