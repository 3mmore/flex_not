/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * SECURITY (Item 3 fix): single source of truth for the refresh token
 * lifetime, shared by both the JWT signing code (auth.service.ts) and the
 * `flx_refresh` cookie's `maxAge` (auth.controller.ts / two-factor.controller.ts).
 *
 * Previously the JWT was signed with `expiresIn: '7d'` while the cookie was
 * set with `maxAge: 30 * 24 * 3600 * 1000` (30 days). That mismatch meant
 * the browser would keep sending a `flx_refresh` cookie for up to 23 extra
 * days after the JWT inside it had already expired — a harmless-looking but
 * sloppy inconsistency that also meant an attacker with a stolen cookie
 * value from day 8 onward would find the JWT itself already rejected by
 * `jwt.verifyAsync` (so no live security regression existed in the *token*
 * validation), but the *stated* lifetime callers might reasonably assume
 * from "the cookie lasts 30 days" was simply wrong, and any future code
 * that trusted cookie presence as a proxy for "still logged in" (rather
 * than re-verifying the JWT) would have been exploitable.
 *
 * FIX: pick ONE value (7 days) and derive both the JWT `expiresIn` and the
 * cookie `maxAge` from it, here, once.
 */

/**
 * PHASE N1 — every value here is now a FUNCTION, read at call time.
 *
 * They used to be module-scope constants, i.e. frozen the moment this file was
 * imported. `ConfigModule` loads `.env` only when the Nest container is
 * initialised, which happens *after* imports, so the constants held the right
 * values solely because `@prisma/client` happened to inject `.env` first (see
 * `config/load-env.ts`). When that accident did not happen, an operator's
 * `REFRESH_TOKEN_TTL_DAYS=1` was silently ignored and the 7-day default used for
 * BOTH the JWT and the `flx_refresh` cookie — a quiet security downgrade in the
 * one file whose whole purpose is to keep those two lifetimes identical and
 * explicit. Reading at call time removes the dependency on import order.
 */

const DEFAULT_REFRESH_TTL_DAYS = 7;
const DEFAULT_ACCESS_TTL_SECONDS = 900; // 15 min, matching the JWT default

/**
 * Parse a `900` / `15m` / `12h` / `7d` style lifetime into seconds.
 */
function parseTtlSeconds(value: string | undefined, fallbackSeconds: number): number {
  if (!value) return fallbackSeconds;
  const m = value.trim().match(/^(\d+)([smhd])?$/i);
  if (!m) return fallbackSeconds;
  const n = Number(m[1]);
  const unit = (m[2] || 's').toLowerCase();
  if (unit === 'm') return n * 60;
  if (unit === 'h') return n * 3600;
  if (unit === 'd') return n * 86400;
  return n;
}

/** Refresh token / cookie lifetime, in days. Override via REFRESH_TOKEN_TTL_DAYS. */
export function refreshTokenTtlDays(): number {
  const raw = process.env.REFRESH_TOKEN_TTL_DAYS;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_REFRESH_TTL_DAYS;
}

/** Same lifetime, in seconds — used for the `RefreshToken.expiresAt` DB column. */
export function refreshTokenTtlSeconds(): number {
  return refreshTokenTtlDays() * 24 * 60 * 60;
}

/**
 * Passed straight into `jwt.signAsync({ ... }, { expiresIn: ... })`. jsonwebtoken
 * accepts a plain number of seconds here just as validly as a "7d"-style string —
 * using the number avoids fighting TypeScript's `ms.StringValue` template-literal
 * type while still guaranteeing this is the exact same value as
 * `refreshTokenTtlSeconds()` used everywhere else.
 */
export function refreshTokenJwtExpiresIn(): number {
  return refreshTokenTtlSeconds();
}

/** Same lifetime, in milliseconds — used for the `flx_refresh` cookie's `maxAge`. */
export function refreshTokenCookieMaxAgeMs(): number {
  return refreshTokenTtlSeconds() * 1000;
}

/**
 * Access token cookie maxAge, derived from JWT_ACCESS_TTL.
 * Falls back to 900 seconds (15 min) matching the JWT default.
 */
export function accessTokenCookieMaxAgeMs(): number {
  return parseTtlSeconds(process.env.JWT_ACCESS_TTL, DEFAULT_ACCESS_TTL_SECONDS) * 1000;
}
