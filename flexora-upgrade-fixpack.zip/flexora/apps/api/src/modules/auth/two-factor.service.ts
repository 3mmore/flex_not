/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * TOTP (RFC 6238) two-factor authentication for OWNER accounts.
 *
 * Security:
 *   - TOTP secrets are AES-256-GCM encrypted at rest via EncryptionService.
 *   - Backup codes (8 one-time codes) are also encrypted.
 *   - A previously-used code cannot be reused (single-use within the 90s window).
 *   - OWNER role only.
 */
import {
  ForbiddenException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { authenticator } from 'otplib';
import * as QRCode from 'qrcode';
import { createHash, randomBytes } from 'crypto';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { EncryptionService } from '../../common/security/encryption.service';

interface PreAuthUserRow {
  id: string;
  email: string;
  role: string;
  gymId: string | null;
  active: boolean;
  twoFaEnabled: boolean;
  twoFaSecret: string | null;
  twoFaBackupCodes: string | null;
  twoFaLastCode: string | null;
}

authenticator.options = { window: 1, step: 30 };

interface SetupResult {
  secret: string; // base32 — only returned once during setup
  otpauthUrl: string;
  qrCodeDataUrl: string;
  backupCodes: string[];
}

@Injectable()
export class TwoFactorService {
  private readonly logger = new Logger(TwoFactorService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  private safeDecrypt(value: string | null | undefined): string {
    if (!value) return '';
    try { return this.encryption.decrypt(value); } catch { return value; }
  }

  private async assertOwner(userId: string) {
    const u = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!u) throw new UnauthorizedException();
    if (u.role !== 'OWNER') {
      throw new ForbiddenException('2FA is only available for OWNER accounts');
    }
    return u;
  }

  /** Generates a new secret + QR + backup codes. Does NOT enable yet. */
  async setup(userId: string): Promise<SetupResult> {
    const user = await this.assertOwner(userId);
    if (user.twoFaEnabled) {
      throw new ForbiddenException('Disable existing 2FA with a valid code before enrolling a new authenticator');
    }
    const secret = authenticator.generateSecret();
    const label = encodeURIComponent(`FLEXORA:${user.email}`);
    const issuer = encodeURIComponent('FLEXORA Gym OS');
    const otpauthUrl = `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&period=30&digits=6`;
    const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);

    // Generate 8 backup codes
    const backupCodes = Array.from({ length: 8 }, () =>
      randomBytes(4).toString('hex').toUpperCase().match(/.{4}/g)!.join('-'),
    );

    // Persist as pending (encrypted) so a verify call can promote them
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFaSecret: this.encryption.encrypt(secret),
        twoFaBackupCodes: this.encryption.encrypt(JSON.stringify(backupCodes)),
        twoFaEnabled: false,
        twoFaLastCode: null,
      },
    });
    return { secret, otpauthUrl, qrCodeDataUrl, backupCodes };
  }

  /**
   * Verifies the first TOTP code and flips twoFaEnabled=true.
   * Returns success only if the code matches the just-generated secret.
   * Also records the code hash in twoFaLastCode to prevent immediate reuse.
   */
  async verifySetup(userId: string, code: string): Promise<{ ok: true }> {
    const user = await this.assertOwner(userId);
    if (!user.twoFaSecret) {
      throw new UnauthorizedException('No 2FA setup in progress');
    }
    const secret = this.safeDecrypt(user.twoFaSecret);
    if (!authenticator.check(code, secret)) {
      throw new UnauthorizedException('Invalid TOTP code');
    }
    const codeHash = createHash('sha256').update(code.trim()).digest('hex');
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFaEnabled: true,
        twoFaLastCode: codeHash,
      },
    });
    return { ok: true };
  }

  /**
   * Verifies a TOTP code at login. Accepts the encrypted secret or
   * consumes one of the encrypted backup codes.
   * Returns true on success, false on failure (never throws here).
   *
   * Security: Prevents code reuse within the 90-second window by hashing
   * the submitted code (SHA-256) and comparing against twoFaLastCode.
   * A reused code is always rejected.
   */
  /**
   * CRITICAL FIX (see migration 202607070001_preauth_lookup_function's
   * extensive comment for the full root-cause/rationale): this method is
   * called both from fully-authenticated, tenant-scoped routes (this
   * service's own setup/verifySetup/disable, reached via
   * TwoFactorController routes that are NOT @Public() and therefore
   * already have app.gym_id correctly set by the global TenantGuard) AND
   * from genuinely pre-auth, @Public() routes with no tenant context at
   * all (AuthService.verifyTwoFaLogin, TwoFactorController.loginStep —
   * both only have a temp 2FA token, not a full session, so no gymId can
   * exist yet). A plain `this.prisma.user.findUnique`/`.update` here would
   * be silently filtered/rejected by "User"'s real FORCE ROW LEVEL
   * SECURITY policy under the real flexora_app production role whenever
   * called from the pre-auth path — confirmed directly against a real
   * Postgres database before this fix. Rather than have this shared
   * method's correctness silently depend on which of its two call-site
   * classes happened to invoke it, it now unconditionally uses the
   * SECURITY DEFINER preauth_find_user_by_id /
   * preauth_update_user_2fa_state functions for both its read and its
   * write — correct and identical regardless of caller context, and
   * still scoped by exact, globally-unique userId (never enumerable) with
   * writes limited to exactly the 2 columns TOTP verification needs.
   */
  async verifyCode(userId: string, code: string): Promise<boolean> {
    // CRITICAL FIX (F-028): The `User` table has FORCE ROW LEVEL SECURITY
    // with policy `"gymId" = current_setting('app.gym_id', true)`. Under
    // the flexora_app production role, a direct `SELECT ... FOR UPDATE`
    // without setting app.gym_id silently returns zero rows.
    //
    // Fix: First get the user via preauth_find_user_by_id (SECURITY DEFINER,
    // bypasses RLS) to obtain their real gymId. Then set app.gym_id so the
    // FOR UPDATE lock can find the row. The writes still use the SECURITY
    // DEFINER preauth_update_user_2fa_state function.
    return this.prisma.$transaction(async (tx) => {
      const preRows = await tx.$queryRaw<PreAuthUserRow[]>(
        Prisma.sql`SELECT * FROM preauth_find_user_by_id(${userId})`,
      );
      const preUser = preRows[0];
      if (!preUser || !preUser.twoFaEnabled || !preUser.twoFaSecret) return false;

      // Set app.gym_id so the FOR UPDATE query can find the user row
      if (preUser.gymId) {
        await tx.$executeRaw(
          Prisma.sql`SELECT set_config('app.gym_id', ${preUser.gymId}, true)`,
        );
      }

      // Now FOR UPDATE will see the row under RLS
      const rows = await tx.$queryRaw<PreAuthUserRow[]>(
        Prisma.sql`SELECT * FROM "User" WHERE id = ${userId} FOR UPDATE`,
      );
      const user = rows[0];
      if (!user) return false;

      const codeHash = createHash('sha256').update(code.trim()).digest('hex');

      // Reject reused code — prevents replay within the 90s window
      if (user.twoFaLastCode === codeHash) return false;

      const secret = this.safeDecrypt(user.twoFaSecret);

      if (authenticator.check(code, secret)) {
      await this.prisma.$queryRaw(
        Prisma.sql`SELECT preauth_update_user_2fa_state(${userId}, ${codeHash}, NULL, false)`,
      );
      return true;
    }

    // Try backup codes
    if (user.twoFaBackupCodes) {
      try {
        const codes: string[] = JSON.parse(
          this.safeDecrypt(user.twoFaBackupCodes),
        );
        const idx = codes.indexOf(code.trim().toUpperCase());
        if (idx >= 0) {
          codes.splice(idx, 1);
          const encryptedCodes = this.encryption.encrypt(JSON.stringify(codes));
          await this.prisma.$queryRaw(
            Prisma.sql`SELECT preauth_update_user_2fa_state(${userId}, ${codeHash}, ${encryptedCodes}, true)`,
          );
          return true;
        }
      } catch (e) {
        this.logger.warn(`Backup-code decryption failed for ${userId}: ${(e as Error).message}`);
      }
    }
    return false;
    }, { isolationLevel: 'Serializable' as any });
  }

  async disable(userId: string, code: string): Promise<{ ok: true }> {
    const ok = await this.verifyCode(userId, code);
    if (!ok) throw new UnauthorizedException('Invalid TOTP code');
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFaEnabled: false,
        twoFaSecret: null,
        twoFaBackupCodes: null,
        twoFaLastCode: null,
      },
    });
    return { ok: true };
  }
}
