/**
 * FLEXORA Gym OS — Item 11 DI sanity check.
 *
 * Boots the REAL AuthModule (via Nest's TestingModule, not manual `new`)
 * to prove the actual dependency-injection graph resolves cleanly now that
 * AuthService additionally depends on TwoFactorService — i.e. this isn't
 * just something that happens to work when hand-constructing mocks in
 * auth.service.spec.ts, it resolves in the real Nest container too.
 */
import { Test } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { AuthModule } from './auth.module';
import { AuthService } from './auth.service';
import { TwoFactorService } from './two-factor.service';
import { PrismaModule } from '../../prisma/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { SecurityModule } from '../../common/security/security.module';
import { PermissionsModule } from '../permissions/permissions.module';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

describe('AuthModule — Item 11: real DI graph resolves AuthService -> TwoFactorService', () => {
  it('bootstraps AuthModule and resolves AuthService with a real, injected TwoFactorService instance', async () => {
    const moduleRef = await Test.createTestingModule({
      // PermissionsModule is @Global — importing it once registers its
      // providers for the whole testing module (the real AppModule does the
      // same), so AuthService's PermissionsService dependency resolves.
      imports: [ConfigModule.forRoot({ isGlobal: true }), PrismaModule, RedisModule, SecurityModule, PermissionsModule, AuthModule],
    })
      // AuthController/TwoFactorController's own `@UseGuards(JwtAuthGuard)`
      // decorations make Nest instantiate JwtAuthGuard directly. Its
      // constructor intentionally accepts a `Reflector | { verifyAsync }`
      // union (a pre-existing, unrelated design choice, not part of Item
      // 11's scope) that automatic constructor injection can't
      // disambiguate — same pre-existing quirk worked around in Item 3's
      // refresh-token-expiry.spec.ts via overrideGuard.
      .overrideGuard(JwtAuthGuard)
      .useValue(new JwtAuthGuard(new Reflector()))
      .compile();

    const authService = moduleRef.get(AuthService);
    const twoFactorService = moduleRef.get(TwoFactorService);

    expect(authService).toBeInstanceOf(AuthService);
    expect(twoFactorService).toBeInstanceOf(TwoFactorService);
    // Confirms AuthService actually received a real TwoFactorService
    // instance (not undefined) via constructor injection.
    expect((authService as any).twoFactor).toBe(twoFactorService);

    await moduleRef.close();
  }, 30000);
});

