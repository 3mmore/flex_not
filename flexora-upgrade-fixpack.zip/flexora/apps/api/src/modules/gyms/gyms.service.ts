/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, NotFoundException } from '@nestjs/common';
import { normalizeHexColor } from '../../common/validation/color';
import { PrismaService } from '../../config/prisma.service';

@Injectable()
export class GymsService {
  constructor(private readonly prisma: PrismaService) {}

  async me(gymId: string) {
    const gym = await this.prisma.gym.findUnique({
      where: { id: gymId }, include: { license: true, subscription: true },
    });
    if (!gym) throw new NotFoundException('Gym not found');
    return gym;
  }
  updateBranding(
    gymId: string,
    data: {
      name?: string; nameAr?: string; logo?: string; faviconUrl?: string;
      loginBackgroundUrl?: string; primaryColor?: string; accentColor?: string;
      email?: string; phone?: string; address?: string; taxId?: string;
      // ROUND 14 (Phase F4): owner-level switch (set by the OWNER only —
      // enforced in the controller).
      managersMayChangeIntegrations?: boolean;
    },
  ) {
    // BUG FIX (P0 branding saves silently 500'd): the DTO used to be passed
    // STRAIGHT into Prisma, but it carries fields that are not Gym columns
    // (nameAr, primaryColor) — Prisma rejects unknown args, so every branding
    // save that included them failed and the color/logo never persisted.
    // Map the client vocabulary onto the real schema instead.
    const { nameAr, primaryColor, ...rest } = data;
    const patch: Record<string, unknown> = { ...rest };
    // Brand colors reach the shell as --brand / --brand-rgb, so they must be a
    // real hex value; normalize (#ABC → #aabbcc) so two gyms that pick the same
    // color store the same string.
    if (primaryColor !== undefined) patch.accentColor = normalizeHexColor(primaryColor) ?? primaryColor;
    if (nameAr !== undefined && !rest.name) patch.name = nameAr;
    return this.prisma.gym.update({ where: { id: gymId }, data: patch });
  }

  async getNotificationSettings(gymId: string) {
    return this.prisma.gym.findUnique({
      where: { id: gymId },
      select: {
        ownerPersonalMobile: true,
        notifyOnSale: true,
        notifyOnMemberAdd: true,
        notifyOnMemberDelete: true,
        notifyOnRefund: true,
        antiTheftEnabled: true,
        maxDiscountAlert: true,
        maxCashAlert: true,
      },
    });
  }

  async updateNotificationSettings(
    gymId: string,
    dto: any) {
    return this.prisma.gym.update({
      where: { id: gymId },
      data: dto,
    });
  }
}
