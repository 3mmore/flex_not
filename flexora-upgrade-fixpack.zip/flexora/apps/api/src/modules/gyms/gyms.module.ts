/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { GymsService } from './gyms.service';
import { GymsController } from './gyms.controller';
@Module({ imports: [JwtModule.register({})], controllers: [GymsController], providers: [GymsService] })
export class GymsModule {}
