/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { ForbiddenException, Body, Controller, Get, Patch, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { GymsService } from './gyms.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { IntegrationBrandingGuard } from '../../common/guards/integration-branding.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { IsOptional, IsString, Matches, IsBoolean, IsInt, Min, Max } from 'class-validator';
import { HEX_COLOR_RE, HEX_COLOR_MESSAGE } from '../../common/validation/color';
import { Type } from 'class-transformer';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';

class UpdateBrandingDto {
  // ROUND 14 (Phase F4): the owner-level switch — only the OWNER may set it.
  @IsOptional() @IsBoolean() managersMayChangeIntegrations?: boolean;
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() nameAr?: string;
  @IsOptional() @IsString() email?: string;
  // P1: gym phone must be a valid Egyptian mobile (settings page edits this).
  @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) logo?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) faviconUrl?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) loginBackgroundUrl?: string;
  @IsOptional() @IsString() @Matches(HEX_COLOR_RE, { message: HEX_COLOR_MESSAGE }) primaryColor?: string;
  @IsOptional() @IsString() @Matches(HEX_COLOR_RE, { message: HEX_COLOR_MESSAGE }) accentColor?: string;
}

export class UpdateNotificationSettingsDto {
  @IsOptional() @IsString()
  ownerPersonalMobile?: string;

  @IsOptional() @IsBoolean()
  @Type(() => Boolean)
  notifyOnSale?: boolean;

  @IsOptional() @IsBoolean()
  @Type(() => Boolean)
  notifyOnMemberAdd?: boolean;

  @IsOptional() @IsBoolean()
  @Type(() => Boolean)
  notifyOnMemberDelete?: boolean;

  @IsOptional() @IsBoolean()
  @Type(() => Boolean)
  notifyOnRefund?: boolean;

  @IsOptional() @IsBoolean()
  @Type(() => Boolean)
  antiTheftEnabled?: boolean;

  @IsOptional() @IsInt() @Min(5) @Max(100)
  @Type(() => Number)
  maxDiscountAlert?: number;

  @IsOptional() @IsInt() @Min(50)
  @Type(() => Number)
  maxCashAlert?: number;
}

@ApiTags('gyms')
@ApiBearerAuth()
@Controller()
export class GymsController {
  constructor(private readonly svc: GymsService) {}

  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('gyms/me')
  @Permissions('members.view')
  me(@GymId() g: string) { return this.svc.me(g); }

  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  // ROUND 14 (Phase F4): branding is owner-only unless the owner enabled the
  // "Managers may change integrations and branding" switch.
  @Patch('gyms/me') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('update','Gym')
  branding(@GymId() g: string, @Body() d: UpdateBrandingDto, @CurrentUser() user: any) {
    // the switch itself is owner-level: only the OWNER may change it
    if (d.managersMayChangeIntegrations !== undefined && user?.role !== 'OWNER') {
      throw new ForbiddenException('Only the gym owner can change this setting');
    }
    return this.svc.updateBranding(g, d);
  }

  @Get('gyms/notification-settings')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Permissions('settings.manage')
  getNotificationSettings(
    @GymId() gymId: string) {
    return this.svc
      .getNotificationSettings(gymId);
  }

  @Patch('gyms/notification-settings')
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard, IntegrationBrandingGuard)
  @Permissions('settings.manage')
  @Audit('update','Gym')
  updateNotificationSettings(
    @GymId() gymId: string,
    @Body() dto: UpdateNotificationSettingsDto) {
    return this.svc
      .updateNotificationSettings(gymId, dto);
  }
}
