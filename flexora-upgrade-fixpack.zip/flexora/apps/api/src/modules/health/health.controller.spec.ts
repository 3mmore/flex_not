/**
 * PHASE P4 — ONE authoritative health controller.
 *
 * What changed and what this pins:
 *
 *  - `apps/api/src/modules/monitoring/health.controller.ts` was a second
 *    `@Controller('health')` that no module ever registered: dead code whose
 *    `/api/health/details` route therefore never existed at runtime, while its
 *    `/live` and `/ready` handlers would have collided with the authoritative
 *    ones had it ever been wired. The file is deleted; `/details` moved into the
 *    authoritative controller behind the SAME guard + policy the controller
 *    already uses for `GET /api/health` and `GET /api/health/metrics`
 *    (JwtAuthGuard + RolesGuard + @Roles('SUPER_ADMIN')) — no new guard, no
 *    weaker one.
 *  - `/ready` no longer considers memory pressure. Readiness answers "can this
 *    replica serve traffic?", and heapUsed/heapTotal creeps towards 1.0 in any
 *    long-lived V8 process, so a busy-but-healthy instance used to be pulled out
 *    of rotation by its own allocator. Memory/pressure now lives on the
 *    authenticated endpoints (`GET /api/health`, `/metrics`, `/details`).
 *  - `/live` stays a pure ping: it must not touch the database or Redis, or a
 *    dependency outage would take the liveness probe — and the container — down
 *    with it.
 *
 * Test 4 ("still 200 under memory pressure") and test 7 (route uniqueness) are
 * the two that fail against the pre-P4 tree.
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'fs';
import { join } from 'path';
import { HealthController } from './health.controller';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';

const API_DIR = join(__dirname, '..', '..', '..');
const REPO_DIR = join(API_DIR, '..', '..');

/** A dependency double that fails the test if the handler touches it at all. */
function forbidden(name: string) {
  return new Proxy(
    {},
    {
      get() {
        throw new Error(`${name} must not be touched by this handler`);
      },
    },
  );
}

function resMock() {
  const res: any = {};
  res.statusCode = 0;
  res.body = undefined;
  res.status = jest.fn((code: number) => {
    res.statusCode = code;
    return res;
  });
  res.json = jest.fn((body: unknown) => {
    res.body = body;
    return res;
  });
  return res;
}

function controller(over: { dbUp?: boolean; redisUp?: boolean } = {}) {
  const dbUp = over.dbUp !== false;
  const redisUp = over.redisUp !== false;
  const prisma = {
    $queryRaw: dbUp ? jest.fn(async () => [{ '?column?': 1 }]) : jest.fn(async () => { throw new Error('db down'); }),
  };
  const redis = {
    client: { ping: redisUp ? jest.fn(async () => 'PONG') : jest.fn(async () => { throw new Error('redis down'); }) },
  };
  const scheduler = {};
  return new HealthController(prisma as never, redis as never, scheduler as never);
}

/** Read the metadata Nest attaches for a handler, without booting Nest. */
function meta(handler: () => unknown, key: string): unknown {
  return Reflect.getMetadata(key, handler);
}
function allMetaKeys(handler: () => unknown): string[] {
  return (Reflect.getMetadataKeys(handler) as string[]) || [];
}
function declaresRole(handler: () => unknown, role: string): boolean {
  return allMetaKeys(handler).some((key) => {
    const value = Reflect.getMetadata(key, handler);
    return Array.isArray(value) && value.includes(role);
  });
}
function usesGuard(handler: () => unknown, guard: unknown): boolean {
  const guards = (meta(handler, '__guards__') as unknown[] | undefined) || [];
  return guards.some((g) => g === guard || (typeof g === 'function' && g.name === (guard as any).name));
}

describe('PHASE P4 — one authoritative health controller', () => {
  const realMemoryUsage = process.memoryUsage;

  afterEach(() => {
    process.memoryUsage = realMemoryUsage;
  });

  it('1. /live is a pure ping: it never touches the database or Redis', () => {
    const c = new HealthController(forbidden('PrismaService') as never, forbidden('RedisService') as never, {} as never);
    const body = c.liveness() as { status: string; timestamp: string };
    expect(body.status).toBe('ok');
    expect(typeof body.timestamp).toBe('string');
    // and it is public, with an explicit 200
    expect(meta(c.liveness, 'path')).toBe('live');
    expect(allMetaKeys(c.liveness).some((k) => Reflect.getMetadata(k, c.liveness) === true)).toBe(true);
  });

  it('2. /ready answers 200 when DATABASE and REDIS are up, and reports no memory check', async () => {
    const c = controller({ dbUp: true, redisUp: true });
    const res = resMock();
    await c.readiness(res);
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ready');
    expect(res.body.checks).toEqual({ database: 'connected', redis: 'connected' });
    // PHASE P4: readiness must not carry memory pressure any more
    expect(res.body.checks).not.toHaveProperty('memory');
    expect(JSON.stringify(res.body)).not.toMatch(/memory|heap|pressure/i);
  });

  it('3. /ready answers 503 when the database OR redis is down', async () => {
    const dbDown = resMock();
    await controller({ dbUp: false, redisUp: true }).readiness(dbDown);
    expect(dbDown.statusCode).toBe(503);
    expect(dbDown.body.status).toBe('not_ready');
    expect(dbDown.body.checks.database).toBe('error');

    const redisDown = resMock();
    await controller({ dbUp: true, redisUp: false }).readiness(redisDown);
    expect(redisDown.statusCode).toBe(503);
    expect(redisDown.body.checks.redis).toBe('error');
  });

  it('4. /ready stays 200 under severe memory pressure (the P4 regression)', async () => {
    // Pre-P4 this handler computed heapUsed/heapTotal < 0.9 and returned 503,
    // which pulled healthy-but-busy replicas out of rotation.
    process.memoryUsage = (() => ({
      rss: 4 * 1024 * 1024 * 1024,
      heapTotal: 100 * 1024 * 1024,
      heapUsed: 99 * 1024 * 1024, // 99% — the old check failed here
      external: 1024,
      arrayBuffers: 0,
    })) as typeof process.memoryUsage;

    const res = resMock();
    await controller({ dbUp: true, redisUp: true }).readiness(res);
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ready');
  });

  it('5. /details reports dependency and pressure state', async () => {
    const c = controller({ dbUp: true, redisUp: true });
    const body = await c.details();
    expect(body.database).toBe('up');
    expect(body.redis).toBe('up');
    expect(['healthy', 'warning']).toContain(body.memory);
    expect(body.cpu).toBe('healthy');
    expect(typeof body.rss).toBe('number');
    expect(typeof body.heapUsed).toBe('number');

    const down = controller({ dbUp: false, redisUp: false });
    const body2 = await down.details();
    expect(body2.database).toBe('down');
    expect(body2.redis).toBe('down');
  });

  it('6. /details is behind the EXISTING SUPER_ADMIN policy and is not public', () => {
    const c = controller();
    const handler = c.details.bind(c) as unknown as () => unknown;
    const proto = Object.getPrototypeOf(c);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'details');
    const target = (descriptor && (descriptor.value as () => unknown)) || handler;

    expect(meta(target, 'path')).toBe('details');
    expect(usesGuard(target, JwtAuthGuard)).toBe(true);
    expect(usesGuard(target, RolesGuard)).toBe(true);
    expect(declaresRole(target, 'SUPER_ADMIN')).toBe(true);
    // the same policy the already-authenticated endpoints use
    const metricsDescriptor = Object.getOwnPropertyDescriptor(proto, 'metrics');
    const metricsTarget = metricsDescriptor && (metricsDescriptor.value as () => unknown);
    expect(declaresRole(metricsTarget as () => unknown, 'SUPER_ADMIN')).toBe(true);
    // and it must not be reachable anonymously
    expect(allMetaKeys(target).some((k) => k.toLowerCase().includes('public'))).toBe(false);
  });

  it('7. exactly one @Controller(\'health\') exists, and the dead monitoring controller is gone', () => {
    const srcDir = join(API_DIR, 'src');
    const hits: string[] = [];
    const walk = (dir: string) => {
      for (const entry of readdirSync(dir)) {
        const full = join(dir, entry);
        const st = statSync(full);
        if (st.isDirectory()) walk(full);
        else if (entry.endsWith('.ts') && !entry.endsWith('.spec.ts')) {
          const text = readFileSync(full, 'utf8');
          if (text.includes("@Controller('health')")) hits.push(full.slice(srcDir.length + 1));
        }
      }
    };
    walk(srcDir);
    expect(hits).toEqual([join('modules', 'health', 'health.controller.ts')]);
    expect(existsSync(join(srcDir, 'modules', 'monitoring', 'health.controller.ts'))).toBe(false);
  });

  it('8. the compose healthcheck points at /api/health/live', () => {
    const compose = readFileSync(join(REPO_DIR, 'docker-compose.yml'), 'utf8');
    const healthcheckLines = compose
      .split('\n')
      .filter((line) => line.includes('api/health/'));
    expect(healthcheckLines.length).toBeGreaterThan(0);
    for (const line of healthcheckLines) {
      expect(line).toMatch(/\/api\/health\/live/);
      expect(line).not.toMatch(/\/api\/health\/(ready|metrics|details)/);
    }
  });
});
