/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Get, HttpCode, HttpStatus, Res, Post, UseGuards } from '@nestjs/common';
import { SkipThrottle } from '@nestjs/throttler';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { HealthProbe } from '../../common/health/probe-routes';

/**
 * PHASE Q2 — every named throttler configured in `app.module.ts` has to be
 * skipped by name: `@SkipThrottle()` with no argument only sets
 * `THROTTLER:SKIPdefault`, and this app configures five NAMED throttlers
 * (global/short/auth/read/write), so the bare form would skip none of them.
 * ThrottlerGuard's storage is in-memory (see
 * src/test/integration/trust-proxy-throttle.spec.ts), so this was never a Redis
 * risk — it is here because a liveness probe that can be rate-limited is a probe
 * that can report a healthy container as dead during an incident storm.
 *
 * health-probe-isolation.spec.ts reads the throttler names out of AppModule's own
 * metadata and fails if this list stops covering them, so the duplication cannot
 * rot silently.
 */
const SKIP_ALL_THROTTLERS = { global: true, short: true, auth: true, read: true, write: true };
import { Response } from 'express';
import { Public } from '../../common/decorators/public.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { SchedulerService } from '../scheduler/scheduler.service';

@ApiTags('health')
@Controller('health')
export class HealthController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly scheduler: SchedulerService,
  ) {}

  /**
   * Liveness probe — always 200 if process is alive
   * Used by Docker HEALTHCHECK and orchestrators (K8s, ECS)
   *
   * PHASE Q2 — `@HealthProbe('live')` is the SINGLE declaration that makes this
   * route an infrastructure probe. Every global component that could otherwise
   * touch Redis (or the database) before this handler reads that marker:
   * guards/interceptors/filters through `probeKindOfContext()`, and middleware —
   * which runs before routing, so it has no handler to read — through
   * `probeKindOfRequest()`, whose path set is derived from this same metadata.
   * No component may consult Redis to answer this route; see
   * common/health/health-probe-isolation.spec.ts, which fails if one does.
   *
   * `@SkipThrottle()`: the global throttler is a global guard like any other, and
   * a liveness probe that can be rate-limited is a probe that can report a
   * healthy container as dead during an incident storm (orchestrators poll it
   * from one IP). The counter is in-memory, so this was never a Redis risk — it
   * is exempted because "no global component stands between the orchestrator and
   * this answer" is the actual requirement.
   */
  @Public()
  @HealthProbe('live')
  @SkipThrottle(SKIP_ALL_THROTTLERS)
  @Get('live')
  @HttpCode(HttpStatus.OK)
  liveness() {
    return { status: 'ok', timestamp: new Date().toISOString() };
  }

  /**
   * Readiness probe — 200 only when DATABASE and REDIS are reachable; 503 when
   * either one is down.
   *
   * PHASE P4: memory pressure is deliberately NOT part of readiness any more.
   * A readiness probe answers "can this replica serve traffic right now?", and
   * heap usage is not a dependency being down: a busy-but-healthy instance used
   * to be pulled out of rotation by its own allocator (heapUsed/heapTotal creeps
   * towards 1.0 in any long-lived V8 process, and `heapTotal` grows lazily), so
   * an orchestrator would restart pods that were serving requests fine — while a
   * genuinely dead database still returned 503 only by luck of being checked in
   * the same handler. Memory/pressure metrics live on the authenticated
   * endpoints below (`GET /api/health` and `GET /api/health/metrics`, both
   * SUPER_ADMIN) and in `GET /api/health/details`.
   */
  @Public()
  @HealthProbe('ready')
  @SkipThrottle(SKIP_ALL_THROTTLERS)
  @Get('ready')
  async readiness(@Res() res: Response) {
    let dbReady = false;
    let redisReady = false;

    // Check DB connectivity
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      dbReady = true;
    } catch {
      dbReady = false;
    }

    // Check Redis connectivity
    try {
      await this.redis.client.ping();
      redisReady = true;
    } catch {
      redisReady = false;
    }

    // PHASE P4: readiness is DATABASE and REDIS only. Memory pressure moved to
    // the authenticated endpoints (see the doc comment above).
    const allReady = dbReady && redisReady;

    const body = {
      status: allReady ? 'ready' : 'not_ready',
      timestamp: new Date().toISOString(),
      checks: {
        database: dbReady ? 'connected' : 'error',
        redis: redisReady ? 'connected' : 'error',
      },
    };

    return res.status(allReady ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE).json(body);
  }

  /**
   * PHASE P4 — `GET /api/health/details`, moved here from the (never wired)
   * `modules/monitoring/health.controller.ts`.
   *
   * It is protected by the SAME guard and policy the rest of this controller
   * already uses for `GET /api/health` and `GET /api/health/metrics`
   * (JwtAuthGuard + RolesGuard + @Roles('SUPER_ADMIN')): no new guard, no
   * weaker one. It reports dependency state plus the memory/cpu pressure
   * information that readiness no longer exposes, so nothing that used to be
   * observable is lost — it is just no longer public.
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('SUPER_ADMIN')
  @Get('details')
  async details() {
    const [database, redis] = await Promise.all([
      this.prisma
        .$queryRaw`SELECT 1`
        .then(() => 'up')
        .catch(() => 'down'),
      this.redis.client
        .ping()
        .then(() => 'up')
        .catch(() => 'down'),
    ]);
    const mem = process.memoryUsage();
    return {
      database,
      redis,
      memory: mem.rss < 1024 * 1024 * 1024 ? 'healthy' : 'warning',
      cpu: 'healthy',
      rss: mem.rss,
      heapUsed: mem.heapUsed,
      heapTotal: mem.heapTotal,
      timestamp: new Date().toISOString(),
    };
  }

/**
 * Full health check — detailed status with all dependencies.
 * Restricted to SUPER_ADMIN to avoid leaking version, uptime, and memory
 * info to unauthenticated callers (see F-023).
 */
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('SUPER_ADMIN')
@Get()
async health() {
    let dbStatus: 'connected' | 'error' = 'connected';
    let redisStatus: 'connected' | 'error' = 'connected';

    try {
      await this.prisma.$queryRaw`SELECT 1`;
    } catch {
      dbStatus = 'error';
    }

    try {
      await this.redis.client.ping();
    } catch {
      redisStatus = 'error';
    }

    const mem = process.memoryUsage();
    const heapUsageRatio = mem.heapUsed / mem.heapTotal;

    return {
      status: dbStatus === 'connected' && redisStatus === 'connected' ? 'ok' : 'error',
      version: process.env.APP_VERSION || (require('../../../package.json') as { version: string }).version,
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      db: dbStatus,
      redis: redisStatus,
      memory: {
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        heapUsagePercent: Math.round(heapUsageRatio * 100),
        rss: mem.rss,
        external: mem.external,
      },
    };
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('SUPER_ADMIN')
  @Get('metrics')
  metrics() {
    const mem = process.memoryUsage();
    return {
      uptimeSeconds: Math.floor(process.uptime()),
      memory: {
        rss: mem.rss,
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        external: mem.external,
      },
      timestamp: new Date().toISOString(),
    };
  }

  @Post('error')
  @Roles('SUPER_ADMIN')
  triggerError() {
    throw new Error('Deliberate tracing error');
  }

  @Post('trigger-cron')
  @Roles('SUPER_ADMIN')
  async triggerCron() {
    return this.scheduler.heartbeat();
  }
}
