/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { HealthController } from './health.controller';
import { SchedulerModule } from '../scheduler/scheduler.module';
// FIX (launch-readiness: third module-wiring bug found in the same chain
// as the QueueService/BackupsService fixes above -- each fix reveals the
// next masked failure since Nest's DI resolution stops at the first
// unresolved dependency it hits during bootstrap). HealthController's own
// constructor directly injects SchedulerService, but HealthModule never
// imported SchedulerModule (the only module that provides and exports
// it) at all. Confirmed directly: "Nest can't resolve dependencies of the
// HealthController (PrismaService, RedisService, ?). Please make sure
// that the argument SchedulerService at index [2] is available in the
// HealthModule module."
@Module({ imports: [SchedulerModule], controllers: [HealthController] })
export class HealthModule {}
