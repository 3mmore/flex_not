import { Module, Global } from '@nestjs/common';
import { SecurityShieldService } from './security-shield.service';
import { AiModule } from '../ai/ai.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Global()
@Module({
  imports: [AiModule, NotificationsModule],
  providers: [SecurityShieldService],
  exports: [SecurityShieldService],
})
export class SecurityShieldModule {}
