import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { AiBrainService } from '../ai/ai-brain.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

@Injectable()
export class SecurityShieldService {
  private readonly BLOCK_THRESHOLD = 50;
  private readonly ALERT_THRESHOLD = 20;

  constructor(
    private prisma: PrismaService,
    private redis: RedisService,
    private aiBrain: AiBrainService,
    private notifications: NotificationsService,
    private readonly cronLeadership: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  async recordFailedAttempt(
    ip: string,
    gymId: string,
    action: string,
  ): Promise<void> {
    const key = `shield:fails:${ip}`;
    const count = await this.redis.client.incr(key);
    if (count === 1) {
      await this.redis.client.expire(key, 3600);
    }
    await this.tenantContext.run(gymId, () => this.prisma.auditLog.create({
      data: {
        gymId,
        action: 'SECURITY_FAILED_ATTEMPT',
        entity: 'SECURITY',
        meta: { ip, action, count },
      },
    })).catch(() => {});

    if (count >= this.BLOCK_THRESHOLD) {
      await this.blockIp(ip, gymId,
        `Auto-blocked: ${count} failures in 1 hour`
      );
    } else if (count === this.ALERT_THRESHOLD) {
      await this.alertOwner(ip, gymId, count);
    }
  }

  async blockIp(
    ip: string,
    gymId: string,
    reason: string,
  ): Promise<void> {
    await this.redis.client.set(
      `shield:blocked:${ip}`,
      reason,
      'EX', 24 * 60 * 60
    );
    await this.tenantContext.run(gymId, () => this.prisma.auditLog.create({
      data: {
        gymId,
        action: 'SECURITY_IP_BLOCKED',
        entity: 'SECURITY',
        meta: { ip, reason },
      },
    })).catch(() => {});

    const ownerPhone = process.env.PLATFORM_OWNER_PHONE;
    if (ownerPhone) {
      await this.notifications.whatsapp(
        null, ownerPhone,
        `🚫 تم حجب IP تلقائياً\n` +
        `IP: ${ip}\n` +
        `السبب: ${reason}\n` +
        `المدة: 24 ساعة`
      );
    }
  }

  async isBlocked(ip: string): Promise<boolean> {
    const blocked = await this.redis.client.get(`shield:blocked:${ip}`);
    return blocked !== null;
  }

  private async alertOwner(
    ip: string,
    gymId: string,
    count: number,
  ): Promise<void> {
    const ownerPhone = process.env.PLATFORM_OWNER_PHONE;
    if (!ownerPhone) return;

    const analysis = await this.aiBrain.chat(
      `Security alert: IP ${ip} made ${count}` +
      ` failed login attempts in 1 hour on` +
      ` gym ${gymId}. Is this a brute force attack?` +
      ` What should we do? Max 100 words. Arabic.`,
      'platform', 'analyst'
    );

    await this.notifications.whatsapp(
      null, ownerPhone,
      `⚠️ تنبيه أمني\n` +
      `IP: ${ip}\n` +
      `محاولات فاشلة: ${count}\n\n` +
      `تحليل AI:\n${analysis}`
    );
  }

  @Cron('*/15 * * * *')
  async scanForThreats(): Promise<void> {
    return requestContext.run({ requestId: 'cron:security-threats' }, async () => {
      if (!(await this.cronLeadership.acquireLock('security-shield-threats', 600_000))) return;
      try {
        const gyms = await this.prisma.gym.findMany({ select: { id: true }, take: 5000 });
        let suspiciousLogs = 0;
        for (const gym of gyms) {
          suspiciousLogs += await this.tenantContext.run(gym.id, () =>
            this.prisma.auditLog.count({
              where: {
                gymId: gym.id,
                action: 'SUSPICIOUS_REQUEST',
                createdAt: { gte: new Date(Date.now() - 15 * 60 * 1000) },
              },
            }),
          );
        }

        if (suspiciousLogs > 10) {
          const ownerPhone = process.env.PLATFORM_OWNER_PHONE;
          if (ownerPhone) {
            await this.notifications.whatsapp(
              null, ownerPhone,
              `🔴 تحذير أمني فوري\n` +
              `طلبات مشبوهة: ${suspiciousLogs}\n` +
              `في آخر 15 دقيقة\n` +
              `يرجى مراجعة السيستم فوراً`
            );
          }
        }
      } finally {
        await this.cronLeadership.releaseLock('security-shield-threats');
      }
    });
  }

  async getBlockedIps(): Promise<string[]> {
    const keys: string[] = [];
    let cursor = '0';
    do {
      const [next, batch] = await this.redis.client.scan(cursor, 'MATCH', 'shield:blocked:*', 'COUNT', 200);
      cursor = next;
      keys.push(...batch);
    } while (cursor !== '0' && keys.length < 10_000);
    return keys.slice(0, 10_000).map((key) => key.replace('shield:blocked:', ''));
  }

  async unblockIp(ip: string): Promise<void> {
    await this.redis.client.del(`shield:blocked:${ip}`);
    await this.prisma.auditLog.create({
      data: {
        gymId: null,
        action: 'SECURITY_IP_UNBLOCKED',
        entity: 'SECURITY',
        meta: { ip, unlockedBy: 'manual' }
      }
    }).catch(() => {});
  }
}
