/**
 * FLEXORA Gym OS — Marketplace controller (Phase 23)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { MarketplaceService } from './marketplace.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Public } from '../../common/decorators/public.decorator';

class InstallModuleDto { @IsOptional() @IsString() licenseKey?: string; }

@ApiTags('marketplace')
@ApiBearerAuth()
@RequiresFeature('priority_support')
@Controller('marketplace')
export class MarketplaceController {
  constructor(private readonly svc: MarketplaceService) {}

  @Public()
  @Get('catalog')
  catalog() { return this.svc.listCatalog(); }

  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('installed') @Roles('OWNER', 'MANAGER')
  installed(@GymId() g: string) { return this.svc.listInstalled(g); }

  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('install/:slug') @Roles('OWNER') @Audit('install', 'MarketplaceModule')
  install(@GymId() g: string, @Param('slug') slug: string, @Body() dto: InstallModuleDto) {
    return this.svc.install(g, slug, dto.licenseKey);
  }

  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Delete('install/:slug') @Roles('OWNER') @Audit('uninstall', 'MarketplaceModule')
  uninstall(@GymId() g: string, @Param('slug') slug: string) { return this.svc.uninstall(g, slug); }
}
