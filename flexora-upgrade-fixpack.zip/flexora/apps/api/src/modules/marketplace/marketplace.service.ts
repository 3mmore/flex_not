/**
 * FLEXORA Gym OS — Marketplace (Phase 23)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';

import { SubscriptionTier } from '@prisma/client';

const DEFAULT_MODULES: Array<{ slug: string; name: string; description: string; category: string; minTier: SubscriptionTier; priceMonthly: number }> = [
  { slug: 'ai-assistant', name: 'AI Business Assistant', description: 'Revenue forecasting, churn prediction, renewal prediction', category: 'AI', minTier: 'PRO', priceMonthly: 49 },
  { slug: 'whatsapp-business', name: 'WhatsApp Business', description: 'Bulk broadcasts, automated replies', category: 'Marketing', minTier: 'PRO', priceMonthly: 29 },
  { slug: 'biometric-pro', name: 'Biometric Pro (WebAuthn)', description: 'Fingerprint / face check-in', category: 'Operations', minTier: 'ELITE', priceMonthly: 39 },
  { slug: 'sms-bulk', name: 'SMS Bulk', description: 'Send thousands of SMS per month', category: 'Marketing', minTier: 'BASIC', priceMonthly: 19 },
  { slug: 'advanced-reports', name: 'Advanced Reports', description: 'P&L, Balance Sheet, Cash Flow', category: 'Reports', minTier: 'PRO', priceMonthly: 29 },
  { slug: 'multi-branch-pro', name: 'Multi-Branch Pro', description: 'Transfers, allocation, comparison', category: 'Operations', minTier: 'PRO', priceMonthly: 39 },
  { slug: 'custom-domain', name: 'Custom Domain', description: 'White-label at portal.yourgym.com', category: 'Branding', minTier: 'PRO', priceMonthly: 19 },
  { slug: 'sso', name: 'SSO + SCIM', description: 'Google / Microsoft / SAML', category: 'Enterprise', minTier: 'ELITE', priceMonthly: 99 },
];

@Injectable()
export class MarketplaceService implements OnModuleInit {
  private readonly logger = new Logger(MarketplaceService.name);
  private seeded = false;
  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    await this.ensureSeeded();
  }

  async ensureSeeded() {
    if (this.seeded) return;
    for (const m of DEFAULT_MODULES) {
      await this.prisma.marketplaceModule.upsert({
        where: { slug: m.slug },
        update: { name: m.name, description: m.description, category: m.category, minTier: m.minTier, priceMonthly: m.priceMonthly },
        create: m,
      });
    }
    this.seeded = true;
    this.logger.log(`Seeded ${DEFAULT_MODULES.length} marketplace modules`);
  }

  async listCatalog() {
    // Read-only: seed happens on module init, not on every GET.
    // This prevents write amplification on every public catalog request.
    return this.prisma.marketplaceModule.findMany({ where: { active: true }, orderBy: { category: 'asc' } });
  }

  async listInstalled(gymId: string) {
    return this.prisma.gymModuleInstallation.findMany({ where: { gymId }, include: { module: true }, orderBy: { activatedAt: 'desc' } });
  }

  async install(gymId: string, moduleSlug: string, licenseKey?: string) {
    const m = await this.prisma.marketplaceModule.findUnique({ where: { slug: moduleSlug } });
    if (!m) throw new BadRequestException('Module not found');
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    const inst = await this.prisma.gymModuleInstallation.upsert({
      where: { gymId_moduleId: { gymId, moduleId: m.id } },
      update: { status: 'INSTALLED', licenseKey, expiresAt },
      create: { gymId, moduleId: m.id, status: 'INSTALLED', licenseKey, expiresAt },
    });
    await this.prisma.marketplaceModule.update({ where: { id: m.id }, data: { installedCount: { increment: 1 } } });
    return inst;
  }

  async uninstall(gymId: string, moduleSlug: string) {
    const m = await this.prisma.marketplaceModule.findUnique({ where: { slug: moduleSlug } });
    if (!m) throw new BadRequestException('Module not found');
    return this.prisma.gymModuleInstallation.deleteMany({ where: { gymId, moduleId: m.id } });
  }
}
