/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { MarketplaceService } from './marketplace.service';

@Module({ imports: [PrismaModule], providers: [MarketplaceService], exports: [MarketplaceService] })
export class MarketplaceModule {}
