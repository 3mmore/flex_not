/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { AiAdvancedService } from './ai-advanced.service';

@Module({ imports: [PrismaModule], providers: [AiAdvancedService], exports: [AiAdvancedService] })
export class AiAdvancedModule {}
