/**
 * FLEXORA Gym OS — Advanced AI controller (Phase 21)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString, Min, MinLength } from 'class-validator';
import { AiAdvancedService } from './ai-advanced.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';

class ForecastDto { @IsOptional() @IsInt() @Min(1) days?: number; }

class AskDto { @IsString() @MinLength(5) question!: string; }

@ApiTags('ai-advanced')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('ai')
@Controller('ai-advanced')
export class AiAdvancedController {
  constructor(private readonly svc: AiAdvancedService) {}

  @Post('revenue-forecast') @Permissions('reports.view')
  forecast(@GymId() g: string, @Body() dto: ForecastDto) { return this.svc.revenueForecast(g, dto.days || 30); }

  @Post('churn') @Permissions('reports.view')
  churn(@GymId() g: string) { return this.svc.churnPrediction(g); }

  @Post('renewal') @Permissions('reports.view')
  renewal(@GymId() g: string) { return this.svc.renewalPrediction(g); }

  @Post('consultant') @Permissions('reports.view')
  consultant(@GymId() g: string, @Body() dto: AskDto) { return this.svc.businessConsultant(g, dto.question); }

  @Get('best-coach') @Permissions('reports.view')
  bestCoach(@GymId() g: string, @Query('days') days?: number) { return this.svc.bestCoach(g, days || 30); }


  @Get('upsell-targets') @Permissions('reports.view')
  upsellTargets(@GymId() g: string) { return this.svc.upsellTargets(g); }

  @Get('smart-pricing') @Permissions('reports.view')
  smartPricing(@GymId() g: string) { return this.svc.smartPricing(g); }

  @Get('retention-score') @Permissions('reports.view')
  retentionScore(@GymId() g: string) { return this.svc.retentionScore(g); }

  @Get('operational-insights') @Permissions('reports.view')
  operationalInsights(@GymId() g: string) { return this.svc.operationalInsights(g); }
}
