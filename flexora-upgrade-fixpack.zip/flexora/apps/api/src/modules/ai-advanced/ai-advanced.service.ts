/**
 * FLEXORA Gym OS — Advanced AI Platform (Phase 21)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { AiProvider } from '../ai/ai.provider';
import { AnthropicProvider } from '../ai/providers/anthropic.provider';
import { GeminiProvider } from '../ai/providers/gemini.provider';
import { GroqProvider } from '../ai/providers/groq.provider';

interface AiAnswer {
  answer: string;
  confidence: 'high' | 'medium' | 'low';
  dataUsed: Record<string, any>;
  generatedAt: string;
  source: 'claude' | 'gemini' | 'groq' | 'heuristic';
}

@Injectable()
export class AiAdvancedService {
  private readonly logger = new Logger(AiAdvancedService.name);
  constructor(private readonly prisma: PrismaService) {}

  private getProvider(): AiProvider | null {
    if (process.env.AI_ENABLED !== 'true') return null;
    const provider = process.env.AI_PROVIDER || 'anthropic';
    const providers: Record<string, AiProvider> = {
      anthropic: new AnthropicProvider(),
      gemini: new GeminiProvider(),
      groq: new GroqProvider(),
    };
    const selected = providers[provider] || providers.anthropic;
    if (!selected.enabled) {
      this.logger.warn(`AI provider "${provider}" selected but API key is missing. Advanced AI is using heuristics.`);
      return null;
    }
    return selected;
  }

  private providerSource(provider: AiProvider): 'claude' | 'gemini' | 'groq' {
    if (provider.name === 'gemini') return 'gemini';
    if (provider.name === 'groq') return 'groq';
    return 'claude';
  }

  private async askProvider(prompt: string, maxTokens = 600): Promise<{ text: string | null; source: 'claude' | 'gemini' | 'groq' | 'heuristic' }> {
    const provider = this.getProvider();
    if (!provider) return { text: null, source: 'heuristic' };
    try {
      const text = await provider.call('You are an expert gym business consultant for FLEXORA Gym OS. Answer briefly, practically, and based only on the provided gym KPIs.', prompt, maxTokens);
      return { text: text || null, source: text ? this.providerSource(provider) : 'heuristic' };
    } catch {
      return { text: null, source: 'heuristic' };
    }
  }

  async revenueForecast(gymId: string, days = 30): Promise<AiAnswer> {
    const since = new Date(Date.now() - 90 * 86400000);
    const recent = await this.prisma.transaction.findMany({
      where: { gymId, type: 'INCOME', createdAt: { gte: since } },
      select: { amount: true, createdAt: true },
      orderBy: { createdAt: 'asc' },
    });
    if (recent.length < 7) {
      return { answer: 'Not enough revenue data — need at least 7 days.', confidence: 'low', dataUsed: {}, generatedAt: new Date().toISOString(), source: 'heuristic' };
    }
    // Bucket by day for stable time-series
    const dayBuckets = new Map<string, number>();
    for (const r of recent) {
      const day = new Date(r.createdAt).toISOString().slice(0, 10);
      dayBuckets.set(day, (dayBuckets.get(day) || 0) + Number(r.amount));
    }
    const series = Array.from(dayBuckets.values());
    // Exponential moving average (alpha=0.3) for trend-aware forecast
    const alpha = 0.3;
    let ema = series[0];
    for (let i = 1; i < series.length; i++) ema = alpha * series[i] + (1 - alpha) * ema;
    const recent7 = series.slice(-7);
    const recent7Avg = recent7.reduce((a, b) => a + b, 0) / recent7.length;
    const dailyAvg = recent7Avg;
    const forecast = dailyAvg * days;
    // Trend: compare last 7 days vs previous 7
    const prev7 = series.slice(-14, -7);
    const prev7Avg = prev7.length ? prev7.reduce((a, b) => a + b, 0) / prev7.length : dailyAvg;
    const trend = prev7Avg > 0 ? ((dailyAvg - prev7Avg) / prev7Avg) * 100 : 0;
    const trendEmoji = trend > 5 ? '📈' : trend < -5 ? '📉' : '➡️';
    const trendText = trend > 5 ? `trending UP ${trend.toFixed(1)}%` : trend < -5 ? `trending DOWN ${Math.abs(trend).toFixed(1)}%` : 'stable';
    const aiResult = await this.askProvider(
      `Gym revenue forecast for next ${days} days. EMA (alpha=0.3): $${ema.toFixed(2)}/day. Recent 7d avg: $${recent7Avg.toFixed(2)}/day. Previous 7d avg: $${prev7Avg.toFixed(2)}/day. Trend: ${trendText}. Total sample: ${series.length} days. Respond in 2-3 sentences.`,
    );
    return {
      answer: aiResult.text || `${trendEmoji} Forecast: ~$${forecast.toFixed(2)} over next ${days} days. ${trendText}.`,
      confidence: aiResult.text ? 'high' : series.length > 30 ? 'medium' : 'low',
      dataUsed: { sampleDays: series.length, dailyAvg, recent7Avg, prev7Avg, ema, trendPercent: trend, forecast },
      generatedAt: new Date().toISOString(),
      source: aiResult.source,
    };
  }

  async churnPrediction(gymId: string): Promise<AiAnswer> {
    const members = await this.prisma.member.findMany({
      where: { gymId, frozen: false },
      select: { id: true, name: true, mobile: true, lastVisit: true, expiry: true, sessionsLeft: true, visits: true, plan: { select: { type: true } } },
    });
    const risks = members.map((m) => {
      let score = 0;
      const reasons: string[] = [];
      if (!m.lastVisit || (Date.now() - new Date(m.lastVisit).getTime()) > 14 * 86400000) { score += 35; reasons.push('no_visit_14d'); }
      if (m.plan?.type === 'SESSION' && (m.sessionsLeft || 0) <= 3) { score += 25; reasons.push('low_sessions'); }
      if (m.expiry && (new Date(m.expiry).getTime() - Date.now()) < 7 * 86400000) { score += 30; reasons.push('expiring_soon'); }
      if (m.visits < 5) { score += 10; reasons.push('low_total_visits'); }
      return { memberId: m.id, name: m.name, mobile: m.mobile, riskScore: Math.min(100, score), reasons };
    }).sort((a, b) => b.riskScore - a.riskScore);
    const high = risks.filter((r) => r.riskScore >= 50).slice(0, 50);
    return { answer: `${high.length} high-risk members identified.`, confidence: 'medium', dataUsed: { totalMembers: members.length, highRisk: high.length, topRisks: high.slice(0, 20) }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }

  async renewalPrediction(gymId: string): Promise<AiAnswer> {
    const expiring = await this.prisma.member.findMany({
      where: { gymId, frozen: false, expiry: { gte: new Date(), lte: new Date(Date.now() + 30 * 86400000) } },
      select: { id: true, name: true, mobile: true, expiry: true, visits: true, plan: { select: { name: true } } },
    });
    const predictions = expiring.map((m) => {
      let p = 0.5;
      if (m.visits >= 15) p += 0.3;
      if (m.visits < 5) p -= 0.3;
      p = Math.max(0.05, Math.min(0.95, p));
      return { memberId: m.id, name: m.name, renewalProbability: Math.round(p * 100) };
    });
    return { answer: `${expiring.length} expiring in 30d. Avg renewal: ${(predictions.reduce((s, p) => s + p.renewalProbability, 0) / Math.max(1, predictions.length)).toFixed(0)}%.`, confidence: 'medium', dataUsed: { expiringSoon: expiring.length }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }

  async businessConsultant(gymId: string, question: string): Promise<AiAnswer> {
    const since30 = new Date(Date.now() - 30 * 86400000);
    const [income, expense, checkins, newMembers, expiring] = await this.prisma.$transaction([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: since30 } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'EXPENSE', createdAt: { gte: since30 } }, _sum: { amount: true } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: since30 } } }),
      this.prisma.member.count({ where: { gymId, createdAt: { gte: since30 } } }),
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: new Date(), lte: new Date(Date.now() + 30 * 86400000) } } }),
    ]);
    const dataUsed = { income30d: Number(income._sum.amount || 0), expense30d: Number(expense._sum.amount || 0), checkins30d: checkins, newMembers30d: newMembers, expiringSoon: expiring };
    const aiResult = await this.askProvider(`You are a gym business consultant. KPIs (30d): revenue=$${dataUsed.income30d}, expenses=$${dataUsed.expense30d}, checkins=${dataUsed.checkins30d}, new=${dataUsed.newMembers30d}, expiring=${dataUsed.expiringSoon}. Question: ${question}. Answer briefly with one recommendation.`, 400);
    return { answer: aiResult.text || 'Insufficient data for AI. KPIs attached.', confidence: aiResult.text ? 'high' : 'low', dataUsed, generatedAt: new Date().toISOString(), source: aiResult.source };
  }

  async bestCoach(gymId: string, days = 30): Promise<AiAnswer> {
    const since = new Date(Date.now() - days * 86400000);
    const sessions = await this.prisma.ptSession.findMany({
      where: { gymId, scheduledAt: { gte: since } },
      select: { coachId: true, status: true, price: true, coach: { select: { user: { select: { name: true } } } } },
      take: 500,
    });
    const stats = new Map<string, { name: string; total: number; completed: number; revenue: number }>();
    for (const s of sessions) {
      const cur = stats.get(s.coachId) ?? { name: s.coach.user.name, total: 0, completed: 0, revenue: 0 };
      cur.total += 1;
      if (s.status === 'COMPLETED') cur.completed += 1;
      cur.revenue += Number(s.price);
      stats.set(s.coachId, cur);
    }
    const ranked = Array.from(stats.values()).map((c) => ({ ...c, completionRate: c.total > 0 ? Math.round((c.completed / c.total) * 100) : 0 })).sort((a, b) => b.revenue - a.revenue);
    return { answer: `Top coach: ${ranked[0]?.name || 'N/A'} (revenue $${ranked[0]?.revenue.toFixed(2) || '0'}, completion ${ranked[0]?.completionRate || 0}%).`, confidence: 'medium', dataUsed: { coaches: ranked, periodDays: days }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }


  async upsellTargets(gymId: string): Promise<AiAnswer> {
    const since = new Date(Date.now() - 60 * 86400000);
    const members = await this.prisma.member.findMany({
      where: { gymId, frozen: false, createdAt: { lte: since }, plan: { type: 'TIME' } },
      select: { id: true, name: true, mobile: true, visits: true, plan: { select: { name: true, price: true } } },
      take: 100,
    });
    const targets = members
      .map((m) => ({ memberId: m.id, name: m.name, mobile: m.mobile, visits: m.visits, pitch: `Hi ${m.name}, upgrade to a premium plan for better value and priority support.` }))
      .sort((a, b) => b.visits - a.visits)
      .slice(0, 25);
    return { answer: `${targets.length} upsell targets identified.`, confidence: 'medium', dataUsed: { targets }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }

  async smartPricing(gymId: string): Promise<AiAnswer> {
    const [active, revenue] = await this.prisma.$transaction([
      this.prisma.member.count({ where: { gymId, frozen: false, status: 'ACTIVE' } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME' }, _sum: { amount: true } }),
    ]);
    const revenueTotal = Number(revenue._sum.amount || 0);
    const urgency = active > 200 ? 'HIGH' : active > 50 ? 'MEDIUM' : 'LOW';
    const recommendation = active > 100 ? 'Test a 5-8% premium plan increase for new memberships.' : 'Keep entry pricing stable and bundle PT/class add-ons.';
    return { answer: `${recommendation} Urgency: ${urgency}.`, confidence: 'medium', dataUsed: { active, revenue: revenueTotal, season: new Date().getMonth() + 1, urgency }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }

  async retentionScore(gymId: string): Promise<AiAnswer> {
    const members = await this.prisma.member.findMany({ where: { gymId }, select: { id: true, name: true, vip: true, visits: true, createdAt: true, lastVisit: true }, take: 2000 });
    const scores = members.map((m) => {
      const recency = m.lastVisit ? Math.max(0, 30 - Math.round((Date.now() - +new Date(m.lastVisit)) / 86400000)) : 0;
      const tenureDays = Math.max(1, Math.round((Date.now() - +new Date(m.createdAt)) / 86400000));
      const frequency = Math.min(30, (m.visits / tenureDays) * 30);
      const score = Math.max(0, Math.min(100, Math.round(recency + frequency + (m.vip ? 20 : 0) + Math.min(20, tenureDays / 30))));
      return { memberId: m.id, name: m.name, score };
    });
    const distribution = { high: scores.filter((s) => s.score >= 70).length, medium: scores.filter((s) => s.score >= 40 && s.score < 70).length, low: scores.filter((s) => s.score < 40).length };
    return { answer: `Retention score distribution: ${distribution.high} high, ${distribution.medium} medium, ${distribution.low} low.`, confidence: 'high', dataUsed: { scores, distribution }, generatedAt: new Date().toISOString(), source: 'heuristic' };
  }

  /**
   * Phase 7 — Operational Insights
   * Detects anomalies and gives the gym owner actionable alerts.
   */
  async operationalInsights(gymId: string): Promise<AiAnswer> {
    const now = new Date();
    const start30 = new Date(now); start30.setDate(now.getDate() - 30);
    const start7 = new Date(now); start7.setDate(now.getDate() - 7);

    const [
      rev30, revPrev30, exp30, checkins30, checkins7,
      newMembers30, expiring30, lowStock, todayCheckins, latestBackup,
    ] = await this.prisma.$transaction([
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { gte: start30 } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', createdAt: { lt: start30, gte: new Date(now.getTime() - 60 * 86400000) } }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { gymId, type: 'EXPENSE', createdAt: { gte: start30 } }, _sum: { amount: true } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: start30 } } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: start7 } } }),
      this.prisma.member.count({ where: { gymId, createdAt: { gte: start30 } } }),
      this.prisma.member.count({ where: { gymId, frozen: false, expiry: { gte: now, lte: new Date(now.getTime() + 30 * 86400000) } } }),
      this.prisma.product.count({ where: { gymId } }),
      this.prisma.attendance.count({ where: { gymId, at: { gte: new Date(now.setHours(0, 0, 0, 0)) } } }),
      this.prisma.backup.findFirst({ where: { gymId }, orderBy: { createdAt: 'desc' } }),
    ]);

    const insights: string[] = [];
    const rev30N = Number(rev30._sum.amount || 0);
    const revPrev30N = Number(revPrev30._sum.amount || 0);
    const revChange = revPrev30N > 0 ? ((rev30N - revPrev30N) / revPrev30N) * 100 : 0;
    if (revChange < -10) insights.push(`🔴 Revenue dropped ${Math.abs(revChange).toFixed(1)}% vs previous 30 days. Investigate.`);
    else if (revChange > 10) insights.push(`🟢 Revenue up ${revChange.toFixed(1)}% vs previous 30 days.`);
    if (newMembers30 === 0) insights.push(`⚠️ Zero new members in 30 days. Acquisition channel review needed.`);
    if (expiring30 > 10) insights.push(`📅 ${expiring30} memberships expiring in next 30 days. Launch renewal campaign.`);
    if (latestBackup && Date.now() - new Date(latestBackup.createdAt).getTime() > 7 * 86400000) {
      insights.push(`💾 Last backup is older than 7 days. Check backup automation.`);
    }
    const net30 = rev30N - Number(exp30._sum.amount || 0);
    if (net30 < 0) insights.push(`💸 Negative cash flow this month (net: $${net30.toFixed(2)}). Review expenses.`);
    if (insights.length === 0) insights.push('✅ All operational metrics within healthy range.');
    return {
      answer: insights.join('\n'),
      confidence: 'high',
      dataUsed: { rev30: rev30N, revPrev30: revPrev30N, revChange, checkins30, checkins7, newMembers30, expiring30, todayCheckins, net30 },
      generatedAt: new Date().toISOString(),
      source: 'heuristic',
    };
  }
}
