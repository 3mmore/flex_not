/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { InvitationsService } from './invitations.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { TenantContextService } from '../../common/services/tenant-context.service';

/**
 * Hourly AI follow-up for free-visit guests. Iterates every gym, finds visits
 * that happened 2h+ ago and have not yet been followed up (and are not no-shows),
 * then triggers a personalised WhatsApp/SMS message + feedback link.
 */
@Injectable()
export class InvitationsCron {
  private readonly logger = new Logger('InvitationsCron');

  constructor(
    private readonly prisma: PrismaService,
    private readonly invitations: InvitationsService,
    private readonly cronLeader: CronLeadershipService,
    private readonly tenantContext: TenantContextService,
  ) {}

  @Cron(CronExpression.EVERY_HOUR)
  async sendVisitorFollowUps() {
    return requestContext.run({ requestId: 'cron:visitor-followups' }, async () => {
      const acquired = await this.cronLeader.acquireLock('invitations-followups-hourly', 55 * 60000);
      if (!acquired) return;
      try {
      let sent = 0;
      const gyms = await this.prisma.gym.findMany({ select: { id: true } });
      for (const gym of gyms) {
        const eligible = await this.tenantContext.run(gym.id, () => this.invitations.eligibleForFollowUp(gym.id));
        for (const inv of eligible) {
          try {
            await this.invitations.sendVisitorFollowUp(gym.id, inv.id);
            sent++;
          } catch (e: unknown) {
            this.logger.warn(`Follow-up failed for ${inv.id}: ${(e as Error).message}`);
          }
        }
      }
      if (sent) this.logger.log(`Visitor AI follow-ups sent: ${sent}`);
      } finally {
        await this.cronLeader.releaseLock('invitations-followups-hourly');
      }
    });
  }
}
