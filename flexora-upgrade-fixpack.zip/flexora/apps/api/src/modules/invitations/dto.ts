/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  IsDateString, IsEnum, IsInt, IsOptional, IsString, Matches, Max, Min, MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { InvitationStatus } from '@prisma/client';
import { PaginationDto } from '../../common/dto/pagination.dto';

import { EG_PHONE } from '../../common/validators/phone';

export class RegisterVisitDto {
  @IsString() memberId!: string;
  @IsString() @MinLength(2) visitorName!: string;
  @Matches(EG_PHONE, { message: 'Invalid Egyptian mobile (11 digits, 010/011/012/015)' })
    visitorPhone!: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsDateString() visitDate?: string;
}

export class SetSlotsDto {
  @Type(() => Number) @IsInt() @Min(0) @Max(20) totalSlots!: number;
}

export class ConvertDto {
  @IsString() newMemberId!: string;
}

export class FeedbackDto {
  @Type(() => Number) @IsInt() @Min(1) @Max(5) score!: number;
  @IsOptional() @IsString() text?: string;
}

export class ListVisitsDto extends PaginationDto {
  @IsOptional() @IsEnum(InvitationStatus) status?: InvitationStatus;
  @IsOptional() @IsString() memberId?: string;
  @IsOptional() @IsDateString() from?: string;
  @IsOptional() @IsDateString() to?: string;
  // ROUND 13 (Phase 1): TenantGuard pins `branchId` into every restricted
  // user's query object (deny-by-default for branch-scoped data). Declaring it
  // here keeps the pinned value valid under `forbidNonWhitelisted` instead of
  // 400-ing the list for every branch-restricted role. The Invitation model
  // carries branchId, so the Prisma scope middleware enforces the pin.
  @IsOptional() @IsString() branchId?: string;
}
