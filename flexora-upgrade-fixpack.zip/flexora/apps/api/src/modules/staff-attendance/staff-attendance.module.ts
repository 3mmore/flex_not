/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { StaffAttendanceService } from './staff-attendance.service';

@Module({
  imports: [PrismaModule],
  providers: [StaffAttendanceService],
  exports: [StaffAttendanceService],
})
export class StaffAttendanceModule {}
