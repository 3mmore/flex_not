/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Staff attendance (Phase 13).
 * - Clock in / clock out
 * - Daily + monthly reports per user
 * - P2-3: shift schedules (per-staff or gym-wide templates) with automatic
 *   lateness computed at check-in time.
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { evaluateLateness, minutesToHHMM, wallParts } from './shift-time';
import type { StaffShift } from '@prisma/client';

@Injectable()
export class StaffAttendanceService {
  private readonly logger = new Logger(StaffAttendanceService.name);
  constructor(private readonly prisma: PrismaService) {}

  /**
   * P2-3: resolve the shift that applies to `userId` right now.
   * Personal shifts override the gym-wide template (userId=null) for the
   * same weekday. "Today" is evaluated in Africa/Cairo — the locale of every
   * FLEXORA gym; the individual shift's tz still drives the minute math.
   */
  private async resolveShift(gymId: string, userId: string, now: Date): Promise<StaffShift | null> {
    const dow = wallParts(now, 'Africa/Cairo').dayOfWeek;
    const personal = await this.prisma.staffShift.findFirst({
      where: { gymId, userId, active: true, dayOfWeek: dow },
      orderBy: { startMin: 'asc' },
    });
    if (personal) return personal;
    return this.prisma.staffShift.findFirst({
      where: { gymId, userId: null, active: true, dayOfWeek: dow },
      orderBy: { startMin: 'asc' },
    });
  }

  async checkIn(gymId: string, userId: string, opts?: { method?: 'QR' | 'MANUAL'; branchId?: string; notes?: string }) {
    const u = await this.prisma.user.findFirst({ where: { id: userId, gymId } });
    if (!u) throw new BadRequestException('Invalid user');
    if (opts?.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: opts.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    const open = await this.prisma.staffAttendance.findFirst({
      where: { gymId, userId, checkOutAt: null },
    });
    if (open) throw new BadRequestException('Already checked in');
    const now = new Date();
    const row = await this.prisma.staffAttendance.create({
      data: {
        gymId,
        userId,
        branchId: opts?.branchId || u.branchId,
        method: opts?.method || 'MANUAL',
        notes: opts?.notes,
      },
    });

    // P2-3: automatic lateness. If the staff member (or the gym template)
    // has a shift for today, stamp expectedAt + lateMinutes onto the row.
    const shift = await this.resolveShift(gymId, userId, now);
    if (!shift) return { ...row, shift: null };
    const { expectedAt, lateMinutes } = evaluateLateness(now, shift);
    if (!expectedAt) return { ...row, shift: null };
    const updated = await this.prisma.staffAttendance.update({
      where: { id: row.id },
      data: { expectedAt, lateMinutes },
    });
    return {
      ...updated,
      shift: { id: shift.id, name: shift.name, start: minutesToHHMM(shift.startMin), end: minutesToHHMM(shift.endMin), graceMin: shift.graceMin },
    };
  }

  // ── P2-3: shift schedule CRUD ────────────────────────────────────────────
  private validateShiftInput(input: { dayOfWeek: number; startMin: number; endMin: number; graceMin?: number; tz?: string }) {
    if (!Number.isInteger(input.dayOfWeek) || input.dayOfWeek < 0 || input.dayOfWeek > 6) throw new BadRequestException('dayOfWeek must be 0 (Sun) – 6 (Sat)');
    if (!Number.isInteger(input.startMin) || input.startMin < 0 || input.startMin > 1439) throw new BadRequestException('startMin must be 0–1439 (minutes from midnight)');
    if (!Number.isInteger(input.endMin) || input.endMin < 0 || input.endMin > 1439) throw new BadRequestException('endMin must be 0–1439 (minutes from midnight)');
    if (input.endMin <= input.startMin) throw new BadRequestException('Shift must end after it starts (overnight shifts are not supported yet — split them)');
    if (input.graceMin !== undefined && (!Number.isInteger(input.graceMin) || input.graceMin < 0 || input.graceMin > 240)) throw new BadRequestException('graceMin must be 0–240');
    if (input.tz !== undefined) {
      try { new Intl.DateTimeFormat('en-US', { timeZone: input.tz }); } catch { throw new BadRequestException(`Unknown timezone: ${input.tz}`); }
    }
  }

  async listShifts(gymId: string) {
    const shifts = await this.prisma.staffShift.findMany({
      where: { gymId },
      orderBy: [{ dayOfWeek: 'asc' }, { startMin: 'asc' }],
      include: { user: { select: { id: true, name: true, role: true } } },
    });
    return shifts.map((s) => ({ ...s, start: minutesToHHMM(s.startMin), end: minutesToHHMM(s.endMin) }));
  }

  async createShift(gymId: string, dto: { userId?: string | null; name?: string; dayOfWeek: number; startMin: number; endMin: number; graceMin?: number; tz?: string; active?: boolean }) {
    this.validateShiftInput(dto);
    let userId: string | null = null;
    if (dto.userId) {
      const u = await this.prisma.user.findFirst({ where: { id: dto.userId, gymId } });
      if (!u) throw new BadRequestException('Staff member not found in this gym');
      userId = u.id;
    }
    const shift = await this.prisma.staffShift.create({
      data: {
        gymId, userId, name: dto.name?.trim() || null,
        dayOfWeek: dto.dayOfWeek, startMin: dto.startMin, endMin: dto.endMin,
        graceMin: dto.graceMin ?? 15, tz: dto.tz || 'Africa/Cairo', active: dto.active ?? true,
      },
      include: { user: { select: { id: true, name: true, role: true } } },
    });
    return { ...shift, start: minutesToHHMM(shift.startMin), end: minutesToHHMM(shift.endMin) };
  }

  async updateShift(gymId: string, id: string, dto: { name?: string; dayOfWeek?: number; startMin?: number; endMin?: number; graceMin?: number; tz?: string; active?: boolean }) {
    const existing = await this.prisma.staffShift.findFirst({ where: { id, gymId } });
    if (!existing) throw new NotFoundException('Shift not found');
    const merged = {
      dayOfWeek: dto.dayOfWeek ?? existing.dayOfWeek,
      startMin: dto.startMin ?? existing.startMin,
      endMin: dto.endMin ?? existing.endMin,
      graceMin: dto.graceMin ?? existing.graceMin,
      tz: dto.tz ?? existing.tz,
    };
    this.validateShiftInput(merged);
    const shift = await this.prisma.staffShift.update({
      where: { id },
      data: { ...(dto.name !== undefined ? { name: dto.name.trim() || null } : {}), dayOfWeek: merged.dayOfWeek, startMin: merged.startMin, endMin: merged.endMin, graceMin: merged.graceMin, tz: merged.tz, ...(dto.active !== undefined ? { active: dto.active } : {}) },
      include: { user: { select: { id: true, name: true, role: true } } },
    });
    return { ...shift, start: minutesToHHMM(shift.startMin), end: minutesToHHMM(shift.endMin) };
  }

  async deleteShift(gymId: string, id: string) {
    const res = await this.prisma.staffShift.deleteMany({ where: { id, gymId } });
    if (res.count === 0) throw new NotFoundException('Shift not found');
    return { ok: true };
  }

  async checkOut(gymId: string, userId: string) {
    const open = await this.prisma.staffAttendance.findFirst({
      where: { gymId, userId, checkOutAt: null },
      orderBy: { checkInAt: 'desc' },
    });
    if (!open) throw new BadRequestException('No open check-in');
    return this.prisma.staffAttendance.update({
      where: { id: open.id },
      data: { checkOutAt: new Date() },
    });
  }

  listToday(gymId: string) {
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart); dayEnd.setDate(dayEnd.getDate() + 1);
    return this.prisma.staffAttendance.findMany({
      where: { gymId, checkInAt: { gte: dayStart, lt: dayEnd } },
      include: { user: { select: { id: true, name: true, role: true } } },
      orderBy: { checkInAt: 'desc' },
    });
  }

  listForUser(gymId: string, userId: string, from: Date, to: Date) {
    return this.prisma.staffAttendance.findMany({
      where: { gymId, userId, checkInAt: { gte: from, lte: to } },
      orderBy: { checkInAt: 'desc' },
    });
  }

  upsertPayProfile(gymId: string, userId: string, hourlyRate: number, currency = 'EGP') {
    return this.prisma.staffPayProfile.upsert({
      where: { gymId_userId: { gymId, userId } },
      update: { hourlyRate, currency, active: true },
      create: { gymId, userId, hourlyRate, currency, active: true },
    });
  }

  async exportPayroll(gymId: string, from: Date, to: Date) {
    const profiles = await this.prisma.staffPayProfile.findMany({ where: { gymId, active: true } });
    const rows = await this.prisma.staffAttendance.findMany({ where: { gymId, checkInAt: { gte: from, lte: to }, checkOutAt: { not: null } }, include: { user: true } });
    const byUser = new Map<string, typeof rows>();
    for (const row of rows) byUser.set(row.userId, [...(byUser.get(row.userId) || []), row]);
    const exports: Array<{ userId: string; totalMinutes: number; overtimeMinutes: number; grossPay: number; timesheetId: string }> = [];
    for (const profile of profiles) {
      const entries = byUser.get(profile.userId) || [];
      const totalMinutes = entries.reduce((sum, entry) => sum + Math.round(((entry.checkOutAt as Date).getTime() - entry.checkInAt.getTime()) / 60000), 0);
      const overtimeMinutes = Math.max(0, totalMinutes - 40 * 60);
      const grossPay = (totalMinutes / 60) * Number(profile.hourlyRate) + (overtimeMinutes / 60) * Number(profile.hourlyRate) * 0.5;
      const timesheet = await this.prisma.timesheet.create({
        data: {
          gymId, userId: profile.userId, periodStart: from, periodEnd: to,
          status: 'EXPORTED', totalMinutes, overtimeMinutes, grossPay,
          entries: { create: entries.map((entry) => {
            const minutes = Math.round(((entry.checkOutAt as Date).getTime() - entry.checkInAt.getTime()) / 60000);
            return { staffAttendanceId: entry.id, checkInAt: entry.checkInAt, checkOutAt: entry.checkOutAt, minutes, overtimeMinutes: 0 };
          }) },
        },
      });
      exports.push({ userId: profile.userId, totalMinutes, overtimeMinutes, grossPay, timesheetId: timesheet.id });
    }
    return { from, to, rows: exports };
  }
}
