/**
 * FLEXORA Gym OS — White Label controller (Phase 22)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsOptional, IsString, Matches } from 'class-validator';
import { HEX_COLOR_RE, HEX_COLOR_MESSAGE } from '../../common/validation/color';
import { WhiteLabelService } from './white-label.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { IntegrationBrandingGuard } from '../../common/guards/integration-branding.guard';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class AddDomainDto { @IsString() hostname!: string; }
class BrandingDto {
  @IsOptional() @IsString() @Matches(HEX_COLOR_RE, { message: HEX_COLOR_MESSAGE }) primaryColor?: string;
  @IsOptional() @IsString() @Matches(HEX_COLOR_RE, { message: HEX_COLOR_MESSAGE }) secondaryColor?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) logo?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) faviconUrl?: string;
  @IsOptional() @IsString() @Matches(/^(https?:\/\/|data:image\/)/) loginBackgroundUrl?: string;
  @IsOptional() @IsString() appNameOverride?: string;
  @IsOptional() theme?: Record<string, string>;
  @IsOptional() @IsString() whatsappNumber?: string;
}
class TemplateDto {
  @IsString() key!: string; @IsString() subject!: string;
  @IsString() bodyHtml!: string; @IsOptional() @IsString() locale?: string;
}

@ApiTags('white-label')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('priority_support')
@Controller('white-label')
export class WhiteLabelController {
  constructor(private readonly svc: WhiteLabelService) {}

  @Get('config') @Permissions('settings.manage')
  config(@GymId() g: string) { return this.svc.getConfig(g); }

  @Get('theme') @Permissions('members.view')
  theme(@GymId() g: string) { return this.svc.getTheme(g); }

  @Patch('config') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('update_branding', 'Gym')
  patchConfig(@GymId() g: string, @Body() dto: BrandingDto) { return this.svc.updateBranding(g, dto); }

  @Post('domain') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('add_domain', 'CustomDomain')
  addDomainAlias(@GymId() g: string, @Body() dto: AddDomainDto) { return this.svc.addDomain(g, dto.hostname); }

  @Get('domains') @Permissions('settings.manage')
  listDomains(@GymId() g: string) { return this.svc.listDomains(g); }

  @Post('domains') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('add_domain', 'CustomDomain')
  addDomain(@GymId() g: string, @Body() dto: AddDomainDto) { return this.svc.addDomain(g, dto.hostname); }

  @Post('domains/:id/verify') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('verify_domain', 'CustomDomain')
  verify(@GymId() g: string, @Param('id') id: string) { return this.svc.verifyDomain(g, id); }

  @Delete('domains/:id') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('remove_domain', 'CustomDomain')
  remove(@GymId() g: string, @Param('id') id: string) { return this.svc.removeDomain(g, id); }

  @Put('branding') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('update_branding', 'Gym')
  updateBranding(@GymId() g: string, @Body() dto: BrandingDto) { return this.svc.updateBranding(g, dto); }

  @Get('templates') @Permissions('settings.manage')
  templates(@GymId() g: string, @Query('locale') locale?: string) { return this.svc.listTemplates(g, locale); }

  @Put('templates') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('upsert_template', 'EmailTemplate')
  upsert(@GymId() g: string, @Body() dto: TemplateDto) { return this.svc.upsertTemplate(g, dto.key, dto); }

  @Patch('templates/:id') @Permissions('settings.manage') @UseGuards(IntegrationBrandingGuard) @Audit('update_template', 'EmailTemplate')
  updateTemplate(@GymId() g: string, @Param('id') id: string, @Body() dto: Partial<TemplateDto>) { return this.svc.updateTemplate(g, id, dto); }
}
