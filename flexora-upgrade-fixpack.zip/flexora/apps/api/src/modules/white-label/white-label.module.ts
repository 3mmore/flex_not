/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { WhiteLabelService } from './white-label.service';

@Module({ imports: [PrismaModule], providers: [WhiteLabelService], exports: [WhiteLabelService] })
export class WhiteLabelModule {}
