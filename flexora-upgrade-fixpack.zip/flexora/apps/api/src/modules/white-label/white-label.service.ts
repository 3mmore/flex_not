/**
 * FLEXORA Gym OS — White Label SaaS (Phase 22)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { Prisma, DomainStatus } from '@prisma/client';

@Injectable()
export class WhiteLabelService {
  private readonly logger = new Logger(WhiteLabelService.name);
  private isThemeRecord(value: unknown): value is Record<string, string> {
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }
  constructor(private readonly prisma: PrismaService) {}

  getConfig(gymId: string) {
    return this.prisma.gym.findUnique({ where: { id: gymId }, select: { id: true, name: true, logo: true, accent: true, accentColor: true, secondaryColor: true, faviconUrl: true, loginBackgroundUrl: true, appNameOverride: true, theme: true, phone: true } });
  }

  async addDomain(gymId: string, hostname: string) {
    if (!/^[a-z0-9.-]+$/.test(hostname)) throw new BadRequestException('Invalid hostname');
    const token = `flexora-verify-${randomBytes(8).toString('hex')}`;
    return this.prisma.customDomain.create({ data: { gymId, hostname, domain: hostname, cnameTarget: process.env.WHITE_LABEL_CNAME_TARGET || 'cname.flexora.app', verificationToken: token, status: DomainStatus.PENDING } });
  }
  async verifyDomain(gymId: string, id: string) {
    const d = await this.getDomain(gymId, id);
    if (d.status === DomainStatus.VERIFIED) return d;
    return this.prisma.customDomain.update({ where: { id }, data: { status: DomainStatus.SSL_ACTIVE, verifiedAt: new Date(), sslProvisioned: true, sslCertPath: process.env.WHITE_LABEL_SSL_CERT_TEMPLATE || null } });
  }
  async removeDomain(gymId: string, id: string) {
    return this.prisma.customDomain.deleteMany({ where: { id, gymId } });
  }
  listDomains(gymId: string) {
    return this.prisma.customDomain.findMany({ where: { gymId }, orderBy: { createdAt: 'desc' } });
  }
  async getDomain(gymId: string, id: string) {
    const d = await this.prisma.customDomain.findFirst({ where: { id, gymId } });
    if (!d) throw new NotFoundException('Domain not found');
    return d;
  }
  async updateBranding(gymId: string, branding: { primaryColor?: string; secondaryColor?: string; logo?: string; faviconUrl?: string; loginBackgroundUrl?: string; appNameOverride?: string; whatsappNumber?: string; theme?: Record<string, string> }) {
    const data: Prisma.GymUpdateInput = {
      accentColor: branding.primaryColor,
      secondaryColor: branding.secondaryColor,
      logo: branding.logo,
      faviconUrl: branding.faviconUrl,
      loginBackgroundUrl: branding.loginBackgroundUrl,
      appNameOverride: branding.appNameOverride,
      theme: branding.theme as Prisma.InputJsonValue,
    };
    return this.prisma.gym.update({ where: { id: gymId }, data });
  }
  async getTheme(gymId: string) {
    const gym = await this.prisma.gym.findUnique({ where: { id: gymId }, select: { accentColor: true, secondaryColor: true, theme: true } });
    const theme: Record<string, string> = this.isThemeRecord(gym?.theme) ? (gym.theme as Record<string, string>) : {};
    return {
      // ROUND 13 (Phase 2): an empty gym accent falls back to FLEXORA gold,
      // never indigo — the old blue fallback repainted the portal blue for
      // any gym whose color was empty.
      primaryColor: theme.primaryColor || gym?.accentColor || '#C5A059',
      secondaryColor: theme.secondaryColor || gym?.secondaryColor || '#22d3a8',
      accentColor: theme.accentColor || '#22d3a8',
      borderRadius: theme.borderRadius || '16px',
      fontFamily: theme.fontFamily || 'Inter, system-ui, sans-serif',
    };
  }
  listTemplates(gymId: string, locale?: string) {
    return this.prisma.emailTemplate.findMany({ where: { gymId, ...(locale ? { locale } : {}) }, orderBy: { key: 'asc' } });
  }
  async upsertTemplate(gymId: string, key: string, dto: { subject: string; bodyHtml: string; locale?: string; active?: boolean }) {
    return this.prisma.emailTemplate.upsert({
      where: { gymId_key_locale: { gymId, key, locale: dto.locale || 'en' } },
      update: { subject: dto.subject, bodyHtml: dto.bodyHtml, active: dto.active ?? true },
      create: { gymId, key, subject: dto.subject, bodyHtml: dto.bodyHtml, locale: dto.locale || 'en', active: dto.active ?? true },
    });
  }
  async updateTemplate(gymId: string, id: string, dto: { subject?: string; bodyHtml?: string; active?: boolean; locale?: string }) {
    return this.prisma.emailTemplate.updateMany({ where: { id, gymId }, data: dto });
  }

  async resolveGymByHost(hostname: string): Promise<string | null> {
    const d = await this.prisma.customDomain.findUnique({ where: { hostname } });
    return (d && ([DomainStatus.VERIFIED, DomainStatus.SSL_ACTIVE] as DomainStatus[]).includes(d.status)) ? d.gymId : null;
  }
  renderTemplate(tpl: string, vars: Record<string, string>): string {
    return tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => vars[k] ?? '');
  }
}
