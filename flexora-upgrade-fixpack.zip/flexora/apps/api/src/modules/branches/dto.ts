/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsOptional, IsString, MinLength, Matches } from 'class-validator';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';
export class CreateBranchDto {
  @IsString() @MinLength(2) name!: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() manager?: string;
}
export class UpdateBranchDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() manager?: string;
}
