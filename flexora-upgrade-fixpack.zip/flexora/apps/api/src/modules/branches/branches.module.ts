/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { BranchesService } from './branches.service';
import { BranchesController } from './branches.controller';
@Module({ imports: [JwtModule.register({})], controllers: [BranchesController], providers: [BranchesService] })
export class BranchesModule {}
