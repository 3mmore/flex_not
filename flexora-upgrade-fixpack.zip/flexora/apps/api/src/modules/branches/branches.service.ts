/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { CreateBranchDto, UpdateBranchDto } from './dto';
import { resolveBranchScope } from '../../common/branch-scope/branch-scope';

@Injectable()
export class BranchesService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * PHASE 4: `GET /branches` is what feeds every branch picker in the UI, so a
   * restricted (non-owner/manager) staff member must only ever receive their
   * own branch here. Hiding the picker in the web app is not enough — the API
   * itself no longer hands out the other branches' names/ids/stats.
   */
  async list(gymId: string, actor?: { role?: string | null; branchId?: string | null } | null) {
    const scope = resolveBranchScope(actor);
    const branches = await this.prisma.branch.findMany({
      where: {
        gymId,
        ...(scope.unrestricted ? {} : { id: scope.filterBranchId as string }),
      },
      orderBy: { createdAt: 'asc' },
    });
    return Promise.all(branches.map(async (b) => {
      const [members, staff, sales] = await this.prisma.$transaction([
        this.prisma.member.count({ where: { gymId, branchId: b.id } }),
        this.prisma.user.count({ where: { gymId, branchId: b.id } }),
        this.prisma.sale.aggregate({ where: { gymId, branchId: b.id }, _sum: { total: true } }),
      ]);
      return { ...b, stats: { members, staff, revenue: Number(sales._sum.total || 0) } };
    }));
  }
  async create(gymId: string, dto: CreateBranchDto) {
    const lic = await this.prisma.license.findUnique({ where: { gymId } });
    const count = await this.prisma.branch.count({ where: { gymId } });
    if (lic && count >= lic.branchesAllowed) {
      throw new BadRequestException('Branch limit reached for current license');
    }
    return this.prisma.branch.create({ data: { gymId, ...dto } });
  }
  async update(gymId: string, id: string, dto: UpdateBranchDto) {
    const b = await this.prisma.branch.findFirst({ where: { id, gymId } });
    if (!b) throw new NotFoundException('Branch not found');
    return this.prisma.branch.update({ where: { id, gymId }, data: dto });
  }
  async remove(gymId: string, id: string) {
    const b = await this.prisma.branch.findFirst({ where: { id, gymId } });
    if (!b) throw new NotFoundException('Branch not found');
    await this.prisma.branch.delete({ where: { id, gymId } });
    return { ok: true };
  }
}
