/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { BranchesService } from './branches.service';
import { CreateBranchDto, UpdateBranchDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('branches')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('branches')
export class BranchesController {
  constructor(private readonly svc: BranchesService) {}
  // PHASE 4: the acting user is passed through so the service can return only
  // the caller's own branch to restricted (non-owner/manager) staff.
  @Get() @Permissions('members.view')
  list(@GymId() gymId: string, @CurrentUser() user: { role?: string; branchId?: string | null }) {
    return this.svc.list(gymId, user);
  }
  @Post() @Permissions('staff.manage') @Audit('create', 'Branch')
  create(@GymId() gymId: string, @Body() dto: CreateBranchDto) { return this.svc.create(gymId, dto); }
  @Patch(':id') @Permissions('staff.manage') @Audit('update', 'Branch')
  update(@GymId() gymId: string, @Param('id') id: string, @Body() dto: UpdateBranchDto) { return this.svc.update(gymId, id, dto); }
  @Delete(':id') @Permissions('branches.manage') @Audit('delete', 'Branch')
  remove(@GymId() gymId: string, @Param('id') id: string) { return this.svc.remove(gymId, id); }
}
