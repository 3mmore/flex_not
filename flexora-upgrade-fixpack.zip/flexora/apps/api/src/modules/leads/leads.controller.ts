/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsDateString, IsEmail, IsOptional, IsString, MinLength, Matches, ValidateIf, IsEnum } from 'class-validator';
import { LeadsService } from './leads.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { LeadSource, LeadPriority, LeadStatus, FollowUpType } from '@prisma/client';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';

const THREE_PART_NAME = /^\S+\s+\S+\s+\S+.*$/;

class CreateLeadDto {
  @IsString() 
  @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' })
  name!: string;

  // P1: was @MinLength(10) — let any 10-char garbage through. Leads now use
  // the same Egyptian-mobile rule as every other phone in the system.
  @IsString() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) mobile!: string;

  @IsOptional() 
  @ValidateIf((o) => o.email && o.email !== '')
  @IsEmail() 
  email?: string;

  @IsOptional() @IsEnum(LeadSource) source?: LeadSource;
  @IsOptional() @IsEnum(LeadPriority) priority?: LeadPriority;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsString() interestedPlanId?: string;
  @IsOptional() @IsString() assignedTo?: string;
  // ROUND 13 (Phase 1): TenantGuard pins `branchId` into the body of a
  // restricted user who sends one — declaring it here keeps that pinned value
  // valid under `forbidNonWhitelisted` instead of 400-ing the create.
  @IsOptional() @IsString() branchId?: string;
}

class FollowUpDto {
  @IsEnum(FollowUpType) type!: FollowUpType;
  @IsOptional() @IsString() message?: string;
  @IsOptional() @IsDateString() scheduledAt?: Date;
  @IsOptional() @IsString() createdBy?: string;
}

class ConvertDto {
  @IsOptional() @IsString() planId?: string;
  @IsOptional() @IsString() branchId?: string;
}

@ApiTags('leads')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('leads')
@Controller('leads')
export class LeadsController {
  constructor(private readonly leads: LeadsService) {}

  @Permissions('members.create')
  @Get()
  list(
    @GymId() gymId: string,
    @Query('status') status?: LeadStatus,
    @Query('priority') priority?: LeadPriority,
    @Query('q') q?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.leads.list(gymId, {
      status, priority, q,
      page: page ? +page : undefined,
      limit: limit ? +limit : undefined,
    });
  }

  // ROUND 13 (Phase 1): the leads page is a first-class RECEPTION page —
  // the stats strip is part of their daily view.
  @Permissions('members.create')
  @Get('stats')
  stats(@GymId() gymId: string) {
    return this.leads.stats(gymId);
  }

  @Permissions('members.create')
  @Post()
  create(@GymId() gymId: string, @Body() dto: CreateLeadDto, @CurrentUser('sub') userId: string) {
    return this.leads.create(gymId, { ...dto, assignedTo: dto.assignedTo || userId });
  }

  @Permissions('members.create')
  @Get(':id')
  get(@GymId() gymId: string, @Param('id') id: string) {
    return this.leads.get(gymId, id);
  }

  @Permissions('members.create')
  @Post(':id/follow-up')
  addFollowUp(@GymId() gymId: string, @Param('id') id: string, @Body() dto: FollowUpDto) {
    return this.leads.addFollowUp(gymId, id, dto);
  }

  @Permissions('members.create')
  @Get(':id/follow-ups')
  listFollowUps(@GymId() gymId: string, @Param('id') id: string) {
    return this.leads.listFollowUps(gymId, id);
  }

  @Permissions('reports.view')
  @Post(':id/ai-follow-up')
  triggerAi(@GymId() gymId: string, @Param('id') id: string) {
    return this.leads.triggerAiFollowUp(gymId, id);
  }

  // ROUND 13 (Phase 1): converting a lead into a member is front-desk work
  // (the convert modal is on the Reception-visible leads page and needs the
  // plan picker from GET /plans). Branch safety: the lead lookup is pinned by
  // the Prisma branch-scope middleware and TenantGuard rewrites the body's
  // branchId, so a Reception user can only ever convert their own branch's
  // leads into their own branch.
  @Permissions('members.create')
  @Post(':id/convert')
  convert(@GymId() gymId: string, @Param('id') id: string, @Body() dto: ConvertDto) {
    return this.leads.convert(gymId, id, dto.planId, dto.branchId);
  }

  @Permissions('reports.view')
  @Post(':id/complete-trial')
  completeTrial(@GymId() gymId: string, @Param('id') id: string) {
    return this.leads.completeTrial(gymId, id);
  }
}
