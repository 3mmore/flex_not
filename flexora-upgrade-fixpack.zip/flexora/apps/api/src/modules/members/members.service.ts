/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, ConflictException, forwardRef, Inject, Injectable, NotFoundException, Optional, ServiceUnavailableException } from '@nestjs/common';
import { Prisma, MemberStatus, Gender } from '@prisma/client';
import { generatePortalCode, hashPortalCode } from '../../common/portal-code';
import { randomBytes, randomInt } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { CreateMemberDto, RegisterAndActivateMemberDto, ActivateMemberDto, RenewMemberDto, UpdateMemberDto } from './dto';
import { ProductEventEmitter } from '../../events/PRODUCT_EVENT_EMITTER';
import { EncryptionService } from '../../common/security/encryption.service';
import { bustMemberListCaches } from '../../common/cache/member-list-cache';
import { OwnerNotifyService } from '../notifications/owner-notify.service';
// ROUND 14 (security review, PHASE K1): the ONE membership-state decision.
import { MembershipStatus, membershipStatus, canTrain, trainingDenialReason } from './membership-status';
// ROUND 14 (security review, PHASE K4): recording the member-bound payment that
// activates a membership, INSIDE the activation transaction. BillingModule
// imports MembersModule, so the reference is resolved through forwardRef.
import { BillingService } from '../billing/billing.service';

const PLAN_MEMBER_LIMITS: Record<string, number> = { BASIC: 50, PRO: 500, ELITE: Number.POSITIVE_INFINITY };

@Injectable()
export class MembersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly realtime: RealtimeGateway,
    private readonly events?: ProductEventEmitter,
    @Optional() private readonly encryption?: EncryptionService,
    @Optional() private readonly ownerNotify?: OwnerNotifyService,
    @Inject(forwardRef(() => BillingService)) private readonly billing?: BillingService,
  ) {}

  private encryptSensitive(value?: string | null): string | undefined {
    if (!value) return value ?? undefined;
    return this.encryption ? this.encryption.encryptDeterministic(value) : value;
  }

  private decryptSensitive(value?: string | null): string | null | undefined {
    if (!value) return value;
    try { return this.encryption?.isEncrypted(value) ? this.encryption.decrypt(value) : value; } catch { return value; }
  }

  private exposeMember<T extends { mobile?: string | null; nationalId?: string | null; email?: string | null }>(member: T): T {
    return { ...member, mobile: this.decryptSensitive(member.mobile) as string | null | undefined, nationalId: this.decryptSensitive(member.nationalId) as string | null | undefined };
  }

  private async invalidate(gymId: string) {
    // BUG FIX (P0-5 "changes need F5"): the member list is cached in Redis for
    // 60s (see list()), keyed per page/limit/q/status/branchId. Mutations only
    // cleared the dashboard cache, so adds/edits/deletes kept serving the stale
    // list (and the unchanged body produced a 304, freezing the UI row set).
    // Clear every cached list variant for this gym so the next read is fresh.
    // Round 11: the same routine is needed by every other member writer (lead
    // conversion, CSV import), so it now lives in one shared helper.
    await bustMemberListCaches(this.redis, gymId);
  }

  private async cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    try { const hit = await this.redis.get(key); if (hit) return JSON.parse(hit) as T; } catch { /* redis down */ }
    const value = await fn();
    try { await this.redis.set(key, JSON.stringify(value), ttl); } catch { /* redis down */ }
    return value;
  }

  private addDays(d: Date, days: number) {
    const x = new Date(d);
    x.setDate(x.getDate() + days);
    return x;
  }

  private async assertBranch(gymId: string, branchId?: string | null) {
    if (!branchId) return;
    const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
    if (!branch) throw new BadRequestException('Invalid branch');
  }

  /**
   * ROUND 14 (security review, PHASE G2): a membership payment must be consumed
   * EXACTLY ONCE. Beyond existence/status/amount, the payment must:
   *   (a) belong to this gym,
   *   (b) be either unassigned (no invoice yet) or already tied to THIS member,
   *   (c) NOT already be linked to a membership/renewal invoice (reuse → 400),
   *   (d) cover the plan price.
   * The atomic consumption itself (marking the payment with the membership
   * invoice id) happens in createMembershipFinancials inside the renewal
   * transaction — see the updateMany guarded by `invoiceId: null` there.
   */
  private async validateMembershipPayment(gymId: string, expectedAmount: number, paymentId?: string, memberId?: string) {
    // ROUND 14 (security review, PHASE H1): a confirmed paymentId is the ONLY
    // accepted proof of payment — the transactionId path (validated only for
    // existence/amount, never consumed or member-bound) is removed.
    if (!paymentId) {
      throw new BadRequestException('Membership activation requires a confirmed paymentId');
    }
    const payment = await this.prisma.payment.findFirst({ where: { id: paymentId, gymId } });
    if (!payment) throw new BadRequestException('Payment not found for this gym');
    const status = String(payment.status || '').toUpperCase();
    if (!['PAID', 'COMPLETED', 'SUCCESS'].includes(status)) throw new BadRequestException('Payment is not confirmed');
    if (Number(payment.amount || 0) + 0.01 < expectedAmount) throw new BadRequestException('Payment amount does not cover membership price');
    // PHASE I1: only a genuine MANUAL_MEMBERSHIP payment may serve as membership
    // proof. A POS sale payment belongs to its sale invoice (never re-pointed
    // to a membership); ONLINE_RENEWAL payments are consumed by the webhook
    // path; OTHER payments are not membership payments at all.
    const purpose = String(payment.purpose || 'OTHER');
    if (purpose === 'POS_SALE') {
      throw new BadRequestException('A POS sale payment cannot be used as membership payment — record a manual payment for the member');
    }
    if (purpose !== 'MANUAL_MEMBERSHIP') {
      throw new BadRequestException('Only a manual membership payment recorded for this member can be used as membership payment');
    }
    // (b) PHASE I1: the payment must be bound to THIS member. A legacy
    // MANUAL_MEMBERSHIP row with a NULL memberId may be bound to the first
    // member that uses it — atomically, in createMembershipFinancials.
    if (memberId && payment.memberId && payment.memberId !== memberId) {
      throw new BadRequestException('This payment was recorded for another member');
    }
    // (c) PHASE H2: the explicit consumption marker — a payment that already
    // paid for a membership (create/renew/online webhook) is rejected outright,
    // regardless of invoice line text.
    if (payment.consumedAt) {
      if (memberId && payment.consumedByInvoiceId) {
        const consumedInv = await this.prisma.invoice.findFirst({ where: { id: payment.consumedByInvoiceId, gymId } });
        if (consumedInv?.memberId === memberId) {
          throw new BadRequestException('This payment was already used for a membership — it cannot be reused');
        }
      }
      throw new BadRequestException('This payment is already used by another member');
    }
    return { paymentId: payment.id, source: 'payment' as const };
  }

  private async createMembershipFinancials(gymId: string, memberId: string, plan: Prisma.PlanGetPayload<{}>, kind: 'membership_create' | 'membership_renewal', confirmedPaymentId?: string, txClient?: any) {
    const db: any = txClient ?? this.prisma;
    const amount = Number(plan.price || 0);
    const rand4 = () => randomBytes(2).toString('hex').toUpperCase();
    const invoiceNo = `MEM-${kind === 'membership_create' ? 'NEW' : 'REN'}-${Date.now().toString(36).toUpperCase()}-${rand4()}`;
    const receiptNo = `RCPT-${Date.now().toString(36).toUpperCase()}-${rand4()}`;
    const invoice = await db.invoice.create({
      data: {
        gymId,
        memberId,
        invoiceNo,
        status: 'PAID',
        subtotal: amount,
        total: amount,
        paid: amount,
        lines: { create: [{ description: `${plan.name} ${kind === 'membership_create' ? 'activation' : 'renewal'}`, qty: 1, unitPrice: amount, total: amount }] },
      },
    });
    let payment: any;
    if (confirmedPaymentId) {
      // ROUND 14 (Phase H2): consume the payment ATOMICALLY — the compare-and-
      // set is guarded by `consumedAt: null` and STAMPS the explicit marker
      // (consumedAt + consumedByInvoiceId) together with the re-link. A
      // concurrent renewal that already consumed it matches zero rows → clear
      // 400 and the whole renewal transaction rolls back. One payment, one
      // membership — detected by the marker, never by invoice text.
      // PHASE I1: the compare-and-set also requires a MANUAL_MEMBERSHIP
      // purpose, and binds the payment to THIS member when it is still
      // unbound (the legacy NULL-memberId case) — atomically.
      const existingPayment = await db.payment.findFirst({ where: { id: confirmedPaymentId, gymId } });
      const consumed = await db.payment.updateMany({
        where: { id: confirmedPaymentId, gymId, consumedAt: null, purpose: 'MANUAL_MEMBERSHIP' },
        data: {
          invoiceId: invoice.id,
          status: 'PAID',
          consumedAt: new Date(),
          consumedByInvoiceId: invoice.id,
          memberId: memberId ?? existingPayment?.memberId ?? null,
        },
      });
      if (consumed.count !== 1) {
        throw new BadRequestException('This payment was already consumed by another membership and cannot be reused');
      }
      payment = await db.payment.findFirst({ where: { id: confirmedPaymentId, gymId } });
    } else {
      payment = await db.payment.create({ data: { gymId, invoiceId: invoice.id, amount, method: 'CASH', status: 'PAID' } });
    }
    // FIX (member create/renew blocked by unique receipt per payment): the
    // manual-payment endpoint (/payments/manual) ALREADY creates a Receipt row
    // for the payment, and Receipt.paymentId is @unique — so unconditionally
    // creating a second receipt here failed every create/renew with a P2002
    // "unique constraint failed" (surfaced as 409 unique_constraint_violation).
    // Reuse the existing receipt (re-point it at the membership invoice) when
    // the payment already has one; only create a fresh receipt otherwise.
    const existingReceipt = confirmedPaymentId
      ? await db.receipt.findFirst({ where: { paymentId: payment.id } })
      : null;
    const receipt = existingReceipt
      ? await db.receipt.update({ where: { id: existingReceipt.id }, data: { invoiceId: invoice.id } })
      : await db.receipt.create({ data: { gymId, invoiceId: invoice.id, paymentId: payment.id, receiptNo } });
    /**
     * P4-5: the ledger used to show this row as "membership_create · MEM-NEW-…"
     * — an internal kind code plus a machine invoice number. Now the row keeps
     * the invoice number as a readable `reference` and gets a plain description
     * (what was paid for + which member), with memberId linked for drill-down.
     *
     * P0 FIX (double-counting revenue): when a confirmedPaymentId is provided
     * (meaning the payment was already recorded via /payments/manual), the
     * billing service already created a Transaction row for that money. Creating
     * a SECOND Transaction row here for the same amount double-counted revenue.
     * Instead, UPDATE the existing MANUAL_PAYMENT transaction to reference the
     * membership — one cash event = one ledger entry.
     *
     * FIX (round 8 review — fragile heuristic matching): the previous lookup
     * used `reference: { contains: 'MANUAL-' }, createdBy: payment.createdBy`
     * — a heuristic that could match the WRONG transaction when two manual
     * payments were processed by the same staff member within the same second.
     * Now we use the precise `paymentId` FK that billing.service.ts stores on
     * the Transaction at creation time. This is unambiguous regardless of
     * concurrency or how many payments the same staff member creates.
     */
    const payingMember = await db.member.findUnique({ where: { id: memberId }, select: { name: true } });
    const plainDescription = `${kind === 'membership_create' ? 'New membership' : 'Membership renewal'} — ${plan.name} — ${payingMember?.name || 'member'}`;

    if (confirmedPaymentId) {
      // A manual payment already created a Transaction row for this money.
      // Find it by the precise paymentId FK (set by billing.service.ts when
      // the manual payment's Transaction was created). This is unambiguous
      // regardless of concurrent payments by the same staff member.
      const existingTx = await db.transaction.findUnique({
        where: { paymentId: confirmedPaymentId },
      });
      if (existingTx) {
        await db.transaction.update({
          where: { id: existingTx.id },
          data: {
            category: kind,
            reference: invoiceNo,
            description: plainDescription,
            memberId,
          },
        });
      } else {
        // No existing transaction found for this payment (shouldn't happen in
        // normal flow — the manual-payment endpoint always creates one). Fall
        // back to creating a fresh ledger entry rather than silently dropping
        // the money from the accounting view.
        await db.transaction.create({ data: { gymId, type: 'INCOME', category: kind, reference: invoiceNo, description: plainDescription, amount, memberId, paymentId: confirmedPaymentId } });
      }
    } else {
      // No pre-existing payment — this is a fresh ledger entry
      await db.transaction.create({ data: { gymId, type: 'INCOME', category: kind, reference: invoiceNo, description: plainDescription, amount, memberId } });
    }
    return { invoice, payment, receipt };
  }

  /**
   * Builds a Prisma `where` fragment that pushes the status filter into SQL
   * (no in-memory filtering) so pagination counts stay correct.
   *  - active  : not frozen AND (SESSION sessionsLeft>0  OR  TIME expiry>=now)
   *  - expired : not frozen AND (SESSION sessionsLeft<=0 OR  TIME expiry<now)
   *  - frozen  : frozen
   */
  private statusWhere(status?: string): Prisma.MemberWhereInput | null {
    const now = new Date();
    if (!status || status === 'all') return null;
    if (status === 'frozen') return { frozen: true };
    if (status === 'active') {
      return {
        frozen: false,
        OR: [
          { plan: { type: 'SESSION' }, sessionsLeft: { gt: 0 } },
          { plan: { type: 'TIME' }, expiry: { gte: now } },
        ],
      };
    }
    if (status === 'expired') {
      return {
        frozen: false,
        OR: [
          { plan: { type: 'SESSION' }, sessionsLeft: { lte: 0 } },
          { plan: { type: 'TIME' }, expiry: { lt: now } },
          // ROUND 14 (security review, PHASE K1): a TIME member with NO expiry
          // is expired too (the shared helper says so), so the "expired" filter
          // must find it — SQL NULL never matches `lt: now`, so before this it
          // appeared in NEITHER the active nor the expired list.
          { plan: { type: 'TIME' }, expiry: null },
        ],
      };
    }
    // ROUND 14 (security review, PHASE K1): registered but not paid for yet.
    if (status === 'pending') return { status: MemberStatus.PENDING_PAYMENT };
    return null;
  }

  async findAll(gymId: string, page: number, limit: number, search?: string, status?: string, branchId?: string) {
    return this.list(gymId, page, limit, search, status, branchId);
  }

  async list(gymId: string, page: number, limit: number, q?: string, status?: string, branchId?: string) {
    return this.cached(`members:list:${gymId}:${page}:${limit}:${q || ''}:${status || ''}:${branchId || ''}`, 60, async () => this.computeList(gymId, page, limit, q, status, branchId));
  }

  private async computeList(gymId: string, page: number, limit: number, q?: string, status?: string, branchId?: string) {
    const and: Prisma.MemberWhereInput[] = [{ gymId }];
    // FIX (P2: members list has no branch filter): filter by branch when provided
    if (branchId) {
      and.push({ branchId });
    }
    if (q) {
      and.push({
        OR: [
          { name: { contains: q, mode: 'insensitive' } },
          { email: { contains: q, mode: 'insensitive' } },
          ...(this.encryptSensitive(q)
            ? [{ mobile: { equals: this.encryptSensitive(q) } }]
            : []),
        ],
      });
    }
    const sw = this.statusWhere(status);
    if (sw) and.push(sw);
    const where: Prisma.MemberWhereInput = { AND: and };

    const [items, total] = await this.prisma.$transaction([
      this.prisma.member.findMany({
        where,
        include: { plan: true, branch: true },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.member.count({ where }),
    ]);
    const decorated = items.map((m) => this.exposeMember({ ...m, status: this.computeStatus(m) }));
    return { items: decorated, total, page, limit };
  }

  /**
   * ROUND 14 (security review, PHASE K1): delegates to the SHARED helper
   * (membership-status.ts) so the members list, the attendance gate, the
   * portal, class booking and the device check-in can never disagree.
   *
   * The body that used to live here answered `active` for a TIME-plan member
   * with a NULL expiry — an open-ended membership rendered as a live one.
   */
  computeStatus(m: { frozen: boolean; sessionsLeft?: number; expiry?: Date | string | null; plan?: { type: string } | null; status?: string | null }): MembershipStatus {
    return membershipStatus(m);
  }

  async findOne(gymId: string, id: string) {
    return this.get(gymId, id);
  }

  async get(gymId: string, id: string) {
    const m = await this.prisma.member.findFirst({
      where: { id, gymId },
      include: { plan: true, branch: true, attendances: { orderBy: { at: 'desc' }, take: 50 } },
    });
    if (!m) throw new NotFoundException('Member not found');
    return this.exposeMember({ ...m, status: this.computeStatus(m) });
  }

  async findByCode(gymId: string, code: string) {
    return this.byCode(gymId, code);
  }

  async byCode(gymId: string, code: string) {
    const m = await this.prisma.member.findFirst({
      where: { gymId, code },
      include: { plan: true },
    });
    if (!m) throw new NotFoundException('Member not found');
    return this.exposeMember({ ...m, status: this.computeStatus(m) });
  }

  async create(gymId: string, dto: CreateMemberDto, actor?: { id?: string; name?: string; branchId?: string | null }) {
    const plan = await this.prisma.plan.findFirst({ where: { id: dto.planId, gymId } });
    if (!plan) throw new BadRequestException('Invalid plan');
    const encryptedMobile = this.encryptSensitive(dto.mobile);
    
    // Check for duplicate
    const dup = await this.prisma.member.findFirst({ where: { gymId, OR: [{ mobile: dto.mobile }, ...(encryptedMobile ? [{ mobile: encryptedMobile }] : [])] } });
    if (dup) {
      throw new ConflictException({
        code: 'MEMBER_ALREADY_EXISTS',
        translationKey: 'error_phone_exists',
        message: 'Mobile already registered',
      });
    }

    const [memberCount] = await Promise.all([
      this.prisma.member.count({ where: { gymId } }),
    ]);
    const sub = await this.prisma.subscription.findUnique({ where: { gymId } }).catch(() => null);
    const tier = sub?.tier || 'BASIC';
    const planLimit = PLAN_MEMBER_LIMITS[tier] ?? 50;
    // Member capacity is governed by the subscription TIER, never by
    // License.seats (that field is a STAFF seat count — see users.service.ts).
    // A previous version checked `memberCount >= licenseSeats.seats` here,
    // which capped every gym at 5 members regardless of tier and surfaced as
    // the unexplained English error "License member capacity reached".
    // The error carries code/translationKey + real numbers so the UI can show
    // a translated, specific message (see web src/lib/safe-error.ts).
    if (memberCount >= planLimit) {
      throw new BadRequestException({
        code: 'MEMBER_LIMIT_REACHED',
        translationKey: 'error_member_limit',
        message: `Member limit reached: this gym already has ${memberCount} members, which is the maximum for the ${tier} plan. Upgrade the plan to add more members.`,
        current: memberCount,
        limit: planLimit,
        tier,
      });
    }
    let branchId = dto.branchId;
    if (!branchId || branchId === '') {
      const branch = await this.prisma.branch.findFirst({ where: { gymId }, orderBy: { createdAt: 'asc' } });
      if (!branch) throw new BadRequestException('No branch exists for this gym — please create at least one branch first from the Branches page');
      branchId = branch.id;
    }
    await this.assertBranch(gymId, branchId);

    const start = dto.startDate ? new Date(dto.startDate) : new Date();
    let created: Prisma.MemberGetPayload<{}> | null = null;
    const invSlots = dto.invitationSlots !== undefined ? dto.invitationSlots : (plan.invitations ?? 5);
    
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const code = `FLEX-${String(randomInt(0, 1000000)).padStart(6, '0')}`;
      try {
        created = await this.prisma.member.create({
      data: {
        gymId,
        planId: plan.id,
        branchId,
        code,
        name: dto.name,
        mobile: this.encryptSensitive(dto.mobile) || dto.mobile,
        gender: dto.gender ?? Gender.MALE,
        dob: dto.dob ? new Date(dto.dob) : null,
        nationalId: this.encryptSensitive(dto.nationalId),
        address: dto.address,
        notes: dto.notes,
        vip: dto.vip ?? false,
        startDate: start,
        // PHASE J2: the member is REGISTERED, not activated. No expiry, no
        // sessions and no activatedAt until a payment bound to THIS member is
        // booked by renew() — so an unpaid member cannot train (see
        // attendance.service.status(), which refuses any non-ACTIVE member).
        expiry: null,
        sessionsLeft: plan.type === 'SESSION' ? 0 : undefined,
        status: MemberStatus.PENDING_PAYMENT,
        paymentId: null,
        activatedAt: null,
        invitationSlots: invSlots,
        maxFreezes: plan.maxFreezes ?? 0,
        freezeDaysLeft: plan.freezeDays ?? 0,
      },
        });
        break;
      } catch (e: unknown) {
        if ((e as Record<string, any>)?.code !== 'P2002' || attempt === 4) {
          if ((e as Record<string, any>)?.code === 'P2002' && (e as any).meta?.target?.includes('mobile')) {
            throw new ConflictException({
              code: 'MEMBER_ALREADY_EXISTS',
              translationKey: 'error_phone_exists',
              message: 'Mobile already registered',
            });
          }
          throw e;
        }
      }
    }
    if (!created) throw new BadRequestException('Unable to generate unique member code');
    // ...
    await this.prisma.invitationSlot.upsert({
      where: { gymId_memberId: { gymId, memberId: created.id } },
      update: { totalSlots: invSlots },
      create: { gymId, memberId: created.id, totalSlots: invSlots, usedSlots: 0 },
    });
    // PHASE J2: NO membership financials are booked here any more. The member
    // is registered as PENDING_PAYMENT — not activated — and is activated by
    // `POST /members/:id/renew` with a payment that is bound to THIS member
    // (see renew(): the first activation books a `membership_create` financial).
    await this.invalidate(gymId);
    this.realtime.emitToGym(gymId, 'new_member', { memberName: created.name, plan: plan.name });
    await this.events?.emitEvent({ type: 'member.created', tenantId: gymId, branchId: created.branchId, entityId: created.id, payload: { memberId: created.id, planId: plan.id }, source: 'api' });
    // FIX (P3: notifications lack actor and branch context): include the
    // actual staff member's name and the branch where this happened.
    try {
      const branch = created.branchId
        ? await this.prisma.branch.findUnique({ where: { id: created.branchId }, select: { name: true } }).catch(() => null)
        : null;
      await this.ownerNotify?.notifyNewMember(gymId, {
        memberName: created.name,
        mobile: dto.mobile ?? '',
        planName: plan?.name ?? 'غير محدد',
        staffName: actor?.name || 'موظف',
        branchName: branch?.name || undefined,
      } as any);
    } catch {}
    return this.exposeMember(created);
  }


  /**
   * ROUND 14 (security review, PHASE K4) — register a member, take the payment
   * and activate the membership in ONE transaction.
   *
   * WHY: the front-desk flow used to be three HTTP calls (POST /members →
   * POST /payments/manual → POST /members/:id/renew). Each one committed on its
   * own, so a failure between them left real damage behind — a registered
   * member with no payment (unpaid but listed, and a duplicate-phone trap for
   * the next attempt), or a payment with no membership (money taken, no access).
   * The browser could also be closed mid-flow.
   *
   * Now the three steps share ONE serializable transaction: the member row, the
   * member-bound payment, the membership invoice/receipt/ledger entry and the
   * activation all commit together, or nothing commits at all.
   */
  async registerAndActivate(
    gymId: string,
    dto: RegisterAndActivateMemberDto,
    actor?: { id?: string; name?: string; branchId?: string | null },
  ) {
    const plan = await this.prisma.plan.findFirst({ where: { id: dto.planId, gymId } });
    if (!plan) throw new BadRequestException('Invalid plan');

    // Same pre-flight as create(): the duplicate and capacity checks run BEFORE
    // the transaction so a rejection is a clean 400/409 and not a rolled-back
    // transaction that still burned a member code.
    const encryptedMobile = this.encryptSensitive(dto.mobile);
    const dup = await this.prisma.member.findFirst({
      where: { gymId, OR: [{ mobile: dto.mobile }, ...(encryptedMobile ? [{ mobile: encryptedMobile }] : [])] },
    });
    if (dup) {
      throw new ConflictException({
        code: 'MEMBER_ALREADY_EXISTS',
        translationKey: 'error_phone_exists',
        message: 'Mobile already registered',
      });
    }
    const memberCount = await this.prisma.member.count({ where: { gymId } });
    const sub = await this.prisma.subscription.findUnique({ where: { gymId } }).catch(() => null);
    const tier = sub?.tier || 'BASIC';
    const planLimit = PLAN_MEMBER_LIMITS[tier] ?? 50;
    if (memberCount >= planLimit) {
      throw new BadRequestException({
        code: 'MEMBER_LIMIT_REACHED',
        translationKey: 'error_member_limit',
        message: `Member limit reached: this gym already has ${memberCount} members, which is the maximum for the ${tier} plan. Upgrade the plan to add more members.`,
        current: memberCount,
        limit: planLimit,
        tier,
      });
    }
    let branchId = dto.branchId;
    if (!branchId || branchId === '') {
      const branch = await this.prisma.branch.findFirst({ where: { gymId }, orderBy: { createdAt: 'asc' } });
      if (!branch) throw new BadRequestException('No branch exists for this gym — please create at least one branch first from the Branches page');
      branchId = branch.id;
    }
    await this.assertBranch(gymId, branchId);

    const { amount, method } = this.resolveActivationAmount(dto.amount, dto.method, plan);
    const start = dto.startDate ? new Date(dto.startDate) : new Date();
    const invSlots = dto.invitationSlots !== undefined ? dto.invitationSlots : (plan.invitations ?? 5);
    const userId = actor?.id || 'staff';

    // PHASE K4: withTenant() — NOT a bare $transaction(). The Prisma extension
    // sets the in-interactive-transaction flag only for withTenant(); a bare
    // $transaction() leaves it unset, so every tx.* call inside would be
    // re-wrapped in its OWN $transaction([set_config, query]) on a different
    // connection — which would commit independently and defeat the whole point
    // of doing this in one transaction. (Same mechanism the Paymob webhook
    // claim/apply uses, whose rollback is live-verified.)
    const activated = await this.runActivationTransaction(gymId, async (tx) => {
      // 1 — the member is registered as PENDING_PAYMENT (no expiry, no sessions)
      const code = await this.nextMemberCode(tx, gymId);
      const member = await tx.member.create({
        data: {
          gymId,
          planId: plan.id,
          branchId,
          code,
          name: dto.name,
          mobile: this.encryptSensitive(dto.mobile) || dto.mobile,
          gender: dto.gender ?? Gender.MALE,
          dob: dto.dob ? new Date(dto.dob) : null,
          nationalId: this.encryptSensitive(dto.nationalId),
          address: dto.address,
          notes: dto.notes,
          vip: dto.vip ?? false,
          startDate: start,
          expiry: null,
          sessionsLeft: plan.type === 'SESSION' ? 0 : undefined,
          status: MemberStatus.PENDING_PAYMENT,
          paymentId: null,
          activatedAt: null,
          invitationSlots: invSlots,
          maxFreezes: plan.maxFreezes ?? 0,
          freezeDaysLeft: plan.freezeDays ?? 0,
        },
      });

      // 2 — the payment that pays for it, bound to THIS member, in the SAME
      //     transaction (the billing service joins an outer tx since K4).
      const { payment } = await this.payments().createManualPayment(
        gymId,
        userId,
        { amount, method, memberId: member.id, memberName: member.name, notes: dto.notes },
        tx,
      );

      // 3 — the membership financials (invoice + receipt + the single ledger
      //     entry) and the atomic consumption of that payment.
      await this.createMembershipFinancials(gymId, member.id, plan, 'membership_create', payment.id, tx);

      // 4 — activation: expiry / sessions / ACTIVE / activatedAt.
      const updated = await tx.member.update({
        where: { id: member.id },
        data: {
          frozen: false,
          startDate: start,
          expiry: plan.type === 'TIME' ? this.addDays(start, plan.days || 0) : null,
          sessionsLeft: plan.type === 'SESSION' ? (plan.sessions || 0) : undefined,
          status: MemberStatus.ACTIVE,
          paymentId: payment.id,
          activatedAt: new Date(),
          invitationSlots: invSlots,
          maxFreezes: plan.maxFreezes ?? 0,
          freezeDaysLeft: plan.freezeDays ?? 0,
          planId: plan.id,
        },
      });
      await tx.invitationSlot.upsert({
        where: { gymId_memberId: { gymId, memberId: member.id } },
        update: { totalSlots: invSlots },
        create: { gymId, memberId: member.id, totalSlots: invSlots, usedSlots: 0 },
      });
      return updated;
    });

    await this.invalidate(gymId);
    this.realtime.emitToGym(gymId, 'new_member', { memberName: activated.name, plan: plan.name });
    await this.events?.emitEvent({ type: 'member.created', tenantId: gymId, branchId: activated.branchId, entityId: activated.id, payload: { memberId: activated.id, planId: plan.id, activated: true }, source: 'api' });
    try {
      const branch = activated.branchId
        ? await this.prisma.branch.findUnique({ where: { id: activated.branchId }, select: { name: true } }).catch(() => null)
        : null;
      await this.ownerNotify?.notifyNewMember(gymId, {
        memberName: activated.name,
        mobile: dto.mobile ?? '',
        planName: plan?.name ?? 'غير محدد',
        staffName: actor?.name || 'موظف',
        branchName: branch?.name || undefined,
      } as any);
    } catch {}
    return this.exposeMember({ ...activated, status: this.computeStatus({ ...activated, plan }) });
  }

  /**
   * PHASE K4 — run an activation inside ONE tenant transaction.
   *
   * The activation runs at SERIALIZABLE so two desks cannot activate the same
   * member (or the same payment) at once. The loser of that race is ABORTED by
   * Postgres — it is not a failure of the product: nothing was written, and the
   * whole point of the transaction is that nothing is. Surfacing that abort as
   * a 500 tells the desk "the server broke"; it did not, and a 500 here would
   * also be indistinguishable from a real bug in monitoring. A lost race is a
   * CONFLICT: refresh and, if the member is not there, submit again.
   */
  private async runActivationTransaction<T>(
    gymId: string,
    fn: (tx: Prisma.TransactionClient) => Promise<T>,
  ): Promise<T> {
    try {
      return await this.prisma.withTenant(gymId, fn, { isolationLevel: 'Serializable' as any });
    } catch (e: any) {
      if (this.isSerializationAbort(e)) {
        throw new ConflictException(
          'Someone was registering this member at the same moment, so this submission was rolled back cleanly (nothing was created). Refresh — if the member is not listed yet, submit again.',
        );
      }
      throw e;
    }
  }

  /** Postgres aborted the transaction because another one committed first. */
  private isSerializationAbort(e: any): boolean {
    if (e?.code === 'P2034' || e?.code === '40001' || e?.code === '40P01') return true;
    return /write conflict|deadlock|could not serialize|serialization failure|concurrent update/i.test(
      String(e?.message || ''),
    );
  }

  /**
   * ROUND 14 (security review, PHASE K4) — take the payment that ACTIVATES an
   * already-registered member (a converted lead, a member imported as pending,
   * or one registered with "pay later") in ONE transaction.
   *
   * The lead-conversion "Collect payment" action is the main caller: before
   * this, it had to be two calls (pay, then renew) and a failure between them
   * left a payment that paid for nothing.
   */
  async activateWithPayment(
    gymId: string,
    id: string,
    dto: ActivateMemberDto,
    actor?: { id?: string; name?: string; branchId?: string | null },
  ) {
    const m = await this.prisma.member.findFirst({ where: { id, gymId }, include: { plan: true } });
    if (!m || !m.plan) throw new NotFoundException('Member/plan not found');

    // Refuse to take money for a membership that is already live — extending a
    // live membership is renew(), which has its own same-day duplicate guard.
    if (canTrain(m)) {
      throw new ConflictException({
        code: 'MEMBER_ALREADY_ACTIVE',
        message: 'This membership is already active — use Renew to extend it',
      });
    }

    let targetPlan = m.plan;
    if (dto.planId && dto.planId !== m.plan.id) {
      const requestedPlan = await this.prisma.plan.findFirst({ where: { id: dto.planId, gymId, active: true } });
      if (!requestedPlan) throw new BadRequestException('Invalid or inactive plan');
      targetPlan = requestedPlan;
    }
    const { amount, method } = this.resolveActivationAmount(dto.amount, dto.method, targetPlan);
    const isFirstActivation = !m.activatedAt || m.status === MemberStatus.PENDING_PAYMENT;
    const start = new Date();
    const invSlots = dto.invitationSlots !== undefined ? dto.invitationSlots : (targetPlan.invitations ?? 5);
    const userId = actor?.id || 'staff';

    // PHASE K4: withTenant() for the same reason as registerAndActivate above —
    // one connection, one transaction, or nothing.
    const activated = await this.runActivationTransaction(gymId, async (tx) => {
      const { payment } = await this.payments().createManualPayment(
        gymId,
        userId,
        { amount, method, memberId: m.id, memberName: m.name },
        tx,
      );
      await this.createMembershipFinancials(
        gymId,
        m.id,
        targetPlan,
        isFirstActivation ? 'membership_create' : 'membership_renewal',
        payment.id,
        tx,
      );
      const updated = await tx.member.update({
        where: { id: m.id },
        data: {
          frozen: false,
          startDate: start,
          expiry: targetPlan.type === 'TIME' ? this.addDays(start, targetPlan.days || 0) : null,
          sessionsLeft: targetPlan.type === 'SESSION' ? (targetPlan.sessions || 0) : undefined,
          status: MemberStatus.ACTIVE,
          paymentId: payment.id,
          activatedAt: new Date(),
          invitationSlots: invSlots,
          maxFreezes: targetPlan.maxFreezes ?? 0,
          freezeDaysLeft: targetPlan.freezeDays ?? 0,
          planId: targetPlan.id,
        },
      });
      await tx.invitationSlot.upsert({
        where: { gymId_memberId: { gymId, memberId: m.id } },
        update: { totalSlots: invSlots },
        create: { gymId, memberId: m.id, totalSlots: invSlots, usedSlots: 0 },
      });
      return updated;
    });

    await this.invalidate(gymId);
    await this.events?.emitEvent({ type: 'member.renewed', tenantId: gymId, branchId: activated.branchId, entityId: activated.id, payload: { memberId: activated.id, activated: true }, source: 'api' });
    return this.exposeMember({ ...activated, status: this.computeStatus({ ...activated, plan: targetPlan }) });
  }

  /**
   * The billing service is injected through forwardRef (BillingModule imports
   * MembersModule). If it is ever unresolvable the activation paths must fail
   * loudly and take NO money — never silently skip the payment step.
   */
  private payments(): BillingService {
    if (!this.billing) {
      throw new ServiceUnavailableException('Payment service unavailable — membership activation aborted, no payment was taken');
    }
    return this.billing;
  }

  /** Shared money validation for the two activation paths above. */
  private resolveActivationAmount(rawAmount: unknown, rawMethod: unknown, plan: { price?: unknown }) {
    const price = Number((plan as any)?.price || 0);
    const amount = rawAmount != null ? Number(rawAmount) : price;
    if (!Number.isFinite(amount) || amount <= 0) {
      throw new BadRequestException('Payment amount must be greater than zero');
    }
    if (amount + 0.01 < price) {
      throw new BadRequestException(`Payment amount does not cover membership price (${price})`);
    }
    const method = String(rawMethod || 'CASH').trim().toUpperCase() || 'CASH';
    if (method.length > 40) throw new BadRequestException('A valid payment method is required');
    return { amount, method };
  }

  /**
   * A member code that is free BEFORE it is used — inside a transaction a
   * unique-violation cannot be caught and retried (Postgres leaves the
   * transaction aborted), so the old catch-P2002 loop is unusable here.
   */
  private async nextMemberCode(tx: any, gymId: string): Promise<string> {
    for (let attempt = 0; attempt < 12; attempt += 1) {
      const code = `FLEX-${String(randomInt(0, 1000000)).padStart(6, '0')}`;
      const clash = await tx.member.findFirst({ where: { gymId, code }, select: { id: true } });
      if (!clash) return code;
    }
    throw new BadRequestException('Unable to generate unique member code');
  }

  async update(gymId: string, id: string, dto: UpdateMemberDto) {
    await this.get(gymId, id);
    const data: Prisma.MemberUpdateInput = {
      name: dto.name,
      email: dto.email,
      address: dto.address,
      notes: dto.notes,
      vip: dto.vip,
      frozen: dto.frozen,
      status: dto.status,
    };
    if (dto.mobile) data.mobile = this.encryptSensitive(dto.mobile);
    if (dto.nationalId) data.nationalId = this.encryptSensitive(dto.nationalId);
    if (dto.dob) data.dob = new Date(dto.dob);
    if (dto.planId) {
      const plan = await this.prisma.plan.findFirst({ where: { id: dto.planId, gymId } });
      if (!plan) throw new BadRequestException('Invalid plan');
      data.plan = { connect: { id: dto.planId } };
    }
    if (dto.branchId) {
      await this.assertBranch(gymId, dto.branchId);
      data.branch = { connect: { id: dto.branchId } };
    }
    // gymId-safe: id already tenant-scoped above by get(gymId, id)
    const updated = await this.prisma.member.update({ where: { id }, data });
    await this.invalidate(gymId);
    await this.events?.emitEvent({ type: 'member.updated', tenantId: gymId, branchId: updated.branchId, entityId: updated.id, payload: { memberId: updated.id }, source: 'api' });
    return this.exposeMember(updated);
  }

  // --------------------------------------------------------------------------
  // ROUND 14 (security review, PHASE F1) — member renewal REQUESTS.
  // The portal "Renew" action creates a PENDING request; the membership is
  // extended ONLY by confirmRenewalRequest (the normal paid renewal flow) or
  // by the verified provider webhook (applyPaidRenewal). Nothing here is free.
  // --------------------------------------------------------------------------

  /** Staff screen: the gym's renewal requests (members.edit). */
  async listRenewalRequests(gymId: string, status?: string) {
    const where: Record<string, unknown> = { gymId };
    if (status && status !== 'all') where.status = status;
    return this.prisma.renewalRequest.findMany({
      where,
      include: {
        member: { select: { id: true, name: true, mobile: true, expiry: true, sessionsLeft: true, plan: { select: { name: true } } } },
        plan: { select: { id: true, name: true, price: true, type: true, days: true, sessions: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  /**
   * Front-desk confirmation: completes the NORMAL renewal flow
   * (members.renew with a confirmed payment) — the only staff path that
   * extends the membership — then marks the request CONFIRMED.
   */
  async confirmRenewalRequest(gymId: string, requestId: string, dto: { paymentId?: string }, actor?: { id?: string; name?: string }) {
    const request = await this.prisma.renewalRequest.findFirst({
      where: { id: requestId, gymId },
      include: { member: true, plan: true },
    });
    if (!request) throw new NotFoundException('Renewal request not found');
    if (request.status !== 'PENDING') {
      throw new BadRequestException(`This request is ${request.status.toLowerCase()} — only pending requests can be confirmed`);
    }
    if (!dto?.paymentId) throw new BadRequestException('A confirmed payment is required');
    // the normal renewal flow — extends the membership exactly once, ON THE
    // REQUESTED PLAN (ROUND 14 Phase G2)
    const renewed = await this.renew(gymId, request.memberId, { paymentId: dto.paymentId, planId: request.planId } as any, actor);
    const invoice = await this.prisma.invoice.findFirst({
      where: { gymId, memberId: request.memberId, status: 'PAID', createdAt: { gte: request.requestedAt }, lines: { some: { description: { contains: 'renewal', mode: 'insensitive' } } } },
      orderBy: { createdAt: 'desc' },
    });
    const updated = await this.prisma.renewalRequest.update({
      where: { id: request.id },
      data: { status: 'CONFIRMED', decidedAt: new Date(), decidedBy: actor?.id || actor?.name || 'staff', invoiceId: invoice?.id ?? null },
    });
    return { request: updated, member: renewed, invoice };
  }

  /** Cancel an open renewal request (front desk). */
  async cancelRenewalRequest(gymId: string, requestId: string, actor?: { id?: string; name?: string }) {
    const request = await this.prisma.renewalRequest.findFirst({ where: { id: requestId, gymId } });
    if (!request) throw new NotFoundException('Renewal request not found');
    if (!['PENDING', 'CHECKOUT'].includes(request.status)) {
      throw new BadRequestException(`This request is ${request.status.toLowerCase()} — only open requests can be cancelled`);
    }
    return this.prisma.renewalRequest.update({
      where: { id: request.id },
      data: { status: 'CANCELLED', decidedAt: new Date(), decidedBy: actor?.id || actor?.name || 'staff' },
    });
  }

  /**
   * The verified-webhook path: extends the membership for an ONLINE payment.
   * Idempotency is enforced by the caller (the RenewalRequest status
   * transition — one extension per payment); the amount is bound to the plan
   * price and the member/plan are bound to the request row.
   */
  /** Staff screen: the gym's renewal requests (members.edit). */
  async applyPaidRenewal(gymId: string, memberId: string, planId: string, opts: { amount: number; providerRef?: string; method?: string }, txClient?: any) {
    // ROUND 14 (Phase G1): tx-aware — the verified-webhook path calls this
    // INSIDE prisma.withTenant(...); the RLS middleware skips its own wrapping
    // there, so the tenant-scoped lookups must run on the caller's tx client
    // (the same pattern the subscription webhook uses for ingestProviderEvent).
    const db: any = txClient ?? this.prisma;
    const plan = await db.plan.findFirst({ where: { id: planId, gymId, active: true } });
    if (!plan) throw new NotFoundException('Plan not found');
    if (Math.abs(Number(plan.price || 0) - Number(opts.amount)) > 0.01) {
      throw new BadRequestException('Paid amount does not match the plan price');
    }
    const member = await db.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new NotFoundException('Member not found');
    const amount = Number(plan.price || 0);
    const now = new Date();
    const base = member.expiry && +new Date(member.expiry) > +now ? new Date(member.expiry) : now;
    const addDays = (d: Date, days: number) => { const x = new Date(d); x.setDate(x.getDate() + days); return x; };
    const newExpiry = plan.type === 'TIME' ? addDays(base, plan.days || 0) : member.expiry;
    const sessionsLeft = plan.type === 'SESSION' ? (member.sessionsLeft ?? 0) + (plan.sessions || 0) : member.sessionsLeft;
    const rand4 = () => randomBytes(2).toString('hex').toUpperCase();
    const invoiceNo = `MEM-REN-${Date.now().toString(36).toUpperCase()}-${rand4()}`;
    const receiptNo = `RCPT-${Date.now().toString(36).toUpperCase()}-${rand4()}`;
    // ROUND 14 (Phase G1): when called from the verified webhook, the writes
    // run on the CALLER's transaction (withTenant) — a nested $transaction here
    // would open a second connection without the tenant context and RLS would
    // block every write. Standalone calls still get their own transaction.
    const writes = async (db: any) => {
      const renewed = await db.member.update({
        where: { id: member.id },
        data: {
          frozen: false,
          status: 'ACTIVE',
          expiry: newExpiry,
          sessionsLeft,
          planId: plan.id,
        },
      });
      const invoice = await db.invoice.create({
        data: {
          gymId, memberId, invoiceNo, status: 'PAID', subtotal: amount, total: amount, paid: amount,
          lines: { create: [{ description: `${plan.name} renewal (online)`, qty: 1, unitPrice: amount, total: amount }] },
        },
      });
      const payment = await db.payment.create({
        data: {
          gymId, invoiceId: invoice.id, amount, method: opts.method || 'ONLINE', status: 'PAID', providerRef: opts.providerRef || null,
          // PHASE H2: the online path consumes the payment exactly once too —
          // stamp the explicit marker at creation.
          consumedAt: new Date(),
          consumedByInvoiceId: invoice.id,
          // PHASE I1: an online provider payment is an ONLINE_RENEWAL payment
          // bound to this member.
          purpose: 'ONLINE_RENEWAL',
          memberId,
        },
      });
      await db.receipt.create({ data: { gymId, invoiceId: invoice.id, paymentId: payment.id, receiptNo, channel: 'ONLINE' } });
      await db.transaction.create({
        data: {
          gymId, type: 'INCOME', category: 'membership_renewal', amount, paymentId: payment.id,
          reference: invoiceNo,
          description: `Membership renewal — ${plan.name} — ${member.name}`,
        },
      });
      return { member: renewed, invoice, payment };
    };
    return txClient ? writes(txClient) : this.prisma.$transaction((tx) => writes(tx));
  }

  /**
   * ROUND 14 (security review, PHASE E): staff-generated one-time member
   * access code — the fallback login path when the gym has no WhatsApp
   * channel. 6 digits, valid 15 minutes, single use, returned ONCE (shown on
   * the staff screen), stored HASHED (MemberOtp — the same row the portal's
   * verify-otp accepts), audit-logged by the controller's @Audit decorator,
   * rate-limited per member per hour. The member types it on /portal/login.
   */
  async generateAccessCode(gymId: string, id: string, actor?: { id?: string; name?: string }) {
    const member = await this.prisma.member.findFirst({ where: { id, gymId } });
    if (!member) throw new NotFoundException('Member not found');

    // Rate limit: max 5 codes per member per hour (Redis; fail closed).
    const rlKey = `accesscode:rate:${member.id}`;
    try {
      const count = await this.redis.client.incr(rlKey);
      if (count === 1) await this.redis.client.expire(rlKey, 3600);
      if (count > 5) {
        throw new BadRequestException({
          code: 'ACCESS_CODE_RATE_LIMITED',
          translationKey: 'access_code_rate_limited',
          message: 'Too many access codes for this member. Try again later.',
        });
      }
    } catch (e) {
      if (e instanceof BadRequestException) throw e;
      throw new ServiceUnavailableException('Service temporarily unavailable. Please try again in a few minutes.');
    }

    // One live code per member: invalidate outstanding codes first.
    await this.prisma.memberOtp.updateMany({
      where: { memberId: member.id, used: false },
      data: { used: true },
    });
    const code = generatePortalCode();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    await this.prisma.memberOtp.create({
      data: {
        gymId: member.gymId,
        memberId: member.id,
        codeHash: hashPortalCode(member.id, code),
        expiresAt,
      },
    });
    return {
      code, // shown once — never stored in plaintext anywhere
      expiresAt,
      generatedBy: actor?.name || actor?.id || 'staff',
      member: { id: member.id, name: member.name, mobile: member.mobile },
    };
  }

  async renew(gymId: string, id: string, dto?: RenewMemberDto, actor?: { id?: string; name?: string; branchId?: string | null }) {
    const m = await this.prisma.member.findFirst({ where: { id, gymId }, include: { plan: true } });
    if (!m || !m.plan) throw new NotFoundException('Member/plan not found');

    // Renew onto a different plan if requested (must belong to the same gym); otherwise keep the current plan.
    let targetPlan = m.plan;
    if (dto?.planId && dto.planId !== m.plan.id) {
      const requestedPlan = await this.prisma.plan.findFirst({ where: { id: dto.planId, gymId, active: true } });
      if (!requestedPlan) throw new BadRequestException('Invalid or inactive plan');
      targetPlan = requestedPlan;
    }

    // ROUND 14 (Phase G2): the payment is validated against THIS member (a
    // payment already consumed by a membership, or tied to another member, is
    // rejected with a clear 400) and consumed atomically below.
    const paymentConfirmation = await this.validateMembershipPayment(gymId, Number(targetPlan.price || 0), dto?.paymentId, id);
    // PHASE J2: a member registered by POST /members is PENDING_PAYMENT until
    // it is paid for, so the FIRST paid activation books a `membership_create`
    // financial (an activation, not a renewal). Every later one is a renewal.
    const isFirstActivation = !m.activatedAt || m.status === MemberStatus.PENDING_PAYMENT;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const duplicateRenewal = isFirstActivation
      ? null
      : await this.prisma.invoice.findFirst({
        where: { gymId, memberId: id, createdAt: { gte: today }, lines: { some: { description: { contains: 'renewal', mode: 'insensitive' } } } },
      });
    if (duplicateRenewal) throw new BadRequestException('Member already renewed today');
    const start = new Date();
    const invSlots = dto?.invitationSlots !== undefined ? dto.invitationSlots : (targetPlan.invitations ?? 5);

    // ROUND 14 (Phase G2): the financials (including the ATOMIC payment
    // consumption), the extension and the slot update run in ONE transaction —
    // a payment that loses the consumption race rolls the whole renewal back.
    const renewed = await this.prisma.$transaction(async (tx) => {
      // PHASE J2: the first paid activation of a registered (PENDING_PAYMENT)
      // member books `membership_create`; any later payment is a renewal.
      await this.createMembershipFinancials(gymId, id, targetPlan, isFirstActivation ? 'membership_create' : 'membership_renewal', paymentConfirmation.paymentId, tx);
      // gymId-safe: id already tenant-scoped above by findFirst
      const updated = await tx.member.update({
        where: { id },
        data: {
          frozen: false,
          startDate: start,
          expiry: targetPlan.type === 'TIME' ? this.addDays(start, targetPlan.days || 0) : null,
          sessionsLeft: targetPlan.type === 'SESSION' ? (targetPlan.sessions || 0) : undefined,
          status: MemberStatus.ACTIVE,
          paymentId: paymentConfirmation.paymentId,
          activatedAt: new Date(),
          invitationSlots: invSlots,
          maxFreezes: targetPlan.maxFreezes ?? 0,
          freezeDaysLeft: targetPlan.freezeDays ?? 0,
          planId: targetPlan.id,
        },
      });
      await tx.invitationSlot.upsert({
        where: { gymId_memberId: { gymId, memberId: id } },
        update: { totalSlots: invSlots },
        create: { gymId, memberId: id, totalSlots: invSlots, usedSlots: 0 },
      });
      return updated;
    });
    await this.invalidate(gymId);
    await this.events?.emitEvent({ type: 'member.renewed', tenantId: gymId, branchId: renewed.branchId, entityId: renewed.id, payload: { memberId: renewed.id }, source: 'api' });
    // FIX (P3: renewal notification shows OLD plan + lacks actor/branch):
    // Use targetPlan (the plan they actually renewed onto) instead of m.plan
    // (their previous plan). Include the branch and staff member who did it.
    try {
      const branch = renewed.branchId
        ? await this.prisma.branch.findUnique({ where: { id: renewed.branchId }, select: { name: true } }).catch(() => null)
        : null;
      await this.ownerNotify?.notifyRenewal(gymId, {
        memberName: renewed.name,
        planName: targetPlan?.name ?? 'غير محدد',
        amount: Number(targetPlan?.price ?? 0),
        staffName: actor?.name || 'موظف',
        branchName: branch?.name || undefined,
      } as any);
    } catch {}
    return this.exposeMember(renewed);
  }

  async freeze(gymId: string, id: string, frozen: boolean) {
    await this.get(gymId, id);
    // gymId-safe: id already tenant-scoped above by get(gymId, id)
    const updated = await this.prisma.member.update({ where: { id }, data: { frozen } });
    await this.invalidate(gymId);
    return updated;
  }

  async remove(gymId: string, id: string, actor?: { id?: string; name?: string }) {
    const member = await this.get(gymId, id);
    await this.prisma.member.delete({ where: { id, gymId } });
    // BUG FIX (P0-5): remove() was the ONE mutation that never invalidated the
    // 60s Redis member-list cache, so a deleted member kept showing up until
    // the TTL expired (the famous "delete needs F5" bug).
    await this.invalidate(gymId);
    await this.events?.emitEvent({ type: 'member.deleted', tenantId: gymId, entityId: id, payload: { memberId: id }, source: 'api' });
    try {
      const mobile = member.mobile
        ? (this.encryption?.isEncrypted(member.mobile as string) ? this.encryption.decrypt(member.mobile as string) : member.mobile as string)
        : 'غير متاح';
      await this.ownerNotify?.notifyMemberDeleted(gymId, {
        memberName: member.name,
        mobile,
        deletedBy: actor?.name || 'موظف',
      });
    } catch {}
    return { ok: true };
  }
}
