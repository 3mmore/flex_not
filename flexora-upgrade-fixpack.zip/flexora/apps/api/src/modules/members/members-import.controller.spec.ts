/**
 * PHASE N1 — members-import controller: no import-time side effects, and no
 * exception may ever escape a multer callback.
 *
 * Both properties were found the hard way:
 *   1. IMPORT_UPLOAD_DIR used to be read at module scope and the directory
 *      created there, so merely importing the app decided the upload location
 *      and could abort the process before the environment validator ran.
 *   2. After the read was made lazy, an unusable directory threw a 503 from
 *      inside multer's `destination` callback. That callback runs in a busboy
 *      stream event, outside Nest's exception pipeline: a single authenticated
 *      POST /api/members/import/preview killed the whole API process.
 *
 * These tests assert on the variable NAME only, never on a secret value
 * (standing L1/M2 constraint).
 */
import { BadRequestException, HttpException, ServiceUnavailableException } from '@nestjs/common';
import { existsSync, mkdtempSync, rmSync, statSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

import { importDir, memberImportDestination } from './members-import.controller';

const REAL_ENV = { ...process.env };

/** Replace process.env wholesale for one test, restoring it afterwards. */
function withEnv<T>(vars: Record<string, string | undefined>, fn: () => T): T {
  const saved = { ...process.env };
  for (const [k, v] of Object.entries(vars)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  try {
    return fn();
  } finally {
    for (const key of Object.keys(process.env)) delete process.env[key];
    Object.assign(process.env, saved);
  }
}

/** A temp root containing a regular file, so paths below it can never be made. */
let root: string;
let blocker: string;
let unusable: string;
let usable: string;

beforeAll(() => {
  root = mkdtempSync(join(tmpdir(), 'n1-import-'));
  blocker = join(root, 'blocker');
  writeFileSync(blocker, 'this is a regular file, not a directory\n');
  unusable = join(blocker, 'imports');       // nearest existing ancestor is a file
  usable = join(root, 'ok', 'imports');      // creatable
});

afterAll(() => {
  Object.keys(process.env).forEach((k) => delete process.env[k]);
  Object.assign(process.env, REAL_ENV);
  try {
    rmSync(root, { recursive: true, force: true });
  } catch {
    /* best effort */
  }
});

/** Collect what a multer callback receives instead of letting it propagate. */
function capture() {
  const calls: Array<{ error: Error | null; destination: string }> = [];
  const cb = (error: Error | null, destination: string) => {
    calls.push({ error, destination });
  };
  return { calls, cb, first: () => calls[0] };
}

describe('PHASE N1 — members-import.controller: import-time safety', () => {
  it('creates nothing and reads nothing when the module is imported', () => {
    const sentinel = join(root, 'sentinel-imports');
    withEnv({ IMPORT_UPLOAD_DIR: sentinel }, () => {
      jest.isolateModules(() => {
        require('./members-import.controller');
      });
    });
    expect(existsSync(sentinel)).toBe(false);
  });

  it('leaves IMPORT_UPLOAD_DIR untouched until a request needs it', () => {
    const sentinel = join(root, 'lazy-imports');
    withEnv({ IMPORT_UPLOAD_DIR: sentinel }, () => {
      expect(existsSync(sentinel)).toBe(false);
      expect(importDir()).toBe(sentinel);
      expect(existsSync(sentinel)).toBe(true);
      expect(statSync(sentinel).isDirectory()).toBe(true);
    });
  });
});

describe('PHASE N1 — members-import.controller: multer destination never throws', () => {
  it('routes an unusable IMPORT_UPLOAD_DIR to the callback as a 503 (no throw)', () => {
    const { calls, cb, first } = capture();
    withEnv({ IMPORT_UPLOAD_DIR: unusable }, () => {
      expect(() =>
        memberImportDestination({ gymId: 'gym-1' } as never, {} as never, cb),
      ).not.toThrow();
    });
    expect(calls).toHaveLength(1);
    const err = first().error;
    expect(err).toBeInstanceOf(HttpException);
    expect(err).toBeInstanceOf(ServiceUnavailableException);
    expect((err as HttpException).getStatus()).toBe(503);
  });

  it('names the variable IMPORT_UPLOAD_DIR in that 503 and explains the remedy', () => {
    const { cb, first } = capture();
    withEnv({ IMPORT_UPLOAD_DIR: unusable }, () => {
      memberImportDestination({ gymId: 'gym-1' } as never, {} as never, cb);
    });
    const message = (first().error as HttpException).message;
    expect(message).toContain('IMPORT_UPLOAD_DIR');
    expect(message).toContain(unusable);
    expect(message).toMatch(/ENOTDIR/);
    expect(message).toMatch(/Set IMPORT_UPLOAD_DIR to a directory/);
  });

  it('never puts a secret value into the diagnostic', () => {
    const SECRET = 'S3cr3t-value-that-must-not-be-logged';
    const { cb, first } = capture();
    withEnv(
      { IMPORT_UPLOAD_DIR: unusable, JWT_ACCESS_SECRET: SECRET, DATABASE_URL: `postgresql://u:${SECRET}@h/db` },
      () => {
        memberImportDestination({ gymId: 'gym-1' } as never, {} as never, cb);
      },
    );
    expect((first().error as HttpException).message).not.toContain(SECRET);
  });

  it('passes an empty destination alongside the error (multer contract)', () => {
    const { cb, first } = capture();
    withEnv({ IMPORT_UPLOAD_DIR: unusable }, () => {
      memberImportDestination({ gymId: 'gym-1' } as never, {} as never, cb);
    });
    expect(first().destination).toBe('');
  });

  it('rejects a request with no tenant context as 400, still without throwing', () => {
    const { calls, cb, first } = capture();
    withEnv({ IMPORT_UPLOAD_DIR: usable }, () => {
      expect(() => memberImportDestination({} as never, {} as never, cb)).not.toThrow();
    });
    expect(calls).toHaveLength(1);
    expect(first().error).toBeInstanceOf(BadRequestException);
    expect((first().error as HttpException).getStatus()).toBe(400);
    expect(existsSync(usable)).toBe(false);
  });

  it('resolves and creates <IMPORT_UPLOAD_DIR>/<gymId> when the directory is usable', () => {
    const { calls, cb, first } = capture();
    withEnv({ IMPORT_UPLOAD_DIR: usable }, () => {
      memberImportDestination({ gymId: 'gym-42' } as never, {} as never, cb);
    });
    expect(calls).toHaveLength(1);
    expect(first().error).toBeNull();
    expect(first().destination).toBe(join(usable, 'gym-42'));
    expect(statSync(first().destination).isDirectory()).toBe(true);
  });
});

describe('PHASE N1 — members-import.controller: handler-side importDir()', () => {
  it('throws a 503 (correct inside a route handler, where Nest catches it)', () => {
    withEnv({ IMPORT_UPLOAD_DIR: unusable }, () => {
      expect(() => importDir()).toThrow(ServiceUnavailableException);
      try {
        importDir();
      } catch (e) {
        expect((e as HttpException).getStatus()).toBe(503);
        expect((e as HttpException).message).toContain('IMPORT_UPLOAD_DIR');
      }
    });
  });

  it('falls back to the documented default when the variable is unset, and still names it on failure', () => {
    const DEFAULT = '/var/backups/flexora/imports';
    withEnv({ IMPORT_UPLOAD_DIR: undefined }, () => {
      expect(process.env.IMPORT_UPLOAD_DIR).toBeUndefined();
      let returned: string | null = null;
      let thrown: unknown = null;
      try {
        returned = importDir();
      } catch (e) {
        thrown = e;
      }
      if (thrown === null) {
        // The host allows the default: it must be exactly the documented path.
        expect(returned).toBe(DEFAULT);
        expect(statSync(DEFAULT as string).isDirectory()).toBe(true);
      } else {
        // The host refuses the default: the operator must still be told which
        // variable to set, not shown a bare EACCES.
        expect(thrown).toBeInstanceOf(ServiceUnavailableException);
        expect((thrown as HttpException).getStatus()).toBe(503);
        expect((thrown as HttpException).message).toContain('IMPORT_UPLOAD_DIR');
        expect((thrown as HttpException).message).toContain(DEFAULT);
      }
    });
  });
});
