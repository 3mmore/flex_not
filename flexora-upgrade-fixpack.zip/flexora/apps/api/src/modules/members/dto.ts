/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  IsBoolean, IsDateString, IsEnum, IsInt, IsOptional, IsString, Matches, Max, Min, MinLength, IsEmail, ValidateIf, IsNumber,
} from 'class-validator';
import { Type } from 'class-transformer';
import { Gender, MemberStatus } from '@prisma/client';

// Re-exported from the shared validator so there is ONE definition system-wide.
import { EG_PHONE } from '../../common/validators/phone';
const THREE_PART_NAME = /^\S+\s+\S+\s+\S+.*$/;

export class CreateMemberDto {
  @IsString() 
  @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' })
  name!: string;

  @Matches(EG_PHONE, { message: 'Invalid Egyptian mobile (11 digits, 010/011/012/015)' })
    mobile!: string;
  @IsOptional() @IsEnum(Gender) gender?: Gender;
  @IsOptional() @IsDateString() dob?: string;
  @IsOptional() @IsString() nationalId?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsBoolean() vip?: boolean;
  @IsString() planId!: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsDateString() startDate?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(20) invitationSlots?: number;
  // PHASE J2: `paymentId` is GONE from member creation. A manual membership
  // payment is now always bound to the member it was taken for (J2), so a
  // payment can only be validated against a member that already exists — the
  // old "create the member and bind the unbound payment to it in one shot"
  // path is exactly the unbound-proof hole J2 closes. Creating a member now
  // registers it as PENDING_PAYMENT; `POST /members/:id/renew` activates it
  // with a payment bound to that member (the first activation books a
  // `membership_create` financial, a later one books `membership_renewal`).
}

/**
 * ROUND 14 (security review, PHASE K4) — register a member AND take the
 * payment that activates it, in ONE API call and ONE database transaction.
 *
 * The old flow was three separate calls (POST /members → POST /payments/manual
 * → POST /members/:id/renew). A failure in the middle left half-done state
 * behind: a registered member with no payment (unpaid, but present in every
 * list) or a payment with no membership (money taken, no access). This single
 * endpoint either does all of it or none of it.
 *
 * `POST /members` (register only) stays for "register now, pay later".
 */
export class RegisterAndActivateMemberDto {
  @IsString()
  @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' })
  name!: string;

  @Matches(EG_PHONE, { message: 'Invalid Egyptian mobile (11 digits, 010/011/012/015)' })
  mobile!: string;

  @IsOptional() @IsEnum(Gender) gender?: Gender;
  @IsOptional() @IsDateString() dob?: string;
  @IsOptional() @IsString() nationalId?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsBoolean() vip?: boolean;
  @IsString() planId!: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsDateString() startDate?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(20) invitationSlots?: number;

  /** Money actually taken at the desk. Defaults to the plan price. */
  @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0.01)
  amount?: number;

  /** CASH / CARD / VODAFONE_CASH / … Defaults to CASH. */
  @IsOptional() @IsString() method?: string;
}

/**
 * ROUND 14 (security review, PHASE K4) — take the payment that activates an
 * ALREADY-REGISTERED member (a converted lead, a row imported as pending, or a
 * member registered with "pay later") in ONE transaction: payment + membership
 * financials + activation, or nothing.
 */
export class ActivateMemberDto {
  /** Money actually taken at the desk. Defaults to the plan price. */
  @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0.01)
  amount?: number;

  /** CASH / CARD / VODAFONE_CASH / … Defaults to CASH. */
  @IsOptional() @IsString() method?: string;

  /** Activate onto a different plan than the member's current one. */
  @IsOptional() @IsString() planId?: string;

  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(20) invitationSlots?: number;
}

export class RenewMemberDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(20) invitationSlots?: number;
  @IsOptional() @IsString() paymentId?: string;
  @IsOptional() @IsString() planId?: string; // renew onto a different plan than the member's current one; defaults to current plan if omitted
}

export class UpdateMemberDto {
  // FIX: edits send the member's EXISTING name, and many real members have
  // 2-part names ("Ahmed Hassan") — enforcing the 3-part rule here blocked
  // even a typo fix. The strict 3-part rule stays on CreateMemberDto only.
  @IsOptional() @IsString() @MinLength(2) name?: string;

  @IsOptional() 
  @ValidateIf((o) => o.email && o.email !== '')
  @IsEmail() 
  email?: string;

  @IsOptional() @Matches(EG_PHONE) mobile?: string;
  @IsOptional() @IsEnum(Gender) gender?: Gender;
  @IsOptional() @IsDateString() dob?: string;
  @IsOptional() @IsString() nationalId?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() @IsBoolean() vip?: boolean;
  @IsOptional() @IsBoolean() frozen?: boolean;
  @IsOptional() @IsEnum(MemberStatus) status?: MemberStatus;
  @IsOptional() @IsString() planId?: string;
  @IsOptional() @IsString() branchId?: string;
}
