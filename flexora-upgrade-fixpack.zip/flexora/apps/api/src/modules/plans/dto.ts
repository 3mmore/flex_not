/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsEnum, IsInt, IsNumber, IsOptional, IsString, Min, IsBoolean } from 'class-validator';
import { PlanType } from '@prisma/client';

export class CreatePlanDto {
  @IsString() name!: string;
  @IsEnum(PlanType) type!: PlanType;
  @IsOptional() @IsInt() @Min(0) sessions?: number;
  @IsInt() @Min(0) days!: number;
  @IsNumber() @Min(0) price!: number;
  // FIX: the plans page sends `active` when creating (its form has an
  // active/inactive toggle) — without this the UI's "add plan" always 400ed
  // with "property active should not exist".
  @IsOptional() @IsBoolean() active?: boolean;
  @IsOptional() @IsInt() @Min(0) invitations?: number;
  @IsOptional() @IsInt() @Min(0) maxFreezes?: number;
  @IsOptional() @IsInt() @Min(0) freezeDays?: number;
}

export class UpdatePlanDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsEnum(PlanType) type?: PlanType;
  @IsOptional() @IsInt() @Min(0) sessions?: number | null;
  @IsOptional() @IsInt() @Min(0) days?: number;
  @IsOptional() @IsNumber() @Min(0) price?: number;
  @IsOptional() @IsBoolean() active?: boolean;
  @IsOptional() @IsInt() @Min(0) invitations?: number;
  @IsOptional() @IsInt() @Min(0) maxFreezes?: number;
  @IsOptional() @IsInt() @Min(0) freezeDays?: number;
}
