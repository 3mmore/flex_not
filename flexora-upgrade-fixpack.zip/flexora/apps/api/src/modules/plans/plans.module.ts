/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PlansService } from './plans.service';
import { PlansController } from './plans.controller';
@Module({ imports: [JwtModule.register({})], controllers: [PlansController], providers: [PlansService] })
export class PlansModule {}
