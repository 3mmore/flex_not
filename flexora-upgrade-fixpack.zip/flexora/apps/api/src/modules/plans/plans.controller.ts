/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PlansService } from './plans.service';
import { CreatePlanDto, UpdatePlanDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('plans')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('plans')
export class PlansController {
  constructor(private readonly svc: PlansService) {}
  
  // ROUND 13 (Phase 1): RECEPTION may read plans — adding a member
  // (POST /members) and renewing (POST /members/:id/renew) both require a
  // plan, and the members/leads pages render a plan picker. Create/update/
  // delete stay OWNER/MANAGER-only (read-only for Reception).
  @Get() @Permissions('plans.view')
  list(@GymId() gymId: string) { return this.svc.list(gymId); }
  
  @Post() @Permissions('plans.manage') @Audit('create', 'Plan')
  create(@GymId() gymId: string, @Body() dto: CreatePlanDto) { return this.svc.create(gymId, dto); }
  
  @Patch(':id') @Permissions('plans.manage') @Audit('update', 'Plan')
  update(@GymId() gymId: string, @Param('id') id: string, @Body() dto: UpdatePlanDto) { return this.svc.update(gymId, id, dto); }
  
  @Delete(':id') @Permissions('plans.delete') @Audit('delete', 'Plan')
  remove(
    @GymId() gymId: string, 
    @Param('id') id: string,
    @Query('targetPlanId') targetPlanId?: string
  ) { 
    return this.svc.remove(gymId, id, targetPlanId); 
  }
}
