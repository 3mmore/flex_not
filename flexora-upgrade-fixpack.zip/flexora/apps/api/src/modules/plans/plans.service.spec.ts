/**
 * PHASE N1.5 — PlansService.remove() and the foreign key that now backs it.
 *
 * "Member"."planId" is NOT NULL with ON DELETE NO ACTION (migration
 * 20261019090000_member_planid_not_null) and "RenewalRequest"."planId" has
 * always been ON DELETE RESTRICT, so Postgres refuses to delete a plan that
 * something still points at. Prisma reports that as P2003, which the global filter
 * (common/filters/http-exception.filter.ts) collapsed into one generic
 * 400 {"message":"foreign_key_constraint_violation"} — untranslated and codeless,
 * so the UI could not distinguish the recoverable case (members still assigned →
 * reassign them) from the unrecoverable one (renewal history → deactivate the
 * plan). These tests pin the 409 PLAN_IN_USE mapping, the unchanged
 * MEMBERS_ASSIGNED guard, the atomic withTenant() reassign, and the rule that
 * unrelated errors are not swallowed.
 */
import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';

import { PlansService } from './plans.service';

jest.mock('../../common/cache/member-list-cache', () => ({
  bustMemberListCaches: jest.fn(async () => undefined),
}));

import { bustMemberListCaches } from '../../common/cache/member-list-cache';

const GYM = 'gym-1';
const PLAN = 'plan-1';
const TARGET = 'plan-2';

/** A real Prisma P2003, shaped the way the runtime raises it. */
function fkViolation(constraint: string): Prisma.PrismaClientKnownRequestError {
  return new Prisma.PrismaClientKnownRequestError(
    `Foreign key constraint failed on the field: \`${constraint}\``,
    { code: 'P2003', clientVersion: '5.22.0', meta: { constraint } },
  );
}

  function makeService(opts: {
    members?: number;
    plan?: unknown;
    targetPlan?: unknown;
    deleteError?: unknown;
    transactionError?: unknown;
    /** what member.count() says WHEN THE GUARD ASKS AGAIN after the FK fired */
    liveCount?: number;
    /** make that recount fail, to prove the 409 still answers */
    recountError?: boolean;
  }) {
    const planDelete = jest.fn(async () => {
      if (opts.deleteError) throw opts.deleteError;
      return { id: PLAN };
    });
    const memberUpdateMany = jest.fn(() => Promise.resolve({ count: opts.members ?? 0 }));
    const prisma = {
      plan: {
        findFirst: jest.fn(async (args: { where?: { id?: string } }) => {
          if (args?.where?.id === TARGET) return opts.targetPlan ?? null;
          return opts.plan === undefined
            ? { id: PLAN, gymId: GYM, _count: { members: opts.members ?? 0 } }
            : opts.plan;
        }),
        delete: planDelete,
      },
      member: {
        updateMany: memberUpdateMany,
        count: jest.fn(async () => {
          if (opts.recountError) throw new Error('recount failed');
          return opts.liveCount ?? opts.members ?? 0;
        }),
      },
      /**
       * The tenant-RLS extension wraps every STANDALONE model call in its own
       * $transaction([set_config, query]), so a bare $transaction([...]) array
       * executes its elements as separate racing transactions (PHASE N1.5 found
       * this live: the re-point committed while plan.delete was rejected by
       * Member_planId_fkey). remove() must therefore use withTenant(), which
       * hands the callback ONE transaction client.
       */
      withTenant: jest.fn(async (gymId: string, fn: (tx: unknown) => Promise<unknown>) => {
        if (opts.transactionError) throw opts.transactionError;
        return fn({
          plan: { delete: planDelete },
          member: { updateMany: memberUpdateMany },
        });
      }),
      $transaction: jest.fn(async () => {
        throw new Error(
          'remove() must not use a bare $transaction() array: under the tenant RLS ' +
          'extension each element runs in its own transaction, so the reassign is not atomic. ' +
          'Use withTenant(gymId, async (tx) => …) instead.',
        );
      }),
    };
    const redis = {} as never;
    return { service: new PlansService(prisma as never, redis), prisma };
  }

  /**
   * The shape Prisma 5.22 ACTUALLY produces in this app (measured live, see
   * work/n1-evidence/n15-live-proofs-AFTER.txt): meta carries no constraint at all
   * and the name only appears inside the message, right next to a back-ticked
   * invocation line that must not be mistaken for the constraint name.
   */
  function fkViolationMessageOnly(constraint?: string): Prisma.PrismaClientKnownRequestError {
    const tail = constraint
      ? `Foreign key constraint violated: \`${constraint} (index)\``
      : 'Foreign key constraint violated';
    return new Prisma.PrismaClientKnownRequestError(
      'Invalid `this.prisma.plan.delete()` invocation in\n' +
      '/app/dist/src/modules/plans/plans.service.js:116:85\n\n' +
      tail,
      { code: 'P2003', clientVersion: '5.22.0' },
    );
  }

  function payloadOf(err: unknown): Record<string, unknown> {
    return (err as ConflictException).getResponse() as Record<string, unknown>;
  }

describe('PHASE N1.5 — PlansService.remove()', () => {
  beforeEach(() => jest.clearAllMocks());

  it('deletes a plan nothing references', async () => {
    const { service, prisma } = makeService({ members: 0 });
    await expect(service.remove(GYM, PLAN)).resolves.toEqual({ ok: true, membersRepointed: 0 });
    expect(prisma.plan.delete).toHaveBeenCalledWith({ where: { id: PLAN, gymId: GYM } });
  });

  it('404s when the plan is not in this gym', async () => {
    const { service } = makeService({ plan: null });
    await expect(service.remove(GYM, PLAN)).rejects.toBeInstanceOf(NotFoundException);
  });

  it('keeps the 400 MEMBERS_ASSIGNED guard when no target plan is given', async () => {
    const { service } = makeService({ members: 3 });
    await expect(service.remove(GYM, PLAN)).rejects.toMatchObject({
      response: { code: 'MEMBERS_ASSIGNED', memberCount: 3 },
    });
  });

    it('reassigns members and deletes the plan inside ONE withTenant transaction', async () => {
      const { service, prisma } = makeService({ members: 2, targetPlan: { id: TARGET } });
      await expect(service.remove(GYM, PLAN, TARGET)).resolves.toEqual({ ok: true, membersRepointed: 2 });
      expect(prisma.withTenant).toHaveBeenCalledTimes(1);
      expect(prisma.withTenant).toHaveBeenCalledWith(GYM, expect.any(Function));
      // both statements ran through the SAME transaction client the callback got
      expect(prisma.member.updateMany).toHaveBeenCalledWith({
        where: { planId: PLAN, gymId: GYM },
        data: { planId: TARGET },
      });
      expect(prisma.plan.delete).toHaveBeenCalledWith({ where: { id: PLAN, gymId: GYM } });
      expect(bustMemberListCaches).toHaveBeenCalledWith(expect.anything(), GYM);
    });

    it('never uses a bare $transaction array — it is not atomic under the RLS extension', async () => {
      const { service, prisma } = makeService({ members: 2, targetPlan: { id: TARGET } });
      await service.remove(GYM, PLAN, TARGET);
      expect(prisma.$transaction).not.toHaveBeenCalled();
    });

  it('answers 409 PLAN_IN_USE when a member appeared between the count and the delete', async () => {
    // The race the guard exists for: memberCount said 0, so the code took the
    // plain delete path, but a concurrent create made the FK refuse it.
    const { service } = makeService({
      members: 0,
      deleteError: fkViolation('Member_planId_fkey'),
    });
    let caught: unknown;
    await service.remove(GYM, PLAN).catch((e) => { caught = e; });
    expect(caught).toBeInstanceOf(ConflictException);
    expect((caught as ConflictException).getStatus()).toBe(409);
    const body = payloadOf(caught);
    expect(body.code).toBe('PLAN_IN_USE');
    expect(body.translationKey).toBe('plan_in_use');
    expect(String(body.message)).toMatch(/still assigned/i);
  });

  it('answers 409 PLAN_IN_USE when the reassign transaction loses the race', async () => {
    const { service } = makeService({
      members: 2,
      targetPlan: { id: TARGET },
      transactionError: fkViolation('Member_planId_fkey'),
    });
    let caught: unknown;
    await service.remove(GYM, PLAN, TARGET).catch((e) => { caught = e; });
    expect(caught).toBeInstanceOf(ConflictException);
    expect(payloadOf(caught)).toMatchObject({
      code: 'PLAN_IN_USE',
      translationKey: 'plan_in_use',
      memberCount: 2,
    });
    // the member list cache is untouched — nothing was committed
    expect(bustMemberListCaches).not.toHaveBeenCalled();
  });

  it('says "renewal history" when RenewalRequest is what blocks the delete', async () => {
    const { service } = makeService({
      members: 0,
      deleteError: fkViolation('RenewalRequest_planId_fkey'),
    });
    let caught: unknown;
    await service.remove(GYM, PLAN).catch((e) => { caught = e; });
    expect(caught).toBeInstanceOf(ConflictException);
    const body = payloadOf(caught);
    expect(body.code).toBe('PLAN_IN_USE');
    expect(body.translationKey).toBe('plan_in_use_history');
    expect(String(body.message)).toMatch(/renewal history/i);
  });

    it('reads the constraint from the MESSAGE when Prisma leaves meta empty (5.x behaviour)', async () => {
      // The live race: memberCount was 0, a concurrent create made Member_planId_fkey
      // refuse the delete, and meta.constraint was empty — the name is message-only.
      const { service } = makeService({
        members: 0,
        deleteError: fkViolationMessageOnly('Member_planId_fkey'),
      });
      let caught: unknown;
      await service.remove(GYM, PLAN).catch((e) => { caught = e; });
      expect(caught).toBeInstanceOf(ConflictException);
      const body = payloadOf(caught);
      expect(body.code).toBe('PLAN_IN_USE');
      expect(body.translationKey).toBe('plan_in_use');
      expect(String(body.message)).toMatch(/still assigned/i);
      expect(JSON.stringify(body)).not.toContain('Member_planId_fkey');
    });

    it('reads RenewalRequest_planId_fkey from the message too', async () => {
      const { service } = makeService({
        members: 0,
        deleteError: fkViolationMessageOnly('RenewalRequest_planId_fkey'),
      });
      let caught: unknown;
      await service.remove(GYM, PLAN).catch((e) => { caught = e; });
      expect(payloadOf(caught)).toMatchObject({
        code: 'PLAN_IN_USE',
        translationKey: 'plan_in_use_history',
      });
    });

    it('trusts the constraint over a stale member count', async () => {
      // 2 members were counted, but the FK that actually refused the delete is the
      // renewal-history one — telling the owner to reassign members would be wrong.
      const { service } = makeService({
        members: 2,
        targetPlan: { id: TARGET },
        transactionError: fkViolationMessageOnly('RenewalRequest_planId_fkey'),
      });
      let caught: unknown;
      await service.remove(GYM, PLAN, TARGET).catch((e) => { caught = e; });
      const body = payloadOf(caught);
      expect(body.translationKey).toBe('plan_in_use_history');
      expect(body.memberCount).toBe(2);
    });

    it('does not mistake the back-ticked invocation for a constraint name', async () => {
      const { service } = makeService({ members: 0, deleteError: fkViolationMessageOnly() });
      let caught: unknown;
      await service.remove(GYM, PLAN).catch((e) => { caught = e; });
      expect(caught).toBeInstanceOf(ConflictException);
      const body = payloadOf(caught);
      expect(body.code).toBe('PLAN_IN_USE');
      // no identifiable constraint → the documented fallback is the member count
      expect(body.translationKey).toBe('plan_in_use_history');
      expect(JSON.stringify(body)).not.toContain('prisma.plan.delete');
    });

    it('reports the LIVE member count in the 409, not the stale one', async () => {
      // memberCount was 0 when the plan was read; a concurrent create is what made
      // the FK fire. The plans page prints this number in its "move them first"
      // dialog, so the guard asks the database again.
      const { service, prisma } = makeService({
        members: 0,
        liveCount: 3,
        deleteError: fkViolationMessageOnly('Member_planId_fkey'),
      });
      let caught: unknown;
      await service.remove(GYM, PLAN).catch((e) => { caught = e; });
      const body = payloadOf(caught);
      expect(body.memberCount).toBe(3);
      expect(String(body.message)).toMatch(/3 member/);
      expect((prisma.member.count as unknown as jest.Mock)).toHaveBeenCalledWith({
        where: { planId: PLAN, gymId: GYM },
      });
    });

    it('still answers 409 when the recount itself fails', async () => {
      const { service } = makeService({
        members: 2,
        targetPlan: { id: TARGET },
        transactionError: fkViolationMessageOnly('Member_planId_fkey'),
        recountError: true,
      });
      let caught: unknown;
      await service.remove(GYM, PLAN, TARGET).catch((e) => { caught = e; });
      expect(caught).toBeInstanceOf(ConflictException);
      expect(payloadOf(caught)).toMatchObject({ code: 'PLAN_IN_USE', memberCount: 2 });
    });

    it('does not recount for the renewal-history branch', async () => {
      const { service, prisma } = makeService({
        members: 0,
        liveCount: 9,
        deleteError: fkViolationMessageOnly('RenewalRequest_planId_fkey'),
      });
      let caught: unknown;
      await service.remove(GYM, PLAN).catch((e) => { caught = e; });
      expect(payloadOf(caught).translationKey).toBe('plan_in_use_history');
      expect(prisma.member.count).not.toHaveBeenCalled();
    });

    it('does not leak the database constraint name to the client', async () => {
    const { service } = makeService({
      members: 0,
      deleteError: fkViolation('Member_planId_fkey'),
    });
    let caught: unknown;
    await service.remove(GYM, PLAN).catch((e) => { caught = e; });
    const serialised = JSON.stringify(payloadOf(caught));
    expect(serialised).not.toContain('Member_planId_fkey');
    expect(serialised).not.toContain('constraint');
  });

  it('rethrows unrelated database errors instead of masking them as a conflict', async () => {
    const notFound = new Prisma.PrismaClientKnownRequestError('Record to delete does not exist.', {
      code: 'P2025',
      clientVersion: '5.22.0',
    });
    const { service } = makeService({ members: 0, deleteError: notFound });
    await expect(service.remove(GYM, PLAN)).rejects.toBe(notFound);
  });

  it('rejects a target plan that is not in this gym', async () => {
    const { service } = makeService({ members: 2, targetPlan: null });
    await expect(service.remove(GYM, PLAN, TARGET)).rejects.toBeInstanceOf(BadRequestException);
  });
});
