/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, ConflictException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { bustMemberListCaches } from '../../common/cache/member-list-cache';
import { CreatePlanDto, UpdatePlanDto } from './dto';
@Injectable()
export class PlansService {
  private readonly logger = new Logger(PlansService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
  ) {}
  list(gymId: string) {
    return this.prisma.plan.findMany({ where: { gymId }, orderBy: { price: 'asc' } });
  }
  async create(gymId: string, dto: CreatePlanDto) {
    // No plan-count cap: the gym owner has full control over their plans
    // (build any number from scratch, edit/delete anytime). A previous
    // version reused License.seats — a STAFF seat count — as the plan cap,
    // which blocked the 6th plan of every gym with "License plan capacity
    // reached".
    try {
      return await this.prisma.plan.create({ data: { gymId, ...dto } });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'PLAN_DUPLICATE',
          translationKey: 'plan_duplicate',
          message: 'A plan with the same name, type, and price already exists.',
        });
      }
      throw error;
    }
  }
  async update(gymId: string, id: string, dto: UpdatePlanDto) {
    const p = await this.prisma.plan.findFirst({ where: { id, gymId } });
    if (!p) throw new NotFoundException('Plan not found');
    try {
      return await this.prisma.plan.update({ where: { id, gymId }, data: dto });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'PLAN_DUPLICATE',
          translationKey: 'plan_duplicate',
          message: 'A plan with the same name, type, and price already exists.',
        });
      }
      throw error;
    }
  }

  async remove(gymId: string, id: string, targetPlanId?: string) {
    const p = await this.prisma.plan.findFirst({ 
      where: { id, gymId },
      include: { _count: { select: { members: true } } }
    });
    if (!p) throw new NotFoundException('Plan not found');

    const memberCount = p._count.members;
    if (memberCount > 0) {
      if (!targetPlanId) {
        throw new BadRequestException({
          message: `Cannot delete plan: ${memberCount} members are still assigned to it.`,
          code: 'MEMBERS_ASSIGNED',
          memberCount,
        });
      }
      
      const targetPlan = await this.prisma.plan.findFirst({ where: { id: targetPlanId, gymId } });
      if (!targetPlan) throw new BadRequestException('Target plan for migration not found');
      if (targetPlan.id === id) throw new BadRequestException('Target plan cannot be the same as the deleted plan');

      // PHASE N1.5: this was a bare `$transaction([...])` ARRAY, which is NOT
      // atomic in this codebase. The tenant-RLS extension in prisma.service.ts
      // wraps every standalone model call in its own
      // `$transaction([set_config('app.gym_id'), query])` unless the call runs
      // inside withTenant(), so the two array elements were each executed as a
      // SEPARATE transaction — and they raced. Live proof (work/n15-live-proofs.js
      // b2, server log): member.updateMany committed, plan.delete was then
      // rejected by Member_planId_fkey, the plan survived, the client got a raw
      // 400 "foreign_key_constraint_violation". A half-applied reassign.
      // withTenant() is the supported path (same rule as the PHASE K4 notes in
      // members.service.ts): ONE interactive transaction, set_config once, both
      // statements on one connection, all-or-nothing.
      await this.withPlanInUseGuard(
        memberCount,
        () => this.prisma.withTenant(gymId, async (tx) => {
          await tx.member.updateMany({
            where: { planId: id, gymId },
            data: { planId: targetPlanId }
          });
          return tx.plan.delete({ where: { id, gymId } });
        }),
        () => this.prisma.member.count({ where: { planId: id, gymId } }),
      );
      // Re-pointing members at another plan rewrites member rows, so the cached
      // member lists (which carry the plan name) must go with it — same rule as
      // every other member-row writer (see common/cache/member-list-cache.ts).
      await bustMemberListCaches(this.redis, gymId);
    } else {
      await this.withPlanInUseGuard(
        memberCount,
        () => this.prisma.plan.delete({ where: { id, gymId } }),
        () => this.prisma.member.count({ where: { planId: id, gymId } }),
      );
    }

    return { ok: true, membersRepointed: memberCount };
  }

  /**
   * PHASE N1.5 — the database is the last line of defence against deleting a plan
   * that something still points at: "Member"."planId" is NOT NULL with
   * ON DELETE NO ACTION (migration 20261019090000_member_planid_not_null), and
   * "RenewalRequest"."planId" has always been ON DELETE RESTRICT.
   *
   * Prisma reports both as P2003, and the global filter
   * (common/filters/http-exception.filter.ts) collapsed EVERY P2003 into one
   * generic 400 {"message":"foreign_key_constraint_violation"} — an untranslated
   * database string with no code, so the UI could not tell "members are still
   * assigned" (recoverable: reassign them) from "renewal history still references
   * it" (not recoverable: deactivate the plan instead), and the plans page could
   * only print the raw wording. Before this migration the member FK was SET NULL,
   * so the same delete silently orphaned members instead and broke
   * GET /api/members for the whole gym — the defect that started this phase.
   * It is an ordinary conflict the operator can act on, so it becomes a 409
   * carrying a translation key. The constraint name is logged, never returned: a
   * response body is not the place for schema details.
   */
  /**
   * Which foreign key refused the delete? Prisma does not report it in a stable
   * place: on 5.x a P2003 arrives with an EMPTY meta and the name only inside the
   * message — "Foreign key constraint violated: `Member_planId_fkey (index)`" —
   * while other versions/drivers populate meta.constraint. This was measured live,
   * not assumed: the first version of the guard read meta only, logged
   * `constraint=unknown` and answered the renewal-history message for a member
   * race (work/n1-evidence/n15-live-proofs-AFTER.txt, check b3).
   *
   * The name is used ONLY to choose which message to send, and is only ever
   * written to the server log — never to a response body.
   */
  private static constraintName(err: Prisma.PrismaClientKnownRequestError): string {
    const meta = (err.meta ?? {}) as Record<string, unknown>;
    const fromMeta = ['constraint', 'field_name', 'target']
      .map((key) => meta[key])
      .find((value): value is string => typeof value === 'string' && value.length > 0);
    if (fromMeta) return fromMeta;
    // The message also back-ticks the invocation ("Invalid
    // `this.prisma.plan.delete()` invocation in …"), so only a real *_fkey name
    // is accepted; anything else falls back to the member count.
    const fk = /`([A-Za-z0-9_]+_fkey)(?:\s*\([^)]*\))?`/.exec(err.message ?? '');
    return fk ? fk[1] : '';
  }

  private async withPlanInUseGuard<T>(
    memberCount: number,
    operation: () => Promise<T>,
    recount?: () => Promise<number>,
  ): Promise<T> {
    try {
      return await operation();
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2003') {
        const constraint = PlansService.constraintName(err);
        // The database is the authority on WHY the delete was refused, so its
        // answer wins over the (possibly stale) member count: a plan can hold
        // members AND renewal history, and only the constraint says which FK
        // fired. The count is the fallback for a driver that names neither.
        const byMembers = constraint ? constraint.startsWith('Member') : memberCount > 0;
        // A count taken before the delete is stale by definition when a race is
        // what brought us here, so ask the database again before telling the
        // operator how many members to move — the plans page prints this number in
        // its "move them first" dialog. Best effort: if the recount fails we keep
        // the number we already had rather than losing the 409.
        const liveCount = byMembers && recount
          ? await recount().catch(() => memberCount)
          : memberCount;
        this.logger.warn(
          `plan delete blocked by the database (constraint=${constraint || 'unknown'}, ` +
          `members=${memberCount}, live=${liveCount}) — answered 409 PLAN_IN_USE`,
        );
        throw new ConflictException({
          // http-exception.filter.ts whitelists which extra keys reach the client;
          // 'memberCount' was added to that list in this phase so the dialog above
          // stops saying "0 members".
          message: byMembers
            ? `Cannot delete plan: ${liveCount || 'one or more'} member(s) are still ` +
              `assigned to it. Move them to another plan first.`
            : 'Cannot delete plan: it is still referenced by renewal history. ' +
              'Deactivate it instead of deleting it.',
          code: 'PLAN_IN_USE',
          translationKey: byMembers ? 'plan_in_use' : 'plan_in_use_history',
          memberCount: liveCount,
        });
      }
      throw err;
    }
  }
}
