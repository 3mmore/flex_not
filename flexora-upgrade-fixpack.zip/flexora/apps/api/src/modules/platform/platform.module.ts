import { Module } from '@nestjs/common';
import { PlatformController } from './platform.controller';
import { PlatformMonitorService } from './platform-monitor.service';
import { FeatureFlagsService } from './feature-flags.service';
import { AiModule } from '../ai/ai.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { SecurityShieldModule } from '../security/security.module';
// PHASE R1 - PlatformController revokes the sessions of an administrator it
// removes, so it needs PlatformSessionService, which PlatformAuthModule exports.
// PlatformAuthModule does not import this module, so there is no cycle.
import { PlatformAuthModule } from '../platform-auth/platform-auth.module';
// PHASE R3 - the audit writer, the alert outbox and the device baseline live in a leaf
// module because PlatformAuthModule needs them too and must not import this one back.
import { PlatformAuditModule } from './platform-audit.module';

@Module({
  imports: [AiModule, NotificationsModule, PrismaModule, RedisModule, SecurityShieldModule, PlatformAuthModule, PlatformAuditModule],
  controllers: [PlatformController],
  providers: [PlatformMonitorService, FeatureFlagsService],
  exports: [PlatformAuditModule],
})
export class PlatformModule {}
