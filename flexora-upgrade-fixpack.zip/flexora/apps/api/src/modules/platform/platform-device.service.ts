/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — the administrator device baseline (owner decision A4).
 *
 * WHAT IT DOES. After a SUCCESSFUL admin login it asks one question: has this
 * administrator logged in from this device before? If not, an alert goes out through the
 * A3 outbox. "Device" means IP address plus the normalised user agent - browser family,
 * major version and operating-system family - so a patch-level browser update is not a new
 * device and does not wake the owner at 3am.
 *
 * WHAT IT NEVER DOES (A4.4). It never blocks, delays or fails a login. Every failure path
 * returns a benign observation: no secret configured, database unavailable, normaliser
 * error. A detection feature that can lock the owner out of their own console is worse
 * than not having it.
 *
 * WHAT IS STORED (A4.2). A one-way digest of IP plus normalised user agent, and the
 * normalised user-agent parts in plain text so that an operator can read what the baseline
 * contains. The raw user agent string is never stored and the raw IP is never stored; the
 * column named ipOnly is a boolean marker for "seeded from a login attempt that had no user
 * agent", not an address.
 *
 * THE SALT (A4.2, and the one deviation worth stating plainly). The digest is keyed so that
 * a leaked database does not let anyone rebuild which IP an administrator used. The
 * requirement was a per-install salt; rather than add an environment variable - which would
 * have touched docker-compose.yml, env-validation.ts, four .env.example files and the
 * owner's setup.ps1 flow - the key is derived by domain separation from a secret every
 * deployment already requires:
 *     device_key = HMAC-SHA256(OTP_HMAC_SECRET, 'flexora.platform.device.v1')
 * Rotating OTP_HMAC_SECRET therefore invalidates the baseline. That is deliberate and
 * bounded: the plain-text uaFamily/uaMajor/osFamily columns still match after a rotation,
 * so the first login afterwards is classified as the lower-severity "known device kind,
 * different digest" case rather than an unknown device.
 */
import { Injectable, Logger } from '@nestjs/common';
import { createHmac } from 'node:crypto';
import { PrismaService } from '../../config/prisma.service';
import { PlatformAlertService } from './platform-alert.service';

/** Domain-separation label. Changing it invalidates every existing baseline entry. */
export const DEVICE_KEY_DOMAIN = 'flexora.platform.device.v1';

export type DeviceObservation =
  | { outcome: 'known' }
  | { outcome: 'new-ip'; deviceRowId: string; alertRaised: boolean }
  | { outcome: 'new-device'; deviceRowId: string; alertRaised: boolean }
  | { outcome: 'baseline-seeded'; deviceRowId: string; alertRaised: false }
  | { outcome: 'skipped'; reason: 'no-device-key' | 'no-ip' | 'error' };

export interface ObserveLoginInput {
  adminId: string;
  ip: string | null;
  userAgent: string | null;
  /** The audit row written for this login, by chain position (A3.7). */
  auditSeq?: number | null;
}

@Injectable()
export class PlatformDeviceService {
  private readonly logger = new Logger('PlatformDevice');
  private cachedDeviceKey: string | null | undefined;

  constructor(
    private readonly prisma: PrismaService,
    private readonly alerts: PlatformAlertService,
  ) {}

  /**
   * Read inside the method, never at module scope. Cached after the first call because it
   * is used on every admin login; a rotation of OTP_HMAC_SECRET takes effect on restart,
   * which is the same restart that rotates TOTP anyway.
   */
  deviceKey(): string | null {
    if (this.cachedDeviceKey !== undefined) return this.cachedDeviceKey;
    const secret = process.env.OTP_HMAC_SECRET ?? '';
    this.cachedDeviceKey = secret
      ? createHmac('sha256', secret).update(DEVICE_KEY_DOMAIN).digest('hex')
      : null;
    if (!this.cachedDeviceKey) {
      this.logger.warn(
        'device baseline disabled: OTP_HMAC_SECRET is not set, so no device key can be derived',
      );
    }
    return this.cachedDeviceKey;
  }

  /** Forget the cached key. Used by tests and by any future in-process rotation. */
  resetDeviceKeyCache(): void {
    this.cachedDeviceKey = undefined;
  }

  /**
   * Normalise a user agent and digest the device in ONE round trip, using the SQL
   * implementations so that the seeding path and the login path cannot disagree (A2.3's
   * reasoning applied to A4.3).
   */
  async fingerprint(ip: string, userAgent: string | null): Promise<{
    uaFamily: string;
    uaMajor: number;
    osFamily: string;
    deviceHash: string;
  }> {
    const key = this.deviceKey();
    if (!key) throw new Error('device key unavailable');
    const rows = await this.prisma.$queryRaw<
      Array<{ ua_family: string; ua_major: number; os_family: string; device_hash: string }>
    >`
      SELECT n.ua_family                       AS ua_family,
             n.ua_major::integer               AS ua_major,
             n.os_family                       AS os_family,
             public.platform_device_hash(
               ${key}::text, ${ip}::text, n.ua_family, n.ua_major::integer, n.os_family
             )                                 AS device_hash
        FROM public.platform_normalize_ua(${userAgent ?? ''}::text) n`;
    const row = rows[0];
    if (!row) throw new Error('normaliser returned no row');
    return {
      uaFamily: row.ua_family,
      uaMajor: Number(row.ua_major) || 0,
      osFamily: row.os_family,
      deviceHash: row.device_hash,
    };
  }

  /**
   * Record a successful login against the baseline and decide whether it is new.
   *
   * A4.5: if this administrator had NO baseline rows at all, the device is recorded
   * silently and no alert is raised. That is what makes seeding safe - the first login
   * after a fresh install, or after a restore that lost the device table, must not send
   * the owner an alert about their own console.
   */
  async observeLogin(input: ObserveLoginInput): Promise<DeviceObservation> {
    if (!input.ip) return { outcome: 'skipped', reason: 'no-ip' };
    if (!this.deviceKey()) return { outcome: 'skipped', reason: 'no-device-key' };

    try {
      const fp = await this.fingerprint(input.ip, input.userAgent);

      const existing = await this.prisma.platformAdminDevice.findFirst({
        where: { adminId: input.adminId, deviceHash: fp.deviceHash },
        select: { id: true },
      });

      if (existing) {
        // A4.4: bookkeeping only, and it must not be able to fail the login.
        await this.prisma.platformAdminDevice
          .update({
            where: { id: existing.id },
            data: {
              lastSeenAt: new Date(),
              loginCount: { increment: 1 },
            },
          })
          .catch((error: Error) => this.logger.warn(`device bookkeeping failed: ${error.message}`));
        return { outcome: 'known' };
      }

      const [priorCount, sameKindCount] = await this.prisma.$transaction([
        this.prisma.platformAdminDevice.count({ where: { adminId: input.adminId } }),
        this.prisma.platformAdminDevice.count({
          where: {
            adminId: input.adminId,
            uaFamily: fp.uaFamily,
            uaMajor: fp.uaMajor,
            osFamily: fp.osFamily,
          },
        }),
      ]);

      const created = await this.prisma.platformAdminDevice.create({
        data: {
          adminId: input.adminId,
          deviceHash: fp.deviceHash,
          uaFamily: fp.uaFamily,
          uaMajor: fp.uaMajor,
          osFamily: fp.osFamily,
          ipOnly: false,
          source: 'LOGIN',
          firstSeenAt: new Date(),
          lastSeenAt: new Date(),
          loginCount: 1,
        },
        select: { id: true },
      });

      // A4.5: an empty baseline records silently, once, with no alert.
      if (priorCount === 0) {
        return { outcome: 'baseline-seeded', deviceRowId: created.id, alertRaised: false };
      }

      // Same browser family, major version and OS but a different digest means the IP
      // changed (or the install key rotated). Different family/major/OS means a genuinely
      // new device. The two get different severities so the owner can triage by eye.
      const outcome: 'new-ip' | 'new-device' = sameKindCount > 0 ? 'new-ip' : 'new-device';
      const raised = await this.alerts.raise({
        type: 'ADMIN_NEW_DEVICE',
        severity: outcome === 'new-ip' ? 'info' : 'warning',
        targetKind: 'admin',
        targetId: input.adminId,
        auditSeq: input.auditSeq ?? null,
      });

      return {
        outcome,
        deviceRowId: created.id,
        alertRaised: !!raised && !raised.deduped,
      };
    } catch (error) {
      this.logger.error(`device baseline check failed for an admin login: ${(error as Error).message}`);
      return { outcome: 'skipped', reason: 'error' };
    }
  }

  /**
   * Seed the baseline from history (A4.1, A4.6). Set-based in SQL, idempotent, additive:
   * it reads PlatformSession rows and SUCCESSFUL PlatformLoginAttempt rows and inserts one
   * entry per distinct administrator and digest, doing nothing on conflict. Failed attempts
   * are never seeded (A4.7 case five): a device seen only in a failed attempt is not this
   * administrator's device.
   */
  async seedBaseline(): Promise<{ seeded: number; considered: number; skipped: boolean }> {
    const key = this.deviceKey();
    if (!key) return { seeded: 0, considered: 0, skipped: true };
    try {
      const rows = await this.prisma.$queryRaw<
        Array<{ seeded: number; considered: number }>
      >`SELECT * FROM public.platform_seed_admin_devices(${key}::text)`;
      const row = rows[0] ?? { seeded: 0, considered: 0 };
      return { seeded: Number(row.seeded) || 0, considered: Number(row.considered) || 0, skipped: false };
    } catch (error) {
      this.logger.error(`device baseline seeding failed: ${(error as Error).message}`);
      return { seeded: 0, considered: 0, skipped: true };
    }
  }

  /** Read model for the console: how much baseline an administrator has, no digests. */
  async summaryFor(adminId: string): Promise<{ devices: number; ipOnlyEntries: number; lastSeenAt: Date | null }> {
    const rows = await this.prisma.platformAdminDevice.aggregate({
      where: { adminId },
      _count: { _all: true },
      _max: { lastSeenAt: true },
    });
    const ipOnly = await this.prisma.platformAdminDevice.count({
      where: { adminId, ipOnly: true },
    });
    return {
      devices: rows._count._all ?? 0,
      ipOnlyEntries: ipOnly,
      lastSeenAt: rows._max.lastSeenAt ?? null,
    };
  }
}
