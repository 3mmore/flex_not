import { BadRequestException, Body, Controller, Delete, Get, HttpCode, InternalServerErrorException, Logger, NotFoundException, Param, Patch, Post, Query, Req, Res, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PlatformAdminGuard } from '../../common/guards/platform-admin.guard';
import { RequireStepUp } from '../../common/decorators/platform-auth.decorators';
import { hashPassword } from '../../config/password-hash';
import { platformPasswordProblem } from '../platform-auth/platform-auth.service';
import { PlatformSessionService } from '../platform-auth/platform-session.service';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import type { Prisma } from '@prisma/client';
import { Prisma as PrismaClient } from '@prisma/client';
import { PlatformMonitorService } from './platform-monitor.service';
import { SecurityShieldService } from '../security/security-shield.service';
import { FeatureFlagsService } from './feature-flags.service';
// PHASE R3 - the single audit writer (R3.6) and the alert outbox (R3.11). Both come from
// PlatformAuditModule, a leaf module, so PlatformAuthModule can use them too.
import { PlatformAuditService, AuditState } from './platform-audit.service';
import { PlatformAlertService, RaiseAlertInput } from './platform-alert.service';
import {
  PlatformCacheService,
  PLATFORM_CACHE_KEYS,
  PLATFORM_CACHE_TTL_SECONDS,
  PLATFORM_CACHE_REDIS_BOUND_MS,
} from './platform-cache.service';
import { IsEmail, IsIn, IsOptional, IsString, MinLength } from 'class-validator';
import { PasswordStrength } from '../../common/decorators/password-strength.decorator';
import { Request, Response } from 'express';
import { PlatformRoute } from '../../common/decorators/platform-route.decorator';

/**
 * PHASE R2 / decisions Q1 and Q3: a destructive gym action must carry a real reason.
 * Eight characters is the same bar the console already applies to suspensions, and it
 * exists so the audit trail says why rather than merely that.
 */
const MIN_ACTION_REASON_LENGTH = 8;
/**
 * PHASE R3 (R3.6). PlatformSessionGuard stamps the session's step-up expiry onto the
 * request. A row records whether a second factor that was still fresh at the moment of the
 * action authorised it. Read from the request rather than from the @RequireStepUp decorator
 * on purpose: the decorator says step-up was REQUIRED, this says it was actually PRESENT,
 * and an auditor needs the second.
 */
/**
 * PHASE R3 (R3.7). One filter builder, used by the list route AND the CSV export, so the
 * two cannot drift apart and an export cannot return rows the console would not show.
 *
 * A malformed date is rejected rather than ignored: silently widening a range an operator
 * asked to narrow would export more history than they intended.
 */
function buildAuditWhere(filters: {
  adminId?: string;
  action?: string;
  target?: string;
  from?: string;
  to?: string;
  search?: string;
}) {
  const where: Record<string, unknown> = {};
  if (filters.adminId) where.adminId = String(filters.adminId);
  if (filters.action) where.action = String(filters.action);
  if (filters.target) where.target = { contains: String(filters.target), mode: 'insensitive' };

  const createdAt: Record<string, Date> = {};
  if (filters.from) {
    const parsed = new Date(String(filters.from));
    if (Number.isNaN(parsed.getTime())) throw new BadRequestException('invalid from date');
    createdAt.gte = parsed;
  }
  if (filters.to) {
    const parsed = new Date(String(filters.to));
    if (Number.isNaN(parsed.getTime())) throw new BadRequestException('invalid to date');
    createdAt.lte = parsed;
  }
  if (createdAt.gte || createdAt.lte) where.createdAt = createdAt;

  const term = filters.search ? String(filters.search).trim() : '';
  if (term) {
    where.OR = [
      { action: { contains: term, mode: 'insensitive' } },
      { target: { contains: term, mode: 'insensitive' } },
      { adminName: { contains: term, mode: 'insensitive' } },
      { reason: { contains: term, mode: 'insensitive' } },
    ];
  }
  return where;
}

/** Hard cap on one CSV download. See exportAuditCsv for why it exists. */
export const AUDIT_EXPORT_MAX_ROWS = 10_000;

/**
 * PHASE R4 (R4.12) - the revenue export.
 *
 * A FIXED ALLOWLIST decides what leaves the database, exactly as it does for the audit export:
 * nothing else can be in the file whatever a row contains. Every column here is gym-level and was
 * already approved one by one in PHASE R2 decision Q2 - gym identity and status, the subscription
 * tier and its timing, and payment aggregates. There is no member column, because the source is
 * public.platform_list_subscriptions, which by construction returns no member data, and no
 * credential column, because that function does not select one either.
 *
 * Amounts are EGP in MAJOR units (the database stores piastres), which is what the Overview's
 * monthlyRevenue already reports, so the CSV and the dashboard cannot disagree about scale.
 */
export const REVENUE_CSV_COLUMNS = [
  'gymId',
  'gymName',
  'gymSlug',
  'gymStatus',
  'tier',
  'subscriptionStatus',
  'currentPeriodStart',
  'currentPeriodEnd',
  'lastPaymentAt',
  'lastPaymentAmount',
  'totalRevenue',
] as const;

export const REVENUE_EXPORT_MAX_ROWS = 5_000;

/** The export's column allowlist, in the order the file writes them. */
export const AUDIT_CSV_COLUMNS = [
  'seq',
  'createdAt',
  'adminId',
  'adminName',
  'action',
  'target',
  'reason',
  'ip',
  'userAgent',
  'stepUpUsed',
  'details',
  'beforeState',
  'afterState',
  'hash',
  'prevHash',
] as const;

/**
 * RFC 4180 quoting plus formula-injection neutralisation. CRLF line endings, as the RFC
 * requires, so the file opens correctly on every platform.
 */
export function csvField(value: unknown): string {
  if (value === null || value === undefined) return '';
  let text: string;
  if (typeof value === 'object') {
    // JSON subtrees go out compact and deterministic. An empty object is written as empty
    // rather than '{}' so a spreadsheet column stays readable.
    const keys = Object.keys(value as Record<string, unknown>);
    text = keys.length ? JSON.stringify(value) : '';
  } else if (value instanceof Date) {
    text = value.toISOString();
  } else if (typeof value === 'boolean') {
    text = value ? 'true' : 'false';
  } else {
    text = String(value);
  }
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  if (/["\r\n,]/.test(text)) text = `"${text.replace(/"/g, '""')}"`;
  return text;
}

export function toAuditCsv(rows: Array<Record<string, unknown>>): string {
  const header = AUDIT_CSV_COLUMNS.join(',');
  const body = rows.map((row) =>
    AUDIT_CSV_COLUMNS.map((column) => csvField(row[column])).join(','),
  );
  return [header, ...body].join('\r\n') + '\r\n';
}

function stepUpIsActive(req: Request): boolean {
  const stamped = (req as unknown as { platformStepUpExpiresAt?: Date | string | null })
    .platformStepUpExpiresAt;
  if (!stamped) return false;
  const at = stamped instanceof Date ? stamped.getTime() : new Date(stamped).getTime();
  return Number.isFinite(at) && at > Date.now();
}

function requireReason(value: unknown, action: string): string {
  const reason = typeof value === 'string' ? value.trim() : '';
  if (reason.length < MIN_ACTION_REASON_LENGTH) {
    throw new BadRequestException(`a reason of at least ${MIN_ACTION_REASON_LENGTH} characters is required to ${action}`);
  }
  return reason;
}

/**
 * PHASE R4 (R4.11) — the grant/extend dialogue, and why it is shaped this way.
 *
 * BEFORE R4, `currentPeriodEnd` was computed as `new Date(Date.now() + months * 30 days)` INSIDE
 * the POST handler. That made the brief's requirement impossible to satisfy: a modal cannot show
 * the administrator the end date the server will write, because the server derives it from the
 * clock at write time. Two taps a second apart wrote two different dates, and neither was the
 * date anyone had looked at. There was also no idempotency key, so a double tap on a phone —
 * which is the normal way people use phones — wrote two ledger rows and raised the alert twice.
 *
 * So the date is now QUOTED and then HONOURED:
 *   1. GET  gyms/:id/grant-quote   computes the end date with the same function the grant uses,
 *                                  and returns it. Read-only, no step-up: the modal needs it
 *                                  before the administrator commits to anything.
 *   2. the modal shows that exact date, and the administrator confirms or cancels.
 *   3. POST gyms/:id/grant-subscription carries the quoted date back, and the server WRITES THAT
 *      DATE, not a fresh computation. It is validated first: parseable, in the future, and within
 *      GRANT_QUOTE_TOLERANCE_MS of what the server would compute now. The tolerance is what stops
 *      the quote becoming an unvalidated input through which an administrator could write an
 *      arbitrary far-future end date; outside it the answer is 400 and the modal must re-quote.
 *
 * IDEMPOTENCY is stored in the append-only ledger rather than in Redis. Two reasons. Redis may be
 * down — R4.8 makes that an expected condition, not an exceptional one, and an idempotency store
 * that disappears during an outage is exactly when a double tap happens. And the ledger is the
 * record of the grant anyway, is append-only for every role including a superuser (PHASE R3 A1=a),
 * and cannot be edited to make a replay look like a first attempt. The key is written into the
 * audit row's details, and a grant begins by looking for a row that already carries it.
 *
 * The lookup and the write happen inside ONE transaction holding a pg_advisory_xact_lock keyed on
 * the idempotency key. Without the lock, two concurrent requests both look, both find nothing, and
 * both write — which is the race the owner asked to have proven closed.
 */
export const GRANT_QUOTE_TOLERANCE_MS = 15 * 60 * 1000;
export const GRANT_MONTHS_MAX = 36;
export const GRANT_TRIAL_DAYS_MAX = 365;
export const IDEMPOTENCY_KEY_MIN_LENGTH = 8;
export const IDEMPOTENCY_KEY_MAX_LENGTH = 128;
/** What public.platform_admin_set_subscription returns: the row as STORED. */
interface SubscriptionWriteRow {
  subscription_id: string;
  gym_id: string;
  tier: string;
  status: string;
  current_period_start: Date | null;
  current_period_end: Date;
  trial_end_date: Date | null;
}

/**
 * Turn the function's own validation errors into the HTTP answer an operator expects, instead of
 * leaking a 500 with a PL/pgSQL context trace. Each code is distinct so a log reader can tell a
 * missing gym from a soft-deleted one from an impossible date range.
 */
function translateSubscriptionWriteFailure(error: unknown, gymId: string): Error {
  const message = String((error as Error)?.message ?? error ?? '');
  if (message.includes('P4GYM')) return new NotFoundException('gym not found');
  if (message.includes('P4DEL')) {
    return new BadRequestException(
      `gym ${gymId} is soft-deleted; restore it before changing its subscription`,
    );
  }
  if (message.includes('P4END')) {
    return new BadRequestException('the quoted end date is not after the period start it would sit against');
  }
  if (message.includes('P4NOOP')) return new BadRequestException('nothing to change');
  if (message.includes('invalid input value for enum')) {
    return new BadRequestException('the plan or status is not a value this deployment recognises');
  }
  return error as Error;
}

const GRANT_PLANS = ['BASIC', 'PRO', 'ELITE'];

/**
 * PHASE R4 (R4.9) - the sortable columns of the gyms list, and the only two directions.
 *
 * Whitelisted here AND in the SQL CASE ladder inside platform_list_gyms, on purpose. The
 * controller check gives a clean 400 with a useful message; the database check is the one that
 * still holds if a future caller forgets, and it holds inside a SECURITY DEFINER function that
 * can see every tenant's rows - which is the last place an unvalidated string should reach.
 */
export const GYM_SORT_COLUMNS = ['createdAt', 'name', 'status', 'currentPeriodEnd', 'memberCount'] as const;
export const GYM_SORT_DIRECTIONS = ['asc', 'desc'] as const;
export const GYM_LIST_PAGE_SIZE = 25;

function clampSort(value: unknown): string {
  const sort = typeof value === 'string' ? value.trim() : '';
  if (!sort) return 'createdAt';
  if (!(GYM_SORT_COLUMNS as readonly string[]).includes(sort)) {
    throw new BadRequestException(`sort must be one of ${GYM_SORT_COLUMNS.join(', ')}`);
  }
  return sort;
}

function clampDirection(value: unknown): string {
  const dir = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!dir) return 'desc';
  if (!(GYM_SORT_DIRECTIONS as readonly string[]).includes(dir)) {
    throw new BadRequestException(`dir must be one of ${GYM_SORT_DIRECTIONS.join(', ')}`);
  }
  return dir;
}

/** The one definition of "months from now", used by both the quote and the grant. */
export function grantPeriodEnd(months: number, from: Date = new Date()): Date {
  return new Date(from.getTime() + months * 30 * 86400000);
}

/** The one definition of "days from now", used by both the trial quote and the extension. */
export function trialPeriodEnd(days: number, from: Date = new Date()): Date {
  return new Date(from.getTime() + days * 86400000);
}

function requireIdempotencyKey(value: unknown, action: string): string {
  const key = typeof value === 'string' ? value.trim() : '';
  if (key.length < IDEMPOTENCY_KEY_MIN_LENGTH || key.length > IDEMPOTENCY_KEY_MAX_LENGTH) {
    throw new BadRequestException(
      `an idempotency key of ${IDEMPOTENCY_KEY_MIN_LENGTH}-${IDEMPOTENCY_KEY_MAX_LENGTH} characters is required to ${action}`,
    );
  }
  return key;
}

function clampMonths(value: unknown): number {
  // Number.isInteger, not Math.floor. The first version floored, so months=1.5 quietly became a
  // one-month grant: the administrator asked for something the platform does not support and got
  // something else, with nothing telling them. With the 30-day-month convention a fractional
  // month has no meaning anyway, so the honest answer is 400. Found by the R4.11 spec, which
  // asserted rejection and got 201.
  const months = Number(value);
  if (!Number.isFinite(months) || !Number.isInteger(months) || months < 1 || months > GRANT_MONTHS_MAX) {
    throw new BadRequestException(`months must be a whole number between 1 and ${GRANT_MONTHS_MAX}`);
  }
  return months;
}

function clampTrialDays(value: unknown): number {
  // Same reasoning as clampMonths: a fractional day is refused rather than floored.
  const days = Number(value);
  if (!Number.isFinite(days) || !Number.isInteger(days) || days < 1 || days > GRANT_TRIAL_DAYS_MAX) {
    throw new BadRequestException(`days must be a whole number between 1 and ${GRANT_TRIAL_DAYS_MAX}`);
  }
  return days;
}

function clampPlan(value: unknown): string {
  const plan = typeof value === 'string' ? value.trim().toUpperCase() : '';
  if (!GRANT_PLANS.includes(plan)) {
    throw new BadRequestException(`plan must be one of ${GRANT_PLANS.join(', ')}`);
  }
  return plan;
}

/**
 * Honour the date the administrator was shown, after checking it is still a sane one.
 * Returns the exact Date to write.
 */
function resolveQuotedDate(quoted: unknown, expected: Date, action: string): Date {
  if (typeof quoted !== 'string' || !quoted.trim()) {
    throw new BadRequestException(
      `the quoted end date is required to ${action}: ask for a quote first so the administrator ` +
        'confirms the date that will actually be written',
    );
  }
  const parsed = new Date(quoted);
  if (Number.isNaN(parsed.getTime())) {
    throw new BadRequestException('the quoted end date is not a parseable timestamp');
  }
  if (parsed.getTime() <= Date.now()) {
    throw new BadRequestException('the quoted end date is in the past; request a fresh quote');
  }
  const drift = Math.abs(parsed.getTime() - expected.getTime());
  if (drift > GRANT_QUOTE_TOLERANCE_MS) {
    throw new BadRequestException(
      'the quoted end date no longer matches what the server would write (the quote is stale or ' +
        'was altered); request a fresh quote',
    );
  }
  return parsed;
}

/** R1.7: how long a created administrator waits for a second one to approve. */
export const APPROVAL_WINDOW_MS = 24 * 60 * 60 * 1000;
/** What the console's overview samples, unchanged from before R1 (LIMIT 50). */
const SUBSCRIPTION_SAMPLE_LIMIT = 50;
/** Row ceiling for the revenue month series, unchanged from before R1 (LIMIT 5000). */
const REVENUE_SERIES_ROW_LIMIT = 5000;

class ChangePlanDto { @IsIn(['BASIC', 'PRO', 'ELITE']) plan!: string; @IsOptional() @IsString() reason?: string; }
class CreatePlatformAdminDto { @IsString() name!: string; @IsEmail() email!: string; @PasswordStrength() password!: string; @IsIn(['PLATFORM_ADMIN', 'PLATFORM_VIEWER']) role!: string; }

/**
 * PHASE R2 / decision Q2. The exact row shape returned by
 * public.platform_list_gyms and public.platform_gym_detail
 * (20261107000000_platform_privacy_r2). Every column here was approved one by one:
 * gym identity, status and business contact details; per-branch AGGREGATE counts;
 * the OWNER user's name and phone; subscription tier, status and timing. Absent by
 * construction - and not merely omitted by a mapper - are taxId, theme, the WhatsApp
 * bot credentials, every stripe identifier, every credential column on User
 * (passwordHash, pinHash, twoFaSecret, twoFaBackupCodes, twoFaLastCode) and every
 * member row of any kind. The functions are SECURITY DEFINER and STABLE, pin
 * search_path, take typed parameters only and contain no dynamic SQL.
 */
interface GymPrivacyRow {
  gym_id: string; gym_name: string; gym_slug: string; gym_status: string;
  gym_email: string; gym_phone: string | null; gym_address: string | null;
  gym_logo: string | null; gym_accent_color: string | null;
  member_count: string | number | bigint; user_count: string | number | bigint; branch_count: string | number | bigint;
  owner_name: string | null; owner_phone: string | null;
  sub_tier: string | null; subscription_status: string | null;
  current_period_start: Date | null; current_period_end: Date | null;
  trial_start_date: Date | null; trial_end_date: Date | null;
  trial_days: number | null; is_trial_used: boolean | null; cancel_at_period_end: boolean | null;
  last_payment_at: Date | null; last_payment_amount: number | null;
  created_at: Date; updated_at: Date; deleted_at: Date | null;
}

interface SubscriptionPrivacyRow {
  subscription_id: string; gym_id: string; gym_name: string; gym_slug: string; gym_status: string;
  sub_tier: string | null; subscription_status: string | null;
  current_period_start: Date | null; current_period_end: Date | null;
  trial_start_date: Date | null; trial_end_date: Date | null;
  trial_days: number | null; is_trial_used: boolean | null;
  suspended_at: Date | null; cancelled_at: Date | null; grace_days: number | null;
  cancel_at_period_end: boolean | null;
  last_payment_at: Date | null; last_payment_amount: number | null;
  created_at: Date; updated_at: Date;
}

@ApiTags('platform')
@ApiBearerAuth()
@Controller('platform')
@PlatformRoute()
// PHASE R1 — JwtAuthGuard is GONE from this list. Authentication for every route
// here is done by the global PlatformSessionGuard (registered in app.module.ts),
// which only accepts a token signed with JWT_PLATFORM_SECRET that names a live
// PlatformSession row. Running the tenant strategy here as well is what made every
// console call 401 before R1: it resolved the platform subject against "User".
// PlatformAdminGuard stays, for the PLATFORM_VIEWER read-only rule.
@UseGuards(PlatformAdminGuard)
export class PlatformController {
  private readonly logger = new Logger('PlatformController');

  constructor(
    private readonly prisma: PrismaService,
    private readonly monitor: PlatformMonitorService,
    private readonly shield: SecurityShieldService,
    private readonly flags: FeatureFlagsService,
    private readonly sessions: PlatformSessionService,
    private readonly auditWriter: PlatformAuditService,
    private readonly alerts: PlatformAlertService,
    private readonly cache: PlatformCacheService,
    private readonly redisService: RedisService,
  ) {}

  /**
   * PHASE R4 (R4.22). This route had step-up but wrote NO audit row, so a feature flag could be
   * flipped for the whole platform - or for one gym - with nothing recording who did it or when.
   * Step-up proves the administrator was present; only the ledger proves what they did. The
   * response shape is unchanged: the audit row is written and the flag service's own result is
   * still what comes back, so no caller of this route has to change.
   */
  @Post('flags')
  @RequireStepUp('change a feature flag')
  async setFlag(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Body() dto: {
      flag: string;
      value: boolean;
      gymId?: string;
    },
  ) {
    const result = await this.flags.setFlag(dto.flag, dto.value, dto.gymId);
    await this.audit(req, 'flag:set', dto.flag, { value: dto.value, gymId: dto.gymId ?? null }, {
      beforeState: null,
      afterState: { value: dto.value },
    });
    return result;
  }

  @Get('flags')
  listFlags() {
    return this.flags.listFlags();
  }

  @Get('shield/blocked')
  getBlockedIps() {
    return this.shield.getBlockedIps();
  }

  /**
   * PHASE R4 (R4.22). Unblocking an IP is the one platform action that can silently undo a
   * security control, and it wrote no audit row at all: an administrator could lift a block on an
   * address that had been attacking the platform and there would be no record that it happened.
   * The blocked address is the audit TARGET, which is the same treatment the log already gives the
   * acting administrator's own IP - this is operational data about an attack, not member PII, and
   * the shield table already stores it.
   */
  @Delete('shield/blocked/:ip')
  @RequireStepUp('unblock an IP address')
  async unblockIp(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Param('ip') ip: string,
  ) {
    const result = await this.shield.unblockIp(ip);
    await this.audit(req, 'shield:unblock', ip, { scope: 'platform' }, {
      beforeState: { blocked: true },
      afterState: { blocked: false },
    });
    return result;
  }

  /**
   * PHASE R4 (R4.22) - same gap as unblock, in the other direction. The reason the administrator
   * typed is now a first-class `reason` column on the audit row rather than only an argument to
   * the shield service, so it survives in the append-only ledger and shows up in the console's
   * audit filters and CSV export.
   */
  @Post('shield/block')
  @RequireStepUp('block an IP address')
  async manualBlock(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Body() dto: { ip: string; reason: string },
  ) {
    const result = await this.shield.blockIp(dto.ip, 'platform', dto.reason);
    await this.audit(req, 'shield:block', dto.ip, { scope: 'platform' }, {
      reason: typeof dto?.reason === 'string' ? dto.reason : null,
      beforeState: { blocked: false },
      afterState: { blocked: true },
    });
    return result;
  }

  @Get('monitor/report')
  getWeeklyReport() {
    return this.monitor.weeklyPlatformReport();
  }

  @Get('monitor/security')
  getSecurityScan() {
    return this.monitor.getSecurityScan();
  }

  /**
   * PHASE R4 (R4.6/R4.7/R4.8) - the Overview aggregate, cached for 60 seconds.
   *
   * The cache is reported in a response HEADER rather than in the body, so the shape every
   * existing caller and test sees is unchanged: `x-flexora-cache` is `hit`, or `miss-<reason>`
   * where reason is one of miss (cold), timeout (Redis slower than the 250 ms bound) or
   * unavailable (Redis rejected). The console shows the operator whether they are looking at
   * cached data, and an operator debugging a Redis outage can see the fallback working without
   * reading a log.
   *
   * R4.8: a slow or dead Redis must neither hang nor fail this route. PHASE P3 already made the
   * command finite, but a rejection on a request path becomes a 503 through
   * DependencyUnavailableFilter - which would fail the page. PlatformCacheService catches it and
   * this route recomputes from the database instead.
   */
  @Get('overview')
  async overview(@Res({ passthrough: true }) res: Response) {
    const key = PLATFORM_CACHE_KEYS.overview;
    const cached = await this.cache.read<Record<string, unknown>>(key);
    res.setHeader('x-flexora-cache', cached.hit ? 'hit' : `miss-${cached.outcome}`);
    if (cached.hit && cached.value) return cached.value;
    const value = await this.computeOverview();
    await this.cache.write(key, value, PLATFORM_CACHE_TTL_SECONDS);
    return value;
  }

  /**
   * The seven aggregates, byte-for-byte the pre-R4 body: the cache wraps them and does not
   * alter what they compute.
   */
  private async computeOverview() {
    const now = new Date(); const monthStart = new Date(now.getFullYear(), now.getMonth(), 1); const prevStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    // CRITICAL FIX (F-027): Platform queries on RLS-protected tables (Member,
    // Subscription, Transaction) use $queryRaw to bypass the FORCE RLS policy.
    // Gym table has no RLS, so regular Prisma calls work fine.
    // PHASE R2 / decision Q6: a soft-deleted gym is not live platform activity.
    // totalGyms and activeGyms exclude status = DELETED, and deletedGyms reports how
    // many sit inside the 30-day restore window. Member and revenue aggregates ignore
    // DELETED gyms too, because the same migration rewrote platform_count_members()
    // and the revenue functions to join public."Gym" and exclude that status.
    const [totalGyms, activeGyms, deletedGyms, totalMembers, subs, revenue, prevRevenue] = await Promise.all([
      this.countGymRows(null, null, null),
      this.countGymRows('ACTIVE', null, null),
      this.countGymRows('DELETED', null, null),
      this.countAllMembers(),
      this.allSubscriptions(),
      this.sumRevenueSince(monthStart),
      this.sumRevenueBetween(prevStart, monthStart),
    ]);
    const planDistribution = { BASIC: 0, PRO: 0, ELITE: 0 } as Record<string, number>;
    for (const s of subs) planDistribution[String(s.tier)] = (planDistribution[String(s.tier)] || 0) + 1;
    const monthlyRevenue = Number(revenue || 0) / 100;
    const prev = Number(prevRevenue || 0) / 100;
    return { totalGyms, activeGyms, deletedGyms, totalMembers, totalRevenue: monthlyRevenue, monthlyRevenue, trialGyms: subs.filter((s) => s.status === 'TRIALING').length, paidGyms: subs.filter((s) => ['PRO','ELITE'].includes(s.tier)).length, churnedGyms: subs.filter((s) => s.status === 'CANCELED').length, planDistribution, memberGrowth: 0, revenueGrowth: prev ? Math.round(((monthlyRevenue - prev) / prev) * 100) : 0 };
  }

  // PHASE R4 (R4.6/R4.7) - the two series the Overview charts draw, cached the same way and
  // for the same 60 s. Keyed by month count so ?months=6 and ?months=12 cannot serve each
  // other's payload.
  @Get('revenue/chart')
  async revenueChart(@Query('months') months = 12, @Res({ passthrough: true }) res?: Response) {
    return this.cachedSeries(PLATFORM_CACHE_KEYS.revenueChart(Number(months)), Number(months), 'revenue', res);
  }

  /**
   * PHASE R4 (R4.12) - the revenue CSV.
   *
   * One query, not one per gym: platform_list_subscriptions is a set-returning function so it
   * belongs in FROM, and the per-gym income function is called on each of its rows inside the same
   * statement. Both are the R2 SECURITY DEFINER functions, so this runs with the runtime role's
   * privileges and never touches a FORCE-RLS table directly.
   *
   * RFC 4180 quoting and formula-injection neutralisation are the R3 csvField(), reused rather
   * than reimplemented - a second CSV writer is a second place to get quoting wrong, and the R3
   * mutation cycle already proves this one.
   */
  @Get('revenue/export')
  async exportRevenueCsv(
    @Res() res: Response,
    @Query('status') status?: string,
    @Query('plan') plan?: string,
  ) {
    const rows = await this.prisma.$queryRaw<
      Array<{
        gym_id: string;
        gym_name: string | null;
        gym_slug: string | null;
        gym_status: string | null;
        sub_tier: string | null;
        subscription_status: string | null;
        current_period_start: Date | null;
        current_period_end: Date | null;
        last_payment_at: Date | null;
        last_payment_amount: string | number | bigint | null;
        total_revenue: string | number | bigint | null;
      }>
    >`
      SELECT r.gym_id,
             r.gym_name,
             r.gym_slug,
             r.gym_status,
             r.sub_tier,
             r.subscription_status,
             r.current_period_start,
             r.current_period_end,
             r.last_payment_at,
             r.last_payment_amount,
             public.platform_sum_transaction_income_for_gym(r.gym_id)::text AS total_revenue
        FROM public.platform_list_subscriptions(
               ${status ?? null}::text,
               ${plan ?? null}::text,
               ${REVENUE_EXPORT_MAX_ROWS + 1}::integer,
               0::integer
             ) r`;

    // One row past the cap is fetched so truncation is a fact rather than a guess, and the
    // response says so in a header - the same contract as the audit export.
    const truncated = rows.length > REVENUE_EXPORT_MAX_ROWS;
    const capped = truncated ? rows.slice(0, REVENUE_EXPORT_MAX_ROWS) : rows;

    const toMajor = (value: string | number | bigint | null) =>
      value === null || value === undefined ? null : Number(value) / 100;

    const records = capped.map((row) => ({
      gymId: row.gym_id,
      gymName: row.gym_name,
      gymSlug: row.gym_slug,
      gymStatus: row.gym_status,
      tier: row.sub_tier,
      subscriptionStatus: row.subscription_status,
      currentPeriodStart: row.current_period_start,
      currentPeriodEnd: row.current_period_end,
      lastPaymentAt: row.last_payment_at,
      lastPaymentAmount: toMajor(row.last_payment_amount),
      totalRevenue: toMajor(row.total_revenue),
    }));

    const header = REVENUE_CSV_COLUMNS.join(',');
    const body = records.map((record) =>
      REVENUE_CSV_COLUMNS.map((column) => csvField((record as Record<string, unknown>)[column])).join(','),
    );
    const csv = [header, ...body].join('\r\n') + (body.length ? '\r\n' : '\r\n');

    const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="flexora-platform-revenue-${stamp}.csv"`);
    res.setHeader('X-Flexora-Revenue-Rows', String(records.length));
    res.setHeader('X-Flexora-Revenue-Truncated', truncated ? 'true' : 'false');
    res.status(200).send(csv);
  }


  @Get('gyms/growth')
  async gymGrowth(@Query('months') months = 12, @Res({ passthrough: true }) res?: Response) {
    return this.cachedSeries(PLATFORM_CACHE_KEYS.gymGrowth(Number(months)), Number(months), 'gyms', res);
  }

  private async cachedSeries(
    key: string,
    months: number,
    type: 'revenue' | 'gyms',
    res?: Response,
  ) {
    const cached = await this.cache.read<Array<{ month: string; value: number }>>(key);
    if (res) res.setHeader('x-flexora-cache', cached.hit ? 'hit' : `miss-${cached.outcome}`);
    if (cached.hit && cached.value) return cached.value;
    const value = await this.monthSeries(months, type);
    await this.cache.write(key, value, PLATFORM_CACHE_TTL_SECONDS);
    return value;
  }

  /**
   * PHASE R2 / decision Q2. The gyms list no longer returns whole Gym rows with their
   * subscription and their first user attached - that shape carried taxId, theme,
   * waBotToken, waBotPhoneId, four stripe identifiers and, for the gym's staff,
   * passwordHash, pinHash, twoFaSecret, twoFaBackupCodes and twoFaLastCode. It now
   * calls public.platform_list_gyms and maps the approved columns. The `plan` filter
   * moved into SQL, so a page and its total can no longer disagree the way they did
   * when the filter was applied in JS after pagination.
   */
  /**
   * PHASE R4 (R4.9) - search, filters, sort and SERVER-side pagination at 25 per page.
   *
   * The scope statement asks for 25 and this route defaulted to 20. The default is changed here
   * rather than only requesting 25 from the console, because a page size that differs between
   * what the api assumes and what the ui asks for is how the two drift. Any caller may still ask
   * for another size up to the existing cap of 100.
   *
   * Sorting happens inside platform_list_gyms, not after it returns: ordering one page of 25 in
   * JavaScript is not sorting, because page 2 would still hold rows that belong on page 1.
   */
  @Get('gyms')
  async listGyms(
    @Query('page') page = 1,
    @Query('limit') limit = GYM_LIST_PAGE_SIZE,
    @Query('search') search?: string,
    @Query('plan') plan?: string,
    @Query('status') status?: string,
    @Query('sort') sort?: string,
    @Query('dir') dir?: string,
  ) {
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(100, Math.max(1, Number(limit) || GYM_LIST_PAGE_SIZE));
    const sortColumn = clampSort(sort);
    const sortDirection = clampDirection(dir);
    const [rows, total] = await Promise.all([
      this.listGymRows(
        status ?? null,
        search ?? null,
        plan ?? null,
        limitNum,
        (pageNum - 1) * limitNum,
        sortColumn,
        sortDirection,
      ),
      this.countGymRows(status ?? null, search ?? null, plan ?? null),
    ]);
    return {
      items: rows.map((row) => this.mapGymRow(row)),
      total,
      page: pageNum,
      limit: limitNum,
      // Echoed so the console can render the active sort without keeping its own copy of the
      // whitelist, and so an operator reading a response can see what order it is in.
      sort: sortColumn,
      dir: sortDirection,
      sortColumns: [...GYM_SORT_COLUMNS],
    };
  }

  /**
   * PHASE R2 / decision Q2. Same reason as listGyms, and this route was worse: it
   * attached EVERY user of the gym, not just the first, so the whole staff roster with
   * its password hashes left the database. public.platform_gym_detail returns one row
   * with the approved columns and the owner's name and phone only. It applies no status
   * filter, so a gym inside the 30-day restore window is still readable and restorable.
   */
  @Get('gyms/:id')
  async getGym(@Param('id') id: string) {
    const rows = await this.gymDetailRows(id);
    if (!rows.length) throw new NotFoundException('gym not found');
    const revenue = await this.sumRevenueForGym(id);
    return { gym: this.mapGymRow(rows[0]), revenue: Number(revenue || 0) };
  }

  @Patch('gyms/:id/plan')
  @RequireStepUp('change a gym subscription plan')
  async updatePlan(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string, @Body() dto: ChangePlanDto) {
    // PHASE R4 - before/after both come from sanctioned paths now. The before-state read used to
    // be a direct prisma.subscription.findUnique, which returns NULL for the runtime role under
    // FORCE RLS, so this row's beforeState was silently empty in production.
    const before = await this.subscriptionSnapshot(id);
    const written = await this.setSubscription(this.prisma, id, {
      tier: String(dto.plan ?? ''),
      status: 'ACTIVE',
      // NULL on purpose: the function leaves an existing period end alone and, when it has to
      // create a row, defaults it to now() + 30 days - which is exactly what this route did
      // before, so the behaviour is preserved rather than reinvented.
      periodEnd: null,
    });
    return this.audit(req, 'gym:plan-change', id, dto, {
      beforeState: { tier: before.tier, status: before.status, currentPeriodEnd: before.currentPeriodEnd },
      // The STORED values, not the requested ones.
      afterState: {
        tier: written.tier,
        status: written.status,
        currentPeriodEnd: written.current_period_end ? new Date(written.current_period_end).toISOString() : null,
      },
    });
  }
  @Post('gyms/:id/suspend')
  @RequireStepUp('suspend a gym')
  async suspendGym(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string, @Body() dto: { reason: string }) {
    const before = await this.prisma.gym.findUnique({ where: { id }, select: { status: true } });
    await this.prisma.gym.update({ where: { id }, data: { status: 'SUSPENDED' as any } });
    return this.audit(req, 'gym:suspend', id, dto, {
      reason: dto?.reason ?? null,
      beforeState: { status: before ? String(before.status) : null },
      afterState: { status: 'SUSPENDED' },
    });
  }
  @Post('gyms/:id/reactivate')
  @RequireStepUp('reactivate a gym')
  async reactivateGym(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string) {
    const before = await this.prisma.gym.findUnique({ where: { id }, select: { status: true } });
    await this.prisma.gym.update({ where: { id }, data: { status: 'ACTIVE' as any } });
    return this.audit(req, 'gym:reactivate', id, {}, {
      beforeState: { status: before ? String(before.status) : null },
      afterState: { status: 'ACTIVE' },
    });
  }
  /**
   * PHASE R2 / decisions Q1 and Q3. Deleting a gym is a SOFT delete: status becomes
   * DELETED and deletedAt is stamped. The previous status is recorded in the audit row
   * because it is not stored anywhere else, and restoreGym reads it back so a gym on
   * trial does not come back as a paying gym. A reason of at least 8 characters is
   * required, exactly as for a suspension. Hard deletion is not reachable over HTTP at
   * all - it lives in prisma/purge-gym.ts, needs the database owner credential, refuses
   * until 30 days have passed, and refuses to run as the runtime role.
   */
  @Delete('gyms/:id')
  @RequireStepUp('delete a gym')
  async deleteGym(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string, @Body() dto: { reason?: string }) {
    const reason = requireReason(dto?.reason, 'delete a gym');
    const gym = await this.prisma.gym.findUnique({ where: { id }, select: { id: true, status: true, deletedAt: true } });
    if (!gym) throw new NotFoundException('gym not found');
    const deletedAt = new Date();
    await this.prisma.gym.update({ where: { id }, data: { status: 'DELETED' as any, deletedAt } });
    const row = await this.audit(
      req,
      'gym:delete-soft',
      id,
      { reason, previousStatus: String(gym.status) },
      {
        reason,
        beforeState: {
          status: String(gym.status),
          deletedAt: gym.deletedAt ? gym.deletedAt.toISOString() : null,
        },
        afterState: { status: 'DELETED', deletedAt: deletedAt.toISOString() },
      },
    );
    // R3.11 - the delete is soft and restorable for 30 days, but the owner hears about it
    // when it happens rather than finding it in a report later.
    await this.raiseAlert({
      type: 'GYM_DELETED',
      severity: 'warning',
      targetKind: 'gym',
      targetId: id,
      auditSeq: row.seq,
    });
    return row;
  }

  /**
   * PHASE R2 / decision Q1. The counterpart of the soft delete. Step-up plus a required
   * reason, and it clears deletedAt so the 30-day purge clock stops. The status the gym
   * had before deletion is restored from the audit trail; if that row cannot be found
   * the gym comes back as ACTIVE rather than failing, because a restorable gym must be
   * restorable.
   */
  @Post('gyms/:id/restore')
  @RequireStepUp('restore a deleted gym')
  async restoreGym(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string, @Body() dto: { reason?: string }) {
    const reason = requireReason(dto?.reason, 'restore a deleted gym');
    const gym = await this.prisma.gym.findUnique({ where: { id }, select: { id: true, status: true, deletedAt: true } });
    if (!gym) throw new NotFoundException('gym not found');
    if (String(gym.status) !== 'DELETED') throw new BadRequestException('gym is not deleted, so there is nothing to restore');
    const lastDelete = await this.prisma.platformAuditLog.findFirst({
      where: { action: 'gym:delete-soft', target: id },
      orderBy: { createdAt: 'desc' },
      select: { details: true },
    });
    const previous = (lastDelete?.details as { previousStatus?: string } | null)?.previousStatus;
    const restored = previous && ['ACTIVE', 'SUSPENDED', 'TRIAL'].includes(previous) ? previous : 'ACTIVE';
    await this.prisma.gym.update({ where: { id }, data: { status: restored as any, deletedAt: null } });
    return this.audit(req, 'gym:restore', id, { reason, restoredStatus: restored }, {
      reason,
      beforeState: { status: 'DELETED' },
      afterState: { status: restored, deletedAt: null },
    });
  }

  /**
   * PHASE R2 / decision Q2. The `include: { gym: true }` here was the third of the three
   * leaks deferred by 20261106000000_platform_auth_r1 section 7: it returned every Gym
   * column, taxId and the WhatsApp bot token among them. It now calls
   * public.platform_list_subscriptions, which embeds only the gym's id, name, slug and
   * status. This route is also why the console showed an empty list before R2:
   * Subscription is FORCE RLS, so the runtime role saw nothing, while the definer
   * function reads as its owner and returns the platform-wide truth.
   */
  @Get('subscriptions/console')
  async subscriptionConsole(
    @Query('page') page = 1, @Query('search') search?: string,
    @Query('status') status?: string, @Query('plan') plan?: string,
    @Query('window') window?: string, @Query('dir') dir?: string,
  ) {
    const pageNum = Math.max(1, Math.floor(Number(page) || 1));
    const direction = dir === 'desc' ? 'desc' : 'asc';
    const statusValue = ['TRIALING', 'ACTIVE', 'EXPIRED', 'CANCELED', 'SUSPENDED', 'PAST_DUE'].includes(status ?? '') ? status : null;
    const planValue = ['BASIC', 'PRO', 'ELITE'].includes(plan ?? '') ? plan : null;
    const windowValue = ['ending7', 'expired'].includes(window ?? '') ? window : null;
    const searchValue = search?.trim().slice(0, 100) || null;
    const query = (offset: number) => this.prisma.$queryRaw<Array<{
      gym_id: string; gym_name: string; gym_status: string; gym_email: string; gym_phone: string;
      owner_name: string | null; owner_phone: string | null; tier: string | null;
      subscription_status: string | null; start_date: Date | null; end_date: Date | null;
      trial_days: number | null; last_payment_at: Date | null; last_payment_amount: number | null;
      last_grant_at: Date | null; effective_status: string | null; total: bigint;
    }>>`SELECT * FROM public.platform_subscription_console(${searchValue}::text, ${statusValue ?? null}::text,
      ${planValue ?? null}::text, ${windowValue ?? null}::text, ${direction}::text, ${25}::integer, ${offset}::integer)`;
    const rows = await query((pageNum - 1) * 25);
    const countRows = rows.length || pageNum === 1 ? rows : await query(0);
    return { page: pageNum, limit: 25, total: Number(countRows[0]?.total ?? 0), items: rows.map((r) => ({
      gymId: r.gym_id, gymName: r.gym_name, gymStatus: r.gym_status, gymEmail: r.gym_email,
      gymPhone: r.gym_phone, ownerName: r.owner_name, ownerPhone: r.owner_phone,
      tier: r.tier, status: r.subscription_status, effectiveStatus: r.effective_status,
      startDate: r.start_date, endDate: r.end_date, trialDays: r.trial_days,
      lastPaymentAt: r.last_payment_at, lastPaymentAmount: r.last_payment_amount,
      lastGrantAt: r.last_grant_at,
    })) };
  }

  @Get('subscriptions')
  async listSubscriptions(@Query('page') page = 1, @Query('limit') limit = 20, @Query('status') status?: string, @Query('plan') plan?: string) {
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(100, Math.max(1, Number(limit) || 25));
    const [rows, total] = await Promise.all([
      this.listSubscriptionRows(status ?? null, plan ?? null, limitNum, (pageNum - 1) * limitNum),
      this.countSubscriptionRows(status ?? null, plan ?? null),
    ]);
    return { items: rows.map((row) => this.mapSubscriptionRow(row)), total, page: pageNum, limit: limitNum };
  }
  /**
   * PHASE R4 (R4.11) - the quote the extend-trial modal shows BEFORE the administrator confirms.
   * Read-only, so no step-up: nothing is written and no date is committed to.
   */
  @Get('gyms/:id/trial-quote')
  async trialQuote(@Param('id') id: string, @Query('days') days?: string) {
    const gym = await this.prisma.gym.findUnique({ where: { id }, select: { id: true, name: true, status: true } });
    if (!gym) throw new NotFoundException('gym not found');
    const trialDays = clampTrialDays(days ?? 7);
    const current = await this.prisma.subscription.findUnique({
      where: { gymId: id },
      select: { status: true, trialEndDate: true },
    });
    return {
      gymId: id,
      gymName: gym.name,
      days: trialDays,
      trialEndDate: trialPeriodEnd(trialDays).toISOString(),
      currentStatus: current ? String(current.status) : null,
      currentTrialEndDate: current?.trialEndDate ? current.trialEndDate.toISOString() : null,
      reasonMinLength: MIN_ACTION_REASON_LENGTH,
      quoteToleranceMs: GRANT_QUOTE_TOLERANCE_MS,
    };
  }

  @Post('gyms/:id/extend-trial')
  @RequireStepUp('extend a gym trial')
  async extendTrial(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Param('id') id: string,
    @Body() dto: { days?: number; reason?: string; idempotencyKey?: string; quotedTrialEndDate?: string },
    @Res({ passthrough: true }) res: Response,
  ) {
    // R4.11: the reason is REQUIRED. requireReason already existed and grant/extend simply did
    // not call it, so `dto?.reason ?? null` let an administrator extend a trial with no recorded
    // justification at all - the exact gap an audit trail is supposed to prevent.
    const reason = requireReason(dto?.reason, 'extend a trial');
    const key = requireIdempotencyKey(dto?.idempotencyKey, 'extend a trial');
    const days = clampTrialDays(dto?.days ?? 7);
    const trialEndDate = resolveQuotedDate(dto?.quotedTrialEndDate, trialPeriodEnd(days), 'extend a trial');
    const action = 'gym:extend-trial';

    // Read the before-state OUTSIDE the transaction: the root client must not be called from
    // inside a $transaction, and the definer read needs no part of the write's atomicity.
    const before = await this.subscriptionSnapshot(id);

    const outcome = await this.prisma.$transaction(async (tx) => {
      // Serialise every attempt that carries this key. hashtextextended gives a bigint lock key;
      // a collision would only make two unrelated grants wait for each other, never merge.
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${`${action}|${id}|${key}`}, 0))`;
      const prior = await tx.platformAuditLog.findFirst({
        where: { action, target: id, details: { path: ['idempotencyKey'], equals: key } },
        orderBy: { seq: 'desc' },
      });
      if (prior) return { row: prior, replayed: true, written: null };

      // PHASE R4 - through the sanctioned write function. A direct tx.subscription.update here
      // is refused by FORCE RLS for the runtime role (42501), which is the defect this migration
      // closes. `before` was read OUTSIDE this transaction, because calling the root client from
      // inside a $transaction is forbidden in this codebase and would use a different connection.
      const written = await this.setSubscription(tx, id, {
        status: 'TRIALING',
        trialEnd: trialEndDate,
      });
      const row = await this.auditWriter.recordInTransaction(tx, {
        adminId: req.user.sub,
        adminName: req.user.name || req.user.email,
        action,
        target: id,
        details: { days, idempotencyKey: key },
        reason,
        ip: req.ip ?? null,
        userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null,
        stepUpUsed: stepUpIsActive(req),
        beforeState: { status: before.status, trialEndDate: before.trialEndDate },
        // The STORED value: this is what makes "the date you confirmed is the date that landed"
        // provable from the ledger rather than merely intended by the code.
        afterState: {
          status: written.status,
          trialEndDate: written.trial_end_date ? new Date(written.trial_end_date).toISOString() : null,
          days,
        },
      });
      return { row, replayed: false };
    });

    res.setHeader('x-flexora-idempotent', outcome.replayed ? 'replayed' : 'applied');
    if (!outcome.replayed) {
      await this.raiseAlert({
        type: 'SUBSCRIPTION_GRANTED',
        severity: 'info',
        targetKind: 'subscription',
        targetId: id,
        auditSeq: outcome.row.seq,
      });
    }
    return { ...outcome.row, idempotent: outcome.replayed ? 'replayed' : 'applied' };
  }
  /**
   * PHASE R4 (R4.11) - the quote the grant modal shows BEFORE the administrator confirms.
   *
   * Read-only and deliberately NOT step-up protected: nothing is written, and the whole point is
   * that the administrator sees the resulting end date before committing to it. The same
   * grantPeriodEnd() the POST uses computes it, so the two cannot disagree by construction.
   */
  @Get('gyms/:id/grant-quote')
  async grantQuote(@Param('id') id: string, @Query('plan') plan?: string, @Query('months') months?: string) {
    const gym = await this.prisma.gym.findUnique({ where: { id }, select: { id: true, name: true, status: true } });
    if (!gym) throw new NotFoundException('gym not found');
    const tier = clampPlan(plan ?? 'BASIC');
    const grantedMonths = clampMonths(months ?? 1);
    const current = await this.prisma.subscription.findUnique({
      where: { gymId: id },
      select: { tier: true, status: true, currentPeriodEnd: true },
    });
    return {
      gymId: id,
      gymName: gym.name,
      gymStatus: String(gym.status),
      plan: tier,
      months: grantedMonths,
      // The date the modal will show and the grant will write.
      currentPeriodEnd: grantPeriodEnd(grantedMonths).toISOString(),
      currentTier: current ? String(current.tier) : null,
      currentStatus: current ? String(current.status) : null,
      previousPeriodEnd: current?.currentPeriodEnd ? current.currentPeriodEnd.toISOString() : null,
      reasonMinLength: MIN_ACTION_REASON_LENGTH,
      quoteToleranceMs: GRANT_QUOTE_TOLERANCE_MS,
    };
  }

  @Post('gyms/:id/grant-subscription')
  @RequireStepUp('grant a gym subscription')
  async grantSubscription(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Param('id') id: string,
    @Body() dto: { plan?: string; months?: number; reason?: string; idempotencyKey?: string; quotedPeriodEnd?: string },
    @Res({ passthrough: true }) res: Response,
  ) {
    // R4.11 - the reason is REQUIRED, and requireReason (which already existed) is now actually
    // called. Before R4 this handler took `dto?.reason ?? null`, so a grant of free subscription
    // time could be written to the ledger with no justification recorded at all.
    const reason = requireReason(dto?.reason, 'grant a subscription');
    const key = requireIdempotencyKey(dto?.idempotencyKey, 'grant a subscription');
    const plan = clampPlan(dto?.plan);
    const months = clampMonths(dto?.months ?? 1);
    // The date the administrator was shown, validated and then written verbatim.
    const currentPeriodEnd = resolveQuotedDate(dto?.quotedPeriodEnd, grantPeriodEnd(months), 'grant a subscription');
    const action = 'gym:grant-subscription';

    const before = await this.subscriptionSnapshot(id);

    const outcome = await this.prisma.$transaction(async (tx) => {
      // One transaction, one advisory lock keyed on the idempotency key: the ledger lookup and
      // the ledger write must not be separable, or two concurrent taps both see "not yet
      // granted" and both grant. This is the race the owner asked to have proven closed.
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${`${action}|${id}|${key}`}, 0))`;
      const prior = await tx.platformAuditLog.findFirst({
        where: { action, target: id, details: { path: ['idempotencyKey'], equals: key } },
        orderBy: { seq: 'desc' },
      });
      if (prior) return { row: prior, replayed: true };

      // PHASE R4 - through the sanctioned write function, for the same reason as extend-trial.
      // The quoted end date goes in verbatim and what comes back is what gets audited.
      const written = await this.setSubscription(tx, id, {
        tier: plan,
        status: 'ACTIVE',
        periodEnd: currentPeriodEnd,
      });
      const row = await this.auditWriter.recordInTransaction(tx, {
        adminId: req.user.sub,
        adminName: req.user.name || req.user.email,
        action,
        target: id,
        // The key lives in the ledger row: that is what makes the ledger the idempotency store,
        // and it means a replay can be audited after the fact by anyone reading the log.
        details: { plan, months, idempotencyKey: key },
        reason,
        ip: req.ip ?? null,
        userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null,
        stepUpUsed: stepUpIsActive(req),
        beforeState: {
          tier: before.tier,
          status: before.status,
          currentPeriodEnd: before.currentPeriodEnd,
        },
        // The STORED values, read back out of the row the function wrote. If the database and the
        // quote ever disagreed, this is where it would show - and r4-grant-idempotency.spec.ts
        // compares the ledger's value against the string the quote route returned.
        afterState: {
          tier: written.tier,
          status: written.status,
          currentPeriodEnd: new Date(written.current_period_end).toISOString(),
          months,
        },
      });
      return { row, replayed: false };
    });

    // Reported in a header AND the body, so the console can tell the administrator that the
    // second tap did nothing rather than leaving them to guess.
    res.setHeader('x-flexora-idempotent', outcome.replayed ? 'replayed' : 'applied');
    if (!outcome.replayed) {
      // R3.11 - a subscription granted by hand is money the platform did not collect, so the
      // owner is told. Only on the FIRST application: a replay must not alert a second time.
      await this.raiseAlert({
        type: 'SUBSCRIPTION_GRANTED',
        severity: 'info',
        targetKind: 'subscription',
        targetId: id,
        auditSeq: outcome.row.seq,
      });
    }
    return { ...outcome.row, idempotent: outcome.replayed ? 'replayed' : 'applied' };
  }

  @Get('admins') listAdmins(@Query('status') status?: string) {
    // status is exposed so a second administrator can see what is waiting for
    // approval. No hash, no TOTP state, no session token is ever selected.
    return this.prisma.platformAdmin.findMany({
      where: status ? { status } : {},
      select: { id: true, name: true, email: true, role: true, status: true, lastLoginAt: true, createdAt: true, requestedBy: true, approvalExpiresAt: true, totpEnabled: true },
      orderBy: { createdAt: 'asc' },
      take: 50,
    });
  }
  @Post('admins')
  @RequireStepUp('create a console administrator')
  /**
   * R1.7 — no public admin creation, and a second administrator must approve.
   * Step-up is enforced by @RequireStepUp above. The password is hashed with the
   * shared PASSWORD_HASH_OPTIONS (before R1 this called bare argon2.hash, so an
   * admin created here was hashed differently from one created by
   * `npm run bootstrap:admin`) and the platform policy of at least 16 characters
   * applies on top of the tenant-wide @PasswordStrength() decorator.
   *
   * A newly created administrator starts in PENDING_APPROVAL and cannot log in
   * until a DIFFERENT active administrator approves, within 24 hours. The very
   * first administrator of a deployment is created by the CLI, not here, so this
   * path always has somebody to ask.
   */
  async createAdmin(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Body() dto: CreatePlatformAdminDto) {
    const email = String(dto.email || '').trim().toLowerCase();
    if (!email) throw new BadRequestException('email is required');
    const policyProblem = platformPasswordProblem(String(dto.password || ''));
    if (policyProblem) throw new BadRequestException(policyProblem);
    const existing = await this.prisma.platformAdmin.findUnique({ where: { email } });
    if (existing) throw new BadRequestException('an administrator with that email already exists');

    const approvalExpiresAt = new Date(Date.now() + APPROVAL_WINDOW_MS);
    const admin = await this.prisma.platformAdmin.create({
      data: {
        name: dto.name,
        email,
        role: dto.role || 'PLATFORM_VIEWER',
        passwordHash: await hashPassword(String(dto.password)),
        status: 'PENDING_APPROVAL',
        requestedBy: req.user.sub,
        approvalExpiresAt,
        // Cannot log in until approved: the login path refuses any status other
        // than ACTIVE, so this is defence in depth rather than the only gate.
        mustChangePassword: true,
      },
    });
    const createdRow = await this.audit(
      req,
      'admin:create-pending',
      admin.id,
      { email, role: admin.role, requestedBy: req.user.sub, approvalExpiresAt: approvalExpiresAt.toISOString() },
      { afterState: { status: String(admin.status), role: String(admin.role) } },
    );
    // R3.11 - creating a console administrator is the most consequential thing anyone can do
    // in here, so the owner is told even though the new record cannot log in until it is
    // approved. Approval is audited as admin:approved and shown on the Admins page; it raises
    // no second alert, because A3.5's dedupe window would collapse it anyway and telling the
    // owner twice about one administrator is noise, not safety.
    await this.raiseAlert({
      type: 'ADMIN_CREATED',
      severity: 'warning',
      targetKind: 'admin',
      targetId: admin.id,
      auditSeq: createdRow.seq,
    });
    return { id: admin.id, status: admin.status, approvalExpiresAt };
  }

  /** R1.7 — the second administrator approves a pending one, with step-up. */
  @Post('admins/:id/approve')
  @RequireStepUp('approve a console administrator')
  async approveAdmin(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string) {
    const target = await this.prisma.platformAdmin.findUnique({ where: { id } });
    if (!target) throw new BadRequestException('admin-not-found');
    if (target.status === 'ACTIVE') return { id, status: target.status, alreadyActive: true };
    if (target.status !== 'PENDING_APPROVAL') throw new BadRequestException(`admin status ${target.status} cannot be approved`);
    if (target.requestedBy === req.user.sub) throw new BadRequestException('cannot-approve-own-request');
    if (target.approvalExpiresAt && target.approvalExpiresAt.getTime() <= Date.now()) {
      await this.audit(req, 'admin:approval-expired', id, { requestedBy: target.requestedBy });
      throw new BadRequestException('approval-window-expired');
    }
    const approved = await this.prisma.platformAdmin.update({
      where: { id },
      data: { status: 'ACTIVE', approvedBy: req.user.sub, approvedAt: new Date() },
    });
    await this.audit(req, 'admin:approved', id, { email: approved.email, role: approved.role });
    return { id: approved.id, status: approved.status };
  }
  @Delete('admins/:id')
  @RequireStepUp('remove a console administrator')
  /**
   * R1.7 — removal needs step-up (above) and revokes every session the removed
   * administrator holds, so the removal takes effect on their next request rather
   * than when their eight-hour token expires. The row itself is still deleted, as
   * it was before R1: turning that into a soft delete would change what stored data
   * means, which needs the owner's decision rather than a quiet edit.
   */
  async removeAdmin(@Req() req: Request & { user: { sub: string; name?: string; email: string } }, @Param('id') id: string) {
    if (req.user.sub === id) return { error: 'cannot-remove-self' };
    const target = await this.prisma.platformAdmin.findUnique({ where: { id } });
    if (!target) throw new BadRequestException('admin-not-found');
    const remaining = await this.prisma.platformAdmin.count({ where: { status: 'ACTIVE' } });
    if (remaining <= 1 && target.status === 'ACTIVE') throw new BadRequestException('cannot-remove-last-active-admin');
    const revoked = await this.sessions.revokeAllForAdmin(id, 'admin-removed');
    await this.prisma.platformAdmin.delete({ where: { id } });
    const removedRow = await this.audit(
      req,
      'admin:delete',
      id,
      { email: target.email, sessionsRevoked: revoked.count },
      {
        beforeState: { status: String(target.status), role: String(target.role) },
        afterState: { status: 'DELETED' },
      },
    );
    await this.raiseAlert({
      type: 'ADMIN_REMOVED',
      severity: 'warning',
      targetKind: 'admin',
      targetId: id,
      auditSeq: removedRow.seq,
    });
    return removedRow;
  }

  /**
   * PHASE R4 (R4.13) - a Health page has to report something true.
   *
   * BEFORE: `{ database: 'connected', redis: 'unknown', uptime, version }`. The database field
   * was a literal string that was true whether or not the database was reachable, and redis was
   * the literal word 'unknown' - so a Health page built on it would have been decoration, and the
   * one thing an owner opens a health page for is the one thing it could not tell them.
   *
   * Now each dependency is actually probed. Both probes are BOUNDED, for the reason R4.8
   * established: PHASE P3 makes every Redis command finite but a rejection on a request path
   * becomes a 503 through DependencyUnavailableFilter, so an unbounded or uncaught probe would
   * turn "Redis is down" into "the health page is down" - which is precisely when an operator
   * needs it. The bound is the cache's, reused rather than reinvented.
   *
   * It also reports the two things this console exists to keep honest: whether the audit chain
   * verifies, and whether the owner alert channel is configured. A green database with a broken
   * chain or a silent alert channel is not a healthy platform.
   */
  @Get('health')
  async health() {
    const startedAt = Date.now();

    const database = await (async () => {
      const at = Date.now();
      try {
        await this.prisma.$queryRaw`SELECT 1`;
        return { status: 'ok' as const, latencyMs: Date.now() - at };
      } catch (error) {
        return {
          status: 'error' as const,
          latencyMs: Date.now() - at,
          // The error CODE and class, never the message: a driver message can carry a
          // connection string, and this response is read in a browser.
          code: (error as { code?: string })?.code ?? 'unknown',
        };
      }
    })();

    const redis = await (async () => {
      const at = Date.now();
      try {
        const pong = await Promise.race([
          this.redisService.client.ping(),
          new Promise<string>((_resolve, reject) =>
            setTimeout(() => reject(new Error('bound')), PLATFORM_CACHE_REDIS_BOUND_MS),
          ),
        ]);
        return { status: pong === 'PONG' ? ('ok' as const) : ('degraded' as const), latencyMs: Date.now() - at };
      } catch {
        // 'unavailable' covers both a rejection (P3: enableOfflineQueue is false, so a command
        // issued while disconnected rejects at once) and the bound firing.
        return { status: 'unavailable' as const, latencyMs: Date.now() - at };
      }
    })();

    // Read-only and cheap, but it is the single most important line on the page: if the audit
    // log does not verify, nothing else about the platform's integrity can be trusted.
    let audit: Record<string, unknown> = { status: 'unknown' };
    try {
      const rows = await this.prisma.$queryRaw<
        Array<{ valid: boolean; rows_checked: number; broken_rows: number; head_seq: number | null }>
      >`SELECT valid, rows_checked::integer, broken_rows::integer, head_seq::integer FROM public.platform_audit_verify()`;
      audit = {
        status: rows[0]?.valid ? 'ok' : 'broken',
        rowsChecked: Number(rows[0]?.rows_checked ?? 0),
        brokenRows: Number(rows[0]?.broken_rows ?? 0),
        headSeq: rows[0]?.head_seq === null || rows[0]?.head_seq === undefined ? null : Number(rows[0].head_seq),
      };
    } catch {
      audit = { status: 'unavailable' };
    }

    const channel = this.alerts.channelState();
    const ok = database.status === 'ok' && audit.status !== 'broken';

    return {
      // 'ok' means the platform can serve and its record is intact. Redis being down is NOT a
      // failure: every cache path falls back to the database, so the platform is degraded and
      // still correct. That distinction is the whole of R4.8 and it is why this field is not
      // simply "are all the dependencies green".
      status: ok ? 'ok' : 'degraded',
      database,
      redis,
      audit,
      alertChannel: { configured: channel.configured, missing: channel.missing },
      uptimeSeconds: Math.round(process.uptime()),
      checkedInMs: Date.now() - startedAt,
      version: process.env.npm_package_version ?? null,
    };
  }
  @Get('errors') recentErrors(@Query('limit') limit = 50) { return this.prisma.platformAuditLog.findMany({ where: { action: { contains: 'fail', mode: 'insensitive' } }, take: Number(limit), orderBy: { createdAt: 'desc' } }); }
  /**
   * PHASE R3 (R3.7). Before this the route accepted page, limit, adminId and action only
   * (work/r3-evidence/00-before.log, B5), and it returned a bare array, so the console could
   * not tell how many pages there were. It now also filters by target, by a date range and by
   * free text, and returns rows with a total.
   *
   * RESPONSE SHAPE CHANGE, stated plainly because rule 0.2 requires it: the body went from a
   * JSON array to { rows, total, page, limit, chainHead }. The only consumer is the console
   * page for this route, which R3.8 rewrites in the same phase, and no test asserted the old
   * shape (r1-platform-auth.spec.ts and r2-platform-pii-crawl.spec.ts check the status only).
   *
   * Free-text search runs over action, target, adminName and reason with `contains`. It is
   * deliberately NOT run over details or beforeState/afterState: those are JSON, a substring
   * match on them is a full scan of every row, and searching them would let a query string
   * probe the contents of a state blob.
   */
  @Get('audit-log')
  async auditLog(
    @Query('page') page = 1,
    @Query('limit') limit = 50,
    @Query('adminId') adminId?: string,
    @Query('action') action?: string,
    @Query('target') target?: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('search') search?: string,
  ) {
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.min(100, Math.max(1, Number(limit) || 50));
    const where = buildAuditWhere({ adminId, action, target, from, to, search });
    const [rows, total, head] = await this.prisma.$transaction([
      this.prisma.platformAuditLog.findMany({
        where,
        skip: (pageNum - 1) * limitNum,
        take: limitNum,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.platformAuditLog.count({ where }),
      // Cheap enough to include on every page and it is what lets the console show the head
      // of the chain without running a full verification.
      this.prisma.platformAuditLog.findFirst({
        orderBy: { seq: 'desc' },
        select: { seq: true, hash: true },
      }),
    ]);
    return {
      rows,
      total,
      page: pageNum,
      limit: limitNum,
      chainHead: head ? { seq: head.seq, hash: head.hash } : null,
    };
  }

  /**
   * PHASE R3 (R3.8) - verify the audit hash chain.
   *
   * platform_audit_verify() is SECURITY INVOKER and STABLE, so it reads with the
   * connecting role's own privileges and adds nothing to the definer-owner compatibility
   * class. It recomputes every row's hash from the stored columns and compares it with the
   * stored hash, then compares each row's prevHash with the hash of the row before it, and
   * reports the LOWEST seq with a problem so an operator is sent to the earliest point the
   * log stopped being trustworthy.
   *
   * THE TAIL-TRUNCATION CROSS-CHECK. A hash chain detects a changed row and a row removed
   * from the middle, but removing rows from the END leaves a valid shorter chain - measured
   * in work/r3-evidence/02-migration-verified.log case (iv): delete seq 8 of 8 and the
   * function reports valid=true, head_seq=7. Only a superuser who has explicitly bypassed
   * the append-only trigger can do it. So this route additionally compares head_seq against
   * the highest auditSeq any PlatformAlert references (A3.7 stores it): an alert that cites
   * seq 40 proves the chain reached 40, and a head_seq below that means rows were removed.
   * A period with no alerts has no such anchor, which is recorded as a residual risk rather
   * than presented as a guarantee.
   *
   * Read-only and reveals only counts and digests, so it does not require step-up.
   */
  @Get('audit-log/verify')
  async verifyAuditChain() {
    const rows = await this.prisma.$queryRaw<
      Array<{
        rows_checked: number;
        valid: boolean;
        broken_rows: number;
        first_broken_seq: number | null;
        first_broken_id: string | null;
        first_broken_reason: string | null;
        head_seq: number | null;
        head_hash: string | null;
        genesis_hash: string;
      }>
    >`SELECT * FROM public.platform_audit_verify()`;
    const chain = rows[0];
    if (!chain) throw new InternalServerErrorException('audit chain verification returned no row');

    const alerted = await this.prisma.platformAlert.aggregate({ _max: { auditSeq: true } });
    const maxAlertedSeq = alerted._max.auditSeq ?? null;
    const headSeq = chain.head_seq ?? null;
    const tailTruncated =
      maxAlertedSeq !== null && headSeq !== null && Number(headSeq) < Number(maxAlertedSeq);

    // Three claims, kept separate because they fail for different reasons and an operator
    // must be able to tell them apart:
    //   chainValid    - every row that exists matches its digest and its predecessor.
    //   tailTruncated - something cites a chain position above the head, so rows are
    //                   missing from the END. This is the one thing a hash chain cannot see
    //                   by itself, and the anchor is an alert's auditSeq (A3.7).
    //   valid         - both. This is the verdict the console shows.
    //
    // CONSEQUENCE, stated because measuring it is what exposed it: any legitimate operation
    // that removes audit rows - an archive, a retention job, a fixture cleanup using the
    // documented superuser bypass - must also remove or re-anchor the alerts that cite the
    // rows it took, or this route will (correctly, by its own rule) report missing rows.
    // There is no retention job in the product today; when one is added it owns that duty.
    return {
      chainValid: chain.valid === true,
      tailTruncated,
      valid: chain.valid === true && !tailTruncated,
      rowsChecked: Number(chain.rows_checked),
      brokenRows: Number(chain.broken_rows),
      firstBrokenSeq: chain.first_broken_seq === null ? null : Number(chain.first_broken_seq),
      firstBrokenId: chain.first_broken_id,
      firstBrokenReason: chain.first_broken_reason,
      headSeq,
      headHash: chain.head_hash,
      genesisHash: chain.genesis_hash,
      maxAlertedSeq,
      checkedAt: new Date().toISOString(),
    };
  }

  /**
   * PHASE R3 (R3.7) - CSV export of the audit log.
   *
   * The columns are an explicit ALLOWLIST, not a projection of the row: the R2 residual
   * risk list records that the PII crawl covered response bodies but not this export, so
   * the export gets its own allowlist and the crawl is extended to cover the downloaded
   * body (R3.17). A column that is not named here does not reach the file, which is what
   * makes the allowlist the control rather than a comment.
   *
   * Formula injection is neutralised: a cell beginning with =, +, -, @, a tab or a carriage
   * return is prefixed with an apostrophe, because Excel and LibreOffice evaluate such a
   * cell as a formula and an administrator's free-text reason is attacker-influenced.
   *
   * Bounded at AUDIT_EXPORT_MAX_ROWS rows so a full-history download cannot exhaust the
   * api's memory; use the date range for anything larger.
   */
  @Get('audit-log/export')
  async exportAuditCsv(
    @Res() res: Response,
    @Query('adminId') adminId?: string,
    @Query('action') action?: string,
    @Query('target') target?: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('search') search?: string,
  ) {
    const where = buildAuditWhere({ adminId, action, target, from, to, search });
    const rows = await this.prisma.platformAuditLog.findMany({
      where,
      orderBy: { seq: 'asc' },
      take: AUDIT_EXPORT_MAX_ROWS,
      select: {
        seq: true,
        createdAt: true,
        adminId: true,
        adminName: true,
        action: true,
        target: true,
        reason: true,
        ip: true,
        userAgent: true,
        stepUpUsed: true,
        details: true,
        beforeState: true,
        afterState: true,
        hash: true,
        prevHash: true,
      },
    });
    const total = await this.prisma.platformAuditLog.count({ where });
    const csv = toAuditCsv(rows);
    const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="flexora-platform-audit-${stamp}.csv"`,
    );
    // The count is in a header rather than a trailing row, so the file stays valid CSV for
    // a spreadsheet and an operator can still see whether the export was truncated.
    res.setHeader('X-Flexora-Audit-Rows', String(rows.length));
    res.setHeader('X-Flexora-Audit-Matching', String(total));
    res.setHeader('X-Flexora-Audit-Truncated', total > rows.length ? 'true' : 'false');
    res.status(200).send(csv);
  }

  /**
   * PHASE R3 (R3.10) - the alert list. The stored columns and nothing more: no message body
   * (there is none, it is rendered at send time), no phone number, no raw provider error.
   * The response carries the channel state so the console can show the A3.4 warning about a
   * missing channel on the same screen as the alerts that could not be delivered.
   */
  @Get('alerts')
  async listAlerts(
    @Query('page') page = 1,
    @Query('limit') limit = 25,
    @Query('type') type?: string,
    @Query('status') status?: string,
  ) {
    return this.alerts.listForConsole({ page: Number(page), limit: Number(limit), type, status });
  }

  /**
   * PHASE R3 - make a NO_CHANNEL or FAILED alert deliverable again, for the operator who
   * has just configured PLATFORM_OWNER_PHONE and does not want to wait for the next event to
   * find out whether it worked. A SENT alert can never be re-queued (A3.2: an alert that was
   * delivered is never delivered twice) and a PENDING one is already on its way, so both are
   * refused. The attempt counter is preserved, so re-queueing cannot be used to escape the
   * bounded retry limit.
   */
  @Post('alerts/:id/requeue')
  @HttpCode(200)
  @RequireStepUp('re-queue a platform alert')
  async requeueAlert(
    @Req() req: Request & { user: { sub: string; name?: string; email: string } },
    @Param('id') id: string,
  ) {
    const alert = await this.prisma.platformAlert.findUnique({ where: { id } });
    if (!alert) throw new NotFoundException('alert not found');
    if (alert.status === 'SENT') throw new BadRequestException('alert-already-sent');
    if (alert.status === 'PENDING') throw new BadRequestException('alert-already-pending');

    const updated = await this.prisma.platformAlert.update({
      where: { id },
      data: { status: 'PENDING', errorCode: null, nextAttemptAt: new Date(), updatedAt: new Date() },
    });
    await this.audit(req, 'alert:requeue', id, {
      type: alert.type,
      previousStatus: alert.status,
      attempts: alert.attempts,
    });
    return { id: updated.id, status: updated.status, attempts: updated.attempts };
  }

  // ── Private helpers: cross-tenant reads through SECURITY DEFINER functions ──
  //
  // PHASE R1 / review item 5. These used to be $queryRaw SELECTs whose comment
  // claimed they "bypass FORCE RLS". They did not: $queryRaw runs as the connecting
  // role, and the documented production role (flexora_app) is NOSUPERUSER
  // NOBYPASSRLS against tables owned by another role with FORCE ROW LEVEL SECURITY,
  // so every one of them returned ZERO. Measured before and after in
  // work/r1-evidence (B5.1: Member=0, Subscription=0 as flexora_app; S4: the same
  // tables hold 6 members and 1 gym).
  //
  // They now call the platform_* functions created by migration
  // 20261106000000_platform_auth_r1: owned by the migration owner, SECURITY
  // DEFINER, SET search_path = pg_catalog, public, every object schema-qualified,
  // typed parameters only, no dynamic SQL, EXECUTE revoked from PUBLIC and granted
  // only to the runtime role. Prisma binds a JS Date as timestamptz and a number as
  // bigint, so both are cast explicitly at the call site; the session TimeZone is
  // UTC, which makes the timestamp(3) cast unambiguous.

  /** Count all members across all gyms. */
  private async countAllMembers(): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ count: string | number | bigint }>>(
      PrismaClient.sql`SELECT platform_count_members()::text AS count`,
    );
    return Number(result[0]?.count ?? 0);
  }

  /** The most recent subscriptions across all gyms, gym-level fields only. */
  private async allSubscriptions(): Promise<Array<{ id: string; gymId: string; tier: string; status: string; lastPaymentAt: Date | null; lastPaymentAmount: number | null }>> {
    return this.prisma.$queryRaw(
      PrismaClient.sql`SELECT id, gym_id AS "gymId", tier, status, last_payment_at AS "lastPaymentAt", last_payment_amount AS "lastPaymentAmount"
                       FROM platform_list_recent_subscriptions(${SUBSCRIPTION_SAMPLE_LIMIT}::integer)`,
    );
  }

  /** Sum of lastPaymentAmount since a given date. */
  private async sumRevenueSince(since: Date): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ total: string | number | bigint }>>(
      PrismaClient.sql`SELECT platform_sum_subscription_revenue_since(${since}::timestamp(3))::text AS total`,
    );
    return Number(result[0]?.total ?? 0);
  }

  /** Sum of lastPaymentAmount between two dates. */
  private async sumRevenueBetween(since: Date, until: Date): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ total: string | number | bigint }>>(
      PrismaClient.sql`SELECT platform_sum_subscription_revenue_between(${since}::timestamp(3), ${until}::timestamp(3))::text AS total`,
    );
    return Number(result[0]?.total ?? 0);
  }

  /** The gyms page, from the R2 definer function. Set-returning, so it goes in FROM. */
  /**
   * PHASE R4 - the stored subscription fields for one gym, read through the R2 SECURITY DEFINER
   * function.
   *
   * This replaced `this.prisma.subscription.findUnique(...)` in three handlers. That call is not
   * merely slow for the runtime role, it is EMPTY: Subscription is FORCE ROW LEVEL SECURITY with
   * a tenant-isolation policy, so as flexora_app it returns null and every beforeState written to
   * the audit log was silently null in production. Measured as flexora_app:
   * `SELECT count(*) FROM public."Subscription"` returns 0. The definer read is the sanctioned
   * way across that boundary and returns only the R2-allowlisted columns.
   */
  private async subscriptionSnapshot(gymId: string): Promise<{
    tier: string | null;
    status: string | null;
    currentPeriodEnd: string | null;
    trialEndDate: string | null;
  }> {
    const rows = await this.gymDetailRows(gymId);
    const row = rows[0];
    if (!row) throw new NotFoundException('gym not found');
    return {
      tier: row.sub_tier ?? null,
      status: row.subscription_status ?? null,
      currentPeriodEnd: row.current_period_end ? new Date(row.current_period_end).toISOString() : null,
      trialEndDate: row.trial_end_date ? new Date(row.trial_end_date).toISOString() : null,
    };
  }

  /**
   * PHASE R4 - the ONE sanctioned write path into Subscription.
   *
   * Subscription is FORCE RLS, and PHASE R2 solved platform READS across tenants with SECURITY
   * DEFINER functions while leaving platform WRITES unaddressed. So all three routes that wrote a
   * subscription failed in production with `42501 new row violates row-level security policy for
   * table "Subscription"` - and nothing caught it for two phases, because the console had no
   * button that called them and every jest harness connects as a superuser, which bypasses RLS
   * outright. Migration 20261107160000_platform_subscription_write_r4 adds
   * public.platform_admin_set_subscription, which writes four columns of one row and validates
   * inside the database.
   *
   * It returns the STORED row, and callers put that into the audit trail rather than the value
   * they intended to write - which is what makes R4.11's "the date you confirmed is the date that
   * landed" true end to end instead of merely intended.
   */
  private async setSubscription(
    client: Prisma.TransactionClient | PrismaService,
    gymId: string,
    change: { tier?: string | null; status?: string | null; periodEnd?: Date | null; trialEnd?: Date | null },
  ): Promise<SubscriptionWriteRow> {
    let rows: SubscriptionWriteRow[];
    try {
      rows = await client.$queryRaw<SubscriptionWriteRow[]>`
        SELECT * FROM public.platform_admin_set_subscription(
          ${gymId}::text,
          ${change.tier ?? null}::text,
          ${change.status ?? null}::text,
          ${change.periodEnd ?? null}::timestamp(3),
          ${change.trialEnd ?? null}::timestamp(3)
        )`;
    } catch (error) {
      throw translateSubscriptionWriteFailure(error, gymId);
    }
    const row = rows[0];
    if (!row) {
      throw new InternalServerErrorException('the subscription write returned no row');
    }
    return row;
  }

  private listGymRows(
    status: string | null,
    search: string | null,
    tier: string | null,
    limit: number,
    offset: number,
    sort = 'createdAt',
    dir = 'desc',
  ): Promise<GymPrivacyRow[]> {
    return this.prisma.$queryRaw(
      PrismaClient.sql`SELECT * FROM public.platform_list_gyms(${status}::text, ${search}::text, ${tier}::text, ${limit}::integer, ${offset}::integer, ${sort}::text, ${dir}::text)`,
    );
  }

  /** How many gyms match, so a page and its total are computed by the same predicate. */
  private async countGymRows(status: string | null, search: string | null, tier: string | null): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ n: string | number | bigint }>>(
      PrismaClient.sql`SELECT public.platform_count_gyms(${status}::text, ${search}::text, ${tier}::text)::text AS n`,
    );
    return Number(result[0]?.n ?? 0);
  }

  /** One gym, by id, through the R2 definer function. */
  private gymDetailRows(gymId: string): Promise<GymPrivacyRow[]> {
    return this.prisma.$queryRaw(
      PrismaClient.sql`SELECT * FROM public.platform_gym_detail(${gymId}::text)`,
    );
  }

  /** The subscriptions page, from the R2 definer function. */
  private listSubscriptionRows(status: string | null, tier: string | null, limit: number, offset: number): Promise<SubscriptionPrivacyRow[]> {
    return this.prisma.$queryRaw(
      PrismaClient.sql`SELECT * FROM public.platform_list_subscriptions(${status}::text, ${tier}::text, ${limit}::integer, ${offset}::integer)`,
    );
  }

  /** How many subscriptions match. */
  private async countSubscriptionRows(status: string | null, tier: string | null): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ n: string | number | bigint }>>(
      PrismaClient.sql`SELECT public.platform_count_subscriptions(${status}::text, ${tier}::text)::text AS n`,
    );
    return Number(result[0]?.n ?? 0);
  }

  /** The approved JSON shape for one gym. Written out explicitly, never spread. */
  private mapGymRow(row: GymPrivacyRow) {
    const hasSubscription = row.sub_tier !== null || row.subscription_status !== null;
    return {
      id: row.gym_id,
      name: row.gym_name,
      slug: row.gym_slug,
      status: row.gym_status,
      email: row.gym_email,
      phone: row.gym_phone,
      address: row.gym_address,
      logo: row.gym_logo,
      accentColor: row.gym_accent_color,
      memberCount: Number(row.member_count ?? 0),
      userCount: Number(row.user_count ?? 0),
      branchCount: Number(row.branch_count ?? 0),
      ownerName: row.owner_name,
      ownerPhone: row.owner_phone,
      subscription: hasSubscription
        ? {
            tier: row.sub_tier,
            status: row.subscription_status,
            currentPeriodStart: row.current_period_start,
            currentPeriodEnd: row.current_period_end,
            trialStartDate: row.trial_start_date,
            trialEndDate: row.trial_end_date,
            trialDays: row.trial_days,
            isTrialUsed: row.is_trial_used,
            cancelAtPeriodEnd: row.cancel_at_period_end,
            lastPaymentAt: row.last_payment_at,
            lastPaymentAmount: row.last_payment_amount,
          }
        : null,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      deletedAt: row.deleted_at,
    };
  }

  /** The approved JSON shape for one subscription, with the gym reduced to four fields. */
  private mapSubscriptionRow(row: SubscriptionPrivacyRow) {
    return {
      id: row.subscription_id,
      gymId: row.gym_id,
      gym: { id: row.gym_id, name: row.gym_name, slug: row.gym_slug, status: row.gym_status },
      tier: row.sub_tier,
      status: row.subscription_status,
      currentPeriodStart: row.current_period_start,
      currentPeriodEnd: row.current_period_end,
      trialStartDate: row.trial_start_date,
      trialEndDate: row.trial_end_date,
      trialDays: row.trial_days,
      isTrialUsed: row.is_trial_used,
      suspendedAt: row.suspended_at,
      cancelledAt: row.cancelled_at,
      graceDays: row.grace_days,
      cancelAtPeriodEnd: row.cancel_at_period_end,
      lastPaymentAt: row.last_payment_at,
      lastPaymentAmount: row.last_payment_amount,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  /** Sum of INCOME transaction amounts for a specific gym. */
  private async sumRevenueForGym(gymId: string): Promise<number> {
    const result = await this.prisma.$queryRaw<Array<{ total: string | number | bigint }>>(
      PrismaClient.sql`SELECT platform_sum_transaction_income_for_gym(${gymId})::text AS total`,
    );
    return Number(result[0]?.total ?? 0);
  }

  /**
   * A month-by-month series for the console's charts. The buckets are built in
   * TypeScript exactly as before R1; only the row source changed, from a direct
   * $queryRaw on "Subscription" (which returned nothing under the runtime role) to
   * the platform_subscription_payments_since() SECURITY DEFINER function.
   */
  private async monthSeries(months: number, type: 'revenue' | 'gyms') {
    const start = new Date(new Date().getFullYear(), new Date().getMonth() - (months - 1), 1);
    const out = Array.from({ length: months }, (_, index) => {
      const month = new Date(start.getFullYear(), start.getMonth() + index, 1).toISOString().slice(0, 7);
      return { month, value: 0 };
    });
    if (type === 'gyms') {
      // "Gym" carries no row-level security (verified: relrowsecurity=f,
      // relforcerowsecurity=f), so a plain Prisma read is correct here and needs no
      // definer function. Adding one would widen the sanctioned cross-tenant
      // surface for no benefit.
      const gyms = await this.prisma.gym.findMany({ where: { createdAt: { gte: start } }, select: { createdAt: true } });
      for (const gym of gyms) {
        const key = gym.createdAt.toISOString().slice(0, 7);
        const row = out.find((item) => item.month === key);
        if (row) row.value += 1;
      }
      return out;
    }
    const subscriptions = await this.prisma.$queryRaw<Array<{ lastPaymentAt: Date | null; lastPaymentAmount: number | null }>>(
      PrismaClient.sql`SELECT last_payment_at AS "lastPaymentAt", last_payment_amount AS "lastPaymentAmount"
                       FROM platform_subscription_payments_since(${start}::timestamp(3), ${REVENUE_SERIES_ROW_LIMIT}::integer)`,
    );
    for (const subscription of subscriptions) {
      if (!subscription.lastPaymentAt) continue;
      const key = subscription.lastPaymentAt.toISOString().slice(0, 7);
      const row = out.find((item) => item.month === key);
      if (row) row.value += Number(subscription.lastPaymentAmount || 0) / 100;
    }
    return out;
  }

  /**
   * PHASE R3 (R3.6). This used to be a one-liner that wrote adminId, adminName, action,
   * target, details and ip. It now also records the user agent, whether a fresh TOTP
   * step-up authorised the action, an optional first-class reason, and the state the
   * action moved the target from and to. Before R3 six of eight genuine audit rows carried
   * no IP at all (work/r3-evidence/00-before.log, B4).
   *
   * It deliberately uses record() and not recordBestEffort(): a privileged console
   * mutation must not succeed unaudited, so if the insert fails the handler fails with it.
   * That is the pre-R3 behaviour too - prisma.create threw - so no capability changed.
   *
   * beforeState and afterState hold identifiers, statuses, tiers, dates and counts only.
   * Never a name, email, phone number, national id or credential. The R2 PII crawl walks
   * both subtrees and fails the run on anything member-shaped or credential-shaped.
   */
  private async audit(
    req: Request & { user: { sub: string; name?: string; email: string } },
    action: string,
    target: string,
    details: unknown,
    extra: { reason?: string | null; beforeState?: AuditState | null; afterState?: AuditState | null } = {},
  ) {
    const row = await this.auditWriter.record({
      adminId: req.user.sub,
      adminName: req.user.name || req.user.email,
      action,
      target,
      details: details as object,
      reason: extra.reason ?? null,
      ip: req.ip ?? null,
      userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null,
      stepUpUsed: stepUpIsActive(req),
      beforeState: extra.beforeState ?? null,
      afterState: extra.afterState ?? null,
    });
    // PHASE R4 (R4.7). An audited action IS a state change, so the cached aggregates behind the
    // Overview and its two charts are now potentially wrong. Invalidating here rather than in
    // each handler is one site instead of twelve, and it cannot be forgotten when a new mutation
    // is added: anything that writes an audit row drops the cache. Auth rows (login, logout,
    // step-up) land here too and cost one recompute, which is cheaper than maintaining a list of
    // "actions that matter" and getting it wrong.
    //
    // Awaited, not fire-and-forget, so a console that refetches immediately after a mutation
    // cannot be served the value that mutation just invalidated. invalidate() is bounded and
    // never throws, so this cannot hang or fail the mutation it follows; with PHASE P3's
    // enableOfflineQueue:false a dead Redis rejects at once rather than costing the full bound.
    //
    // Only the default 12-month series are dropped. A console showing ?months=6 keeps its entry
    // for at most the 60 s TTL, which is the staleness the brief already accepts.
    await this.cache.invalidate(
      PLATFORM_CACHE_KEYS.overview,
      PLATFORM_CACHE_KEYS.revenueChart(12),
      PLATFORM_CACHE_KEYS.gymGrowth(12),
    );
    return row;
  }

  /**
   * Raise an owner alert for a console mutation. Never throws (A3.3): an alert that cannot
   * be recorded must not take down the action that triggered it, and the action is already
   * audited by the time this runs, so the record survives either way.
   */
  private async raiseAlert(input: RaiseAlertInput): Promise<void> {
    try {
      await this.alerts.raise(input);
    } catch (error) {
      this.logger.warn(`could not raise a ${input.type} alert: ${(error as Error).message}`);
    }
  }
}
