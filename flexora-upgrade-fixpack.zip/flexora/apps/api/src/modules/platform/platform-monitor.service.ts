import { Injectable, Optional } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { AiBrainService } from '../ai/ai-brain.service';
import { NotificationsService } from '../notifications/notifications.service';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';

@Injectable()
export class PlatformMonitorService {
  constructor(
    private prisma: PrismaService,
    private aiBrain: AiBrainService,
    private notifications: NotificationsService,
    private readonly cronLeadership: CronLeadershipService,
    @Optional() private readonly redis?: RedisService,
  ) {}

  @Cron('0 8 * * 1') // Every Monday 8am
  async weeklyPlatformReport() {
    return requestContext.run({ requestId: 'cron:platform-weekly' }, async () => {
      if (!(await this.cronLeadership.acquireLock('platform-weekly', 3600_000))) return;
      try {
        // Gather platform-wide stats
        const [
          totalGyms,
          activeGyms,
          totalMembers,
          newGymsThisWeek,
          totalRevenue,
          churnedGyms,
        ] = await Promise.all([
          this.prisma.gym.count(),
          this.prisma.gym.count({
            where: { subscription: {
              status: 'ACTIVE'
            }}
          }),
          this.prisma.member.count({
            where: { status: 'ACTIVE' }
          }),
          this.prisma.gym.count({
            where: { createdAt: {
              gte: new Date(Date.now() - 7*24*60*60*1000)
            }}
          }),
          this.prisma.subscription.aggregate({
            _sum: { lastPaymentAmount: true }
          }),
          this.prisma.gym.count({
            where: { subscription: {
              status: 'CANCELED'
            }}
          }),
        ]);

        const context = `
Platform Stats (this week):
- Total gyms on platform: ${totalGyms}
- Active paying gyms: ${activeGyms}
- Total active members across all gyms: ${totalMembers}
- New gyms this week: ${newGymsThisWeek}
- Total platform revenue: ${totalRevenue._sum.lastPaymentAmount || 0}
- Churned gyms: ${churnedGyms}
    `.trim();

        const prompt = `
You are analyzing the Flexora gym management SaaS platform.
${context}

Provide a concise weekly report in Arabic with:
1. Performance summary (2-3 sentences)
2. Key metrics vs expectations
3. Top 3 action items for the platform owner
4. Any concerns or anomalies to investigate
Be direct and actionable. Max 300 words.
    `.trim();

        const report = await this.aiBrain.chat(
          prompt, null, 'analyst');

        // Save report to platform log
        await this.prisma.platformLog.create({
          data: {
            type: 'WEEKLY_AI_REPORT',
            content: report,
            meta: {
              totalGyms,
              activeGyms,
              totalMembers,
              newGymsThisWeek,
            } as Prisma.InputJsonValue
          }
        }).catch(() => {}); // non-critical

        // Send to platform owner via WhatsApp
        const ownerPhone = process.env.PLATFORM_OWNER_PHONE;
        if (ownerPhone) {
          await this.notifications.whatsapp(
            null, ownerPhone,
            `📊 تقرير FLEXORA الأسبوعي\n\n${report}`
          );
        }

        return { report, stats: {
          totalGyms, activeGyms,
          totalMembers, newGymsThisWeek
        }};
      } finally {
        await this.cronLeadership.releaseLock('platform-weekly');
      }
    });
  }

  async getSecurityScan(): Promise<string> {
    // Scan for anomalies
    const [
      failedLogins,
      unusualActivity,
      expiredTokens,
    ] = await Promise.all([
      this.prisma.auditLog.count({
        where: {
          action: 'LOGIN_FAILED',
          createdAt: { gte: new Date(Date.now() - 24*60*60*1000) }
        }
      }),
      this.prisma.auditLog.count({
        where: {
          action: { in: [
            'UNAUTHORIZED_ACCESS',
            'RATE_LIMIT_EXCEEDED',
            'SUSPICIOUS_REQUEST',
          ]},
          createdAt: { gte: new Date(Date.now() - 24*60*60*1000) }
        }
      }),
      this.prisma.refreshToken.count({
        where: { expiresAt: {
          lt: new Date()
        }}
      }),
    ]);

    const securityContext = `
Security scan (last 24 hours):
- Failed login attempts: ${failedLogins}
- Unusual/suspicious activities: ${unusualActivity}
- Expired refresh tokens still in DB: ${expiredTokens}
    `.trim();

    const analysis = await this.aiBrain.chat(
      `You are a security analyst for a SaaS platform.
       ${securityContext}
       
       Rate the security status (GREEN/YELLOW/RED)
       and list any concerns. Max 150 words. Arabic.`,
      null, 'analyst'
    );

    return analysis;
  }

  @Cron('0 7 * * *') // Every day at 7am
  async dailySecurityScan() {
    return requestContext.run({ requestId: 'cron:security-scan' }, async () => {
      if (!(await this.cronLeadership.acquireLock('platform-daily-scan', 3600_000))) return;
      try {
        const scan = await this.getSecurityScan();
        const ownerPhone = process.env.PLATFORM_OWNER_PHONE;
        if (!ownerPhone) return;

        // Only alert if not GREEN
        if (!scan.includes('GREEN')) {
          await this.notifications.whatsapp(
            null, ownerPhone,
            `🔐 تنبيه أمني FLEXORA\n\n${scan}`
          );
        }
      } finally {
        await this.cronLeadership.releaseLock('platform-daily-scan');
      }
    });
  }
}
