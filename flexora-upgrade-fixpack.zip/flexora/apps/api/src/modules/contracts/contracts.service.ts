/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Digital contracts (Phase 13).
 * - Generate member contracts with signature SVG
 * - Send via WhatsApp (queue-based)
 * - Track signed / pending / delivered state
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { QueueService, QueueModule } from '../queue/queue.module';

@Injectable()
export class ContractsService {
  private readonly logger = new Logger(ContractsService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
  ) {}

  list(gymId: string) {
    return this.prisma.memberContract.findMany({
      where: { gymId },
      include: { member: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }

  async get(gymId: string, id: string) {
    const c = await this.prisma.memberContract.findFirst({ where: { id, gymId } });
    if (!c) throw new NotFoundException('Contract not found');
    return c;
  }

  async create(gymId: string, memberId: string, dto: { title: string; bodyMd: string }) {
    const m = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!m) throw new BadRequestException('Invalid member');
    const contractNo = `CON-${randomBytes(2).toString('hex').toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    return this.prisma.memberContract.create({
      data: { gymId, memberId, contractNo, title: dto.title, bodyMd: dto.bodyMd },
    });
  }

  async sign(gymId: string, id: string, signatureSvg: string) {
    const c = await this.get(gymId, id);
    if (c.signedAt) throw new BadRequestException('Already signed');
    // Generate the PDF after signing (Phase 13).
    let pdfUrl: string | null = null;
    try {
      pdfUrl = await this.generatePdf(gymId, c, signatureSvg);
    } catch (e) {
      this.logger.warn(`PDF generation failed for contract ${id}: ${(e as Error).message}`);
    }
    return this.prisma.memberContract.update({
      where: { id },
      data: { signedAt: new Date(), signatureSvg, pdfUrl: pdfUrl ?? c.pdfUrl },
    });
  }

  /** Phase 13 — Render the contract to a PDF using pdfkit. */
  private async generatePdf(
    gymId: string,
    contract: { id: string; contractNo: string; title: string; bodyMd: string; memberId: string; createdAt: Date; signedAt?: Date | null },
    signatureSvg?: string,
  ): Promise<string> {
    const PDFDocument = (await import('pdfkit')).default;
    const { mkdir } = await import('fs/promises');
    const { join } = await import('path');
    const { createWriteStream } = await import('fs');
    const dir = process.env.CONTRACT_PDF_DIR || '/var/backups/flexora/contracts';
    await mkdir(dir, { recursive: true });
    const file = join(dir, `${contract.contractNo}.pdf`);

    const doc = new PDFDocument({ size: 'A4', margin: 50 });
    const stream = createWriteStream(file);
    doc.pipe(stream);

    const gym = await this.prisma.gym.findUnique({ where: { id: gymId } });
    const member = await this.prisma.member.findUnique({ where: { id: contract.memberId, gymId } });

    doc.fontSize(20).fillColor('#000000').text(contract.title, { align: 'center' });
    doc.moveDown(0.5);
    doc.fontSize(10).fillColor('#666666').text(`Contract No: ${contract.contractNo}`, { align: 'center' });
    doc.text(`Gym: ${gym?.name ?? gymId}`, { align: 'center' });
    doc.text(`Member: ${member?.name ?? contract.memberId}  ·  ${member?.mobile ?? ''}`, { align: 'center' });
    doc.text(`Date: ${new Date(contract.createdAt).toLocaleDateString()}`, { align: 'center' });
    doc.moveDown(2);

    doc.fontSize(11).fillColor('#000000');
    const lines = contract.bodyMd.split('\n');
    for (const line of lines) {
      doc.text(line, { align: 'left' });
      doc.moveDown(0.3);
    }

    doc.moveDown(2);
    if (contract.signedAt || signatureSvg) {
      doc.fontSize(11).fillColor('#22c55e').text('Signed: ' + new Date(contract.signedAt || Date.now()).toLocaleString());
      if (signatureSvg) {
        try {
          const m = signatureSvg.match(/<svg[\s\S]*?<\/svg>/i);
          if (m) {
            doc.fontSize(8).fillColor('#888888').text(`Signature fingerprint: ${m[0].slice(0, 80)}…`);
          }
        } catch { /* ignore */ }
      }
    } else {
      doc.fontSize(11).fillColor('#f59e0b').text('Awaiting signature…');
    }

    doc.moveDown(4);
    doc.fontSize(8).fillColor('#999999').text(
      `FLEXORA Gym OS · © ${new Date().getFullYear()} Ammar Allam`,
      { align: 'center' },
    );

    doc.end();
    await new Promise<void>((resolve, reject) => {
      stream.on('finish', () => resolve());
      stream.on('error', reject);
    });
    this.logger.log(`PDF written: ${file}`);
    return file;
  }

  async sendWhatsApp(gymId: string, id: string) {
    const c = await this.get(gymId, id);
    const member = await this.prisma.member.findFirst({ where: { id: c.memberId, gymId } });
    if (!member) throw new BadRequestException('Member missing');
    if (c.signedAt) {
      throw new BadRequestException('Already signed — use sendSignedCopy');
    }
    await this.queue.enqueue('send-whatsapp', {
      gymId,
      to: member.mobile,
      templateKey: 'CONTRACT_INVITE',
      body: `Please review and sign your contract "${c.title}": ${process.env.PUBLIC_BASE_URL || ''}/portal/contracts/${c.id}`,
    });
    return this.prisma.memberContract.update({
      where: { id },
      data: { whatsappSent: true, whatsappSentAt: new Date() },
    });
  }

  async delete(gymId: string, id: string) {
    await this.get(gymId, id);
    return this.prisma.memberContract.deleteMany({ where: { id, gymId } });
  }
}
