/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MinLength } from 'class-validator';
import { ContractsService } from './contracts.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { RequiresFeature } from '../license/license.module';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class SignContractDto { @IsString() @IsNotEmpty() signatureSvg!: string; }

class CreateContractBodyDto {
  @IsString() @IsNotEmpty() memberId!: string;
  @IsString() @MinLength(3) title!: string;
  @IsString() @MinLength(10) bodyMd!: string;
}

@ApiTags('contracts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('contracts')
@Controller('contracts')
export class ContractsController {
  constructor(private readonly svc: ContractsService) {}

  @Get()
  @Permissions('contracts.manage')
  list(@GymId() gymId: string) { return this.svc.list(gymId); }

  @Get(':id') @Permissions('contracts.manage')
  get(@GymId() gymId: string, @Param('id') id: string) { return this.svc.get(gymId, id); }

  @Post() @Permissions('contracts.manage') @Audit('create', 'MemberContract')
  create(
    @GymId() gymId: string,
    @Body() dto: CreateContractBodyDto,
  ) { return this.svc.create(gymId, dto.memberId, dto); }

  @Post(':id/sign')
  @Permissions('contracts.manage')
  sign(@GymId() gymId: string, @Param('id') id: string, @Body() dto: SignContractDto) {
    return this.svc.sign(gymId, id, dto.signatureSvg);
  }

  @Post(':id/send') @Permissions('contracts.manage')
  @Audit('send_whatsapp', 'MemberContract')
  sendAlias(@GymId() gymId: string, @Param('id') id: string) { return this.svc.sendWhatsApp(gymId, id); }

  @Post(':id/send-whatsapp') @Permissions('contracts.manage')
  @Audit('send_whatsapp', 'MemberContract')
  send(@GymId() gymId: string, @Param('id') id: string) { return this.svc.sendWhatsApp(gymId, id); }

  @Delete(':id') @Permissions('contracts.manage') @Audit('delete', 'MemberContract')
  remove(@GymId() gymId: string, @Param('id') id: string) { return this.svc.delete(gymId, id); }
}
