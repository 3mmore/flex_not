/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { QueueModule } from '../queue/queue.module';
import { ContractsService } from './contracts.service';

@Module({
  imports: [QueueModule],
  providers: [ContractsService],
  exports: [ContractsService],
})
export class ContractsModule {}
