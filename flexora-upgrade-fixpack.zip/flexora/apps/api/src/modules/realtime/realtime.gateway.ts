import { JwtService } from '@nestjs/jwt';
import { OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit, SubscribeMessage, WebSocketGateway, WebSocketServer, ConnectedSocket, MessageBody } from '@nestjs/websockets';
import { Logger, OnApplicationShutdown } from '@nestjs/common';
import { createAdapter } from '@socket.io/redis-adapter';
import Redis from 'ioredis';
import { assertRedisTransport, redisConnectionOptions } from '../../config/redis-transport';
import { Server, Socket } from 'socket.io';

/**
 * PHASE N1 — the WebSocket CORS allow-list, resolved per handshake.
 *
 * A decorator argument is evaluated when the class is defined, i.e. at import
 * time, so `origin: process.env.CORS_ORIGIN?.split(',')` froze the socket.io
 * allow-list to whatever the environment held then — `['http://localhost:3000']`
 * whenever `.env` had not been injected yet. That is a security-relevant
 * default: the realtime namespace would have accepted browser origins from the
 * development list in production. socket.io accepts a function here, which keeps
 * the meaning identical while reading the configuration at call time.
 */
function allowedSocketOrigins(): string[] {
  const list = (process.env.CORS_ORIGIN || '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);
  return list.length ? list : ['http://localhost:3000'];
}

@WebSocketGateway({
  cors: {
    origin: (
      origin: string | undefined,
      cb: (err: Error | null, allow?: boolean | string) => void,
    ) => {
      // No Origin header = a non-browser client (kiosk / native app); there is
      // no browser same-origin policy to enforce, exactly as with an array.
      if (!origin) return cb(null, true);
      return cb(null, allowedSocketOrigins().includes(origin) ? origin : false);
    },
    credentials: true,
  },
  namespace: '/realtime',
})
export class RealtimeGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect, OnApplicationShutdown {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(RealtimeGateway.name);
  private pubClient?: Redis;
  private subClient?: Redis;
  constructor(private jwtService: JwtService) {}

  afterInit(server: Server) {
    const redisUrl = process.env.REDIS_URL;
    if (!redisUrl) {
      this.logger.warn('REDIS_URL not set — Socket.IO uses in-memory adapter');
      return;
    }
    // FIX (launch-readiness, discovered while re-verifying the FULL test
    // suite is green after the QueueService DI cascade fix — real, genuine
    // runtime bug, NOT a version mismatch):
    // Because this gateway declares `namespace: '/realtime'` in its
    // `@WebSocketGateway(...)` options, Nest's `WebSocketsController`
    // passes THIS namespace's `Namespace` instance into `afterInit(server)`
    // (see `@nestjs/websockets/web-sockets-controller.js`'s
    // `subscribeToServerEvents` -> `assignServerToProperties`/`observableServer.server`),
    // NOT the root Socket.IO `Server`. `Namespace` (socket.io's
    // `dist/namespace.js`) has its own `adapter` PROPERTY (the already-
    // constructed Adapter instance for that one namespace), not an
    // `adapter(...)` METHOD — only the root `Server` (`dist/index.js`)
    // exposes `adapter(v)` as a setter/getter function that both records
    // the adapter constructor AND re-initializes every namespace's
    // `.adapter` via `Namespace#_initAdapter()`. Calling `server.adapter(fn)`
    // on a `Namespace` therefore always throws
    // `TypeError: server.adapter is not a function` — confirmed directly by
    // reproducing with a bare `socket.io` `Server`/`of()` call in Node
    // outside Nest entirely. Every `Namespace` instance carries a `.server`
    // back-reference to the real root `Server` (`this.server = server` in
    // the `Namespace` constructor) — so the fix is to register the Redis
    // adapter on that root reference when we were handed a namespace,
    // falling back to calling `.adapter()` directly when we're ever handed
    // the root server itself (e.g. if the `namespace` option is ever
    // removed in the future). This was never caught before because no test
    // in this suite ever built a real Nest application via `app.init()`
    // with `REDIS_URL` set until the QueueService DI bug (fixed earlier in
    // this same hardening pass) was preventing the app from booting far
    // enough to ever reach WebSocket gateway initialization at all — this
    // bug was purely MASKED by that earlier one, exactly like the cascade
    // of module-wiring bugs found before it.
    const rootServer: Server = (server as unknown as { server?: Server }).server ?? server;
    // PHASE O1.4: same shared decision as config/redis.service.ts, so the
    // socket.io adapter clients cannot end up on plaintext Redis in production
    // while the main client is on TLS (they used to be constructed with no
    // check at all, and `.duplicate()` inherits these options).
    const decision = assertRedisTransport(redisUrl);
    if (decision.warn) this.logger.warn(decision.warn);
    this.pubClient = new Redis(redisUrl, {
      maxRetriesPerRequest: null,
      ...redisConnectionOptions(decision),
    });
    this.subClient = this.pubClient.duplicate();
    rootServer.adapter(createAdapter(this.pubClient, this.subClient));
    this.logger.log('Socket.IO Redis adapter enabled for /realtime namespace');
  }

  handleConnection(client: Socket) {
    const timeout = setTimeout(() => {
      if (!client.data.authenticated) client.disconnect(true);
    }, 30_000);
    client.data.authTimeout = timeout;
    const token =
      client.handshake.auth?.token ||
      client.handshake.headers?.authorization
        ?.replace('Bearer ', '') ||
      client.handshake.headers?.cookie
        ?.split(';')
        ?.find((c: string) => c.trim().startsWith('flx_access='))
        ?.split('=')[1];
    if (token) this.authenticate(client, token);
  }

  @SubscribeMessage('join')
  async handleJoin(@ConnectedSocket() client: Socket, @MessageBody() body: { token?: string }) {
    return this.authenticate(client, body?.token || '');
  }

  private authenticate(client: Socket, token: string) {
    try {
      if (!token) { client.disconnect(true); return { ok: false }; }
      const payload = this.jwtService.verify(token, {
        secret: process.env.JWT_ACCESS_SECRET,
        algorithms: ['HS256'],
      }) as { sub?: string; gymId?: string; type?: string };
      if (!payload.sub || !payload.gymId || payload.type === 'platform') {
        throw new Error('Tenant user token required');
      }
      if (client.data.authTimeout) { clearTimeout(client.data.authTimeout); client.data.authTimeout = null; }
      client.data.authenticated = true;
      client.join(`gym:${payload.gymId}`);
      client.data = { ...client.data, userId: payload.sub, gymId: payload.gymId };
      return { ok: true, gymId: payload.gymId };
    } catch {
      client.disconnect(true);
      return { ok: false };
    }
  }

  handleDisconnect(client: Socket) {
    if (client.data.authTimeout) clearTimeout(client.data.authTimeout);
  }

  /**
   * PHASE N2 — the pub/sub connections are released here, and ONLY here.
   *
   * Nest's shutdown order is onModuleDestroy → beforeApplicationShutdown →
   * dispose() → onApplicationShutdown, and dispose() is what closes the socket
   * module: server.close() → RedisAdapter.close() → subClient.punsubscribe().
   * ioredis REJECTS any command issued on a closed connection and
   * @socket.io/redis-adapter never catches that promise, so quitting these two
   * clients from onModuleDestroy (where they used to be quit) made EVERY graceful
   * shutdown throw an unhandled rejection — Node >= 15 rethrows it, so the process
   * died mid-shutdown. In tests it killed the jest worker outright: `npm test`
   * aborted with no summary at all, which is how this was found.
   *
   * onApplicationShutdown is the only hook that runs AFTER the adapter has been
   * closed, so the unsubscribe commands always land on a live connection.
   */
  async onApplicationShutdown() {
    await Promise.allSettled([
      this.subClient?.quit(),
      this.pubClient?.quit(),
    ].filter((promise): promise is Promise<'OK'> => Boolean(promise)));
    this.subClient = undefined;
    this.pubClient = undefined;
  }

  emitToGym(gymId: string, event: string, data: unknown) {
    this.server?.to(`gym:${gymId}`).emit(event, data);
  }
}
