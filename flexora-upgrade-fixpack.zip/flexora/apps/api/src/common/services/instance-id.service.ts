import { Injectable } from '@nestjs/common';
import { randomUUID } from 'crypto';

@Injectable()
export class InstanceIdService {
  readonly id: string = randomUUID();
}
