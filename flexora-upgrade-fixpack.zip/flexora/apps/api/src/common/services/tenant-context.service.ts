/**
 * FLEXORA Gym OS — request tenant context for DB safety nets
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE 4: the store now also carries the *branch* scope, so the Prisma
 * extension (prisma.service.ts) can pin `branchId` on every branch-scoped
 * model without any service having to remember to do it. See
 * common/branch-scope/branch-scope.ts for the rules.
 */
import { Injectable } from '@nestjs/common';
import { AsyncLocalStorage } from 'async_hooks';
import type { BranchScope } from '../branch-scope/branch-scope';

export interface TenantScope {
  gymId?: string | null;
  branchId?: string | null;
  unrestrictedBranch?: boolean;
}

@Injectable()
export class TenantContextService {
  private readonly storage = new AsyncLocalStorage<TenantScope>();

  run<T>(scope: string | null | undefined | TenantScope, callback: () => T): T {
    // Backwards compatible: the old signature took a bare gymId string.
    const store: TenantScope =
      typeof scope === 'object' && scope !== null
        ? scope
        : { gymId: (scope as string | null | undefined) || null };
    return this.storage.run(store, callback);
  }

  enter(scope: string | null | undefined | TenantScope) {
    const store: TenantScope =
      typeof scope === 'object' && scope !== null
        ? scope
        : { gymId: (scope as string | null | undefined) || null };
    this.storage.enterWith(store);
  }

  getGymId(): string | null {
    return this.storage.getStore()?.gymId || null;
  }

  /**
   * The branch a restricted staff member is pinned to for THIS request.
   * Returns null when the request is unrestricted (owner/manager, pre-auth,
   * platform routes, cron/background work) — callers must treat null as
   * "do not force a branch filter".
   */
  getForcedBranchId(): string | null {
    const store = this.storage.getStore();
    if (!store || store.unrestrictedBranch !== false) return null;
    return store.branchId || null;
  }

  getBranchScope(): BranchScope | null {
    const store = this.storage.getStore();
    if (!store || store.unrestrictedBranch === undefined) return null;
    return {
      role: '',
      unrestricted: store.unrestrictedBranch === true,
      branchId: store.branchId ?? null,
      filterBranchId: store.unrestrictedBranch ? null : store.branchId ?? null,
      source: store.unrestrictedBranch ? 'unrestricted-role' : 'assigned-branch',
    };
  }
}
