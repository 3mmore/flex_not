/**
 * FLEXORA Gym OS — distributed cron leadership lock
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable } from '@nestjs/common';
import { RedisService } from '../../config/redis.service';
import { InstanceIdService } from './instance-id.service';

@Injectable()
export class CronLeadershipService {
  constructor(
    private readonly redis: RedisService,
    private readonly instance: InstanceIdService,
  ) {}

  async acquireLock(jobName: string, durationMs: number): Promise<boolean> {
    const key = `cron:lock:${jobName}`;
    const acquired = await this.redis.client.set(key, this.instance.id, 'PX', durationMs, 'NX');
    return acquired === 'OK';
  }

  async releaseLock(jobName: string): Promise<void> {
    const key = `cron:lock:${jobName}`;
    // Compare-and-delete atomically. GET followed by DEL can delete a new
    // leader's lock if this lease expires between those two commands.
    await this.redis.client.eval(
      `if redis.call('get', KEYS[1]) == ARGV[1] then
         return redis.call('del', KEYS[1])
       end
       return 0`,
      1,
      key,
      this.instance.id,
    );
  }
}
