/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
export function normalizeMobile(
  value: unknown,
  defaultCountryCode = '20',
): string | null {
  if (!value) return null;

  let s = String(value)
    .replace(/\s+/g, '')
    .replace(/[^\d+]/g, '');

  if (!s) return null;

  if (s.startsWith('+')) return s;

  if (s.startsWith('00')) return '+' + s.slice(2);

  // Egyptian: 01XXXXXXXXX (11 digits)
  if (s.startsWith('01') && s.length === 11) return '+2' + s;

  // Already has country code without +
  if (s.length >= 12) return '+' + s;

  // Add default country code
  return '+' + defaultCountryCode + s;
}