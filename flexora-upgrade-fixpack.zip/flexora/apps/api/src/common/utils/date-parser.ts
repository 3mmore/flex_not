/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
export function parseFlexibleDate(value: unknown): Date | null {
  if (!value) return null;

  const s = String(value).trim();
  if (!s || s === 'null' || s === 'undefined') return null;

  // Try ISO directly
  let d = new Date(s);
  if (!isNaN(d.getTime())) return d;

  // DD/MM/YYYY
  const dmy = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (dmy) {
    d = new Date(`${dmy[3]}-${dmy[2].padStart(2, '0')}-${dmy[1].padStart(2, '0')}`);
    if (!isNaN(d.getTime())) return d;
  }

  // DD-MM-YYYY
  const dmy2 = s.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
  if (dmy2) {
    d = new Date(`${dmy2[3]}-${dmy2[2].padStart(2, '0')}-${dmy2[1].padStart(2, '0')}`);
    if (!isNaN(d.getTime())) return d;
  }

  // Excel serial number (e.g. 44927 = 2023-01-01)
  const num = Number(s);
  if (!isNaN(num) && num > 40000 && num < 60000) {
    d = new Date((num - 25569) * 86400 * 1000);
    if (!isNaN(d.getTime())) return d;
  }

  return null;
}