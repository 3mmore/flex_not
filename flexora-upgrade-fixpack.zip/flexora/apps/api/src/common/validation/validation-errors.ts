/**
 * FLEXORA Gym OS — structured validation errors
 * © 2024 Ammar Allam. All rights reserved.
 *
 * WHY THIS EXISTS
 * Nest's default ValidationPipe returns `message` as an ARRAY of strings
 * (`["Name must contain at least 3 parts"]`). The web client only understood a
 * string, so every DTO rejection collapsed into "HTTP 400" and the user saw a
 * blank/generic failure — e.g. adding an employee with a two-part name looked
 * like the form was simply broken.
 *
 * Every rejection is therefore flattened into one machine-readable entry per
 * field, each carrying a `translationKey` when the constraint is one the UI
 * knows how to phrase, so the frontend can show the reason in the user's
 * language:
 *
 *   { statusCode: 400, code: 'VALIDATION_FAILED',
 *     message: [...],            // kept for API consumers / Swagger
 *     messages: [...],           // same list, explicit
 *     errors: [{ field, message, translationKey }] }
 */
import { BadRequestException, ValidationError } from '@nestjs/common';

export type ValidationIssue = {
  /** DTO property that failed (dotted path for nested payloads). */
  field: string;
  /** The validator's own English message (kept for logs / API clients). */
  message: string;
  /** i18n key the web dictionary renders this as, when we have one. */
  translationKey?: string;
};

/**
 * Constraint text → i18n key. Matching on the message keeps this in one place
 * instead of editing every DTO; an unmapped message simply passes through as
 * text (never hidden).
 */
const MESSAGE_KEYS: Array<{ test: RegExp; key: string }> = [
  { test: /3 parts/i, key: 'error_staff_name_parts' },
  { test: /Egyptian mobile/i, key: 'error_invalid_phone' },
  { test: /must be an email/i, key: 'error_invalid_email' },
  { test: /longer than or equal to 8/i, key: 'error_password_min_length' },
  { test: /Password must contain/i, key: 'error_weak_password' },
  { test: /should not exist/i, key: 'error_unknown_field' },
  { test: /should not be empty/i, key: 'error_required_field' },
  { test: /must be (a|an) (string|number|boolean|enum|array|object|date)/i, key: 'error_invalid_value' },
  { test: /must be one of the following values/i, key: 'error_invalid_value' },
];

export function translationKeyFor(message: string): string | undefined {
  return MESSAGE_KEYS.find((m) => m.test.test(message))?.key;
}

/** class-validator nests by property; flatten to one entry per failing constraint. */
export function flattenValidationErrors(errors: ValidationError[], parent = ''): ValidationIssue[] {
  const out: ValidationIssue[] = [];
  for (const err of errors) {
    const field = parent ? `${parent}.${err.property}` : err.property;
    for (const message of Object.values(err.constraints || {})) {
      out.push({ field, message, translationKey: translationKeyFor(message) });
    }
    if (err.children?.length) out.push(...flattenValidationErrors(err.children, field));
  }
  // A payload can be rejected with no per-field constraints (e.g. a whitelist
  // rejection on the root object) — never return an empty explanation.
  if (out.length === 0) {
    out.push({ field: parent || '(body)', message: 'Invalid request payload', translationKey: 'error_invalid_value' });
  }
  return out;
}

export function validationException(errors: ValidationError[]): BadRequestException {
  const issues = flattenValidationErrors(errors);
  return new BadRequestException({
    statusCode: 400,
    code: 'VALIDATION_FAILED',
    // `message` stays an array (Nest's own shape); the client joins it.
    message: issues.map((i) => i.message),
    messages: issues.map((i) => i.message),
    errors: issues,
  });
}
