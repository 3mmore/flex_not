/**
 * FLEXORA Gym OS — @BranchScope() parameter decorator (Phase 4)
 *
 * Controllers use it to read the branch scope TenantGuard pinned on the
 * request instead of re-deriving it from `@CurrentUser()`:
 *
 *   list(@GymId() gymId: string, @BranchScope() scope: BranchScope) { … }
 *
 * For an OWNER/MANAGER it is `{ unrestricted: true, filterBranchId: null }`;
 * for every other role it carries the single branch they are pinned to.
 */
import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { BranchScope } from './branch-scope';
import { resolveBranchScope } from './branch-scope';

export const BranchScopeParam = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): BranchScope => {
    const req = ctx.switchToHttp().getRequest();
    return (req?.branchScope as BranchScope) || resolveBranchScope(req?.user);
  },
);
