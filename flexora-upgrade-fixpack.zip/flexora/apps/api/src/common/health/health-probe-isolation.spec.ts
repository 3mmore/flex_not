/**
 * PHASE Q2 — `/api/health/live` must answer 200 whatever Redis does.
 *
 * THE DEFECT THIS PINS, reproduced and then removed
 * -------------------------------------------------
 * PHASE P3 excluded the probes from `IpShieldMiddleware` with
 * `.exclude("api/health/live", "api/health/ready")` in `app.module.ts`. That
 * exclusion NEVER MATCHED, so the middleware ran on the liveness probe, called
 * `SecurityShieldService.isBlocked()` — one Redis GET — and with Redis
 * unreachable the bounded rejection became the probe's answer. Measured in the
 * PHASE P3 evidence (work/p3-evidence/live-proof-final.log):
 *
 *     A1 GET /api/health/live (pure ping)   503   0.001807s   Retry-After=5
 *     [DependencyUnavailable] REDIS_UNAVAILABLE -> 503 + Retry-After 5s for /
 *
 * i.e. the container reported itself BROKEN because a dependency its liveness
 * probe does not need was down — which is exactly what an orchestrator acts on by
 * restarting (or killing) a healthy process.
 *
 * Why the string did not match is not a guess; it is Nest's own code, asserted
 * against the real classes in test 1 below: `RouteInfoPathExtractor` PREPENDS the
 * global prefix to every non-wildcard path, so `"api/health/live"` was registered
 * as `/api/api/health/live`, while `isMiddlewareRouteExcluded()` matches the
 * exclusion against `req.originalUrl`, which is `/api/health/live`.
 *
 * WHAT REPLACES IT
 * ----------------
 * One declaration — `@HealthProbe('live'|'ready')` on the two handlers — and every
 * global component reads route IDENTITY from it: guards/interceptors/filters
 * through `probeKindOfContext()` (the matched handler is available), middleware
 * through `probeKindOfRequest()` (routing has not happened yet, so the path set is
 * DERIVED FROM THE SAME METADATA and matched against every path representation
 * Express exposes). `app.module.ts` also passes the metadata-derived, PREFIX-FREE
 * forms to `.exclude()`, which is what Nest needs in order to build the real path.
 *
 * THE TRIPWIRE (test 5)
 * ---------------------
 * Every global component is enumerated FROM AppModule's own metadata — the
 * APP_GUARD / APP_INTERCEPTOR / APP_FILTER providers plus whatever
 * `AppModule.configure()` applies — instantiated with recording stubs, and invoked
 * with a probe request. The assertion is stronger than "no Redis": a probe must
 * not touch ANY collaborator. Add a new global guard, interceptor, filter or
 * middleware and test 5b fails until it is added to the table; make one of them
 * call anything at all on the probe path and test 5a fails. Test 6 is the negative
 * control proving the harness can see a collaborator call at all.
 */
import { Reflector } from '@nestjs/core';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { NotFoundException } from '@nestjs/common';
import type { MiddlewareConsumer } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import { readFileSync } from 'fs';
import { resolve } from 'path';
import { of } from 'rxjs';

import { AppModule } from '../../app.module';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { HealthController } from '../../modules/health/health.controller';
import { LicenceStateService } from '../../modules/license/licence-state.service';
import { LICENSE_REQUIRED_ENV } from '../../modules/license/licence-policy';
import { TenantContextService } from '../services/tenant-context.service';
import { RequestIdMiddleware } from '../middleware/request-id.middleware';
import { IpShieldMiddleware } from '../middleware/ip-shield.middleware';
import { CsrfMiddleware } from '../middleware/csrf.middleware';
import { NullByteMiddleware } from '../middleware/null-byte.middleware';
import { PlatformSessionGuard } from '../guards/platform-session.guard';
import { PlatformTotpEnrolmentGuard } from '../guards/platform-totp-enrolment.guard';
import { PlatformCsrfGuard } from '../guards/platform-csrf.guard';
import { PlatformStepUpGuard } from '../guards/platform-step-up.guard';
import { PlatformHeadersInterceptor } from '../interceptors/platform-headers.interceptor';
import { LicenceAvailabilityGuard } from '../guards/licence-availability.guard';
import { AdminHostGuard } from '../guards/admin-host.guard';
import { PlatformRoute } from '../decorators/platform-route.decorator';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { TenantGuard } from '../guards/tenant.guard';
import { RolesGuard } from '../guards/roles.guard';
import { PermissionsGuard } from '../guards/permissions.guard';
import { LicenseGuard } from '../../modules/license/license.guard';
import { TenantContextInterceptor } from '../interceptors/tenant-context.interceptor';
import { AuditInterceptor } from '../interceptors/audit.interceptor';
import { DependencyUnavailableFilter } from '../filters/dependency-unavailable.filter';
import { HttpExceptionFilter } from '../filters/http-exception.filter';
import {
  HEALTH_PROBE_METADATA,
  probeExclusionsForNest,
  probeKindOfContext,
  probeKindOfRequest,
  resolvedProbes,
} from './probe-routes';

// ---------------------------------------------------------------------------
// harness
// ---------------------------------------------------------------------------

/** Records every property read and every call made on a stubbed collaborator. */
class Recorder {
  readonly calls: string[] = [];

  stub(label: string): any {
    const make = (path: string): any =>
      new Proxy(function stub() {} as any, {
        get: (_t, prop) => {
          const key = String(prop);
          // `await` probes for .then; answering it keeps the harness honest
          // (the awaited value is the stub itself) without counting as a call.
          if (key === 'then' || key === 'catch' || key === 'finally') return undefined;
          if (key === 'toString' || key === Symbol.toPrimitive as unknown as string) return () => `${label}${path}`;
          if (key === 'constructor') return Object;
          if (typeof prop === 'symbol') return undefined;
          this.calls.push(`${label}${path}.${key}`);
          return make(`${path}.${key}`);
        },
        apply: () => {
          this.calls.push(`${label}${path}()`);
          return make(`${path}()`);
        },
        construct: () => make(`${path}.new`),
      });
    return make('');
  }
}

/**
 * What Express hands a middleware for `GET /api/health/live` when Nest has mounted
 * it under the global prefix: `originalUrl` keeps the full path, `url`/`path` are
 * the remainder after the mount, `baseUrl` is the mount itself. Every one of those
 * representations has to resolve to the same route.
 */
function mountedRequest(route: string, method = 'GET'): any {
  const full = `/${API_GLOBAL_PREFIX}${route}`;
  return {
    method,
    originalUrl: full,
    url: route,
    path: route,
    baseUrl: `/${API_GLOBAL_PREFIX}`,
    headers: {},
    ip: '127.0.0.1',
    socket: { remoteAddress: '127.0.0.1' },
  };
}

const LIVE_REQ = mountedRequest('/health/live');
const READY_REQ = mountedRequest('/health/ready');
const BUSINESS_REQ = mountedRequest('/members?limit=1');

function responseStub() {
  const res: any = { headersSent: false, statusCode: 0, body: undefined, headers: {} };
  res.status = (code: number) => { res.statusCode = code; return res; };
  res.setHeader = (k: string, v: string) => { res.headers[k] = v; return res; };
  res.json = (body: unknown) => { res.body = body; return res; };
  res.cookie = () => res;
  res.end = () => res;
  return res;
}

/** An ExecutionContext for one of the two probes, carrying the REAL handler. */
function probeContext(kind: 'live' | 'ready', req: any) {
  const handler = kind === 'live' ? HealthController.prototype.liveness : HealthController.prototype.readiness;
  return {
    switchToHttp: () => ({ getRequest: () => req, getResponse: () => responseStub() }),
    getHandler: () => handler,
    getClass: () => HealthController,
    getType: () => 'http' as const,
  } as any;
}

/** An ExecutionContext for an ordinary licensed route. */
function businessContext(req: any = BUSINESS_REQ) {
  const handler = function members() { return undefined; };
  const klass = class MembersController {};
  return {
    switchToHttp: () => ({ getRequest: () => req, getResponse: () => responseStub() }),
    getHandler: () => handler,
    getClass: () => klass,
    getType: () => 'http' as const,
  } as any;
}

/**
 * An ExecutionContext for an OWNER-CONSOLE route (PHASE R0). The controller carries
 * the real `@PlatformRoute()` marker, so AdminHostGuard identifies it from metadata
 * exactly as it does in production - never from the URL string.
 */
function platformContext(req: any) {
  @PlatformRoute()
  class PlatformProbeController {
    overview() { return undefined; }
  }
  return {
    switchToHttp: () => ({ getRequest: () => req, getResponse: () => responseStub() }),
    getHandler: () => PlatformProbeController.prototype.overview,
    getClass: () => PlatformProbeController,
    getType: () => 'http' as const,
  } as any;
}

/** The throttler names really configured in app.module.ts, read from metadata. */
function configuredThrottlerNames(): string[] {
  const imports = (Reflect.getMetadata('imports', AppModule) || []) as any[];
  const dynamic = imports.find((m) => m && m.module && m.module.name === 'ThrottlerModule');
  expect(dynamic).toBeDefined();
  const optionsProvider = (dynamic.providers || []).find(
    (p: any) => String(p?.provide) === 'THROTTLER:MODULE_OPTIONS',
  );
  expect(optionsProvider).toBeDefined();
  const throttlers = (optionsProvider.useValue?.throttlers || []) as Array<{ name?: string }>;
  expect(throttlers.length).toBeGreaterThan(0);
  return throttlers.map((t) => t.name || 'default');
}

// ---------------------------------------------------------------------------
// 1. the Nest quirk that made the PHASE P3 exclusion dead code
// ---------------------------------------------------------------------------
describe('PHASE Q2 — Nest prepends the global prefix to middleware exclude paths', () => {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { RouteInfoPathExtractor } = require('@nestjs/core/middleware/route-info-path-extractor');
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { mapToExcludeRoute } = require('@nestjs/core/middleware/utils');
  const extractor = new RouteInfoPathExtractor({
    getGlobalPrefix: () => API_GLOBAL_PREFIX,
    getGlobalPrefixOptions: () => ({}),
    getVersioning: () => undefined,
  });

  it('1. the PHASE P3 string was registered as /api/api/health/live and matched nothing', () => {
    const before = extractor.extractPathFrom({ path: '/api/health/live', method: -1 });
    expect(before).toEqual(['/api/api/health/live']);

    const beforeRegex = mapToExcludeRoute([{ path: before[0], method: -1 }])[0].pathRegex;
    // isMiddlewareRouteExcluded matches this against req.originalUrl
    expect(beforeRegex.test('/api/health/live')).toBe(false);
    expect(beforeRegex.test('/api/api/health/live')).toBe(true);
  });

  it('1b. the metadata-derived, PREFIX-FREE form produces the real request path', () => {
    const exclusions = probeExclusionsForNest();
    expect(exclusions).toEqual(['health/live', 'health/ready']);
    for (const exclusion of exclusions) {
      const extracted = extractor.extractPathFrom({ path: `/${exclusion}`, method: -1 });
      expect(extracted).toEqual([`/${API_GLOBAL_PREFIX}/${exclusion}`]);
      const regex = mapToExcludeRoute([{ path: extracted[0], method: -1 }])[0].pathRegex;
      expect(regex.test(`/${API_GLOBAL_PREFIX}/${exclusion}`)).toBe(true);
    }
  });
});

// ---------------------------------------------------------------------------
// 2. the probes are declared once, on the handlers, and resolve to two routes
// ---------------------------------------------------------------------------
describe('PHASE Q2 — the probe routes are declared by metadata on the handlers', () => {
  it('2. both handlers carry the marker, and nothing else does', () => {
    expect(Reflect.getMetadata(HEALTH_PROBE_METADATA, HealthController.prototype.liveness)).toBe('live');
    expect(Reflect.getMetadata(HEALTH_PROBE_METADATA, HealthController.prototype.readiness)).toBe('ready');
    // the authenticated health endpoints are NOT probes: they are licensed work
    for (const method of ['health', 'details', 'metrics', 'triggerError', 'triggerCron']) {
      const handler = (HealthController.prototype as any)[method];
      if (typeof handler === 'function') {
        expect(Reflect.getMetadata(HEALTH_PROBE_METADATA, handler)).toBeUndefined();
      }
    }
    expect(resolvedProbes().map((p) => p.prefixed).sort()).toEqual([
      '/api/health/live',
      '/api/health/ready',
    ]);
  });

  it('2b. the probes are skipped for EVERY throttler the app actually configures', () => {
    const names = configuredThrottlerNames();
    expect(names.sort()).toEqual(['auth', 'global', 'read', 'short', 'write']);
    for (const handler of [HealthController.prototype.liveness, HealthController.prototype.readiness]) {
      for (const name of names) {
        expect(Reflect.getMetadata(`THROTTLER:SKIP${name}`, handler)).toBe(true);
      }
    }
  });

  it('2c. guards/interceptors/filters recognise the probes from the context alone', () => {
    expect(probeKindOfContext(probeContext('live', LIVE_REQ))).toBe('live');
    expect(probeKindOfContext(probeContext('ready', READY_REQ))).toBe('ready');
    expect(probeKindOfContext(businessContext())).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// 3. middleware-time identification, across every path representation
// ---------------------------------------------------------------------------
describe('PHASE Q2 — middleware identifies the probes before routing happens', () => {
  const representations = [
    // mounted under the global prefix (what Nest actually produces)
    { originalUrl: '/api/health/live', url: '/health/live', path: '/health/live', baseUrl: '/api' },
    // not mounted: url keeps the full path
    { originalUrl: '/api/health/live', url: '/api/health/live', path: '/api/health/live', baseUrl: '' },
    // with a query string
    { originalUrl: '/api/health/live?ts=1', url: '/health/live?ts=1', path: '/health/live', baseUrl: '/api' },
    // trailing slash
    { originalUrl: '/api/health/live/', url: '/health/live/', path: '/health/live/', baseUrl: '/api' },
    // only originalUrl present
    { originalUrl: '/api/health/ready' },
    // only url present, prefix-free
    { url: '/health/ready' },
  ];

  it.each(representations)('3. resolves %o', (req) => {
    expect(probeKindOfRequest(req)).toBeDefined();
  });

  it('3b. does NOT resolve lookalikes or any other route', () => {
    for (const req of [
      { originalUrl: '/api/health', url: '/health', path: '/health', baseUrl: '/api' },
      { originalUrl: '/api/health/liveness', url: '/health/liveness', path: '/health/liveness' },
      { originalUrl: '/api/health/live-x', url: '/health/live-x', path: '/health/live-x' },
      { originalUrl: '/api/health/details', url: '/health/details', path: '/health/details' },
      { originalUrl: '/api/health/metrics', url: '/health/metrics', path: '/health/metrics' },
      { originalUrl: '/api/members?limit=1', url: '/?limit=1', path: '/' },
      { originalUrl: '/', url: '/' },
      { originalUrl: '/api/auth/login', url: '/auth/login', method: 'POST' },
      undefined,
      null,
      {},
    ]) {
      expect(probeKindOfRequest(req)).toBeUndefined();
    }
  });

  it('3c. kinds are distinguished: live is a ping, ready reports dependencies', () => {
    expect(probeKindOfRequest(LIVE_REQ)).toBe('live');
    expect(probeKindOfRequest(READY_REQ)).toBe('ready');
  });
});

// ---------------------------------------------------------------------------
// 4/5. the global-component harness
// ---------------------------------------------------------------------------
type Covered = {
  name: string;
  kind: 'middleware' | 'guard' | 'interceptor' | 'filter';
  build: (rec: Recorder) => any;
};

function coveredComponents(): Covered[] {
  const reflector = () => new Reflector();
  return [
    // PHASE R0 added AdminHostGuard as the FIRST APP_GUARD in app.module.ts. Test 5b
    // is the tripwire that caught it: a new global component is not "covered" until
    // it is in this table and proven not to touch a collaborator on the probes.
    { name: 'AdminHostGuard', kind: 'guard', build: () => new AdminHostGuard(reflector()) },
    { name: 'RequestIdMiddleware', kind: 'middleware', build: () => new RequestIdMiddleware() },
    {
      name: 'IpShieldMiddleware',
      kind: 'middleware',
      build: (rec) => new IpShieldMiddleware(rec.stub('SecurityShieldService')),
    },
    { name: 'CsrfMiddleware', kind: 'middleware', build: () => new CsrfMiddleware() },
    // PHASE R1 added six global components. Each one is a no-op unless the route
    // carries @PlatformRoute(), and a health probe never does, so none of them may
    // touch Redis or the database on the probe path - which is what this table and
    // the tests around it prove rather than assume.
    { name: 'NullByteMiddleware', kind: 'middleware', build: () => new NullByteMiddleware() },
    {
      name: 'PlatformSessionGuard',
      kind: 'guard',
      build: (rec) => new PlatformSessionGuard(reflector(), rec.stub('PlatformSessionService'), rec.stub('PrismaService')),
    },
    { name: 'PlatformTotpEnrolmentGuard', kind: 'guard', build: () => new PlatformTotpEnrolmentGuard(reflector()) },
    { name: 'PlatformCsrfGuard', kind: 'guard', build: () => new PlatformCsrfGuard(reflector()) },
    { name: 'PlatformStepUpGuard', kind: 'guard', build: () => new PlatformStepUpGuard(reflector()) },
    { name: 'PlatformHeadersInterceptor', kind: 'interceptor', build: () => new PlatformHeadersInterceptor(reflector()) },
    {
      name: 'LicenceAvailabilityGuard',
      kind: 'guard',
      build: () => {
        const state = new LicenceStateService();
        // worst case: enforcement ON and the licence NOT verified
        state.markUnverified('unreachable');
        return new LicenceAvailabilityGuard(state);
      },
    },
    {
      name: 'ThrottlerGuard',
      kind: 'guard',
      build: (rec) => {
        const imports = (Reflect.getMetadata('imports', AppModule) || []) as any[];
        const dynamic = imports.find((m) => m && m.module && m.module.name === 'ThrottlerModule');
        const options = (dynamic.providers || []).find(
          (p: any) => String(p?.provide) === 'THROTTLER:MODULE_OPTIONS',
        ).useValue;
        const guard = new ThrottlerGuard(options, rec.stub('ThrottlerStorage'), reflector());
        // Nest calls this during initialisation; without it `throttlers` is unset
        (guard as any).onModuleInit();
        return guard;
      },
    },
    { name: 'JwtAuthGuard', kind: 'guard', build: () => new JwtAuthGuard(reflector()) },
    { name: 'TenantGuard', kind: 'guard', build: (rec) => new TenantGuard(rec.stub('PrismaService'), reflector()) },
    { name: 'RolesGuard', kind: 'guard', build: () => new RolesGuard(reflector()) },
    {
      name: 'PermissionsGuard',
      kind: 'guard',
      build: (rec) =>
        new PermissionsGuard(reflector(), rec.stub('PermissionsService'), new TenantContextService()),
    },
    { name: 'LicenseGuard', kind: 'guard', build: (rec) => new LicenseGuard(reflector(), rec.stub('LicenseService')) },
    {
      name: 'TenantContextInterceptor',
      kind: 'interceptor',
      build: () => new TenantContextInterceptor(new TenantContextService()),
    },
    {
      name: 'AuditInterceptor',
      kind: 'interceptor',
      build: (rec) => new AuditInterceptor(rec.stub('PrismaService'), reflector()),
    },
    { name: 'DependencyUnavailableFilter', kind: 'filter', build: () => new DependencyUnavailableFilter() },
    // registered by main.ts with useGlobalFilters (which runs ahead of APP_FILTER),
    // so it is not discoverable from AppModule's metadata — covered explicitly.
    { name: 'HttpExceptionFilter', kind: 'filter', build: () => new HttpExceptionFilter() },
  ];
}

async function invoke(component: Covered, instance: any, req: any): Promise<void> {
  const ctx =
    req === LIVE_REQ || req === READY_REQ
      ? probeContext(req === LIVE_REQ ? 'live' : 'ready', req)
      : businessContext(req);
  switch (component.kind) {
    case 'middleware': {
      const res = responseStub();
      // awaited: IpShieldMiddleware.use is async, and a collaborator call made
      // after an await must still be on the recorder when the assertion runs
      await instance.use(req, res, () => undefined);
      // a middleware that answered instead of calling next() would have set a
      // status; the probe must reach the controller
      expect(res.statusCode).toBe(0);
      return;
    }
    case 'guard':
      expect(await instance.canActivate(ctx)).not.toBe(false);
      return;
    case 'interceptor':
      instance.intercept(ctx, { handle: () => of(undefined) });
      return;
    case 'filter': {
      const res = responseStub();
      const host = {
        switchToHttp: () => ({ getResponse: () => res, getRequest: () => req }),
        getType: () => 'http' as const,
      } as any;
      try {
        instance.catch(new Error('connect ECONNREFUSED 127.0.0.1:6379'), host);
      } catch {
        // re-throwing an error it does not own is the documented behaviour
      }
      return;
    }
  }
}

describe('PHASE Q2 — no global component touches a collaborator on the probes', () => {
  let savedFlag: string | undefined;
  beforeEach(() => {
    savedFlag = process.env[LICENSE_REQUIRED_ENV];
    // worst case for the licence guard: enforcement ON, licence unverified
    process.env[LICENSE_REQUIRED_ENV] = 'true';
  });
  afterEach(() => {
    if (savedFlag === undefined) delete process.env[LICENSE_REQUIRED_ENV];
    else process.env[LICENSE_REQUIRED_ENV] = savedFlag;
  });

  it.each(['live', 'ready'] as const)(
    '5a. every global component lets GET /api/health/%s through without touching ANY collaborator',
    async (kind) => {
      const req = kind === 'live' ? LIVE_REQ : READY_REQ;
      const offenders: string[] = [];
      for (const component of coveredComponents()) {
        const rec = new Recorder();
        const instance = component.build(rec);
        await invoke(component, instance, req);
        if (rec.calls.length) {
          offenders.push(`${component.name} -> ${rec.calls.slice(0, 4).join(', ')}`);
        }
      }
      expect(offenders).toEqual([]);
    },
  );

  it('5a2. IpShieldMiddleware really is async and really does call next() for a probe', async () => {
    const rec = new Recorder();
    const mw = new IpShieldMiddleware(rec.stub('SecurityShieldService'));
    let nextCalled = false;
    const res = responseStub();
    await mw.use(LIVE_REQ, res, () => { nextCalled = true; });
    expect(nextCalled).toBe(true);
    expect(res.statusCode).toBe(0);
    expect(rec.calls).toEqual([]);
    // the canonical client IP is still attached: nothing downstream loses it
    expect(LIVE_REQ.__clientIp).toBe('127.0.0.1');
  });

  it('5b. tripwire: the global components registered by AppModule are exactly the ones covered here', () => {
    const providers = (Reflect.getMetadata('providers', AppModule) || []) as any[];
    const discovered = providers
      .filter((p) => p && (p.provide === APP_GUARD || p.provide === APP_INTERCEPTOR || p.provide === APP_FILTER))
      .map((p) => (p.useClass ? p.useClass.name : String(p.provide)));

    const applied: unknown[] = [];
    const proxy: any = {
      exclude: () => proxy,
      forRoutes: () => { applied.push(...pending); return proxy; },
    };
    let pending: unknown[] = [];
    const consumer = {
      apply: (...middleware: unknown[]) => { pending = middleware; return proxy; },
    } as unknown as MiddlewareConsumer;
    new AppModule().configure(consumer);
    const middlewareNames = applied.map((m: any) => m?.name || String(m));

    const covered = coveredComponents().map((c) => c.name);
    const all = [...new Set([...discovered, ...middlewareNames])].sort();
    const missing = all.filter((name) => !covered.includes(name));
    expect(missing).toEqual([]);
    // and nothing in the table has gone stale
    const stale = covered.filter(
      (name) => name !== 'HttpExceptionFilter' && !all.includes(name),
    );
    expect(stale).toEqual([]);
    // sanity: the harness is not enumerating an empty app
    expect(all.length).toBeGreaterThanOrEqual(12);
    expect(discovered).toContain('LicenceAvailabilityGuard');
    // PHASE R1 added NullByteMiddleware, registered between IpShieldMiddleware and
    // CsrfMiddleware in app.module.ts. This list is a tripwire on PURPOSE: a new global
    // middleware has to be added here AND to coveredComponents() above, which is what
    // forces the question "does it touch a collaborator on the probe path?" to be
    // answered rather than assumed. For NullByteMiddleware the answer is no - it is a
    // string check on req.url that answers 400 or calls next().
    expect(middlewareNames).toEqual(['RequestIdMiddleware', 'IpShieldMiddleware', 'NullByteMiddleware', 'CsrfMiddleware']);
  });

  it('5c. PHASE R0: the host gate never touches the probes, even when it refuses every hostname', () => {
    // Worst case for the gate: production with ADMIN_HOSTS unset, so the allow-list
    // is empty and EVERY hostname is refused (fail closed). docker-compose.yml's
    // healthcheck curls /api/health/live, and PHASE P requires the process to stay
    // up and answer it, so host gating must not be able to break the probes.
    const env = process.env as Record<string, string | undefined>;
    const savedNode = env.NODE_ENV;
    const savedHosts = env.ADMIN_HOSTS;
    try {
      env.NODE_ENV = 'production';
      delete env.ADMIN_HOSTS;
      const guard = new AdminHostGuard(new Reflector());

      // the probes pass, and the guard reads no collaborator to decide (the Recorder
      // in 5a is what proves that half; this is the decision itself)
      expect(guard.canActivate(probeContext('live', LIVE_REQ))).toBe(true);
      expect(guard.canActivate(probeContext('ready', READY_REQ))).toBe(true);

      // NOT VACUOUS: in the very same state, the same guard refuses a console route
      // carrying the same (absent) Host header the probes were just allowed through.
      const consoleReq = mountedRequest('/platform/overview');
      expect(() => guard.canActivate(platformContext(consoleReq))).toThrow(NotFoundException);

      // and it is not a blanket denial: name the hostname and the console route is
      // reached, which is the other half of "gating is host-based, not route-based".
      env.ADMIN_HOSTS = 'console.example.com';
      const adminReq = { ...consoleReq, headers: { ...consoleReq.headers, host: 'console.example.com' } };
      expect(guard.canActivate(platformContext(adminReq))).toBe(true);
      const publicReq = { ...consoleReq, headers: { ...consoleReq.headers, host: 'app.example.com' } };
      expect(() => guard.canActivate(platformContext(publicReq))).toThrow(NotFoundException);
    } finally {
      if (savedNode === undefined) delete env.NODE_ENV; else env.NODE_ENV = savedNode;
      if (savedHosts === undefined) delete env.ADMIN_HOSTS; else env.ADMIN_HOSTS = savedHosts;
    }
  });

  it('6. NEGATIVE CONTROL: the same harness sees a collaborator call on a business route', () => {
    // Without this, "zero calls" could be vacuous — a harness that never invoked
    // anything would pass test 5a too.
    const rec = new Recorder();
    const mw = new IpShieldMiddleware(rec.stub('SecurityShieldService'));
    const res = responseStub();
    // not awaited on purpose: the call is recorded synchronously before the await
    void mw.use(BUSINESS_REQ, res, () => undefined);
    expect(rec.calls.some((c) => c.includes('isBlocked'))).toBe(true);
  });

  it('6b. NEGATIVE CONTROL: the licence guard refuses a business route under the same conditions', () => {
    const state = new LicenceStateService();
    state.markUnverified('unreachable');
    const guard = new LicenceAvailabilityGuard(state);
    expect(() => guard.canActivate(businessContext())).toThrow();
    expect(guard.canActivate(probeContext('live', LIVE_REQ))).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// 7. the compose healthcheck still points at /live
// ---------------------------------------------------------------------------
describe('PHASE Q2 — the container healthcheck uses the liveness probe', () => {
  const compose = readFileSync(resolve(__dirname, '..', '..', '..', '..', '..', 'docker-compose.yml'), 'utf8');

  it('7. the api healthcheck curls /api/health/live and never /ready', () => {
    // SUBSTITUTE EVIDENCE: there is no Docker in this sandbox, so the healthcheck
    // is asserted from the compose file rather than from a running container.
    const curlChecks = compose.match(/test:\s*\[[^\]]*"curl"[^\]]*\]/g) || [];
    expect(curlChecks.length).toBe(1);
    expect(curlChecks[0]).toContain('/api/health/live');
    expect(curlChecks[0]).not.toContain('/api/health/ready');
    // /ready answers 503 when Redis is down, so pointing a container healthcheck at
    // it would restart a process that is perfectly able to serve.
    expect(compose).not.toMatch(/healthcheck[^\n]*\n[^\n]*health\/ready/);
  });
});
