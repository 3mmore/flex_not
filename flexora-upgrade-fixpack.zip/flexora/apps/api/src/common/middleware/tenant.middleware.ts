import { Injectable, NestMiddleware, Logger, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class TenantMiddleware implements NestMiddleware {
  private readonly logger = new Logger(TenantMiddleware.name);

  constructor(private prisma: PrismaService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    // NOTE: In NestJS, APP_GUARD providers run before
    // middleware in the execution pipeline when using
    // useGlobalGuards or APP_GUARD token.
    // JwtAuthGuard (registered as APP_GUARD) populates
    // req.user before this middleware executes.
    // Do NOT move JWT verification here.
    const publicPaths = [
      '/api/health', '/api/auth/register', '/api/auth/login', '/api/auth/refresh',
      '/api/auth/forgot-password', '/api/auth/reset-password', '/api/auth/2fa/login',
      '/api/portal/request-otp', '/api/portal/verify-otp',
      // PHASE R1 / owner decision: '/api/admin/login' is GONE. The module it belonged
      // to (modules/admin) was removed - it was a second, public administrator login
      // outside the R0 host gate. The entry was also dead on arrival: the real route
      // was /api/admin/auth/login, which does not start with '/api/admin/login'.
      '/api/billing/webhook', '/api/paymob/webhook',
    ];

    if (publicPaths.some(p => req.path.startsWith(p))) return next();

    const request = req as Request & { user?: { gymId?: string }; gym?: unknown; tenantId?: string };

    try {
      const user = request.user;
      if (!user || !user.gymId) {
        throw new UnauthorizedException('Tenant identification required');
      }

      const gym = await this.prisma.gym.findUnique({
        where: { id: user.gymId },
        select: { id: true, status: true, slug: true },
      });

      if (!gym || gym.status === 'SUSPENDED') {
        throw new UnauthorizedException('Gym account is suspended');
      }

      request['gym'] = gym;
      request['tenantId'] = user.gymId;
      next();
    } catch (error) {
      if (error instanceof UnauthorizedException) throw error;
      this.logger.error(`Tenant middleware error: ${(error as Error).message}`);
      throw new UnauthorizedException('Tenant verification failed');
    }
  }
}
