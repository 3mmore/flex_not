/**
 * FLEXORA Gym OS — Item 7 regression test: CSRF webhook bypass too broad.
 *
 * The old check `req.path.includes('/webhook')` matched ANY path
 * containing that substring anywhere — not just the real webhook routes —
 * so a crafted, non-webhook route like `/api/members/my-webhook-thing`
 * would also skip CSRF protection entirely.
 *
 * This test mounts the REAL CsrfMiddleware on a real Express app (via
 * supertest — genuine HTTP requests, not mocked function calls) and proves:
 *   1. A crafted fake path containing "webhook" that is NOT one of the
 *      real, enumerated webhook routes is now CSRF-protected (403 without
 *      a valid token).
 *   2. The real webhook routes are still correctly exempted.
 *   3. A normal, non-webhook mutating route is (as before) CSRF-protected.
 */
import express, { Express } from 'express';
import cookieParser from 'cookie-parser';
import request from 'supertest';
import { CsrfMiddleware } from './csrf.middleware';

function buildApp(): Express {
  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  const csrf = new CsrfMiddleware();
  app.use((req, res, next) => csrf.use(req, res, next));
  app.use((req, res) => res.status(200).json({ ok: true, path: req.path }));
  return app;
}

describe('CsrfMiddleware — Item 7: explicit webhook allow-list (no substring bypass)', () => {
  let app: Express;

  beforeEach(() => {
    app = buildApp();
  });

  it('CSRF-protects a crafted fake path that merely CONTAINS "webhook" but is not a real webhook route', async () => {
    // This is exactly the attack the old `req.path.includes('/webhook')`
    // check allowed through: a normal, non-webhook, tenant-scoped route
    // whose path happens to contain the substring "webhook".
    const res = await request(app).post('/api/members/my-webhook-thing').send({ evil: true });
    expect(res.status).toBe(403);
    // Note: this raw Express app has no NestJS HttpExceptionFilter attached
    // (that's app-level plumbing outside this middleware's own
    // responsibility), so Express's default error handler renders the
    // thrown HttpException's message as plain HTML/text rather than the
    // { statusCode, message } JSON shape the real Nest app would produce.
    // What matters for this test — and what changed — is the status code:
    // 403 (Forbidden) instead of 200 (the old bypass).
    expect(res.text).toMatch(/CSRF validation failed/i);
  });

  it('CSRF-protects another crafted fake path: /api/webhook-test (starts with "webhook" but is not in the allow-list)', async () => {
    const res = await request(app).post('/api/webhook-test').send({ evil: true });
    expect(res.status).toBe(403);
  });

  it('still exempts the real /api/billing/webhook route', async () => {
    const res = await request(app).post('/api/billing/webhook').send({ type: 'checkout.session.completed' });
    expect(res.status).toBe(200);
  });

  it('still exempts the real /api/stripe/webhook route', async () => {
    const res = await request(app).post('/api/stripe/webhook').send({});
    expect(res.status).toBe(200);
  });

  it('still exempts the real /api/paymob/webhook route', async () => {
    const res = await request(app).post('/api/paymob/webhook').send({});
    expect(res.status).toBe(200);
  });

  it('still exempts the real /api/webhooks/whatsapp route', async () => {
    const res = await request(app).post('/api/webhooks/whatsapp').send({});
    expect(res.status).toBe(200);
  });

  it('still exempts the real per-gym /api/wa-bot/webhook/:gymId route', async () => {
    const res = await request(app).post('/api/wa-bot/webhook/gym-123').send({});
    expect(res.status).toBe(200);
  });

  it('CSRF-protects an ordinary, non-webhook mutating route with no token (unchanged baseline behavior)', async () => {
    const res = await request(app).post('/api/members').send({ name: 'Test' });
    expect(res.status).toBe(403);
  });

  it('allows an ordinary mutating route through once a matching csrf cookie + header are presented', async () => {
    const agent = request.agent(app);
    // GET issues the _csrf cookie.
    await agent.get('/api/members');
    const cookies = (agent as unknown as { jar: { getCookiesSync: (url: string) => { key: string; value: string }[] } });
    // Simplest robust approach: perform a GET to capture Set-Cookie, then
    // reuse the same token as the X-CSRF-Token header on the POST.
    const getRes = await request(app).get('/api/members');
    const setCookie = getRes.headers['set-cookie'] as unknown as string[];
    const csrfCookieHeader = (Array.isArray(setCookie) ? setCookie : [setCookie]).find((c) => c.startsWith('_csrf='));
    expect(csrfCookieHeader).toBeDefined();
    const csrfValue = csrfCookieHeader!.split(';')[0].split('=')[1];

    const postRes = await request(app)
      .post('/api/members')
      .set('Cookie', [`_csrf=${csrfValue}`])
      .set('X-CSRF-Token', csrfValue)
      .send({ name: 'Test' });
    expect(postRes.status).toBe(200);
  });
});
