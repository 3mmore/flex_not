/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.8 — the response headers every platform API answer must carry.
 *
 * Measured BEFORE (work/r1-evidence/00-before.log B6.1): a platform API response
 * carried helmet's tenant CSP, `Referrer-Policy: strict-origin-when-cross-origin`,
 * TWO different X-Frame-Options values (SAMEORIGIN from helmet and DENY from
 * nginx) and no Cache-Control or X-Robots-Tag at all.
 *
 * The set below is applied by route metadata — the same @PlatformRoute() marker
 * the R0 host gate and the R1 credential guards use — never by matching a URL.
 *
 * Two notes on scope, both deliberate:
 *   - This is an interceptor, so it runs after the guards. A request a guard
 *     refuses (401/403/404) does not pass through here. At the production edge that
 *     does not matter, because nginx applies the same set to the whole
 *     /api/platform/ location, including refusals; direct-to-api refusals keep
 *     helmet's headers. Both cases are measured in the R1 evidence.
 *   - A JSON API needs no script, style, image or font source, so the CSP is
 *     default-src 'none'. The console PAGES get a different, nonce-based policy
 *     from the web middleware (owner decision D1) because Next injects inline
 *     flight-data scripts into every document.
 */
import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Response } from 'express';
import { Observable } from 'rxjs';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';

/** The canonical platform API header set, in one place so nginx can be checked against it. */
export const PLATFORM_API_HEADERS: ReadonlyArray<readonly [string, string]> = [
  ['Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"],
  ['X-Frame-Options', 'DENY'],
  ['X-Content-Type-Options', 'nosniff'],
  ['Referrer-Policy', 'no-referrer'],
  ['Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'],
  ['Pragma', 'no-cache'],
  ['Expires', '0'],
  ['X-Robots-Tag', 'noindex, nofollow, noarchive'],
];

/**
 * CORS headers that must NOT appear on a platform response (R1.8: no CORS). A
 * browser must never be able to read a console response from another origin, and a
 * preflight must not be answered for these routes.
 */
const CORS_HEADERS_TO_REMOVE = [
  'Access-Control-Allow-Origin',
  'Access-Control-Allow-Credentials',
  'Access-Control-Allow-Methods',
  'Access-Control-Allow-Headers',
  'Access-Control-Expose-Headers',
  'Access-Control-Max-Age',
];

/**
 * Apply the console header set to a response object.
 *
 * The interceptor covers responses that reach a handler. A request a GUARD refuses
 * never gets there, so each platform guard calls this before throwing: without it a
 * 401 or 403 on an administrator hostname answered with helmet's tenant headers
 * (X-Frame-Options SAMEORIGIN, no Cache-Control, no X-Robots-Tag). nginx appends its
 * own map-driven Referrer-Policy after the upstream's and the last value wins, so
 * these agree rather than fight.
 *
 * It is deliberately NOT called by AdminHostGuard: on a hostname that is not in
 * ADMIN_HOSTS a console path must be indistinguishable from a route that does not
 * exist, which is what the R0 harness proves (47 of 47 refusals). Adding console
 * headers there is exactly the leak R0 closed.
 */
export function applyPlatformHeaders(response: unknown): void {
  const res = response as { setHeader?: (name: string, value: string) => void; removeHeader?: (name: string) => void } | undefined;
  if (!res || typeof res.setHeader !== 'function') return;
  for (const [name, value] of PLATFORM_API_HEADERS) res.setHeader(name, value);
  if (typeof res.removeHeader === 'function') {
    for (const name of CORS_HEADERS_TO_REMOVE) res.removeHeader(name);
  }
}

@Injectable()
export class PlatformHeadersInterceptor implements NestInterceptor {
  constructor(private readonly reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const isPlatformRoute = this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPlatformRoute) applyPlatformHeaders(context.switchToHttp().getResponse<Response>());
    return next.handle();
  }
}
