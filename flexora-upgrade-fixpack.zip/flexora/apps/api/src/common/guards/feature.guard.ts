/**
 * FLEXORA Gym OS — Feature entitlement guard
 * © 2024 Ammar Allam. All rights reserved.
 */
import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { FEATURE_KEY, FeatureKey } from '../../modules/license/license.service';
import { PrismaService } from '../../config/prisma.service';

// NOTE: maxMembers/maxStaff here are informational only — this guard enforces
// the `features` set. The ENFORCED limits live in members.service.ts (member
// caps) and users.service.ts (staff caps); keep the numbers in sync with them
// and with docs/PLAN_TIER_LIMITS.md (old values 1/5 were stale).
const FEATURE_MATRIX: Record<string, { maxMembers: number; maxStaff: number; features: Set<string> }> = {
  BASIC: { maxMembers: 50, maxStaff: 3, features: new Set(['members', 'attendance', 'basic_reports']) },
  PRO: { maxMembers: 500, maxStaff: 10, features: new Set(['classes', 'pos', 'inventory', 'reports', 'advancedReports', 'crm', 'leads', 'contracts', 'staff_attendance', 'ai', 'whatsapp', 'sms', 'campaigns', 'apiAccess', 'multi_branch']) },
  ELITE: { maxMembers: Number.POSITIVE_INFINITY, maxStaff: Number.POSITIVE_INFINITY, features: new Set(['classes', 'pos', 'inventory', 'reports', 'advancedReports', 'crm', 'leads', 'contracts', 'staff_attendance', 'ai', 'whatsapp', 'sms', 'campaigns', 'apiAccess', 'multi_branch', 'whiteLabel', 'white_label', 'biometric', 'webauthn', 'priority_support', 'payroll', 'marketplace', 'enterprise', 'advanced_analytics']) },
};

const FEATURE_ALIASES: Record<string, string> = {
  reports: 'advancedReports',
  advanced_analytics: 'advancedReports',
  white_label: 'whiteLabel',
  payroll: 'payroll',
};

@Injectable()
export class FeatureGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const feature = this.reflector.getAllAndOverride<FeatureKey | undefined>(FEATURE_KEY, [context.getHandler(), context.getClass()]);
    if (!feature) return true;
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (user?.role === 'SUPER_ADMIN') return true;
    const gymId = request.gymId || request.tenantId || user?.gymId;
    if (!gymId || gymId === 'unknown') throw new ForbiddenException('tenant_missing');

    const subscription = await this.prisma.subscription.findUnique({ where: { gymId } }).catch(() => null);
    const plan = subscription?.tier || 'BASIC';
    const entitlement = FEATURE_MATRIX[plan] || FEATURE_MATRIX.BASIC;
    const normalized = FEATURE_ALIASES[String(feature)] || String(feature);
    if (!entitlement.features.has(normalized) && !entitlement.features.has(String(feature))) {
      throw new ForbiddenException('feature_upgrade_required');
    }
    return true;
  }
}
