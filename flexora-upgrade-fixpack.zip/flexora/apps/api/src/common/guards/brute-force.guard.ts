import { Injectable, CanActivate, ExecutionContext, HttpException, HttpStatus } from '@nestjs/common';
import { BruteForceService } from '../security/brute-force.service';
import { Request } from 'express';
import { Reflector } from '@nestjs/core';
import { BRUTE_FORCE_KEY } from '../decorators/brute-force.decorator';

/**
 * Brute-force protection guard (CHECK-ONLY).
 *
 * This guard runs BEFORE validation and authentication. Its job is:
 *  1. Check whether the IP is already locked out (based on the scope key).
 *  2. If locked, reject with 429.
 *  3. Otherwise, attach `__bruteForce` metadata to the request so that
 *     the CONTROLLER can call `registerFailure` on authentication failure
 *     and `reset` on success.
 *
 * The guard does NOT increment the failure counter. Incrementing here
 * would count legitimate (even successful) requests as failures and let
 * read/modify/write races defeat the limiter. The controller MUST:
 *  - Call bruteForceService.registerFailure(scope, key) after every
 *    authentication failure.
 *  - Call bruteForceService.reset(scope, key) after every successful
 *    authentication.
 *
 * Previously this guard locked out accounts by email/mobile, allowing an
 * attacker to permanently lock a victim's account by making 5 failed
 * login attempts with the victim's email — a classic account lockout attack.
 *
 * Now the guard:
 *  - Rate-limits by IP only (prevents targeted account lockout attacks)
 *  - Does NOT track email-based failures (that is the controller's job)
 *  - Never locks an account based on email alone
 */
@Injectable()
export class BruteForceGuard implements CanActivate {
  constructor(
    private readonly bruteForceService: BruteForceService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request & {
      __bruteForce?: { scope: string; key: string };
    }>();
    const ip = request.ip || request.socket.remoteAddress || 'unknown';
    const metadata = this.reflector.getAllAndOverride<string | boolean>(BRUTE_FORCE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    const scope = typeof metadata === 'string' ? metadata : 'auth';
    const key = `ip:${ip}`;

    // Guards run before validation and before authentication. They must only
    // check the current lock; incrementing here counts successful requests as
    // failures and lets read/modify/write races defeat the limiter.
    const result = await this.bruteForceService.check(scope, key);
    if (!result.allowed) {
      throw new HttpException(
        { message: 'Too many attempts. Try again later.', lockoutSeconds: result.lockoutSeconds },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    request.__bruteForce = { scope, key };
    return true;
  }
}
