/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { PrismaService } from '../../config/prisma.service';
import {
  applyBranchScopeToRequest,
  pinRequestQuery,
  resolveBranchScope,
} from '../branch-scope/branch-scope';

@Injectable()
export class TenantGuard implements CanActivate {
  private readonly logger = new Logger(TenantGuard.name);

  constructor(private readonly prisma: PrismaService, private readonly reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [context.getHandler(), context.getClass()]);
    if (isPublic) return true;
    const req = context.switchToHttp().getRequest();
    const user = req.user;
    if (!user) throw new ForbiddenException('unauthorized');

    const isPlatformRoute = this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPlatformRoute) {
      if (user.type !== 'platform') throw new ForbiddenException('platform_session_required');
      req.gymId = null;
      req.branchScope = resolveBranchScope({ role: 'SUPER_ADMIN', branchId: null });
      return true;
    }

    // ── PHASE 4: role-based branch scoping ──────────────────────────────
    // OWNER/MANAGER/SUPER_ADMIN stay unrestricted (unchanged behaviour).
    // Every other staff role is pinned to their own branch — and any explicit
    // request for a different branch is refused here, before a controller (or
    // a service, or the Prisma layer) ever sees it. This is what makes a
    // hand-edited `?branchId=…` URL or a direct curl call useless.
    const scope = resolveBranchScope(user);
    req.branchScope = scope;
    if (!scope.unrestricted) {
      // Read `req.query` exactly ONCE and keep our own reference: under
      // Express 5 the property is a re-parsing prototype getter (see
      // pinRequestQuery) so `applyBranchScopeToRequest` must receive the
      // captured object and the result must be pinned back onto the request.
      const normalisedQuery = (req.query ?? {}) as Record<string, unknown>;
      const { rejected } = applyBranchScopeToRequest(scope, normalisedQuery, req.body);
      pinRequestQuery(req, normalisedQuery);
      if (rejected.length) {
        this.logger.warn(
          `Blocked cross-branch access: user=${user.sub} role=${scope.role} ` +
          `pinned=${scope.filterBranchId} attempted=[${rejected.join(', ')}] path=${req.originalUrl || req.url}`,
        );
        throw new ForbiddenException({
          code: 'BRANCH_FORBIDDEN',
          translationKey: 'error_branch_forbidden',
          message:
            'Your account is restricted to a single branch, so you cannot access data from another branch.',
          branchId: scope.branchId,
          attempted: rejected,
        });
      }
    }

    if (user.role === 'SUPER_ADMIN') {
      const rawGymId = req.headers['x-gym-id'];
      if (rawGymId) {
        if (Array.isArray(rawGymId) || typeof rawGymId !== 'string' || !rawGymId.trim()) {
          throw new ForbiddenException('invalid_tenant_id');
        }
        const trimmedGymId = rawGymId.trim();
        const gym = await this.prisma.gym.findUnique({
          where: { id: trimmedGymId },
          select: { id: true, status: true },
        });
        if (!gym) {
          throw new ForbiddenException('tenant_not_found');
        }
        req.gymId = trimmedGymId;
      } else {
        req.gymId = null;
      }
      return true;
    }
    if (!user.gymId) throw new ForbiddenException('tenant_missing');
    const requestedGymId = req.headers['x-gym-id'];
    if (requestedGymId && requestedGymId !== user.gymId) {
      throw new ForbiddenException('tenant_mismatch');
    }
    const gym = await this.prisma.gym.findUnique({
      where: { id: user.gymId },
      select: { status: true },
    });
    if (!gym || gym.status === 'SUSPENDED' || gym.status === 'DELETED') {
      throw new ForbiddenException('license_suspended');
    }
    req.gymId = user.gymId;
    return true;
  }
}
