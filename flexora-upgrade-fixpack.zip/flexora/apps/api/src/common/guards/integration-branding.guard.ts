import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';

/**
 * ROUND 14 (security review, PHASE F4) — "Managers may change integrations
 * and branding" switch (Gym.managersMayChangeIntegrations, default OFF).
 *
 * The integrations & branding surfaces (white-label domains/branding, the
 * WhatsApp bot, messaging/notification configuration, gym branding, and AI
 * action approvals) are @Permissions('settings.manage') — which MANAGER holds
 * by default. This guard layers the owner-level switch on top: when the
 * switch is OFF (the default), those endpoints require the OWNER role even
 * for a MANAGER holding settings.manage. When the owner turns the switch ON,
 * managers may change them again.
 *
 * Runs after the global guards (JwtAuth/Tenant/Roles/Permissions), so
 * request.user and request.gymId are already resolved.
 */
@Injectable()
export class IntegrationBrandingGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const gymId = request.gymId ?? user?.gymId ?? null;
    if (!user) throw new ForbiddenException('Authenticated staff context is required');
    // The OWNER always may (the switch is the owner's own policy).
    if (user.role === 'OWNER' || user.role === 'SUPER_ADMIN') return true;
    if (!gymId) throw new ForbiddenException('Tenant context is required');
    const gym = await this.prisma.gym.findFirst({ where: { id: gymId }, select: { managersMayChangeIntegrations: true } });
    if (gym?.managersMayChangeIntegrations === true) return true;
    throw new ForbiddenException({
      code: 'OWNER_ONLY_INTEGRATIONS',
      message: 'Changing integrations and branding is owner-only. Ask the gym owner to enable "Managers may change integrations and branding" in Settings.',
    });
  }
}
