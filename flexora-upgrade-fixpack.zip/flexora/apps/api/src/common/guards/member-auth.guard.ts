import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { RedisService } from '../../config/redis.service';
import { Request } from 'express';

@Injectable()
export class MemberAuthGuard implements CanActivate {
  constructor(
    private jwtService: JwtService,
    private redis: RedisService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request & { cookies?: Record<string, string>; member?: unknown; gymId?: string }>();
    // ROUND 14 (security review, PHASE F2): the member token is accepted from
    // the HttpOnly cookie ONLY — never from an Authorization header (a header
    // can be set by any JS, re-introducing the token-theft path this phase
    // closes). The cookie is SameSite=Strict, so cross-site requests do not
    // carry it.
    const token = request.cookies?.flx_member_access;
    if (!token) throw new UnauthorizedException('Member authentication required');

    try {
      const payload = await this.jwtService.verifyAsync(token, {
        secret: process.env.JWT_MEMBER_SECRET,
        algorithms: ['HS256'],
      });

      if (payload.role !== 'MEMBER' || !payload.sub || !payload.gymId) {
        throw new UnauthorizedException('Member token required');
      }

      // Server-side revocation check: if the member's token has been revoked
      // (e.g. via logout), the token's jti (if present) or the member's
      // session is listed in Redis as revoked. This prevents use of stolen
      // tokens even before they expire.
      try {
        const jti = payload.jti;
        if (jti) {
          const revoked = await this.redis.client.get(`member:revoked:${jti}`);
          if (revoked) {
            throw new UnauthorizedException('Member session revoked');
          }
        }
        // Also check member-level revocation (all sessions revoked)
        const memberRevoked = await this.redis.client.get(`member:revoked-all:${payload.sub}`);
        if (memberRevoked) {
          throw new UnauthorizedException('Member session revoked');
        }
      } catch (e) {
        if (e instanceof UnauthorizedException) throw e;
        // Redis unavailable — fall back to JWT-only validation
      }

      request.member = payload;
      request.gymId = payload.gymId;
      return true;
    } catch {
      throw new UnauthorizedException('Invalid or expired member token');
    }
  }
}
