/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - AdminHostGuard: the owner-console host gate, proven by ATTACK ATTEMPTS.
 *
 * Nothing in this file asserts what the code says; every test issues a real HTTP
 * request through a real Nest application and asserts the response an attacker
 * would actually receive. The definition of success is the one the owner set:
 * a refused console request must be INDISTINGUISHABLE from a route that does not
 * exist - same status, same content type, same header names, same body once the two
 * legitimately volatile fields (the timestamp and the echoed request path) are
 * normalised.
 *
 * Test 12 is the mutation proof required by the phase rules: the very same
 * controllers, wired WITHOUT the guard, answer 200 on a public hostname. So the 404s
 * asserted above are produced by this guard, and removing it turns this suite red.
 */
import { Controller, Get, Module, Post } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { Test, TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';

import { PlatformRoute } from '../decorators/platform-route.decorator';
import { AdminHostGuard } from './admin-host.guard';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';

// ── fixtures ────────────────────────────────────────────────────────────────
// The marked controller is NOT named "platform" on purpose: the gate must key on
// the @PlatformRoute() marker, never on the URL (test 4).
@Controller('owner-desk')
@PlatformRoute()
class MarkedController {
  @Get('overview')
  overview() {
    return { reached: 'owner-desk/overview' };
  }

  @Post('login')
  login() {
    return { reached: 'owner-desk/login' };
  }
}

// One controller, two routes, only one marked: proves the granularity is per-route
// metadata and that an unmarked sibling in a marked-by-method controller is untouched.
@Controller('mixed')
class MixedController {
  @Get('open')
  open() {
    return { reached: 'mixed/open' };
  }

  @PlatformRoute()
  @Get('secret')
  secret() {
    return { reached: 'mixed/secret' };
  }
}

@Controller('tenant')
class TenantController {
  @Get('plans')
  plans() {
    return { reached: 'tenant/plans' };
  }
}

const CONTROLLERS = [MarkedController, MixedController, TenantController];

@Module({
  controllers: CONTROLLERS,
  providers: [{ provide: APP_GUARD, useClass: AdminHostGuard }],
})
class GatedModule {}

// Identical app, minus the guard: the mutation proof (test 12).
@Module({ controllers: CONTROLLERS })
class UngatedModule {}

const ADMIN_HOST = 'console.test';
const PUBLIC_HOST = 'app.test';

let gated: INestApplication;
let ungated: INestApplication;
let savedAdminHosts: string | undefined;
let savedNodeEnv: string | undefined;
let savedHops: string | undefined;

/** Strip the two fields that legitimately differ between any two 404 bodies. */
function normalise(body: string, path: string): string {
  return body
    .replace(/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?Z/g, '<TS>')
    .split(path)
    .join('<PATH>');
}

function headerNames(res: { headers: Record<string, unknown> }): string[] {
  return Object.keys(res.headers).map((h) => h.toLowerCase()).sort();
}

async function buildApp(moduleClass: unknown): Promise<INestApplication> {
  const fixture: TestingModule = await Test.createTestingModule({
    imports: [moduleClass as never],
  }).compile();
  const app = fixture.createNestApplication();
  app.setGlobalPrefix('api');
  await app.init();
  return app;
}

beforeAll(async () => {
  savedAdminHosts = process.env[ADMIN_HOSTS_VAR];
  savedNodeEnv = process.env.NODE_ENV;
  savedHops = process.env.TRUST_PROXY_HOPS;
  process.env.NODE_ENV = 'test';
  process.env[ADMIN_HOSTS_VAR] = ADMIN_HOST;
  delete process.env.TRUST_PROXY_HOPS;
  gated = await buildApp(GatedModule);
  ungated = await buildApp(UngatedModule);
});

afterAll(async () => {
  await gated?.close();
  await ungated?.close();
  if (savedAdminHosts === undefined) delete process.env[ADMIN_HOSTS_VAR];
  else process.env[ADMIN_HOSTS_VAR] = savedAdminHosts;
  if (savedNodeEnv === undefined) delete process.env.NODE_ENV;
  else process.env.NODE_ENV = savedNodeEnv;
  if (savedHops === undefined) delete process.env.TRUST_PROXY_HOPS;
  else process.env.TRUST_PROXY_HOPS = savedHops;
});

describe('PHASE R0 - AdminHostGuard (attack attempts)', () => {
  it('1. ATTACK: a marked route on a public hostname is refused with a 404 that is indistinguishable from an unknown route', async () => {
    const server = gated.getHttpServer();
    const attacked = await request(server).get('/api/owner-desk/overview').set('Host', PUBLIC_HOST);
    const unknown = await request(server).get('/api/this-route-does-not-exist').set('Host', PUBLIC_HOST);

    expect(attacked.status).toBe(404);
    expect(unknown.status).toBe(404);
    expect(attacked.headers['content-type']).toBe(unknown.headers['content-type']);
    expect(headerNames(attacked)).toEqual(headerNames(unknown));
    expect(normalise(JSON.stringify(attacked.body), '/api/owner-desk/overview')).toBe(
      normalise(JSON.stringify(unknown.body), '/api/this-route-does-not-exist'),
    );
    // and the refusal must not explain itself
    expect(JSON.stringify(attacked.body)).not.toMatch(/admin|console|platform|host|forbidden|unauthor/i);
  });

  it('2. ATTACK: a POST to a marked route on a public hostname is refused the same way a POST to an unknown route is', async () => {
    const server = gated.getHttpServer();
    const attacked = await request(server)
      .post('/api/owner-desk/login')
      .set('Host', PUBLIC_HOST)
      .send({ email: 'nobody@example.com', password: 'whatever' });
    const unknown = await request(server)
      .post('/api/this-route-does-not-exist')
      .set('Host', PUBLIC_HOST)
      .send({ email: 'nobody@example.com', password: 'whatever' });

    expect(attacked.status).toBe(404);
    expect(attacked.headers['content-type']).toBe(unknown.headers['content-type']);
    expect(headerNames(attacked)).toEqual(headerNames(unknown));
    expect(normalise(JSON.stringify(attacked.body), '/api/owner-desk/login')).toBe(
      normalise(JSON.stringify(unknown.body), '/api/this-route-does-not-exist'),
    );
  });

  it('3. the same routes answer normally on an admin hostname (the gate does not break the console)', async () => {
    const server = gated.getHttpServer();
    const overview = await request(server).get('/api/owner-desk/overview').set('Host', ADMIN_HOST);
    expect(overview.status).toBe(200);
    expect(overview.body).toEqual({ reached: 'owner-desk/overview' });

    // Nest answers a POST with 201 by default; the point is that the gate let it through.
    const login = await request(server).post('/api/owner-desk/login').set('Host', ADMIN_HOST);
    expect(login.status).toBe(201);
    expect(login.body).toEqual({ reached: 'owner-desk/login' });
  });

  it('4. route identity is METADATA, not the URL: a route whose path never mentions platform is gated, and a marked method is gated while its unmarked sibling is not', async () => {
    const server = gated.getHttpServer();
    // 'owner-desk' contains no 'platform' substring, yet it is gated because it is marked
    expect((await request(server).get('/api/owner-desk/overview').set('Host', PUBLIC_HOST)).status).toBe(404);
    // same controller, one marked method and one not
    expect((await request(server).get('/api/mixed/secret').set('Host', PUBLIC_HOST)).status).toBe(404);
    const open = await request(server).get('/api/mixed/open').set('Host', PUBLIC_HOST);
    expect(open.status).toBe(200);
    expect(open.body).toEqual({ reached: 'mixed/open' });
  });

  it('5. NEGATIVE CONTROL: an unmarked tenant route is untouched on every hostname', async () => {
    const server = gated.getHttpServer();
    for (const host of [PUBLIC_HOST, ADMIN_HOST, 'anything.at.all']) {
      const res = await request(server).get('/api/tenant/plans').set('Host', host);
      expect(res.status).toBe(200);
      expect(res.body).toEqual({ reached: 'tenant/plans' });
    }
  });

  it('6. ATTACK: X-Forwarded-Host cannot open the console from a public Host', async () => {
    const server = gated.getHttpServer();
    const res = await request(server)
      .get('/api/owner-desk/overview')
      .set('Host', PUBLIC_HOST)
      .set('X-Forwarded-Host', ADMIN_HOST);
    expect(res.status).toBe(404);
    expect(JSON.stringify(res.body)).not.toMatch(/forward/i);
  });

  it('7. ATTACK: a forwarded host that contradicts an allowed Host is refused too (fail closed on ambiguity)', async () => {
    const server = gated.getHttpServer();
    const res = await request(server)
      .get('/api/owner-desk/overview')
      .set('Host', ADMIN_HOST)
      .set('X-Forwarded-Host', PUBLIC_HOST);
    expect(res.status).toBe(404);
  });

  it('8. a forwarded host that AGREES is allowed, and with TRUST_PROXY_HOPS=0 it is ignored entirely', async () => {
    const server = gated.getHttpServer();
    const agreeing = await request(server)
      .get('/api/owner-desk/overview')
      .set('Host', ADMIN_HOST)
      .set('X-Forwarded-Host', ADMIN_HOST);
    expect(agreeing.status).toBe(200);

    process.env.TRUST_PROXY_HOPS = '0';
    const ignored = await request(server)
      .get('/api/owner-desk/overview')
      .set('Host', ADMIN_HOST)
      .set('X-Forwarded-Host', PUBLIC_HOST);
    expect(ignored.status).toBe(200);
    delete process.env.TRUST_PROXY_HOPS;
  });

  it('9. hostname spelling: case, an explicit port and a trailing root dot are the same host', async () => {
    const server = gated.getHttpServer();
    for (const host of ['CONSOLE.TEST', 'console.test:443', 'console.test.']) {
      const res = await request(server).get('/api/owner-desk/overview').set('Host', host);
      expect(res.status).toBe(200);
    }
  });

  it('10. ATTACK: a hostname that merely contains an allowed one is refused', async () => {
    const server = gated.getHttpServer();
    for (const host of ['console.test.evil.example', 'xconsole.test', 'not-console.test']) {
      expect((await request(server).get('/api/owner-desk/overview').set('Host', host)).status).toBe(404);
    }
  });

  it('11. a wildcard ADMIN_HOSTS never opens the console: the entry is dropped and everything is refused', async () => {
    const server = gated.getHttpServer();
    process.env[ADMIN_HOSTS_VAR] = '*';
    expect((await request(server).get('/api/owner-desk/overview').set('Host', ADMIN_HOST)).status).toBe(404);
    expect((await request(server).get('/api/owner-desk/overview').set('Host', PUBLIC_HOST)).status).toBe(404);

    // production with no value at all fails closed as well
    process.env.NODE_ENV = 'production';
    delete process.env[ADMIN_HOSTS_VAR];
    expect((await request(server).get('/api/owner-desk/overview').set('Host', 'localhost')).status).toBe(404);

    process.env.NODE_ENV = 'test';
    process.env[ADMIN_HOSTS_VAR] = ADMIN_HOST;
  });

  it('12. MUTATION PROOF: the identical app without AdminHostGuard serves the console to a public hostname', async () => {
    const server = ungated.getHttpServer();
    const overview = await request(server).get('/api/owner-desk/overview').set('Host', PUBLIC_HOST);
    expect(overview.status).toBe(200);
    expect(overview.body).toEqual({ reached: 'owner-desk/overview' });
    const secret = await request(server).get('/api/mixed/secret').set('Host', PUBLIC_HOST);
    expect(secret.status).toBe(200);
    // ... which is exactly what the guard prevents, so deleting the guard's
    // registration from app.module.ts turns tests 1, 2, 4, 6, 7, 10 and 11 red.
  });

  it('13. the refusal does not add an admin-specific response header', async () => {
    const server = gated.getHttpServer();
    const refused = await request(server).get('/api/owner-desk/overview').set('Host', PUBLIC_HOST);
    const unknown = await request(server).get('/api/nope-not-here').set('Host', PUBLIC_HOST);
    expect(headerNames(refused)).toEqual(headerNames(unknown));
    for (const name of headerNames(refused)) {
      expect(name).not.toMatch(/admin|console|platform/);
    }
  });
});
