/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console host gate (api side).
 *
 * WHAT IT DOES
 * A request whose Host is not in ADMIN_HOSTS never reaches a platform handler.
 * It is answered with exactly the response Nest produces for a route that does
 * not exist: same status, same content type, same header set, same body shape,
 * with the requested path echoed the same way. An attacker on the public
 * hostname therefore cannot distinguish "there is an admin console here but you
 * may not in" from "there is nothing here" - which is the whole point.
 *
 * ROUTE IDENTITY COMES FROM METADATA, NOT FROM URL STRINGS (owner rule, PHASE Q).
 * The gate reads the `@PlatformRoute()` marker off the matched handler and its
 * controller, exactly like PlatformAdminGuard does. Two measured reasons a string
 * match cannot be used (both recorded in PHASE Q2, src/common/health/probe-routes.ts):
 * `setGlobalPrefix('api')` rewrites `req.url` inside middleware mounted at `/api/*`,
 * while `MiddlewareConsumer.exclude()`/`.forRoutes()` PREPEND the prefix, so a
 * literal such as `api/platform/overview` is registered as `/api/api/platform/...`
 * and silently matches nothing. A decorator cannot be decorated away either
 * (`//api/platform/overview`, `/%70latform/overview`, a trailing slash).
 *
 * ORDER MATTERS: this guard is registered as the FIRST APP_GUARD in app.module.ts,
 * ahead of LicenceAvailabilityGuard, ThrottlerGuard and JwtAuthGuard. Consequences,
 * all intended:
 *   - an unverified licence cannot turn a public-host probe into a 503
 *     LICENCE_UNVERIFIED (which would itself confirm the route exists);
 *   - the throttler never counts a public-host request, so an attacker cannot use
 *     the console's own rate limiter to lock the owner out;
 *   - the login brute-force counter is never touched from a public host.
 *
 * WHAT IT IS NOT (owner decision, PHASE R0)
 * Host gating is an ISOLATION LAYER. It is not authentication, not authorization
 * and not network security: an attacker who can open a socket to the api port
 * directly can send `Host: localhost` and pass. The defence against that is the
 * platform session (R1), the RBAC guard and not publishing the port. Nothing in
 * this file may be read as making a platform route safe to expose.
 */
import { CanActivate, ExecutionContext, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';

import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { ADMIN_HOSTS_VAR, adminHostsConfig, adminHostVerdict } from '../../config/admin-hosts';

@Injectable()
export class AdminHostGuard implements CanActivate {
  private readonly logger = new Logger('AdminHostGate');
  /** One warning per distinct (host, reason) pair, so a scanner cannot flood the log. */
  private readonly warned = new Set<string>();

  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    // 1. Is this a platform route at all? Metadata only - never a URL string.
    const marked = this.reflector.getAllAndOverride<boolean | undefined>(IS_PLATFORM_ROUTE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!marked) return true; // tenant routes: untouched, on every host

    const req = context.switchToHttp().getRequest<Request>();
    const verdict = adminHostVerdict(req.headers ?? {}, adminHostsConfig());
    if (verdict.allowed) return true;

    // 2. Refuse - indistinguishably. `Cannot <METHOD> <path>` with the path taken
    //    from the request is literally what Nest throws for an unmatched route, and
    //    HttpExceptionFilter renders it into {statusCode,path,timestamp,message}.
    //    No explanation, no admin-specific header, no distinct status code.
    const host = String(req.headers?.host ?? '<none>');
    const key = `${host}|${verdict.reason}`;
    if (!this.warned.has(key) && this.warned.size < 200) {
      this.warned.add(key);
      // The host is not a secret and is already in every access log; the reason is
      // one of four fixed words. Nothing else about the request is logged here.
      this.logger.warn(
        `console route refused: host=${host} reason=${verdict.reason} ` +
          `(${ADMIN_HOSTS_VAR} decides which hostnames may serve the owner console)`,
      );
    }
    throw new NotFoundException(`Cannot ${req.method} ${req.originalUrl}`);
  }
}
