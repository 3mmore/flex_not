/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 / review item 1 — the platform credential path.
 *
 * THE BUG THIS REPLACES (measured, work/r1-evidence/00-before.log B1.1 and B7.4):
 * a successful console login set `flx_platform_token`, and every console call then
 * returned 401 "Invalid or expired token". Two independent causes, both in the
 * tenant path:
 *
 *   1. jwt.strategy.ts:32 offered `flx_platform_token` to the TENANT extractor, so
 *      the tenant strategy was the thing validating a platform credential;
 *   2. jwt.strategy.ts validate() resolves `payload.sub` against the "User" table
 *      through preauth_find_user_by_id. A platform token's `sub` is a
 *      PlatformAdmin id, so that lookup returns zero rows, validate() returns
 *      null, and the guard 401s. Fixing only the extractor (or only line 60 of
 *      jwt-auth.guard.ts, which is the test-injection path) would not have worked.
 *
 * WHAT THIS GUARD GUARANTEES, in both directions:
 *
 *   - a platform session is accepted ONLY on routes marked @PlatformRoute(). On
 *     every other route this guard is a no-op and never even reads the cookie, so
 *     a platform credential cannot be presented to tenant code;
 *   - a tenant credential is never accepted here: the token must be signed with
 *     JWT_PLATFORM_SECRET (which the boot validator refuses to let equal any
 *     tenant secret), must carry aud=flexora-platform-admin and type=platform, and
 *     must name a live PlatformSession row whose subject is an ACTIVE
 *     PlatformAdmin. A tenant JWT fails the signature check before any of that.
 *
 * Every refusal collapses to the same 401 with the same body. The internal reason
 * is logged (bounded) and audit-relevant, but it is never in the response: an
 * attacker must not be able to distinguish "no such session" from "idle-expired"
 * from "wrong audience".
 */
import { CanActivate, ExecutionContext, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Request } from 'express';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { PrismaService } from '../../config/prisma.service';
import { applyPlatformHeaders } from '../interceptors/platform-headers.interceptor';
import {
  PLATFORM_COOKIE_NAME,
  PlatformSessionService,
  type SessionRefusal,
} from '../../modules/platform-auth/platform-session.service';

/** What this guard puts on the request for the guards and handlers behind it. */
export interface PlatformRequestUser {
  id: string;
  sub: string;
  email: string;
  name: string;
  role: string;
  type: 'platform';
  sessionId: string;
  /** True while TOTP enrolment is outstanding. Authoritative source: the admin row. */
  totpPending: boolean;
  totpEnabled: boolean;
  stepUpValid: boolean;
}

export type PlatformRequest = Request & {
  user?: PlatformRequestUser;
  platformSessionId?: string;
  platformStepUpExpiresAt?: Date | null;
};

@Injectable()
export class PlatformSessionGuard implements CanActivate {
  private readonly logger = new Logger(PlatformSessionGuard.name);
  /** One warning per refusal reason, so a credential-stuffing run cannot flood the log. */
  private readonly warned = new Set<string>();
  private static readonly WARN_CAP = 40;

  constructor(
    private readonly reflector: Reflector,
    private readonly sessions: PlatformSessionService,
    private readonly prisma: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const handler = context.getHandler();
    const controller = context.getClass();
    const isPlatformRoute = this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [handler, controller]);

    // Not a platform route: this guard does nothing at all. In particular it does
    // not read flx_platform_token, so a platform credential has no meaning here.
    if (!isPlatformRoute) return true;

    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [handler, controller]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest<PlatformRequest>();
    const token = extractPlatformToken(request);
    if (!token) throw this.refuse('no-credential', request);

    const checked = await this.sessions.verifyToken(token);
    if (!checked.ok) throw this.refuse(checked.reason, request);

    const { session, admin } = checked;
    const totpPending = admin.totpEnabled !== true;

    // Keep the stored flag honest: it is what the security centre lists, and a CLI
    // TOTP reset (decision D4) must show up on an already-issued session.
    if (session.totpPending !== totpPending) {
      await this.prisma.platformSession.update({ where: { id: session.id }, data: { totpPending } }).catch(() => undefined);
    }

    request.user = {
      id: admin.id,
      sub: admin.id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
      type: 'platform',
      sessionId: session.id,
      totpPending,
      totpEnabled: admin.totpEnabled === true,
      stepUpValid: this.sessions.stepUpIsValid(session),
    };
    request.platformSessionId = session.id;
    request.platformStepUpExpiresAt = session.stepUpExpiresAt;
    return true;
  }

  private refuse(reason: SessionRefusal | 'no-credential', request: PlatformRequest): UnauthorizedException {
    applyPlatformHeaders(request.res);
    if (this.warned.size < PlatformSessionGuard.WARN_CAP && !this.warned.has(reason)) {
      this.warned.add(reason);
      // Path and reason only. No token, no cookie value, no administrator identity.
      this.logger.warn(`platform session refused (${reason}) for ${request.method} ${request.path}`);
    }
    // Identical for every reason: same status, same message, same shape.
    return new UnauthorizedException('Invalid or expired token');
  }
}

/**
 * The platform credential, from the cookie first and the Authorization header
 * second. Both are validated identically. The cookie is the console's normal
 * shape; the header exists so an operator can drive the api from a script without
 * a browser, and it is NOT a tenant token path — a tenant Bearer token fails the
 * platform signature check.
 */
export function extractPlatformToken(request: PlatformRequest): string | null {
  const cookies = (request as { cookies?: Record<string, string> }).cookies;
  const fromCookie = cookies?.[PLATFORM_COOKIE_NAME];
  if (fromCookie && typeof fromCookie === 'string' && fromCookie.includes('.')) return fromCookie;
  const header = request.headers?.authorization;
  if (typeof header === 'string' && header.startsWith('Bearer ')) {
    const value = header.slice(7).trim();
    if (value.includes('.')) return value;
  }
  return null;
}
