/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.5 — step-up assertion for the sensitive console actions.
 *
 * A console session lives up to eight hours, and the owner mostly uses a phone
 * that may be handed to somebody else or left unlocked. Password + TOTP at login
 * is therefore not a strong enough assertion for granting a free year of service,
 * suspending a gym, deleting one, or creating another administrator.
 *
 * POST /api/platform/auth/step-up verifies a fresh TOTP code and stamps the
 * CURRENT SESSION with a claim that expires five minutes later. This guard refuses
 * any handler marked @RequireStepUp('reason') when that claim is absent or spent.
 *
 * The claim lives on the session row, not in the token, so:
 *   - it cannot be forged or extended by editing a cookie;
 *   - it dies with the session (logout, revocation, idle timeout, rotation);
 *   - a step-up taken on the owner's phone does not authorise the desktop.
 *
 * Route selection is metadata. A test enumerates every state-changing handler
 * under a @PlatformRoute() controller and fails if one that should require step-up
 * is unmarked, so a new console endpoint cannot quietly skip this.
 */
import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { REQUIRE_STEP_UP_KEY } from '../decorators/platform-auth.decorators';
import type { PlatformRequest } from './platform-session.guard';
import { applyPlatformHeaders } from '../interceptors/platform-headers.interceptor';

export const STEP_UP_REQUIRED_CODE = 'STEP_UP_REQUIRED';

@Injectable()
export class PlatformStepUpGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const handler = context.getHandler();
    const controller = context.getClass();
    if (!this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [handler, controller])) return true;

    const reason = this.reflector.getAllAndOverride<string>(REQUIRE_STEP_UP_KEY, [handler, controller]);
    if (!reason) return true;

    const request = context.switchToHttp().getRequest<PlatformRequest>();
    const user = request.user;
    if (!user) return true; // PlatformSessionGuard already refused; do not answer twice
    if (user.stepUpValid) return true;

    applyPlatformHeaders(context.switchToHttp().getResponse());
    throw new ForbiddenException({
      statusCode: 403,
      code: STEP_UP_REQUIRED_CODE,
      message: 'This action needs a fresh authenticator assertion',
      // The reason is echoed so the console can say what it is about to do
      // ("Suspend gym") before asking for the code. It is developer-authored
      // text from a decorator, never user input.
      action: reason,
    });
  }
}
