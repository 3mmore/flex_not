/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE P3 — one place that turns "a dependency this request needs is not
 * answering" into a bounded, honest 503.
 *
 * Two failure modes used to reach the client as either a hang or a 500:
 *
 *   - Redis unreachable: an awaited command never settled (`maxRetriesPerRequest:
 *     null` + an offline queue), so the request hung until the client or the
 *     proxy gave up. Everything on that path is now bounded (see
 *     config/redis.service.ts), which means it REJECTS — and a rejection used to
 *     surface as a 500 with a stack-ish message, which both hides the real cause
 *     and tells a client to give up instead of retrying.
 *   - Licence unverified: see LicenceAvailabilityGuard, which throws a
 *     ServiceUnavailableException carrying the LICENCE_UNVERIFIED code.
 *
 * A 503 without `Retry-After` is a guess for the client; with it, retries are
 * scheduled. Both cases are transient by definition, so both get the header.
 * Nothing here logs or returns a URL, key, token or licence detail.
 */
import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Response } from 'express';

/** Stable machine-readable codes, so a client can branch without parsing prose. */
export const REDIS_UNAVAILABLE = 'REDIS_UNAVAILABLE';
export const LICENCE_UNVERIFIED = 'LICENCE_UNVERIFIED';

/** Seconds a client should wait before retrying a 503 from this filter. */
export const RETRY_AFTER_SECONDS = 5;

const REDIS_ERROR_PATTERN =
  /ECONNREFUSED|ECONNRESET|ETIMEDOUT|EAI_AGAIN|Connection is closed|Connection lost|Ready check failed|Command timed out|maxRetriesPerRequest|Couldn't connect to Redis|Redis connection|Stream isn't writeable|enableOfflineQueue|Connection not ready|Stream not writeable/i;

export function isRedisUnavailableError(err: unknown): boolean {
  if (!err) return false;
  const e = err as { code?: string; message?: string; name?: string };
  const code = typeof e.code === 'string' ? e.code : '';
  if (['ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(code)) return true;
  const text = `${e.name || ''} ${e.message || ''} ${String(err).slice(0, 200)}`;
  return REDIS_ERROR_PATTERN.test(text);
}

@Catch()
export class DependencyUnavailableFilter implements ExceptionFilter {
  private readonly logger = new Logger('DependencyUnavailable');
  private lastLogAt = 0;

  /**
   * True when this filter — not the generic handler — should answer: a bounded
   * Redis rejection, or a 503 already carrying the LICENCE_UNVERIFIED code.
   */
  handles(exception: unknown): boolean {
    return (
      isRedisUnavailableError(exception) ||
      (exception instanceof HttpException &&
        exception.getStatus() === HttpStatus.SERVICE_UNAVAILABLE &&
        String((exception.getResponse() as { code?: string })?.code || '') === LICENCE_UNVERIFIED)
    );
  }

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    if (!res || typeof res.status !== 'function' || res.headersSent) {
      // Not an HTTP context at all (a queue job, a cron tick, a socket), or the
      // response has already been written: there is nothing this filter can
      // answer, so the caller's own error handling keeps it.
      throw exception;
    }

    const licenceUnverified =
      exception instanceof HttpException &&
      exception.getStatus() === HttpStatus.SERVICE_UNAVAILABLE &&
      String((exception.getResponse() as { code?: string })?.code || '') === LICENCE_UNVERIFIED;

    const redisDown = !licenceUnverified && isRedisUnavailableError(exception);

    if (licenceUnverified || redisDown) {
      const code = licenceUnverified ? LICENCE_UNVERIFIED : REDIS_UNAVAILABLE;
      const path = (ctx.getRequest<{ url?: string }>() || {}).url || '';
      this.throttledWarn(code, path, exception);
      res
        .status(HttpStatus.SERVICE_UNAVAILABLE)
        .setHeader('Retry-After', String(RETRY_AFTER_SECONDS))
        .setHeader('Cache-Control', 'no-store')
        .json({
          statusCode: HttpStatus.SERVICE_UNAVAILABLE,
          code,
          // Transient, retryable, and deliberately vague: no host, port, URL,
          // key or licence detail leaves the process.
          message: licenceUnverified
            ? 'Service temporarily unavailable: the licence could not be verified. Retry shortly.'
            : 'Service temporarily unavailable: a required dependency is not answering. Retry shortly.',
          retryAfterSeconds: RETRY_AFTER_SECONDS,
          path: path.split('?')[0],
          timestamp: new Date().toISOString(),
        });
      return;
    }

    // -------------------------------------------------------------------
    // PHASE Q4a — everything else is not this filter's business, but a filter
    // that has been handed the exception MUST answer it.
    //
    // This used to `throw exception`, on the theory that re-throwing hands the
    // error to the next handler. It does not: registering an APP_FILTER with a
    // bare `@Catch()` REPLACES Nest's own BaseExceptionFilter, so there is no
    // next handler — the throw escapes the route handler and Express's default
    // error handler answers instead. Measured live in a Nest `Test` app built
    // straight from AppModule (evidence: work/q4-evidence/flows-html-before.log):
    //
    //     status=400  ctype=text/html; charset=utf-8  len=309  <title>Error</title>
    //
    // A JSON-only API answering an HTML page, and the client losing the
    // machine-readable `code` the controller had put in the exception
    // (flexora-critical-flows asserts `body.code === 'WHATSAPP_NOT_CONFIGURED'`
    // and received `undefined`). In production `main.ts` registers
    // HttpExceptionFilter with `useGlobalFilters`, which runs ahead of any
    // APP_FILTER and answers first, so the defect only showed up in test apps —
    // exactly where a suite that builds AppModule itself lives, and exactly where
    // nobody can see it in a browser.
    //
    // The reply below is what Nest's BaseExceptionFilter itself produces: for an
    // HttpException it replies with `exception.getResponse()` at the exception's
    // status; for anything else it logs the error and replies a bare 500
    // "Internal server error". Deleting this filter would therefore not change
    // what a client sees — which is the point: this filter owns the dependency
    // 503s and nothing else.
    // -------------------------------------------------------------------
    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const payload = exception.getResponse();
      res.status(status).json(
        payload && typeof payload === 'object'
          ? (payload as object)
          : { statusCode: status, message: payload },
      );
      return;
    }
    // Unknown error: log it here (Nest's ExceptionsHandler logger no longer sees
    // it, because this filter is the registered handler) and answer the same bare
    // 500. The message is never echoed — an unknown error's text can carry a
    // query, a connection string fragment or a stored value.
    this.logger.error(exception instanceof Error ? exception : String(exception));
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: 'Internal server error',
    });
  }

  private throttledWarn(code: string, path: string, exception: unknown): void {
    const now = Date.now();
    if (now - this.lastLogAt < 5_000) return;
    this.lastLogAt = now;
    const reason = exception instanceof Error ? exception.message : String(exception);
    // the reason is truncated and never contains a credential by construction
    this.logger.warn(`${code} -> 503 + Retry-After ${RETRY_AFTER_SECONDS}s for ${path.split('?')[0]} (${reason.slice(0, 160)})`);
  }
}
