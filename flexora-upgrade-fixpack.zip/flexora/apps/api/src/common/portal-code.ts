/**
 * ROUND 14 (security review, PHASE E) — shared helpers for member-portal
 * login codes (WhatsApp OTPs and staff-generated one-time access codes).
 *
 * Both flows store the SAME MemberOtp row shape (HMAC of memberId:code with
 * OTP_HMAC_SECRET), so one verify path (POST /portal/verify-otp) accepts
 * either kind of code. The plaintext code exists only in the message that is
 * SENT to the member (WhatsApp) or SHOWN once on the staff screen — it is
 * never persisted (neither in Notification.body nor anywhere else).
 */
import { createHmac, randomBytes, randomInt } from 'crypto';
import { BadRequestException } from '@nestjs/common';

/** The body stored in the notification log for any code-bearing message. */
export const OTP_REDACTED_BODY = 'Login code sent';

/** Random per-process key used only when a test run has not set OTP_HMAC_SECRET. */
let cachedTestSecret: string | null = null;
function testOnlySecret(): string {
  if (!cachedTestSecret) cachedTestSecret = randomBytes(32).toString('hex');
  return cachedTestSecret;
}

/** 6-digit numeric code. */
export function generatePortalCode(): string {
  return String(randomInt(100000, 1000000));
}

/** HMAC-SHA256(memberId:code) — the only form a code is ever stored in. */
export function hashPortalCode(memberId: string, code: string): string {
  // PHASE M3.2: the previous fallback was the literal string
  // 'test-otp-hmac-secret'. It was only reachable under Jest, but a key that
  // sits in the source tree is one copy-paste away from being a real one. When
  // OTP_HMAC_SECRET is absent under test we now mint a random key for the life
  // of the process — codes still verify within a test run, and no key is ever
  // written down.
  const secret = process.env.OTP_HMAC_SECRET || (process.env.JEST_WORKER_ID ? testOnlySecret() : undefined);
  if (!secret) throw new BadRequestException('OTP_HMAC_SECRET is not configured');
  return createHmac('sha256', secret).update(`${memberId}:${code}`).digest('hex');
}

/** Constant-time comparison of two hex digests (different lengths fail). */
export function safeEqualHex(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
