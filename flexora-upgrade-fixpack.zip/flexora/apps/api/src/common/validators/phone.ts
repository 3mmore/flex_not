/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Single source of truth for Egyptian mobile validation.
 *
 * The same 11-digit rule (010/011/012/015 + 8 digits) was previously re-declared
 * in members/dto.ts, invitations/dto.ts and leads.service.ts, while staff
 * (users/dto.ts) used a loose generic pattern that accepted things like
 * "+1 (555) 123-4567". Staff phones now enforce the identical rule so a phone
 * number means the same thing everywhere in the system.
 */
export const EG_PHONE = /^(010|011|012|015)\d{8}$/;

export const EG_PHONE_MESSAGE = 'Invalid Egyptian mobile (11 digits, 010/011/012/015)';
