import { createParamDecorator, ExecutionContext } from '@nestjs/common';
export const GymId = createParamDecorator(
  (data: unknown, ctx: ExecutionContext) => ctx.switchToHttp().getRequest().user?.gymId,
);
