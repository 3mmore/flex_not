/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface AuthMember {
  sub: string;      // member id
  gymId: string;
  role: 'MEMBER';
  mobile: string;
  name: string;
  jti?: string;      // token id, for server-side revocation
}

export const CurrentMember = createParamDecorator(
  (data: keyof AuthMember | undefined, ctx: ExecutionContext): AuthMember | any => {
    const req = ctx.switchToHttp().getRequest();
    return data ? req.member?.[data] : req.member;
  },
);
