/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — the platform auth decorators.
 *
 * All three are METADATA, read with the Reflector. Nothing in R1 decides who may
 * do what by matching a URL string: R0 established that route identity comes from
 * controller metadata, and the guards below follow the same rule. Each one has a
 * companion test that enumerates every @PlatformRoute() handler and fails when a
 * handler that should carry the marker does not.
 */
import { SetMetadata } from '@nestjs/common';

/**
 * Marks a route as needing a fresh step-up assertion (R1.5): a TOTP code
 * verified within the last 5 minutes on THIS session. The value is the reason,
 * which is written to the audit row so an administrator action can be tied to
 * the assertion that authorised it.
 */
export const REQUIRE_STEP_UP_KEY = 'platformRequireStepUp';
export const RequireStepUp = (reason: string) => SetMetadata(REQUIRE_STEP_UP_KEY, reason);

/**
 * Marks a route as usable while TOTP enrolment is still pending (R1.1, review
 * item 3). Everything else under @PlatformRoute() is refused with 403
 * TOTP_ENROLMENT_REQUIRED until the admin has enrolled. The value is the reason,
 * so an exemption is always documented at the place it is granted.
 */
export const ALLOWED_BEFORE_TOTP_KEY = 'platformAllowedBeforeTotp';
export const AllowedBeforeTotp = (reason: string) => SetMetadata(ALLOWED_BEFORE_TOTP_KEY, reason);

/**
 * Exempts one platform route from the double-submit CSRF check (R1.6). The
 * reason is required: a test asserts that every exemption carries one, and that
 * the exemption list is exactly the set of routes that cannot present a token
 * (the login itself, and the CSP report a browser posts without credentials).
 */
export const PLATFORM_CSRF_EXEMPT_KEY = 'platformCsrfExempt';
export const PlatformCsrfExempt = (reason: string) => SetMetadata(PLATFORM_CSRF_EXEMPT_KEY, reason);
