import { SetMetadata } from '@nestjs/common';

/**
 * ROUND 13 (Phase 5) — fine-grained permission gate.
 *
 *   @Permissions('members.view')          — require that permission
 *   @Permissions('members.view', 'pos.sell') — require ALL listed (AND)
 *
 * Replaces the hard-coded @Roles lists on the tenant API surface. The
 * PermissionsGuard resolves the caller's EFFECTIVE permissions (role defaults
 * + owner-controlled per-user overrides) and rejects with 403 otherwise.
 * Endpoints without @Permissions stay open to any authenticated user (same
 * convention as @Roles before). Branch scoping is untouched — the TenantGuard
 * and the Prisma scope middleware keep applying exactly as before.
 */
export const PERMISSIONS_KEY = 'permissions';
export const Permissions = (...permissions: string[]) => SetMetadata(PERMISSIONS_KEY, permissions);
