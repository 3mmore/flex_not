import { SetMetadata } from '@nestjs/common';
export const BRUTE_FORCE_KEY = 'bruteForce';
export const BruteForce = (scope?: string) => SetMetadata(BRUTE_FORCE_KEY, scope || true);
