/**
 * ROUND 14 (security review, PHASE C) — tenant endpoint guard coverage.
 *
 * Invariant: every TENANT controller endpoint must carry explicit access
 * metadata — @Roles(...), @Permissions(...) or @Public() — so no tenant route
 * is ever left to "any authenticated user" by accident. A controller that
 * forgets the decorator on one handler silently widens access to a whole
 * role family; this spec fails the suite when that happens.
 *
 * Scope: controllers under src/modules EXCEPT the platform surface
 * (platform/, platform-auth/, admin/, monitoring/) — those are guarded by the
 * platform admin guard / SUPER_ADMIN role checks and are not tenant data
 * routes. (admin/ and platform-auth/ still pass the check on their own
 * merits — the exclusion only documents that they are not tenant surface.)
 *
 * Method: the file is split into METHOD REGIONS at each method signature; a
 * region runs from the previous signature to this one, so it contains exactly
 * this method's decorators (whether they are written above or below the route
 * decorator) plus the previous method's body tail. A region counts as an
 * endpoint when it contains a route decorator (@Get/@Post/@Patch/@Put/
 * @Delete/@All). Class-level @Roles/@Permissions/@Public (above the first
 * method) covers every endpoint in the controller.
 */
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

const MODULES_ROOT = join(__dirname, '../../modules');

/** Platform surface — not tenant data routes (platform admin guard / SUPER_ADMIN). */
const PLATFORM_MODULES = new Set(['platform', 'platform-auth', 'admin', 'monitoring']);

/** Strip comments so decorator-like text inside them cannot fake a match. */
function stripComments(src: string): string {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:"'`])\/\/[^\n]*/g, '$1');
}

const ROUTE_DECORATOR = /@(Get|Post|Patch|Put|Delete|All)\s*\(/;
const GUARD_DECORATOR = /@(Roles|Permissions|Public)\s*\(/;
/** A method signature: a line starting with an optional async + identifier + ( */
const SIGNATURE = /(?:^|\n)\s*(?:async\s+)?(?!if\b|for\b|while\b|switch\b|catch\b|return\b|else\b|new\b|typeof\b)(\w+)\s*\(/g;

interface Endpoint {
  controller: string;
  method: string;
  route: string;
}

function collectControllers(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) {
      if (PLATFORM_MODULES.has(entry)) continue;
      collectControllers(p, out);
    } else if (entry.endsWith('.controller.ts')) {
      out.push(p);
    }
  }
  return out;
}

/** Every tenant endpoint that has neither @Roles nor @Permissions nor @Public. */
function findUnguardedEndpoints(): Endpoint[] {
  const violations: Endpoint[] = [];
  for (const file of collectControllers(MODULES_ROOT)) {
    const src = stripComments(readFileSync(file, 'utf8'));
    const rel = file.slice(MODULES_ROOT.length + 1);

    // method signature positions inside the file
    const sigs: { index: number; name: string }[] = [];
    for (const m of src.matchAll(SIGNATURE)) sigs.push({ index: m.index, name: m[1] });
    if (!sigs.length) continue;

    // class-level guard decorators (anywhere above the first method
    // signature — Nest reads them via getAllAndOverride([handler, class]))
    // cover every endpoint in the controller
    const firstSig = sigs[0].index;
    const classHeader = src.slice(0, firstSig);
    const classGuarded = GUARD_DECORATOR.test(classHeader);

    for (let i = 0; i < sigs.length; i++) {
      const regionStart = i === 0 ? 0 : sigs[i - 1].index;
      const region = src.slice(regionStart, sigs[i].index);
      const routeMatch = region.match(ROUTE_DECORATOR);
      if (!routeMatch) continue; // not an endpoint (constructor, helper, field…)
      if (classGuarded) continue;
      if (GUARD_DECORATOR.test(region)) continue;
      violations.push({
        controller: rel,
        method: sigs[i].name,
        route: routeMatch[1],
      });
    }
  }
  return violations;
}

describe('tenant endpoint guard coverage', () => {
  it('every tenant controller endpoint has @Roles, @Permissions or @Public', () => {
    const violations = findUnguardedEndpoints();
    if (violations.length) {
      const list = violations
        .map((v) => `  - ${v.controller} :: ${v.route} ${v.method}()`)
        .join('\n');
      throw new Error(
        `Tenant endpoints without @Roles/@Permissions/@Public (add the decorator — or @Public() if the route is genuinely public):\n${list}`,
      );
    }
  });

  it('scans a meaningful number of tenant controllers (the walk is not vacuous)', () => {
    const files = collectControllers(MODULES_ROOT);
    expect(files.length).toBeGreaterThan(30);
  });

  it('the permission catalog itself is fully gated (permissions/me reads only the caller)', () => {
    const src = readFileSync(join(MODULES_ROOT, 'permissions/permissions.controller.ts'), 'utf8');
    expect(src).toContain("@Get('me') @Permissions('profile.self')");
  });
});
