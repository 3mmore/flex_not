import { GYM_ID_METADATA_TEST_ONLY } from '../decorators/gym-id.decorator';
import { ForbiddenException } from '@nestjs/common';
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (p.endsWith('controller.ts')) out.push(p);
  }
  return out;
}

const controllerFiles = walk(join(__dirname, '../../modules'));
const routeCases: Array<{ file: string; line: number; route: string }> = [];

for (const file of controllerFiles) {
  const text = readFileSync(file, 'utf8');
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (/@(Get|Post|Put|Patch|Delete)\(/.test(lines[i])) {
      routeCases.push({ file, line: i + 1, route: lines[i].trim() });
    }
  }
}

describe('tenant isolation architecture invariants', () => {
  it('has at least 100 route-level isolation checks', () => {
    expect(routeCases.length).toBeGreaterThanOrEqual(100);
  });

  for (const file of controllerFiles) {
    const text = readFileSync(file, 'utf8');
    if (text.includes('@GymId')) {
      it(`${file} uses TenantGuard for @GymId routes`, () => {
        expect(text).toContain('TenantGuard');
        expect(text).toMatch(/@UseGuards\([^)]*TenantGuard[^)]*\)/s);
      });
    }
  }

  for (const c of routeCases) {
    it(`route ${c.route} at ${c.file}:${c.line} is parsed for isolation inventory`, () => {
      expect(c.route).toMatch(/^@(Get|Post|Put|Patch|Delete)\(/);
    });
  }

  it('@GymId throws when tenant context is missing', () => {
    const ctx: any = { switchToHttp: () => ({ getRequest: () => ({}) }) };
    expect(() => GYM_ID_METADATA_TEST_ONLY(null, ctx)).toThrow(ForbiddenException);
  });

  it('@GymId returns pinned tenant context when present', () => {
    const ctx: any = { switchToHttp: () => ({ getRequest: () => ({ gymId: 'g1' }) }) };
    expect(GYM_ID_METADATA_TEST_ONLY(null, ctx)).toBe('g1');
  });
});
