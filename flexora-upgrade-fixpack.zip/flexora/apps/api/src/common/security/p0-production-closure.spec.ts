import { readFileSync } from 'fs';

const read = (p: string) => readFileSync(p, 'utf8');

describe('P0 production closure source invariants', () => {
  it('exposes refund and void sale endpoints', () => {
    const src = read('src/modules/sales/sales.controller.ts');
    expect(src).toContain("@Post(':id/refund')");
    expect(src).toContain("@Post(':id/void')");
    // ROUND 14 (security review, PHASE B): refund/void are gated by the
    // dedicated sales.refund permission (re-pinned from the old coarse
    // @Roles list — the invariant is now STRONGER: the endpoints exist, are
    // permission-gated, and the default role set is exactly OWNER+MANAGER).
    expect(src).toContain("@Post(':id/refund') @Permissions('sales.refund')");
    expect(src).toContain("@Post(':id/void') @Permissions('sales.refund')");
    const catalog = read('src/modules/permissions/permissions.catalog.ts');
    // OWNER gets [...PERMISSIONS] — so sales.refund must be IN the catalog list
    expect(catalog).toContain("'sales.refund'");
    // MANAGER is PERMISSIONS.filter(...) — sales.refund must NOT be excluded
    const managerFilter = catalog.slice(catalog.indexOf('MANAGER: PERMISSIONS.filter'), catalog.indexOf('RECEPTION: ['));
    expect(managerFilter).not.toContain("p !== 'sales.refund'");
    // … and the front-desk roles' literal default lists must not grant it
    for (const role of ['RECEPTION: [', 'COACH: [', 'ACCOUNTANT: [']) {
      const start = catalog.indexOf(role);
      const end = catalog.indexOf('],', start);
      expect(catalog.slice(start, end)).not.toContain('sales.refund');
    }
  });

  it('persists refund, invoice, payment and receipt models', () => {
    const schema = read('prisma/schema.prisma');
    for (const model of ['model Refund', 'model RefundItem', 'model RefundAudit', 'model Invoice', 'model InvoiceLine', 'model Payment', 'model Receipt']) {
      expect(schema).toContain(model);
    }
  });

  it('campaign delivery uses recipients and does not complete without recipients', () => {
    const service = read('src/modules/campaigns/campaigns.service.ts');
    const queue = read('src/modules/queue/queue.module.ts');
    expect(service).toContain('campaignRecipient.createMany');
    expect(queue).toContain('Campaign has no recipients');
    expect(queue).toContain('campaignRecipient.updateMany');
  });

  it('purchase orders persist items and receiving validates quantities', () => {
    const schema = read('prisma/schema.prisma');
    const service = read('src/modules/inventory/inventory.service.ts');
    expect(schema).toContain('model PurchaseOrderItem');
    expect(schema).toContain('model GoodsReceiptItem');
    expect(service).toContain('qtyReceived + item.qty > ordered.qtyOrdered');
    expect(service).toContain('goodsReceiptItem.create');
  });

  it('billing failed-payment recovery creates attempts and tasks', () => {
    const src = read('src/modules/billing/billing.service.ts');
    expect(src).toContain('paymentAttempt.create');
    expect(src).toContain('billingRecoveryTask.create');
    expect(src).not.toContain("tenantId: sub.metadata?.gymId || 'unknown'");
  });

  it('payroll readiness models and endpoints exist', () => {
    const schema = read('prisma/schema.prisma');
    const controller = read('src/modules/staff-attendance/staff-attendance.controller.ts');
    for (const model of ['model StaffPayProfile', 'model Timesheet', 'model TimesheetEntry']) expect(schema).toContain(model);
    expect(controller).toContain("@Post('pay-profile')");
    expect(controller).toContain("@Get('payroll/export')");
  });
});
