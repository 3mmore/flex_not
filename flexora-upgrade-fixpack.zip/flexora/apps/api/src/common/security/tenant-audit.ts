/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Static tenant-isolation audit (Phase 2A).
 *
 * Walks every Prisma call in `src/modules/**` and verifies that
 * any query touching a gym-scoped model includes a `gymId` predicate
 * in the `where` clause. Cross-tenant data leaks are flagged as
 * `HIGH` severity.
 *
 * Heuristics:
 *   1. Every `prisma.<model>.findMany/findFirst/findUnique/count/update/delete`
 *      call must mention `gymId` somewhere in its argument list.
 *   2. `createMany`, `create`, `upsert` must pass `data: { ... gymId: ... }`.
 *   3. Aggregate queries are excluded (they typically join gym-scoped
 *      tables via groupBy on gymId).
 *   4. SUPER_ADMIN routes that legitimately cross tenants are exempt.
 *
 * The audit runs at boot in development mode and exits non-zero on
 * violations so the developer sees them immediately.
 *
 * Usage: `npx ts-node src/common/security/tenant-audit.ts <root>`
 */
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

const TENANT_MODELS = new Set([
  'user', 'branch', 'member', 'plan', 'attendance',
  'product', 'sale', 'saleItem', 'expense', 'transaction',
  'auditLog', 'notification', 'backup',
  'classTemplate', 'classSession', 'classBooking',
  'coachProfile', 'ptSession', 'bodyMeasurement',
  'invitationSlot', 'invitation',
  'memberOtp',
  'lead', 'leadFollowUp', 'memberContract', 'campaign',
  'staffAttendance', 'reportCache',
]);

// Methods that MUST be scoped
const SCOPED_METHODS = [
  'findMany', 'findFirst', 'findFirstOrThrow', 'findUnique',
  'findUniqueOrThrow', 'count', 'aggregate', 'groupBy',
  'update', 'updateMany', 'delete', 'deleteMany',
];

export interface AuditFinding {
  file: string;
  line: number;
  model: string;
  method: string;
  reason: string;
}

export function auditTenantIsolation(rootDir: string): AuditFinding[] {
  const findings: AuditFinding[] = [];
  walk(rootDir, (file) => {
    if (!file.endsWith('.ts')) return;
    if (file.endsWith('.spec.ts')) return;
    if (file.endsWith('.d.ts')) return;
    // Audit / reportCache legitimately cross tenants - skip them.
    // PHASE R1: the '/modules/admin/' exclusion is gone with the module it exempted.
    // Leaving it would silently exempt any future directory of that name from the
    // tenant-isolation audit. The console's cross-tenant reads are handled by the
    // SECURITY DEFINER platform_* functions (migration 20261106000000) instead.
    if (file.includes('/modules/audit/')) return;
    if (file.includes('report-cache.service.ts')) return;
    const src = readFileSync(file, 'utf8');
    src.split('\n').forEach((line, idx) => {
      // Match patterns like: prisma.member.findMany
      //        prisma.attendance.findFirst({ where: { ... } })
      const m = line.match(/this\.prisma\.([a-zA-Z]+)\.(find|update|delete|count|aggregate|groupBy)\w*\s*\(/);
      if (!m) return;
      const [, model, methodBase] = m;
      if (!TENANT_MODELS.has(model)) return;
      const method = methodBase;
      if (!SCOPED_METHODS.includes(methodBase)) return;
      // Look forward ~30 lines for the closing ')' to inspect the args
      const slice = src.split('\n').slice(idx, idx + 40).join('\n');
      // Skip if the call is scoped by id (TenantGuard + JWT guarantee
      // ownership) or explicitly by gymId.
      const scopedById = /where\s*:\s*\{\s*id\s*:/.test(slice);
      if (scopedById) return;
      if (!slice.includes('gymId')) {
        findings.push({
          file: file.replace(rootDir + '/', ''),
          line: idx + 1,
          model,
          method,
          reason: 'Prisma call does not reference gymId (and is not a single-id lookup)',
        });
      }
    });
  });
  return findings;
}

function walk(dir: string, onFile: (full: string) => void) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const s = statSync(full);
    if (s.isDirectory()) walk(full, onFile);
    else if (s.isFile()) onFile(full);
  }
}

if (require.main === module) {
  const root = process.argv[2] || join(__dirname, '../../../src/modules');
  const findings = auditTenantIsolation(root);
  if (findings.length === 0) {
    // eslint-disable-next-line no-console
    process.stdout.write(String(`✅ Tenant audit passed: no unscoped Prisma calls found under ${root}`) + '\n');
    process.exit(0);
  }
  // eslint-disable-next-line no-console
  console.error(`❌ Tenant audit found ${findings.length} potentially unscoped call(s):`);
  for (const f of findings) {
    // eslint-disable-next-line no-console
    console.error(`  - ${f.file}:${f.line}  prisma.${f.model}.${f.method}()  — ${f.reason}`);
  }
  process.exit(1);
}
