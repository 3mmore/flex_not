/**
 * FLEXORA Gym OS — Logout cache-purge contract test
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Verifies the CLEAR_CACHE purge semantics used by:
 *   - apps/web/public/sw.js          (message handler)
 *   - apps/web/src/lib/pwa.ts        (clearMemberCaches fallback)
 *
 * Both must delete EVERY Cache Storage entry on logout so a different member
 * signing in on the same device cannot read the previous account's cached
 * pages (account-switching leak prevention).
 *
 * The SW runs outside the bundler, so we test the exact purge algorithm
 * (caches.keys() -> delete all) against a faithful mock of the Cache API.
 */

/** Mirror of the purge loop in sw.js CLEAR_CACHE + pwa.ts fallback. */
async function purgeAllCaches(cacheStorage: {
  keys(): Promise<string[]>;
  delete(name: string): Promise<boolean>;
}): Promise<number> {
  const keys = await cacheStorage.keys();
  await Promise.all(keys.map((k) => cacheStorage.delete(k)));
  return keys.length;
}

function makeCacheStorage(initial: string[]) {
  const store = new Set(initial);
  return {
    store,
    keys: jest.fn(async () => Array.from(store)),
    delete: jest.fn(async (name: string) => store.delete(name)),
  };
}

describe('Logout cache purge (CLEAR_CACHE)', () => {
  it('deletes every cache, including old versioned + cross-account caches', async () => {
    const cs = makeCacheStorage([
      'flexora-portal-v1',
      'flexora-portal-v2',
      'member-m1-pages',
      'member-m2-pages',
    ]);
    const cleared = await purgeAllCaches(cs);
    expect(cleared).toBe(4);
    expect(cs.delete).toHaveBeenCalledTimes(4);
    expect(cs.store.size).toBe(0);
  });

  it('is a no-op safe when there are no caches (never throws)', async () => {
    const cs = makeCacheStorage([]);
    const cleared = await purgeAllCaches(cs);
    expect(cleared).toBe(0);
    expect(cs.store.size).toBe(0);
  });

  it('leaves no member-scoped cache behind after purge', async () => {
    const cs = makeCacheStorage(['member-previous-account', 'static-v9']);
    await purgeAllCaches(cs);
    const remaining = await cs.keys();
    expect(remaining).toHaveLength(0);
  });
});
