/**
 * PHASE M3.3 — tests for the rotation procedure itself.
 *
 * These are not tests of the cipher; they are tests that the rotation does what
 * the runbook claims: old rows stay readable during a standard rotation, a
 * missing old key aborts instead of corrupting rows, and the search-key path
 * (which has no versioning) really does re-encrypt every deterministic value.
 */
import { EncryptionService } from './encryption.service';
import {
  ENCRYPTED_FIELDS,
  planField,
  readKid,
  rotateValue,
  RotationRow,
  RotationTarget,
} from './encryption-rotation';

const KEY_V1 = '5a3c8ca45ae62ad5153cfe4500fe4045666a6973a6bdceb5f8a66acdc6b5175a';
const KEY_V2 = '59e037eb63a85137d3775df26fe4d6d79edfd9a6f57a68fdd8eb4195815be7ec';
const KEY_V3 = '632711e31a03476082362d8db5f516072e4c42b50d254abe2b2f5a6aacb88e37';
const SEARCH_OLD = 'cef2db84495c5723d33a9c4949ba05f93d074b4b5e78bfb7dfa79308983d83cd';
const SEARCH_NEW = 'ce22a83d6ad79bc9a89838f5cec76ca4dfe931f5c2a111fbe0a01d44a309a0e8';

function service(opts: {
  versions?: Record<string, string>;
  currentKid?: string;
  legacy?: string;
  searchKey?: string;
}): EncryptionService {
  // Start from a clean slate: a key left over from a previous build would make
  // a "the old key has been retired" scenario silently succeed, which is
  // exactly the situation this module exists to catch.
  for (const k of Object.keys(process.env)) {
    if (/^ENCRYPTION_KEY(_V[0-9]+)?$/.test(k)) delete process.env[k];
  }
  delete process.env.ENCRYPTION_CURRENT_KID;
  delete process.env.ENCRYPTION_SEARCH_KEY;

  const svc = new EncryptionService();
  for (const [k, v] of Object.entries(opts.versions || {})) process.env[k] = v;
  if (opts.legacy) process.env.ENCRYPTION_KEY = opts.legacy;
  if (opts.currentKid) process.env.ENCRYPTION_CURRENT_KID = opts.currentKid;
  process.env.ENCRYPTION_SEARCH_KEY = opts.searchKey || SEARCH_OLD;
  svc.onModuleInit();
  return svc;
}

const savedEnv = { ...process.env };
afterEach(() => {
  for (const k of Object.keys(process.env)) {
    if (!(k in savedEnv)) delete process.env[k];
  }
  Object.assign(process.env, savedEnv);
  for (const k of [
    'ENCRYPTION_KEY',
    'ENCRYPTION_KEY_V1',
    'ENCRYPTION_KEY_V2',
    'ENCRYPTION_KEY_V3',
    'ENCRYPTION_CURRENT_KID',
    'ENCRYPTION_SEARCH_KEY',
  ]) {
    if (!(k in savedEnv)) delete process.env[k];
  }
});

describe('PHASE M3.3 — encryption rotation', () => {
  it('loads several key versions at once and stamps the current kid', () => {
    const svc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1, ENCRYPTION_KEY_V2: KEY_V2 }, currentKid: 'v2' });
    const payload = JSON.parse(svc.encrypt('hello'));
    expect(payload.kid).toBe('v2');
    expect(svc.decrypt(svc.encrypt('hello'))).toBe('hello');
  });

  it('rotates a v1 row onto v2 and keeps the plaintext', () => {
    const before = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1' });
    const after = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1, ENCRYPTION_KEY_V2: KEY_V2 }, currentKid: 'v2' });

    const oldCiphertext = before.encrypt('+201012345678');
    expect(readKid(oldCiphertext)).toBe('v1');

    // the OLD key is still loaded, so old rows stay readable during the rotation
    expect(after.decrypt(oldCiphertext)).toBe('+201012345678');

    const rotated = rotateValue(oldCiphertext, after, after, 'v2');
    expect(rotated).not.toBeNull();
    expect(readKid(rotated as string)).toBe('v2');
    expect(after.decrypt(rotated as string)).toBe('+201012345678');
  });

  it('leaves a row that is already on the current key alone', () => {
    const svc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1, ENCRYPTION_KEY_V2: KEY_V2 }, currentKid: 'v2' });
    const current = svc.encrypt('secret-value');
    expect(rotateValue(current, svc, svc, 'v2')).toBeNull();
  });

  it('leaves plaintext and empty values alone', () => {
    const svc = service({ versions: { ENCRYPTION_KEY_V2: KEY_V2 }, currentKid: 'v2' });
    expect(rotateValue('not-encrypted', svc, svc, 'v2')).toBeNull();
    expect(rotateValue(null, svc, svc, 'v2')).toBeNull();
    expect(rotateValue(undefined, svc, svc, 'v2')).toBeNull();
    expect(rotateValue('', svc, svc, 'v2')).toBeNull();
  });

  it('REFUSES to rewrite a row whose key is gone — it throws instead', () => {
    const before = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1' });
    const oldCiphertext = before.encrypt('+201012345678');

    // Operator "retired" v1 too early: only v3 is configured now.
    const afterRetiringV1 = service({ versions: { ENCRYPTION_KEY_V3: KEY_V3 }, currentKid: 'v3' });
    expect(() => rotateValue(oldCiphertext, afterRetiringV1, afterRetiringV1, 'v3')).toThrow();
  });

  // ------------------------------------------------------------------ search
  it('re-encrypts deterministic values when the search key changes (kid cannot tell you)', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const newSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_NEW });

    const ciphertext = oldSvc.encryptDeterministic('+201012345678');
    expect(readKid(ciphertext)).toBe('search-v1');

    // deterministic kid never changes — without `always` the row looks current
    expect(rotateValue(ciphertext, oldSvc, newSvc, 'search-v1')).toBeNull();
    // ...so the deterministic path must force the rewrite
    const rotated = rotateValue(ciphertext, oldSvc, newSvc, 'search-v1', true); // deterministic
    expect(rotated).not.toBeNull();
    expect(rotated).not.toBe(ciphertext);
    expect(readKid(rotated as string)).toBe('search-v1');
    // the new key can read it, and it still encrypts to the same ciphertext
    // (determinism is what makes these fields searchable)
    expect(newSvc.encryptDeterministic('+201012345678')).toBe(rotated);
  });

  it('deterministic rotation preserves equality lookups', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const newSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_NEW });
    for (const mobile of ['+201012345678', '+201012345679']) {
      const rotated = rotateValue(oldSvc.encryptDeterministic(mobile), oldSvc, newSvc, 'search-v1', true);
      expect(newSvc.encryptDeterministic(mobile)).toBe(rotated);
    }
  });

  // ---------------------------------------------------------------- planning
  const target: RotationTarget = { model: 'member', field: 'mobile', kind: 'deterministic' };

  it('plans a column: counts plaintext, current and rotated rows', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const newSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_NEW });

    const rows: RotationRow[] = [
      { id: '1', value: oldSvc.encryptDeterministic('+201010000001') },
      { id: '2', value: '+201010000002' }, // plaintext legacy row
      { id: '3', value: null },
      { id: '4', value: oldSvc.encryptDeterministic('+201010000004') },
    ];
    const { stats, writes } = planField(target, rows, oldSvc, newSvc, 'search-v1');
    expect(stats).toMatchObject({ scanned: 4, rotated: 2, plaintext: 2, failed: 0 });
    expect(writes.map((w) => w.id)).toEqual(['1', '4']);
    // every rewritten row still decrypts to the original value
    expect(newSvc.decrypt(writes[0].value as string)).toBe('+201010000001');
  });

  it('reports a failure instead of dropping the row when the old key is missing', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const wrongReader = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_NEW });
    const rows = [{ id: '1', value: oldSvc.encryptDeterministic('+201010000001') }];
    const { stats, writes } = planField(target, rows, wrongReader, wrongReader, 'search-v1');
    expect(stats.failed).toBe(1);
    expect(writes).toHaveLength(0); // nothing to write -> the CLI aborts
  });


  it('is IDEMPOTENT: a row the new key already reads is left alone, not failed', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const newSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_NEW });

    // already rotated by an earlier run: encrypted under the NEW key
    const alreadyRotated = newSvc.encryptDeterministic('+201010000001');
    const rows: RotationRow[] = [
      { id: '1', value: alreadyRotated },
      { id: '2', value: oldSvc.encryptDeterministic('+201010000002') }, // still on the old key
    ];
    const { stats, writes } = planField(target, rows, oldSvc, newSvc, 'search-v1');
    expect(stats.failed).toBe(0); // the already-rotated row is NOT a failure
    expect(stats.alreadyCurrent).toBe(1);
    expect(stats.rotated).toBe(1);
    expect(writes.map((w) => w.id)).toEqual(['2']);
    // re-encrypting row 2 with the new key must be a no-op afterwards
    const second = planField(target, [{ id: '2', value: writes[0].value }], oldSvc, newSvc, 'search-v1');
    expect(second.stats.rotated).toBe(0);
    expect(second.stats.alreadyCurrent).toBe(1);
  });

  it('still aborts when NEITHER key can read a row', () => {
    const oldSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: SEARCH_OLD });
    const thirdSvc = service({ versions: { ENCRYPTION_KEY_V1: KEY_V1 }, currentKid: 'v1', searchKey: KEY_V3 });
    const rows = [{ id: '1', value: oldSvc.encryptDeterministic('+201010000001') }];
    const { stats, writes } = planField(target, rows, thirdSvc, thirdSvc, 'search-v1');
    expect(stats.failed).toBe(1);
    expect(writes).toHaveLength(0);
    expect(stats.firstError).toBeTruthy(); // the operator is told why
    expect(stats.firstError).not.toContain('+201010000001'); // but never shown the value
  });

  it('the inventory covers the columns the services actually encrypt', () => {
    const covered = ENCRYPTED_FIELDS.map((f) => `${f.model}.${f.field}`);
    // call sites verified against the schema in PHASE M3.3
    for (const column of [
      'user.twoFaSecret',
      'user.twoFaBackupCodes',
      'gym.waBotToken',
      'gymMessagingConfig.whatsappToken',
      'gymMessagingConfig.smsApiKey',
      'gymMessagingConfig.smsApiSecret',
      'gymMessagingConfig.smtpPass',
      'gymSettings.value',
      'ownerNotification.metadata',
      'member.mobile',
      'member.nationalId',
      'lead.mobile',
    ]) {
      expect(covered).toContain(column);
    }
    // deterministic fields must be flagged as such, or the kid check will skip them
    for (const f of ENCRYPTED_FIELDS.filter((f) =>
      ['member.mobile', 'member.nationalId', 'lead.mobile'].includes(`${f.model}.${f.field}`),
    )) {
      expect(f.kind).toBe('deterministic');
    }
  });
});
