/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * SECURITY (Item 8 fix): shared, real CIDR-matching IP allow-list utility.
 *
 * There were previously TWO independent, both-broken implementations of
 * "is this IP in an allowed private range" guarding the /metrics endpoint:
 *   1. modules/monitoring/metrics.guard.ts (a NestJS CanActivate guard,
 *      applied to the @Controller('metrics') route, which — due to
 *      app.setGlobalPrefix('api') — actually serves /api/metrics)
 *   2. main.ts's inline httpAdapter.use('/metrics', ...) middleware, which
 *      serves the real, unprefixed /metrics route Prometheus scrapes in
 *      production (mounted before setGlobalPrefix('api') runs)
 * Both used plain string prefix matching instead of real CIDR arithmetic
 * (main.ts's version was arguably worse: `ip?.startsWith('10.')` would also
 * match "100.0.0.1", "10999.x", etc. — not even bounded to octet
 * boundaries). This module is the single, real implementation both call
 * into now, built on `ipaddr.js` for correct IPv4/IPv6 CIDR math.
 */
import ipaddr from 'ipaddr.js';

/** Default private-network CIDR ranges considered "internal" for metrics access. */
export const DEFAULT_METRICS_ALLOWED_CIDRS = ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'];

export class IpAllowlist {
  private readonly cidrs: Array<[ipaddr.IPv4 | ipaddr.IPv6, number]> = [];
  private readonly exactAddrs: Array<ipaddr.IPv4 | ipaddr.IPv6> = [];

  /**
   * Accepts a mix of plain IPs (e.g. "127.0.0.1", "::1") and CIDR ranges
   * (e.g. "10.0.0.0/8") — exactly the format documented for
   * METRICS_ALLOWED_IPS in .env.example (Item 5). Malformed entries are
   * skipped rather than throwing, so one bad value in an operator-supplied
   * env var can't crash the process at boot.
   */
  constructor(entries: string[] = DEFAULT_METRICS_ALLOWED_CIDRS) {
    for (const raw of entries) {
      const entry = raw.trim();
      if (!entry) continue;
      try {
        if (entry.includes('/')) {
          this.cidrs.push(ipaddr.parseCIDR(entry));
        } else {
          this.exactAddrs.push(ipaddr.process(entry));
        }
      } catch {
        // Skip malformed entries — deny-by-default is preserved because an
        // unparseable entry simply never matches anything.
      }
    }
  }

  /**
   * Returns true if `rawIp` is real IPv4/IPv6 loopback (regardless of
   * whether an explicit loopback entry was configured — this is always
   * safe to allow for a locally-scraped metrics endpoint), matches one of
   * the configured exact addresses, or falls inside one of the configured
   * CIDR ranges — using real CIDR arithmetic rather than string prefix
   * matching, and correctly normalizing IPv4-mapped IPv6 addresses (e.g.
   * "::ffff:127.0.0.1", which Node/Express commonly report for IPv4
   * clients on a dual-stack listener) before comparing.
   */
  isAllowed(rawIp: string | undefined | null): boolean {
    if (!rawIp) return false;

    let addr: ipaddr.IPv4 | ipaddr.IPv6;
    try {
      addr = ipaddr.process(rawIp);
    } catch {
      return false; // Not a parseable IP at all — deny by default.
    }

    if (addr.range() === 'loopback') return true;

    if (this.exactAddrs.some((a) => a.kind() === addr.kind() && a.toString() === addr.toString())) {
      return true;
    }

    if (addr.kind() !== 'ipv4') return false;

    return this.cidrs.some((cidr) => {
      if (cidr[0].kind() !== 'ipv4') return false;
      return (addr as ipaddr.IPv4).match(cidr as [ipaddr.IPv4, number]);
    });
  }
}

