/**
 * FLEXORA Gym OS — brute-force service tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BruteForceService } from './brute-force.service';
import { RedisService } from '../../config/redis.service';
import { Redis } from 'ioredis';

class FakeRedis {
  store = new Map<string, { value: string; expires: number }>();
  now() { return Date.now(); }
  async get(key: string) {
    const e = this.store.get(key);
    if (!e) return null;
    if (e.expires && e.expires < this.now()) {
      this.store.delete(key);
      return null;
    }
    return e.value;
  }
  async set(key: string, value: string, ttl?: number) {
    this.store.set(key, { value, expires: ttl ? this.now() + ttl * 1000 : 0 });
    return 'OK';
  }
  async del(key: string) {
    return this.store.delete(key) ? 1 : 0;
  }
  get client() {
    const self = this;
    return {
      async incr(key: string) {
        const cur = parseInt((await self.get(key)) || '0', 10) + 1;
        await self.set(key, String(cur));
        return cur;
      },
      async expire(key: string, sec: number) {
        const e = self.store.get(key);
        if (e) {
          e.expires = self.now() + sec * 1000;
          return 1;
        }
        return 0;
      },
    };
  }
}

describe('BruteForceService', () => {
  let svc: BruteForceService;
  let redis: FakeRedis;

  beforeEach(() => {
    redis = new FakeRedis();
    // BruteForceService expects RedisService with { client, get, set, del }
    svc = new BruteForceService(redis as any as RedisService);
  });

  it('allows by default and returns 0 failures', async () => {
    const r = await svc.check('login', '1.1.1.1|a@b.com');
    expect(r.allowed).toBe(true);
    expect(r.failures).toBe(0);
  });

  it('locks at 3 failures for 30s', async () => {
    await svc.registerFailure('login', 'k');
    await svc.registerFailure('login', 'k');
    const r = await svc.registerFailure('login', 'k');
    expect(r.allowed).toBe(false);
    expect(r.retryAfterSeconds).toBe(30);
  });

  it('locks at 5 failures for 15m', async () => {
    for (let i = 0; i < 4; i++) await svc.registerFailure('login', 'k');
    const r = await svc.registerFailure('login', 'k');
    expect(r.allowed).toBe(false);
    expect(r.retryAfterSeconds).toBe(900);
  });

  it('locks at 10 failures for 24h', async () => {
    for (let i = 0; i < 9; i++) await svc.registerFailure('login', 'k');
    const r = await svc.registerFailure('login', 'k');
    expect(r.allowed).toBe(false);
    expect(r.retryAfterSeconds).toBe(86400);
  });

  it('reset() clears counters and lockout', async () => {
    for (let i = 0; i < 3; i++) await svc.registerFailure('login', 'k');
    await svc.reset('login', 'k');
    const r = await svc.check('login', 'k');
    expect(r.allowed).toBe(true);
    expect(r.failures).toBe(0);
  });

  it('returns retryAfterSeconds when still locked', async () => {
    for (let i = 0; i < 3; i++) await svc.registerFailure('login', 'k');
    const r = await svc.check('login', 'k');
    expect(r.allowed).toBe(false);
    expect(r.retryAfterSeconds).toBeGreaterThan(0);
  });
});
