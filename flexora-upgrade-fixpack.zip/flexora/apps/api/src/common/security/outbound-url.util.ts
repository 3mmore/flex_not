import { BadRequestException } from '@nestjs/common';

const DEFAULT_WHATSAPP_HOSTS = ['graph.facebook.com'];

/**
 * Restrict tenant-configurable WhatsApp endpoints to operator-approved HTTPS
 * hosts. A generic IsUrl check still permits loopback, RFC1918, metadata, and
 * DNS-rebinding targets and therefore is not an SSRF boundary.
 */
export function assertAllowedWhatsAppBaseUrl(value: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new BadRequestException('Invalid WhatsApp API URL');
  }

  const allowedHosts = new Set(
    (process.env.WHATSAPP_ALLOWED_HOSTS || DEFAULT_WHATSAPP_HOSTS.join(','))
      .split(',')
      .map((host) => host.trim().toLowerCase())
      .filter(Boolean),
  );
  const host = url.hostname.toLowerCase();
  if (
    url.protocol !== 'https:' ||
    url.username ||
    url.password ||
    !allowedHosts.has(host) ||
    url.port
  ) {
    throw new BadRequestException('WhatsApp API host is not allowed');
  }

  url.search = '';
  url.hash = '';
  return url.toString().replace(/\/$/, '');
}
