/**
 * FLEXORA Gym OS — Security Module (Phase 3)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Global, Module } from '@nestjs/common';
import { SecurityMonitorService } from './security-monitor.service';
import { EncryptionService } from './encryption.service';
import { BruteForceService } from './brute-force.service';
import { RedisRateLimitGuard } from '../guards/redis-rate-limit.guard';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';

@Global()
@Module({
  imports: [PrismaModule, RedisModule],
  providers: [SecurityMonitorService, EncryptionService, BruteForceService, RedisRateLimitGuard],
  exports: [SecurityMonitorService, EncryptionService, BruteForceService, RedisRateLimitGuard],
})
export class SecurityModule {}
