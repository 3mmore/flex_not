/**
 * One place that knows how to invalidate the member-list caches.
 *
 * WHY THIS EXISTS
 * `MembersService.list()` caches the member list in Redis for 60 s, keyed per
 * `page/limit/q/status/branchId`
 * (`members:list:${gymId}:${page}:${limit}:${q}:${status}:${branchId}`), and the
 * analytics dashboard is cached under `reports:dashboard:${gymId}`.
 *
 * Every read of "the members" in the product goes through that cache — the
 * members table, the manual check-in dropdown on /attendance (which loads
 * `/members?limit=1000`), the POS member search, contracts, classes, …
 *
 * So EVERY code path that creates, updates or deletes a member row has to drop
 * those cached variants immediately. If it does not, the next reader is served
 * a list built before the write and the new member is simply not there for up
 * to a minute — which is exactly the "the check-in dropdown is empty right
 * after I add someone, then works later" bug.
 *
 * This used to be open-coded in three services and one of them (lead
 * conversion in `LeadsService.convert`) forgot it, so it now lives here and
 * every writer calls it. Do not add a fourth copy.
 */
export interface MemberCacheRedis {
  del(key: string): Promise<unknown>;
  delByPrefix(prefix: string): Promise<unknown>;
}

/** Drop every cached member-list variant for a gym, plus the dashboard rollup. */
export async function bustMemberListCaches(
  redis: MemberCacheRedis | undefined | null,
  gymId: string,
): Promise<void> {
  if (!redis || !gymId) return;
  try {
    await redis.delByPrefix(`members:list:${gymId}:`);
  } catch {
    /* redis down — the 60 s TTL is the fallback */
  }
  try {
    await redis.del(`reports:dashboard:${gymId}`);
  } catch {
    /* redis down */
  }
}
