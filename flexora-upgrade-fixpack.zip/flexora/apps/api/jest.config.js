/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: 'src',
  testRegex: '.*\\.spec\\.ts$',
  moduleFileExtensions: ['ts', 'js', 'json'],
  transform: {
    '^.+\\.ts$': 'ts-jest',
    // PHASE R4 (dependency upgrades, 2026-11-08). Two of the upgraded packages ship ESM only:
    // sanitize-html 2.18.1 pulls htmlparser2 12 (plus its dom-serializer / domelementtype /
    // domhandler / domutils / entities chain), and nodemailer 10 is itself `"type": "module"`.
    // Node 20.19+ can require() ESM, so the BUILT API RUNS FINE on node:20-alpine - verified
    // directly: require('sanitize-html') and require('htmlparser2') both work and sanitise
    // correctly on v20.20.2. Jest is the problem, not the runtime: jest has its own CJS module
    // loader and throws "Cannot use import statement outside a module" on those files, which
    // failed 15 suites at LOAD time with zero test failures.
    //
    // sanitize-html 2.18.1 is not optional and not negotiable down to 2.17.x: two of its four
    // advisories have vulnerable range `<2.18.0` (measured with npm audit against 2.17.6,
    // 2.17.7 and 2.18.0 - all three still report the finding). So the ESM dependency stays and
    // the test runner adapts to it.
    //
    // The list below is exactly the ESM-only packages reachable from src, enumerated by scanning
    // apps/api/node_modules for `"type": "module"` rather than guessed. eslint's own ESM packages
    // are deliberately absent: they are dev-only and never imported by a suite.
    '^.+\\.js$': ['ts-jest', { tsconfig: { allowJs: true, esModuleInterop: true } }],
  },
  transformIgnorePatterns: [
    '/node_modules/(?!(htmlparser2|dom-serializer|domelementtype|domhandler|domutils|entities|nodemailer|nanoid|minimatch)/)',
  ],
};
