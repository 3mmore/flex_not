import { PrismaClient } from '@prisma/client';

/**
 * One-shot, idempotent cleanup for duplicate active plans.
 * Canonical = oldest active row in each (gymId, name, type, price) group.
 * Run with DATABASE_URL configured: npx ts-node prisma/deduplicate-plans.ts
 */
const prisma = new PrismaClient();

async function main() {
  const before = await prisma.plan.count();
  const duplicateGroups = await prisma.plan.groupBy({
    by: ['gymId', 'name', 'price', 'type'],
    where: { active: true },
    _count: { _all: true },
    having: { id: { _count: { gt: 1 } } },
    orderBy: { gymId: 'asc' },
  });
  console.log('DUPLICATE_DETECTION_QUERY_OUTPUT');
  console.log(JSON.stringify(duplicateGroups, (_, value) => typeof value === 'object' && value?.constructor?.name === 'Decimal' ? value.toString() : value, 2));

  let repointedMembers = 0;
  const affectedGyms = new Set<string>();
  const gymPlanCountsBefore = new Map<string, number>();
  for (const group of duplicateGroups) {
    affectedGyms.add(group.gymId);
    if (!gymPlanCountsBefore.has(group.gymId)) {
      gymPlanCountsBefore.set(group.gymId, await prisma.plan.count({ where: { gymId: group.gymId } }));
    }
    const activeRows = await prisma.plan.findMany({
      where: { gymId: group.gymId, name: group.name, price: group.price, type: group.type, active: true },
      orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      select: { id: true },
    });
    const canonical = activeRows[0];
    if (!canonical) continue;
    // Include inactive historical rows too, otherwise the full-table unique
    // constraint could still fail when the migration is applied.
    const allRows = await prisma.plan.findMany({
      where: { gymId: group.gymId, name: group.name, price: group.price, type: group.type },
      select: { id: true },
    });
    const duplicateIds = allRows.filter((row) => row.id !== canonical.id).map((row) => row.id);
    if (!canonical || duplicateIds.length === 0) continue;
    const result = await prisma.$transaction(async (tx) => {
      const members = await tx.member.updateMany({ where: { planId: { in: duplicateIds } }, data: { planId: canonical.id } });
      // Delete extras rather than only deactivating them: the database-level
      // unique constraint covers historical rows as well as active rows.
      await tx.plan.deleteMany({ where: { id: { in: duplicateIds } } });
      return members.count;
    });
    repointedMembers += result;
  }

  const after = await prisma.plan.count();
  const affectedCounts = await Promise.all([...affectedGyms].map(async (gymId) => ({
    gymId,
    before: gymPlanCountsBefore.get(gymId) ?? 0,
    after: await prisma.plan.count({ where: { gymId } }),
    activeAfter: await prisma.plan.count({ where: { gymId, active: true } }),
  })));
  const orphanRows = await prisma.$queryRaw<Array<{ count: bigint }>>`SELECT COUNT(*)::bigint AS count FROM "Member" m LEFT JOIN "Plan" p ON p.id = m."planId" WHERE p.id IS NULL`;
  const orphanedMembers = Number(orphanRows[0]?.count ?? 0n);
  console.log('CLEANUP_ROW_COUNTS');
  console.log(JSON.stringify({ planRowsBefore: before, planRowsAfter: after, affectedGyms: affectedCounts, membersRepointed: repointedMembers }, null, 2));
  console.log('ORPHANED_MEMBER_QUERY_OUTPUT');
  console.log(JSON.stringify({ orphanedMembers }, null, 2));
  if (orphanedMembers !== 0) throw new Error(`Orphaned members remain: ${orphanedMembers}`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => prisma.$disconnect());
