// MUST stay the first import: loads apps/api/.env before the guards below read
// NODE_ENV / SUPER_ADMIN_PASSWORD (see src/config/load-env.ts).
import '../src/config/load-env';
import { PrismaClient, Prisma } from '@prisma/client';
import * as argon2 from 'argon2';
import { randomBytes } from 'crypto';
import { isProduction, envMode } from '../src/config/env-mode';

const prisma = new PrismaClient();
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const lic = () => { const b = () => randomBytes(2).toString('hex').toUpperCase(); return `FLEX-${b()}-${b()}-${b()}`; };

async function main() {
  // PHASE M1: production is the default. The seed writes demo accounts with a
  // known password, so it must refuse unless the environment explicitly says
  // development or test — an unset NODE_ENV no longer lets it through.
  if (isProduction()) {
    console.error(`FATAL: seed.ts must not run outside development/test (NODE_ENV=${envMode()}).`);
    process.exit(1);
  }
  // PHASE M3.2: there is no default password any more. A shipped default is a
  // credential: it is in every clone, in every fork and in every scanner's
  // dictionary. If SUPER_ADMIN_PASSWORD is not set, the seed refuses and tells
  // you how to make one, instead of silently creating accounts anyone can
  // log into.
  const pwd = process.env.SUPER_ADMIN_PASSWORD;
  if (!pwd || pwd.length < 12) {
    console.error(
      'FATAL: SUPER_ADMIN_PASSWORD is not set (or is shorter than 12 characters).\n' +
        '       The seed creates real accounts, so it will not invent a password for you.\n' +
        '       Generate one and put it in apps/api/.env, e.g.:\n' +
        '         echo "SUPER_ADMIN_PASSWORD=$(openssl rand -base64 24 | tr \'+/\' \'-_\')" >> apps/api/.env',
    );
    process.exit(1);
  }
  const hash = await argon2.hash(pwd);

  // PHASE R1 / owner decision D3 - the default console administrator is a
  // DEVELOPMENT convenience only. Outside development it is not created, because a
  // known email address with a password that came from an environment variable is
  // exactly the account an attacker tries first. A real deployment creates its first
  // administrator with `npm run bootstrap:admin`, which refuses to run without
  // --confirm, never takes a password on the command line, and hashes with the same
  // PASSWORD_HASH_OPTIONS the api uses.
  //
  // An administrator that already exists in a database is NOT deleted here: that
  // would be a change to stored data. PlatformBootChecks makes it loud instead -
  // an error line and an immutable audit row at every production boot - and R1.1
  // makes it useless without TOTP enrolment.
  const seedNodeEnv = String(process.env.NODE_ENV || 'development').toLowerCase();
  if (seedNodeEnv === 'production') {
    console.log('  skipping the default console administrator (NODE_ENV=production)');
    console.log('  create one with: npm run bootstrap:admin -- --confirm --email you@example.com');
  } else {
    const defaultAdminEmail = process.env.PLATFORM_ADMIN_EMAIL || 'admin@flexora.com';
    await prisma.platformAdmin.upsert({
      where: { email: defaultAdminEmail },
      update: {},
      create: {
        email: defaultAdminEmail,
        passwordHash: await argon2.hash(process.env.PLATFORM_ADMIN_PASSWORD || pwd),
        name: 'Platform Admin',
        role: 'PLATFORM_ADMIN',
      },
    });
    console.log(`  console administrator for development: ${defaultAdminEmail} (TOTP enrolment is still required)`);
  }

  // Phase 5: seeded plans/branches/classes below belong to the INTERNAL demo
  // testing gym (slug 'demo') ONLY. Nothing here runs for a real customer
  // signup — real gyms are created through /api/auth/register.
  //
  // PHASE P6 correction: this comment used to claim registration creates "a gym
  // with a single 'Main Branch'". It does not. auth.service.ts stopped
  // auto-creating a default branch (see the note at its register path:
  // "Previously a default 'Main Branch' was auto-created here"), so a freshly
  // registered gym has NO branch and ZERO plans, and the owner creates both.
  // That matters operationally: Member.branchId is NOT NULL, so a new gym cannot
  // add a member until it has created at least one branch — which is exactly why
  // the demo gym below is seeded with branches while a real signup is not.
  const existing = await prisma.gym.findUnique({ where: { slug: 'demo' } });
  if (existing) { console.log('Demo gym already seeded'); return; }

  const gym = await prisma.gym.create({
    data: {
      name: 'FLEXORA Demo Gym',
      slug: 'demo',
      status: 'ACTIVE',
      email: 'owner@demo.flexora.app',
      phone: '01000000000',
      // ROUND 13 (Phase 2): set the demo gym's brand color EXPLICITLY instead
      // of inheriting whatever the column default happens to be — the demo
      // account is the first thing anyone sees, and it must boot gold.
      accentColor: '#C5A059',
      branches: {
        create: [
          { name: 'Nasr City', address: '90th St, Cairo', phone: '01012345678', manager: 'Sara Salah' },
          { name: 'Maadi', address: 'Road 9, Cairo', phone: '01112223344', manager: 'Omar Khaled' },
        ],
      },
      plans: {
        create: [
          { name: '15 Sessions', type: 'SESSION', sessions: 15, days: 60, price: 600 },
          { name: '1 Month', type: 'TIME', days: 30, price: 450 },
          { name: '3 Months', type: 'TIME', days: 90, price: 1100 },
          { name: '6 Months', type: 'TIME', days: 180, price: 1900 },
          { name: '12 Months', type: 'TIME', days: 365, price: 3200 },
        ],
      },
      license: { create: { key: lic(), status: 'ACTIVE', seats: 25, branchesAllowed: 5, expiresAt: addDays(new Date(), 365) } },
      subscription: { create: { tier: 'ELITE', status: 'ACTIVE', currentPeriodEnd: addDays(new Date(), 30) } },
      classTemplates: {
        create: [
          { name: 'Zumba Gold', capacity: 20, color: '#ec4899', durationMin: 45 },
          { name: 'CrossFit Basics', capacity: 12, color: '#ef4444', durationMin: 60 },
          { name: 'Yoga Flow', capacity: 25, color: '#10b981', durationMin: 75 },
        ],
      },
    },
    include: { branches: true, plans: true, classTemplates: true },
  });

  // CRITICAL: Set RLS context for the remainder of the session to avoid "new row violates RLS policy"
  await prisma.$executeRawUnsafe(`SELECT set_config('app.gym_id', '${gym.id}', false)`);

  const branch = gym.branches[0];
  /**
   * onboardingCompleted: true — the demo gym is a fully configured tenant
   * (branches, plans, members, devices already exist), but the flag defaults to
   * false. The middleware sends an OWNER whose claim is false to /onboarding,
   * so every demo login landed in the setup wizard instead of the dashboard and
   * NO page behind it could be exercised. The wizard is for new signups only.
   */
  await prisma.user.create({
    data: { gymId: gym.id, branchId: branch.id, name: 'Sara Salah', email: 'owner@demo.flexora.app', passwordHash: hash, role: 'OWNER', onboardingCompleted: true },
  });
  await prisma.user.createMany({
    data: [
      { gymId: gym.id, branchId: branch.id, name: 'Mona Adel', email: 'reception@demo.flexora.app', passwordHash: hash, role: 'RECEPTION', onboardingCompleted: true },
      { gymId: gym.id, branchId: gym.branches[1].id, name: 'Omar Khaled', email: 'manager@demo.flexora.app', passwordHash: hash, role: 'MANAGER', onboardingCompleted: true },
      { gymId: gym.id, branchId: branch.id, name: 'Khaled Raafat', email: 'coach@demo.flexora.app', passwordHash: hash, role: 'COACH', onboardingCompleted: true },
    ],
  });

  const plan3m = gym.plans.find((p) => p.name === '3 Months')!;
  const plan15 = gym.plans.find((p) => p.name === '15 Sessions')!;

  await prisma.member.createMany({
    data: [
      { gymId: gym.id, branchId: branch.id, planId: plan3m.id, code: 'FLEX-' + randomBytes(3).toString('hex').toUpperCase(), name: 'Ahmed Hassan', mobile: '01012345678', gender: 'MALE', startDate: addDays(new Date(), -40), expiry: addDays(new Date(), 50), visits: 22 },
      { gymId: gym.id, branchId: branch.id, planId: plan15.id, code: 'FLEX-' + randomBytes(3).toString('hex').toUpperCase(), name: 'Youssef Ibrahim', mobile: '01298765432', gender: 'MALE', sessionsLeft: 4, startDate: addDays(new Date(), -20), visits: 11 },
      { gymId: gym.id, branchId: branch.id, planId: plan3m.id, code: 'FLEX-' + randomBytes(3).toString('hex').toUpperCase(), name: 'Mariam Adel', mobile: '01112223344', gender: 'FEMALE', vip: true, startDate: addDays(new Date(), -10), expiry: addDays(new Date(), 80), visits: 14 },
    ],
  });

  await prisma.product.createMany({
    data: [
      { gymId: gym.id, name: 'Whey Protein 2kg', category: 'protein', barcode: '622000100011', sellingPrice: 1450, costPrice: 1050, qty: 18, lowStockThreshold: 5 },
      { gymId: gym.id, name: 'Creatine 300g', category: 'creatine', barcode: '622000100035', sellingPrice: 520, costPrice: 360, qty: 4, lowStockThreshold: 5 },
      { gymId: gym.id, name: 'Water 600ml', category: 'water', barcode: '622000100059', sellingPrice: 10, costPrice: 5, qty: 120, lowStockThreshold: 24 },
    ],
  });

  const zumba = gym.classTemplates.find(t => t.name === 'Zumba Gold')!;
  const yoga = gym.classTemplates.find(t => t.name === 'Yoga Flow')!;
  const zumbaStart = addDays(new Date(), 1); zumbaStart.setHours(18, 0, 0, 0);
  const yogaStart = addDays(new Date(), 2); yogaStart.setHours(10, 0, 0, 0);

  await prisma.classSession.createMany({
    data: [
      { gymId: gym.id, templateId: zumba.id, branchId: branch.id, startsAt: zumbaStart, endsAt: new Date(zumbaStart.getTime() + 45 * 60000), capacity: zumba.capacity, status: 'SCHEDULED' },
      { gymId: gym.id, templateId: yoga.id, branchId: branch.id, startsAt: yogaStart, endsAt: new Date(yogaStart.getTime() + 75 * 60000), capacity: yoga.capacity, status: 'SCHEDULED' },
    ]
  });

  console.log('Seed complete.');
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
