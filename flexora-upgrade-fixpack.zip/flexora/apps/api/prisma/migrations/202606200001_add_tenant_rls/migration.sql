-- FLEXORA tenant isolation RLS safety net
-- Additive migration: enables RLS and creates policies for tables with gymId.

ALTER TABLE "User" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'User' AND policyname = 'User_tenant_isolation') THEN
    CREATE POLICY "User_tenant_isolation" ON "User"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Branch" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Branch' AND policyname = 'Branch_tenant_isolation') THEN
    CREATE POLICY "Branch_tenant_isolation" ON "Branch"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Plan" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Plan' AND policyname = 'Plan_tenant_isolation') THEN
    CREATE POLICY "Plan_tenant_isolation" ON "Plan"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Member" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Member' AND policyname = 'Member_tenant_isolation') THEN
    CREATE POLICY "Member_tenant_isolation" ON "Member"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "MemberOtp" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'MemberOtp' AND policyname = 'MemberOtp_tenant_isolation') THEN
    CREATE POLICY "MemberOtp_tenant_isolation" ON "MemberOtp"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Attendance" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Attendance' AND policyname = 'Attendance_tenant_isolation') THEN
    CREATE POLICY "Attendance_tenant_isolation" ON "Attendance"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Product" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Product' AND policyname = 'Product_tenant_isolation') THEN
    CREATE POLICY "Product_tenant_isolation" ON "Product"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Sale" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Sale' AND policyname = 'Sale_tenant_isolation') THEN
    CREATE POLICY "Sale_tenant_isolation" ON "Sale"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Expense" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Expense' AND policyname = 'Expense_tenant_isolation') THEN
    CREATE POLICY "Expense_tenant_isolation" ON "Expense"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Transaction" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Transaction' AND policyname = 'Transaction_tenant_isolation') THEN
    CREATE POLICY "Transaction_tenant_isolation" ON "Transaction"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'AuditLog' AND policyname = 'AuditLog_tenant_isolation') THEN
    CREATE POLICY "AuditLog_tenant_isolation" ON "AuditLog"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Notification" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Notification' AND policyname = 'Notification_tenant_isolation') THEN
    CREATE POLICY "Notification_tenant_isolation" ON "Notification"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Backup" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Backup' AND policyname = 'Backup_tenant_isolation') THEN
    CREATE POLICY "Backup_tenant_isolation" ON "Backup"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "License" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'License' AND policyname = 'License_tenant_isolation') THEN
    CREATE POLICY "License_tenant_isolation" ON "License"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Subscription" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Subscription' AND policyname = 'Subscription_tenant_isolation') THEN
    CREATE POLICY "Subscription_tenant_isolation" ON "Subscription"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ClassTemplate" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ClassTemplate' AND policyname = 'ClassTemplate_tenant_isolation') THEN
    CREATE POLICY "ClassTemplate_tenant_isolation" ON "ClassTemplate"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ClassSession" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ClassSession' AND policyname = 'ClassSession_tenant_isolation') THEN
    CREATE POLICY "ClassSession_tenant_isolation" ON "ClassSession"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ClassBooking" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ClassBooking' AND policyname = 'ClassBooking_tenant_isolation') THEN
    CREATE POLICY "ClassBooking_tenant_isolation" ON "ClassBooking"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "CoachProfile" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'CoachProfile' AND policyname = 'CoachProfile_tenant_isolation') THEN
    CREATE POLICY "CoachProfile_tenant_isolation" ON "CoachProfile"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PtSession" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PtSession' AND policyname = 'PtSession_tenant_isolation') THEN
    CREATE POLICY "PtSession_tenant_isolation" ON "PtSession"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "BodyMeasurement" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'BodyMeasurement' AND policyname = 'BodyMeasurement_tenant_isolation') THEN
    CREATE POLICY "BodyMeasurement_tenant_isolation" ON "BodyMeasurement"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "InvitationSlot" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'InvitationSlot' AND policyname = 'InvitationSlot_tenant_isolation') THEN
    CREATE POLICY "InvitationSlot_tenant_isolation" ON "InvitationSlot"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Invitation" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Invitation' AND policyname = 'Invitation_tenant_isolation') THEN
    CREATE POLICY "Invitation_tenant_isolation" ON "Invitation"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "LicenseRenewal" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'LicenseRenewal' AND policyname = 'LicenseRenewal_tenant_isolation') THEN
    CREATE POLICY "LicenseRenewal_tenant_isolation" ON "LicenseRenewal"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ReportCache" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ReportCache' AND policyname = 'ReportCache_tenant_isolation') THEN
    CREATE POLICY "ReportCache_tenant_isolation" ON "ReportCache"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Lead" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Lead' AND policyname = 'Lead_tenant_isolation') THEN
    CREATE POLICY "Lead_tenant_isolation" ON "Lead"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "LeadFollowUp" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'LeadFollowUp' AND policyname = 'LeadFollowUp_tenant_isolation') THEN
    CREATE POLICY "LeadFollowUp_tenant_isolation" ON "LeadFollowUp"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "BiometricCredential" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'BiometricCredential' AND policyname = 'BiometricCredential_tenant_isolation') THEN
    CREATE POLICY "BiometricCredential_tenant_isolation" ON "BiometricCredential"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "MemberContract" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'MemberContract' AND policyname = 'MemberContract_tenant_isolation') THEN
    CREATE POLICY "MemberContract_tenant_isolation" ON "MemberContract"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Campaign" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Campaign' AND policyname = 'Campaign_tenant_isolation') THEN
    CREATE POLICY "Campaign_tenant_isolation" ON "Campaign"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "StaffAttendance" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'StaffAttendance' AND policyname = 'StaffAttendance_tenant_isolation') THEN
    CREATE POLICY "StaffAttendance_tenant_isolation" ON "StaffAttendance"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "BranchTransfer" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'BranchTransfer' AND policyname = 'BranchTransfer_tenant_isolation') THEN
    CREATE POLICY "BranchTransfer_tenant_isolation" ON "BranchTransfer"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ChartOfAccount" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ChartOfAccount' AND policyname = 'ChartOfAccount_tenant_isolation') THEN
    CREATE POLICY "ChartOfAccount_tenant_isolation" ON "ChartOfAccount"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "JournalEntry" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'JournalEntry' AND policyname = 'JournalEntry_tenant_isolation') THEN
    CREATE POLICY "JournalEntry_tenant_isolation" ON "JournalEntry"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Supplier" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Supplier' AND policyname = 'Supplier_tenant_isolation') THEN
    CREATE POLICY "Supplier_tenant_isolation" ON "Supplier"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PurchaseOrder" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PurchaseOrder' AND policyname = 'PurchaseOrder_tenant_isolation') THEN
    CREATE POLICY "PurchaseOrder_tenant_isolation" ON "PurchaseOrder"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "GoodsReceipt" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'GoodsReceipt' AND policyname = 'GoodsReceipt_tenant_isolation') THEN
    CREATE POLICY "GoodsReceipt_tenant_isolation" ON "GoodsReceipt"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "StockMovement" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'StockMovement' AND policyname = 'StockMovement_tenant_isolation') THEN
    CREATE POLICY "StockMovement_tenant_isolation" ON "StockMovement"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Pipeline" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Pipeline' AND policyname = 'Pipeline_tenant_isolation') THEN
    CREATE POLICY "Pipeline_tenant_isolation" ON "Pipeline"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Deal" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Deal' AND policyname = 'Deal_tenant_isolation') THEN
    CREATE POLICY "Deal_tenant_isolation" ON "Deal"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Activity" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Activity' AND policyname = 'Activity_tenant_isolation') THEN
    CREATE POLICY "Activity_tenant_isolation" ON "Activity"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Task" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Task' AND policyname = 'Task_tenant_isolation') THEN
    CREATE POLICY "Task_tenant_isolation" ON "Task"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "AiInsight" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'AiInsight' AND policyname = 'AiInsight_tenant_isolation') THEN
    CREATE POLICY "AiInsight_tenant_isolation" ON "AiInsight"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "CustomDomain" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'CustomDomain' AND policyname = 'CustomDomain_tenant_isolation') THEN
    CREATE POLICY "CustomDomain_tenant_isolation" ON "CustomDomain"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "EmailTemplate" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'EmailTemplate' AND policyname = 'EmailTemplate_tenant_isolation') THEN
    CREATE POLICY "EmailTemplate_tenant_isolation" ON "EmailTemplate"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "GymModuleInstallation" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'GymModuleInstallation' AND policyname = 'GymModuleInstallation_tenant_isolation') THEN
    CREATE POLICY "GymModuleInstallation_tenant_isolation" ON "GymModuleInstallation"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "GymSettings" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'GymSettings' AND policyname = 'GymSettings_tenant_isolation') THEN
    CREATE POLICY "GymSettings_tenant_isolation" ON "GymSettings"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "CustomRole" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'CustomRole' AND policyname = 'CustomRole_tenant_isolation') THEN
    CREATE POLICY "CustomRole_tenant_isolation" ON "CustomRole"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "ScimToken" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'ScimToken' AND policyname = 'ScimToken_tenant_isolation') THEN
    CREATE POLICY "ScimToken_tenant_isolation" ON "ScimToken"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Refund" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Refund' AND policyname = 'Refund_tenant_isolation') THEN
    CREATE POLICY "Refund_tenant_isolation" ON "Refund"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "RefundAudit" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'RefundAudit' AND policyname = 'RefundAudit_tenant_isolation') THEN
    CREATE POLICY "RefundAudit_tenant_isolation" ON "RefundAudit"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Invoice" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Invoice' AND policyname = 'Invoice_tenant_isolation') THEN
    CREATE POLICY "Invoice_tenant_isolation" ON "Invoice"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Payment" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Payment' AND policyname = 'Payment_tenant_isolation') THEN
    CREATE POLICY "Payment_tenant_isolation" ON "Payment"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Receipt" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Receipt' AND policyname = 'Receipt_tenant_isolation') THEN
    CREATE POLICY "Receipt_tenant_isolation" ON "Receipt"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "CampaignRecipient" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'CampaignRecipient' AND policyname = 'CampaignRecipient_tenant_isolation') THEN
    CREATE POLICY "CampaignRecipient_tenant_isolation" ON "CampaignRecipient"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PurchaseOrderItem" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PurchaseOrderItem' AND policyname = 'PurchaseOrderItem_tenant_isolation') THEN
    CREATE POLICY "PurchaseOrderItem_tenant_isolation" ON "PurchaseOrderItem"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PaymentAttempt" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PaymentAttempt' AND policyname = 'PaymentAttempt_tenant_isolation') THEN
    CREATE POLICY "PaymentAttempt_tenant_isolation" ON "PaymentAttempt"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "BillingRecoveryTask" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'BillingRecoveryTask' AND policyname = 'BillingRecoveryTask_tenant_isolation') THEN
    CREATE POLICY "BillingRecoveryTask_tenant_isolation" ON "BillingRecoveryTask"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "StaffPayProfile" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'StaffPayProfile' AND policyname = 'StaffPayProfile_tenant_isolation') THEN
    CREATE POLICY "StaffPayProfile_tenant_isolation" ON "StaffPayProfile"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "Timesheet" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'Timesheet' AND policyname = 'Timesheet_tenant_isolation') THEN
    CREATE POLICY "Timesheet_tenant_isolation" ON "Timesheet"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "FinancialReconciliation" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'FinancialReconciliation' AND policyname = 'FinancialReconciliation_tenant_isolation') THEN
    CREATE POLICY "FinancialReconciliation_tenant_isolation" ON "FinancialReconciliation"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PaymentProviderEvent" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PaymentProviderEvent' AND policyname = 'PaymentProviderEvent_tenant_isolation') THEN
    CREATE POLICY "PaymentProviderEvent_tenant_isolation" ON "PaymentProviderEvent"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "NotificationSubscription" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'NotificationSubscription' AND policyname = 'NotificationSubscription_tenant_isolation') THEN
    CREATE POLICY "NotificationSubscription_tenant_isolation" ON "NotificationSubscription"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "WaConversation" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'WaConversation' AND policyname = 'WaConversation_tenant_isolation') THEN
    CREATE POLICY "WaConversation_tenant_isolation" ON "WaConversation"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "WaMessage" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'WaMessage' AND policyname = 'WaMessage_tenant_isolation') THEN
    CREATE POLICY "WaMessage_tenant_isolation" ON "WaMessage"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "AutonomousAction" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'AutonomousAction' AND policyname = 'AutonomousAction_tenant_isolation') THEN
    CREATE POLICY "AutonomousAction_tenant_isolation" ON "AutonomousAction"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "CampaignMessage" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'CampaignMessage' AND policyname = 'CampaignMessage_tenant_isolation') THEN
    CREATE POLICY "CampaignMessage_tenant_isolation" ON "CampaignMessage"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "DunningLog" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'DunningLog' AND policyname = 'DunningLog_tenant_isolation') THEN
    CREATE POLICY "DunningLog_tenant_isolation" ON "DunningLog"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PayrollRecord" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PayrollRecord' AND policyname = 'PayrollRecord_tenant_isolation') THEN
    CREATE POLICY "PayrollRecord_tenant_isolation" ON "PayrollRecord"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

ALTER TABLE "PayrollDetail" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'PayrollDetail' AND policyname = 'PayrollDetail_tenant_isolation') THEN
    CREATE POLICY "PayrollDetail_tenant_isolation" ON "PayrollDetail"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;
