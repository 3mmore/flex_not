-- Sale member relation: SET NULL on delete (preserve financial records)

ALTER TABLE "Sale" DROP CONSTRAINT IF EXISTS "Sale_memberId_fkey";

ALTER TABLE "Sale" ADD CONSTRAINT "Sale_memberId_fkey"
  FOREIGN KEY ("memberId") REFERENCES "Member"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;