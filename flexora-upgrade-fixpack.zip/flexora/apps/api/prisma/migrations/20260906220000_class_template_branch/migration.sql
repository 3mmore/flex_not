-- P4-1: class templates gain branch scoping.
-- NOTE: "branchId" column already exists in the DB (created by an earlier
-- hand migration) but was missing from the Prisma schema — adding it there
-- is what makes create/update accept it. Here we only add integrity guards:
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ClassTemplate_coachId_fkey') THEN
    ALTER TABLE "ClassTemplate" ADD CONSTRAINT "ClassTemplate_coachId_fkey"
      FOREIGN KEY ("coachId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ClassTemplate_branchId_fkey') THEN
    ALTER TABLE "ClassTemplate" ADD CONSTRAINT "ClassTemplate_branchId_fkey"
      FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END$$;

CREATE INDEX IF NOT EXISTS "ClassTemplate_gymId_branchId_idx" ON "ClassTemplate"("gymId", "branchId");
