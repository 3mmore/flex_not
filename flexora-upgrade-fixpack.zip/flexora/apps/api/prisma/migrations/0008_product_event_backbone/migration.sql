-- Product event backbone — immutable tenant-scoped event log.
CREATE TABLE IF NOT EXISTS "ProductEvent" (
  "id" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "tenantId" TEXT NOT NULL,
  "branchId" TEXT,
  "userId" TEXT,
  "entityId" TEXT,
  "payload" JSONB NOT NULL,
  "source" TEXT NOT NULL,
  "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ProductEvent_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ProductEvent_tenantId_timestamp_idx" ON "ProductEvent"("tenantId", "timestamp");
CREATE INDEX IF NOT EXISTS "ProductEvent_tenantId_type_timestamp_idx" ON "ProductEvent"("tenantId", "type", "timestamp");
CREATE INDEX IF NOT EXISTS "ProductEvent_entityId_idx" ON "ProductEvent"("entityId");
