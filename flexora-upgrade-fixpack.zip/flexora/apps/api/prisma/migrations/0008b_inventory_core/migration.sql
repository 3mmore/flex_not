-- FIX: create inventory parent tables (Supplier, PurchaseOrder, GoodsReceipt,
-- StockMovement) + their enums. These models exist in schema.prisma but were
-- never created by any migration; 0009 then references PurchaseOrder/GoodsReceipt
-- as FK targets, breaking `prisma migrate deploy` on a fresh database.
-- Idempotent (IF NOT EXISTS / DO-block enum guards) so re-runs are safe.

DO $$ BEGIN CREATE TYPE "PurchaseOrderStatus" AS ENUM ('DRAFT','SENT','PARTIAL','RECEIVED','CANCELLED'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "StockMovementType" AS ENUM ('PURCHASE','SALE','TRANSFER_IN','TRANSFER_OUT','ADJUSTMENT','EXPIRY'); EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS "Supplier" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "name" TEXT NOT NULL,
  "contactName" TEXT,
  "phone" TEXT,
  "email" TEXT,
  "address" TEXT,
  "taxId" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "Supplier_gymId_idx" ON "Supplier"("gymId");

CREATE TABLE IF NOT EXISTS "PurchaseOrder" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "supplierId" TEXT NOT NULL REFERENCES "Supplier"("id") ON UPDATE CASCADE,
  "branchId" TEXT,
  "poNo" TEXT NOT NULL,
  "status" "PurchaseOrderStatus" NOT NULL DEFAULT 'DRAFT',
  "total" DECIMAL(14,2) NOT NULL DEFAULT 0,
  "notes" TEXT,
  "expectedAt" TIMESTAMP(3),
  "receivedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS "PurchaseOrder_gymId_poNo_key" ON "PurchaseOrder"("gymId","poNo");
CREATE INDEX IF NOT EXISTS "PurchaseOrder_gymId_status_idx" ON "PurchaseOrder"("gymId","status");

CREATE TABLE IF NOT EXISTS "GoodsReceipt" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "purchaseOrderId" TEXT REFERENCES "PurchaseOrder"("id") ON UPDATE CASCADE,
  "branchId" TEXT,
  "receivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "receivedBy" TEXT,
  "notes" TEXT
);
CREATE INDEX IF NOT EXISTS "GoodsReceipt_gymId_idx" ON "GoodsReceipt"("gymId");

CREATE TABLE IF NOT EXISTS "StockMovement" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "productId" TEXT NOT NULL REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "branchId" TEXT,
  "type" "StockMovementType" NOT NULL,
  "qty" INTEGER NOT NULL,
  "unitCost" DECIMAL(14,2),
  "reference" TEXT,
  "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdBy" TEXT
);
CREATE INDEX IF NOT EXISTS "StockMovement_gymId_productId_idx" ON "StockMovement"("gymId","productId");
CREATE INDEX IF NOT EXISTS "StockMovement_gymId_type_occurredAt_idx" ON "StockMovement"("gymId","type","occurredAt");
