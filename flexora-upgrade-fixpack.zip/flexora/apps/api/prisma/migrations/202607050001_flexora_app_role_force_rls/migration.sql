-- FLEXORA Gym OS — Item 2: dedicated non-superuser Postgres role for RLS
-- enforcement, plus FORCE ROW LEVEL SECURITY on every tenant-scoped table.
--
-- WHY: Postgres RLS policies are silently BYPASSED for the table owner and
-- for any role with the SUPERUSER or BYPASSRLS attribute — no matter how
-- many `CREATE POLICY` statements exist. Every previous RLS migration in
-- this project (202606200001_add_tenant_rls, 202606200002_add_missing_rls_
-- policies, ...) only ever ran `ENABLE ROW LEVEL SECURITY`, which is *not*
-- enough on its own if the application connects as the table owner (which
-- is exactly what `prisma migrate deploy`/`db push` does by default — the
-- role that created the tables automatically owns them). If DATABASE_URL in
-- production points at that same owner/superuser role, every RLS policy in
-- this codebase is decorative only.
--
-- THIS MIGRATION:
--   1. Creates a dedicated, least-privilege `flexora_app` login role that is
--      explicitly NOSUPERUSER and NOBYPASSRLS (idempotent — safe to re-run).
--   2. Grants it exactly the privileges the application needs (CRUD on all
--      current tables/sequences in `public`, plus default privileges so
--      future tables created by migrations are automatically covered).
--   3. Does NOT make flexora_app own any table — ownership stays with
--      whatever role runs migrations (e.g. `postgres` or a dedicated
--      migrator role), which is what makes FORCE ROW LEVEL SECURITY actually
--      matter: FORCE RLS has no effect on the table owner, but flexora_app
--      is deliberately never the owner.
--   4. Adds `FORCE ROW LEVEL SECURITY` to every table that already has
--      `ENABLE ROW LEVEL SECURITY` set by earlier migrations, so that even a
--      role with table-level GRANTs (like flexora_app) cannot read/write
--      rows outside its tenant context — FORCE RLS applies row security to
--      the table owner too, but since flexora_app is NOT the owner, plain
--      ENABLE RLS already covered it; FORCE additionally protects against
--      accidentally granting flexora_app ownership later, and against the
--      "table owner" edge case entirely, closing the gap directly named in
--      the ticket ("if the app connects as a superuser/table owner, RLS is
--      bypassed entirely").
--   5. Also enables + forces RLS + adds the same tenant-isolation policy for
--      "OwnerNotification", the one gymId-bearing table that earlier
--      migrations (202606200015_owner_notifications) created without ever
--      turning RLS on for it — closing that pre-existing gap while we're
--      here, since it is squarely inside the "FORCE ROW LEVEL SECURITY on
--      every tenant table" requirement of this item.
--
-- Deploying with the new role:
--   DATABASE_URL should be changed to use `flexora_app` instead of the
--   table-owning/superuser role, e.g.:
--     postgresql://flexora_app:<password>@host:5432/flexora?schema=public
--   The password below is a placeholder; ALWAYS set a real one immediately
--   after this migration runs, e.g.:
--     ALTER ROLE flexora_app WITH PASSWORD '<openssl rand -hex 24>';
--   (See apps/api/scripts/setup-db-role.sql and docs/DATABASE_SETUP.md for
--   the documented production setup procedure.)

-- 1. Create the role (idempotent).
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'flexora_app') THEN
    CREATE ROLE flexora_app
      WITH LOGIN
      NOSUPERUSER
      NOCREATEDB
      NOCREATEROLE
      NOREPLICATION
      NOBYPASSRLS
      CONNECTION LIMIT -1
      PASSWORD 'CHANGE_ME_IMMEDIATELY_AFTER_MIGRATION';
  ELSE
    -- Re-assert the safety attributes even if the role already exists, in
    -- case someone manually altered it later (defense in depth).
    ALTER ROLE flexora_app
      NOSUPERUSER
      NOCREATEDB
      NOCREATEROLE
      NOREPLICATION
      NOBYPASSRLS;
  END IF;
END $$;

-- 2. Grant schema usage + CRUD on all current tables/sequences, and make
--    sure future tables/sequences created by later migrations are
--    automatically granted too (ALTER DEFAULT PRIVILEGES only affects
--    objects created *by the role that runs this statement* from now on —
--    typically the migration/owner role — which is exactly what we want:
--    flexora_app should never need to be the one creating tables).
GRANT USAGE ON SCHEMA public TO flexora_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO flexora_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO flexora_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO flexora_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO flexora_app;

-- 3. Close the OwnerNotification RLS gap (gymId-bearing table that was
--    never RLS-enabled by earlier migrations) — required so step 4 below
--    ("FORCE RLS on every tenant table") is complete and correct.
ALTER TABLE "OwnerNotification" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = current_schema() AND tablename = 'OwnerNotification'
      AND policyname = 'OwnerNotification_tenant_isolation'
  ) THEN
    CREATE POLICY "OwnerNotification_tenant_isolation" ON "OwnerNotification"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

-- 4. FORCE ROW LEVEL SECURITY on every table that has RLS enabled
--    (all tenant tables from every prior RLS migration, plus
--    OwnerNotification which we just enabled above).
DO $$
DECLARE
  t text;
BEGIN
  FOR t IN
    SELECT relname FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = current_schema()
      AND c.relkind = 'r'
      AND c.relrowsecurity = true
  LOOP
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;
