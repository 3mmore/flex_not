-- =============================================================================
-- PHASE N2 — FORCE ROW LEVEL SECURITY on EVERY table that has RLS enabled.
--
-- THE BUG (found by running the full `npm test` suite against a freshly
-- migrated database): migration 202607050001_flexora_app_role_force_rls adds
-- FORCE ROW LEVEL SECURITY with a dynamic DO block that walks pg_class and
-- covers "every table that has RLS enabled" — but it can only see the tables
-- that existed AT THE TIME IT RAN. Two tenant-scoped tables enable RLS in
-- LATER migrations and therefore never received FORCE:
--
--   * "UserPermission"   — 20261009220000_round13_user_permissions (:27)
--   * "RenewalRequest"   — 20261014100000_round14_phaseF (:42)
--
-- On a database that was built by applying the migrations in order (a new
-- installation, a restored backup, CI's service container) those two tables
-- ended up with relrowsecurity = true and relforcerowsecurity = false, i.e.
-- 77 RLS tables but only 75 forced. The defect stayed invisible on the
-- long-lived developer database only because that migration had been re-run
-- there (migrate resolve --rolled-back + redeploy) AFTER all tables existed.
--
-- WHY IT MATTERS: without FORCE, RLS does not apply to the table OWNER. The
-- application connects as the unprivileged `flexora_app` role today, so it is
-- covered either way — but the moment anything connects as the owning role
-- (a migration runner, a psql session, a future service, a restore job),
-- policies on those two tables are silently bypassed. FORCE is the
-- defence-in-depth half of the RLS design documented in 202607050001.
--
-- THE FIX: re-apply FORCE dynamically, so this migration is correct no matter
-- which tables exist, is idempotent, and is safe to run on an already-fixed
-- database. It ends with a hard assertion: if ANY public table still has RLS
-- enabled without FORCE, the migration FAILS instead of shipping a database
-- that only looks protected.
--
-- RULE FOR FUTURE MIGRATIONS (enforced at test time by
-- src/test/integration/db-role-rls-enforcement.spec.ts, "every table with RLS
-- enabled also has FORCE ROW LEVEL SECURITY set"): every
-- `ALTER TABLE x ENABLE ROW LEVEL SECURITY` must be accompanied by
-- `ALTER TABLE x FORCE ROW LEVEL SECURITY` in the SAME migration.
-- =============================================================================

DO $$
DECLARE
  t text;
  fixed text[] := ARRAY[]::text[];
  remaining text;
BEGIN
  FOR t IN
    SELECT c.relname FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = current_schema()
      AND c.relkind = 'r'
      AND c.relrowsecurity = true
      AND NOT c.relforcerowsecurity
    ORDER BY c.relname
  LOOP
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    fixed := fixed || t;
    RAISE NOTICE 'PHASE N2: FORCE ROW LEVEL SECURITY added to "%" (RLS was enabled without it)', t;
  END LOOP;

  IF array_length(fixed, 1) IS NOT NULL THEN
    RAISE NOTICE 'PHASE N2: FORCE ROW LEVEL SECURITY applied to % table(s): %',
      array_length(fixed, 1), array_to_string(fixed, ', ');
  ELSE
    RAISE NOTICE 'PHASE N2: every RLS-enabled table already had FORCE ROW LEVEL SECURITY (nothing to do)';
  END IF;

  -- Hard assertion — never leave a database that only looks protected.
  SELECT string_agg(c.relname, ', ' ORDER BY c.relname) INTO remaining
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = current_schema()
    AND c.relkind = 'r'
    AND c.relrowsecurity = true
    AND NOT c.relforcerowsecurity;

  IF remaining IS NOT NULL THEN
    RAISE EXCEPTION
      'PHASE N2: FORCE ROW LEVEL SECURITY could not be applied to: %. Refusing to continue with tenant tables whose policies the owning role would bypass.',
      remaining;
  END IF;
END $$;
