CREATE INDEX IF NOT EXISTS "RefreshToken_userId_idx" ON "RefreshToken"("userId");
CREATE INDEX IF NOT EXISTS "Sale_gymId_memberId_idx" ON "Sale"("gymId", "memberId");
CREATE INDEX IF NOT EXISTS "Sale_gymId_branchId_idx" ON "Sale"("gymId", "branchId");
CREATE INDEX IF NOT EXISTS "SaleItem_productId_idx" ON "SaleItem"("productId");
CREATE INDEX IF NOT EXISTS "Expense_gymId_branchId_idx" ON "Expense"("gymId", "branchId");
CREATE INDEX IF NOT EXISTS "Transaction_gymId_memberId_idx" ON "Transaction"("gymId", "memberId");
CREATE INDEX IF NOT EXISTS "Transaction_gymId_branchId_idx" ON "Transaction"("gymId", "branchId");
CREATE INDEX IF NOT EXISTS "UserRole_customRoleId_idx" ON "UserRole"("customRoleId");
CREATE INDEX IF NOT EXISTS "SsoIdentity_userId_idx" ON "SsoIdentity"("userId");
