-- P2-3: staff shift schedules + automatic lateness on staff check-in

ALTER TABLE "StaffAttendance" ADD COLUMN "expectedAt" TIMESTAMP(3);
ALTER TABLE "StaffAttendance" ADD COLUMN "lateMinutes" INTEGER;

CREATE TABLE "StaffShift" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "userId" TEXT,
    "name" TEXT,
    "dayOfWeek" INTEGER NOT NULL,
    "startMin" INTEGER NOT NULL,
    "endMin" INTEGER NOT NULL,
    "graceMin" INTEGER NOT NULL DEFAULT 15,
    "tz" TEXT NOT NULL DEFAULT 'Africa/Cairo',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "StaffShift_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "StaffShift_gymId_dayOfWeek_idx" ON "StaffShift"("gymId", "dayOfWeek");
CREATE INDEX "StaffShift_gymId_userId_dayOfWeek_idx" ON "StaffShift"("gymId", "userId", "dayOfWeek");

ALTER TABLE "StaffShift" ADD CONSTRAINT "StaffShift_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "StaffShift" ADD CONSTRAINT "StaffShift_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
