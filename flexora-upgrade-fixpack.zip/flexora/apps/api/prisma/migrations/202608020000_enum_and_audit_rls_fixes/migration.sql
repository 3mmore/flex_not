-- 1. Ensure Enum types exist (use $func$ delimiter, not $$)
DO $func$ BEGIN
  CREATE TYPE "PaymentStatus" AS ENUM ('PENDING','PARTIAL','PAID','FAILED','REFUNDED');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT','PENDING','PARTIALLY_PAID','PAID','VOID');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "RefundStatus" AS ENUM ('COMPLETED','VOIDED');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "FinancialReconciliationStatus" AS ENUM ('PENDING','RECONCILED','MISSING_INTERNAL','MISSING_PROVIDER','AMOUNT_MISMATCH','CURRENCY_MISMATCH','PROVIDER_FAILED','NOT_APPLICABLE');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "FinancialSourceType" AS ENUM ('SALE','PAYMENT','REFUND','SUBSCRIPTION');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "NotifyChannel" AS ENUM ('INAPP','EMAIL','WHATSAPP','WHATSAPP_INBOUND','SMS');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "NotifyStatus" AS ENUM ('PENDING','SENT','FAILED','RECEIVED','FAILED_PROVIDER_MISSING');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "PayrollStatus" AS ENUM ('DRAFT','APPROVED','PAID','CANCELLED');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

DO $func$ BEGIN
  CREATE TYPE "PayrollDetailType" AS ENUM ('SALARY','BONUS','DEDUCTION','OVERTIME','COMMISSION');
EXCEPTION WHEN duplicate_object THEN null;
END $func$;

-- Extend existing types
ALTER TYPE "NotifyChannel" ADD VALUE IF NOT EXISTS 'WHATSAPP_INBOUND';
ALTER TYPE "NotifyChannel" ADD VALUE IF NOT EXISTS 'SMS';
ALTER TYPE "NotifyStatus" ADD VALUE IF NOT EXISTS 'RECEIVED';
ALTER TYPE "NotifyStatus" ADD VALUE IF NOT EXISTS 'FAILED_PROVIDER_MISSING';
ALTER TYPE "InvoiceStatus" ADD VALUE IF NOT EXISTS 'PENDING';

-- 2. Convert columns: drop default, change type, restore default
ALTER TABLE "Payment" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "Payment" ALTER COLUMN "status" TYPE "PaymentStatus" USING "status"::"PaymentStatus";
ALTER TABLE "Payment" ALTER COLUMN "status" SET DEFAULT 'PAID'::"PaymentStatus";

ALTER TABLE "Invoice" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "Invoice" ALTER COLUMN "status" TYPE "InvoiceStatus" USING "status"::"InvoiceStatus";
ALTER TABLE "Invoice" ALTER COLUMN "status" SET DEFAULT 'DRAFT'::"InvoiceStatus";

ALTER TABLE "Refund" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "Refund" ALTER COLUMN "status" TYPE "RefundStatus" USING "status"::"RefundStatus";
ALTER TABLE "Refund" ALTER COLUMN "status" SET DEFAULT 'COMPLETED'::"RefundStatus";

ALTER TABLE "FinancialReconciliation" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "status" TYPE "FinancialReconciliationStatus" USING "status"::"FinancialReconciliationStatus";
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "status" SET DEFAULT 'PENDING'::"FinancialReconciliationStatus";

ALTER TABLE "FinancialReconciliation" ALTER COLUMN "sourceType" TYPE "FinancialSourceType" USING "sourceType"::"FinancialSourceType";

ALTER TABLE "CampaignMessage" ALTER COLUMN "channel" TYPE "NotifyChannel" USING "channel"::"NotifyChannel";

ALTER TABLE "CampaignMessage" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "CampaignMessage" ALTER COLUMN "status" TYPE "NotifyStatus" USING "status"::"NotifyStatus";
ALTER TABLE "CampaignMessage" ALTER COLUMN "status" SET DEFAULT 'PENDING'::"NotifyStatus";

ALTER TABLE "PayrollRecord" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "PayrollRecord" ALTER COLUMN "status" TYPE "PayrollStatus" USING "status"::"PayrollStatus";
ALTER TABLE "PayrollRecord" ALTER COLUMN "status" SET DEFAULT 'DRAFT'::"PayrollStatus";

ALTER TABLE "PayrollDetail" ALTER COLUMN "type" TYPE "PayrollDetailType" USING "type"::"PayrollDetailType";

ALTER TABLE "Sale" ALTER COLUMN "paymentStatus" DROP DEFAULT;
ALTER TABLE "Sale" ALTER COLUMN "paymentStatus" TYPE "PaymentStatus" USING "paymentStatus"::"PaymentStatus";
ALTER TABLE "Sale" ALTER COLUMN "paymentStatus" SET DEFAULT 'PAID'::"PaymentStatus";

-- 3. Fix AuditLog RLS
DROP POLICY IF EXISTS "AuditLog_isolation" ON "AuditLog";
DROP POLICY IF EXISTS "AuditLog_tenant_isolation" ON "AuditLog";
DROP POLICY IF EXISTS "AuditLog_platform_access" ON "AuditLog";

CREATE POLICY "AuditLog_isolation" ON "AuditLog"
USING (
  "gymId" = current_setting('app.gym_id', true)
  OR "gymId" IS NULL
)
WITH CHECK (
  "gymId" = current_setting('app.gym_id', true)
  OR "gymId" IS NULL
);
