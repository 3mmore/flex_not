
-- ----- Add Product columns needed by Inventory module ----
ALTER TABLE "Product"
  ADD COLUMN IF NOT EXISTS "branchId" TEXT,
  ADD COLUMN IF NOT EXISTS "active" BOOLEAN NOT NULL DEFAULT TRUE;
