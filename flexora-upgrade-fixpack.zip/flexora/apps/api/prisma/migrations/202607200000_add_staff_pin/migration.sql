-- AlterTable: Add pinHash to User for staff identity verification
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "pinHash" TEXT;
