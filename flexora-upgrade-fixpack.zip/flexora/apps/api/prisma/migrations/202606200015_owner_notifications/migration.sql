ALTER TABLE "Gym"
    ADD COLUMN IF NOT EXISTS
      "ownerPersonalMobile" TEXT,
    ADD COLUMN IF NOT EXISTS
      "ownerEmail" TEXT,
    ADD COLUMN IF NOT EXISTS
      "notifyOnSale" BOOLEAN NOT NULL DEFAULT true,
    ADD COLUMN IF NOT EXISTS
      "notifyOnMemberAdd" BOOLEAN NOT NULL
        DEFAULT true,
    ADD COLUMN IF NOT EXISTS
      "notifyOnMemberDelete" BOOLEAN NOT NULL
        DEFAULT true,
    ADD COLUMN IF NOT EXISTS
      "notifyOnDiscount" BOOLEAN NOT NULL
        DEFAULT true,
    ADD COLUMN IF NOT EXISTS
      "notifyOnRefund" BOOLEAN NOT NULL
        DEFAULT true,
    ADD COLUMN IF NOT EXISTS
      "notifyOnCheckin" BOOLEAN NOT NULL
        DEFAULT false,
    ADD COLUMN IF NOT EXISTS
      "maxDiscountAlert" INT NOT NULL DEFAULT 30,
    ADD COLUMN IF NOT EXISTS
      "maxCashAlert" INT NOT NULL DEFAULT 500,
    ADD COLUMN IF NOT EXISTS
      "antiTheftEnabled" BOOLEAN NOT NULL
        DEFAULT true;

  CREATE TABLE IF NOT EXISTS
    "OwnerNotification" (
    "id"        TEXT NOT NULL
      DEFAULT gen_random_uuid(),
    "gymId"     TEXT NOT NULL,
    "type"      TEXT NOT NULL,
    "title"     TEXT NOT NULL,
    "body"      TEXT NOT NULL,
    "icon"      TEXT NOT NULL DEFAULT 'info',
    "severity"  TEXT NOT NULL DEFAULT 'info',
    "metadata"  JSONB,
    "isRead"    BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL
      DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OwnerNotification_pkey"
      PRIMARY KEY ("id")
  );

  CREATE INDEX IF NOT EXISTS
    "OwnerNotification_gymId_isRead_idx"
    ON "OwnerNotification"("gymId", "isRead");

  CREATE INDEX IF NOT EXISTS
    "OwnerNotification_gymId_createdAt_idx"
    ON "OwnerNotification"("gymId", "createdAt");

  ALTER TABLE "OwnerNotification"
    ADD CONSTRAINT
    "OwnerNotification_gymId_fkey"
    FOREIGN KEY ("gymId")
    REFERENCES "Gym"("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
