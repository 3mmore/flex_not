-- SECURITY: PostgreSQL grants EXECUTE on new functions to PUBLIC by default.
-- These SECURITY DEFINER functions bypass tenant RLS and must be callable only
-- by the dedicated application role.
REVOKE ALL ON FUNCTION preauth_find_users_by_email(TEXT, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION preauth_find_user_by_id(TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION preauth_find_user_by_refresh_token_hash(TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION preauth_update_user_password(TEXT, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION preauth_update_user_2fa_state(TEXT, TEXT, TEXT, BOOLEAN) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION preauth_find_users_by_email(TEXT, TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_find_user_by_id(TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_find_user_by_refresh_token_hash(TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_update_user_password(TEXT, TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_update_user_2fa_state(TEXT, TEXT, TEXT, BOOLEAN) TO flexora_app;
