-- P4-5: money movements get a human-readable reference (invoice/receipt no)
-- separate from the plain-language description.
ALTER TABLE "Transaction" ADD COLUMN "reference" TEXT;
