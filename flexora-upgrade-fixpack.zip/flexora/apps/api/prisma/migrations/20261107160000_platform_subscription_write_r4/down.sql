-- ===========================================================================
-- FLEXORA Gym OS - PHASE R4 rollback: remove the platform's subscription write path.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- One explicit transaction block, so `psql --single-transaction -f down.sql` is all or
-- nothing. No data is touched: this drops one function and its grants.
--
-- WHAT ROLLING BACK MEANS, stated plainly: after this, the three platform routes that write a
-- subscription (PATCH gyms/:id/plan, POST gyms/:id/extend-trial, POST
-- gyms/:id/grant-subscription) go back to failing with 42501 whenever the api connects as the
-- runtime role, which is how production runs. That is the pre-R4 behaviour, so it is a faithful
-- rollback and not a new breakage - but it is not a state anyone should want to be in.
-- ===========================================================================

BEGIN;

DROP FUNCTION IF EXISTS public.platform_admin_set_subscription(text, text, text, timestamp(3), timestamp(3));

COMMIT;
