-- ===========================================================================
-- FLEXORA Gym OS - PHASE R4: the platform's ONE sanctioned write path into a
-- FORCE-RLS tenant table.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- ---------------------------------------------------------------------------
-- THE DEFECT THIS CLOSES, AND WHY IT SURVIVED TWO PHASES
-- ---------------------------------------------------------------------------
-- public."Subscription" is FORCE ROW LEVEL SECURITY with a single tenant-isolation
-- policy. PHASE R2 solved platform READS across tenants with eleven SECURITY DEFINER
-- aggregate functions - and every one of them is read-only. Platform WRITES were never
-- addressed. So all three routes that write a subscription (PATCH gyms/:id/plan,
-- POST gyms/:id/extend-trial, POST gyms/:id/grant-subscription) failed in production
-- with:
--     42501  new row violates row-level security policy for table "Subscription"
-- measured live during PHASE R4 (work/r4-evidence/07-gyms-mobile-375.log first run, and
-- the api log for the same request id).
--
-- Nothing caught it, for two reasons that compound. The console had no surface for any of
-- the three routes - the gyms page was a 32-line JSON dump with no buttons - so no owner
-- ever pressed one. And every jest harness connects as `flexora`, a SUPERUSER, and a
-- superuser bypasses row-level security outright, so the suites passed while the
-- production role could not write at all. PHASE R4 building the first UI that calls these
-- routes is what exposed it, and it was exposed by a browser proof driving the real api
-- rather than a test app.
--
-- ---------------------------------------------------------------------------
-- THE AUDIT THAT SCOPED THIS MIGRATION (owner requirement 4)
-- ---------------------------------------------------------------------------
-- Every write the platform modules make was enumerated and classified:
--     platform.controller.ts:588  this.prisma.subscription.upsert   (updatePlan)
--     platform.controller.ts:770  tx.subscription.update            (extendTrial)
--     platform.controller.ts:872  tx.subscription.upsert            (grantSubscription)
--     raw SQL writes to a tenant table: NONE (the only $executeRaw calls are the two
--       pg_advisory_xact_lock statements added by R4.11, which write nothing)
--     writes to non-RLS tables (Gym, PlatformAdmin, PlatformSession, PlatformAuditLog,
--       PlatformAlert, PlatformAdminDevice, PlatformLoginAttempt, flags, shield): 28, and
--       all of them are platform-owned tables with no row-level security, so they are
--       unaffected.
-- So exactly three sites, all Subscription, all covered by this one function. There is no
-- other platform write path with this defect.
--
-- ---------------------------------------------------------------------------
-- ONE DEVIATION FROM THE R2 CONVENTION, STATED RATHER THAN BURIED
-- ---------------------------------------------------------------------------
-- The owner's decision was "follow the R2 convention exactly: owner-owned, LANGUAGE sql,
-- SECURITY DEFINER, search_path=pg_catalog,public, typed params, no dynamic SQL, EXECUTE
-- revoked from PUBLIC and granted only to flexora_app" AND "validate inside the function,
-- not only in the api ... raise a clear error otherwise".
--
-- Those two cannot both hold. A LANGUAGE sql function has no RAISE statement, so it cannot
-- produce a clear error: the only ways to fail from pure SQL are a cast error (which does
-- work for the enum parameters, and is used below) or an arithmetic trick like dividing by
-- zero, whose message is "division by zero" and tells an operator nothing. This function is
-- therefore LANGUAGE plpgsql.
--
-- Every OTHER element of the convention is preserved exactly: owner-owned, SECURITY
-- DEFINER, `SET search_path = pg_catalog, public`, typed parameters only, no dynamic SQL and
-- no EXECUTE of a built string anywhere, EXECUTE revoked from PUBLIC and granted only to the
-- runtime role. Volatility is VOLATILE rather than STABLE because it writes; that is the
-- honest label and it also prevents the planner from folding or caching a call.
--
-- ---------------------------------------------------------------------------
-- WHAT IT MAY AND MAY NOT DO
-- ---------------------------------------------------------------------------
-- It writes FOUR columns of ONE row, identified by gym id: tier, status, currentPeriodEnd,
-- trialEndDate. A NULL parameter means "leave this column alone", which is what lets one
-- function serve a plan change (tier only), a grant (tier, status, period end) and a trial
-- extension (status, trial end) without three separate privileges.
--
-- It cannot reach Member, Payment, Transaction, User, Plan, Branch, Attendance or Invoice.
-- It cannot delete anything. It cannot change a gym's status. It cannot read a subscription
-- it is not writing. There is no parameter through which a caller can widen any of that,
-- because there is no dynamic SQL: the statement is written here, at migration time.
--
-- It validates, and raises a distinct SQLSTATE and message for each failure, so an operator
-- reading a log can tell a missing gym from a soft-deleted one from a bad tier:
--   * the gym must exist                       -> 'P4GYM'  gym not found
--   * the gym must not be soft-deleted (Q1)    -> 'P4DEL'  gym is deleted
--   * tier must be a real SubscriptionTier     -> enum cast error from PostgreSQL itself
--   * status must be a real SubscriptionStatus -> enum cast error from PostgreSQL itself
--   * the period end must be after the period
--     start it will sit against                -> 'P4END'  period end is not after start
--   * at least one column must be requested    -> 'P4NOOP' nothing to change
-- The two enum checks use the database's OWN enum types by casting, so they cannot drift
-- from the schema the way a hand-written IN list would.
--
-- It returns the row it wrote. That is not a convenience: R4.11 requires the date the
-- administrator confirmed to be the date that lands, and returning the stored value lets the
-- api put the DATABASE's answer into the audit row instead of the value it intended to write.
-- ===========================================================================

BEGIN;

CREATE OR REPLACE FUNCTION public.platform_admin_set_subscription(
  p_gym_id     text,
  p_tier       text,
  p_status     text,
  p_period_end timestamp(3),
  p_trial_end  timestamp(3)
)
RETURNS TABLE (
  subscription_id      text,
  gym_id               text,
  tier                 text,
  status               text,
  current_period_start timestamp(3),
  current_period_end   timestamp(3),
  trial_end_date       timestamp(3)
)
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
DECLARE
  v_gym_status   text;
  v_period_start timestamp(3);
  v_tier         public."SubscriptionTier";
  v_status       public."SubscriptionStatus";
  v_row          public."Subscription"%ROWTYPE;
BEGIN
  -- ORDER OF CHECKS, which a first version got wrong and a psql probe caught: the gym must be
  -- resolved BEFORE the "nothing to change" test. Otherwise a call naming a gym that does not
  -- exist and setting nothing reported P4NOOP, which sends an operator looking at the caller's
  -- parameters instead of at the gym id they actually got wrong. Most specific first.

  -- Validate the enums by casting to the database's own types. A bad value raises here with
  -- PostgreSQL's own message naming the type, and cannot drift from the schema.
  IF p_tier IS NOT NULL THEN
    v_tier := p_tier::public."SubscriptionTier";
  END IF;
  IF p_status IS NOT NULL THEN
    v_status := p_status::public."SubscriptionStatus";
  END IF;

  SELECT g.status::text INTO v_gym_status
    FROM public."Gym" g
   WHERE g.id = p_gym_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'platform_admin_set_subscription: gym % not found', p_gym_id
      USING ERRCODE = 'P4GYM';
  END IF;

  -- Nothing to do is an error, not a no-op: a caller that reached here with every parameter
  -- NULL has a bug, and silently returning the unchanged row would hide it.
  IF p_tier IS NULL AND p_status IS NULL AND p_period_end IS NULL AND p_trial_end IS NULL THEN
    RAISE EXCEPTION 'platform_admin_set_subscription: nothing to change for gym %', p_gym_id
      USING ERRCODE = 'P4NOOP';
  END IF;


  -- PHASE R2 decision Q1: a soft-deleted gym is out of platform commerce. Granting time to a
  -- gym inside the 30-day restore window would be granting time to something the console
  -- reports as deleted, so it is refused here rather than left to the caller to remember.
  IF v_gym_status = 'DELETED' THEN
    RAISE EXCEPTION 'platform_admin_set_subscription: gym % is deleted; restore it first', p_gym_id
      USING ERRCODE = 'P4DEL';
  END IF;

  SELECT s."currentPeriodStart" INTO v_period_start
    FROM public."Subscription" s
   WHERE s."gymId" = p_gym_id;

  -- "end after start": the start the new end will actually sit against, which is the stored
  -- one if there is a row and now() if this call creates it.
  IF p_period_end IS NOT NULL AND p_period_end <= coalesce(v_period_start, now()) THEN
    RAISE EXCEPTION
      'platform_admin_set_subscription: period end % is not after period start % for gym %',
      p_period_end, coalesce(v_period_start, now()), p_gym_id
      USING ERRCODE = 'P4END';
  END IF;

  -- One upsert on the unique gymId key. COALESCE means a NULL parameter leaves the column
  -- alone, and on INSERT the columns that are not being set take the table's own defaults.
  INSERT INTO public."Subscription" AS s
      ("id", "gymId", tier, status, "currentPeriodStart", "currentPeriodEnd",
       "trialEndDate", "createdAt", "updatedAt")
  VALUES
      -- New rows get a UUID. Existing rows keep whatever id they have (a Prisma cuid); the
      -- column is an opaque unique text and nothing in the product parses its format.
      (gen_random_uuid()::text, p_gym_id,
       coalesce(v_tier, 'BASIC'::public."SubscriptionTier"),
       coalesce(v_status, 'TRIALING'::public."SubscriptionStatus"),
       now(),
       coalesce(p_period_end, now() + interval '30 days'),
       p_trial_end, now(), now())
  ON CONFLICT ("gymId") DO UPDATE
     SET tier             = coalesce(v_tier, s.tier),
         status           = coalesce(v_status, s.status),
         "currentPeriodEnd" = coalesce(p_period_end, s."currentPeriodEnd"),
         "trialEndDate"   = coalesce(p_trial_end, s."trialEndDate"),
         "updatedAt"      = now()
  RETURNING * INTO v_row;

  -- Return what is STORED, not what was asked for. R4.11 depends on the difference being
  -- impossible to fake: the api writes this value into the audit row, so the ledger records
  -- the database's answer.
  RETURN QUERY SELECT
    v_row.id,
    v_row."gymId",
    v_row.tier::text,
    v_row.status::text,
    v_row."currentPeriodStart",
    v_row."currentPeriodEnd",
    v_row."trialEndDate";
END;
$fn$;

-- R2 convention, exactly: EXECUTE is not PUBLIC's, and the runtime role is named explicitly.
-- A deployment whose runtime role is not called flexora_app must adjust this GRANT;
-- scripts/check-db-compat.sh exercises the supported owner profiles.
REVOKE ALL ON FUNCTION public.platform_admin_set_subscription(text, text, text, timestamp(3), timestamp(3)) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_admin_set_subscription(text, text, text, timestamp(3), timestamp(3)) TO flexora_app;

COMMIT;
