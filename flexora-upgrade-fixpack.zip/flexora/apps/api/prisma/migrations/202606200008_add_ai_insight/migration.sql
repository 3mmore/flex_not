-- FIX (Task 2, launch-readiness migration-history repair): this migration
-- previously created "AiInsight" with a DIFFERENT shape ("weekOf"/"content")
-- than the one 0013_schema_catchup (an EARLIER migration, position 15,
-- vs. this one at position 24) already creates it with
-- ("kind"/"payload"/"computedAt"/"expiresAt" — the shape that actually
-- matches schema.prisma today). Because `CREATE TABLE IF NOT EXISTS` is a
-- no-op once the table already exists, this file's own CREATE TABLE
-- statement was always a no-op in true sequential migration order — but
-- its unconditional `ALTER TABLE "AiInsight" ADD CONSTRAINT
-- "AiInsight_gymId_fkey" ...` below was NOT guarded the same way, so it
-- fails with "constraint ... already exists" once 0013's own identical FK
-- constraint (added at position 15) is already in place. This was never
-- caught before because `prisma migrate deploy` has never actually
-- succeeded in this project's history (every environment used `prisma db
-- push` instead, which doesn't replay migration SQL at all — see
-- 0015_missing_table_creates/migration.sql's header comment for the full
-- investigation). Fixed by wrapping the ADD CONSTRAINT in the same
-- idempotent DO $$ ... EXCEPTION WHEN duplicate_object THEN null; END $$;
-- pattern already used throughout this migration history (e.g.
-- 0009_p0_production_closure/migration.sql's CREATE TYPE statements).
CREATE TABLE IF NOT EXISTS "AiInsight" (
  "id"        TEXT NOT NULL DEFAULT gen_random_uuid(),
  "gymId"     TEXT NOT NULL,
  "weekOf"    TIMESTAMP(3) NOT NULL,
  "content"   TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AiInsight_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "AiInsight_gymId_idx"
  ON "AiInsight"("gymId");

DO $$ BEGIN
  ALTER TABLE "AiInsight"
    ADD CONSTRAINT "AiInsight_gymId_fkey"
    FOREIGN KEY ("gymId")
    REFERENCES "Gym"("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;

