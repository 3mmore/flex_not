-- ===========================================================================
-- PHASE R2 (privacy / least privilege): the console's cross-tenant reads become
-- SECURITY DEFINER functions that can only return gym-level fields and
-- aggregates, and the owner's name and phone - never a member row, never a
-- staff credential, never the gym's tax number.
--
-- WHY (measured, work/r2-evidence/00-before.log):
--   B2  Member, User, Branch, Subscription, Payment, Transaction, Plan all carry
--       FORCE ROW LEVEL SECURITY and are owned by `flexora`.
--   B3  As the runtime role flexora_app (rolsuper=f, rolbypassrls=f) those tables
--       read as ZERO rows, while Gym, PlatformAdmin and PlatformAuditLog (no RLS)
--       read normally. So before R2 the console's gym list, gym detail and
--       subscription list returned empty arrays in the posture the product
--       documents as correct - and the moment anyone "fixed" that by widening the
--       api's database rights, `include: { users: true }` would have returned
--       every scalar of every staff row: passwordHash, pinHash, twoFaSecret,
--       twoFaBackupCodes and twoFaLastCode included.
--   R1 section 7 of 20261106000000_platform_auth_r1 deferred exactly these three
--       reads to R2 for this reason: writing a function around the old shape would
--       have frozen the PII.
--
-- CONVENTIONS (identical to 20261106000000_platform_auth_r1, which copied
-- 202607070001_preauth_lookup_function and 202607160001_restrict_preauth_functions):
--   * SECURITY DEFINER, owned by whoever runs `prisma migrate deploy` - never the
--     runtime role.
--   * SET search_path = pg_catalog, public, and every object schema-qualified.
--   * TYPED PARAMETERS ONLY. No dynamic SQL anywhere in this file: no EXECUTE, no
--     format(), no string-built predicate. Optional filters are expressed as
--     `p_x IS NULL OR column = p_x`, which the planner handles as a parameter.
--   * Aggregates and gym-level fields only. No member column is selected by any
--     function here, and the only person-level fields are the gym OWNER's name and
--     phone, which the brief allows and decision Q2 (option c) bounds.
--   * EXECUTE revoked from PUBLIC and granted only to the runtime role.
--   * Prisma maps DateTime to timestamp(3), not timestamptz, so every timestamp
--     column and parameter here is timestamp(3): a timestamptz would be converted
--     through the session TimeZone and silently shift the value.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. The gym list. Replaces
--      prisma.gym.findMany({ include: { subscription: true, users: { take: 1 },
--                                       _count: { select: { members: true } } } })
--    Differences, all deliberate:
--      * `users: { take: 1 }` picked an ARBITRARY staff row and returned every
--        scalar of it. This returns the OWNER's name and phone and nothing else.
--      * taxId, waBotToken, waBotPhoneId, waBotEnabled, waBotGreeting,
--        waBotLanguage, theme, managersMayChangeIntegrations, faviconUrl,
--        appNameOverride, loginBackgroundUrl, secondaryColor and accent are not
--        selected: the platform console has no use for a gym's tax number, its
--        WhatsApp credentials or its branding internals (decision Q2 = option c).
--      * DELETED gyms are excluded unless p_status asks for them (decision Q1).
--      * The search still matches name, email AND slug: today's listGyms searches name
--        and email, and silently dropping one would remove a capability (rule 0.1).
--      * Member, User and Branch appear only as COUNT(*) aggregates.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.platform_list_gyms(
  p_status text,
  p_search text,
  p_tier   text,
  p_limit  integer,
  p_offset integer
)
RETURNS TABLE (
  gym_id              text,
  gym_name            text,
  gym_slug            text,
  gym_status          text,
  gym_email           text,
  gym_phone           text,
  gym_address         text,
  gym_logo            text,
  gym_accent_color    text,
  member_count        integer,
  user_count          integer,
  branch_count        integer,
  owner_name          text,
  owner_phone         text,
  sub_tier            text,
  subscription_status text,
  current_period_start timestamp(3),
  current_period_end  timestamp(3),
  trial_start_date    timestamp(3),
  trial_end_date      timestamp(3),
  trial_days          integer,
  is_trial_used       boolean,
  cancel_at_period_end boolean,
  last_payment_at     timestamp(3),
  last_payment_amount integer,
  created_at          timestamp(3),
  updated_at          timestamp(3),
  deleted_at          timestamp(3)
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT g.id,
         g.name,
         g.slug,
         g.status::text,
         g.email,
         g.phone,
         g.address,
         g.logo,
         g."accentColor",
         (SELECT COUNT(*)::integer FROM public."Member" m  WHERE m."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."User"   u  WHERE u."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."Branch" b  WHERE b."gymId" = g.id),
         o.name,
         o.phone,
         s.tier::text,
         s.status::text,
         s."currentPeriodStart",
         s."currentPeriodEnd",
         s."trialStartDate",
         s."trialEndDate",
         s."trialDays",
         s."isTrialUsed",
         s."cancelAtPeriodEnd",
         s."lastPaymentAt",
         s."lastPaymentAmount",
         g."createdAt",
         g."updatedAt",
         g."deletedAt"
    FROM public."Gym" g
    LEFT JOIN LATERAL (
           SELECT u.name, u.phone
             FROM public."User" u
            WHERE u."gymId" = g.id
              AND u.role = 'OWNER'
            ORDER BY u."createdAt" ASC
            LIMIT 1
         ) o ON true
    LEFT JOIN public."Subscription" s ON s."gymId" = g.id
   WHERE (p_status IS NULL OR g.status::text = p_status)
     -- decision Q1: a DELETED gym leaves the default list but stays reachable by
     -- an explicit status filter, so the console can still restore it.
     AND (p_status IS NOT NULL OR g.status::text <> 'DELETED')
     -- the `plan` query parameter, filtered here rather than in JS after pagination
     AND (p_tier IS NULL OR s.tier::text = p_tier)
     AND (p_search IS NULL
          OR g.name  ILIKE '%' || p_search || '%'
          OR g.slug  ILIKE '%' || p_search || '%'
          OR g.email ILIKE '%' || p_search || '%')
   ORDER BY g."createdAt" DESC
   LIMIT p_limit OFFSET p_offset;
$fn$;

-- The matching total for server-side pagination. Same predicates, so the count and
-- the page can never disagree.
CREATE OR REPLACE FUNCTION public.platform_count_gyms(p_status text, p_search text, p_tier text)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COUNT(*)::bigint
    FROM public."Gym" g
    LEFT JOIN public."Subscription" s ON s."gymId" = g.id
   WHERE (p_status IS NULL OR g.status::text = p_status)
     AND (p_status IS NOT NULL OR g.status::text <> 'DELETED')
     AND (p_tier IS NULL OR s.tier::text = p_tier)
     AND (p_search IS NULL
          OR g.name  ILIKE '%' || p_search || '%'
          OR g.slug  ILIKE '%' || p_search || '%'
          OR g.email ILIKE '%' || p_search || '%');
$fn$;

-- ---------------------------------------------------------------------------
-- 2. One gym. Replaces
--      prisma.gym.findUnique({ include: { users: true, subscription: true,
--                                          _count: { members, users, branches } } })
--    `users: true` was the worst of the three: every staff row of the gym with
--    every scalar, password hash and TOTP secret included. No status filter here,
--    so a DELETED gym is still readable - the console must be able to show it in
--    order to restore it or to purge it.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.platform_gym_detail(p_gym_id text)
RETURNS TABLE (
  gym_id              text,
  gym_name            text,
  gym_slug            text,
  gym_status          text,
  gym_email           text,
  gym_phone           text,
  gym_address         text,
  gym_logo            text,
  gym_accent_color    text,
  member_count        integer,
  user_count          integer,
  branch_count        integer,
  owner_name          text,
  owner_phone         text,
  sub_tier            text,
  subscription_status text,
  current_period_start timestamp(3),
  current_period_end  timestamp(3),
  trial_start_date    timestamp(3),
  trial_end_date      timestamp(3),
  trial_days          integer,
  is_trial_used       boolean,
  cancel_at_period_end boolean,
  last_payment_at     timestamp(3),
  last_payment_amount integer,
  created_at          timestamp(3),
  updated_at          timestamp(3),
  deleted_at          timestamp(3)
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT g.id,
         g.name,
         g.slug,
         g.status::text,
         g.email,
         g.phone,
         g.address,
         g.logo,
         g."accentColor",
         (SELECT COUNT(*)::integer FROM public."Member" m  WHERE m."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."User"   u  WHERE u."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."Branch" b  WHERE b."gymId" = g.id),
         o.name,
         o.phone,
         s.tier::text,
         s.status::text,
         s."currentPeriodStart",
         s."currentPeriodEnd",
         s."trialStartDate",
         s."trialEndDate",
         s."trialDays",
         s."isTrialUsed",
         s."cancelAtPeriodEnd",
         s."lastPaymentAt",
         s."lastPaymentAmount",
         g."createdAt",
         g."updatedAt",
         g."deletedAt"
    FROM public."Gym" g
    LEFT JOIN LATERAL (
           SELECT u.name, u.phone
             FROM public."User" u
            WHERE u."gymId" = g.id
              AND u.role = 'OWNER'
            ORDER BY u."createdAt" ASC
            LIMIT 1
         ) o ON true
    LEFT JOIN public."Subscription" s ON s."gymId" = g.id
   WHERE g.id = p_gym_id;
$fn$;

-- ---------------------------------------------------------------------------
-- 3. The subscription list. Replaces
--      prisma.subscription.findMany({ include: { gym: true } })
--    `gym: true` embedded the WHOLE gym row, waBotToken and taxId included. Only
--    the four gym identity fields the console needs to label a row are returned,
--    and the stripe identifiers are not: they are third-party account handles the
--    platform console has no use for.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.platform_list_subscriptions(
  p_status text,
  p_tier   text,
  p_limit  integer,
  p_offset integer
)
RETURNS TABLE (
  subscription_id      text,
  gym_id               text,
  gym_name             text,
  gym_slug             text,
  gym_status           text,
  sub_tier             text,
  subscription_status  text,
  current_period_start timestamp(3),
  current_period_end   timestamp(3),
  trial_start_date     timestamp(3),
  trial_end_date       timestamp(3),
  trial_days           integer,
  is_trial_used        boolean,
  suspended_at         timestamp(3),
  cancelled_at         timestamp(3),
  grace_days           integer,
  cancel_at_period_end boolean,
  last_payment_at      timestamp(3),
  last_payment_amount  integer,
  created_at           timestamp(3),
  updated_at           timestamp(3)
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT s.id,
         s."gymId",
         g.name,
         g.slug,
         g.status::text,
         s.tier::text,
         s.status::text,
         s."currentPeriodStart",
         s."currentPeriodEnd",
         s."trialStartDate",
         s."trialEndDate",
         s."trialDays",
         s."isTrialUsed",
         s."suspendedAt",
         s."cancelledAt",
         s."graceDays",
         s."cancelAtPeriodEnd",
         s."lastPaymentAt",
         s."lastPaymentAmount",
         s."createdAt",
         s."updatedAt"
    FROM public."Subscription" s
    JOIN public."Gym" g ON g.id = s."gymId"
   WHERE (p_status IS NULL OR s.status::text = p_status)
     AND (p_tier   IS NULL OR s.tier::text   = p_tier)
     -- a subscription of a DELETED gym is not live platform revenue
     AND g.status::text <> 'DELETED'
   ORDER BY s."updatedAt" DESC
   LIMIT p_limit OFFSET p_offset;
$fn$;

CREATE OR REPLACE FUNCTION public.platform_count_subscriptions(p_status text, p_tier text)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COUNT(*)::bigint
    FROM public."Subscription" s
    JOIN public."Gym" g ON g.id = s."gymId"
   WHERE (p_status IS NULL OR s.status::text = p_status)
     AND (p_tier   IS NULL OR s.tier::text   = p_tier)
     AND g.status::text <> 'DELETED';
$fn$;

-- ---------------------------------------------------------------------------
-- 4. Least privilege: EXECUTE for the runtime role only, nothing for PUBLIC.
--    The runtime role name is written out explicitly, exactly as
--    20261106000000_platform_auth_r1 and 202607160001_restrict_preauth_functions
--    do. A deployment whose runtime role is not named flexora_app must adjust
--    these GRANTs; scripts/check-db-compat.sh exercises the supported owner
--    profiles and is re-run for this migration.
-- ---------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_count_gyms(text, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_gym_detail(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_list_subscriptions(text, text, integer, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_count_subscriptions(text, text) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_count_gyms(text, text, text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_gym_detail(text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_list_subscriptions(text, text, integer, integer) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_count_subscriptions(text, text) TO flexora_app;

-- ---------------------------------------------------------------------------
-- 5. Decision Q6: a soft-deleted gym is not live platform activity, so the R1
--    aggregates stop counting it. Each function below is CREATE OR REPLACE'd with
--    the SAME signature, the SAME conventions and the SAME result type as
--    20261106000000_platform_auth_r1 created it with - the only change is a join to
--    public."Gym" that excludes status = 'DELETED'. No caller and no Prisma binding
--    changes. platform_sum_transaction_income_for_gym(text) is deliberately NOT
--    touched: it is already scoped to one gym, and the caller decides.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.platform_count_members()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COUNT(*)::bigint
    FROM public."Member" m
    JOIN public."Gym" g ON g.id = m."gymId"
   WHERE g.status::text <> 'DELETED';
$fn$;

CREATE OR REPLACE FUNCTION public.platform_list_recent_subscriptions(p_limit integer)
RETURNS TABLE (
  id                  text,
  gym_id              text,
  tier                text,
  status              text,
  last_payment_at     timestamp(3),
  last_payment_amount integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT s.id::text,
         s."gymId"::text,
         s.tier::text,
         s.status::text,
         s."lastPaymentAt",
         s."lastPaymentAmount"
  FROM public."Subscription" s
  JOIN public."Gym" g ON g.id = s."gymId"
  WHERE g.status::text <> 'DELETED'
  LIMIT LEAST(GREATEST(p_limit, 1), 50);
$fn$;

CREATE OR REPLACE FUNCTION public.platform_sum_subscription_revenue_since(p_since timestamp(3))
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COALESCE(SUM(s."lastPaymentAmount"), 0)::bigint
  FROM public."Subscription" s
  JOIN public."Gym" g ON g.id = s."gymId"
  WHERE s."lastPaymentAt" >= p_since
    AND g.status::text <> 'DELETED';
$fn$;

CREATE OR REPLACE FUNCTION public.platform_sum_subscription_revenue_between(
  p_since timestamp(3),
  p_until timestamp(3)
)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COALESCE(SUM(s."lastPaymentAmount"), 0)::bigint
  FROM public."Subscription" s
  JOIN public."Gym" g ON g.id = s."gymId"
  WHERE s."lastPaymentAt" >= p_since
    AND s."lastPaymentAt" <  p_until
    AND g.status::text <> 'DELETED';
$fn$;

CREATE OR REPLACE FUNCTION public.platform_subscription_payments_since(
  p_since timestamp(3),
  p_limit integer
)
RETURNS TABLE (
  last_payment_at     timestamp(3),
  last_payment_amount integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT s."lastPaymentAt", s."lastPaymentAmount"
  FROM public."Subscription" s
  JOIN public."Gym" g ON g.id = s."gymId"
  WHERE s."lastPaymentAt" >= p_since
    AND g.status::text <> 'DELETED'
  ORDER BY s."lastPaymentAt" DESC
  LIMIT LEAST(GREATEST(p_limit, 1), 5000);
$fn$;

-- The four replacements keep the R1 grants: REVOKE from PUBLIC again (a CREATE OR
-- REPLACE preserves the ACL, but stating it makes the intent auditable in this file).
REVOKE ALL ON FUNCTION public.platform_count_members() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_list_recent_subscriptions(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_sum_subscription_revenue_since(timestamp(3)) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_sum_subscription_revenue_between(timestamp(3), timestamp(3)) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_subscription_payments_since(timestamp(3), integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_count_members() TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_list_recent_subscriptions(integer) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_sum_subscription_revenue_since(timestamp(3)) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_sum_subscription_revenue_between(timestamp(3), timestamp(3)) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_subscription_payments_since(timestamp(3), integer) TO flexora_app;
