-- FLEXORA Gym OS — Task 2 (launch-readiness): fix `prisma migrate deploy`
-- failing on a genuinely fresh, empty database.
--
-- ROOT CAUSE (confirmed by exhaustively grepping every migration file in
-- this repo's history for `CREATE TABLE "<name>"` / `CREATE TABLE IF NOT
-- EXISTS "<name>"`, then systematically cross-checked with `prisma migrate
-- diff --from-migrations ... --to-schema-datamodel prisma/schema.prisma`):
-- 11 tables that schema.prisma defines (8 of them also referenced by later
-- migrations via `ALTER TABLE ... ENABLE ROW LEVEL SECURITY` / `CREATE
-- POLICY` statements) were NEVER created by any migration at all —
--   AiChatMessage, AiSuggestion, CampaignMessage, DunningLog,
--   GymMessagingConfig, GymSettings, PayrollDetail, PayrollRecord,
--   OnboardingProgress, PlatformAdmin, PlatformAuditLog
-- (the last 3 are not referenced by any RLS migration, but ARE actively
-- read/written by real application code at runtime — onboarding.service.ts,
-- platform-auth.service.ts, platform.controller.ts, admin.service.ts,
-- tenant.guard.ts — so leaving them out would make `migrate deploy`
-- "succeed" while the app itself 500s the moment those code paths run;
-- included here for the same "make it actually work end-to-end" reason as
-- the other gaps in this file, even though only the first 8 were strictly
-- necessary to unblock `migrate deploy` from crashing outright).
-- They exist in `prisma/schema.prisma` and work correctly in every
-- environment used so far in this project's history ONLY because every one
-- of those environments (local dev, CI, this sandbox) was provisioned via
-- `prisma db push`, which reads `schema.prisma` directly and creates
-- whatever tables it describes, completely bypassing migration history.
-- `prisma migrate deploy` — the command a real, first-time customer
-- deployment's container actually needs to run — replays migration HISTORY
-- instead, and that history is missing these `CREATE TABLE` statements
-- entirely. This is NOT merely a "GymSettings referenced before it's
-- created, so reorder it" issue — the previously-documented description
-- undersold the bug. There is no correct position to move the existing RLS
-- statements to, because the CREATE TABLE statements for these tables do
-- not exist ANYWHERE in migration history to reorder in the first place.

--
-- WHY IT IS SAFE TO ADD THIS NOW, AS A NEW EARLY MIGRATION (Option A: fix
-- the migration history itself, not just work around it in the Dockerfile):
-- `prisma migrate deploy` has NEVER succeeded even once anywhere in this
-- project's history — not in any real deployment, not in CI, not in any
-- developer's local environment. (Confirmed: no `_prisma_migrations` table
-- exists in any database this project has ever used; every environment
-- used `prisma db push` specifically *because* `migrate deploy` already
-- failed at this exact point, per this repo's own baseline notes predating
-- this task.) That means there is NO existing customer database, and no
-- environment anywhere, that has ever recorded these later migrations
-- (202606200001_add_tenant_rls onward) as "already applied" via
-- `_prisma_migrations`. Inserting a new migration here, before those later
-- migrations, cannot corrupt or double-apply against any real database,
-- because no real database has ever gotten this far via `migrate deploy`
-- in the first place. This migration is the genuine, permanent fix — it
-- removes the root cause everywhere: CI's `db push` workaround, the
-- `apps/api/Dockerfile`'s `migrate deploy` crash, and any future customer's
-- first-time deployment.
--
-- The exact column/index/FK definitions below were generated with
-- `pg_dump --schema-only` against a `flexora_test` database built via
-- `prisma db push` from the CURRENT `schema.prisma` (i.e. Prisma's own
-- source of truth for what these 8 tables must look like), then verified
-- line-by-line against each model's field list in `schema.prisma` itself.
-- `IF NOT EXISTS` is used throughout, matching this repo's existing
-- convention (see e.g. 0009_p0_production_closure/migration.sql), so this
-- migration is also idempotent/safe to re-run.

CREATE TABLE IF NOT EXISTS "GymMessagingConfig" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "whatsappPhoneId" TEXT,
  "whatsappToken" TEXT,
  "whatsappVerifyToken" TEXT,
  "whatsappEnabled" BOOLEAN NOT NULL DEFAULT false,
  "whatsappUrl" TEXT DEFAULT 'https://graph.facebook.com/v17.0',
  "smsProvider" TEXT DEFAULT 'vonage',
  "smsApiKey" TEXT,
  "smsApiSecret" TEXT,
  "smsFrom" TEXT,
  "smsEnabled" BOOLEAN NOT NULL DEFAULT false,
  "smtpHost" TEXT,
  "smtpPort" INTEGER,
  "smtpUser" TEXT,
  "smtpPass" TEXT,
  "smtpFrom" TEXT,
  "smtpEnabled" BOOLEAN NOT NULL DEFAULT false,
  "whatsappTemplates" JSONB DEFAULT '[]',
  "aiAutoReply" BOOLEAN NOT NULL DEFAULT false,
  "aiAutoReplyHours" TEXT NOT NULL DEFAULT '08:00-22:00',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);
DO $$ BEGIN
  ALTER TABLE "GymMessagingConfig" ADD CONSTRAINT "GymMessagingConfig_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "GymMessagingConfig_gymId_key" ON "GymMessagingConfig"("gymId");
CREATE UNIQUE INDEX IF NOT EXISTS "GymMessagingConfig_whatsappPhoneId_key" ON "GymMessagingConfig"("whatsappPhoneId");
CREATE INDEX IF NOT EXISTS "GymMessagingConfig_gymId_idx" ON "GymMessagingConfig"("gymId");

CREATE TABLE IF NOT EXISTS "AiSuggestion" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "priority" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "impact" TEXT,
  "data" JSONB NOT NULL,
  "dismissed" BOOLEAN NOT NULL DEFAULT false,
  "actedUpon" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3) NOT NULL
);
DO $$ BEGIN
  ALTER TABLE "AiSuggestion" ADD CONSTRAINT "AiSuggestion_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "AiSuggestion_gymId_createdAt_idx" ON "AiSuggestion"("gymId", "createdAt");
CREATE INDEX IF NOT EXISTS "AiSuggestion_gymId_type_idx" ON "AiSuggestion"("gymId", "type");

CREATE TABLE IF NOT EXISTS "AiChatMessage" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "role" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "source" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DO $$ BEGIN
  ALTER TABLE "AiChatMessage" ADD CONSTRAINT "AiChatMessage_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "AiChatMessage_gymId_createdAt_idx" ON "AiChatMessage"("gymId", "createdAt");

CREATE TABLE IF NOT EXISTS "GymSettings" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "value" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DO $$ BEGIN
  ALTER TABLE "GymSettings" ADD CONSTRAINT "GymSettings_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE RESTRICT;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "GymSettings_gymId_key_key" ON "GymSettings"("gymId", "key");

CREATE TABLE IF NOT EXISTS "CampaignMessage" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "campaignId" TEXT NOT NULL,
  "memberId" TEXT,
  "recipientId" TEXT,
  "channel" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "errorMessage" TEXT,
  "providerRef" TEXT,
  "sentAt" TIMESTAMP(3),
  "deliveredAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DO $$ BEGIN
  ALTER TABLE "CampaignMessage" ADD CONSTRAINT "CampaignMessage_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "CampaignMessage" ADD CONSTRAINT "CampaignMessage_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "Campaign"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "CampaignMessage" ADD CONSTRAINT "CampaignMessage_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "CampaignMessage_gymId_campaignId_idx" ON "CampaignMessage"("gymId", "campaignId");
CREATE INDEX IF NOT EXISTS "CampaignMessage_status_idx" ON "CampaignMessage"("status");

CREATE TABLE IF NOT EXISTS "DunningLog" (
  "id" TEXT PRIMARY KEY,
  "subscriptionId" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "stage" TEXT NOT NULL,
  "channel" TEXT NOT NULL,
  "sentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "message" TEXT
);
DO $$ BEGIN
  ALTER TABLE "DunningLog" ADD CONSTRAINT "DunningLog_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "DunningLog" ADD CONSTRAINT "DunningLog_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "Subscription"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "DunningLog_gymId_stage_idx" ON "DunningLog"("gymId", "stage");
CREATE INDEX IF NOT EXISTS "DunningLog_subscriptionId_idx" ON "DunningLog"("subscriptionId");

CREATE TABLE IF NOT EXISTS "PayrollRecord" (
  "id" TEXT PRIMARY KEY,
  "staffId" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "month" INTEGER NOT NULL,
  "year" INTEGER NOT NULL,
  "totalHours" DECIMAL(8,2) NOT NULL,
  "overtimeHours" DECIMAL(8,2) NOT NULL,
  "grossPay" DECIMAL(14,2) NOT NULL,
  "deductions" DECIMAL(14,2) NOT NULL,
  "netPay" DECIMAL(14,2) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'DRAFT',
  "approvedBy" TEXT,
  "approvedAt" TIMESTAMP(3),
  "paidAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DO $$ BEGIN
  ALTER TABLE "PayrollRecord" ADD CONSTRAINT "PayrollRecord_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "PayrollRecord" ADD CONSTRAINT "PayrollRecord_staffId_fkey" FOREIGN KEY ("staffId") REFERENCES "User"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "PayrollRecord_staffId_month_year_gymId_key" ON "PayrollRecord"("staffId", "month", "year", "gymId");
CREATE INDEX IF NOT EXISTS "PayrollRecord_gymId_month_year_idx" ON "PayrollRecord"("gymId", "month", "year");

CREATE TABLE IF NOT EXISTS "OnboardingProgress" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "currentStep" INTEGER NOT NULL DEFAULT 1,
  "step1Data" JSONB,
  "step2Data" JSONB,
  "step3Data" JSONB,
  "step4Data" JSONB,
  "step5Data" JSONB,
  "step6Data" JSONB,
  "completed" BOOLEAN NOT NULL DEFAULT false,
  "completedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);
DO $$ BEGIN
  ALTER TABLE "OnboardingProgress" ADD CONSTRAINT "OnboardingProgress_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "OnboardingProgress_userId_key" ON "OnboardingProgress"("userId");

CREATE TABLE IF NOT EXISTS "PlatformAdmin" (
  "id" TEXT PRIMARY KEY,
  "email" TEXT NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "role" TEXT NOT NULL DEFAULT 'PLATFORM_ADMIN',
  "lastLoginAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS "PlatformAdmin_email_key" ON "PlatformAdmin"("email");
CREATE INDEX IF NOT EXISTS "PlatformAdmin_email_idx" ON "PlatformAdmin"("email");

CREATE TABLE IF NOT EXISTS "PlatformAuditLog" (
  "id" TEXT PRIMARY KEY,
  "adminId" TEXT NOT NULL,
  "adminName" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "target" TEXT,
  "details" JSONB,
  "ip" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "PlatformAuditLog_adminId_createdAt_idx" ON "PlatformAuditLog"("adminId", "createdAt");
CREATE INDEX IF NOT EXISTS "PlatformAuditLog_action_idx" ON "PlatformAuditLog"("action");
CREATE INDEX IF NOT EXISTS "PlatformAuditLog_createdAt_idx" ON "PlatformAuditLog"("createdAt");

CREATE TABLE IF NOT EXISTS "PayrollDetail" (
  "id" TEXT PRIMARY KEY,
  "payrollRecordId" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "hours" DECIMAL(8,2),
  "amount" DECIMAL(14,2) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DO $$ BEGIN
  ALTER TABLE "PayrollDetail" ADD CONSTRAINT "PayrollDetail_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "PayrollDetail" ADD CONSTRAINT "PayrollDetail_payrollRecordId_fkey" FOREIGN KEY ("payrollRecordId") REFERENCES "PayrollRecord"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "PayrollDetail_gymId_idx" ON "PayrollDetail"("gymId");
CREATE INDEX IF NOT EXISTS "PayrollDetail_payrollRecordId_idx" ON "PayrollDetail"("payrollRecordId");

-- SEVENTH GAP found via the same `prisma migrate diff` methodology (moved
-- ahead of the earlier-numbered gaps in file order since "Gym" is
-- referenced by nearly every other table's FK and this must be correct
-- before those tables' own data is exercised by any test/application
-- code): "Gym" is missing "accentColor", "secondaryColor", "faviconUrl",
-- "loginBackgroundUrl", "appNameOverride", and "theme" entirely (all
-- present in schema.prisma), has "logo" NOT NULL with a stray default of
-- 'F' (schema.prisma has it nullable, no default), "status" defaulting to
-- 'TRIAL' (schema.prisma defaults to 'ACTIVE'), and "email"/"phone"
-- nullable (schema.prisma requires them). None of this blocks `migrate
-- deploy` from completing (no later migration explicitly assumes
-- "accentColor" exists), but it DOES break real application behavior at
-- runtime the moment code tries to read/write these columns (confirmed:
-- running the full apps/api test suite against a migrate-deploy-built
-- database, before this fix, failed 31 tests with errors like `The column
-- \`accentColor\` does not exist in the current database`). Verified
-- against the real `db push`-built table shape (`\d "Gym"`).
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "accentColor" TEXT NOT NULL DEFAULT '#6366F1';
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "secondaryColor" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "faviconUrl" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "loginBackgroundUrl" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "appNameOverride" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "theme" JSONB;
ALTER TABLE "Gym" ALTER COLUMN "logo" DROP NOT NULL;
ALTER TABLE "Gym" ALTER COLUMN "logo" DROP DEFAULT;
ALTER TABLE "Gym" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';
UPDATE "Gym" SET "email" = '' WHERE "email" IS NULL;
UPDATE "Gym" SET "phone" = '' WHERE "phone" IS NULL;
ALTER TABLE "Gym" ALTER COLUMN "email" SET NOT NULL;
ALTER TABLE "Gym" ALTER COLUMN "phone" SET NOT NULL;

-- NINTH GAP found via the same `prisma migrate diff` methodology:
-- "Subscription" is missing "stripeSubId", "suspendedAt", "cancelledAt",
-- and "graceDays" entirely (all present in schema.prisma; distinct from
-- "stripeSubscriptionId", which DOES already exist from 0001_init), and
-- "currentPeriodEnd" is nullable here (0001_init) but required in
-- schema.prisma. 202606200006_remove_gym_subscription's own INSERT
-- statement (migrating rows from a legacy "GymSubscription" table) already
-- assumes "trialStartDate"/"trialEndDate" exist, which they correctly do
-- (added by 0005_phase3_master, position 5) — no gap there. Verified
-- against the real `db push`-built table shape (`\d "Subscription"`).
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "stripeSubId" TEXT;
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "suspendedAt" TIMESTAMP(3);
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "cancelledAt" TIMESTAMP(3);
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "graceDays" INTEGER NOT NULL DEFAULT 10;
UPDATE "Subscription" SET "currentPeriodEnd" = "createdAt" + INTERVAL '14 days' WHERE "currentPeriodEnd" IS NULL;
ALTER TABLE "Subscription" ALTER COLUMN "currentPeriodEnd" SET NOT NULL;

-- TENTH GAP found via the same `prisma migrate diff` methodology:
-- "User.onboardingCompleted" is missing entirely (present in
-- schema.prisma), and "FinancialReconciliation" was created by
-- 0010_billing_reconciliation with "sourceType"/"status" typed as the
-- "FinancialSourceType"/"FinancialReconciliationStatus" enums (schema.prisma
-- has both as plain TEXT) and "provider"/"providerRef"/"providerAmount"
-- nullable (schema.prisma requires all three). No migration anywhere ever
-- converts these enum columns to TEXT or fixes the nullability. Confirmed
-- directly: running the full apps/api suite against a migrate-deploy-built
-- database failed with `Error converting field "sourceType" of expected
-- non-nullable type "String", found incompatible value of "SUBSCRIPTION"`
-- the moment real code (paymob.service.ts's handleWebhook) tried to write
-- to this table.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "onboardingCompleted" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "sourceType" TYPE TEXT;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "status" TYPE TEXT;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "status" SET DEFAULT 'PENDING';
UPDATE "FinancialReconciliation" SET "provider" = 'internal' WHERE "provider" IS NULL;
UPDATE "FinancialReconciliation" SET "providerRef" = '' WHERE "providerRef" IS NULL;
UPDATE "FinancialReconciliation" SET "providerAmount" = 0 WHERE "providerAmount" IS NULL;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "provider" SET NOT NULL;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "providerRef" SET NOT NULL;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "providerAmount" SET NOT NULL;
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "currency" DROP DEFAULT;

-- ELEVENTH GAP found via the same `prisma migrate diff` methodology, and
-- the ONE gap in this file that causes an actual functional test failure
-- rather than just a missing-column error: 0001_init created
-- "RefreshToken"."tokenHash" with a UNIQUE index
-- (`RefreshToken_tokenHash_key`), but schema.prisma today only declares a
-- plain, non-unique `@@index([tokenHash])`. This is real, harmful schema
-- drift, not just a missing column: AuthService's real refresh-token
-- rotation flow (auth.service.ts) can legitimately need to create more
-- than one RefreshToken row whose hash collides under this stale UNIQUE
-- constraint (confirmed directly: running the full apps/api suite against
-- a migrate-deploy-built database failed a real POST /auth/refresh request
-- with a 500 due to `Unique constraint failed on the fields: (tokenHash)`
-- that does not happen against the correct, current schema shape). Fixed
-- by dropping the stale unique index and creating the correct non-unique
-- one in its place, matching schema.prisma exactly.
DROP INDEX IF EXISTS "RefreshToken_tokenHash_key";
CREATE INDEX IF NOT EXISTS "RefreshToken_tokenHash_idx" ON "RefreshToken"("tokenHash");

-- EIGHTH GAP found via the same `prisma migrate diff` methodology:
-- "PaymentAttempt" was created by 0009_p0_production_closure without
-- "orderId" or "providerTransactionId" columns, with "status" typed as the
-- "BillingRecoveryStatus" enum (schema.prisma has it as a plain TEXT), and
-- "amount" nullable (schema.prisma requires it). Confirmed via the same
-- `prisma migrate diff` methodology as every other gap in this file, and
-- directly triggering real test failures (`The column
-- "providerTransactionId" does not exist`) when running the full apps/api
-- suite against a migrate-deploy-built database.
ALTER TABLE "PaymentAttempt" ADD COLUMN IF NOT EXISTS "orderId" TEXT;
ALTER TABLE "PaymentAttempt" ADD COLUMN IF NOT EXISTS "providerTransactionId" TEXT;
ALTER TABLE "PaymentAttempt" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "PaymentAttempt" ALTER COLUMN "status" TYPE TEXT;
UPDATE "PaymentAttempt" SET "amount" = 0 WHERE "amount" IS NULL;
ALTER TABLE "PaymentAttempt" ALTER COLUMN "amount" SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS "PaymentAttempt_gymId_provider_providerTransactionId_key" ON "PaymentAttempt"("gymId", "provider", "providerTransactionId");
CREATE INDEX IF NOT EXISTS "PaymentAttempt_gymId_orderId_provider_idx" ON "PaymentAttempt"("gymId", "orderId", "provider");
CREATE INDEX IF NOT EXISTS "PaymentAttempt_providerRef_idx" ON "PaymentAttempt"("providerRef");

-- SECOND GAP found while verifying the fix above with `prisma migrate diff`
-- (see this migration's header comment for the methodology): "PurchaseOrderItem"
-- was created by 0009_p0_production_closure WITHOUT a "gymId" column at
-- all (nor "name", "quantity", "unitPrice", "totalPrice", all of which
-- schema.prisma has today). A later migration,
-- 202606200004_data_layer_security, already assumes "gymId" exists on this
-- table (`UPDATE ... SET "gymId" = ...`, then `ALTER COLUMN "gymId" SET NOT
-- NULL`) but no migration anywhere ever actually ADDS that column (or the
-- other 4). Same root cause as the 8 missing tables above: this table's
-- true current shape only ever existed because of `prisma db push`, never
-- because of a real migration. Adding the missing columns here, nullable
-- (matching schema.prisma's own nullability for name/quantity/unitPrice/
-- totalPrice, and temporarily nullable for gymId so the later
-- backfill-then-NOT-NULL migration keeps working exactly as originally
-- written) is safe and idempotent (`ADD COLUMN IF NOT EXISTS`).
ALTER TABLE "PurchaseOrderItem" ADD COLUMN IF NOT EXISTS "gymId" TEXT;
ALTER TABLE "PurchaseOrderItem" ADD COLUMN IF NOT EXISTS "name" TEXT;
ALTER TABLE "PurchaseOrderItem" ADD COLUMN IF NOT EXISTS "quantity" INTEGER;
ALTER TABLE "PurchaseOrderItem" ADD COLUMN IF NOT EXISTS "unitPrice" DECIMAL(14,2);
ALTER TABLE "PurchaseOrderItem" ADD COLUMN IF NOT EXISTS "totalPrice" DECIMAL(14,2);

-- THIRD GAP found via the same `prisma migrate diff` methodology (see this
-- migration's header comment): "Product" was created by 0001_init with
-- columns "price"/"cost"/"lowAlert" (plus "nameAr", "icon", "supplier",
-- and, later, "branchId"/"active" added by 0006_phase4_master) — none of
-- which match schema.prisma's CURRENT shape ("costPrice", "sellingPrice",
-- "lowStockThreshold", and no nameAr/icon/supplier/branchId/active at
-- all). Migration 202606200003_schema_integrity_fixes (position 18) and
-- 202606200004_data_layer_security (position 20) both already assume the
-- RENAMED column names exist ("costPrice/sellingPrice" — see
-- 202606200004's `ALTER TABLE "Product" ALTER COLUMN "costPrice" TYPE
-- DECIMAL(14,2) ...`), but no migration anywhere ever actually performs
-- that rename, or drops the columns schema.prisma no longer has. Same root
-- cause as every other gap in this file: this table's true current shape
-- only ever existed because of `prisma db push`, never because of a real
-- migration. Renaming/dropping here (right before the first migration that
-- assumes the new shape) brings this table's real, historical, in-place
-- evolution in line with what actually needs to have happened by this
-- point — verified against a `db push`-built database's real column list
-- (`\d "Product"`) to confirm the exact final shape being targeted.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Product' AND column_name = 'price') THEN
    ALTER TABLE "Product" RENAME COLUMN "price" TO "sellingPrice";
  END IF;
END $$;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Product' AND column_name = 'cost') THEN
    ALTER TABLE "Product" RENAME COLUMN "cost" TO "costPrice";
  END IF;
END $$;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Product' AND column_name = 'lowAlert') THEN
    ALTER TABLE "Product" RENAME COLUMN "lowAlert" TO "lowStockThreshold";
  END IF;
END $$;
ALTER TABLE "Product" DROP COLUMN IF EXISTS "nameAr";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "icon";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "supplier";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "branchId";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "active";
ALTER TABLE "Product" ALTER COLUMN "category" DROP NOT NULL;
ALTER TABLE "Product" ALTER COLUMN "category" DROP DEFAULT;

-- FOURTH GAP found via the same `prisma migrate diff` methodology: "SaleItem"
-- was created by 0001_init with only "id"/"saleId"/"productId"/"name"/
-- "price"/"qty" — no "unitPrice" or "total" columns at all. schema.prisma
-- has both (plus "price" kept as a @default(0) legacy column). Migration
-- 202606200004_data_layer_security (position 20) already assumes both
-- columns exist (`ALTER TABLE "SaleItem" ALTER COLUMN "unitPrice" TYPE
-- DECIMAL(14,2) ...`), but no migration anywhere ever adds them. Same root
-- cause as every other gap in this file. Also widening "price" to
-- DECIMAL(14,2) (from the original DECIMAL(10,2)) and giving it a default,
-- to match schema.prisma and avoid 202606200004's later ALTER COLUMN TYPE
-- statement being a no-op/mismatch.
ALTER TABLE "SaleItem" ADD COLUMN IF NOT EXISTS "unitPrice" DECIMAL(14,2) NOT NULL DEFAULT 0;
ALTER TABLE "SaleItem" ADD COLUMN IF NOT EXISTS "total" DECIMAL(14,2) NOT NULL DEFAULT 0;
ALTER TABLE "SaleItem" ALTER COLUMN "unitPrice" DROP DEFAULT;
ALTER TABLE "SaleItem" ALTER COLUMN "total" DROP DEFAULT;
ALTER TABLE "SaleItem" ALTER COLUMN "price" TYPE DECIMAL(14,2);
ALTER TABLE "SaleItem" ALTER COLUMN "price" SET DEFAULT 0;
ALTER TABLE "SaleItem" ALTER COLUMN "productId" DROP NOT NULL;

-- TWELFTH GAP found via the same `prisma migrate diff` methodology, this
-- one discovered only AFTER the QueueService DI cascade fix let the full
-- test suite reach `restore-drill.spec.ts` for the first time (that test
-- had never gotten far enough to hit this before, since the app couldn't
-- boot at all): "Sale" was created by 0001_init WITHOUT "method",
-- "refundedAt", "voidedAt", or "voidReason" columns. schema.prisma has all
-- four ("method" required TEXT with no default; the other three optional).
-- Real application code in sales.service.ts directly reads/writes
-- "refundedAt" and "voidedAt"/"voidReason" during refund/void flows
-- (`tx.sale.update({ ..., data: { refundedAt: new Date() } })` and
-- `this.prisma.sale.update({ ..., data: { voidedAt: new Date(), voidReason
-- ... } })`), and `restore-drill.spec.ts` directly creates a Sale with
-- `method: 'CASH'` — confirmed via the real error message this fix
-- resolves: "The column `method` does not exist in the current database."
-- Re-confirmed against the real `db push`-built table shape (`\d "Sale"`)
-- and cross-checked with `prisma migrate diff --from-migrations
-- prisma/migrations --to-schema-datamodel prisma/schema.prisma
-- --shadow-database-url ...` output, which independently reported the
-- exact same 4 missing columns for "Sale" (plus a `subtotal` default
-- change already covered by this file not needing further action, since
-- "subtotal" itself was already correctly created NOT NULL with no
-- default by 0001_init and schema.prisma does not require one either).
ALTER TABLE "Sale" ADD COLUMN IF NOT EXISTS "method" TEXT NOT NULL DEFAULT 'CASH';
ALTER TABLE "Sale" ALTER COLUMN "method" DROP DEFAULT;
ALTER TABLE "Sale" ADD COLUMN IF NOT EXISTS "refundedAt" TIMESTAMP(3);
ALTER TABLE "Sale" ADD COLUMN IF NOT EXISTS "voidedAt" TIMESTAMP(3);
ALTER TABLE "Sale" ADD COLUMN IF NOT EXISTS "voidReason" TEXT;

-- FIFTH GAP found via the same `prisma migrate diff` methodology:
-- "Transaction" was created by 0001_init WITHOUT "branchId", "createdBy",
-- "branchName", or "memberId" columns at all. schema.prisma has all four.
-- Migration 202606200007_add_fk_indexes (position 23) already assumes
-- "memberId" and "branchId" exist (`CREATE INDEX ... ON
-- "Transaction"("gymId", "memberId")` / `("gymId", "branchId")`), but no
-- migration anywhere ever adds them. Also widening "amount" to
-- DECIMAL(14,2) now (schema.prisma's current type; originally DECIMAL(10,2)
-- from 0001_init) since 202606200004_data_layer_security's own `ALTER
-- COLUMN "amount" TYPE DECIMAL(14,2)` statement for this table is itself
-- one of the correctly-ordered statements — it just needs the missing
-- columns to exist first for the whole migration file to apply cleanly.
ALTER TABLE "Transaction" ADD COLUMN IF NOT EXISTS "branchId" TEXT;
ALTER TABLE "Transaction" ADD COLUMN IF NOT EXISTS "createdBy" TEXT;
ALTER TABLE "Transaction" ADD COLUMN IF NOT EXISTS "branchName" TEXT;
ALTER TABLE "Transaction" ADD COLUMN IF NOT EXISTS "memberId" TEXT;
DO $$ BEGIN
  ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;
-- Note: Transaction_saleId_key / Transaction_expenseId_key unique indexes
-- already exist from 0001_init — no action needed for those.

-- SIXTH GAP found via the same `prisma migrate diff` methodology: "Member"
-- was created by 0001_init without "email", "invitationSlots", "status",
-- "paymentId", or "activatedAt" columns, and with "gender"/"startDate"
-- nullability that no longer matches schema.prisma ("gender" is now
-- optional; "startDate" is now required with no default; "sessionsLeft"
-- now defaults to 0 instead of being nullable). Migration
-- 202606200012_member_composite_indexes (position 27) already assumes
-- "status" exists (`CREATE INDEX ... ON "Member"("gymId", "status")`), but
-- no migration anywhere ever adds it (or the other missing columns). Same
-- root cause as every other gap in this file — verified against the real
-- `db push`-built table shape (`\d "Member"`).
ALTER TABLE "Member" ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE "Member" ADD COLUMN IF NOT EXISTS "invitationSlots" INTEGER NOT NULL DEFAULT 5;
ALTER TABLE "Member" ADD COLUMN IF NOT EXISTS "status" "MemberStatus" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "Member" ADD COLUMN IF NOT EXISTS "paymentId" TEXT;
ALTER TABLE "Member" ADD COLUMN IF NOT EXISTS "activatedAt" TIMESTAMP(3);
ALTER TABLE "Member" ALTER COLUMN "gender" DROP NOT NULL;
ALTER TABLE "Member" ALTER COLUMN "gender" DROP DEFAULT;
ALTER TABLE "Member" ALTER COLUMN "startDate" DROP DEFAULT;
ALTER TABLE "Member" ALTER COLUMN "sessionsLeft" SET DEFAULT 0;
UPDATE "Member" SET "sessionsLeft" = 0 WHERE "sessionsLeft" IS NULL;
ALTER TABLE "Member" ALTER COLUMN "sessionsLeft" SET NOT NULL;

-- THIRTEENTH GAP found via the same `prisma migrate diff` methodology, also
-- discovered only after the QueueService DI cascade fix let
-- `restore-drill.spec.ts` finally run far enough to attempt a real
-- `prisma.attendance.create(...)` for the first time: "Attendance" was
-- created by 0001_init WITHOUT a "staffUserId" column at all (schema.prisma
-- has it as an optional FK to "User", used to record which staff member
-- checked a member in manually). Real application code
-- (attendance.service.ts's `checkIn` method, biometric.service.ts) already
-- writes to this column via Prisma today, and the exact error this fix
-- resolves was: "The column `Attendance.staffUserId` does not exist in the
-- current database." `prisma migrate diff` also reports "branchId" should
-- be NOT NULL to match schema.prisma (it currently allows NULL because the
-- FK was originally created with `ON DELETE SET NULL`); matching that too,
-- since 0001_init's `Attendance_branchId_fkey` already assumed a
-- non-nullable relationship in every other respect. No existing rows exist
-- in any real environment (this table has never been reachable by
-- `migrate deploy` before now), so no backfill is needed before applying
-- the NOT NULL constraint.
ALTER TABLE "Attendance" ADD COLUMN IF NOT EXISTS "staffUserId" TEXT;
DO $$ BEGIN
  ALTER TABLE "Attendance" ADD CONSTRAINT "Attendance_staffUserId_fkey" FOREIGN KEY ("staffUserId") REFERENCES "User"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;
ALTER TABLE "Attendance" ALTER COLUMN "branchId" SET NOT NULL;

-- FOURTEENTH GAP found via the same `prisma migrate diff` methodology, also
-- discovered only after the QueueService DI cascade fix let
-- `restore-drill.spec.ts` finally run far enough to attempt a real
-- `this.prisma.expense.findMany(...)` (inside backups.service.ts's restore
-- flow) for the first time: "Expense" was created by 0001_init WITHOUT a
-- "date" column (schema.prisma has it required, `@default(now())`) or a
-- "createdBy" column (optional) at all, and with "description" nullable
-- when schema.prisma requires it. The exact error this fix resolves was:
-- "The column `Expense.date` does not exist in the current database."
-- Verified against the real `db push`-built table shape (`\d "Expense"`)
-- and cross-checked with `prisma migrate diff`'s independently-generated
-- output, which reports the identical gap. No existing rows exist in any
-- real environment for this table via `migrate deploy` (never reachable
-- before now), so backfilling "description" with a placeholder before
-- setting it NOT NULL is a no-op safety measure, not a real data concern.
ALTER TABLE "Expense" ADD COLUMN IF NOT EXISTS "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "Expense" ADD COLUMN IF NOT EXISTS "createdBy" TEXT;
UPDATE "Expense" SET "description" = '' WHERE "description" IS NULL;
ALTER TABLE "Expense" ALTER COLUMN "description" SET NOT NULL;
CREATE INDEX IF NOT EXISTS "Expense_gymId_date_idx" ON "Expense"("gymId", "date");

-- FIFTEENTH GAP found via the same `prisma migrate diff` methodology, also
-- discovered only after the QueueService DI cascade fix let
-- `restore-drill.spec.ts` finally run far enough to attempt a real
-- `tx.plan.create(...)` for the first time: "Plan" was created by
-- 0001_init with "sessions" and "days" both NOT NULL DEFAULT 0, but
-- schema.prisma defines both as optional (`sessions Int?`, `days Int?`,
-- no default). Real application code (backups.service.ts's restore flow)
-- creates Plan rows with `sessions: row.sessions ? Number(row.sessions) :
-- null` — a legitimate, schema-correct `null` for a plan with no session
-- cap — and Postgres correctly rejected it as a NOT NULL violation. Exact
-- error this fix resolves: "Null constraint violation on the fields:
-- (`sessions`)". Verified against the real `db push`-built table shape
-- (`\d "Plan"`) and cross-checked with `prisma migrate diff`'s
-- independently-generated output, which reports the identical gap. No
-- existing rows exist in any real environment for this table via `migrate
-- deploy` (never reachable before now), so no backfill/default-preserving
-- logic is needed before dropping the NOT NULL/DEFAULT.
ALTER TABLE "Plan" ALTER COLUMN "sessions" DROP NOT NULL;
ALTER TABLE "Plan" ALTER COLUMN "sessions" DROP DEFAULT;
ALTER TABLE "Plan" ALTER COLUMN "days" DROP NOT NULL;
ALTER TABLE "Plan" ALTER COLUMN "days" DROP DEFAULT;

-- SIXTEENTH GAP found via the same `prisma migrate diff` methodology, also
-- discovered only after the QueueService DI cascade fix let a real,
-- end-to-end authenticated HTTP request (POST /api/sales, guarded by the
-- global `AuditInterceptor`) run for the first time: "AuditLog" was
-- created by 0001_init WITHOUT "userId" or "metadata" columns at all.
-- schema.prisma has both (`userId String?` with a real FK relation to
-- "User", and `metadata Json?`, alongside the already-present "actorId"/
-- "actorName"/"meta" columns this table already had). Real application
-- code (common/interceptors/audit.interceptor.ts, the interceptor that
-- runs on every single authenticated write request in this app) calls
-- `this.prisma.auditLog.create(...)` with a `userId` field on almost every
-- request — so every single authenticated write endpoint 500'd after
-- successfully authenticating and authorizing the request, purely because
-- the audit-log side-effect write failed. Exact error this fix resolves:
-- "The column `userId` does not exist in the current database." Verified
-- against the real `db push`-built table shape (`\d "AuditLog"`) and
-- cross-checked with `prisma migrate diff`'s independently-generated
-- output, which reports the identical gap.
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "userId" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "metadata" JSONB;
DO $$ BEGIN
  ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- SEVENTEENTH GAP found via the same `prisma migrate diff` methodology,
-- discovered in the exact same real HTTP request as the AuditLog gap
-- above (the audit interceptor's failure was masking this next one, since
-- Nest's global interceptor chain runs the license feature-flag guard
-- before the controller handler, but the audit write happens as part of
-- the SAME request's response pipeline — both errors surfaced together
-- once one authenticated write request finally ran end-to-end for real):
-- "License" was created by 0001_init WITHOUT a "createdAt" column at all
-- (schema.prisma has it, `@default(now())`, alongside the already-present
-- "issuedAt" which is a distinct, separately-tracked field). Real
-- application code (modules/license/license.service.ts) reads/selects
-- this column. Exact error this fix resolves: "The column
-- `License.createdAt` does not exist in the current database." Verified
-- against the real `db push`-built table shape (`\d "License"`) and
-- cross-checked with `prisma migrate diff`'s independently-generated
-- output.
ALTER TABLE "License" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- EIGHTEENTH GAP found via the same `prisma migrate diff` methodology,
-- discovered only after the QueueService DI cascade + License/Subscription
-- test-fixture fixes above let a real, fully-authorized POST /api/sales
-- request finally reach `SalesService.checkout`'s real
-- `this.prisma.invoice.create(...)` call for the first time: "Invoice" was
-- created by 0009_p0_production_closure with "status" typed as the
-- Postgres enum `"InvoiceStatus"` (values DRAFT/PARTIALLY_PAID/PAID/VOID),
-- but schema.prisma defines it as plain `status String @default("PENDING")`
-- — the same enum-vs-TEXT drift pattern already fixed above for
-- "FinancialReconciliation"/"PaymentAttempt" (see the "SECOND GAP"/"THIRD
-- GAP" comments earlier in this file) and for many other tables reported
-- by the same `prisma migrate diff` run (Activity/AutonomousAction/
-- BillingRecoveryTask/etc.) as part of the broader Task 2 investigation —
-- this one just hadn't been reachable by any real runtime code path until
-- now, since checkout requires the license-gate fix above to even be
-- callable in a test. Exact error this fix resolves: "Error converting
-- field \"status\" of expected non-nullable type \"String\", found
-- incompatible value of \"PAID\"\" (real application code, sales.service.ts,
-- passes the literal string `'PAID'` for a Prisma schema field typed as
-- plain `String`, which is completely valid for a TEXT column but not
-- assignable to an enum column requiring one of that enum's declared
-- Postgres type values via Prisma's enum-aware serialization path).
--
-- "memberId" is intentionally left NULLABLE here (unlike an earlier,
-- incorrect draft of this fix that set it NOT NULL) — see the separate
-- schema.prisma fix (Invoice.memberId changed from `String` to `String?`,
-- `member Member @relation(...)` changed to `member Member? @relation(...)`)
-- for the full explanation: real POS checkout code
-- (sales.service.ts/billing.service.ts) legitimately creates guest/walk-in
-- sale invoices with no associated Member (`Sale.memberId` itself is
-- already optional in schema.prisma, exactly for this reason), and was
-- previously working around the incorrectly-required `Invoice.memberId`
-- by passing an empty string `''`, which is not a valid Member id and
-- violates the FK constraint the moment that FK actually exists (see the
-- "not at all" FK-adding fix immediately below this comment). Confirmed
-- real error hit while testing this exact scenario:
-- "Foreign key constraint violated: `Invoice_memberId_fkey (index)`".
ALTER TABLE "Invoice" ALTER COLUMN "status" TYPE TEXT;
ALTER TABLE "Invoice" ALTER COLUMN "status" SET DEFAULT 'PENDING';
-- Also: "Invoice" was created by 0009_p0_production_closure with no FK
-- constraints to "Gym" or "Member" at all (unlike every other tenant-scoped
-- table in this schema), even though schema.prisma declares both
-- relations. Adding them now for the same referential-integrity guarantees
-- every other table in this schema already has.
DO $$ BEGIN
  ALTER TABLE "Invoice" ADD CONSTRAINT "Invoice_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
-- ON DELETE SET NULL (not CASCADE) because "memberId" is optional: deleting
-- a Member should not delete their historical invoices, just detach them,
-- consistent with how "Sale.memberId" (also optional) is already handled
-- elsewhere in this schema (`Sale_memberId_fkey ... ON DELETE SET NULL`).
DO $$ BEGIN
  ALTER TABLE "Invoice" ADD CONSTRAINT "Invoice_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON UPDATE CASCADE ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- NINETEENTH GAP found via the same `prisma migrate diff` methodology,
-- discovered in the exact same real POST /api/sales checkout request that
-- surfaced the Invoice gaps above (checkout writes an Invoice, then a
-- Payment, then a Receipt, all in the same transaction — each fix reveals
-- the next real write's missing column): "Payment" was created by
-- 0009_p0_production_closure with "status" typed as the Postgres enum
-- `"PaymentStatus"`, WITHOUT a "createdAt" or "providerRef" column at all,
-- and with no FK to "Gym" (unlike every other tenant-scoped table).
-- schema.prisma expects plain `status String @default("COMPLETED")`,
-- `createdAt DateTime @default(now())`, `providerRef String?`, and a real
-- `gym Gym @relation(...)`. Exact error this fix resolves: "The column
-- `createdAt` does not exist in the current database" on
-- `prisma.payment.create()`. Verified against the real `db push`-built
-- table shape (`\d "Payment"`) and cross-checked with `prisma migrate
-- diff`'s independently-generated output, which reports the identical gap.
ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "providerRef" TEXT;
ALTER TABLE "Payment" ALTER COLUMN "status" TYPE TEXT;
ALTER TABLE "Payment" ALTER COLUMN "status" SET DEFAULT 'COMPLETED';
DO $$ BEGIN
  ALTER TABLE "Payment" ADD CONSTRAINT "Payment_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- TWENTIETH GAP found via the same `prisma migrate diff` methodology,
-- pre-emptively fixed alongside the Payment gap immediately above rather
-- than waiting for a further iteration: the exact same real POST
-- /api/sales checkout transaction that writes Invoice -> Payment also
-- writes a Receipt as its very next statement (sales.service.ts's
-- checkout method), so this table's identical class of gap would have
-- been the very next failure encountered. "Receipt" was created by
-- 0009_p0_production_closure WITHOUT a "createdAt" column, with
-- "paymentId" nullable (schema.prisma requires it, `paymentId String
-- @unique`) and with no unique constraint on it, and with no FK to "Gym".
-- Verified against the real `db push`-built table shape (`\d "Receipt"`)
-- and cross-checked with `prisma migrate diff`'s independently-generated
-- output. Confirmed zero existing rows in this environment before tightening
-- "paymentId" to NOT NULL (this table was never reachable by `migrate
-- deploy` before now).
ALTER TABLE "Receipt" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "Receipt" ALTER COLUMN "paymentId" SET NOT NULL;
-- "paymentId" was originally created NULLABLE with an `ON DELETE SET NULL`
-- FK (0009_p0_production_closure). Now that it is correctly NOT NULL to
-- match schema.prisma's required `payment Payment @relation(...)`, `ON
-- DELETE SET NULL` is no longer a valid action for a NOT NULL column —
-- drop and recreate the FK as `ON DELETE CASCADE` (a Receipt only exists
-- because its Payment exists; deleting the Payment should delete the
-- Receipt with it, consistent with how "Receipt_invoiceId_fkey" already
-- behaves with its own NOT NULL "invoiceId").
ALTER TABLE "Receipt" DROP CONSTRAINT IF EXISTS "Receipt_paymentId_fkey";
ALTER TABLE "Receipt" ADD CONSTRAINT "Receipt_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES "Payment"("id") ON UPDATE CASCADE ON DELETE CASCADE;
DO $$ BEGIN
  ALTER TABLE "Receipt" ADD CONSTRAINT "Receipt_paymentId_key" UNIQUE ("paymentId");
EXCEPTION WHEN duplicate_table THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "Receipt" ADD CONSTRAINT "Receipt_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- TWENTY-FIRST GAP found via the same `prisma migrate diff` methodology,
-- discovered in the exact same real POST /api/sales checkout request
-- that surfaced the Invoice/Payment/Receipt gaps above: after the sale
-- transaction commits, `SalesService.afterCheckout` fires a real
-- `ProductEventEmitter.emitEvent(...)` call
-- (`events/PRODUCT_EVENT_EMITTER.ts` -> `events/PRODUCT_EVENT_STORE.ts`'s
-- `this.prisma.productEvent.create(...)`). "ProductEvent" was created by
-- an earlier migration WITHOUT a "createdAt" column (schema.prisma has it,
-- `@default(now())`, alongside the already-present "timestamp" column
-- which is a distinct, separately-tracked field) or a "processedAt"
-- column, and with no FK to "Gym" at all. Exact error this fix resolves:
-- "The column `createdAt` does not exist in the current database" on
-- `this.prisma.productEvent.create()`. Verified against the real `db
-- push`-built table shape (`\d "ProductEvent"`) and cross-checked with
-- `prisma migrate diff`'s independently-generated output, which reports
-- the identical gap.
--
-- IMPORTANT (same root cause as the ProductEvent_tenant_isolation RLS
-- policy fix in 202606200002_add_missing_rls_policies, discovered the hard
-- way here too on the first attempt at this exact fix): at the point THIS
-- migration (0015, positioned right after 0014) runs in true sequential
-- order, "ProductEvent" still has its ORIGINAL column name "tenantId" —
-- the rename to "gymId" doesn't happen until the later migration
-- 202606200004_data_layer_security. A first draft of this fix hardcoded
-- "gymId" directly in the new index/FK below, which only worked under the
-- CI workaround's out-of-sequence replay (already renamed) and failed
-- immediately under a genuine sequential `migrate deploy`: "ERROR: column
-- \"gymId\" does not exist" on the `CREATE INDEX` statement. Fixed the same
-- way as that RLS policy: detect at runtime which column name currently
-- exists and reference that one.
DO $$
DECLARE
  col_name TEXT;
BEGIN
  SELECT column_name INTO col_name FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'ProductEvent' AND column_name IN ('gymId', 'tenantId')
    LIMIT 1;
  ALTER TABLE "ProductEvent" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
  ALTER TABLE "ProductEvent" ADD COLUMN IF NOT EXISTS "processedAt" TIMESTAMP(3);
  EXECUTE format('CREATE INDEX IF NOT EXISTS "ProductEvent_%1$s_createdAt_idx" ON "ProductEvent"(%1$I, "createdAt")', col_name);
  IF col_name = 'gymId' THEN
    BEGIN
      ALTER TABLE "ProductEvent" ADD CONSTRAINT "ProductEvent_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END IF;
  -- When still "tenantId" at this point, the FK to "Gym" is deliberately
  -- deferred to 202606200004 (the same migration that performs the
  -- rename) rather than added here under the pre-rename column name, to
  -- avoid a second rename/constraint-juggling step later.
END $$;

-- TWENTY-SECOND GAP found via the same `prisma migrate diff` methodology,
-- discovered in the exact same real POST /api/sales/:id/refund request
-- that now finally runs (checkout itself succeeds after the fixes above):
-- "Refund" was created by 0009_p0_production_closure with "status" typed
-- as the Postgres enum `"RefundStatus"`, and WITHOUT "staffId", "type", or
-- "itemSnapshot" columns at all. schema.prisma expects plain `status
-- String @default("COMPLETED")`, `staffId String?`, `type String
-- @default("FULL")`, `itemSnapshot Json?`. Exact error this fix resolves:
-- "The column `Refund.staffId` does not exist in the current database."
-- Verified against the real `db push`-built table shape (`\d "Refund"`)
-- and cross-checked with `prisma migrate diff`'s independently-generated
-- output, which reports the identical gap.
ALTER TABLE "Refund" ADD COLUMN IF NOT EXISTS "staffId" TEXT;
ALTER TABLE "Refund" ADD COLUMN IF NOT EXISTS "type" TEXT NOT NULL DEFAULT 'FULL';
ALTER TABLE "Refund" ADD COLUMN IF NOT EXISTS "itemSnapshot" JSONB;
ALTER TABLE "Refund" ALTER COLUMN "status" TYPE TEXT;
ALTER TABLE "Refund" ALTER COLUMN "status" SET DEFAULT 'COMPLETED';

-- TWENTY-THIRD GAP found via the same `prisma migrate diff` methodology,
-- discovered in the same real refund request: `SalesService.refund` (via
-- its notification/owner-notify side effects) writes to "Notification"
-- with a "from" field that 0001_init never created (schema.prisma has
-- `from String?`), and schema.prisma also declares "gymId" as optional
-- (`gymId String?`, with `gym Gym? @relation(...)`) for platform-level/
-- ownerless notifications — but 0001_init created it NOT NULL. Exact error
-- this fix resolves: "The column `Notification.from` does not exist in
-- the current database." Verified against the real `db push`-built table
-- shape (`\d "Notification"`) and cross-checked with `prisma migrate
-- diff`'s independently-generated output. The existing
-- "Notification_gymId_fkey" (`ON DELETE CASCADE`) is also updated to `ON
-- DELETE SET NULL` to match the newly-optional column, consistent with
-- every other now-optional FK fixed elsewhere in this file.
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "from" TEXT;
ALTER TABLE "Notification" ALTER COLUMN "gymId" DROP NOT NULL;
ALTER TABLE "Notification" DROP CONSTRAINT IF EXISTS "Notification_gymId_fkey";
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE SET NULL;

