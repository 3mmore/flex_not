-- Resolve only the tenant id needed to establish RLS for an unguessable public
-- invitation feedback id. Do not expose invitation/member content here.
CREATE OR REPLACE FUNCTION public_invitation_gym_id(p_invitation_id TEXT)
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT "gymId" FROM "Invitation" WHERE id = p_invitation_id LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public_invitation_gym_id(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public_invitation_gym_id(TEXT) TO flexora_app;
