-- Security hardening: OTPs are stored as HMAC hashes only.
ALTER TABLE "MemberOtp" RENAME COLUMN "code" TO "codeHash";

-- Refresh-token family tracking for rotation/reuse detection.
ALTER TABLE "RefreshToken" ADD COLUMN IF NOT EXISTS "familyId" TEXT;
ALTER TABLE "RefreshToken" ADD COLUMN IF NOT EXISTS "replacedByTokenHash" TEXT;
ALTER TABLE "RefreshToken" ADD COLUMN IF NOT EXISTS "reusedAt" TIMESTAMP(3);
UPDATE "RefreshToken" SET "familyId" = "id" WHERE "familyId" IS NULL;
ALTER TABLE "RefreshToken" ALTER COLUMN "familyId" SET NOT NULL;
CREATE INDEX IF NOT EXISTS "RefreshToken_familyId_idx" ON "RefreshToken"("familyId");
