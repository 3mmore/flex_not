-- Migration: 0002_ai_enhancements
-- The AI Intelligence module (churn risk, revenue forecast, product insights,
-- daily briefing, ask-AI) is computed entirely from existing tables
-- (Member, Transaction, Sale, SaleItem, Product, Attendance, Notification).
-- No schema/model changes were required, so this migration is intentionally
-- a no-op. It exists to keep the migration history linear and explicit, and to
-- document the AI release. It is idempotent and safe to run on any environment.

-- (no schema changes)
SELECT 1;
