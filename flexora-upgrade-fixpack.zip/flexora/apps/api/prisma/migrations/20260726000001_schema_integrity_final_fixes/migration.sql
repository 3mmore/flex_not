-- PtSession rating
ALTER TABLE "PtSession" ADD COLUMN "rating" INTEGER;

-- Campaign type
ALTER TABLE "Campaign" ADD COLUMN "type" TEXT NOT NULL DEFAULT 'CAMPAIGN';

-- CustomDomain additions
ALTER TABLE "CustomDomain" ADD COLUMN "domain" TEXT;
ALTER TABLE "CustomDomain" ADD COLUMN "cnameTarget" TEXT NOT NULL DEFAULT 'cname.flexora.app';
ALTER TABLE "CustomDomain" ADD COLUMN "sslCertPath" TEXT;

-- NotificationSubscription keys
ALTER TABLE "NotificationSubscription" ADD COLUMN "keys" JSONB NOT NULL DEFAULT '{}';

-- Remove unused columns if they exist (cleanup)
ALTER TABLE "ClassSession" DROP COLUMN IF EXISTS "startTime", DROP COLUMN IF EXISTS "endTime";
ALTER TABLE "ClassBooking" DROP COLUMN IF EXISTS "bookedAt", DROP COLUMN IF EXISTS "cancelledAt";
ALTER TABLE "PtSession" DROP COLUMN IF EXISTS "startTime", DROP COLUMN IF EXISTS "endTime";
ALTER TABLE "BodyMeasurement" DROP COLUMN IF EXISTS "recordedAt";
ALTER TABLE "LeadFollowUp" DROP COLUMN IF EXISTS "status";
ALTER TABLE "Campaign" DROP COLUMN IF EXISTS "template";
ALTER TABLE "StaffAttendance" DROP COLUMN IF EXISTS "createdAt";
ALTER TABLE "EmailTemplate" DROP COLUMN IF EXISTS "createdAt";
ALTER TABLE "SsoIdentity" DROP COLUMN IF EXISTS "createdAt";
ALTER TABLE "CampaignRecipient" DROP COLUMN IF EXISTS "name", DROP COLUMN IF EXISTS "contact";
ALTER TABLE "PurchaseOrderItem" DROP COLUMN IF EXISTS "createdAt";
ALTER TABLE "NotificationSubscription" DROP COLUMN IF EXISTS "platform";
