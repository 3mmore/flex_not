-- PHASE N1.5 — Member.planId: make the database match schema.prisma.
--
-- WHY THIS MIGRATION EXISTS
--   0001_init created this foreign key as
--       ON DELETE SET NULL   (column nullable)
--   because schema.prisma declared `planId String?` at the time. The schema was
--   later tightened to `planId String` (required) with NO migration, so the
--   deployed database and the Prisma client disagreed about whether a member can
--   exist without a plan.
--
--   The database could therefore hold a state the client cannot read. One member
--   with planId = NULL made every `prisma.member.findMany()` fail with
--       Error converting field "planId" of expected non-nullable type "String",
--       found incompatible value of "null".
--   and GET /api/members answered 500 for the whole gym — the members page, the
--   member picker, the portal and every import died with it. Observed live on
--   2026-10-18 after a plan deletion left the probe member
--   "Sec Probe Create 389784 4" with a NULL plan.
--
-- WHAT THIS DOES
--   1. backfills every orphan with the deterministic rule documented below;
--   2. sets "Member"."planId" NOT NULL;
--   3. recreates the foreign key as ON DELETE NO ACTION.
--
--   NO ACTION rather than RESTRICT on purpose: `DELETE FROM "Gym"` cascades to
--   both "Member" and "Plan" in a single statement, and a NO ACTION constraint is
--   checked at the END of the statement — so wiping a gym (and every test purge
--   script that deletes a gym) keeps working. RESTRICT would abort the cascade
--   mid-statement. What NO ACTION does prevent is a plan being deleted out from
--   under a member that still points at it, which is the corruption above.
--
-- BACKFILL RULE (deterministic, in priority order)
--   "The plan of the member's most recent renewal/activation invoice" cannot be
--   read off an invoice: neither Invoice nor InvoiceLine carries a planId. The
--   record that does is RenewalRequest (it is what produces the invoice —
--   RenewalRequest."invoiceId"), so the rule is evaluated there:
--     1. the plan of the member's most recent COMPLETED renewal
--        (status PAID or CONFIRMED — a renewal that actually extended the
--        membership), newest by "requestedAt", then "createdAt", then id;
--     2. otherwise the plan of the member's most recent renewal of any status
--        except CANCELLED (still an explicit plan choice by that member);
--     3. otherwise the gym's OLDEST plan ("createdAt", then id).
--   Ties are always broken by id so the result does not depend on row order.
--
--   If a gym has an orphan member and NO plan at all, this migration ABORTS with
--   a message naming the gym and the member instead of guessing: there is no
--   defensible plan to point them at, and inventing one would silently reprice a
--   real membership.

DO $$
DECLARE
  orphan        RECORD;
  chosen_plan   text;
  chosen_reason text;
  fixed         integer := 0;
BEGIN
  FOR orphan IN
    SELECT m.id, m.name, m."gymId", g.name AS gym_name
    FROM "Member" m
    JOIN "Gym" g ON g.id = m."gymId"
    WHERE m."planId" IS NULL
    ORDER BY m."createdAt", m.id
  LOOP
    chosen_plan   := NULL;
    chosen_reason := NULL;

    -- rule 1: the plan of the most recent completed (PAID/CONFIRMED) renewal
    SELECT rr."planId" INTO chosen_plan
    FROM "RenewalRequest" rr
    WHERE rr."memberId" = orphan.id
      AND rr.status IN ('PAID', 'CONFIRMED')
    ORDER BY rr."requestedAt" DESC, rr."createdAt" DESC, rr.id DESC
    LIMIT 1;
    IF FOUND THEN
      chosen_reason := 'most recent completed renewal (PAID/CONFIRMED)';
    END IF;

    -- rule 2: the plan of the most recent non-cancelled renewal
    IF chosen_plan IS NULL THEN
      SELECT rr."planId" INTO chosen_plan
      FROM "RenewalRequest" rr
      WHERE rr."memberId" = orphan.id
        AND rr.status <> 'CANCELLED'
      ORDER BY rr."requestedAt" DESC, rr."createdAt" DESC, rr.id DESC
      LIMIT 1;
      IF FOUND THEN
        chosen_reason := 'most recent non-cancelled renewal';
      END IF;
    END IF;

    -- rule 3: the gym's oldest plan
    IF chosen_plan IS NULL THEN
      SELECT p.id INTO chosen_plan
      FROM "Plan" p
      WHERE p."gymId" = orphan."gymId"
      ORDER BY p."createdAt" ASC, p.id ASC
      LIMIT 1;
      IF FOUND THEN
        chosen_reason := 'oldest plan of the gym';
      END IF;
    END IF;

    -- no plan at all for this gym: refuse rather than guess
    IF chosen_plan IS NULL THEN
      RAISE EXCEPTION
        'PHASE N1.5: cannot backfill "Member"."planId" — member "%" (id %) belongs to gym "%" (id %), has no plan, and that gym has NO plans at all. Create a plan for the gym (or remove the orphan member) and re-run the migration. Refusing to guess a membership plan.',
        orphan.name, orphan.id, orphan.gym_name, orphan."gymId";
    END IF;

    UPDATE "Member" SET "planId" = chosen_plan WHERE id = orphan.id;
    fixed := fixed + 1;
    RAISE NOTICE 'PHASE N1.5: member "%" (id %) of gym "%" -> plan % [%]',
      orphan.name, orphan.id, orphan.gym_name, chosen_plan, chosen_reason;
  END LOOP;

  RAISE NOTICE 'PHASE N1.5: backfilled % orphan member(s)', fixed;
END $$;

-- 2. required, exactly as schema.prisma has always declared it
ALTER TABLE "Member" ALTER COLUMN "planId" SET NOT NULL;

-- 3. NO ACTION instead of SET NULL (see the header for why not RESTRICT)
ALTER TABLE "Member" DROP CONSTRAINT "Member_planId_fkey";
ALTER TABLE "Member" ADD CONSTRAINT "Member_planId_fkey"
  FOREIGN KEY ("planId") REFERENCES "Plan"("id") ON DELETE NO ACTION ON UPDATE CASCADE;
