-- Narrow tenant lookup for signed WhatsApp callbacks. The caller still has to
-- pass Meta's HMAC verification before using this value in application code.
CREATE OR REPLACE FUNCTION public_messaging_gym_id(p_phone_id TEXT)
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT "gymId" FROM "GymMessagingConfig"
  WHERE "whatsappPhoneId" = p_phone_id
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public_messaging_gym_id(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public_messaging_gym_id(TEXT) TO flexora_app;
