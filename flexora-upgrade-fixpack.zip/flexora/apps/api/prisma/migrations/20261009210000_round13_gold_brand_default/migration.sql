-- ROUND 13 (Phase 2) — the brand default becomes FLEXORA gold (#C5A059).
--
-- The column default used to be indigo (#6366F1), so every gym that never
-- picked a color (including the seeded demo gym) was STORED as indigo and
-- overrode the gold CSS default at runtime. Two things change:
--
--   1. New gyms default to gold (schema.prisma).
--   2. Existing rows still holding the OLD DEFAULT are re-pointed at gold.
--      Both casings are matched: the column default stored '#6366F1', while
--      the Settings PATCH normalizes owner-picked colors to lowercase — a gym
--      whose owner explicitly picked indigo is indistinguishable from one
--      that never picked, and the product decision is that indigo-by-default
--      becomes gold. Gyms that picked any OTHER color are untouched.
ALTER TABLE "Gym" ALTER COLUMN "accentColor" SET DEFAULT '#C5A059';
UPDATE "Gym" SET "accentColor" = '#C5A059' WHERE lower("accentColor") = '#6366f1';
