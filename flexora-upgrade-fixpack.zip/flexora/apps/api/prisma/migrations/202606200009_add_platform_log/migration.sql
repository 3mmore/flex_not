CREATE TABLE IF NOT EXISTS "PlatformLog" (
  "id"        TEXT NOT NULL
    DEFAULT gen_random_uuid(),
  "type"      TEXT NOT NULL,
  "content"   TEXT NOT NULL,
  "meta"      JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL
    DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PlatformLog_pkey"
    PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PlatformLog_type_idx"
  ON "PlatformLog"("type");

CREATE INDEX IF NOT EXISTS
  "PlatformLog_createdAt_idx"
  ON "PlatformLog"("createdAt");
