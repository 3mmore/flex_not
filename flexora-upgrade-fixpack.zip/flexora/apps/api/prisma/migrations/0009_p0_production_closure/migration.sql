-- P0 production closure models.
ALTER TABLE "Sale" ADD COLUMN IF NOT EXISTS "status" TEXT NOT NULL DEFAULT 'COMPLETED';

DO $$ BEGIN CREATE TYPE "RefundStatus" AS ENUM ('COMPLETED','VOIDED'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT','PARTIALLY_PAID','PAID','VOID'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "PaymentStatus" AS ENUM ('PENDING','PARTIAL','PAID','FAILED','REFUNDED'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "CampaignRecipientStatus" AS ENUM ('PENDING','SENT','DELIVERED','FAILED','OPENED','CLICKED','CONVERTED'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "BillingRecoveryStatus" AS ENUM ('FAILED','RETRYING','RECOVERED','EXPIRED'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "TimesheetStatus" AS ENUM ('OPEN','APPROVED','EXPORTED'); EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS "Refund" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "saleId" TEXT NOT NULL, "amount" DECIMAL(14,2) NOT NULL, "reason" TEXT NOT NULL, "status" "RefundStatus" NOT NULL DEFAULT 'COMPLETED', "createdBy" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS "RefundItem" ("id" TEXT PRIMARY KEY, "refundId" TEXT NOT NULL REFERENCES "Refund"("id") ON DELETE CASCADE, "saleItemId" TEXT NOT NULL, "productId" TEXT, "qty" INTEGER NOT NULL, "amount" DECIMAL(14,2) NOT NULL);
CREATE TABLE IF NOT EXISTS "RefundAudit" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "refundId" TEXT NOT NULL REFERENCES "Refund"("id") ON DELETE CASCADE, "action" TEXT NOT NULL, "actorId" TEXT, "reason" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS "Refund_gymId_saleId_idx" ON "Refund"("gymId","saleId");
CREATE INDEX IF NOT EXISTS "Refund_gymId_createdAt_idx" ON "Refund"("gymId","createdAt");
CREATE INDEX IF NOT EXISTS "RefundItem_refundId_idx" ON "RefundItem"("refundId");
CREATE INDEX IF NOT EXISTS "RefundItem_saleItemId_idx" ON "RefundItem"("saleItemId");
CREATE INDEX IF NOT EXISTS "RefundAudit_gymId_createdAt_idx" ON "RefundAudit"("gymId","createdAt");

CREATE TABLE IF NOT EXISTS "Invoice" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "memberId" TEXT, "invoiceNo" TEXT NOT NULL, "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT', "subtotal" DECIMAL(14,2) NOT NULL, "total" DECIMAL(14,2) NOT NULL, "paid" DECIMAL(14,2) NOT NULL DEFAULT 0, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS "InvoiceLine" ("id" TEXT PRIMARY KEY, "invoiceId" TEXT NOT NULL REFERENCES "Invoice"("id") ON DELETE CASCADE, "description" TEXT NOT NULL, "qty" INTEGER NOT NULL DEFAULT 1, "unitPrice" DECIMAL(14,2) NOT NULL, "total" DECIMAL(14,2) NOT NULL);
CREATE TABLE IF NOT EXISTS "Payment" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "invoiceId" TEXT NOT NULL REFERENCES "Invoice"("id") ON DELETE CASCADE, "amount" DECIMAL(14,2) NOT NULL, "method" TEXT NOT NULL DEFAULT 'CASH', "status" "PaymentStatus" NOT NULL DEFAULT 'PAID', "reference" TEXT, "paidAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "createdBy" TEXT);
CREATE TABLE IF NOT EXISTS "Receipt" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "invoiceId" TEXT NOT NULL REFERENCES "Invoice"("id") ON DELETE CASCADE, "paymentId" TEXT REFERENCES "Payment"("id") ON DELETE SET NULL, "receiptNo" TEXT NOT NULL, "issuedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "channel" TEXT NOT NULL DEFAULT 'IN_PERSON');
CREATE UNIQUE INDEX IF NOT EXISTS "Invoice_gymId_invoiceNo_key" ON "Invoice"("gymId","invoiceNo");
CREATE UNIQUE INDEX IF NOT EXISTS "Receipt_gymId_receiptNo_key" ON "Receipt"("gymId","receiptNo");

CREATE TABLE IF NOT EXISTS "CampaignRecipient" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "campaignId" TEXT NOT NULL, "memberId" TEXT, "leadId" TEXT, "to" TEXT NOT NULL, "status" "CampaignRecipientStatus" NOT NULL DEFAULT 'PENDING', "error" TEXT, "sentAt" TIMESTAMP(3), "deliveredAt" TIMESTAMP(3), "openedAt" TIMESTAMP(3), "clickedAt" TIMESTAMP(3), "convertedAt" TIMESTAMP(3), "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS "CampaignRecipient_gymId_campaignId_idx" ON "CampaignRecipient"("gymId","campaignId");

CREATE TABLE IF NOT EXISTS "PurchaseOrderItem" ("id" TEXT PRIMARY KEY, "purchaseOrderId" TEXT NOT NULL REFERENCES "PurchaseOrder"("id") ON DELETE CASCADE, "productId" TEXT NOT NULL, "qtyOrdered" INTEGER NOT NULL, "qtyReceived" INTEGER NOT NULL DEFAULT 0, "unitCost" DECIMAL(14,2) NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS "GoodsReceiptItem" ("id" TEXT PRIMARY KEY, "goodsReceiptId" TEXT NOT NULL REFERENCES "GoodsReceipt"("id") ON DELETE CASCADE, "productId" TEXT NOT NULL, "qtyReceived" INTEGER NOT NULL, "unitCost" DECIMAL(14,2) NOT NULL DEFAULT 0, "varianceQty" INTEGER NOT NULL DEFAULT 0);

CREATE TABLE IF NOT EXISTS "PaymentAttempt" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "provider" TEXT NOT NULL, "providerRef" TEXT, "status" "BillingRecoveryStatus" NOT NULL, "amount" DECIMAL(14,2), "currency" TEXT NOT NULL DEFAULT 'USD', "attemptedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "error" TEXT);
CREATE TABLE IF NOT EXISTS "BillingRecoveryTask" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "status" "BillingRecoveryStatus" NOT NULL DEFAULT 'FAILED', "stage" INTEGER NOT NULL DEFAULT 1, "dueAt" TIMESTAMP(3) NOT NULL, "recoveredAt" TIMESTAMP(3), "notes" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS "StaffPayProfile" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "userId" TEXT NOT NULL, "hourlyRate" DECIMAL(14,2) NOT NULL, "currency" TEXT NOT NULL DEFAULT 'EGP', "active" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX IF NOT EXISTS "StaffPayProfile_gymId_userId_key" ON "StaffPayProfile"("gymId","userId");
CREATE TABLE IF NOT EXISTS "Timesheet" ("id" TEXT PRIMARY KEY, "gymId" TEXT NOT NULL, "userId" TEXT NOT NULL, "periodStart" TIMESTAMP(3) NOT NULL, "periodEnd" TIMESTAMP(3) NOT NULL, "status" "TimesheetStatus" NOT NULL DEFAULT 'OPEN', "totalMinutes" INTEGER NOT NULL DEFAULT 0, "overtimeMinutes" INTEGER NOT NULL DEFAULT 0, "grossPay" DECIMAL(14,2) NOT NULL DEFAULT 0, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS "TimesheetEntry" ("id" TEXT PRIMARY KEY, "timesheetId" TEXT NOT NULL REFERENCES "Timesheet"("id") ON DELETE CASCADE, "staffAttendanceId" TEXT, "checkInAt" TIMESTAMP(3) NOT NULL, "checkOutAt" TIMESTAMP(3), "minutes" INTEGER NOT NULL, "overtimeMinutes" INTEGER NOT NULL DEFAULT 0);
