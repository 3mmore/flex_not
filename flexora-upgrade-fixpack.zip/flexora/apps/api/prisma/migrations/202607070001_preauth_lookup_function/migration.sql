-- FLEXORA Gym OS -- CRITICAL FIX: real /api/auth/login (and every other
-- pre-authentication flow) is completely broken under the correct,
-- hardened flexora_app + FORCE ROW LEVEL SECURITY production
-- configuration introduced by 202607050001_flexora_app_role_force_rls.
--
-- ROOT CAUSE (confirmed via direct reproduction against a real Postgres
-- database with the real flexora_app role and FORCE RLS active -- not
-- speculation): "User" has FORCE ROW LEVEL SECURITY with policy
-- USING ("gymId" = current_setting('app.gym_id', true)). Every
-- pre-authentication flow (login, registerGym, forgotPassword,
-- changePassword, resetPassword -- all @Public() routes that never pass
-- through TenantGuard, since TenantGuard's entire job is to establish
-- app.gym_id from an ALREADY-authenticated user's JWT) necessarily runs
-- its very first User lookup with NO tenant context yet -- that is the
-- whole point of a login flow: the caller does not know their own gymId
-- until the server tells them. With app.gym_id unset,
-- current_setting('app.gym_id', true) returns NULL, and
-- "gymId" = NULL is never TRUE in SQL -- so EVERY row is filtered out.
-- Confirmed directly: POST /api/auth/login with 100% correct, real
-- credentials always returned 401 "Invalid credentials" under the real
-- flexora_app role, even though the exact same query succeeds instantly
-- when run as the table-owning role. Reconfirmed for every other affected
-- flow: registerGym's nested Gym.create({ users: { create: {...} } })
-- fails outright with "new row violates row-level security policy for
-- table \"User\""; forgotPassword's User.findFirst always returns 0 rows;
-- changePassword/resetPassword's User.update always fails with "Record to
-- update not found" (Prisma's phrasing for "the WHERE clause matched zero
-- rows after RLS filtering").
--
-- WHY NOT OTHER FIXES (each investigated and rejected before choosing this
-- one -- see accompanying report for full reasoning):
--   - Weakening the RLS policy itself would reintroduce the exact
--     cross-tenant data exposure this migration's own RLS work was meant
--     to close, or require a fragile, hard-to-audit per-query carve-out.
--   - Routing pre-auth flows through the table-owning/superuser role
--     (e.g. a second PrismaClient instance, or toggling roles on a shared
--     connection) was explicitly rejected: a second, separately configured
--     PrismaClient instance is easy to misuse elsewhere, and toggling
--     roles on a shared/pooled connection (pgbouncer transaction mode) is
--     not reliably possible at all.
--
-- THE FIX: a narrowly-scoped, SECURITY DEFINER Postgres function, owned
-- by the table-owning role (whichever role runs migrate deploy -- never
-- flexora_app), that runs with the OWNER's privileges (bypassing RLS)
-- ONLY for the single query inside this one function body -- not for the
-- calling connection/session in general. flexora_app is granted EXECUTE
-- on this function only; its own baseline table-level GRANTs (and
-- therefore RLS enforcement on every ordinary, direct query it makes) are
-- completely unchanged everywhere else in the application. Verified
-- directly before writing this migration: after granting EXECUTE on an
-- equivalent test function, a raw SELECT ... FROM "User" by flexora_app
-- still correctly returned 0 rows (RLS still fully enforced for direct
-- access) while calling the function correctly returned the real row --
-- proving this is a precise, minimal carve-out, not a blanket bypass.
--
-- The function returns ONLY the columns AuthService.login/forgotPassword
-- actually need (not SELECT *), which is itself a stronger security
-- posture than a broader bypass would be.
CREATE OR REPLACE FUNCTION preauth_find_users_by_email(p_email TEXT, p_gym_id TEXT DEFAULT NULL)
RETURNS TABLE (
  id TEXT,
  name TEXT,
  email TEXT,
  "passwordHash" TEXT,
  role "Role",
  "gymId" TEXT,
  "branchId" TEXT,
  active BOOLEAN,
  "onboardingCompleted" BOOLEAN,
  "twoFaEnabled" BOOLEAN,
  "twoFaSecret" TEXT,
  "twoFaBackupCodes" TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    u.id, u.name, u.email, u."passwordHash", u.role, u."gymId", u."branchId",
    u.active, u."onboardingCompleted", u."twoFaEnabled", u."twoFaSecret", u."twoFaBackupCodes"
  FROM "User" u
  WHERE u.email = p_email
    AND (p_gym_id IS NULL OR u."gymId" = p_gym_id)
  LIMIT 5;
$$;

-- Used by AuthService.verifyTwoFaLogin / TwoFactorService -- the temp-2FA
-- token carries a real, already-authenticated-once userId (not an email),
-- but the caller still has no app.gym_id in context (the whole 2FA
-- exchange is deliberately a separate, still-@Public() endpoint from the
-- final login), so this lookup by id has exactly the same problem.
CREATE OR REPLACE FUNCTION preauth_find_user_by_id(p_user_id TEXT)
RETURNS TABLE (
  id TEXT,
  name TEXT,
  email TEXT,
  "passwordHash" TEXT,
  role "Role",
  "gymId" TEXT,
  "branchId" TEXT,
  active BOOLEAN,
  "onboardingCompleted" BOOLEAN,
  "twoFaEnabled" BOOLEAN,
  "twoFaSecret" TEXT,
  "twoFaBackupCodes" TEXT,
  "twoFaLastCode" TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    u.id, u.name, u.email, u."passwordHash", u.role, u."gymId", u."branchId",
    u.active, u."onboardingCompleted", u."twoFaEnabled", u."twoFaSecret", u."twoFaBackupCodes",
    u."twoFaLastCode"
  FROM "User" u
  WHERE u.id = p_user_id
  LIMIT 1;
$$;

-- Used by AuthService.refresh -- "RefreshToken" itself is not RLS-protected
-- (it is looked up by an unguessable random token hash, not by tenant),
-- but its include: { user: true } join needs the same pre-auth,
-- tenant-unknown User row.
CREATE OR REPLACE FUNCTION preauth_find_user_by_refresh_token_hash(p_token_hash TEXT)
RETURNS TABLE (
  id TEXT,
  name TEXT,
  email TEXT,
  "passwordHash" TEXT,
  role "Role",
  "gymId" TEXT,
  "branchId" TEXT,
  active BOOLEAN,
  "onboardingCompleted" BOOLEAN,
  "twoFaEnabled" BOOLEAN,
  "twoFaSecret" TEXT,
  "twoFaBackupCodes" TEXT,
  "refreshTokenId" TEXT,
  "refreshTokenExpiresAt" TIMESTAMP(3),
  "refreshTokenRevoked" BOOLEAN,
  "refreshTokenFamilyId" TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    u.id, u.name, u.email, u."passwordHash", u.role, u."gymId", u."branchId",
    u.active, u."onboardingCompleted", u."twoFaEnabled", u."twoFaSecret", u."twoFaBackupCodes",
    rt.id AS "refreshTokenId", rt."expiresAt" AS "refreshTokenExpiresAt",
    rt.revoked AS "refreshTokenRevoked", rt."familyId" AS "refreshTokenFamilyId"
  FROM "RefreshToken" rt
  JOIN "User" u ON u.id = rt."userId"
  WHERE rt."tokenHash" = p_token_hash
  LIMIT 1;
$$;

-- Used by AuthService.changePassword/resetPassword -- updating a User row
-- with no tenant context yet known. Scoped to ONLY the passwordHash
-- column -- cannot be used to modify role/gymId/active or any other
-- sensitive field.
CREATE OR REPLACE FUNCTION preauth_update_user_password(p_user_id TEXT, p_new_password_hash TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_updated_count INT;
BEGIN
  UPDATE "User" SET "passwordHash" = p_new_password_hash WHERE id = p_user_id;
  GET DIAGNOSTICS v_updated_count = ROW_COUNT;
  RETURN v_updated_count > 0;
END;
$$;

-- NOTE on AuthService.registerGym (the one other pre-auth flow that writes
-- to RLS-protected tables): this is NOT fixed with a SECURITY DEFINER
-- function. "Gym" itself carries no RLS (only tenant-CHILD tables like
-- User/Branch/Plan/License/Subscription do -- there is no tenant "above"
-- Gym to isolate it from). Since Prisma already generates the new Gym's
-- id before issuing any child-table INSERTs, the application code creates
-- the Gym row first (no RLS obstacle), then wraps the remaining
-- User/Branch/Plan/License/Subscription creates in
-- tenantContext.run(newGymId, () => ...) -- the EXACT SAME, already-
-- proven-correct mechanism TenantGuard uses for every authenticated
-- request, just entered explicitly here instead of derived from a JWT
-- (since no JWT exists yet during signup). Verified directly before
-- choosing this approach with a real, standalone script run against this
-- exact database (real flexora_app role, real FORCE RLS) before writing
-- this migration -- see auth.service.ts's own comment on registerGym.

GRANT EXECUTE ON FUNCTION preauth_find_users_by_email(TEXT, TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_find_user_by_id(TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_find_user_by_refresh_token_hash(TEXT) TO flexora_app;
GRANT EXECUTE ON FUNCTION preauth_update_user_password(TEXT, TEXT) TO flexora_app;

-- Used by TwoFactorService.verifyCode -- this single method is called both
-- from fully-authenticated, tenant-scoped routes (TwoFactorController's
-- setup/verify/disable, which already correctly have app.gym_id set by
-- the global TenantGuard, since those routes are NOT @Public()) AND from
-- genuinely pre-auth, @Public() routes (AuthService.verifyTwoFaLogin,
-- TwoFactorController.loginStep -- the whole point of these being that
-- the caller has only a temp 2FA token, not a full session yet, so no
-- tenant context can exist). Rather than have verifyCode's behavior
-- silently depend on which of its two call-site classes happened to
-- invoke it (fragile, easy to regress), it now unconditionally uses this
-- same SECURITY DEFINER pattern for its own read+write, making it
-- correct and identical regardless of caller context. Scoped by exact,
-- globally-unique userId (never guessable/enumerable) and limited to
-- exactly the 3 columns TOTP verification legitimately needs to update.
CREATE OR REPLACE FUNCTION preauth_update_user_2fa_state(
  p_user_id TEXT,
  p_two_fa_last_code TEXT,
  p_two_fa_backup_codes TEXT,
  p_update_backup_codes BOOLEAN
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_updated_count INT;
BEGIN
  IF p_update_backup_codes THEN
    UPDATE "User" SET "twoFaLastCode" = p_two_fa_last_code, "twoFaBackupCodes" = p_two_fa_backup_codes WHERE id = p_user_id;
  ELSE
    UPDATE "User" SET "twoFaLastCode" = p_two_fa_last_code WHERE id = p_user_id;
  END IF;
  GET DIAGNOSTICS v_updated_count = ROW_COUNT;
  RETURN v_updated_count > 0;
END;
$$;

GRANT EXECUTE ON FUNCTION preauth_update_user_2fa_state(TEXT, TEXT, TEXT, BOOLEAN) TO flexora_app;
