-- Product barcodes are tenant-scoped, not global.
DROP INDEX IF EXISTS "Product_barcode_key";
CREATE UNIQUE INDEX IF NOT EXISTS "Product_gymId_barcode_key" ON "Product"("gymId", "barcode");

-- Normalize subscription spelling and remove duplicate enum value.
UPDATE "Subscription" SET "status" = 'CANCELED' WHERE "status"::text = 'CANCELLED';
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'SubscriptionStatus') THEN
    ALTER TYPE "SubscriptionStatus" RENAME TO "SubscriptionStatus_old";
    CREATE TYPE "SubscriptionStatus" AS ENUM ('ACTIVE','PAST_DUE','CANCELED','TRIALING','SUSPENDED');
    ALTER TABLE "Subscription" ALTER COLUMN "status" DROP DEFAULT;
    ALTER TABLE "Subscription" ALTER COLUMN "status" TYPE "SubscriptionStatus" USING "status"::text::"SubscriptionStatus";
    ALTER TABLE "Subscription" ALTER COLUMN "status" SET DEFAULT 'TRIALING';
    DROP TYPE "SubscriptionStatus_old";
  END IF;
EXCEPTION WHEN duplicate_object THEN
  NULL;
END $$;
