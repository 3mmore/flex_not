DROP FUNCTION IF EXISTS public.platform_subscription_console(text,text,text,text,text,integer,integer);
