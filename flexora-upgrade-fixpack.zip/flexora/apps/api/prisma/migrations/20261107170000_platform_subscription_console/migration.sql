-- Additive, read-only, allowlisted platform subscription directory.
-- No existing table, function or data is changed.
BEGIN;
CREATE FUNCTION public.platform_subscription_console(
  p_search text, p_status text, p_tier text, p_window text,
  p_dir text, p_limit integer, p_offset integer
) RETURNS TABLE (
  gym_id text, gym_name text, gym_status text, gym_email text, gym_phone text,
  owner_name text, owner_phone text, tier text, subscription_status text,
  start_date timestamp(3), end_date timestamp(3), trial_days integer,
  last_payment_at timestamp(3), last_payment_amount integer,
  last_grant_at timestamp(3), effective_status text, total bigint
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public
AS $fn$
  WITH base AS (
    SELECT g.id AS gym_id, g.name AS gym_name, g.status::text AS gym_status,
           g.email AS gym_email, g.phone AS gym_phone, o.name AS owner_name,
           o.phone AS owner_phone, s.tier::text AS tier,
           s.status::text AS subscription_status,
           CASE WHEN s.status::text = 'TRIALING' THEN s."trialStartDate" ELSE s."currentPeriodStart" END AS start_date,
           CASE WHEN s.status::text = 'TRIALING' THEN COALESCE(s."trialEndDate", s."currentPeriodEnd") ELSE s."currentPeriodEnd" END AS end_date,
           s."trialDays" AS trial_days, s."lastPaymentAt" AS last_payment_at,
           s."lastPaymentAmount" AS last_payment_amount,
           (SELECT a."createdAt" FROM public."PlatformAuditLog" a
             WHERE a.target = g.id AND a.action IN ('gym:grant-subscription','gym:extend-trial')
             ORDER BY a.seq DESC LIMIT 1) AS last_grant_at
      FROM public."Gym" g
      LEFT JOIN public."Subscription" s ON s."gymId" = g.id
      LEFT JOIN LATERAL (SELECT u.name, u.phone FROM public."User" u
        WHERE u."gymId" = g.id AND u.role = 'OWNER'
        ORDER BY u."createdAt", u.id LIMIT 1) o ON true
     WHERE g.status::text <> 'DELETED'
  ), classified AS (
    SELECT base.*, CASE
      WHEN subscription_status = 'CANCELED' THEN 'CANCELED'
      WHEN subscription_status = 'SUSPENDED' THEN 'SUSPENDED'
      WHEN end_date < (now() AT TIME ZONE 'UTC') THEN 'EXPIRED'
      ELSE subscription_status END AS effective_status FROM base
  ), filtered AS (
    SELECT * FROM classified c
     WHERE (p_search IS NULL OR c.gym_name ILIKE '%' || p_search || '%' OR c.owner_name ILIKE '%' || p_search || '%')
       AND (p_status IS NULL OR c.effective_status = p_status)
       AND (p_tier IS NULL OR c.tier = p_tier)
       AND (p_window IS NULL OR (p_window = 'expired' AND c.end_date < (now() AT TIME ZONE 'UTC'))
         OR (p_window = 'ending7' AND c.end_date >= (now() AT TIME ZONE 'UTC') AND c.end_date <= (now() AT TIME ZONE 'UTC') + interval '7 days'))
  )
  SELECT f.*, count(*) OVER () AS total FROM filtered f
  ORDER BY CASE WHEN p_dir = 'desc' THEN f.end_date END DESC NULLS LAST,
           CASE WHEN p_dir <> 'desc' OR p_dir IS NULL THEN f.end_date END ASC NULLS LAST,
           f.gym_id ASC
  LIMIT LEAST(GREATEST(COALESCE(p_limit,25),1),100) OFFSET GREATEST(COALESCE(p_offset,0),0);
$fn$;
REVOKE ALL ON FUNCTION public.platform_subscription_console(text,text,text,text,text,integer,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_subscription_console(text,text,text,text,text,integer,integer) TO flexora_app;
COMMIT;
