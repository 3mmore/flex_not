-- Gym bot config
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "waBotEnabled" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "waBotPhoneId" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "waBotToken" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "waBotGreeting" TEXT;
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "waBotLanguage" TEXT NOT NULL DEFAULT 'ar';

-- Conversations
CREATE TABLE IF NOT EXISTS "WaConversation" (
  "id" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "memberPhone" TEXT NOT NULL,
  "memberId" TEXT,
  "lastMessageAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WaConversation_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "WaConversation_gymId_memberPhone_key" ON "WaConversation"("gymId", "memberPhone");
CREATE INDEX IF NOT EXISTS "WaConversation_gymId_lastMessageAt_idx" ON "WaConversation"("gymId", "lastMessageAt" DESC);

-- Messages
DO $$ BEGIN
  CREATE TYPE "MessageDirection" AS ENUM ('INBOUND', 'OUTBOUND');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;
CREATE TABLE IF NOT EXISTS "WaMessage" (
  "id" TEXT NOT NULL,
  "conversationId" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "direction" "MessageDirection" NOT NULL,
  "content" TEXT NOT NULL,
  "aiGenerated" BOOLEAN NOT NULL DEFAULT false,
  "waMessageId" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "WaMessage_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "WaMessage_conversationId_idx" ON "WaMessage"("conversationId");

-- Foreign keys
DO $$ BEGIN
  ALTER TABLE "WaConversation" ADD CONSTRAINT "WaConversation_gymId_fkey" 
    FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "WaConversation" ADD CONSTRAINT "WaConversation_memberId_fkey" 
    FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  ALTER TABLE "WaMessage" ADD CONSTRAINT "WaMessage_conversationId_fkey" 
    FOREIGN KEY ("conversationId") REFERENCES "WaConversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
