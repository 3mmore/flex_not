-- ROUND 14 (security review, PHASE E) — member-portal security.
--
-- 1. NEVER persist OTP/access codes in Notification.body. Portal login OTPs
--    used to be stored verbatim in the WHATSAPP notification log row, so any
--    staff user who could read the log could take over a member's portal
--    session. New OTP messages are written with a redacted body going forward
--    (see NotificationsService.whatsapp's persistBody parameter); this
--    migration redacts the rows that already exist.
--
-- 2. "isRead" lets the member portal mark its own notifications read without
--    giving members write access to the shared staff notification log.

-- 1. Redact existing OTP bodies in the notification log.
UPDATE "Notification"
SET "body" = 'Login code sent'
WHERE "channel" = 'WHATSAPP'
  AND (
    "body" LIKE '%كود الدخول%'          -- the Arabic OTP template
    OR "body" ILIKE '%login code%'    -- English OTP templates
    OR "body" ILIKE '%access code%'   -- staff-generated access-code messages
    OR "body" ILIKE '%otp%'           -- any other OTP-shaped message
    OR "body" ~ '^[0-9]{6}$'          -- a bare 6-digit code
  );

-- 2. Member-portal read state.
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "isRead" BOOLEAN NOT NULL DEFAULT false;
