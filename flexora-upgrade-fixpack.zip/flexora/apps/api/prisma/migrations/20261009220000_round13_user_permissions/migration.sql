-- ROUND 13 (Phase 5) — per-employee permission overrides.
--
-- Effective permissions = role defaults adjusted by these rows. Only the
-- OWNER writes them; every change is audit-logged. Same tenant RLS pattern as
-- the other gymId tables (see 202606200001_add_tenant_rls).
CREATE TABLE "UserPermission" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "permission" TEXT NOT NULL,
  "granted" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "UserPermission_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "UserPermission_userId_permission_key" ON "UserPermission"("userId", "permission");
CREATE INDEX "UserPermission_gymId_idx" ON "UserPermission"("gymId");

ALTER TABLE "UserPermission" ADD CONSTRAINT "UserPermission_userId_fkey"
  FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "UserPermission" ADD CONSTRAINT "UserPermission_gymId_fkey"
  FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Tenant isolation, same policy shape as User/Plan/Member.
ALTER TABLE "UserPermission" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'UserPermission' AND policyname = 'UserPermission_tenant_isolation') THEN
    CREATE POLICY "UserPermission_tenant_isolation" ON "UserPermission"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;
