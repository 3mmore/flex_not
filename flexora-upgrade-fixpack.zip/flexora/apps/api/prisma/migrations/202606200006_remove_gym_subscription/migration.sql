ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "stripePriceId" TEXT;
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "currentPeriodStart" TIMESTAMP(3);
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "cancelAtPeriodEnd" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "lastPaymentAt" TIMESTAMP(3);
ALTER TABLE "Subscription" ADD COLUMN IF NOT EXISTS "lastPaymentAmount" INTEGER;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'GymSubscription') THEN
    EXECUTE $sql$
      INSERT INTO "Subscription" ("id", "gymId", "tier", "status", "currentPeriodStart", "currentPeriodEnd", "stripeCustomerId", "stripeSubscriptionId", "stripePriceId", "trialStartDate", "trialEndDate", "cancelAtPeriodEnd", "lastPaymentAt", "lastPaymentAmount", "createdAt", "updatedAt")
      SELECT gen_random_uuid()::text, gs."gymId", gs."plan"::"SubscriptionTier", gs."status"::"SubscriptionStatus", gs."currentPeriodStart", COALESCE(gs."currentPeriodEnd", NOW()), gs."stripeCustomerId", gs."stripeSubscriptionId", gs."stripePriceId", gs."trialStart", gs."trialEnd", gs."cancelAtPeriodEnd", gs."lastPaymentAt", gs."lastPaymentAmount", gs."createdAt", gs."updatedAt"
      FROM "GymSubscription" gs
      ON CONFLICT ("gymId") DO UPDATE SET
        "tier" = EXCLUDED."tier",
        "status" = EXCLUDED."status",
        "currentPeriodStart" = EXCLUDED."currentPeriodStart",
        "currentPeriodEnd" = EXCLUDED."currentPeriodEnd",
        "stripeCustomerId" = EXCLUDED."stripeCustomerId",
        "stripeSubscriptionId" = EXCLUDED."stripeSubscriptionId",
        "stripePriceId" = EXCLUDED."stripePriceId",
        "trialStartDate" = EXCLUDED."trialStartDate",
        "trialEndDate" = EXCLUDED."trialEndDate",
        "cancelAtPeriodEnd" = EXCLUDED."cancelAtPeriodEnd",
        "lastPaymentAt" = EXCLUDED."lastPaymentAt",
        "lastPaymentAmount" = EXCLUDED."lastPaymentAmount"
    $sql$;
    EXECUTE 'DROP TABLE "GymSubscription"';
  END IF;
END $$;

DROP POLICY IF EXISTS "ProductEvent_tenant_isolation" ON "ProductEvent";
CREATE POLICY "ProductEvent_tenant_isolation" ON "ProductEvent"
USING ("gymId" = current_setting('app.gym_id', true))
WITH CHECK ("gymId" = current_setting('app.gym_id', true));

DROP TABLE IF EXISTS "SuperAdmin";
