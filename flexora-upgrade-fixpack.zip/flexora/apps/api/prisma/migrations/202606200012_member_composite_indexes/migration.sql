-- Add composite indexes for Member table (performance + tenant safety)
CREATE INDEX IF NOT EXISTS "Member_gymId_mobile_idx" ON "Member"("gymId", "mobile");
CREATE INDEX IF NOT EXISTS "Member_gymId_code_idx" ON "Member"("gymId", "code");
CREATE INDEX IF NOT EXISTS "Member_gymId_status_idx" ON "Member"("gymId", "status");
CREATE INDEX IF NOT EXISTS "Member_gymId_expiry_idx" ON "Member"("gymId", "expiry");