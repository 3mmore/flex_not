DO $$ BEGIN CREATE TYPE "FinancialReconciliationStatus" AS ENUM ('PENDING','RECONCILED','MISSING_INTERNAL','MISSING_PROVIDER','AMOUNT_MISMATCH','CURRENCY_MISMATCH','PROVIDER_FAILED','NOT_APPLICABLE'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE "FinancialSourceType" AS ENUM ('SALE','PAYMENT','REFUND','SUBSCRIPTION'); EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS "FinancialReconciliation" (
  "id" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "sourceType" "FinancialSourceType" NOT NULL,
  "sourceId" TEXT NOT NULL,
  "provider" TEXT,
  "providerRef" TEXT,
  "expectedAmount" DECIMAL(14,2) NOT NULL,
  "providerAmount" DECIMAL(14,2),
  "currency" TEXT NOT NULL DEFAULT 'EGP',
  "status" "FinancialReconciliationStatus" NOT NULL DEFAULT 'PENDING',
  "reason" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FinancialReconciliation_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "FinancialReconciliation_gymId_sourceType_sourceId_key" ON "FinancialReconciliation"("gymId", "sourceType", "sourceId");
CREATE INDEX IF NOT EXISTS "FinancialReconciliation_gymId_status_idx" ON "FinancialReconciliation"("gymId", "status");
CREATE INDEX IF NOT EXISTS "FinancialReconciliation_provider_providerRef_idx" ON "FinancialReconciliation"("provider", "providerRef");

CREATE TABLE IF NOT EXISTS "PaymentProviderEvent" (
  "id" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "eventId" TEXT NOT NULL,
  "eventType" TEXT NOT NULL,
  "payload" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PROCESSED',
  "processedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PaymentProviderEvent_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "PaymentProviderEvent_provider_eventId_key" ON "PaymentProviderEvent"("provider", "eventId");
CREATE INDEX IF NOT EXISTS "PaymentProviderEvent_gymId_processedAt_idx" ON "PaymentProviderEvent"("gymId", "processedAt");
