-- Phase 4: staff/employee management redesign.
-- Staff are captured as discrete labeled fields; phone becomes a real column.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "phone" TEXT;
