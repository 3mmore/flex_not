-- Add ON DELETE CASCADE to Member relations for data integrity

-- Attendance
ALTER TABLE "Attendance" DROP CONSTRAINT IF EXISTS "Attendance_memberId_fkey";
ALTER TABLE "Attendance" ADD CONSTRAINT "Attendance_memberId_fkey"
  FOREIGN KEY ("memberId") REFERENCES "Member"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

-- MemberOtp
ALTER TABLE "MemberOtp" DROP CONSTRAINT IF EXISTS "MemberOtp_memberId_fkey";
ALTER TABLE "MemberOtp" ADD CONSTRAINT "MemberOtp_memberId_fkey"
  FOREIGN KEY ("memberId") REFERENCES "Member"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

-- PtSession
ALTER TABLE "PtSession" DROP CONSTRAINT IF EXISTS "PtSession_memberId_fkey";
ALTER TABLE "PtSession" ADD CONSTRAINT "PtSession_memberId_fkey"
  FOREIGN KEY ("memberId") REFERENCES "Member"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;