-- Migration: Add twoFaLastCode field to User model for TOTP code reuse prevention
-- Date: 2026-06-20
-- Security Fix: Prevents reuse of the same TOTP code within the 90-second acceptance window

ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "twoFaLastCode" TEXT;