-- Duplicate active plans must be cleaned with prisma/deduplicate-plans.ts before deploying this migration.
CREATE UNIQUE INDEX "Plan_gymId_name_type_price_key"
  ON "Plan" ("gymId", "name", "type", "price");
