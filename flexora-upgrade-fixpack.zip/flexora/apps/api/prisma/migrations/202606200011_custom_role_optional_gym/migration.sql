-- Migration: Make CustomRole.gymId nullable to support GLOBAL-scoped roles
-- Date: 2026-06-20
-- Security Fix: Prevents FK violation when gymId is null (platform-level roles)
-- Previously gymId defaulted to 'platform' which is not a valid Gym.id

ALTER TABLE "CustomRole" ALTER COLUMN "gymId" DROP NOT NULL;