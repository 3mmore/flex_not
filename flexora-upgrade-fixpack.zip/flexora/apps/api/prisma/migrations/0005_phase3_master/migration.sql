-- =====================================================================
-- FLEXORA Gym OS — Migration 0005 — Phase 3 MASTER
-- © 2024 Ammar Allam. All rights reserved.
--
-- This migration:
--   1. Extends User model with 2FA columns (Phase 1D)
--   2. Extends PtSession with coach self check-in + notes (Phase 12)
--   3. Extends Subscription with trial fields (Phase 7)
--   4. Extends License with grace / offline / customer fields (Phase 6)
--   5. Adds new tables for Phase 6 / 7 / 8 / 10 / 11 / 13 / 14
--   6. Adds new enums for Phase 10 / 13
--   7. Adds performance indexes for Phase 3
--
-- Idempotent via IF NOT EXISTS where possible.
-- =====================================================================

-- ---------- 2FA on User ----------
ALTER TABLE "User"
  ADD COLUMN IF NOT EXISTS "twoFaEnabled" BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS "twoFaSecret" TEXT,
  ADD COLUMN IF NOT EXISTS "twoFaBackupCodes" TEXT;

-- ---------- PtSession coach self check-in (Phase 12) ----------
ALTER TABLE "PtSession"
  ADD COLUMN IF NOT EXISTS "coachCheckedIn" BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS "coachCheckedInAt" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "coachSessionNotes" TEXT,
  ADD COLUMN IF NOT EXISTS "memberProgress" TEXT,
  ADD COLUMN IF NOT EXISTS "exercisesDone" JSONB,
  ADD COLUMN IF NOT EXISTS "nextSessionPlan" TEXT;

-- ---------- Subscription trial (Phase 7) ----------
ALTER TABLE "Subscription"
  ADD COLUMN IF NOT EXISTS "trialStartDate" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "trialEndDate" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "trialDays" INTEGER NOT NULL DEFAULT 14,
  ADD COLUMN IF NOT EXISTS "isTrialUsed" BOOLEAN NOT NULL DEFAULT FALSE;

-- ---------- License commercial fields (Phase 6) ----------
ALTER TABLE "License"
  ADD COLUMN IF NOT EXISTS "customerName" TEXT,
  ADD COLUMN IF NOT EXISTS "customerEmail" TEXT,
  ADD COLUMN IF NOT EXISTS "customerPhone" TEXT,
  ADD COLUMN IF NOT EXISTS "gracePeriodDays" INTEGER NOT NULL DEFAULT 7,
  ADD COLUMN IF NOT EXISTS "lastValidatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN IF NOT EXISTS "offlineGraceDays" INTEGER NOT NULL DEFAULT 3;

-- =====================================================================
-- New enums (Phase 10 / 13)
-- =====================================================================

DO $$ BEGIN
  CREATE TYPE "LeadStatus" AS ENUM ('NEW', 'CONTACTED', 'INTERESTED', 'TRIAL_BOOKED', 'CONVERTED', 'LOST');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE "LeadSource" AS ENUM ('WALK_IN', 'REFERRAL', 'SOCIAL_MEDIA', 'WEBSITE', 'WHATSAPP', 'INVITATION', 'OTHER');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE "LeadPriority" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'HOT');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE "FollowUpType" AS ENUM ('CALL', 'WHATSAPP', 'EMAIL', 'VISIT', 'TRIAL');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE "FollowUpOutcome" AS ENUM ('PENDING', 'SUCCESS', 'NO_RESPONSE', 'NOT_INTERESTED', 'SCHEDULED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE "CampaignStatus" AS ENUM ('DRAFT', 'SCHEDULED', 'SENDING', 'COMPLETED', 'CANCELLED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- =====================================================================
-- New tables
-- =====================================================================

-- BiometricCredential (Phase 11)
CREATE TABLE IF NOT EXISTS "BiometricCredential" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "memberId" TEXT NOT NULL,
  "credentialId" TEXT NOT NULL,
  "publicKey" TEXT NOT NULL,
  "counter" BIGINT NOT NULL DEFAULT 0,
  "deviceName" TEXT,
  "lastUsedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "BiometricCredential_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE,
  CONSTRAINT "BiometricCredential_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "BiometricCredential_credentialId_key" ON "BiometricCredential"("credentialId");
CREATE INDEX IF NOT EXISTS "BiometricCredential_gymId_idx" ON "BiometricCredential"("gymId");
CREATE INDEX IF NOT EXISTS "BiometricCredential_memberId_idx" ON "BiometricCredential"("memberId");

-- Lead (Phase 10)
CREATE TABLE IF NOT EXISTS "Lead" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "branchId" TEXT,
  "name" TEXT NOT NULL,
  "mobile" TEXT NOT NULL,
  "email" TEXT,
  "source" "LeadSource" NOT NULL DEFAULT 'WALK_IN',
  "status" "LeadStatus" NOT NULL DEFAULT 'NEW',
  "priority" "LeadPriority" NOT NULL DEFAULT 'MEDIUM',
  "interestedPlanId" TEXT,
  "notes" TEXT,
  "assignedTo" TEXT,
  "aiScore" INTEGER,
  "aiRecommendation" TEXT,
  "lastContactAt" TIMESTAMP(3),
  "nextFollowUpAt" TIMESTAMP(3),
  "convertedMemberId" TEXT,
  "convertedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Lead_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "Lead_gymId_status_idx" ON "Lead"("gymId", "status");
CREATE INDEX IF NOT EXISTS "Lead_gymId_createdAt_idx" ON "Lead"("gymId", "createdAt");
CREATE INDEX IF NOT EXISTS "Lead_gymId_priority_idx" ON "Lead"("gymId", "priority");
CREATE INDEX IF NOT EXISTS "Lead_gymId_mobile_idx" ON "Lead"("gymId", "mobile");

-- LeadFollowUp (Phase 10)
CREATE TABLE IF NOT EXISTS "LeadFollowUp" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "leadId" TEXT NOT NULL,
  "type" "FollowUpType" NOT NULL,
  "outcome" "FollowUpOutcome" NOT NULL DEFAULT 'PENDING',
  "message" TEXT,
  "scheduledAt" TIMESTAMP(3),
  "completedAt" TIMESTAMP(3),
  "createdBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "LeadFollowUp_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE,
  CONSTRAINT "LeadFollowUp_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "LeadFollowUp_gymId_idx" ON "LeadFollowUp"("gymId");
CREATE INDEX IF NOT EXISTS "LeadFollowUp_leadId_idx" ON "LeadFollowUp"("leadId");

-- MemberContract (Phase 13)
CREATE TABLE IF NOT EXISTS "MemberContract" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "memberId" TEXT NOT NULL,
  "contractNo" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "bodyMd" TEXT NOT NULL,
  "signedAt" TIMESTAMP(3),
  "signatureSvg" TEXT,
  "pdfUrl" TEXT,
  "whatsappSent" BOOLEAN NOT NULL DEFAULT FALSE,
  "whatsappSentAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MemberContract_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE,
  CONSTRAINT "MemberContract_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "MemberContract_gymId_contractNo_key" ON "MemberContract"("gymId", "contractNo");
CREATE INDEX IF NOT EXISTS "MemberContract_gymId_idx" ON "MemberContract"("gymId");
CREATE INDEX IF NOT EXISTS "MemberContract_memberId_idx" ON "MemberContract"("memberId");

-- Campaign (Phase 13)
CREATE TABLE IF NOT EXISTS "Campaign" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "channel" "NotifyChannel" NOT NULL,
  "templateKey" TEXT,
  "body" TEXT NOT NULL,
  "audienceFilter" JSONB,
  "scheduledAt" TIMESTAMP(3),
  "status" "CampaignStatus" NOT NULL DEFAULT 'DRAFT',
  "statsSent" INTEGER NOT NULL DEFAULT 0,
  "statsFailed" INTEGER NOT NULL DEFAULT 0,
  "createdBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Campaign_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "Campaign_gymId_status_idx" ON "Campaign"("gymId", "status");
CREATE INDEX IF NOT EXISTS "Campaign_gymId_scheduledAt_idx" ON "Campaign"("gymId", "scheduledAt");

-- StaffAttendance (Phase 13)
CREATE TABLE IF NOT EXISTS "StaffAttendance" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "branchId" TEXT,
  "checkInAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "checkOutAt" TIMESTAMP(3),
  "method" "CheckinMethod" NOT NULL DEFAULT 'MANUAL',
  "notes" TEXT,
  CONSTRAINT "StaffAttendance_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "StaffAttendance_gymId_checkInAt_idx" ON "StaffAttendance"("gymId", "checkInAt");
CREATE INDEX IF NOT EXISTS "StaffAttendance_userId_idx" ON "StaffAttendance"("userId");

-- SaasPlan (Phase 8)
CREATE TABLE IF NOT EXISTS "SaasPlan" (
  "id" TEXT PRIMARY KEY,
  "slug" TEXT NOT NULL UNIQUE,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "tier" "SubscriptionTier" NOT NULL,
  "monthlyPrice" DECIMAL(10,2) NOT NULL,
  "yearlyPrice" DECIMAL(10,2) NOT NULL,
  "maxBranches" INTEGER NOT NULL DEFAULT 1,
  "maxMembers" INTEGER NOT NULL DEFAULT 500,
  "maxStaff" INTEGER NOT NULL DEFAULT 5,
  "features" JSONB NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT TRUE,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- SuperAdmin (Phase 9) — separate identity row for platform admins
-- (kept alongside User.role=SUPER_ADMIN for backwards compatibility).
CREATE TABLE IF NOT EXISTS "SuperAdmin" (
  "id" TEXT PRIMARY KEY,
  "email" TEXT NOT NULL UNIQUE,
  "passwordHash" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT TRUE,
  "lastLoginAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ReportCache (Phase 4C)
CREATE TABLE IF NOT EXISTS "ReportCache" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "reportKey" TEXT NOT NULL,
  "data" JSONB NOT NULL,
  "computedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ReportCache_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "ReportCache_gymId_reportKey_key" ON "ReportCache"("gymId", "reportKey");
CREATE INDEX IF NOT EXISTS "ReportCache_gymId_idx" ON "ReportCache"("gymId");
CREATE INDEX IF NOT EXISTS "ReportCache_expiresAt_idx" ON "ReportCache"("expiresAt");

-- LicenseRenewal (Phase 6)
CREATE TABLE IF NOT EXISTS "LicenseRenewal" (
  "id" TEXT PRIMARY KEY,
  "gymId" TEXT NOT NULL,
  "licenseId" TEXT NOT NULL,
  "previousKey" TEXT NOT NULL,
  "newKey" TEXT NOT NULL,
  "renewedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "renewedBy" TEXT,
  "durationDays" INTEGER NOT NULL DEFAULT 365,
  "notes" TEXT,
  CONSTRAINT "LicenseRenewal_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "LicenseRenewal_gymId_idx" ON "LicenseRenewal"("gymId");

-- =====================================================================
-- Performance indexes (Phase 3A)
-- =====================================================================

-- Attendance
CREATE INDEX IF NOT EXISTS "Attendance_gymId_at_brin_idx" ON "Attendance"("gymId", "at" DESC);
CREATE INDEX IF NOT EXISTS "Attendance_gymId_memberId_at_idx" ON "Attendance"("gymId", "memberId", "at" DESC);
CREATE INDEX IF NOT EXISTS "Attendance_branchId_at_idx" ON "Attendance"("branchId", "at" DESC) WHERE "branchId" IS NOT NULL;

-- Sales
CREATE INDEX IF NOT EXISTS "Sale_gymId_createdAt_branchId_idx" ON "Sale"("gymId", "createdAt" DESC, "branchId");
CREATE INDEX IF NOT EXISTS "Sale_gymId_memberId_idx" ON "Sale"("gymId", "memberId") WHERE "memberId" IS NOT NULL;

-- Notifications
CREATE INDEX IF NOT EXISTS "Notification_gymId_status_createdAt_idx" ON "Notification"("gymId", "status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "Notification_gymId_channel_idx" ON "Notification"("gymId", "channel");

-- Member
CREATE INDEX IF NOT EXISTS "Member_gymId_vip_idx" ON "Member"("gymId", "vip") WHERE "vip" = TRUE;
CREATE INDEX IF NOT EXISTS "Member_gymId_expiry_idx" ON "Member"("gymId", "expiry") WHERE "expiry" IS NOT NULL;
CREATE INDEX IF NOT EXISTS "Member_gymId_lastVisit_idx" ON "Member"("gymId", "lastVisit" DESC) WHERE "lastVisit" IS NOT NULL;

-- Invitation
CREATE INDEX IF NOT EXISTS "Invitation_gymId_status_visitDate_idx" ON "Invitation"("gymId", "status", "visitDate" DESC);

-- Transaction
CREATE INDEX IF NOT EXISTS "Transaction_gymId_type_createdAt_idx" ON "Transaction"("gymId", "type", "createdAt" DESC);

-- AuditLog
CREATE INDEX IF NOT EXISTS "AuditLog_gymId_action_createdAt_idx" ON "AuditLog"("gymId", "action", "createdAt" DESC);

-- User
CREATE INDEX IF NOT EXISTS "User_gymId_role_idx" ON "User"("gymId", "role") WHERE "gymId" IS NOT NULL;

-- Expense
CREATE INDEX IF NOT EXISTS "Expense_gymId_category_createdAt_idx" ON "Expense"("gymId", "category", "createdAt" DESC);

-- ClassSession
CREATE INDEX IF NOT EXISTS "ClassSession_gymId_status_startsAt_idx" ON "ClassSession"("gymId", "status", "startsAt" DESC);

-- PtSession
CREATE INDEX IF NOT EXISTS "PtSession_gymId_status_scheduledAt_idx" ON "PtSession"("gymId", "status", "scheduledAt" DESC);
