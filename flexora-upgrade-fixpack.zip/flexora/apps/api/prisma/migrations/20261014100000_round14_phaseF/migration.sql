-- ROUND 14 (security review, PHASE F) — portal renewal requests + the
-- owner-level integrations/branding switch.
--
-- F1: the member portal "Renew" action must never extend the membership for
-- free. It creates a RenewalRequest row instead; the membership is extended
-- only by the normal paid staff renewal flow or by a verified online-provider
-- webhook (one extension per payment).
--
-- F4: managersMayChangeIntegrations — owner-level switch (default OFF). When
-- OFF, the integrations & branding endpoints require the OWNER even for
-- MANAGERs holding settings.manage.

CREATE TYPE "RenewalRequestStatus" AS ENUM ('PENDING', 'CHECKOUT', 'PAID', 'CONFIRMED', 'CANCELLED');

CREATE TABLE "RenewalRequest" (
  "id" TEXT NOT NULL,
  "gymId" TEXT NOT NULL,
  "memberId" TEXT NOT NULL,
  "planId" TEXT NOT NULL,
  "status" "RenewalRequestStatus" NOT NULL DEFAULT 'PENDING',
  "amount" DECIMAL(14,2) NOT NULL,
  "providerRef" TEXT,
  "checkoutUrl" TEXT,
  "invoiceId" TEXT,
  "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "decidedAt" TIMESTAMP(3),
  "decidedBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "RenewalRequest_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "RenewalRequest_gymId_memberId_idx" ON "RenewalRequest"("gymId", "memberId");
CREATE INDEX "RenewalRequest_gymId_status_idx" ON "RenewalRequest"("gymId", "status");
CREATE INDEX "RenewalRequest_providerRef_idx" ON "RenewalRequest"("providerRef");

ALTER TABLE "RenewalRequest" ADD CONSTRAINT "RenewalRequest_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "RenewalRequest" ADD CONSTRAINT "RenewalRequest_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "RenewalRequest" ADD CONSTRAINT "RenewalRequest_planId_fkey" FOREIGN KEY ("planId") REFERENCES "Plan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Tenant isolation, same policy shape as the other gymId tables.
ALTER TABLE "RenewalRequest" ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = current_schema() AND tablename = 'RenewalRequest' AND policyname = 'RenewalRequest_tenant_isolation') THEN
    CREATE POLICY "RenewalRequest_tenant_isolation" ON "RenewalRequest"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
END $$;

-- F4: the owner-level switch (default OFF — managers may NOT change
-- integrations & branding unless the owner explicitly allows it).
ALTER TABLE "Gym" ADD COLUMN IF NOT EXISTS "managersMayChangeIntegrations" BOOLEAN NOT NULL DEFAULT false;
