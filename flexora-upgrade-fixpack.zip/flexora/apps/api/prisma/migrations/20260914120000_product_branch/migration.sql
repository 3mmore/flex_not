-- PHASE 8 — products get a real branch assignment.
-- Nullable on purpose: rows created before this migration keep working and are
-- reported as "not assigned" instead of being silently attributed to a branch.
ALTER TABLE "Product" ADD COLUMN "branchId" TEXT;
CREATE INDEX "Product_branchId_idx" ON "Product"("branchId");
ALTER TABLE "Product" ADD CONSTRAINT "Product_branchId_fkey"
  FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;
