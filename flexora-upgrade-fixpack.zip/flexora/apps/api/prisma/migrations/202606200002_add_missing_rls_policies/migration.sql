ALTER TABLE "GymMessagingConfig" ADD COLUMN IF NOT EXISTS "whatsappVerifyToken" TEXT;

ALTER TABLE "GymMessagingConfig" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AiSuggestion" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AiChatMessage" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ProductEvent" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'GymMessagingConfig' AND policyname = 'GymMessagingConfig_tenant_isolation') THEN
    CREATE POLICY "GymMessagingConfig_tenant_isolation" ON "GymMessagingConfig"
    USING ("gymId" = current_setting('app.gym_id', true))
    WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'AiSuggestion' AND policyname = 'AiSuggestion_tenant_isolation') THEN
    CREATE POLICY "AiSuggestion_tenant_isolation" ON "AiSuggestion"
    USING ("gymId" = current_setting('app.gym_id', true))
    WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'AiChatMessage' AND policyname = 'AiChatMessage_tenant_isolation') THEN
    CREATE POLICY "AiChatMessage_tenant_isolation" ON "AiChatMessage"
    USING ("gymId" = current_setting('app.gym_id', true))
    WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'GymSubscription') AND NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'GymSubscription' AND policyname = 'GymSubscription_tenant_isolation') THEN
    CREATE POLICY "GymSubscription_tenant_isolation" ON "GymSubscription"
    USING ("gymId" = current_setting('app.gym_id', true))
    WITH CHECK ("gymId" = current_setting('app.gym_id', true));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'ProductEvent' AND policyname = 'ProductEvent_tenant_isolation') THEN
    -- FIX (found during the CI/closure hardening sweep, corrected again
    -- during Task 2's migration-history fix): this policy originally
    -- referenced a "tenantId" column. At the time this migration was first
    -- written, "ProductEvent" still had a column literally named "tenantId"
    -- (see 0008_product_event_backbone/migration.sql). A LATER migration,
    -- 202606200004_data_layer_security, renames that column to "gymId"
    -- (`ALTER TABLE "ProductEvent" RENAME COLUMN "tenantId" TO "gymId"`) to
    -- match every other tenant table's convention — but that rename has
    -- NOT happened yet at the point this migration runs, in true
    -- sequential order. An earlier fix in this same file (during the
    -- CI/closure sweep) hardcoded "gymId" here, which is only correct for
    -- the CI workaround's execution order (db push, which builds the FINAL
    -- schema shape directly, then replays 202606200001/202606200002/
    -- 202606200006 out of full sequence, skipping 202606200003 and
    -- 202606200004 in between) — it is WRONG for a genuine, complete,
    -- sequential `prisma migrate deploy` run (confirmed directly: running
    -- migrate deploy against a fresh DB fails here with `column "gymId"
    -- does not exist` once the earlier missing-table/-column gaps fixed by
    -- 0015_missing_table_creates are in place and this migration is
    -- finally reached in true order). FIX: detect which column actually
    -- exists at the moment this statement runs and use that one — this
    -- makes the migration correct under BOTH execution paths (true
    -- sequential `migrate deploy`, where the column is still "tenantId"
    -- here; and the CI workaround's out-of-full-sequence replay against an
    -- already-fully-shaped db-push schema, where it is already "gymId").
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'ProductEvent' AND column_name = 'gymId') THEN
      CREATE POLICY "ProductEvent_tenant_isolation" ON "ProductEvent"
      USING ("gymId" = current_setting('app.gym_id', true))
      WITH CHECK ("gymId" = current_setting('app.gym_id', true));
    ELSE
      CREATE POLICY "ProductEvent_tenant_isolation" ON "ProductEvent"
      USING ("tenantId" = current_setting('app.gym_id', true))
      WITH CHECK ("tenantId" = current_setting('app.gym_id', true));
    END IF;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'AuditLog' AND policyname = 'AuditLog_platform_access') THEN
    CREATE POLICY "AuditLog_platform_access" ON "AuditLog"
    USING ("gymId" IS NULL)
    WITH CHECK ("gymId" IS NULL);
  END IF;
END $$;
