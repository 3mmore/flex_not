-- ===========================================================================
-- FLEXORA Gym OS - PHASE R4 (R4.9): server-side sorting for the console gyms list.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- WHY A MIGRATION AND NOT A CODE CHANGE. The gyms list does not read the Gym table directly:
-- PHASE R2 decision Q2 moved it behind public.platform_list_gyms, a SECURITY DEFINER aggregate
-- function that returns only the allowlisted columns. Sorting after the function returns would
-- mean sorting ONE PAGE of 25, which is not sorting at all - page 2 would still contain rows
-- that belong on page 1. So the ORDER BY has to move into the function, and the function is
-- database code.
--
-- WHY A CASE LADDER AND NOT DYNAMIC SQL. p_sort and p_dir arrive from a query string. Building
-- "ORDER BY " || p_sort would be SQL injection through a SECURITY DEFINER function, which is the
-- worst possible place to have it: the function runs as its owner and can see every tenant's
-- rows. A CASE ladder can only ever order by an expression written here at migration time, so an
-- unrecognised p_sort simply matches no branch and contributes nothing. The controller also
-- whitelists the values before they arrive; this is the second, database-side guarantee, and it
-- is the one that holds if a future caller forgets.
--
-- THE TIEBREAKER IS NOT DECORATION. Ordering by a non-unique column (name, status, or a
-- subscription date that is NULL for gyms with no subscription) leaves the order of ties up to
-- the planner, and the planner is free to choose differently between two executions. With LIMIT
-- and OFFSET that means a row can appear on two pages, or on neither. Appending g.id makes the
-- total order deterministic, which is what makes OFFSET pagination correct at all.
--
-- NULLS LAST on every branch so a gym with no subscription sorts consistently in both
-- directions rather than flipping between the top and the bottom.
--
-- Both new parameters have DEFAULTs, so every existing five-argument call keeps working - and
-- the five-argument overload is then dropped, because leaving it would make a five-argument call
-- ambiguous between two functions that both match.
--
-- R2 convention preserved exactly: LANGUAGE sql, STABLE, SECURITY DEFINER, search_path pinned to
-- pg_catalog and public, every parameter typed, EXECUTE revoked from PUBLIC and granted only to
-- the runtime role. scripts/check-db-compat.sh re-run after this migration.
-- ===========================================================================

BEGIN;

CREATE OR REPLACE FUNCTION public.platform_list_gyms(
  p_status text,
  p_search text,
  p_tier   text,
  p_limit  integer,
  p_offset integer,
  p_sort   text DEFAULT 'createdAt',
  p_dir    text DEFAULT 'desc'
)
RETURNS TABLE (
  gym_id              text,
  gym_name            text,
  gym_slug            text,
  gym_status          text,
  gym_email           text,
  gym_phone           text,
  gym_address         text,
  gym_logo            text,
  gym_accent_color    text,
  member_count        integer,
  user_count          integer,
  branch_count        integer,
  owner_name          text,
  owner_phone         text,
  sub_tier            text,
  subscription_status text,
  current_period_start timestamp(3),
  current_period_end  timestamp(3),
  trial_start_date    timestamp(3),
  trial_end_date      timestamp(3),
  trial_days          integer,
  is_trial_used       boolean,
  cancel_at_period_end boolean,
  last_payment_at     timestamp(3),
  last_payment_amount integer,
  created_at          timestamp(3),
  updated_at          timestamp(3),
  deleted_at          timestamp(3)
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT g.id,
         g.name,
         g.slug,
         g.status::text,
         g.email,
         g.phone,
         g.address,
         g.logo,
         g."accentColor",
         (SELECT COUNT(*)::integer FROM public."Member" m  WHERE m."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."User"   u  WHERE u."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."Branch" b  WHERE b."gymId" = g.id),
         o.name,
         o.phone,
         s.tier::text,
         s.status::text,
         s."currentPeriodStart",
         s."currentPeriodEnd",
         s."trialStartDate",
         s."trialEndDate",
         s."trialDays",
         s."isTrialUsed",
         s."cancelAtPeriodEnd",
         s."lastPaymentAt",
         s."lastPaymentAmount",
         g."createdAt",
         g."updatedAt",
         g."deletedAt"
    FROM public."Gym" g
    LEFT JOIN LATERAL (
           SELECT u.name, u.phone
             FROM public."User" u
            WHERE u."gymId" = g.id
              AND u.role = 'OWNER'
            ORDER BY u."createdAt" ASC
            LIMIT 1
         ) o ON true
    LEFT JOIN public."Subscription" s ON s."gymId" = g.id
   WHERE (p_status IS NULL OR g.status::text = p_status)
     -- decision Q1: a DELETED gym leaves the default list but stays reachable by an
     -- explicit status filter, so the console can still restore it.
     AND (p_status IS NOT NULL OR g.status::text <> 'DELETED')
     AND (p_tier IS NULL OR s.tier::text = p_tier)
     AND (p_search IS NULL
          OR g.name  ILIKE '%' || p_search || '%'
          OR g.slug  ILIKE '%' || p_search || '%'
          OR g.email ILIKE '%' || p_search || '%')
   -- PHASE R4 (R4.9). Four sortable columns, each in both directions, as a CASE ladder so no
   -- part of this ORDER BY can be influenced by the caller's string beyond selecting a branch
   -- that already exists. An unrecognised p_sort matches nothing and falls through to the
   -- tiebreaker, which is a stable order rather than an error.
   ORDER BY
     CASE WHEN p_sort = 'name'             AND p_dir = 'asc'  THEN g.name                END ASC  NULLS LAST,
     CASE WHEN p_sort = 'name'             AND p_dir = 'desc' THEN g.name                END DESC NULLS LAST,
     CASE WHEN p_sort = 'status'           AND p_dir = 'asc'  THEN g.status::text        END ASC  NULLS LAST,
     CASE WHEN p_sort = 'status'           AND p_dir = 'desc' THEN g.status::text        END DESC NULLS LAST,
     CASE WHEN p_sort = 'currentPeriodEnd' AND p_dir = 'asc'  THEN s."currentPeriodEnd"  END ASC  NULLS LAST,
     CASE WHEN p_sort = 'currentPeriodEnd' AND p_dir = 'desc' THEN s."currentPeriodEnd"  END DESC NULLS LAST,
     CASE WHEN p_sort = 'memberCount'      AND p_dir = 'asc'
          THEN (SELECT COUNT(*)::integer FROM public."Member" m WHERE m."gymId" = g.id)  END ASC  NULLS LAST,
     CASE WHEN p_sort = 'memberCount'      AND p_dir = 'desc'
          THEN (SELECT COUNT(*)::integer FROM public."Member" m WHERE m."gymId" = g.id)  END DESC NULLS LAST,
     CASE WHEN p_sort = 'createdAt'        AND p_dir = 'asc'  THEN g."createdAt"         END ASC  NULLS LAST,
     CASE WHEN p_sort = 'createdAt'        AND p_dir = 'desc' THEN g."createdAt"         END DESC NULLS LAST,
     g.id ASC
   LIMIT p_limit OFFSET p_offset;
$fn$;

-- Drop the five-argument overload. Leaving it in place would make a five-argument call
-- ambiguous, because the new signature's two extra parameters have defaults and so also match.
DROP FUNCTION IF EXISTS public.platform_list_gyms(text, text, text, integer, integer);

-- R2 convention: EXECUTE is not PUBLIC's, and the runtime role is named explicitly. A
-- deployment whose runtime role is not called flexora_app must adjust this GRANT;
-- scripts/check-db-compat.sh exercises the supported owner profiles.
REVOKE ALL ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer, text, text) TO flexora_app;

COMMIT;
