-- ===========================================================================
-- FLEXORA Gym OS - PHASE R4 (R4.9) rollback: put platform_list_gyms back to the
-- five-argument R2 form with its fixed ORDER BY g."createdAt" DESC.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- One explicit transaction block, so `psql --single-transaction -f down.sql` is all or
-- nothing. A half-applied rollback here would leave the console's gyms list calling a
-- signature that no longer exists, which is worse than either end state - the same lesson
-- the R3 down.sql files were rewritten for.
--
-- No data is touched: this changes one function definition and its grants.
-- ===========================================================================

BEGIN;

DROP FUNCTION IF EXISTS public.platform_list_gyms(text, text, text, integer, integer, text, text);

CREATE OR REPLACE FUNCTION public.platform_list_gyms(
  p_status text,
  p_search text,
  p_tier   text,
  p_limit  integer,
  p_offset integer
)
RETURNS TABLE (
  gym_id              text,
  gym_name            text,
  gym_slug            text,
  gym_status          text,
  gym_email           text,
  gym_phone           text,
  gym_address         text,
  gym_logo            text,
  gym_accent_color    text,
  member_count        integer,
  user_count          integer,
  branch_count        integer,
  owner_name          text,
  owner_phone         text,
  sub_tier            text,
  subscription_status text,
  current_period_start timestamp(3),
  current_period_end  timestamp(3),
  trial_start_date    timestamp(3),
  trial_end_date      timestamp(3),
  trial_days          integer,
  is_trial_used       boolean,
  cancel_at_period_end boolean,
  last_payment_at     timestamp(3),
  last_payment_amount integer,
  created_at          timestamp(3),
  updated_at          timestamp(3),
  deleted_at          timestamp(3)
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT g.id,
         g.name,
         g.slug,
         g.status::text,
         g.email,
         g.phone,
         g.address,
         g.logo,
         g."accentColor",
         (SELECT COUNT(*)::integer FROM public."Member" m  WHERE m."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."User"   u  WHERE u."gymId" = g.id),
         (SELECT COUNT(*)::integer FROM public."Branch" b  WHERE b."gymId" = g.id),
         o.name,
         o.phone,
         s.tier::text,
         s.status::text,
         s."currentPeriodStart",
         s."currentPeriodEnd",
         s."trialStartDate",
         s."trialEndDate",
         s."trialDays",
         s."isTrialUsed",
         s."cancelAtPeriodEnd",
         s."lastPaymentAt",
         s."lastPaymentAmount",
         g."createdAt",
         g."updatedAt",
         g."deletedAt"
    FROM public."Gym" g
    LEFT JOIN LATERAL (
           SELECT u.name, u.phone
             FROM public."User" u
            WHERE u."gymId" = g.id
              AND u.role = 'OWNER'
            ORDER BY u."createdAt" ASC
            LIMIT 1
         ) o ON true
    LEFT JOIN public."Subscription" s ON s."gymId" = g.id
   WHERE (p_status IS NULL OR g.status::text = p_status)
     AND (p_status IS NOT NULL OR g.status::text <> 'DELETED')
     AND (p_tier IS NULL OR s.tier::text = p_tier)
     AND (p_search IS NULL
          OR g.name  ILIKE '%' || p_search || '%'
          OR g.slug  ILIKE '%' || p_search || '%'
          OR g.email ILIKE '%' || p_search || '%')
   ORDER BY g."createdAt" DESC
   LIMIT p_limit OFFSET p_offset;
$fn$;

REVOKE ALL ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_list_gyms(text, text, text, integer, integer) TO flexora_app;

COMMIT;
