-- =============================================================================
-- FLEXORA PHASE R3 - DOWN migration for 20261107120000_platform_audit_chain_r3.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- Prisma does not execute down migrations, so this file is applied by hand:
--     psql "$DATABASE_ADMIN_URL" -v ON_ERROR_STOP=1 --single-transaction \
--       -f apps/api/prisma/migrations/20261107120000_platform_audit_chain_r3/down.sql
-- It is tested on a COPY of the database (owner decision A2.6), never on the live one,
-- and the test asserts the table is byte-for-byte back to its pre-R3 shape: the same
-- eight columns, the same nullability, no user-defined triggers, and no R3 functions.
--
-- ROLLING BACK DESTROYS THE TAMPER EVIDENCE. Once these columns are dropped, nothing
-- remains that could prove the log was not edited. This exists so a deployment can
-- recover from a bad upgrade, not as a routine operation.
--
-- The order matters: the triggers must go before the columns they read, and the
-- append-only triggers must go before anything that would need to modify a row.
-- =============================================================================

--
-- THIS FILE IS ONE EXPLICIT TRANSACTION. It was written without one first and failed on
-- the LOCK with "LOCK TABLE can only be used in transaction blocks", because psql runs
-- each statement in its own implicit transaction unless told otherwise. Atomicity is not
-- cosmetic here: a rollback that dropped the append-only triggers but kept the chain
-- columns would leave the table writable and unverifiable at the same time.

BEGIN;

LOCK TABLE public."PlatformAuditLog" IN ACCESS EXCLUSIVE MODE;

-- 1. Triggers first.
DROP TRIGGER IF EXISTS "PlatformAuditLog_no_update"    ON public."PlatformAuditLog";
DROP TRIGGER IF EXISTS "PlatformAuditLog_no_delete"    ON public."PlatformAuditLog";
DROP TRIGGER IF EXISTS "PlatformAuditLog_chain_assign" ON public."PlatformAuditLog";

-- 2. Indexes added by the up migration.
DROP INDEX IF EXISTS public."PlatformAuditLog_createdAt_seq_idx";
DROP INDEX IF EXISTS public."PlatformAuditLog_seq_key";

-- 3. Functions. CASCADE is not used: nothing else may depend on these, and if something
--    does, this file should fail rather than silently drop a dependent object.
DROP FUNCTION IF EXISTS public.platform_audit_verify();
DROP FUNCTION IF EXISTS public.platform_audit_append_only();
DROP FUNCTION IF EXISTS public.platform_audit_chain_assign();
DROP FUNCTION IF EXISTS public.platform_audit_hash(
    integer, text, text, text, text, jsonb, jsonb, jsonb,
    text, text, text, boolean, timestamp(3), text);
DROP FUNCTION IF EXISTS public.platform_audit_genesis_hash();
DROP FUNCTION IF EXISTS public.platform_audit_field(text);

-- 4. Columns. Dropping a column is DDL, so the append-only triggers would not have
--    fired anyway; they are gone by now regardless.
ALTER TABLE public."PlatformAuditLog"
  DROP COLUMN IF EXISTS "seq",
  DROP COLUMN IF EXISTS "hash",
  DROP COLUMN IF EXISTS "prevHash",
  DROP COLUMN IF EXISTS "reason",
  DROP COLUMN IF EXISTS "userAgent",
  DROP COLUMN IF EXISTS "beforeState",
  DROP COLUMN IF EXISTS "afterState",
  DROP COLUMN IF EXISTS "stepUpUsed";

-- 5. Assert the table is back to its pre-R3 state. A failure here means the down
--    migration did not do its job, and the operator must not assume it did.
DO $do$
DECLARE
  v_cols     bigint;
  v_triggers bigint;
  v_funcs    bigint;
  v_names    text;
BEGIN
  SELECT count(*), string_agg(column_name, ',' ORDER BY ordinal_position)
    INTO v_cols, v_names
    FROM information_schema.columns
   WHERE table_schema = 'public' AND table_name = 'PlatformAuditLog';

  IF v_cols <> 8 OR v_names <> 'id,adminId,adminName,action,target,details,ip,createdAt' THEN
    RAISE EXCEPTION
      'PHASE R3 down-migration left the wrong column set (% columns: %); expected 8: id,adminId,adminName,action,target,details,ip,createdAt',
      v_cols, v_names
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;

  SELECT count(*) INTO v_triggers
    FROM pg_trigger t
   WHERE t.tgrelid = 'public."PlatformAuditLog"'::regclass AND NOT t.tgisinternal;

  IF v_triggers <> 0 THEN
    RAISE EXCEPTION 'PHASE R3 down-migration left % user-defined trigger(s) behind', v_triggers
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;

  SELECT count(*) INTO v_funcs
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
   WHERE n.nspname = 'public' AND p.proname LIKE 'platform_audit_%';

  IF v_funcs <> 0 THEN
    RAISE EXCEPTION 'PHASE R3 down-migration left % platform_audit_* function(s) behind', v_funcs
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;
END
$do$;

COMMIT;
