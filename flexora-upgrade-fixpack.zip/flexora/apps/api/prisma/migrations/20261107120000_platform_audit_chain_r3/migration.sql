-- =============================================================================
-- FLEXORA PHASE R3 - migration 1 of 2: the append-only, hash-chained audit log.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- WHAT THIS DOES
--   1. Locks public."PlatformAuditLog" ACCESS EXCLUSIVE for the whole migration, so no
--      write can slip in between the steps (owner decision A2.1).
--   2. Adds the chain columns (seq, hash, prevHash) NULLABLE, plus the four R3 content
--      columns (reason, userAgent, stepUpUsed, beforeState, afterState).
--   3. Backfills the chain over every row that already exists, in (createdAt, id) order,
--      with ONE set-based statement (owner decisions A2.1 and A2.7).
--   4. Asserts that nothing pre-existing changed: same row count and same checksum of
--      the eight original columns, computed before and after. Any mismatch raises and
--      the whole migration rolls back (owner decision A2.2).
--   5. Sets NOT NULL on the chain columns and makes seq unique.
--   6. Installs the BEFORE INSERT trigger that assigns seq, prevHash and hash.
--   7. Installs the BEFORE UPDATE and BEFORE DELETE triggers that refuse the operation
--      for EVERY role (owner decision A1).
--   8. Installs the read-only verification function.
--
-- THE ORDERING IS LOAD-BEARING. The backfill in step 3 is an UPDATE, so it must run
-- before step 7 installs the trigger that refuses UPDATE. Step 4's assertion must run
-- before step 5 makes the columns NOT NULL, so a partial backfill aborts on the
-- assertion rather than on a constraint.
--
-- -----------------------------------------------------------------------------
-- THE HASH SCHEME, DOCUMENTED (owner decision A2.3)
-- -----------------------------------------------------------------------------
-- There is exactly ONE hash function, public.platform_audit_hash(), and it is used by
-- the backfill, by the BEFORE INSERT trigger and by the verification function. No
-- application code computes an audit hash, so there is no second implementation to
-- drift out of agreement; the test that they agree exercises the same row through the
-- backfill path and the trigger path and compares the results.
--
-- Domain prefix:   'flexora.platform.audit.v1|'
-- Fields, in this exact order:
--    1  seq           integer, rendered as decimal text. integer and not bigint on
--                      purpose: Prisma maps bigint to a JS BigInt, and JSON.stringify
--                      throws on BigInt, which would put a trap in every audit route,
--                      the CSV export and every test that reads a seq. At a thousand
--                      audit rows a day an integer seq lasts about 5,900 years.
--    2  adminId       text
--    3  adminName     text
--    4  action        text
--    5  target        text
--    6  details       jsonb, rendered as jsonb::text
--    7  beforeState   jsonb, rendered as jsonb::text
--    8  afterState    jsonb, rendered as jsonb::text
--    9  reason        text
--   10  ip            text
--   11  userAgent     text
--   12  stepUpUsed    boolean, rendered as 'true' or 'false'
--   13  createdAt     timestamp(3), rendered by to_char as
--                     'YYYY-MM-DD"T"HH24:MI:SS.MS' - always exactly three decimals.
--                     Prisma stores this column as UTC, so no zone conversion is
--                     applied and none may be added without invalidating the chain.
--   14  prevHash      text
--
-- NULL handling: every field is encoded by public.platform_audit_field(text) as
--   NULL      ->  'n'
--   non-NULL  ->  'v' || octet_length(value) || ':' || value
-- The length prefix makes the encoding injective, so no two distinct rows can produce
-- the same canonical string and no field boundary can be forged by embedding the
-- separator in a value. There is no separator between fields for the same reason.
--
-- JSON handling: jsonb columns are hashed as their jsonb::text rendering. Postgres
-- normalises jsonb on write (keys ordered by length then bytewise, insignificant
-- whitespace removed, duplicate keys collapsed), so the same logical value always
-- renders byte-identically. A third party re-verifying offline must use the same
-- normalisation; these functions are exported by this migration so they can.
--
-- Hash: SHA-256 over the UTF-8 encoding of the canonical string, lower-case hex.
-- Genesis: the prevHash of seq 1 is SHA-256('flexora.platform.audit.genesis.v1'),
-- returned by public.platform_audit_genesis_hash().
-- =============================================================================

-- 1. Lock first (A2.1). ACCESS EXCLUSIVE blocks every read and write on the table for
--    the duration of this transaction, which is what makes the backfill and the
--    assertion race-free.
LOCK TABLE public."PlatformAuditLog" IN ACCESS EXCLUSIVE MODE;

-- -----------------------------------------------------------------------------
-- 2. The hashing primitives. Created before anything uses them.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_audit_field(p_value text)
  RETURNS text
  LANGUAGE sql
  IMMUTABLE
  SET search_path = pg_catalog, public
  AS $fn$
    SELECT CASE
             WHEN p_value IS NULL THEN 'n'
             ELSE 'v' || octet_length(p_value)::text || ':' || p_value
           END;
  $fn$;

CREATE OR REPLACE FUNCTION public.platform_audit_genesis_hash()
  RETURNS text
  LANGUAGE sql
  IMMUTABLE
  SET search_path = pg_catalog, public
  AS $fn$
    SELECT encode(sha256(convert_to('flexora.platform.audit.genesis.v1', 'UTF8')), 'hex');
  $fn$;

CREATE OR REPLACE FUNCTION public.platform_audit_hash(
    p_seq           integer,
    p_admin_id      text,
    p_admin_name    text,
    p_action        text,
    p_target        text,
    p_details       jsonb,
    p_before_state  jsonb,
    p_after_state   jsonb,
    p_reason        text,
    p_ip            text,
    p_user_agent    text,
    p_step_up_used  boolean,
    p_created_at    timestamp(3),
    p_prev_hash     text
  )
  RETURNS text
  LANGUAGE sql
  IMMUTABLE
  SET search_path = pg_catalog, public
  AS $fn$
    SELECT encode(sha256(convert_to(
        'flexora.platform.audit.v1|'
     || public.platform_audit_field(p_seq::text)
     || public.platform_audit_field(p_admin_id)
     || public.platform_audit_field(p_admin_name)
     || public.platform_audit_field(p_action)
     || public.platform_audit_field(p_target)
     || public.platform_audit_field(p_details::text)
     || public.platform_audit_field(p_before_state::text)
     || public.platform_audit_field(p_after_state::text)
     || public.platform_audit_field(p_reason)
     || public.platform_audit_field(p_ip)
     || public.platform_audit_field(p_user_agent)
     || public.platform_audit_field(CASE WHEN p_step_up_used THEN 'true' ELSE 'false' END)
     || public.platform_audit_field(
          to_char(p_created_at, 'YYYY-MM-DD"T"HH24:MI:SS.MS'))
     || public.platform_audit_field(p_prev_hash)
    , 'UTF8')), 'hex');
  $fn$;

-- -----------------------------------------------------------------------------
-- 3. Add the columns. The three chain columns are NULLABLE for now (A2.1); they are
--    made NOT NULL in step 6, after the backfill and its assertion.
--    Column names follow the existing camelCase convention of this table, so raw SQL
--    must quote them.
-- -----------------------------------------------------------------------------

ALTER TABLE public."PlatformAuditLog"
  ADD COLUMN IF NOT EXISTS "seq"         integer,
  ADD COLUMN IF NOT EXISTS "hash"        text,
  ADD COLUMN IF NOT EXISTS "prevHash"    text,
  ADD COLUMN IF NOT EXISTS "reason"      text,
  ADD COLUMN IF NOT EXISTS "userAgent"   text,
  ADD COLUMN IF NOT EXISTS "beforeState" jsonb,
  ADD COLUMN IF NOT EXISTS "afterState"  jsonb,
  ADD COLUMN IF NOT EXISTS "stepUpUsed"  boolean NOT NULL DEFAULT false;

-- -----------------------------------------------------------------------------
-- 4. Capture the pre-state (A2.2). Row count plus a checksum over the eight columns
--    that existed before this migration. ON COMMIT DROP: this is scratch space inside
--    the migration transaction and must not survive it.
-- -----------------------------------------------------------------------------

CREATE TEMP TABLE _r3_audit_pre ON COMMIT DROP AS
SELECT
    count(*)                                                        AS n,
    coalesce(encode(sha256(convert_to(
      coalesce(string_agg(row_text, E'\x1f' ORDER BY row_text), ''),
      'UTF8')), 'hex'), '(empty)')                                  AS chk
  FROM (
    SELECT 'flexora.audit.pre.v1|'
        || public.platform_audit_field(a.id)
        || public.platform_audit_field(a."adminId")
        || public.platform_audit_field(a."adminName")
        || public.platform_audit_field(a.action)
        || public.platform_audit_field(a.target)
        || public.platform_audit_field(a.details::text)
        || public.platform_audit_field(a.ip)
        || public.platform_audit_field(
             to_char(a."createdAt", 'YYYY-MM-DD"T"HH24:MI:SS.MS'))   AS row_text
      FROM public."PlatformAuditLog" a
  ) t;

-- -----------------------------------------------------------------------------
-- 5. The backfill (A2.1 order, A2.7 set-based). One statement, no application round
--    trips. A hash chain is inherently sequential, so it is expressed as a recursive
--    CTE walking rn = 1, 2, 3 ... rather than as a window function, which cannot
--    reference a value it has not computed yet.
--    Order: (createdAt, id). id is the tie-breaker so the order is total and the
--    result is reproducible no matter how many rows share a timestamp.
-- -----------------------------------------------------------------------------

WITH RECURSIVE ordered AS (
    SELECT
        a.id,
        a."adminId",
        a."adminName",
        a.action,
        a.target,
        a.details,
        a.ip,
        a."createdAt",
        row_number() OVER (ORDER BY a."createdAt", a.id) AS rn
      FROM public."PlatformAuditLog" a
), chain AS (
    SELECT
        o.rn,
        o.id,
        1::integer                         AS new_seq,
        public.platform_audit_genesis_hash() AS new_prev,
        public.platform_audit_hash(
          1, o."adminId", o."adminName", o.action, o.target,
          o.details, NULL::jsonb, NULL::jsonb, NULL::text, o.ip, NULL::text,
          false, o."createdAt", public.platform_audit_genesis_hash()) AS new_hash
      FROM ordered o
     WHERE o.rn = 1
  UNION ALL
    SELECT
        o.rn,
        o.id,
        c.new_seq + 1,
        c.new_hash,
        public.platform_audit_hash(
          c.new_seq + 1, o."adminId", o."adminName", o.action, o.target,
          o.details, NULL::jsonb, NULL::jsonb, NULL::text, o.ip, NULL::text,
          false, o."createdAt", c.new_hash)
      FROM ordered o
      JOIN chain c ON c.rn = o.rn - 1
)
UPDATE public."PlatformAuditLog" a
   SET "seq"      = ch.new_seq,
       "prevHash" = ch.new_prev,
       "hash"     = ch.new_hash
  FROM chain ch
 WHERE a.id = ch.id;

-- Pre-existing rows have no reason, no user agent and no before/after: those columns
-- stay NULL, and stepUpUsed keeps its DEFAULT false. Nothing that existed is rewritten
-- (A2.8: no new data inside audit rows).

-- -----------------------------------------------------------------------------
-- 6. Assert nothing pre-existing changed (A2.2), and that the backfill is complete.
--    Raising here rolls the whole migration back, because Prisma applies a migration
--    file inside a single transaction.
-- -----------------------------------------------------------------------------

CREATE TEMP TABLE _r3_audit_post ON COMMIT DROP AS
SELECT
    count(*)                                                        AS n,
    coalesce(encode(sha256(convert_to(
      coalesce(string_agg(row_text, E'\x1f' ORDER BY row_text), ''),
      'UTF8')), 'hex'), '(empty)')                                  AS chk
  FROM (
    SELECT 'flexora.audit.pre.v1|'
        || public.platform_audit_field(a.id)
        || public.platform_audit_field(a."adminId")
        || public.platform_audit_field(a."adminName")
        || public.platform_audit_field(a.action)
        || public.platform_audit_field(a.target)
        || public.platform_audit_field(a.details::text)
        || public.platform_audit_field(a.ip)
        || public.platform_audit_field(
             to_char(a."createdAt", 'YYYY-MM-DD"T"HH24:MI:SS.MS'))   AS row_text
      FROM public."PlatformAuditLog" a
  ) t;

DO $do$
DECLARE
  v_pre_n    bigint;
  v_pre_chk  text;
  v_post_n   bigint;
  v_post_chk text;
  v_missing  bigint;
BEGIN
  SELECT n, chk INTO v_pre_n, v_pre_chk FROM _r3_audit_pre;
  SELECT n, chk INTO v_post_n, v_post_chk FROM _r3_audit_post;

  IF v_pre_n IS DISTINCT FROM v_post_n THEN
    RAISE EXCEPTION
      'PHASE R3 backfill changed the audit row count (% -> %); aborting and rolling back',
      v_pre_n, v_post_n
      USING ERRCODE = 'data_exception';
  END IF;

  IF v_pre_chk IS DISTINCT FROM v_post_chk THEN
    RAISE EXCEPTION
      'PHASE R3 backfill altered the contents of the eight pre-existing audit columns (checksum mismatch over % rows); aborting and rolling back',
      v_post_n
      USING ERRCODE = 'data_exception';
  END IF;

  SELECT count(*) INTO v_missing
    FROM public."PlatformAuditLog"
   WHERE "seq" IS NULL OR "hash" IS NULL OR "prevHash" IS NULL;

  IF v_missing > 0 THEN
    RAISE EXCEPTION
      'PHASE R3 backfill left % row(s) without a chain position; aborting and rolling back',
      v_missing
      USING ERRCODE = 'data_exception';
  END IF;
END
$do$;

-- -----------------------------------------------------------------------------
-- 7. NOT NULL and the uniqueness that makes a gap impossible to store (A2.1).
-- -----------------------------------------------------------------------------

ALTER TABLE public."PlatformAuditLog"
  ALTER COLUMN "seq"      SET NOT NULL,
  ALTER COLUMN "hash"     SET NOT NULL,
  ALTER COLUMN "prevHash" SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS "PlatformAuditLog_seq_key"
  ON public."PlatformAuditLog"("seq");

CREATE INDEX IF NOT EXISTS "PlatformAuditLog_createdAt_seq_idx"
  ON public."PlatformAuditLog"("createdAt", "seq");

-- -----------------------------------------------------------------------------
-- 8. The chain-assignment trigger (A2.4).
--
--    WHY AN ADVISORY LOCK AND NOT FOR UPDATE ALONE. Taking the head row FOR UPDATE by
--    itself does not produce a gapless chain: a concurrent inserter holds the lock on
--    the row that was head when its own statement started, and once it commits the
--    waiter proceeds with that same stale head, so both children claim the same seq and
--    the same prevHash - a fork. The transaction-scoped advisory lock is taken FIRST so
--    that only one inserter at a time can read the head, and the head read then happens
--    after the lock is held and sees the committed head. The FOR UPDATE the owner asked
--    for is kept as well: it is harmless once serialised, and it makes the intent
--    explicit at the row that defines the chain head.
--
--    A client that supplies seq, hash or prevHash is overwritten. The chain is
--    authoritative and cannot be dictated by a caller.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_audit_chain_assign()
  RETURNS trigger
  LANGUAGE plpgsql
  SET search_path = pg_catalog, public
  AS $fn$
DECLARE
  v_head_seq  integer;
  v_head_hash text;
BEGIN
  PERFORM pg_advisory_xact_lock(
    hashtextextended('flexora.platform.audit.chain', 3));

  SELECT a."seq", a."hash"
    INTO v_head_seq, v_head_hash
    FROM public."PlatformAuditLog" a
   ORDER BY a."seq" DESC
   LIMIT 1
   FOR UPDATE;

  IF v_head_seq IS NULL THEN
    NEW."seq"      := 1;
    NEW."prevHash" := public.platform_audit_genesis_hash();
  ELSE
    NEW."seq"      := v_head_seq + 1;
    NEW."prevHash" := v_head_hash;
  END IF;

  NEW."hash" := public.platform_audit_hash(
    NEW."seq",
    NEW."adminId",
    NEW."adminName",
    NEW.action,
    NEW.target,
    NEW.details,
    NEW."beforeState",
    NEW."afterState",
    NEW.reason,
    NEW.ip,
    NEW."userAgent",
    NEW."stepUpUsed",
    NEW."createdAt",
    NEW."prevHash");

  RETURN NEW;
END
$fn$;

CREATE TRIGGER "PlatformAuditLog_chain_assign"
  BEFORE INSERT ON public."PlatformAuditLog"
  FOR EACH ROW
  EXECUTE FUNCTION public.platform_audit_chain_assign();

-- -----------------------------------------------------------------------------
-- 9. Append-only (A1 = option a: refuse for EVERY role).
--
--    A trigger fires for superusers too, so this closes the hole the BEFORE
--    measurement proved: as the migration owner AND as flexora_app, UPDATE and DELETE
--    on an audit row both succeeded silently (work/r3-evidence/00-before.log, B3).
--
--    The only ways past it are explicit superuser bypasses -
--    SET session_replication_role = replica, or ALTER TABLE ... DISABLE TRIGGER - and
--    both leave the row's stored hash inconsistent with its contents, so
--    platform_audit_verify() names the exact row. That is the tamper test (R3.5).
--
--    TRUNCATE is deliberately NOT blocked (that was decision A1 option c), so the test
--    harness reset and any future retention job remain possible without a bypass.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_audit_append_only()
  RETURNS trigger
  LANGUAGE plpgsql
  SET search_path = pg_catalog, public
  AS $fn$
BEGIN
  RAISE EXCEPTION
    'public."PlatformAuditLog" is append-only (PHASE R3): % is refused for every role. A superuser can bypass this only with SET session_replication_role = replica or ALTER TABLE ... DISABLE TRIGGER, and the chain verification will then report the row that was touched.',
    TG_OP
    USING ERRCODE = 'insufficient_privilege';
END
$fn$;

CREATE TRIGGER "PlatformAuditLog_no_update"
  BEFORE UPDATE ON public."PlatformAuditLog"
  FOR EACH ROW
  EXECUTE FUNCTION public.platform_audit_append_only();

CREATE TRIGGER "PlatformAuditLog_no_delete"
  BEFORE DELETE ON public."PlatformAuditLog"
  FOR EACH ROW
  EXECUTE FUNCTION public.platform_audit_append_only();

-- -----------------------------------------------------------------------------
-- 10. Verification (R3.4). Read-only and STABLE, with search_path pinned, every object
--     schema-qualified and no dynamic SQL - the R2 conventions.
--
--     It is SECURITY INVOKER, deliberately NOT SECURITY DEFINER like the R2 aggregate
--     functions. Those needed the owner's privileges because they read tenant tables
--     that FORCE RLS hides from the runtime role. This one reads public."PlatformAuditLog",
--     which has no RLS and on which the runtime role already holds SELECT, so running it
--     as the caller grants nothing extra - and keeping it out of the SECURITY DEFINER
--     class means it adds no new requirement to the owner-profile compatibility matrix.
--
--     It recomputes every hash from the stored columns and checks three things per row:
--       hash-mismatch  the row's own contents no longer produce its stored hash
--       link-mismatch  prevHash does not equal the previous row's hash (or the genesis
--                      hash for seq 1) - this is what catches a deleted row, because a
--                      deletion leaves the successor pointing at a hash that is gone
--       seq-gap        seq is not exactly one more than the previous row's seq
--     first_broken_seq is the LOWEST seq with a problem, so an operator is sent to the
--     earliest point the log stopped being trustworthy.
--
--     KNOWN LIMIT, stated rather than hidden. A hash chain detects a changed row and a
--     row removed from the middle, but it cannot detect the removal of rows from the END:
--     delete the tail and what remains is still a perfectly valid, shorter chain. Only a
--     superuser who has explicitly bypassed the append-only trigger can do this, and it
--     is detectable against a head hash recorded earlier - which is why this function
--     returns head_seq and head_hash, why the console shows them, why the CSV export
--     carries seq, and why the api's verify route additionally compares head_seq against
--     the highest auditSeq any PlatformAlert references. A period with no alerts has no
--     such anchor, and that is recorded as a residual risk in docs/ADMIN_CONSOLE.md.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_audit_verify()
  RETURNS TABLE (
    rows_checked        integer,
    valid               boolean,
    broken_rows         integer,
    first_broken_seq    integer,
    first_broken_id     text,
    first_broken_reason text,
    head_seq            integer,
    head_hash           text,
    genesis_hash        text
  )
  LANGUAGE sql
  STABLE
  SECURITY INVOKER
  SET search_path = pg_catalog, public
  AS $fn$
    WITH recomputed AS (
      SELECT
          a."seq"      AS row_seq,
          a.id         AS row_id,
          a."hash"     AS row_hash,
          a."prevHash" AS row_prev,
          public.platform_audit_hash(
            a."seq", a."adminId", a."adminName", a.action, a.target,
            a.details, a."beforeState", a."afterState", a.reason,
            a.ip, a."userAgent", a."stepUpUsed", a."createdAt", a."prevHash"
          ) AS expect_hash,
          lag(a."hash") OVER (ORDER BY a."seq") AS prev_actual_hash,
          lag(a."seq")  OVER (ORDER BY a."seq") AS prev_actual_seq
        FROM public."PlatformAuditLog" a
    ), flagged AS (
      SELECT
          r.row_seq,
          r.row_id,
          r.row_hash,
          -- The ORDER of these three tests is deliberate and was fixed after measuring
          -- it. expect_hash is recomputed from the stored columns INCLUDING prevHash, so
          -- if the content test ran first, a forged prevHash would be reported as
          -- 'hash-mismatch' and the more specific diagnosis would be lost. Both are
          -- caught either way; this order tells an operator whether the row's CONTENT
          -- changed, whether it was RE-LINKED to a different predecessor, or whether a
          -- predecessor DISAPPEARED - which is the first thing they need to know.
          CASE
            WHEN r.row_prev IS DISTINCT FROM
                 coalesce(r.prev_actual_hash, public.platform_audit_genesis_hash())
              THEN 'link-mismatch'
            WHEN r.row_hash IS DISTINCT FROM r.expect_hash
              THEN 'hash-mismatch'
            WHEN r.row_seq IS DISTINCT FROM coalesce(r.prev_actual_seq, 0) + 1
              THEN 'seq-gap'
            ELSE NULL
          END AS problem
        FROM recomputed r
    ), agg AS (
      SELECT count(*) AS n,
             count(*) FILTER (WHERE problem IS NOT NULL) AS bad
        FROM flagged
    ), first_broken AS (
      SELECT f.row_seq, f.row_id, f.problem
        FROM flagged f
       WHERE f.problem IS NOT NULL
       ORDER BY f.row_seq
       LIMIT 1
    ), head AS (
      SELECT f.row_seq, f.row_hash
        FROM flagged f
       ORDER BY f.row_seq DESC
       LIMIT 1
    )
    SELECT
        agg.n::integer,
        agg.bad = 0,
        agg.bad::integer,
        first_broken.row_seq::integer,
        first_broken.row_id,
        first_broken.problem,
        head.row_seq::integer,
        head.row_hash,
        public.platform_audit_genesis_hash()
      FROM agg
      LEFT JOIN first_broken ON true
      LEFT JOIN head ON true;
  $fn$;

-- -----------------------------------------------------------------------------
-- 11. Least privilege.
--
--     platform_audit_verify() follows the R2 grant convention exactly: EXECUTE revoked from
--     PUBLIC and granted only to the runtime role. The runtime role name is written out
--     explicitly, as the R2 migration does; a deployment whose runtime role is not named
--     flexora_app must adjust this GRANT, and scripts/check-db-compat.sh exercises the
--     supported owner profiles.
--
--     The three trigger-reachable functions deliberately KEEP the default PUBLIC
--     EXECUTE. platform_audit_chain_assign() and platform_audit_append_only() are
--     invoked by the trigger machinery on behalf of whichever role inserts an audit
--     row; revoking EXECUTE from PUBLIC would turn every audited platform action into a
--     permission error in any deployment whose runtime role is named differently, which
--     is a worse failure than the one being prevented. Neither function grants access
--     to data: one assigns chain fields to the row being inserted, the other only ever
--     raises. platform_audit_hash(), platform_audit_field() and
--     platform_audit_genesis_hash() are pure functions of their arguments and are also
--     what an offline verifier needs, so they stay executable.
-- -----------------------------------------------------------------------------

REVOKE ALL ON FUNCTION public.platform_audit_verify() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.platform_audit_verify() TO flexora_app;

-- =============================================================================
-- DOWN MIGRATION
-- A separate, documented file: prisma/migrations/20261107120000_platform_audit_chain_r3/down.sql
-- Prisma does not run down migrations, so this one is applied by hand and is tested on
-- a COPY of the database (owner decision A2.6). It returns the table to exactly its
-- pre-R3 state: eight columns, no triggers, no R3 functions.
-- =============================================================================
