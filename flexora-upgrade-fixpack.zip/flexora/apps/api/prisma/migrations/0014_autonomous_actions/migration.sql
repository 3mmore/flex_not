-- CreateEnum
CREATE TYPE "AutonomousActionType" AS ENUM ('CREATE_TASK', 'CREATE_WORKFLOW', 'ASSIGN_STAFF', 'SCHEDULE_REMINDER', 'CREATE_RECOMMENDATION', 'QUEUE_COMMUNICATION', 'OPEN_REVIEW_REQUEST');

-- CreateEnum
CREATE TYPE "AutonomousActionStatus" AS ENUM ('EXECUTED', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'REVERTED');

-- CreateEnum
CREATE TYPE "AutonomousOutcome" AS ENUM ('PENDING', 'RETAINED', 'STILL_AT_RISK', 'CHURNED', 'RECOVERED', 'NOT_RECOVERED', 'REVENUE_STABILIZED', 'REVENUE_DECLINED', 'UTILIZATION_IMPROVED', 'NO_CHANGE');

-- CreateTable
CREATE TABLE "AutonomousAction" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "flow" TEXT NOT NULL,
    "signal" TEXT NOT NULL,
    "decision" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "type" "AutonomousActionType" NOT NULL,
    "title" TEXT NOT NULL,
    "ownerUserId" TEXT,
    "ownerLabel" TEXT NOT NULL,
    "subjectType" TEXT,
    "subjectId" TEXT,
    "status" "AutonomousActionStatus" NOT NULL DEFAULT 'EXECUTED',
    "autonomyLevel" INTEGER NOT NULL DEFAULT 2,
    "pendingIntent" TEXT,
    "dueAt" TIMESTAMP(3),
    "outcome" "AutonomousOutcome" NOT NULL DEFAULT 'PENDING',
    "outcomeNote" TEXT,
    "measuredAt" TIMESTAMP(3),
    "reverted" BOOLEAN NOT NULL DEFAULT false,
    "revertedAt" TIMESTAMP(3),
    "revertReason" TEXT,
    "taskId" TEXT,
    "meta" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AutonomousAction_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "AutonomousAction_gymId_createdAt_idx" ON "AutonomousAction"("gymId", "createdAt");

-- CreateIndex
CREATE INDEX "AutonomousAction_gymId_status_idx" ON "AutonomousAction"("gymId", "status");

-- CreateIndex
CREATE INDEX "AutonomousAction_gymId_flow_idx" ON "AutonomousAction"("gymId", "flow");

-- CreateIndex
CREATE INDEX "AutonomousAction_gymId_outcome_idx" ON "AutonomousAction"("gymId", "outcome");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "Member_gymId_vip_idx" ON "Member"("gymId", "vip");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "Member_gymId_expiry_idx" ON "Member"("gymId", "expiry");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "User_gymId_role_idx" ON "User"("gymId", "role");

-- AddForeignKey
ALTER TABLE "AutonomousAction" ADD CONSTRAINT "AutonomousAction_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;

