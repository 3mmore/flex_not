-- ROUND 14 (security review, PHASE I1) — only genuine membership payments may
-- serve as proof of payment.
--
-- Payment.purpose classifies what a payment was created for:
--   POS_SALE         — a POS sale payment (belongs to a sale invoice; never
--                      re-pointed to a membership)
--   ONLINE_RENEWAL   — an online provider webhook payment
--   MANUAL_MEMBERSHIP— a front-desk manual payment, optionally bound to a
--                      member (NULL memberId may be bound to the first member
--                      that uses it, atomically)
--   OTHER            — anything else (not usable as membership proof)
--
-- Existing rows are backfilled from their invoice shape.

CREATE TYPE "PaymentPurpose" AS ENUM ('MANUAL_MEMBERSHIP', 'ONLINE_RENEWAL', 'POS_SALE', 'OTHER');

ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "purpose" "PaymentPurpose" NOT NULL DEFAULT 'OTHER';
ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "memberId" TEXT;

-- POS sale payments (their invoice belongs to a sale)
UPDATE "Payment" p
SET "purpose" = 'POS_SALE',
    "memberId" = (SELECT i."memberId" FROM "Invoice" i WHERE i.id = p."invoiceId")
WHERE p."invoiceId" IN (SELECT id FROM "Invoice" WHERE "invoiceNo" LIKE 'SALE-%');

-- online webhook payments
UPDATE "Payment" p
SET "purpose" = 'ONLINE_RENEWAL',
    "memberId" = (SELECT i."memberId" FROM "Invoice" i WHERE i.id = p."invoiceId")
WHERE p."method" = 'ONLINE';

-- manual front-desk payments (memberId NULL — bindable at first use)
UPDATE "Payment" p
SET "purpose" = 'MANUAL_MEMBERSHIP'
WHERE p."invoiceId" IN (SELECT id FROM "Invoice" WHERE "invoiceNo" LIKE 'MANUAL-%');
