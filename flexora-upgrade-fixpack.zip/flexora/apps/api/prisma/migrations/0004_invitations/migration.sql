-- Migration: 0004_invitations
-- Invitation System: free guest visits with member-allocated slots and an
-- AI follow-up loop that collects visitor feedback and tracks conversion to
-- paying members. Additive only — new enum, two new tables, indexes and FKs.
-- No existing columns or tables are altered or dropped, so it is safe and
-- non-breaking on environments that already ran 0001..0003.

-- CreateEnum
CREATE TYPE "InvitationStatus" AS ENUM ('VISITED', 'NO_SHOW', 'CONVERTED', 'DECLINED');

-- CreateTable
CREATE TABLE "InvitationSlot" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "totalSlots" INTEGER NOT NULL DEFAULT 2,
    "usedSlots" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "InvitationSlot_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Invitation" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "slotId" TEXT NOT NULL,
    "invitedBy" TEXT NOT NULL,
    "visitorName" TEXT NOT NULL,
    "visitorPhone" TEXT NOT NULL,
    "visitDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "branchId" TEXT,
    "status" "InvitationStatus" NOT NULL DEFAULT 'VISITED',
    "convertedToMember" BOOLEAN NOT NULL DEFAULT false,
    "convertedMemberId" TEXT,
    "aiFeedbackSent" BOOLEAN NOT NULL DEFAULT false,
    "aiFeedbackSentAt" TIMESTAMP(3),
    "feedbackScore" INTEGER,
    "feedbackText" TEXT,
    "aiSummary" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Invitation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "InvitationSlot_memberId_key" ON "InvitationSlot"("memberId");

-- CreateIndex
CREATE INDEX "InvitationSlot_gymId_idx" ON "InvitationSlot"("gymId");

-- CreateIndex
CREATE UNIQUE INDEX "InvitationSlot_gymId_memberId_key" ON "InvitationSlot"("gymId", "memberId");

-- CreateIndex
CREATE INDEX "Invitation_gymId_visitDate_idx" ON "Invitation"("gymId", "visitDate");

-- CreateIndex
CREATE INDEX "Invitation_invitedBy_idx" ON "Invitation"("invitedBy");

-- CreateIndex
CREATE INDEX "Invitation_visitorPhone_idx" ON "Invitation"("visitorPhone");

-- AddForeignKey
ALTER TABLE "InvitationSlot" ADD CONSTRAINT "InvitationSlot_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InvitationSlot" ADD CONSTRAINT "InvitationSlot_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Invitation" ADD CONSTRAINT "Invitation_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Invitation" ADD CONSTRAINT "Invitation_slotId_fkey" FOREIGN KEY ("slotId") REFERENCES "InvitationSlot"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Invitation" ADD CONSTRAINT "Invitation_invitedBy_fkey" FOREIGN KEY ("invitedBy") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;
