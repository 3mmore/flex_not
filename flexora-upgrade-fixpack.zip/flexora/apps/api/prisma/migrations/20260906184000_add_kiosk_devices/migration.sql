-- KioskDevice: self-service check-in devices (P2)
CREATE TABLE "KioskDevice" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "branchId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "lastSeenAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "KioskDevice_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "KioskDevice_token_key" ON "KioskDevice"("token");
CREATE INDEX "KioskDevice_gymId_idx" ON "KioskDevice"("gymId");

ALTER TABLE "KioskDevice" ADD CONSTRAINT "KioskDevice_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "KioskDevice" ADD CONSTRAINT "KioskDevice_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE CASCADE ON UPDATE CASCADE;
