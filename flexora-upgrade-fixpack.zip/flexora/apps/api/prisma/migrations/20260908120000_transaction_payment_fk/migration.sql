-- AlterTable: Add paymentId column to Transaction model
-- FIX (round 8 review — fragile transaction matching in double-counting fix):
-- A precise FK link from Transaction back to Payment, so the membership flow
-- can find the EXACT manual-payment transaction to update instead of using
-- a heuristic (reference LIKE 'MANUAL-%', same createdBy) that can match the
-- WRONG row under concurrent payments by the same staff member.

ALTER TABLE "Transaction" ADD COLUMN "paymentId" TEXT;

-- Unique constraint: each payment maps to at most one ledger transaction
CREATE UNIQUE INDEX "Transaction_paymentId_key" ON "Transaction"("paymentId");

-- Foreign key to Payment (nullable, SET NULL if payment is deleted)
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_paymentId_fkey"
  FOREIGN KEY ("paymentId") REFERENCES "Payment"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Index for efficient lookup by paymentId
CREATE INDEX "Transaction_paymentId_idx" ON "Transaction"("paymentId");
