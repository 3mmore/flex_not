-- ROUND 14 (security review, PHASE H) — renewal money path hardening.
--
-- H2: explicit one-time payment consumption. Payment.consumedAt +
--     consumedByInvoiceId are set in the same atomic compare-and-set that
--     links the payment to its membership invoice; a payment with the marker
--     set can never pay for a second membership, regardless of invoice text.
--     Existing payments already linked to membership/renewal/activation
--     invoices are backfilled.
-- H4: RenewalRequest.providerOrderId stores the SIGNED Paymob order id
--     (order.id — covered by the webhook HMAC, unlike merchant_order_id).
--     PaymentAttempt's (provider, providerTransactionId) claim becomes unique
--     across the whole platform rather than per gym.

ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "consumedAt" TIMESTAMP(3);
ALTER TABLE "Payment" ADD COLUMN IF NOT EXISTS "consumedByInvoiceId" TEXT;

ALTER TABLE "RenewalRequest" ADD COLUMN IF NOT EXISTS "providerOrderId" TEXT;

-- H4: platform-wide idempotency claim for provider transactions.
DROP INDEX IF EXISTS "PaymentAttempt_gymId_provider_providerTransactionId_key";
CREATE UNIQUE INDEX IF NOT EXISTS "PaymentAttempt_provider_providerTransactionId_key" ON "PaymentAttempt"("provider", "providerTransactionId");

-- H2: backfill the consumption marker for payments already linked to
-- membership / renewal / activation invoices (activation lines read
-- "<plan> activation").
UPDATE "Payment" p
SET "consumedAt" = now(), "consumedByInvoiceId" = p."invoiceId"
WHERE p."invoiceId" IN (
  SELECT i.id FROM "Invoice" i
  JOIN "InvoiceLine" l ON l."invoiceId" = i.id
  WHERE l."description" ILIKE '%membership%'
     OR l."description" ILIKE '%renewal%'
     OR l."description" ILIKE '%activation%'
);
