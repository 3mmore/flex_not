-- CreateTable: NotificationSubscription (member portal Web Push)
CREATE TABLE "NotificationSubscription" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "endpoint" TEXT NOT NULL,
    "p256dh" TEXT NOT NULL,
    "auth" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "NotificationSubscription_pkey" PRIMARY KEY ("id")
);

-- Endpoint uniqueness: one row per browser push endpoint
CREATE UNIQUE INDEX "NotificationSubscription_endpoint_key" ON "NotificationSubscription"("endpoint");

-- Tenant / member scoping indexes
CREATE INDEX "NotificationSubscription_gymId_idx" ON "NotificationSubscription"("gymId");
CREATE INDEX "NotificationSubscription_memberId_idx" ON "NotificationSubscription"("memberId");
CREATE INDEX "NotificationSubscription_gymId_memberId_idx" ON "NotificationSubscription"("gymId", "memberId");

-- Foreign keys (cascade with gym / member deletion)
ALTER TABLE "NotificationSubscription"
  ADD CONSTRAINT "NotificationSubscription_gymId_fkey"
  FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "NotificationSubscription"
  ADD CONSTRAINT "NotificationSubscription_memberId_fkey"
  FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;
