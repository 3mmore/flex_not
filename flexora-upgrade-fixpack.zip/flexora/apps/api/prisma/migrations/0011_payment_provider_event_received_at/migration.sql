ALTER TABLE "PaymentProviderEvent"
  ADD COLUMN IF NOT EXISTS "receivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

UPDATE "PaymentProviderEvent"
SET "receivedAt" = "processedAt"
WHERE "processedAt" IS NOT NULL;

DROP INDEX IF EXISTS "PaymentProviderEvent_gymId_processedAt_idx";
CREATE INDEX IF NOT EXISTS "PaymentProviderEvent_gymId_receivedAt_idx" ON "PaymentProviderEvent"("gymId", "receivedAt");

ALTER TABLE "PaymentProviderEvent"
  DROP COLUMN IF EXISTS "processedAt";
