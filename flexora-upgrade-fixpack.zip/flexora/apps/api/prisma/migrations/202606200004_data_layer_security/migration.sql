ALTER TABLE "Plan" ALTER COLUMN "price" TYPE DECIMAL(14,2) USING "price"::DECIMAL(14,2);
ALTER TABLE "Sale" ALTER COLUMN "total" TYPE DECIMAL(14,2) USING "total"::DECIMAL(14,2), ALTER COLUMN "discount" TYPE DECIMAL(14,2) USING "discount"::DECIMAL(14,2), ALTER COLUMN "subtotal" TYPE DECIMAL(14,2) USING "subtotal"::DECIMAL(14,2), ALTER COLUMN "tax" TYPE DECIMAL(14,2) USING "tax"::DECIMAL(14,2);
ALTER TABLE "Expense" ALTER COLUMN "amount" TYPE DECIMAL(14,2) USING "amount"::DECIMAL(14,2);
ALTER TABLE "Transaction" ALTER COLUMN "amount" TYPE DECIMAL(14,2) USING "amount"::DECIMAL(14,2);
ALTER TABLE "Invoice" ALTER COLUMN "subtotal" TYPE DECIMAL(14,2) USING "subtotal"::DECIMAL(14,2), ALTER COLUMN "total" TYPE DECIMAL(14,2) USING "total"::DECIMAL(14,2), ALTER COLUMN "paid" TYPE DECIMAL(14,2) USING "paid"::DECIMAL(14,2);
ALTER TABLE "Payment" ALTER COLUMN "amount" TYPE DECIMAL(14,2) USING "amount"::DECIMAL(14,2);
ALTER TABLE "PaymentAttempt" ALTER COLUMN "amount" TYPE DECIMAL(14,2) USING "amount"::DECIMAL(14,2);
ALTER TABLE "FinancialReconciliation" ALTER COLUMN "expectedAmount" TYPE DECIMAL(14,2) USING "expectedAmount"::DECIMAL(14,2), ALTER COLUMN "providerAmount" TYPE DECIMAL(14,2) USING "providerAmount"::DECIMAL(14,2);
ALTER TABLE "PtSession" ALTER COLUMN "price" TYPE DECIMAL(14,2) USING "price"::DECIMAL(14,2);
ALTER TABLE "CoachProfile" ALTER COLUMN "pricePerHour" TYPE DECIMAL(14,2) USING "pricePerHour"::DECIMAL(14,2);

ALTER TABLE "ProductEvent" RENAME COLUMN "tenantId" TO "gymId";
-- FIX (Task 2/launch-readiness follow-up, found while re-verifying
-- migrate deploy after adding "ProductEvent"'s missing "createdAt"/
-- "processedAt" columns in 0015_missing_table_creates): "ProductEvent" has
-- never had a real FK to "Gym" in any migration, even though
-- schema.prisma declares `gym Gym @relation(fields: [gymId], ...)`. Adding
-- it here, immediately after the rename that first makes the "gymId"
-- column name exist, so it's present exactly once regardless of whether
-- this migration runs via the CI workaround's out-of-sequence replay or a
-- genuine sequential `migrate deploy` (0015's own ProductEvent fix
-- deliberately skips adding this FK pre-rename, precisely so it is added
-- here, in exactly one place, right after the column has its final name).
DO $$ BEGIN
  ALTER TABLE "ProductEvent" ADD CONSTRAINT "ProductEvent_gymId_fkey" FOREIGN KEY ("gymId") REFERENCES "Gym"("id") ON UPDATE CASCADE ON DELETE CASCADE;
EXCEPTION WHEN duplicate_object THEN null; END $$;
CREATE INDEX IF NOT EXISTS "User_gymId_branchId_idx" ON "User"("gymId", "branchId");
UPDATE "PurchaseOrderItem" poi SET "gymId" = po."gymId" FROM "PurchaseOrder" po WHERE poi."purchaseOrderId" = po."id" AND poi."gymId" IS NULL;
DELETE FROM "PurchaseOrderItem" WHERE "gymId" IS NULL;
ALTER TABLE "PurchaseOrderItem" ALTER COLUMN "gymId" SET NOT NULL;

ALTER TABLE "Product" ALTER COLUMN "costPrice" TYPE DECIMAL(14,2) USING "costPrice"::DECIMAL(14,2), ALTER COLUMN "sellingPrice" TYPE DECIMAL(14,2) USING "sellingPrice"::DECIMAL(14,2);
ALTER TABLE "SaleItem" ALTER COLUMN "unitPrice" TYPE DECIMAL(14,2) USING "unitPrice"::DECIMAL(14,2), ALTER COLUMN "total" TYPE DECIMAL(14,2) USING "total"::DECIMAL(14,2), ALTER COLUMN "price" TYPE DECIMAL(14,2) USING "price"::DECIMAL(14,2);
ALTER TABLE "InvoiceLine" ALTER COLUMN "unitPrice" TYPE DECIMAL(14,2) USING "unitPrice"::DECIMAL(14,2), ALTER COLUMN "total" TYPE DECIMAL(14,2) USING "total"::DECIMAL(14,2);
