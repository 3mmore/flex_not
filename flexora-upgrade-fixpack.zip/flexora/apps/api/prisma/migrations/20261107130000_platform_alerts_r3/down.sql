-- =============================================================================
-- FLEXORA PHASE R3 - DOWN migration for 20261107130000_platform_alerts_r3.
-- (c) 2024 Ammar Allam. All rights reserved.
--
-- Prisma does not execute down migrations, so this file is applied by hand:
--     psql "$DATABASE_ADMIN_URL" -v ON_ERROR_STOP=1 --single-transaction \
--       -f apps/api/prisma/migrations/20261107130000_platform_alerts_r3/down.sql
-- Tested on a COPY of the database (owner decisions A3.8 and A4.6), never on the live
-- one. The up migration is purely additive, so this one is purely subtractive and
-- returns the database to exactly its pre-R3 state.
--
-- DROPPING "PlatformAlert" DISCARDS THE ALERT HISTORY, including any alert that could
-- not be delivered because no channel was configured (status NO_CHANNEL). Read the
-- console's alert list first if that history matters.
-- =============================================================================

--
-- THIS FILE IS ONE EXPLICIT TRANSACTION. It was written without one first and failed on
-- the LOCK with "LOCK TABLE can only be used in transaction blocks", because psql runs
-- each statement in its own implicit transaction unless told otherwise. Atomicity is not
-- cosmetic here: a rollback that dropped the append-only triggers but kept the chain
-- columns would leave the table writable and unverifiable at the same time.

BEGIN;

-- 1. Functions. No CASCADE: nothing else may depend on these, and if something does this
--    file should fail rather than silently drop a dependent object.
DROP FUNCTION IF EXISTS public.platform_claim_alerts_for_retry(timestamp(3), integer);
DROP FUNCTION IF EXISTS public.platform_seed_admin_devices(text);
DROP FUNCTION IF EXISTS public.platform_device_hash(text, text, text, integer, text);
DROP FUNCTION IF EXISTS public.platform_normalize_ua(text);

-- 2. Tables. The device table first: it carries the only foreign key this migration
--    added, and dropping it before its parent's dependants keeps the order obvious.
DROP TABLE IF EXISTS public."PlatformAdminDevice";
DROP TABLE IF EXISTS public."PlatformAlert";

-- 3. Assert the database is back to its pre-R3 state. A failure here means the down
--    migration did not do its job and the operator must not assume it did.
DO $do$
DECLARE
  v_tables   bigint;
  v_funcs    bigint;
  v_indexes  bigint;
BEGIN
  SELECT count(*) INTO v_tables
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
   WHERE n.nspname = 'public'
     AND c.relkind = 'r'
     AND c.relname IN ('PlatformAlert', 'PlatformAdminDevice');

  IF v_tables <> 0 THEN
    RAISE EXCEPTION 'PHASE R3 down-migration left % of the two R3 tables behind', v_tables
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;

  SELECT count(*) INTO v_funcs
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
   WHERE n.nspname = 'public'
     AND p.proname IN ('platform_normalize_ua', 'platform_device_hash',
                       'platform_seed_admin_devices', 'platform_claim_alerts_for_retry');

  IF v_funcs <> 0 THEN
    RAISE EXCEPTION 'PHASE R3 down-migration left % of the four R3 functions behind', v_funcs
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;

  SELECT count(*) INTO v_indexes
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
   WHERE n.nspname = 'public'
     AND c.relkind = 'i'
     AND c.relname LIKE 'PlatformAlert\_%';

  IF v_indexes <> 0 THEN
    RAISE EXCEPTION 'PHASE R3 down-migration left % PlatformAlert index(es) behind', v_indexes
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;

  -- The audit table is untouched by this migration, so it must still be there and still
  -- be chained. This down migration is for the alerts half only; rolling back the audit
  -- chain is the other file's job.
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = 'public' AND c.relname = 'PlatformAuditLog'
  ) THEN
    RAISE EXCEPTION 'PHASE R3 down-migration must not touch "PlatformAuditLog", but it is missing'
      USING ERRCODE = 'object_not_in_prerequisite_state';
  END IF;
END
$do$;

COMMIT;
