-- =============================================================================
-- FLEXORA PHASE R3 - migration 2 of 2: the platform alert outbox and the admin
-- device baseline. (c) 2024 Ammar Allam. All rights reserved.
--
-- ADDITIVE ONLY (owner decision A3.8): this migration creates two new tables and four
-- new functions. It changes no existing table and no existing value. The audit-chain
-- migration that runs before it is the only one that touches stored data, and it proves
-- it changed nothing.
--
--   public."PlatformAlert"        the outbox every R3 alert is written to (A3)
--   public."PlatformAdminDevice"  the per-admin baseline of known devices (A4)
--   public.platform_normalize_ua(text)                  one UA rule, used by BOTH the
--                                                       seeding below and the runtime
--                                                       device check, so there is no
--                                                       second implementation to drift
--   public.platform_device_hash(text, text, text, integer, text)
--                                                       the keyed device digest
--   public.platform_seed_admin_devices(text)            set-based, idempotent seeding
--   public.platform_claim_alerts_for_retry(timestamp(3), integer)
--                                                       FOR UPDATE SKIP LOCKED claim
--
-- NEITHER TABLE IS A TENANT TABLE (A3.6): no gymId column, no row-level security, not
-- reachable from the tenant UI. They are platform tables like "PlatformAuditLog" and
-- "PlatformSession", and the api reads and writes them with the runtime role only.
-- Nothing here needs the database owner credential, so DATABASE_ADMIN_URL stays out of
-- the api entirely.
--
-- -----------------------------------------------------------------------------
-- NO PGCRYPTO, AND WHY
-- -----------------------------------------------------------------------------
-- A4.2 asks for a one-way hash of IP + user agent with a per-install salt. The natural
-- primitive is HMAC, but Postgres only offers hmac() through the pgcrypto extension,
-- and CREATE EXTENSION needs a superuser - which would add a new requirement to the
-- owner-profile compatibility matrix that scripts/check-db-compat.sh exercises, and
-- seven profiles are already blocked for other reasons. So this uses a keyed digest
-- built from the platform's own sha256():
--
--     device_hash = hex( sha256( key || '|' || ip || '|' || family || '|' || major
--                                || '|' || os || '|' || key ) )
--
-- The key appears on BOTH sides. That is deliberate: a bare sha256(key || message) is
-- vulnerable to length extension, while appending the key again makes extension
-- impossible, because an attacker who could append bytes cannot also append the key.
-- The value is a pseudonymous identifier, not an authentication tag - no authorisation
-- decision trusts it - so a keyed digest is the right weight of primitive here.
--
-- The per-install key is NOT a new environment variable. It is derived by domain
-- separation from a secret the deployment already requires, already validates and
-- already passes through compose:
--
--     device_key = hex( HMAC-SHA256(OTP_HMAC_SECRET, 'flexora.platform.device.v1') )
--
-- computed in the api at start-up and passed to platform_seed_admin_devices() and
-- platform_device_hash() as a parameter. It never reaches this file and is never stored.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. The alert outbox (A3.1: the column list is the whole story, and it holds no PII
--    and no secret - no owner phone number, no token, no message body, no raw error
--    text, only an error CODE).
-- -----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public."PlatformAlert" (
  "id"            text        NOT NULL,
  "type"          text        NOT NULL,
  "severity"      text        NOT NULL DEFAULT 'info',
  "targetKind"    text        NOT NULL,
  "targetId"      text,
  "auditSeq"      integer,
  "channel"       text        NOT NULL DEFAULT 'WHATSAPP_OWNER',
  "status"        text        NOT NULL DEFAULT 'PENDING',
  "attempts"      integer     NOT NULL DEFAULT 0,
  "maxAttempts"   integer     NOT NULL DEFAULT 5,
  "errorCode"     text,
  "dedupeKey"     text        NOT NULL,
  "nextAttemptAt" timestamp(3),
  "lastAttemptAt" timestamp(3),
  "sentAt"        timestamp(3),
  "createdAt"     timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"     timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PlatformAlert_pkey" PRIMARY KEY ("id")
);

-- type is one of a fixed vocabulary, asserted in the service and in the tests:
--   ADMIN_LOGIN_BURST       three or more failed admin logins        (R3.10a)
--   ADMIN_NEW_DEVICE        login from an unseen IP or device        (R3.10b)
--   ADMIN_CREATED           a platform admin was created             (R3.10c)
--   ADMIN_REMOVED           a platform admin was removed             (R3.10c)
--   SUBSCRIPTION_GRANTED    a subscription was granted or extended   (R3.10d)
--   GYM_DELETED             a gym was soft-deleted                   (R3.10e)
--   AUDIT_WRITE_FAILED      an audit row could not be written        (R3.15)
--   ALERT_SEND_FAILED       the channel rejected or could not take a send
-- severity is info | warning | danger.
-- status  is PENDING | SENT | FAILED | NO_CHANNEL   (NO_CHANNEL is A3.4).
-- targetKind is admin | gym | subscription | audit | platform.
-- targetId holds a UUID only. It must never hold a name, an email, a phone number or a
-- national id; the PII crawl asserts that on the alert list route (A3.7).

-- A3.5: the same type for the same target inside one window collapses into one alert.
-- The window is folded into the key itself, so collapsing is a plain uniqueness
-- violation handled with ON CONFLICT rather than a read-then-write race.
CREATE UNIQUE INDEX IF NOT EXISTS "PlatformAlert_dedupeKey_key"
  ON public."PlatformAlert"("dedupeKey");

-- A3.2: the retry cron claims by status and due time, so that pair is the hot path.
CREATE INDEX IF NOT EXISTS "PlatformAlert_status_nextAttemptAt_idx"
  ON public."PlatformAlert"("status", "nextAttemptAt");
CREATE INDEX IF NOT EXISTS "PlatformAlert_type_createdAt_idx"
  ON public."PlatformAlert"("type", "createdAt");
CREATE INDEX IF NOT EXISTS "PlatformAlert_createdAt_idx"
  ON public."PlatformAlert"("createdAt");

-- -----------------------------------------------------------------------------
-- 2. The admin device baseline (A4.2). No raw IP and no raw user agent are stored:
--    only the keyed digest, the normalised UA triple, and counters.
-- -----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public."PlatformAdminDevice" (
  "id"           text        NOT NULL,
  "adminId"      text        NOT NULL,
  "deviceHash"   text        NOT NULL,
  "uaFamily"     text        NOT NULL DEFAULT 'Unknown',
  "uaMajor"      integer     NOT NULL DEFAULT 0,
  "osFamily"     text        NOT NULL DEFAULT 'Unknown',
  "ipOnly"       boolean     NOT NULL DEFAULT false,
  "source"       text        NOT NULL DEFAULT 'LOGIN',
  "firstSeenAt"  timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "lastSeenAt"   timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "loginCount"   integer     NOT NULL DEFAULT 1,
  CONSTRAINT "PlatformAdminDevice_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PlatformAdminDevice_adminId_fkey" FOREIGN KEY ("adminId")
    REFERENCES public."PlatformAdmin"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- One row per (admin, device digest). This is what makes seeding idempotent (A4.6) and
-- what makes a repeated login from a known device a counter bump rather than a new row.
CREATE UNIQUE INDEX IF NOT EXISTS "PlatformAdminDevice_adminId_deviceHash_key"
  ON public."PlatformAdminDevice"("adminId", "deviceHash");
CREATE INDEX IF NOT EXISTS "PlatformAdminDevice_adminId_idx"
  ON public."PlatformAdminDevice"("adminId");

-- ipOnly marks a baseline entry that came from a successful PlatformLoginAttempt, which
-- records an IP but no user agent. Such an entry can say "this IP has been seen before"
-- and is used to make an alert message more useful. It must NEVER suppress a new-device
-- alert, because a known IP with an unseen browser or OS is exactly the case worth
-- reporting. The tests assert that.

-- -----------------------------------------------------------------------------
-- 3. One user-agent rule (A4.3), used by the seeding below AND by the runtime device
--    check. Normalising to browser family + major version + operating system is what
--    stops a routine minor browser update from alerting: Chrome 130.0.6723.92 and
--    Chrome 130.0.6723.119 both normalise to (Chrome, 130, ...).
--
--    Detection order is part of the rule and must not be rearranged: Edge, Opera and
--    Samsung browsers all advertise "Chrome" and "Safari" in their user-agent strings,
--    and Firefox and Chrome on iOS advertise "Safari", so the specific engines are
--    tested before the generic ones. Android is tested before Linux for the same reason.
--
--    Known limitation, documented rather than hidden: since iPadOS 13 an iPad asks for
--    the desktop site by default and reports "Macintosh", so it normalises to macOS.
--    That makes an iPad and a Mac the same device family - fewer alerts, not more.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_normalize_ua(p_user_agent text)
  RETURNS TABLE (
    ua_family text,
    ua_major  integer,
    os_family text
  )
  LANGUAGE sql
  IMMUTABLE
  SECURITY INVOKER
  SET search_path = pg_catalog, public
  AS $fn$
    SELECT
      CASE
        WHEN p_user_agent IS NULL OR p_user_agent = '' THEN 'Unknown'
        WHEN p_user_agent ~ 'OPR/[0-9]+|Opera/[0-9]+'          THEN 'Opera'
        WHEN p_user_agent ~ 'Edg/[0-9]+|Edge/[0-9]+'           THEN 'Edge'
        WHEN p_user_agent ~ 'SamsungBrowser/[0-9]+'            THEN 'Samsung'
        WHEN p_user_agent ~ 'FxiOS/[0-9]+|Firefox/[0-9]+'      THEN 'Firefox'
        WHEN p_user_agent ~ 'CriOS/[0-9]+|Chrome/[0-9]+|Chromium/[0-9]+' THEN 'Chrome'
        WHEN p_user_agent ~ 'Version/[0-9]+.*Safari/'          THEN 'Safari'
        WHEN p_user_agent ~ 'curl/[0-9]+'                      THEN 'curl'
        WHEN p_user_agent ~ 'node|undici|axios|python-requests|Go-http-client' THEN 'Bot'
        ELSE 'Unknown'
      END,
      coalesce(
        (regexp_match(p_user_agent,
          '(?:OPR|Opera|Edg|Edge|SamsungBrowser|FxiOS|Firefox|CriOS|Chrome|Chromium|Version|curl)/([0-9]+)'))[1]::integer,
        0),
      CASE
        WHEN p_user_agent IS NULL OR p_user_agent = '' THEN 'Unknown'
        WHEN p_user_agent ~ 'Windows'                        THEN 'Windows'
        WHEN p_user_agent ~ 'Android'                        THEN 'Android'
        WHEN p_user_agent ~ 'iPhone|iPad|iPod'               THEN 'iOS'
        WHEN p_user_agent ~ 'CrOS'                           THEN 'ChromeOS'
        WHEN p_user_agent ~ 'Mac OS X|Macintosh'             THEN 'macOS'
        WHEN p_user_agent ~ 'Linux|X11'                      THEN 'Linux'
        ELSE 'Unknown'
      END;
  $fn$;

-- -----------------------------------------------------------------------------
-- 4. The keyed device digest. The key is passed in by the caller (the api derives it
--    from OTP_HMAC_SECRET by domain separation); it is never stored and never appears
--    in this file.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_device_hash(
    p_key      text,
    p_ip       text,
    p_family   text,
    p_major    integer,
    p_os       text
  )
  RETURNS text
  LANGUAGE sql
  IMMUTABLE
  SECURITY INVOKER
  SET search_path = pg_catalog, public
  AS $fn$
    SELECT encode(sha256(convert_to(
        p_key || '|'
     || coalesce(p_ip, '') || '|'
     || coalesce(p_family, 'Unknown') || '|'
     || coalesce(p_major, 0)::text || '|'
     || coalesce(p_os, 'Unknown') || '|'
     || p_key
    , 'UTF8')), 'hex');
  $fn$;

-- -----------------------------------------------------------------------------
-- 5. Seeding (A4.1 and A4.6): set-based, idempotent, additive, and safe on an empty
--    table. One INSERT ... SELECT, no per-row round trips.
--
--    A4.1 restricts the sources to SUCCESSFUL logins. Every "PlatformSession" row exists
--    only because a login succeeded, so all of them qualify and they are the only source
--    that carries a user agent. Successful "PlatformLoginAttempt" rows are also seeded,
--    but they record no user agent, so they become ipOnly entries that can enrich an
--    alert message and can never suppress one.
--
--    Failed attempts are NOT seeded. Seeding from them would turn an attacker's past
--    guesses into "known" devices and silence the alert on the attempt that works.
--
--    Idempotence comes from ON CONFLICT DO NOTHING on (adminId, deviceHash): running
--    this twice inserts nothing the second time, which is what makes it safe to call on
--    every api start.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_seed_admin_devices(p_device_key text)
  RETURNS TABLE (seeded integer, considered integer)
  LANGUAGE sql
  SECURITY INVOKER
  SET search_path = pg_catalog, public
  AS $fn$
    WITH candidates AS (
      -- Successful logins that still have a session: admin id, IP and user agent.
      SELECT
          pa.id                       AS admin_id,
          coalesce(s.ip, '')                AS ip,
          s."userAgent"                     AS user_agent,
          false                             AS ip_only,
          'MIGRATION_SEED'                  AS source,
          coalesce(s."createdAt", CURRENT_TIMESTAMP) AS seen_at
        FROM public."PlatformSession" s
        -- The join is an existence check, not a lookup. PlatformSession.adminId has NO foreign
        -- key (measured: pg_constraint has no 'f' row for that table), so a session row can
        -- outlive the administrator it belongs to. On the development database two sessions
        -- referenced an administrator that no longer existed, seeding from them violated
        -- PlatformAdminDevice_adminId_fkey, and the whole seed aborted at boot. A baseline
        -- entry for an administrator who is gone is worthless anyway, and this table's own ON
        -- DELETE CASCADE would remove it the moment they were deleted.
        JOIN public."PlatformAdmin" pa ON pa.id = s."adminId"
       WHERE s."adminId" IS NOT NULL
      UNION ALL
      -- Successful login attempts whose session is gone: IP only, no user agent. The
      -- admin is resolved through the email the attempt recorded.
      SELECT
          pa.id,
          coalesce(la.ip, ''),
          NULL::text,
          true,
          'MIGRATION_SEED',
          coalesce(la."createdAt", CURRENT_TIMESTAMP)
        FROM public."PlatformLoginAttempt" la
        JOIN public."PlatformAdmin" pa ON pa.email = la.email
       WHERE upper(la.outcome) = 'SUCCESS'
    ), normalised AS (
      SELECT
          c.admin_id,
          c.ip,
          n.ua_family,
          n.ua_major,
          n.os_family,
          c.ip_only,
          c.source,
          c.seen_at,
          public.platform_device_hash(p_device_key, c.ip, n.ua_family, n.ua_major, n.os_family) AS device_hash
        FROM candidates c
        CROSS JOIN LATERAL public.platform_normalize_ua(c.user_agent) n
    ), inserted AS (
      INSERT INTO public."PlatformAdminDevice"
        ("id", "adminId", "deviceHash", "uaFamily", "uaMajor", "osFamily",
         "ipOnly", "source", "firstSeenAt", "lastSeenAt", "loginCount")
      SELECT
          -- A deterministic id derived from the digest, so a re-run cannot create a
          -- second row for the same device even before the unique index is consulted.
          'dev_' || md5(d.admin_id || '|' || d.device_hash),
          d.admin_id,
          d.device_hash,
          d.ua_family,
          d.ua_major,
          d.os_family,
          d.ip_only,
          d.source,
          min(d.seen_at),
          max(d.seen_at),
          count(*)
        FROM normalised d
       GROUP BY d.admin_id, d.device_hash, d.ua_family, d.ua_major, d.os_family, d.ip_only, d.source
      ON CONFLICT ("adminId", "deviceHash") DO NOTHING
      RETURNING 1
    )
    -- Cast to integer on purpose: count(*) is bigint, Prisma maps bigint to a JS
    -- BigInt, and JSON.stringify throws on BigInt. These two numbers are returned to
    -- the api at start-up, so they must be plain numbers.
    SELECT (SELECT count(*) FROM inserted)::integer,
           (SELECT count(*) FROM normalised)::integer;
  $fn$;

-- -----------------------------------------------------------------------------
-- 6. The retry claim (A3.2). FOR UPDATE SKIP LOCKED means two cron runs, or two api
--    replicas, can claim disjoint sets and cannot both send the same alert. The claim
--    increments "attempts" in the same statement, so a crash between claim and result
--    costs one attempt rather than looping forever: after "maxAttempts" claims the row
--    is left PENDING with no due time in the past, and the caller marks it FAILED.
--
--    A row whose status is already SENT is never selected, which is what makes a retry
--    incapable of re-sending a delivered alert.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.platform_claim_alerts_for_retry(
    p_now   timestamp(3),
    p_limit integer
  )
  RETURNS TABLE (
    alert_id     text,
    alert_type   text,
    severity     text,
    target_kind  text,
    target_id    text,
    audit_seq    integer,
    attempts     integer,
    max_attempts integer
  )
  LANGUAGE sql
  SECURITY INVOKER
  SET search_path = pg_catalog, public
  AS $fn$
    WITH claimable AS (
      SELECT a."id"
        FROM public."PlatformAlert" a
       WHERE a.status = 'PENDING'
         AND (a."nextAttemptAt" IS NULL OR a."nextAttemptAt" <= p_now)
       ORDER BY a."createdAt"
       LIMIT least(greatest(p_limit, 1), 100)
       FOR UPDATE SKIP LOCKED
    ), claimed AS (
      UPDATE public."PlatformAlert" a
         SET "attempts"      = a."attempts" + 1,
             "lastAttemptAt" = p_now,
             "updatedAt"     = p_now
        FROM claimable c
       WHERE a."id" = c."id"
      RETURNING a."id", a."type", a.severity, a."targetKind", a."targetId",
                a."auditSeq", a."attempts", a."maxAttempts"
    )
    SELECT cl."id", cl."type", cl.severity, cl."targetKind", cl."targetId",
           cl."auditSeq", cl."attempts", cl."maxAttempts"
      FROM claimed cl;
  $fn$;

-- -----------------------------------------------------------------------------
-- 7. Least privilege, following the R2 convention: EXECUTE revoked from PUBLIC and
--    granted only to the runtime role, whose name is written out explicitly. A
--    deployment whose runtime role is not named flexora_app must adjust these GRANTs;
--    scripts/check-db-compat.sh exercises the supported owner profiles.
--
--    All four functions are SECURITY INVOKER. They read and write only platform tables
--    on which the runtime role already holds the needed privileges through the
--    ALTER DEFAULT PRIVILEGES statement in migration 202607050001, so running them as
--    the caller grants nothing extra and adds no new requirement to the compatibility
--    matrix.
-- -----------------------------------------------------------------------------

REVOKE ALL ON FUNCTION public.platform_normalize_ua(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_device_hash(text, text, text, integer, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_seed_admin_devices(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_claim_alerts_for_retry(timestamp(3), integer) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.platform_normalize_ua(text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_device_hash(text, text, text, integer, text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_seed_admin_devices(text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_claim_alerts_for_retry(timestamp(3), integer) TO flexora_app;

-- =============================================================================
-- DOWN MIGRATION
-- A separate, documented file: prisma/migrations/20261107130000_platform_alerts_r3/down.sql
-- Prisma does not run down migrations, so this one is applied by hand and is tested on a
-- COPY of the database (owner decisions A3.8 and A4.6). Because this migration is purely
-- additive, the down migration is purely subtractive: dropping the two tables and the
-- four functions returns the database to exactly its pre-R3 state.
-- =============================================================================
