-- =============================================================================
-- FLEXORA PHASE R1 - platform (owner console) authentication: server-side
-- sessions, mandatory TOTP, recovery codes, lockout state, admin approval.
--
-- Every statement here is additive. No tenant table is altered, no tenant
-- column changes meaning, and no existing row is rewritten.
--
-- SECURITY DEFINER conventions are copied from the two existing precedent
-- migrations (202607070001_preauth_lookup_function and
-- 202607160001_restrict_preauth_functions): the function is owned by whichever
-- role runs `prisma migrate deploy` (never the runtime role), search_path is
-- pinned, every object is schema-qualified, parameters are typed, there is no
-- dynamic SQL, EXECUTE is revoked from PUBLIC and granted only to the runtime
-- role.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. PlatformAdmin: TOTP state, lockout state, approval state.
--    All columns are nullable or defaulted, so existing rows stay valid.
-- ---------------------------------------------------------------------------
ALTER TABLE "PlatformAdmin"
  ADD COLUMN IF NOT EXISTS "totpSecret"         TEXT,
  ADD COLUMN IF NOT EXISTS "totpEnabled"        BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS "totpLastUsedStep"   INTEGER,
  ADD COLUMN IF NOT EXISTS "totpEnrolledAt"     TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "failedLoginCount"   INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "lockedUntil"        TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "mustChangePassword" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS "status"             TEXT NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN IF NOT EXISTS "requestedBy"        TEXT,
  ADD COLUMN IF NOT EXISTS "approvedBy"         TEXT,
  ADD COLUMN IF NOT EXISTS "approvedAt"         TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "approvalExpiresAt"  TIMESTAMP(3);

CREATE INDEX IF NOT EXISTS "PlatformAdmin_status_idx" ON "PlatformAdmin"("status");

-- totpLastUsedStep is the replay-protection counter: the UNIX step
-- (floor(epoch_seconds / 30)) of the most recent code this admin has already
-- spent. INTEGER is enough (the step is ~59,000,000 today) and, unlike BIGINT,
-- it survives JSON serialisation in the API layer.

-- ---------------------------------------------------------------------------
-- 2. PlatformSession: the revocable server-side session (R1.4).
--    tokenHash is sha256 of the cookie value, never the value itself, so a
--    database leak yields nothing an attacker can present.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "PlatformSession" (
  "id"              TEXT NOT NULL,
  "adminId"         TEXT NOT NULL,
  "tokenHash"       TEXT NOT NULL,
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "lastSeenAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt"       TIMESTAMP(3) NOT NULL,
  "idleExpiresAt"   TIMESTAMP(3) NOT NULL,
  "revokedAt"       TIMESTAMP(3),
  "revokeReason"    TEXT,
  "ip"              TEXT,
  "userAgent"       TEXT,
  "totpPending"     BOOLEAN NOT NULL DEFAULT false,
  "stepUpAt"        TIMESTAMP(3),
  "stepUpExpiresAt" TIMESTAMP(3),
  CONSTRAINT "PlatformSession_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "PlatformSession_tokenHash_key" ON "PlatformSession"("tokenHash");
CREATE INDEX IF NOT EXISTS "PlatformSession_adminId_idx" ON "PlatformSession"("adminId");
CREATE INDEX IF NOT EXISTS "PlatformSession_expiresAt_idx" ON "PlatformSession"("expiresAt");
CREATE INDEX IF NOT EXISTS "PlatformSession_active_idx" ON "PlatformSession"("adminId", "revokedAt", "expiresAt");

-- ---------------------------------------------------------------------------
-- 3. PlatformRecoveryCode: 10 single-use codes per enrolment, argon2id hashed
--    by the SAME shared options the API uses for passwords (R1.1/R1.2).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "PlatformRecoveryCode" (
  "id"        TEXT NOT NULL,
  "adminId"   TEXT NOT NULL,
  "codeHash"  TEXT NOT NULL,
  "label"     TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "usedAt"    TIMESTAMP(3),
  "replacedAt" TIMESTAMP(3),
  CONSTRAINT "PlatformRecoveryCode_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "PlatformRecoveryCode_adminId_idx" ON "PlatformRecoveryCode"("adminId", "usedAt");

-- ---------------------------------------------------------------------------
-- 4. PlatformLoginAttempt: the per-account and per-IP evidence trail (R1.3).
--    Kept separate from PlatformAuditLog so a flood of failures cannot bury the
--    administrative audit trail.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "PlatformLoginAttempt" (
  "id"        TEXT NOT NULL,
  "email"     TEXT,
  "ip"        TEXT,
  "outcome"   TEXT NOT NULL,
  "detail"    TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PlatformLoginAttempt_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "PlatformLoginAttempt_email_idx" ON "PlatformLoginAttempt"("email", "createdAt");
CREATE INDEX IF NOT EXISTS "PlatformLoginAttempt_ip_idx" ON "PlatformLoginAttempt"("ip", "createdAt");

-- ---------------------------------------------------------------------------
-- 5. SECURITY DEFINER functions for the console's cross-tenant reads (RV5).
--
-- WHY THEY ARE NEEDED (measured, work/r1-evidence/00-before.log section B5):
-- the runtime role flexora_app is NOSUPERUSER NOBYPASSRLS and the tenant tables
-- carry FORCE ROW LEVEL SECURITY, so the $queryRaw aggregates in
-- platform.controller.ts - whose own comment claims they "bypass FORCE RLS" -
-- return ZERO. $queryRaw runs as the connecting role; it bypasses nothing. The
-- console's numbers are therefore only correct when DATABASE_URL happens to use
-- a superuser, which is exactly the posture the product documents as wrong.
--
-- Each function below reproduces ONE existing query, with the same tables, the
-- same predicates and the same result types, so response shapes do not change.
-- Conventions (copied from 202607070001_preauth_lookup_function and
-- 202607160001_restrict_preauth_functions): SECURITY DEFINER, owned by whoever
-- runs `prisma migrate deploy` (never the runtime role), search_path pinned to
-- pg_catalog + public, every object schema-qualified, typed parameters only, no
-- dynamic SQL, aggregates and gym-level fields only - never member PII.
--
-- Prisma maps DateTime to timestamp(3) (not timestamptz), so the time
-- parameters are timestamp(3): passing a timestamptz here would make Postgres
-- convert through the session TimeZone and silently shift the window.
-- ---------------------------------------------------------------------------

-- platform.controller.ts countAllMembers(): SELECT COUNT(*)::bigint FROM "Member"
CREATE OR REPLACE FUNCTION public.platform_count_members()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COUNT(*)::bigint FROM public."Member";
$fn$;

-- platform.controller.ts allSubscriptions():
--   SELECT id, "gymId", tier, status, "lastPaymentAt", "lastPaymentAmount"
--   FROM "Subscription" LIMIT 50
-- The enum columns are cast to text so the caller sees exactly the strings the
-- controller compares against today ('TRIALING', 'PRO', 'ELITE', 'CANCELED').
CREATE OR REPLACE FUNCTION public.platform_list_recent_subscriptions(p_limit integer)
RETURNS TABLE (
  id                  text,
  gym_id              text,
  tier                text,
  status              text,
  last_payment_at     timestamp(3),
  last_payment_amount integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT s.id::text,
         s."gymId"::text,
         s.tier::text,
         s.status::text,
         s."lastPaymentAt",
         s."lastPaymentAmount"
  FROM public."Subscription" s
  LIMIT LEAST(GREATEST(p_limit, 1), 50);
$fn$;

-- platform.controller.ts sumRevenueSince(since):
--   SELECT SUM("lastPaymentAmount")::bigint FROM "Subscription" WHERE "lastPaymentAt" >= $1
CREATE OR REPLACE FUNCTION public.platform_sum_subscription_revenue_since(p_since timestamp(3))
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COALESCE(SUM(s."lastPaymentAmount"), 0)::bigint
  FROM public."Subscription" s
  WHERE s."lastPaymentAt" >= p_since;
$fn$;

-- platform.controller.ts sumRevenueBetween(since, until):
--   ... WHERE "lastPaymentAt" >= $1 AND "lastPaymentAt" < $2
CREATE OR REPLACE FUNCTION public.platform_sum_subscription_revenue_between(
  p_since timestamp(3),
  p_until timestamp(3)
)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COALESCE(SUM(s."lastPaymentAmount"), 0)::bigint
  FROM public."Subscription" s
  WHERE s."lastPaymentAt" >= p_since
    AND s."lastPaymentAt" <  p_until;
$fn$;

-- platform.controller.ts sumRevenueForGym(gymId):
--   SELECT SUM(amount)::bigint FROM "Transaction" WHERE "gymId" = $1 AND type = 'INCOME'
-- The ::bigint truncation of a Decimal(14,2) column is today's behaviour and is
-- preserved deliberately; changing it would change the numbers the console shows.
CREATE OR REPLACE FUNCTION public.platform_sum_transaction_income_for_gym(p_gym_id text)
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT COALESCE(SUM(t.amount), 0)::bigint
  FROM public."Transaction" t
  WHERE t."gymId" = p_gym_id
    AND t.type = 'INCOME'::public."TxType";
$fn$;

-- platform.controller.ts monthSeries(months, 'revenue'):
--   SELECT "lastPaymentAt", "lastPaymentAmount" FROM "Subscription"
--   WHERE "lastPaymentAt" >= $1 ORDER BY "lastPaymentAt" DESC LIMIT 5000
-- Subscription-level (gym-level) rows only: no member id, no name, no contact
-- detail. The bucketing into months stays in TypeScript, exactly as today.
CREATE OR REPLACE FUNCTION public.platform_subscription_payments_since(
  p_since timestamp(3),
  p_limit integer
)
RETURNS TABLE (
  last_payment_at     timestamp(3),
  last_payment_amount integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
  SELECT s."lastPaymentAt", s."lastPaymentAmount"
  FROM public."Subscription" s
  WHERE s."lastPaymentAt" >= p_since
  ORDER BY s."lastPaymentAt" DESC
  LIMIT LEAST(GREATEST(p_limit, 1), 5000);
$fn$;

-- ---------------------------------------------------------------------------
-- 6. Lock the functions down: PostgreSQL grants EXECUTE to PUBLIC by default.
--    Written out explicitly, as the precedent migration does, so this file
--    contains no dynamic SQL at all.
-- ---------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.platform_count_members() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_list_recent_subscriptions(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_sum_subscription_revenue_since(timestamp(3)) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_sum_subscription_revenue_between(timestamp(3), timestamp(3)) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_sum_transaction_income_for_gym(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.platform_subscription_payments_since(timestamp(3), integer) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.platform_count_members() TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_list_recent_subscriptions(integer) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_sum_subscription_revenue_since(timestamp(3)) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_sum_subscription_revenue_between(timestamp(3), timestamp(3)) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_sum_transaction_income_for_gym(text) TO flexora_app;
GRANT EXECUTE ON FUNCTION public.platform_subscription_payments_since(timestamp(3), integer) TO flexora_app;

-- NOTE: the runtime role name is written out explicitly, exactly as
-- 202607160001_restrict_preauth_functions does. A deployment whose runtime role
-- is not named flexora_app must adjust these GRANTs; scripts/check-db-compat.sh
-- exercises the supported owner profiles and is re-run for this migration.

-- ---------------------------------------------------------------------------
-- 7. NOT converted here, reported instead (scope honesty).
--
--    GET /api/platform/subscriptions  (prisma.subscription.findMany + count,
--    include: { gym: true }) and GET /api/platform/gyms (include: { users:
--    { take: 1 }, _count: { members } }) and GET /api/platform/gyms/:id
--    (include: { users: true }) are cross-tenant reads too, and they return
--    ZERO rows / empty arrays under the runtime role for the same reason. They
--    are NOT converted in R1 because their present shape embeds staff PII
--    (User rows: names, emails, phone numbers) which R2 forbids in console
--    responses. Writing a SECURITY DEFINER function now would freeze a shape
--    that R2 must immediately break. Both are measured in the BEFORE evidence
--    and reported as FOUND IN R1, FIXED IN R2, with the PII rule that decides
--    their final shape.
-- ---------------------------------------------------------------------------
