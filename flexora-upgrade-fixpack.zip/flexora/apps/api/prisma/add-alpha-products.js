const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const gym = await prisma.gym.findUnique({ where: { slug: 'alpha' } });
  if (!gym) { console.log('alpha gym not found'); return; }
  const products = [
    { name: 'Whey Protein', category: 'protein', barcode: 'BAR-ALPHA-001', sellingPrice: 1450, costPrice: 1050, qty: 50 },
    { name: 'Creatine', category: 'creatine', barcode: 'BAR-ALPHA-002', sellingPrice: 520, costPrice: 360, qty: 30 },
    { name: 'Water 600ml', category: 'water', barcode: 'BAR-ALPHA-003', sellingPrice: 10, costPrice: 5, qty: 200 },
  ];
  const created = [];
  for (const p of products) {
    const prod = await prisma.product.create({
      data: { gymId: gym.id, name: p.name, category: p.category, barcode: p.barcode, sellingPrice: p.sellingPrice, costPrice: p.costPrice, qty: p.qty, lowStockThreshold: 5 },
    });
    created.push(prod.id);
  }
  console.log(JSON.stringify(created));
}
main().catch(console.error).finally(() => prisma.$disconnect());
