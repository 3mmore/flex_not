const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const user = await prisma.user.findFirst({ where: { email: 'owner@alpha.flexora.app' }, include: { gym: true } });
  const members = await prisma.member.findMany({ where: { gymId: user.gymId }, take: 3, select: { code: true, name: true } });
  console.log(JSON.stringify({ gymId: user.gymId, gymSlug: user.gym.slug, members }, null, 2));
}
main().catch(console.error).finally(() => prisma.$disconnect());
