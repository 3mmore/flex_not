/**
 * FLEXORA Gym OS — SaaS Plans seed (Phase 8)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Seeds the three commercial tiers: STARTER / PRO / ELITE.
 * Idempotent — uses upsert by slug.
 */
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const PLANS = [
  {
    slug: 'starter',
    name: 'Starter',
    nameAr: 'الأساسية',
    tier: 'BASIC' as const,
    monthlyPrice: 29,
    yearlyPrice: 290,
    maxBranches: 1,
    maxMembers: 200,
    maxStaff: 3,
    features: {
      members: true,
      attendance: true,
      pos: true,
      multi_branch: false,
      ai: false,
      biometric: false,
      campaigns: false,
      leads: false,
      contracts: false,
      staff_attendance: false,
    },
    sortOrder: 1,
  },
  {
    slug: 'pro',
    name: 'Pro',
    nameAr: 'الاحترافية',
    tier: 'PRO' as const,
    monthlyPrice: 79,
    yearlyPrice: 790,
    maxBranches: 5,
    maxMembers: 2000,
    maxStaff: 15,
    features: {
      members: true,
      attendance: true,
      pos: true,
      multi_branch: true,
      ai: true,
      biometric: false,
      campaigns: true,
      leads: true,
      contracts: true,
      staff_attendance: true,
    },
    sortOrder: 2,
  },
  {
    slug: 'elite',
    name: 'Elite',
    nameAr: 'النخبة',
    tier: 'ELITE' as const,
    monthlyPrice: 199,
    yearlyPrice: 1990,
    maxBranches: 50,
    maxMembers: 20000,
    maxStaff: 100,
    features: {
      members: true,
      attendance: true,
      pos: true,
      multi_branch: true,
      ai: true,
      biometric: true,
      campaigns: true,
      leads: true,
      contracts: true,
      staff_attendance: true,
      webauthn: true,
      priority_support: true,
    },
    sortOrder: 3,
  },
];

async function main() {
  for (const p of PLANS) {
    await prisma.saasPlan.upsert({
      where: { slug: p.slug },
      update: {
        name: p.name,
        nameAr: p.nameAr,
        tier: p.tier,
        monthlyPrice: p.monthlyPrice,
        yearlyPrice: p.yearlyPrice,
        maxBranches: p.maxBranches,
        maxMembers: p.maxMembers,
        maxStaff: p.maxStaff,
        features: p.features,
        sortOrder: p.sortOrder,
        active: true,
      },
      create: p,
    });
    console.log(`[seed-plans] upserted ${p.slug}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
