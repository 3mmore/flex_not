const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const members = await prisma.member.findMany({ where: { gym: { slug: 'alpha' } }, take: 5, select: { code: true } });
  const products = await prisma.product.findMany({ where: { gym: { slug: 'alpha' } }, take: 3, select: { id: true, name: true } });
  console.log(JSON.stringify({ members: members.map(m => m.code), products }, null, 2));
}
main().catch(console.error).finally(() => prisma.$disconnect());
