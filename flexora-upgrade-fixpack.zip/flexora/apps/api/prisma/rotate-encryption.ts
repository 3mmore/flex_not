/**
 * PHASE M3.3 — re-encrypt stored data after an encryption key rotation.
 *
 * Run from apps/api:
 *
 *   # standard (versioned) keys — report only, writes nothing
 *   npx ts-node prisma/rotate-encryption.ts
 *
 *   # after checking the report
 *   npx ts-node prisma/rotate-encryption.ts --apply
 *
 *   # search-key rotation (deterministic fields) — needs BOTH keys present:
 *   #   OLD_ENCRYPTION_SEARCH_KEY=<old>  ENCRYPTION_SEARCH_KEY=<new>
 *   npx ts-node prisma/rotate-encryption.ts --search --apply
 *
 * Safety rules, in the order they matter:
 *   1. Dry run is the default. Nothing is written without --apply.
 *   2. Every target column is checked against the generated Prisma client
 *      before anything is read, so a renamed column aborts instead of silently
 *      leaving a table behind.
 *   3. A row that cannot be decrypted aborts the whole run BEFORE any write.
 *      Skipping it would mean overwriting good data with something unreadable.
 *   4. Writes for one column run in a single transaction.
 */
import { PrismaClient } from '@prisma/client';
import { EncryptionService } from '../src/common/security/encryption.service';
import {
  ENCRYPTED_FIELDS,
  FieldStats,
  RotationTarget,
  planField,
} from '../src/common/security/encryption-rotation';

/**
 * Rotation must see EVERY tenant's rows, so it connects with the owner/superuser
 * url (DIRECT_URL) rather than the application url (DATABASE_URL).
 *
 * This is not a preference, it is a correctness requirement: the `flexora_app`
 * role is NOSUPERUSER/NOBYPASSRLS and every table has RLS FORCED, so with no
 * tenant in the session that role reads ZERO rows. A rotation run that way
 * reports "Nothing to do" and exits 0 while every row is still on the old key —
 * a silent no-op that looks like success. assertUnrestrictedConnection() makes
 * that impossible to miss.
 */
const ROTATION_URL = process.env.DIRECT_URL || process.env.DATABASE_URL;
const prisma = new PrismaClient({
  datasources: { db: { url: ROTATION_URL } },
});

async function assertUnrestrictedConnection(): Promise<string> {
  const rows: { user: string; canbypass: boolean }[] = await prisma.$queryRaw`
    SELECT current_user AS "user",
           (SELECT rolsuper OR rolbypassrls FROM pg_roles WHERE rolname = current_user) AS "canbypass"
  `;
  const role = rows[0]?.user || 'unknown';
  if (!rows[0]?.canbypass) {
    console.error(
      `\nFATAL: connected as '${role}', which cannot bypass row-level security.\n` +
        '       Every table has RLS FORCED, so this role reads zero rows outside a\n' +
        '       tenant session and the rotation would report "nothing to do" while\n' +
        '       leaving every row on the OLD key.\n' +
        '       Set DIRECT_URL to the owner/superuser connection and run again.\n',
    );
    process.exit(1);
  }
  return role;
}

function buildService(overrides: Record<string, string | undefined>): EncryptionService {
  const saved: Record<string, string | undefined> = {};
  for (const [k, v] of Object.entries(overrides)) {
    saved[k] = process.env[k];
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  const svc = new EncryptionService();
  try {
    svc.onModuleInit();
  } finally {
    for (const [k, v] of Object.entries(saved)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
  }
  return svc;
}

function delegate(model: string): any {
  const d = (prisma as any)[model];
  if (!d || typeof d.findMany !== 'function') {
    throw new Error(`Prisma model '${model}' does not exist — the rotation inventory is out of date.`);
  }
  return d;
}

function runtimeModel(model: string): any {
  // The runtime data model is keyed by the PascalCase model name (Member),
  // while the delegate on the client is camelCase (member). Look up both, and
  // fail loudly if neither matches: a silent miss here would mean skipping a
  // whole column of encrypted data.
  const models = (prisma as any)._runtimeDataModel?.models || {};
  const exact = models[model] || models[model.charAt(0).toUpperCase() + model.slice(1)];
  const found =
    exact ||
    Object.entries(models).find(([name]) => name.toLowerCase() === model.toLowerCase())?.[1];
  if (!found) {
    throw new Error(`Model '${model}' is not in the generated client — the rotation inventory is out of date.`);
  }
  return found;
}

/** True when the column can hold NULL (found on the live schema by running this). */
function columnIsNullable(model: string, field: string): boolean {
  const entry = runtimeModel(model);
  const fields: any[] = entry.fields || [];
  const f = fields.find((x: any) => x.name === field);
  if (!f) {
    throw new Error(`Column '${model}.${field}' does not exist — the rotation inventory is out of date.`);
  }
  // `isRequired` is true for NOT NULL columns. Filtering those with
  // `{ not: null }` makes Prisma reject the query outright, so skip the filter
  // there — every row already has a value.
  return f.isRequired === false;
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2);
  const apply = argv.includes('--apply');
  const searchMode = argv.includes('--search');

  console.log(`\n=== encryption rotation (${apply ? 'APPLY' : 'DRY RUN'}) ===`);
  console.log(`mode:  ${searchMode ? 'search key (deterministic fields)' : 'standard versioned keys'}`);

  // --- build the reader (old key) and writer (new key) ---------------------
  const writer = buildService({});
  const targetKid = searchMode ? 'search-v1' : (process.env.ENCRYPTION_CURRENT_KID || 'v0');

  let reader = writer;
  if (searchMode) {
    const old = process.env.OLD_ENCRYPTION_SEARCH_KEY;
    if (!old) {
      console.error(
        '\nFATAL: search-key rotation needs the old key in OLD_ENCRYPTION_SEARCH_KEY\n' +
          '       and the new key in ENCRYPTION_SEARCH_KEY, so each row can be\n' +
          '       decrypted with one and encrypted with the other.\n',
      );
      process.exit(1);
    }
    reader = buildService({ ENCRYPTION_SEARCH_KEY: old });
  }
  const role = await assertUnrestrictedConnection();
  console.log(`target kid: ${targetKid}`);
  console.log(`connection: ${role} (RLS bypass confirmed)\n`);

  // --- verify the inventory before touching data ---------------------------
  const targets: RotationTarget[] = ENCRYPTED_FIELDS.filter((t) =>
    searchMode ? t.kind === 'deterministic' : t.kind === 'standard',
  );
  const nullable = new Map<string, boolean>();
  for (const t of targets) {
    delegate(t.model);
    nullable.set(`${t.model}.${t.field}`, columnIsNullable(t.model, t.field));
  }

  // --- plan every column first; an abort must happen before any write ------
  const allStats: FieldStats[] = [];
  const allWrites: { target: RotationTarget; rows: { id: string; value: unknown }[] }[] = [];

  for (const target of targets) {
    const where: Record<string, unknown> = { ...(target.where || {}) };
    // only nullable columns can be filtered for "has a value"
    if (nullable.get(`${target.model}.${target.field}`)) where[target.field] = { not: null };
    const rows = await delegate(target.model).findMany({
      where,
      select: { id: true, [target.field]: true },
    });
    const mapped = rows.map((r: any) => ({ id: r.id, value: r[target.field] }));
    const { stats, writes } = planField(target, mapped, reader, writer, targetKid);
    allStats.push(stats);
    if (writes.length) allWrites.push({ target, rows: writes });
  }

  // --- report -------------------------------------------------------------
  console.log('column                                  scanned  rotated  current  plain  failed');
  for (const s of allStats) {
    console.log(
      `${(s.model + '.' + s.field).padEnd(38)} ${String(s.scanned).padStart(7)} ${String(
        s.rotated,
      ).padStart(8)} ${String(s.alreadyCurrent).padStart(8)} ${String(s.plaintext).padStart(6)} ${String(
        s.failed,
      ).padStart(7)}`,
    );
  }

  for (const s of allStats) {
    if (s.firstError) console.log(`  ${s.model}.${s.field}: first failure — ${s.firstError}`);
  }

  const failed = allStats.reduce((n, s) => n + s.failed, 0);
  const rotated = allStats.reduce((n, s) => n + s.rotated, 0);

  if (failed > 0) {
    console.error(
      `\nABORT: ${failed} row(s) could not be decrypted. Nothing was written.\n` +
        '       The old key is probably missing from the environment — put it back\n' +
        '       (ENCRYPTION_KEY_V<n> for standard keys, OLD_ENCRYPTION_SEARCH_KEY\n' +
        '       for the search key) and run again. Never drop the old key until\n' +
        '       the rotation reports zero failures.',
    );
    process.exit(1);
  }

  if (rotated === 0) {
    console.log('\nNothing to do — every row is already on the target key.');
    return;
  }
  if (!apply) {
    console.log(`\nDry run: ${rotated} row(s) would be re-encrypted. Re-run with --apply.`);
    return;
  }

  // --- apply, one transaction per column ----------------------------------
  for (const { target, rows } of allWrites) {
    await prisma.$transaction(
      rows.map((r) =>
        delegate(target.model).update({
          where: { id: r.id },
          data: { [target.field]: r.value as any },
        }),
      ),
    );
    console.log(`  wrote ${rows.length} row(s) → ${target.model}.${target.field}`);
  }
  console.log(`\nDONE: ${rotated} row(s) re-encrypted to ${targetKid}.`);
}

main()
  .catch((e) => {
    console.error('\nROTATION FAILED — nothing was written.\n', e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
