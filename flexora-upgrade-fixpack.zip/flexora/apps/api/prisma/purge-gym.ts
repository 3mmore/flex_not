/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R2 (R2.9) - the ONLY way a gym's data is hard-deleted.
 *
 *   npm run purge:gym -- --slug <slug> --confirm <slug> --reason "<why>" [--execute]
 *
 * The console never hard-deletes: DELETE /api/platform/gyms/:id sets status=DELETED and
 * deletedAt, and the gym stays restorable for 30 days (decision Q1). This CLI is the
 * irreversible step, and it is deliberately awkward to run.
 *
 * GATES, in order, all of them before a single write:
 *   1. DATABASE_ADMIN_URL must be set. It is an OPERATOR-ONLY variable: the api process
 *      must never be given it (decision Q7). Its value is never printed.
 *   2. ROLE VERIFICATION (decision Q7, addition b): the connected role must be the owner
 *      of public."Gym", a superuser, or BYPASSRLS. The runtime role flexora_app is
 *      NOSUPERUSER NOBYPASSRLS and every tenant table carries FORCE ROW LEVEL SECURITY,
 *      so as that role this CLI would see zero rows and "succeed" while deleting
 *      nothing. It refuses instead, with no database writes at all.
 *   3. VISIBILITY (addition c): the gym must be found by slug AND be visible to this
 *      connection. Not visible -> refuse.
 *   4. The gym must be status=DELETED with deletedAt at least 30 days old. No --force:
 *      the window cannot be bypassed by a flag (decision Q3, option a).
 *   5. --confirm must equal the slug exactly, and --reason must be a real sentence.
 *   6. Dry run by DEFAULT. --execute is required to act.
 *   7. POST-EXECUTE RE-COUNT (addition d): inside the same transaction, after the
 *      deletes, every affected table and the Gym row itself are counted again. Any
 *      remainder throws, which rolls the whole transaction back and exits non-zero, so
 *      the CLI can never report success while deleting nothing.
 *
 * PRIVACY: the plan and the summary print COUNTS ONLY. No member name, mobile, email,
 * national id, payment amount or any other tenant value is ever printed, and no secret
 * value (including DATABASE_ADMIN_URL) is echoed.
 *
 * The delete order is DERIVED from the catalog at runtime, not hardcoded: 79 tables carry
 * a gymId column, 10 more reference those, and the FK delete rules on Gym are
 * CASCADE=64, RESTRICT=2 (GymSettings, RenewalRequest), SET NULL=1 (Notification). The
 * two RESTRICT rules are why the Gym row cannot simply be deleted and left to cascade.
 */
import { PrismaClient } from '@prisma/client';

const RETENTION_DAYS = 30;
const MIN_REASON_LENGTH = 8;
const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;
/** Quoted once, validated twice: identifiers come from pg_catalog, never from argv. */
const q = (ident: string) => {
  if (!IDENTIFIER.test(ident)) throw new Error(`refusing to use a non-identifier from the catalog: ${ident}`);
  return `"${ident}"`;
};

interface Args {
  slug?: string;
  confirm?: string;
  reason?: string;
  execute: boolean;
  help: boolean;
}

function parseArgs(argv: string[]): Args {
  const out: Args = { execute: false, help: false };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    const next = () => argv[++i];
    switch (token) {
      case '--slug': out.slug = next(); break;
      case '--confirm': out.confirm = next(); break;
      case '--reason': out.reason = next(); break;
      case '--execute': out.execute = true; break;
      case '--help': case '-h': out.help = true; break;
      default:
        if (token.startsWith('--slug=')) out.slug = token.slice(7);
        else if (token.startsWith('--confirm=')) out.confirm = token.slice(10);
        else if (token.startsWith('--reason=')) out.reason = token.slice(9);
        else throw new Error(`unknown argument: ${token}`);
    }
  }
  return out;
}

function usage(): string {
  return [
    'usage: npm run purge:gym -- --slug <slug> --confirm <slug> --reason "<why>" [--execute]',
    '',
    '  --slug      the gym to purge (must already be status=DELETED and 30 days old)',
    '  --confirm   the same slug, typed again; a mismatch refuses',
    '  --reason    why, recorded in the immutable platform audit log',
    '  --execute   actually delete. Without it this is a dry run that changes nothing',
    '',
    '  Requires DATABASE_ADMIN_URL (operator-only; never given to the api process).',
    '  Prints counts only - never a member name, mobile, email or payment amount.',
  ].join('\n');
}

/** One row of the FK graph, as the catalog reports it. */
interface Edge {
  child: string;
  childColumn: string;
  parent: string;
  rule: string;
}

interface PlanStep {
  table: string;
  predicate: string;
  params: string[];
  depth: number;
}

/**
 * Build the affected-table set and a delete order from the catalog.
 *
 * A table is affected if it carries a gymId column, or if it has a foreign key to an
 * affected table (transitively). Children are deleted before parents, so the two
 * RESTRICT FKs on Gym can never block the final delete.
 */
async function buildPlan(prisma: PrismaClient, gymId: string): Promise<PlanStep[]> {
  const columns = await prisma.$queryRawUnsafe<Array<{ table_name: string }>>(
    `SELECT c.table_name
       FROM information_schema.columns c
      WHERE c.table_schema = 'public' AND c.column_name = 'gymId'
      ORDER BY c.table_name`,
  );
  const edges = await prisma.$queryRawUnsafe<Array<{ child: string; child_column: string; parent: string; rule: string }>>(
    `SELECT cl.relname AS child,
            a.attname  AS child_column,
            fk.relname AS parent,
            CASE con.confdeltype WHEN 'a' THEN 'NO ACTION' WHEN 'r' THEN 'RESTRICT'
                 WHEN 'c' THEN 'CASCADE' WHEN 'n' THEN 'SET NULL' WHEN 'd' THEN 'SET DEFAULT' END AS rule
       FROM pg_constraint con
       JOIN pg_class cl ON cl.oid = con.conrelid
       JOIN pg_class fk ON fk.oid = con.confrelid
       JOIN pg_namespace n ON n.oid = cl.relnamespace
       JOIN pg_attribute a ON a.attrelid = con.conrelid AND a.attnum = con.conkey[1]
      WHERE con.contype = 'f' AND n.nspname = 'public'`,
  );
  const graph: Edge[] = edges.map((e) => ({
    child: e.child, childColumn: e.child_column, parent: e.parent, rule: e.rule,
  }));

  const direct = new Set(columns.map((c) => c.table_name));
  // predicate per table, built outward from the gym
  const predicate = new Map<string, { sql: string; params: string[]; depth: number }>();
  for (const table of direct) {
    predicate.set(table, { sql: `${q(table)}.${q('gymId')} = $1`, params: ['gymId'], depth: 0 });
  }

  // grow the set: any table whose FK points at an affected table inherits a predicate
  // through that FK. SET NULL needs no delete (the database clears the reference), so
  // those children are skipped - deleting their rows would destroy unrelated data.
  let grew = true;
  let guard = 0;
  while (grew && guard < 12) {
    grew = false;
    guard += 1;
    for (const edge of graph) {
      if (predicate.has(edge.child)) continue;
      const parent = predicate.get(edge.parent);
      if (!parent) continue;
      if (edge.rule === 'SET NULL') {
        predicate.set(edge.child, { sql: '', params: [], depth: -1 }); // -1 = do not delete
        grew = true;
        continue;
      }
      const parentPredicate = parent.sql.replace(new RegExp(`${q(edge.parent)}\\.`, 'g'), '');
      predicate.set(edge.child, {
        sql: `${q(edge.child)}.${q(edge.childColumn)} IN (SELECT ${q('id')} FROM ${q(edge.parent)} WHERE ${parentPredicate})`,
        params: parent.params,
        depth: parent.depth + 1,
      });
      grew = true;
    }
  }

  const steps: PlanStep[] = [];
  for (const [table, info] of predicate) {
    if (info.depth < 0 || !info.sql) continue;
    steps.push({ table, predicate: info.sql, params: info.params, depth: info.depth });
  }
  // ---- a real topological order, not a sort ---------------------------------
  // Depth-descending plus alphabetical is NOT a topological order. It only happened to
  // work on today's schema by coincidence: Member sorts before Plan (and
  // RenewalRequest.memberId is ON DELETE CASCADE, so the RESTRICT edge
  // RenewalRequest.planId -> Plan is never reached), and PurchaseOrder sorts before
  // Supplier. Measured in work/r2-evidence/05-fk-gaps.log, and reproduced as a real
  // failure by src/test/integration/r2-purge-cli.spec.ts item 13, which adds a gymId
  // table whose name sorts after its RESTRICT parent: PostgreSQL refused the purge with
  // 23503 and the transaction rolled back.
  //
  // Rule: a table must be deleted before every table it references, whatever the rule -
  // mandatory for RESTRICT and NO ACTION, harmless and safer for CASCADE. SET NULL
  // children are not in this set at all (depth -1) because the database clears the
  // reference itself and deleting their rows would destroy unrelated data.
  const byTable = new Map<string, PlanStep>(steps.map((step) => [step.table, step]));
  const childrenOf = new Map<string, Set<string>>();
  for (const edge of graph) {
    if (edge.child === edge.parent) continue;
    if (!byTable.has(edge.child) || !byTable.has(edge.parent)) continue;
    const set = childrenOf.get(edge.parent) ?? new Set<string>();
    set.add(edge.child);
    childrenOf.set(edge.parent, set);
  }

  const ordered: PlanStep[] = [];
  const state = new Map<string, 'visiting' | 'done'>();
  const cycles: string[] = [];
  const visit = (table: string, stack: string[]): void => {
    const seen = state.get(table);
    if (seen === 'done') return;
    if (seen === 'visiting') {
      cycles.push([...stack.slice(stack.indexOf(table)), table].join(' -> '));
      return;
    }
    state.set(table, 'visiting');
    const children = [...(childrenOf.get(table) ?? [])].sort((a, b) => a.localeCompare(b));
    for (const child of children) visit(child, [...stack, table]);
    state.set(table, 'done');
    const step = byTable.get(table);
    if (step) ordered.push(step);
  };
  // Seed in the old deterministic order so the printed plan stays reviewable and so a
  // table with no constraints at all still lands somewhere sensible.
  const seeds = [...steps].sort((a, b) => b.depth - a.depth || a.table.localeCompare(b.table));
  for (const seed of seeds) visit(seed.table, []);
  for (const step of seeds) if (!ordered.includes(step)) ordered.push(step);
  if (cycles.length) {
    console.error(`WARNING: circular foreign keys among affected tables: ${cycles.join(' | ')}`);
    console.error('  The order below is best-effort; if the purge fails, PostgreSQL will roll it back.');
  }
  void gymId;
  return ordered;
}

async function countOf(prisma: PrismaClient, step: PlanStep, gymId: string): Promise<number> {
  const rows = await prisma.$queryRawUnsafe<Array<{ n: bigint | number }>>(
    `SELECT COUNT(*)::bigint AS n FROM ${q(step.table)} WHERE ${step.predicate}`,
    gymId,
  );
  return Number(rows[0]?.n ?? 0);
}

async function main(): Promise<number> {
  const argv = process.argv.slice(2);
  let args: Args;
  try {
    args = parseArgs(argv);
  } catch (error) {
    console.error(`ERROR: ${(error as Error).message}`);
    console.error(usage());
    return 2;
  }
  if (args.help) { console.log(usage()); return 0; }

  // ---- gate 1: the operator-only credential ---------------------------------
  // Read here, inside main(), never at module scope. The value is never printed.
  const adminUrl = process.env.DATABASE_ADMIN_URL;
  if (!adminUrl) {
    console.error(
      [
        'ERROR: DATABASE_ADMIN_URL is not set.',
        '',
        '  This CLI needs an owner-level connection because 79 tables carrying gymId sit',
        '  under FORCE ROW LEVEL SECURITY. It must NOT be given the api credential: the',
        '  api holds the runtime role only, and as that role this tool would see zero',
        '  rows and report success while deleting nothing.',
        '',
        '  export DATABASE_ADMIN_URL=postgresql://<owner>:<password>@<host>:5432/<db>',
        '  (documented in .env.example as operator-only, never for the api process)',
      ].join('\n'),
    );
    return 2;
  }
  if (!args.slug) { console.error('ERROR: --slug is required\n\n' + usage()); return 2; }

  const prisma = new PrismaClient({ datasources: { db: { url: adminUrl } }, log: ['error'] });
  try {
    await prisma.$connect();

    // ---- gate 2: verify the connected role BEFORE any write --------------------
    const roleRows = await prisma.$queryRawUnsafe<Array<{ current_user: string; rolsuper: boolean; rolbypassrls: boolean; gym_owner: string }>>(
      `SELECT current_user,
              (SELECT rolsuper     FROM pg_roles WHERE rolname = current_user) AS rolsuper,
              (SELECT rolbypassrls FROM pg_roles WHERE rolname = current_user) AS rolbypassrls,
              (SELECT pg_get_userbyid(c.relowner)
                 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public' AND c.relname = 'Gym') AS gym_owner`,
    );
    const role = roleRows[0];
    const isOwner = role.current_user === role.gym_owner;
    console.log(
      `  connected role : ${role.current_user}  (owner of public."Gym" = ${role.gym_owner})` +
      `  superuser=${role.rolsuper}  bypassrls=${role.rolbypassrls}`,
    );
    if (!(isOwner || role.rolsuper || role.rolbypassrls)) {
      console.error(
        [
          `ERROR: refusing to run as "${role.current_user}".`,
          '',
          `  That role is not the owner of public."Gym" ("${role.gym_owner}"), is not a`,
          '  superuser and does not have BYPASSRLS. Every tenant table carries FORCE ROW',
          '  LEVEL SECURITY, so this connection would see ZERO rows: the purge would',
          '  report success and delete nothing.',
          '',
          '  This is the runtime role (flexora_app) or something like it. Point',
          '  DATABASE_ADMIN_URL at the migration-owner credential instead.',
          '  No database write was attempted.',
        ].join('\n'),
      );
      return 3;
    }

    // ---- gate 3: the gym must exist AND be visible to this connection ----------
    const gyms = await prisma.$queryRawUnsafe<Array<{ id: string; slug: string; status: string; deleted_at: Date | null }>>(
      `SELECT g.id, g.slug, g.status::text AS status, g."deletedAt" AS deleted_at
         FROM public."Gym" g WHERE g.slug = $1`,
      args.slug,
    );
    if (gyms.length === 0) {
      console.error(
        [
          `ERROR: no gym with slug "${args.slug}" is visible to this connection.`,
          '',
          '  Either it does not exist, or row-level security is hiding it from this',
          '  role - which is exactly the "silently deletes nothing" case this CLI',
          '  refuses. No database write was attempted.',
        ].join('\n'),
      );
      return 4;
    }
    const gym = gyms[0];

    // ---- gate 4: soft-deleted and out of the 30-day restore window -------------
    const deletedAt = gym.deleted_at ? new Date(gym.deleted_at) : null;
    if (gym.status !== 'DELETED' || !deletedAt) {
      console.error(
        `ERROR: gym "${gym.slug}" has status=${gym.status} and deletedAt=${deletedAt ? deletedAt.toISOString() : 'null'}.` +
        `\n  A gym must be soft-deleted first (DELETE /api/platform/gyms/:id sets status=DELETED).`,
      );
      return 5;
    }
    const ageDays = (Date.now() - deletedAt.getTime()) / 86400000;
    if (ageDays < RETENTION_DAYS) {
      const remaining = Math.ceil(RETENTION_DAYS - ageDays);
      console.error(
        [
          `ERROR: gym "${gym.slug}" was soft-deleted ${ageDays.toFixed(1)} day(s) ago.`,
          `  The restore window is ${RETENTION_DAYS} days: ${remaining} day(s) remain.`,
          '  There is no --force. Restore it, or come back when the window has closed.',
        ].join('\n'),
      );
      return 6;
    }

    // ---- gate 5: the slug typed again, and a real reason -----------------------
    if (args.confirm !== args.slug) {
      console.error(`ERROR: --confirm must equal --slug exactly. Got --confirm=${args.confirm ?? '(missing)'} for --slug=${args.slug}.`);
      return 7;
    }
    const reason = (args.reason ?? '').trim();
    if (reason.length < MIN_REASON_LENGTH) {
      console.error(`ERROR: --reason must be at least ${MIN_REASON_LENGTH} characters; it is recorded in the immutable platform audit log.`);
      return 7;
    }

    // ---- the plan, derived from the catalog -----------------------------------
    const steps = await buildPlan(prisma, gym.id);
    const counts: Array<{ table: string; n: number }> = [];
    let total = 0;
    for (const step of steps) {
      const n = await countOf(prisma, step, gym.id);
      counts.push({ table: step.table, n });
      total += n;
    }
    console.log('');
    console.log(`  gym            : ${gym.slug} (id ${gym.id})  status=${gym.status}  deletedAt=${deletedAt.toISOString()}  age=${ageDays.toFixed(1)}d`);
    console.log(`  reason         : ${reason}`);
    console.log(`  delete order   : ${steps.length} tables, deepest dependency first (derived from pg_constraint)`);
    console.log('  rows to delete : (COUNTS ONLY - no tenant value is printed)');
    for (const row of counts.filter((c) => c.n > 0)) console.log(`      ${row.table.padEnd(28)} ${row.n}`);
    const zero = counts.filter((c) => c.n === 0).length;
    console.log(`      ${`(${zero} more tables with 0 rows)`.padEnd(28)}`);
    console.log(`      ${'Gym'.padEnd(28)} 1`);
    console.log(`  TOTAL          : ${total + 1} row(s) including the Gym row`);

    if (!args.execute) {
      console.log('');
      console.log('  DRY RUN - nothing was deleted. Re-run with --execute to act.');
      console.log('R2_PURGE_DRY_RUN_OK');
      return 0;
    }

    // ---- gate 7: delete, then RE-COUNT inside the same transaction ------------
    const deleted = await prisma.$transaction(async (tx) => {
      const perTable: Array<{ table: string; n: number }> = [];
      for (const step of steps) {
        const result = await tx.$executeRawUnsafe(`DELETE FROM ${q(step.table)} WHERE ${step.predicate}`, gym.id);
        perTable.push({ table: step.table, n: result });
      }
      await tx.$executeRawUnsafe(`DELETE FROM public."Gym" WHERE id = $1`, gym.id);

      // The re-count is the point of the whole exercise: if a single row survived -
      // a RESTRICT FK we did not know about, a policy hiding rows, a new table added
      // next month - the transaction throws and NOTHING is committed.
      const leftovers: string[] = [];
      for (const step of steps) {
        const rows = await tx.$queryRawUnsafe<Array<{ n: bigint | number }>>(
          `SELECT COUNT(*)::bigint AS n FROM ${q(step.table)} WHERE ${step.predicate}`,
          gym.id,
        );
        const n = Number(rows[0]?.n ?? 0);
        if (n > 0) leftovers.push(`${step.table}=${n}`);
      }
      const gymRows = await tx.$queryRawUnsafe<Array<{ n: bigint | number }>>(
        `SELECT COUNT(*)::bigint AS n FROM public."Gym" WHERE id = $1`,
        gym.id,
      );
      if (Number(gymRows[0]?.n ?? 0) > 0) leftovers.push('Gym=1');
      if (leftovers.length) {
        throw new Error(
          `post-delete re-count found surviving rows: ${leftovers.join(', ')}. ` +
          'Rolling the whole transaction back; nothing was deleted.',
        );
      }

      // The immutable audit row. Counts and identifiers only - no PII, no reason-free
      // action. adminId carries a CLI marker: this actor is not a PlatformAdmin.
      await tx.$executeRawUnsafe(
        `INSERT INTO public."PlatformAuditLog" (id, "adminId", "adminName", action, target, details, ip, "createdAt")
         VALUES (gen_random_uuid(), $1, $2, $3, $4, $5::jsonb, $6, now())`,
        'cli:purge-gym',
        'purge-gym CLI (DATABASE_ADMIN_URL)',
        'gym:purge',
        gym.id,
        JSON.stringify({ slug: gym.slug, reason, deletedAt: deletedAt.toISOString(), ageDays: Number(ageDays.toFixed(2)), tables: perTable.length, rows: perTable.reduce((a, b) => a + b.n, 0) + 1 }),
        'cli',
      );
      return perTable;
    }, { timeout: 300_000 });

    console.log('');
    console.log(`  EXECUTED - ${deleted.length} tables cleared, re-count verified zero rows remaining, transaction committed.`);
    console.log(`  audit row written: action=gym:purge target=${gym.id} (counts and reason only, no tenant data)`);
    console.log('R2_PURGE_EXECUTED_OK');
    return 0;
  } catch (error) {
    const message = (error as Error).message.split('\n')[0];
    console.error(`ERROR: ${message}`);
    if (/surviving rows/i.test(message)) {
      console.error('  The post-delete re-count found rows that survived, so the transaction was rolled back.');
    }
    // Every write this CLI makes happens inside ONE transaction, so any failure at all -
    // a refused delete, a RESTRICT foreign key, a lost connection, a surviving row -
    // means the database committed nothing. Say that explicitly: an operator who reads
    // only a bare SQL error cannot tell whether a tenant is now half deleted.
    console.error('  The transaction was rolled back. Nothing was deleted.');
    return 1;
  } finally {
    await prisma.$disconnect();
  }
}

main().then(
  (code) => process.exit(code),
  (error) => { console.error(`FATAL: ${(error as Error).message}`); process.exit(9); },
);
