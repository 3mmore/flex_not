const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const gym = await prisma.gym.findUnique({ where: { slug: 'alpha' } });
  if (!gym) { console.log('alpha not found'); return; }
  const members = await prisma.member.findMany({ where: { gymId: gym.id }, take: 10, select: { code: true } });
  const products = await prisma.product.findMany({ where: { gymId: gym.id }, take: 3, select: { id: true, name: true } });
  console.log(JSON.stringify({
    members: members.map(m => m.code),
    products: products.map(p => ({ id: p.id, name: p.name }))
  }, null, 2));
}
main().catch(console.error).finally(() => prisma.$disconnect());
