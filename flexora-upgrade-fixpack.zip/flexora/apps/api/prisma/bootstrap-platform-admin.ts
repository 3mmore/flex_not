#!/usr/bin/env ts-node
/**
 * PHASE O1.7 — create the FIRST platform admin of a deployment.
 *
 * WHY THIS EXISTS
 * ---------------
 * `prisma/seed.ts` refuses to run outside development/test, and that is correct:
 * it writes a demo gym and accounts whose password the operator chose once, in
 * public. A production deployment still needs its first platform admin, and the
 * only route that creates one (POST /api/platform/admins) requires an
 * authenticated platform admin — a chicken-and-egg problem. This script is the
 * guarded way out. It is deliberately NOT a general user-creation tool.
 *
 * GUARDS
 *   1. refuses unless an explicit --confirm (or --yes) flag is present
 *   2. refuses if ANY platform admin already exists, and says who they are;
 *      rotating an existing admin is a different procedure (see
 *      docs/SECRET_ROTATION.md and POST /api/platform/auth/change-password)
 *   3. refuses to accept a password as a command-line argument. argv is world
 *      readable in /proc and lands in shell history; so does a hash. The password
 *      comes from --password-file, --password-env, or stdin (prompted without
 *      echo on a TTY, read from the pipe otherwise, e.g. `docker compose exec -T`)
 *   4. validates the password with the SAME function the API's boot validator
 *      uses (validateCredentialVar), so a password this script accepts cannot be
 *      one the API would reject
 *   5. hashes with PASSWORD_HASH_OPTIONS from src/config/password-hash.ts — the
 *      API's own parameters — then verifies the hash before committing
 *   6. prints no password and no hash, ever
 *
 * The PlatformAdmin table has no row-level security, so this runs with the api
 * service's own restricted DATABASE_URL: unlike migrations, it needs no owner
 * credential.
 *
 * usage:
 *   npm run bootstrap:admin -- --confirm [--email admin@example.com] [--name "Ops"]
 *                                [--password-env NAME | --password-file PATH] [--dry-run]
 * exit: 0 created (or --dry-run clean) · 1 refused
 */
import '../src/config/load-env';
import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';
import { readFileSync } from 'fs';
import * as readline from 'readline';
import { PASSWORD_HASH_OPTIONS, hashPassword, passwordHashParamsLabel } from '../src/config/password-hash';
import { validateCredentialVar } from '../src/config/env-validation';
import { envMode } from '../src/config/env-mode';
import type { PrismaService } from '../src/config/prisma.service';
import type { EncryptionService } from '../src/common/security/encryption.service';
import { PlatformTotpService } from '../src/modules/platform-auth/platform-totp.service';
import { PlatformAuditService } from '../src/modules/platform/platform-audit.service';
import { PlatformAlertService } from '../src/modules/platform/platform-alert.service';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function fail(message: string, hint?: string): never {
  console.error(`FATAL: ${message}`);
  if (hint) console.error(`       ${hint}`);
  process.exit(1);
}

interface Args {
  confirm: boolean;
  dryRun: boolean;
  email: string | null;
  name: string | null;
  passwordEnv: string | null;
  passwordFile: string | null;
  /** PHASE R1 / D4: clear an administrator's TOTP enrolment instead of creating one. */
  resetTotp: boolean;
  /** Required with --reset-totp; written to the immutable platform audit log. */
  reason: string | null;
}

function parseArgs(argv: string[]): Args {
  const args: Args = {
    confirm: false,
    dryRun: false,
    resetTotp: false,
    reason: null,
    email: null,
    name: null,
    passwordEnv: null,
    passwordFile: null,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => {
      const v = argv[++i];
      if (v === undefined) fail(`${a} needs a value`);
      return v;
    };
    if (a === '--confirm' || a === '--yes') args.confirm = true;
    else if (a === '--reset-totp') args.resetTotp = true;
    else if (a === '--reason') args.reason = next();
    else if (a.startsWith('--reason=')) args.reason = a.slice('--reason='.length);
    else if (a === '--dry-run') args.dryRun = true;
    else if (a === '--email') args.email = next();
    else if (a === '--name') args.name = next();
    else if (a === '--password-env') args.passwordEnv = next();
    else if (a === '--password-file') args.passwordFile = next();
    else if (a.startsWith('--email=')) args.email = a.slice('--email='.length);
    else if (a.startsWith('--name=')) args.name = a.slice('--name='.length);
    else if (a.startsWith('--password-env=')) args.passwordEnv = a.slice('--password-env='.length);
    else if (a.startsWith('--password-file=')) args.passwordFile = a.slice('--password-file='.length);
    // Guard 3: an inline password is refused outright, whatever its value.
    else if (a === '--password' || a.startsWith('--password=') || a === '-p') {
      fail(
        'this command will not take a password as an argument',
        'argv is readable in /proc and is copied into shell history. Use --password-env NAME,\n' +
          '       --password-file PATH, or let the command prompt on stdin (no echo).',
      );
    } else if (a === '--help' || a === '-h') {
      console.log(readFileSync(__filename, 'utf8').split('*/')[0].replace(/^\/\*\*/, '').trim());
      process.exit(0);
    } else {
      fail(`unknown argument ${a}`, 'try --help');
    }
  }
  return args;
}

/** Prompt on a TTY without echoing, or read one line from a pipe. */
function readStdinPassword(prompt: string): Promise<string> {
  return new Promise((resolve, reject) => {
    if (process.stdin.isTTY) {
      process.stderr.write(prompt);
      const rl = readline.createInterface({ input: process.stdin, terminal: true });
      const stdin = process.stdin as unknown as { setRawMode?: (m: boolean) => void };
      if (stdin.setRawMode) stdin.setRawMode(true);
      let value = '';
      const onData = (ch: string) => {
        for (const c of ch) {
          if (c === '\r' || c === '\n' || c === '\u0004') {
            if (stdin.setRawMode) stdin.setRawMode(false);
            rl.close();
            process.stderr.write('\n');
            resolve(value);
            return;
          }
          if (c === '\u0003') {
            if (stdin.setRawMode) stdin.setRawMode(false);
            rl.close();
            process.stderr.write('\n');
            reject(new Error('interrupted'));
            return;
          }
          if (c === '\u007f' || c === '\b') value = value.slice(0, -1);
          else value += c;
        }
      };
      rl.on('line', () => undefined);
      process.stdin.on('data', onData);
      return;
    }
    // Not a TTY (docker compose exec -T, a pipe, CI): read exactly one line.
    const rl = readline.createInterface({ input: process.stdin, terminal: false });
    let value: string | null = null;
    rl.on('line', (line) => {
      if (value === null) value = line;
      rl.close();
    });
    rl.on('close', () => {
      if (value === null) reject(new Error('no password arrived on stdin'));
      else resolve(value);
    });
  });
}

async function obtainPassword(args: Args): Promise<{ password: string; source: string }> {
  if (args.passwordFile) {
    const raw = readFileSync(args.passwordFile, 'utf8').replace(/\r?\n$/, '');
    if (!raw) fail(`--password-file ${args.passwordFile} is empty`);
    return { password: raw, source: `--password-file (path only, contents never printed)` };
  }
  if (args.passwordEnv) {
    const v = process.env[args.passwordEnv];
    if (!v) fail(`--password-env ${args.passwordEnv}: that variable is not set`, 'export it first; do not put the value in this command line');
    return { password: v, source: `--password-env ${args.passwordEnv}` };
  }
  if (process.env.SUPER_ADMIN_PASSWORD) {
    return { password: process.env.SUPER_ADMIN_PASSWORD, source: 'the SUPER_ADMIN_PASSWORD environment variable' };
  }
  const password = await readStdinPassword('Password for the new platform admin (input is not echoed): ');
  return { password, source: process.stdin.isTTY ? 'an interactive prompt (no echo)' : 'stdin (piped)' };
}

/**
 * PHASE R1 / owner decision D4 - CLI-only TOTP recovery.
 *
 * Deliberate properties, each one a requirement from the owner:
 *   - explicit confirmation, reusing the same --confirm gate as creation;
 *   - the target must exist, and the email must be exact: an address that matches
 *     zero or more than one administrator is refused rather than guessed;
 *   - a --reason is mandatory and lands in the immutable platform audit log with
 *     the actor and a timestamp;
 *   - nothing secret is printed. No TOTP secret, no recovery code, no hash;
 *   - live sessions are revoked, so a device that was already signed in loses
 *     access at the same moment the second factor is cleared;
 *   - the next login is forced back through enrolment before any other console
 *     action, because the enrolment gate reads the administrator row, not the
 *     session.
 *
 * The service is constructed with a stub EncryptionService: resetEnrolment only
 * clears columns and writes an audit row, and if that ever changes the stub throws
 * loudly instead of silently doing nothing.
 */
/**
 * PHASE R3. The audit writer is real here - the --reset-totp path genuinely writes an
 * audit row, and it must go through the same single writer as every other row so that it
 * gets a chain position and a first-class reason. The alert outbox is not: it needs the
 * notifications and cron-leadership services, which a standalone CLI has no container to
 * build them from. Following the convention this file already sets for encryption, the stub
 * throws loudly if it is ever reached. It can only be reached if the audit write itself
 * failed, and PlatformAuditService.recordBestEffort catches a failing hook and logs it, so
 * the reset still completes and the operator sees why in the terminal they are looking at.
 */
const ALERTS_NOT_AVAILABLE_IN_CLI = {
  raise(): never {
    throw new Error(
      'the alert outbox is not available in the --reset-totp path; ' +
        'investigate the audit write failure reported above',
    );
  },
} as unknown as PlatformAlertService;

const ENCRYPTION_NOT_USED_BY_RESET: EncryptionService = {
  encrypt() {
    throw new Error('encryption is not available in the --reset-totp path');
  },
  decrypt() {
    throw new Error('encryption is not available in the --reset-totp path');
  },
} as unknown as EncryptionService;

async function resetTotpFlow(args: Args): Promise<void> {
  if (!args.confirm) {
    fail(
      'refusing to clear a second factor without an explicit --confirm',
      'this removes TOTP from a real console account.\n' +
        '       Re-run with --confirm and a --reason, which is written to the audit log.',
    );
  }
  const supplied = (args.email || '').trim();
  if (!supplied) {
    fail(
      '--reset-totp needs an explicit --email',
      'this command never falls back to PLATFORM_ADMIN_EMAIL or a default address:\n' +
        '       clearing the wrong account\u2019s second factor is not a recoverable mistake.',
    );
  }
  if (supplied.includes(',') || supplied.includes(';') || /\s/.test(supplied)) {
    fail(`"${supplied}" is ambiguous input for --email`, 'one exact email address, no separators, no whitespace.');
  }
  const email = supplied.toLowerCase();
  if (!EMAIL_RE.test(email)) fail(`"${supplied}" is not a valid email address`);
  const reason = (args.reason || '').trim();
  if (!reason) {
    fail('--reset-totp needs a --reason', 'it is recorded in the immutable platform audit log next to the actor.');
  }

  const prisma = new PrismaClient();
  try {
    const matches = await prisma.platformAdmin.findMany({
      where: { email: { equals: email, mode: 'insensitive' } },
      select: { id: true, email: true, name: true, totpEnabled: true, status: true },
    });
    if (matches.length === 0) fail(`no console administrator has the email ${email}`);
    if (matches.length > 1) fail(`${matches.length} administrators match ${email} - refusing to guess which one`);
    const admin = matches[0];

    if (!admin.totpEnabled) {
      console.log(`  ${admin.email} has no TOTP enrolment to clear (totpEnabled=false)`);
      return;
    }
    if (args.dryRun) {
      console.log(`  --dry-run: would clear TOTP for ${admin.email} and revoke that administrator's live sessions`);
      return;
    }

    const actor = `bootstrap:admin(${process.env.USER || process.env.USERNAME || 'unknown-user'})`;
    const prismaAsService = prisma as unknown as PrismaService;
    const totp = new PlatformTotpService(
      prismaAsService,
      ENCRYPTION_NOT_USED_BY_RESET,
      new PlatformAuditService(prismaAsService),
      ALERTS_NOT_AVAILABLE_IN_CLI,
    );
    const result = await totp.resetEnrolment({ adminId: admin.id, actor, reason });

    console.log(`  TOTP enrolment cleared for ${admin.email}`);
    console.log(`  recovery codes invalidated: ${result.codesInvalidated}`);
    console.log(`  live sessions revoked:      ${result.sessionsRevoked}`);
    console.log('  audit row written: admin:totp-reset-by-cli (actor, target, reason, timestamp, chain seq)');
    console.log('  nothing secret was printed: no TOTP secret, no recovery code, no hash');
    console.log('  the next login for this administrator must complete enrolment first');
  } finally {
    await prisma.$disconnect();
  }
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  const mode = envMode();
  console.log(`bootstrap-platform-admin · mode=${mode} · hash=${passwordHashParamsLabel()}`);

  // PHASE R1 / owner decision D4 - the ONLY recovery path for an administrator who
  // has lost their authenticator and spent their recovery codes. There is no HTTP
  // endpoint for it and no self-service flow: this process is the recovery.
  //
  //   npm run bootstrap:admin -- --reset-totp --confirm --email owner@example.com \
  //       --reason "lost phone, confirmed by voice call"
  //
  // It prints no secret and no recovery code, verifies that exactly one
  // administrator has that email, refuses ambiguous or malformed input, and writes
  // an immutable audit row naming the actor, the target and the reason. The next
  // login for that administrator is forced back through enrolment before any other
  // console action.
  if (args.resetTotp) {
    await resetTotpFlow(args);
    return;
  }

  // Guard 1
  if (!args.confirm) {
    fail(
      'refusing to run without an explicit --confirm',
      'this creates a real account that can administer every gym on the platform.\n' +
        '       Re-run with --confirm (add --dry-run first to check the password policy).',
    );
  }

  const email = (args.email || process.env.PLATFORM_ADMIN_EMAIL || 'admin@flexora.com').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) fail(`"${email}" is not a valid email address`);
  const name = (args.name || process.env.PLATFORM_ADMIN_NAME || 'Platform Admin').trim();

  const prisma = new PrismaClient();
  try {
    // Guard 2 — never a second admin, and never a silent overwrite
    const existing = await prisma.platformAdmin.findMany({ select: { email: true, createdAt: true }, orderBy: { createdAt: 'asc' } });
    if (existing.length > 0) {
      console.error('FATAL: a platform admin already exists — this command creates only the FIRST one.');
      for (const a of existing) console.error(`       ${a.email} (created ${a.createdAt.toISOString()})`);
      console.error('       To change a password use POST /api/platform/auth/change-password while');
      console.error('       authenticated, or follow docs/SECRET_ROTATION.md. To add another admin use');
      console.error('       POST /api/platform/admins as an authenticated platform admin.');
      process.exit(1);
    }

    const { password, source } = await obtainPassword(args);
    console.log(`  password source: ${source}`);
    console.log(`  email:           ${email}`);

    // Guard 4 — the API's own credential policy, not a copy of it
    const problems = validateCredentialVar('SUPER_ADMIN_PASSWORD', password, false);
    if (problems.length > 0) {
      console.error('FATAL: that password does not satisfy the API credential policy:');
      for (const p of problems) console.error(`       ${p}`);
      console.error('       Generate one with:  openssl rand -base64 18 | tr \'+/\' \'-_\'');
      process.exit(1);
    }
    console.log(`  policy:          satisfied (${password.length} characters, classes checked by validateCredentialVar)`);

    if (args.dryRun) {
      console.log('  --dry-run: nothing written.');
      return;
    }

    // Guard 5 — the API's parameters, then prove the hash verifies
    const passwordHash = await hashPassword(password);
    if (!(await argon2.verify(passwordHash, password, PASSWORD_HASH_OPTIONS))) {
      fail('the hash this script just produced does not verify — refusing to write it');
    }
    if (passwordHash.includes(password)) fail('the hash contains the password in clear — refusing to write it');

    const created = await prisma.platformAdmin.create({
      data: { email, passwordHash, name, role: 'PLATFORM_ADMIN' },
      select: { id: true, email: true, role: true, createdAt: true },
    });
    console.log('  PASS created the first platform admin:');
    console.log(`       id=${created.id} email=${created.email} role=${created.role} created=${created.createdAt.toISOString()}`);
    console.log('       the password was not printed and is not recoverable from this output.');
    console.log('  next: POST /api/platform/auth/login with that email and password.');
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((e) => {
  // Never let a driver error print the connection string it was given.
  const msg = e instanceof Error ? e.message : String(e);
  console.error(`FATAL: ${msg.replace(/:[^:@/\s]+@/, ':***@')}`);
  process.exit(1);
});
