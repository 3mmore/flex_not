const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main() {
  const alpha = await prisma.member.count({ where: { gym: { slug: 'alpha' } } });
  const beta = await prisma.member.count({ where: { gym: { slug: 'beta' } } });
  const gamma = await prisma.member.count({ where: { gym: { slug: 'gamma' } } });
  console.log(JSON.stringify({ alpha, beta, gamma, total: alpha + beta + gamma }));
}
main().catch(console.error).finally(() => prisma.$disconnect());
