/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE P1 / PHASE Q1 — database owner compatibility preflight.
 *
 * Runs BEFORE `prisma migrate deploy` (see the `migrate` npm script and the
 * compose `migrate` service) and refuses, with a message that names the missing
 * role attribute, when the role that is about to own the schema cannot support
 * the migrations that are STILL PENDING. Without it the chain dies part way
 * through with a raw Postgres error and leaves a half-created schema behind.
 *
 * ---------------------------------------------------------------------------
 * PHASE Q1 — WHY THIS IS "PENDING-AWARE"
 * ---------------------------------------------------------------------------
 * The first version of this preflight evaluated its two requirements against the
 * owner's attributes ALONE. That is correct for a first deploy and wrong for
 * every later one: on a managed database the owner is typically a non-superuser,
 * the first deploy is done by a privileged bootstrap role (or by the provider),
 * and from then on `flexora_app` exists — so requirement R1 can never be
 * satisfied again. The preflight therefore refused EVERY redeploy, and because
 * the `api` service depends on `migrate` completing, the API never started. A
 * guard that bricks routine redeploys is worse than no guard.
 *
 * The privileged operations only matter for the migrations that actually still
 * have to run. So this version:
 *
 *   1. reads `public._prisma_migrations` FIRST;
 *   2. computes the PENDING set exactly the way `prisma migrate deploy` does —
 *      every directory under `prisma/migrations` with no successfully applied
 *      row (a row that exists but has `finished_at IS NULL` and
 *      `rolled_back_at IS NULL` is a FAILED migration: Prisma will retry it, so
 *      it counts as pending here too);
 *   3. inspects the SQL of the pending migrations only, and derives which
 *      requirements they need from the statements themselves;
 *   4. evaluates R1/R2 only for the requirements that are actually needed.
 *      Nothing pending needs them  ->  PASS, whatever the owner's attributes.
 *
 * The requirement markers are read from the SQL rather than hardcoded to
 * migration names, so a future migration that creates or alters a role — or that
 * creates another SECURITY DEFINER function — is picked up automatically, and a
 * future migration that does neither cannot re-block a redeploy.
 *
 * FAIL CLOSED: if the migrations directory cannot be read, or `_prisma_migrations`
 * exists but cannot be queried, this preflight assumes EVERY migration is
 * pending. "I could not work out what still has to run" must never become "pass".
 *
 * ---------------------------------------------------------------------------
 * THE TWO REQUIREMENTS (both measured by scripts/check-db-compat.sh, not assumed)
 * ---------------------------------------------------------------------------
 *   R1 — CREATE/ALTER ROLE.
 *     Migration `202607050001_flexora_app_role_force_rls` creates the restricted
 *     runtime role (`CREATE ROLE flexora_app … NOSUPERUSER NOBYPASSRLS …`) and,
 *     when the role already exists, re-asserts those attributes with
 *     `ALTER ROLE flexora_app …`. Both statements require SUPERUSER or
 *     CREATEROLE; BYPASSRLS alone is not enough. A NOSUPERUSER owner without
 *     CREATEROLE fails there with `42501 permission denied`.
 *     Measured on PostgreSQL 17: a NOSUPERUSER CREATEROLE role MAY run
 *     `CREATE ROLE … NOSUPERUSER …` but may NOT run `ALTER ROLE … NOSUPERUSER …`,
 *     even holding ADMIN OPTION on the target role — PostgreSQL refuses any
 *     non-superuser ALTER ROLE that mentions the SUPERUSER attribute at all,
 *     even to set it false when it is already false. Hence R1 below is
 *     `superuser OR (runtime role absent AND createrole)`.
 *
 *   R2 — the SECURITY DEFINER pre-auth functions must be able to read rows.
 *     The chain also creates `preauth_find_user_by_id`,
 *     `preauth_find_user_by_refresh_token_hash`, `preauth_find_users_by_email`,
 *     `preauth_update_user_password`, `public_invitation_gym_id` and
 *     `public_messaging_gym_id`, all SECURITY DEFINER and all owned by whoever
 *     applies the migration that creates them. Every tenant table is
 *     `FORCE ROW LEVEL SECURITY`, which applies to the table owner as well, so a
 *     NOBYPASSRLS owner sees nothing through the functions it owns — and login,
 *     which is pre-authentication and therefore has no tenant context to satisfy
 *     a policy, can never return a user. R2 only matters for a migration that
 *     CREATES such a function: one that already exists keeps the owner it was
 *     created by, so a later, unprivileged redeploy cannot break it.
 *
 * Supported owner profiles — stated as CONDITIONS, because whether a named
 * profile works depends on PostgreSQL version, on whether `flexora_app` already
 * exists, AND (since PHASE Q1) on what is still pending.
 * scripts/check-db-compat.sh measures the matrix instead of asserting it;
 * docs/DEPLOYMENT.md → "Database owner profiles" carries the result.
 *
 * This file never prints a connection string, a password or any other secret
 * value — only role NAMES, boolean attributes, migration names and counts.
 */
import '../src/config/load-env';
import { PrismaClient } from '@prisma/client';
import { existsSync, readdirSync, readFileSync, statSync } from 'fs';
import { join, resolve } from 'path';

export type RoleAttrs = {
  role_name: string;
  rolsuper: boolean;
  rolcreaterole: boolean;
  rolbypassrls: boolean;
  runtime_role_exists: boolean;
  has_admin_option: boolean;
};

/** One migration directory and what applying it would demand of the owner. */
export type MigrationNeed = {
  name: string;
  /** Contains CREATE ROLE / ALTER ROLE — needs R1. */
  needsRolePrivilege: boolean;
  /** Contains SECURITY DEFINER — needs R2 (it would own the function). */
  needsDefinerOwner: boolean;
};

/** One row of `public._prisma_migrations`, as far as this preflight cares. */
export type AppliedRow = {
  migration_name: string;
  finished: boolean;
  rolled_back: boolean;
};

/** The migration that needs R1, quoted in the failure message. */
export const ROLE_MIGRATION = '202607050001_flexora_app_role_force_rls';

/** Name of the table Prisma records applied migrations in. */
export const MIGRATIONS_TABLE = '_prisma_migrations';

const ROLE_STMT = /\b(?:CREATE|ALTER)\s+ROLE\b/i;
const DEFINER_STMT = /\bSECURITY\s+DEFINER\b/i;

/**
 * Remove `--` line comments, block comments and quoted text, so that a migration
 * which merely MENTIONS a privileged statement in prose is not mistaken for one
 * that runs it. This matters in both directions:
 *
 *   - `202607050001_flexora_app_role_force_rls` documents the operator's
 *     password-rotation step as `--  ALTER ROLE flexora_app WITH PASSWORD …`.
 *     A comment-only mention in some other migration would otherwise make R1
 *     "required" and refuse a redeploy that needs no privilege at all — i.e.
 *     reintroduce the exact bug PHASE Q1 removes.
 *   - The real statements are inside `DO $$ … $$` plpgsql bodies, which are CODE,
 *     not string literals, so dollar-quoted regions are deliberately scanned
 *     through rather than skipped. Comments and quotes inside them are handled by
 *     the same rules PostgreSQL applies.
 *
 * Known limitation (accepted, and in the fail-closed direction): an `E'…\'…'`
 * escape string is not modelled, so a backslash-escaped quote could end a string
 * early. Migrations in this chain contain none.
 */
export function stripSqlComments(sql: string): string {
  const src = String(sql || '');
  const out: string[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '-' && src[i + 1] === '-') {
      while (i < src.length && src[i] !== '\n') i += 1;
      continue;
    }
    if (c === '/' && src[i + 1] === '*') {
      i += 2;
      while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i += 1;
      i = Math.min(src.length, i + 2);
      out.push(' ');
      continue;
    }
    if (c === "'" || c === '"') {
      // Quoted text is data, not statements: replace it with an empty literal so
      // no keyword inside it can be mistaken for DDL.
      const quote = c;
      i += 1;
      while (i < src.length) {
        if (src[i] === quote) {
          if (src[i + 1] === quote) {
            i += 2; // SQL doubled-quote escape — still inside the literal
            continue;
          }
          i += 1;
          break;
        }
        i += 1;
      }
      out.push(quote, quote);
      continue;
    }
    out.push(c);
    i += 1;
  }
  return out.join('');
}

/**
 * Which owner privileges the SQL of ONE migration demands. Pure, exported and
 * unit-tested: the whole point of PHASE Q1 is that this decision is made per
 * pending migration instead of once for the whole chain.
 */
export function detectRequirements(sql: string): {
  needsRolePrivilege: boolean;
  needsDefinerOwner: boolean;
} {
  const text = stripSqlComments(sql);
  return {
    needsRolePrivilege: ROLE_STMT.test(text),
    needsDefinerOwner: DEFINER_STMT.test(text),
  };
}

/** R1: can this owner create — or re-assert the attributes of — `flexora_app`? */
export function canManageRuntimeRole(attrs: RoleAttrs): boolean {
  return attrs.rolsuper || (!attrs.runtime_role_exists && attrs.rolcreaterole);
}

/** R2: would SECURITY DEFINER functions owned by this role be able to read rows? */
export function canOwnDefinerFunctions(attrs: RoleAttrs): boolean {
  return attrs.rolsuper || attrs.rolbypassrls;
}

export type PreflightDecision = {
  pass: boolean;
  r1Required: boolean;
  r2Required: boolean;
  r1Satisfied: boolean;
  r2Satisfied: boolean;
  /** Pending migrations that made each requirement necessary. */
  r1RequiredBy: string[];
  r2RequiredBy: string[];
  missing: string[];
};

/**
 * The decision, isolated from I/O so it can be tested directly (see
 * src/config/db-compat-preflight.spec.ts): given the owner's attributes and the
 * requirements of the PENDING migrations, does this deploy proceed?
 */
export function decide(attrs: RoleAttrs, pending: MigrationNeed[]): PreflightDecision {
  const r1RequiredBy = pending.filter((m) => m.needsRolePrivilege).map((m) => m.name);
  const r2RequiredBy = pending.filter((m) => m.needsDefinerOwner).map((m) => m.name);
  const r1Required = r1RequiredBy.length > 0;
  const r2Required = r2RequiredBy.length > 0;
  const r1Satisfied = !r1Required || canManageRuntimeRole(attrs);
  const r2Satisfied = !r2Required || canOwnDefinerFunctions(attrs);

  const missing: string[] = [];
  if (!r1Satisfied) {
    missing.push(
      `R1 CREATE/ALTER ROLE — pending migration ${r1RequiredBy.join(', ')} creates (or re-asserts)\n` +
        `     the restricted runtime role "flexora_app". That needs SUPERUSER, or\n` +
        `     CREATEROLE when the role does not exist yet. When it already exists,\n` +
        `     only a SUPERUSER may run the migration's "ALTER ROLE flexora_app\n` +
        `     NOSUPERUSER …": ADMIN OPTION is not enough, because PostgreSQL refuses\n` +
        `     any non-superuser ALTER ROLE that mentions the SUPERUSER attribute.\n` +
        `     flexora_app exists=${attrs.runtime_role_exists}, admin option=${attrs.has_admin_option}.`,
    );
  }
  if (!r2Satisfied) {
    missing.push(
      `R2 BYPASSRLS — pending migration ${r2RequiredBy.join(', ')} creates SECURITY DEFINER\n` +
        `     pre-auth functions (preauth_find_users_by_email and friends). They would be\n` +
        `     owned by this role, and every tenant table is FORCE ROW LEVEL SECURITY: a\n` +
        `     NOBYPASSRLS owner reads nothing through them, so no user could ever log in.`,
    );
  }

  return {
    pass: missing.length === 0,
    r1Required,
    r2Required,
    r1Satisfied,
    r2Satisfied,
    r1RequiredBy,
    r2RequiredBy,
    missing,
  };
}

function maskUrl(url: string | undefined): string {
  if (!url) return '(unset)';
  // Show the scheme, host and database, never the credentials.
  const m = url.match(/^([a-z]+):\/\/(?:[^@/]*@)?([^/?]+)(?:\/([^?]*))?/i);
  if (!m) return '(unparseable)';
  return `${m[1]}://***:***@${m[2]}/${m[3] || ''}`;
}

/** Every migration directory in the chain, in `ls` order (Prisma's own order). */
export function listMigrationDirs(migrationsDir: string): string[] {
  return readdirSync(migrationsDir, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => e.name)
    .sort();
}

/**
 * Split the chain into applied / failed / pending, mirroring what
 * `prisma migrate deploy` itself considers pending: a directory with no row, or
 * with a row that never finished and was never rolled back (Prisma retries that
 * one, and refuses to continue past it until it is resolved).
 *
 * `tableReadable=false` means `_prisma_migrations` exists but could not be
 * queried; the caller must then treat everything as pending (fail closed).
 */
export function classifyMigrations(
  dirs: string[],
  rows: AppliedRow[] | null,
): { applied: string[]; failed: string[]; pending: string[]; tableReadable: boolean } {
  if (rows === null) {
    return { applied: [], failed: [], pending: [...dirs], tableReadable: false };
  }
  const byName = new Map(rows.map((r) => [r.migration_name, r]));
  const applied: string[] = [];
  const failed: string[] = [];
  const pending: string[] = [];
  for (const name of dirs) {
    const row = byName.get(name);
    if (!row) pending.push(name);
    else if (row.finished && !row.rolled_back) applied.push(name);
    else if (!row.finished && !row.rolled_back) failed.push(name);
    else pending.push(name); // rolled back -> Prisma will apply it again
  }
  return { applied, failed, pending, tableReadable: true };
}

async function main(): Promise<number> {
  const url = process.env.DIRECT_URL || process.env.DATABASE_URL;
  if (!url) {
    console.error(
      'FATAL: db-compat preflight needs DIRECT_URL (or DATABASE_URL) to inspect the\n' +
        '       role that will own the schema. Neither is set.',
    );
    return 1;
  }

  const prisma = new PrismaClient({ datasources: { db: { url } } });
  let attrs: RoleAttrs;
  try {
    const rows = (await prisma.$queryRawUnsafe(
      `SELECT r.rolname AS role_name,
              r.rolsuper, r.rolcreaterole, r.rolbypassrls,
              EXISTS (SELECT 1 FROM pg_roles x WHERE x.rolname = 'flexora_app') AS runtime_role_exists,
              -- Only meaningful when flexora_app exists; pg_has_role with
              -- 'USAGE WITH ADMIN OPTION' is what a non-superuser would need for
              -- ALTER ROLE. Reported for diagnosis: it is NOT sufficient (see R1).
              CASE WHEN EXISTS (SELECT 1 FROM pg_roles x WHERE x.rolname = 'flexora_app')
                   THEN pg_has_role(r.rolname, 'flexora_app', 'USAGE WITH ADMIN OPTION')
                   ELSE false END AS has_admin_option
         FROM pg_roles r WHERE r.rolname = current_user`,
    )) as RoleAttrs[];
    if (!rows.length) {
      console.error('FATAL: db-compat preflight could not read its own role attributes.');
      return 1;
    }
    attrs = rows[0];
  } catch (e) {
    console.error(
      `FATAL: db-compat preflight could not connect to the migration database\n` +
        `       (${maskUrl(process.env.DIRECT_URL)}): ${(e as Error).message}\n` +
        `       No migration has been applied.`,
    );
    return 1;
  }

  // ---------------------------------------------------------------------
  // PHASE Q1 — what is actually still pending?
  // ---------------------------------------------------------------------
  const migrationsDir = resolve(__dirname, 'migrations');
  let dirs: string[];
  try {
    if (!existsSync(migrationsDir) || !statSync(migrationsDir).isDirectory()) {
      throw new Error(`${migrationsDir} is not a directory`);
    }
    dirs = listMigrationDirs(migrationsDir);
    if (!dirs.length) throw new Error(`${migrationsDir} contains no migration directories`);
  } catch (e) {
    console.error(
      `FATAL: db-compat preflight could not read the migration chain\n` +
        `       (${(e as Error).message}). It cannot tell which migrations are pending, so it\n` +
        `       refuses rather than guessing. No migration has been applied.`,
    );
    await prisma.$disconnect().catch(() => undefined);
    return 1;
  }

  let appliedRows: AppliedRow[] | null = null;
  let tablePresent = false;
  try {
    const present = (await prisma.$queryRawUnsafe(
      `SELECT to_regclass('public.${MIGRATIONS_TABLE}') IS NOT NULL AS present`,
    )) as { present: boolean }[];
    tablePresent = Boolean(present[0]?.present);
    if (tablePresent) {
      const rows = (await prisma.$queryRawUnsafe(
        `SELECT migration_name, finished_at IS NOT NULL AS finished,
                rolled_back_at IS NOT NULL AS rolled_back
           FROM public.${MIGRATIONS_TABLE}`,
      )) as AppliedRow[];
      appliedRows = rows;
    } else {
      // No bookkeeping table: this is a fresh database, everything is pending.
      appliedRows = [];
    }
  } catch (e) {
    // Fail closed: unreadable bookkeeping means "assume the whole chain runs".
    console.error(
      `db-compat preflight: WARNING — could not read public.${MIGRATIONS_TABLE} ` +
        `(${(e as Error).message.slice(0, 160)}); assuming ALL ${dirs.length} migrations are pending.`,
    );
    appliedRows = null;
  }

  const { applied, failed, pending, tableReadable } = classifyMigrations(dirs, appliedRows);

  // Read only the pending migrations: that is the set whose statements decide
  // whether R1/R2 are needed at all.
  const needs: MigrationNeed[] = [];
  for (const name of pending) {
    let sql = '';
    try {
      sql = readFileSync(join(migrationsDir, name, 'migration.sql'), 'utf8');
    } catch (e) {
      console.error(
        `FATAL: pending migration "${name}" has no readable migration.sql\n` +
          `       (${(e as Error).message}). Refusing rather than guessing what it needs.\n` +
          `       No migration has been applied.`,
      );
      await prisma.$disconnect().catch(() => undefined);
      return 1;
    }
    needs.push({ name, ...detectRequirements(sql) });
  }

  const decision = decide(attrs, needs);

  console.log(
    `db-compat preflight: migration owner "${attrs.role_name}" ` +
      `superuser=${attrs.rolsuper} createrole=${attrs.rolcreaterole} bypassrls=${attrs.rolbypassrls} ` +
      `runtime_role_exists=${attrs.runtime_role_exists} admin_option_on_runtime_role=${attrs.has_admin_option}`,
  );
  console.log(
    `db-compat preflight: ${MIGRATIONS_TABLE} ${tablePresent ? 'present' : 'absent'} ` +
      `(${tableReadable ? 'readable' : 'UNREADABLE — failing closed'}); chain=${dirs.length} ` +
      `applied=${applied.length} failed=${failed.length} pending=${pending.length}`,
  );
  if (failed.length) {
    console.log(
      `db-compat preflight: FAILED migration rows (Prisma will refuse to continue past these ` +
        `until they are resolved): ${failed.join(', ')}`,
    );
  }
  console.log(
    `db-compat preflight: requirements of the PENDING migrations — ` +
      `R1(CREATE/ALTER ROLE)=${decision.r1Required ? `needed by ${decision.r1RequiredBy.join(', ')}` : 'not needed'}; ` +
      `R2(SECURITY DEFINER)=${decision.r2Required ? `needed by ${decision.r2RequiredBy.join(', ')}` : 'not needed'}`,
  );

  await prisma.$disconnect().catch(() => undefined);

  if (decision.pass) {
    if (!decision.r1Required && !decision.r2Required) {
      // PHASE Q1: the redeploy case. Say explicitly why this owner is allowed
      // through even though it could not have applied the original chain, so an
      // operator reading the log is not left guessing.
      console.log(
        `db-compat preflight: PASS — no pending migration needs CREATE/ALTER ROLE or creates a\n` +
          `       SECURITY DEFINER function, so this owner profile is sufficient for this deploy.\n` +
          `       (Note: ${pending.length === 0 ? 'the chain is fully applied.' : 'the pending migrations need no privileged operation.'}\n` +
          `       A deploy that has to RUN ${ROLE_MIGRATION} or create a SECURITY DEFINER function\n` +
          `       would still require SUPERUSER, or CREATEROLE+BYPASSRLS on a cluster where\n` +
          `       "flexora_app" does not exist yet.)`,
      );
      return 0;
    }
    console.log('db-compat preflight: PASS — this owner profile is supported for the pending migrations.');
    return 0;
  }

  console.error(
    '\n' +
      `FATAL: the database owner "${attrs.role_name}" cannot apply the ${pending.length} PENDING migration(s).\n` +
      `       No migration has been applied and no schema was created.\n` +
      `       Pending: ${pending.slice(0, 8).join(', ')}${pending.length > 8 ? `, … (${pending.length} total)` : ''}\n\n` +
      decision.missing.map((m) => `       • ${m}`).join('\n\n') +
      '\n\n' +
      '       What the PENDING migrations need from the migration owner (DIRECT_URL):\n' +
      '         R1  SUPERUSER; or CREATEROLE when "flexora_app" does not exist yet.\n' +
      '             On a cluster where it already exists, only a SUPERUSER can apply\n' +
      '             the chain — ADMIN OPTION is not enough.\n' +
      '         R2  SUPERUSER or BYPASSRLS, so the SECURITY DEFINER pre-auth functions\n' +
      '             can read through FORCE ROW LEVEL SECURITY.\n\n' +
      '       Neither requirement is re-checked for migrations that are ALREADY recorded\n' +
      '       as applied in public._prisma_migrations, so a routine redeploy on a managed\n' +
      '       database (non-superuser owner, chain already applied) is not blocked.\n\n' +
      '       Fix: run migrations with a role that satisfies both (DIRECT_URL) while the\n' +
      '       application keeps using the restricted runtime role (DATABASE_URL):\n' +
      '         ALTER ROLE <owner> WITH CREATEROLE BYPASSRLS;   -- fresh cluster\n' +
      '       See docs/DEPLOYMENT.md → "Database owner profiles" and\n' +
      '       docs/DATABASE_SETUP.md. To reproduce the full matrix run\n' +
      '       scripts/check-db-compat.sh.',
  );
  return 1;
}

// Only run when executed directly (`ts-node prisma/preflight-db-compat.ts`).
// Importing this module — as the unit spec does — must not connect to a database
// or call process.exit().
if (require.main === module) {
  main()
    .then((code) => process.exit(code))
    .catch((e) => {
      console.error(`FATAL: db-compat preflight crashed: ${(e as Error).message}`);
      process.exit(1);
    });
}
