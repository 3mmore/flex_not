import { PrismaClient, Gender } from '@prisma/client';
import * as argon2 from 'argon2';
import { randomBytes } from 'crypto';

const prisma = new PrismaClient();
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

const GYMS = [
  { name: 'Load Test Gym Alpha', slug: 'alpha', email: 'owner@alpha.flexora.app', phone: '01000000001' },
  { name: 'Load Test Gym Beta', slug: 'beta', email: 'owner@beta.flexora.app', phone: '01000000002' },
  { name: 'Load Test Gym Gamma', slug: 'gamma', email: 'owner@gamma.flexora.app', phone: '01000000003' },
];

async function main() {
  const hash = await argon2.hash('LoadTestPassword123!');
  const results: { gymId: string; ownerEmail: string; memberCodes: string[]; productIds: string[] }[] = [];

  for (const g of GYMS) {
    const existing = await prisma.gym.findUnique({ where: { slug: g.slug } });
    if (existing) {
      console.log(`Gym ${g.slug} already exists, skipping creation`);
      const members = await prisma.member.findMany({ where: { gymId: existing.id }, take: 200, select: { code: true } });
      const products = await prisma.product.findMany({ where: { gymId: existing.id }, take: 20, select: { id: true } });
      results.push({ gymId: existing.id, ownerEmail: g.email, memberCodes: members.map(m => m.code), productIds: products.map(p => p.id) });
      continue;
    }

    const gym = await prisma.gym.create({
      data: {
        name: g.name,
        slug: g.slug,
        status: 'ACTIVE',
        email: g.email,
        phone: g.phone,
        branches: { create: [{ name: 'Main Branch', address: 'Test Address', phone: g.phone }] },
        plans: { create: [
          { name: '1 Month', type: 'TIME', days: 30, price: 450 },
          { name: '3 Months', type: 'TIME', days: 90, price: 1100 },
          { name: '15 Sessions', type: 'SESSION', sessions: 15, days: 60, price: 600 },
        ] },
        license: { create: { key: `LOAD-${randomBytes(4).toString('hex').toUpperCase()}`, status: 'ACTIVE', seats: 100, branchesAllowed: 5, expiresAt: addDays(new Date(), 365) } },
        subscription: { create: { tier: 'ELITE', status: 'ACTIVE', currentPeriodEnd: addDays(new Date(), 30) } },
      },
      include: { branches: true, plans: true },
    });

    const branch = gym.branches[0];
    const plan1m = gym.plans.find(p => p.name === '1 Month')!;
    const plan3m = gym.plans.find(p => p.name === '3 Months')!;
    const plan15 = gym.plans.find(p => p.name === '15 Sessions')!;

    const owner = await prisma.user.create({
      data: { gymId: gym.id, branchId: branch.id, name: 'Owner', email: g.email, passwordHash: hash, role: 'OWNER' },
    });

    // Create 70 members per gym (210 total)
    const memberCodes: string[] = [];
    const memberData = Array.from({ length: 70 }, (_, i) => {
      const code = `FLEX-${g.slug.toUpperCase().slice(0,3)}-${String(i+1).padStart(5,'0')}`;
      memberCodes.push(code);
      const isSession = i % 3 === 0;
      return {
        gymId: gym.id,
        branchId: branch.id,
        planId: isSession ? plan15.id : plan1m.id,
        code,
        name: `Member ${g.slug} ${i+1}`,
        mobile: `01${[0,1,2,5][i%4]}${String(10000000 + i).slice(1)}`,
        gender: (i % 2 === 0 ? 'MALE' : 'FEMALE') as Gender,
        startDate: addDays(new Date(), -(i % 40)),
        expiry: isSession ? null : addDays(new Date(), 30 + (i % 60)),
        sessionsLeft: isSession ? (i % 15) : 0,
        visits: Math.floor(i / 2),
      };
    });
    await prisma.member.createMany({ data: memberData });

    // Create 5-10 products per gym
    const products = [
      // FIX (load test): quantities raised to 10000 to prevent stock depletion
      // during k6 runs (200+ VUs × 30s × 3 products would otherwise exhaust
      // the old 50/30/200 stock well before the test ends, causing legitimate
      // "Insufficient stock" failures that are NOT a concurrency bug).
      { name: 'Whey Protein', category: 'protein', barcode: `BAR-${g.slug}-001`, sellingPrice: 1450, costPrice: 1050, qty: 10000 },
      { name: 'Creatine', category: 'creatine', barcode: `BAR-${g.slug}-002`, sellingPrice: 520, costPrice: 360, qty: 10000 },
      { name: 'Water 600ml', category: 'water', barcode: `BAR-${g.slug}-003`, sellingPrice: 10, costPrice: 5, qty: 10000 },
      { name: 'Pre-workout', category: 'supplement', barcode: `BAR-${g.slug}-004`, sellingPrice: 850, costPrice: 600, qty: 10000 },
      { name: 'BCAA', category: 'supplement', barcode: `BAR-${g.slug}-005`, sellingPrice: 450, costPrice: 300, qty: 10000 },
      { name: 'Gloves', category: 'accessory', barcode: `BAR-${g.slug}-006`, sellingPrice: 150, costPrice: 80, qty: 10000 },
      { name: 'Shaker', category: 'accessory', barcode: `BAR-${g.slug}-007`, sellingPrice: 120, costPrice: 60, qty: 10000 },
      { name: 'Energy Bar', category: 'snack', barcode: `BAR-${g.slug}-008`, sellingPrice: 35, costPrice: 18, qty: 10000 },
    ];
    const productIds: string[] = [];
    for (const p of products) {
      const prod = await prisma.product.create({
        data: { gymId: gym.id, name: p.name, category: p.category, barcode: p.barcode, sellingPrice: p.sellingPrice, costPrice: p.costPrice, qty: p.qty, lowStockThreshold: 5 },
      });
      productIds.push(prod.id);
    }

    results.push({ gymId: gym.id, ownerEmail: g.email, memberCodes, productIds });
    console.log(`Seeded ${g.slug}: ${memberCodes.length} members, ${productIds.length} products`);
  }

  console.log('Load test seed complete.');
  console.log(JSON.stringify(results, null, 2));
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
