const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

async function main() {
  const gym = await prisma.gym.findUnique({ where: { slug: 'alpha' }, include: { branches: true, plans: true } });
  if (!gym) { console.log('alpha gym not found'); return; }
  const branch = gym.branches[0];
  const plan1m = gym.plans.find(p => p.name === '1 Month');
  const plan15 = gym.plans.find(p => p.name === '15 Sessions');

  const memberData = [];
  for (let i = 0; i < 60; i++) {
    const code = `FLEX-ALP-${String(i+1).padStart(5,'0')}`;
    const isSession = i % 3 === 0;
    const rec = {
      gymId: gym.id, branchId: branch.id,
      planId: isSession ? plan15.id : plan1m.id,
      code, name: `Member alpha ${i+1}`,
      mobile: `01${[0,1,2,5][i%4]}${String(10000000 + i).slice(1)}`,
      gender: i % 2 === 0 ? 'MALE' : 'FEMALE',
      startDate: addDays(new Date(), -(i % 40)), visits: Math.floor(i / 2),
    };
    if (!isSession) rec.expiry = addDays(new Date(), 30 + (i % 60));
    else rec.sessionsLeft = i % 15;
    memberData.push(rec);
  }
  await prisma.member.createMany({ data: memberData });
  console.log(`Added 60 members to alpha. Total alpha: ${await prisma.member.count({ where: { gymId: gym.id } })}`);
}
main().catch(console.error).finally(() => prisma.$disconnect());
